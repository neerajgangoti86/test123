<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12"> 
	  <ul class="timeline">
                <!-- timeline time label -->
                <!--<li class="time-label">
                  <span class="bg-red">
                    10 Feb. 2014
                  </span>
                </li>-->
                <!-- /.timeline-label -->
                <!-- timeline item -->
             <?php if($activityfeed->rowCount()>0){ while($actfeed = $activityfeed->fetch()){ ?>
               <li>
                  <i class="fa fa-user bg-aqua"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-clock-o"></i> <?= $actfeed['activity_time'];?> </span>
                    <h3 class="timeline-header no-border"> <?= $actfeed['initiator_name'] ?> <?= $actfeed['activity_type'] ?> From IP <?= $actfeed['ip_address'] ?> </h3>
                  </div>
                </li>
             <?php } }else{ echo '<li>No activity found.</li>';} ?>
                <!-- END timeline item -->
               
                <li>
                  <i class="fa fa-clock-o bg-gray"></i>
                </li>
              </ul>
      </div>
    </div>
  </section>
  <!-- Main content -->