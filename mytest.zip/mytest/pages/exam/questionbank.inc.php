<!-- Main content -->
<script src="http://cdn.ckeditor.com/4.5.6/standard-all/ckeditor.js"></script>
<script src="<?= ASSETS_FOLDER ?>/js/plugin.js"></script>

<section class="content">
    <div class="row">
        <div class="col-md-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title" >
                        <?php
                        if (http_get('param1') == "add" && @$step != "step2") {
                            ?>Question Paper Preparation
                            <?php
                        } else {
                            ?>
                            Question Paper Generator
                            <?php
                        }
                        ?></h3>
                    <h3 class="box-title"><a href="<?php echo CLIENT_URL . "/view-questions" ?>" type="button" class="btn bg-olive btn-flat margin">View Questions</a></h3>
                </div>

                <?php
                if (http_get('param1') == "add") {
                    ?><form  method="post" id="add_question">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>" />
                        <div class="box-body">
                            <div class="row"> 
                                <div class="form-group">
                                    <div class="col-md-3"><label>Class:<span class="text-red">*</span></label></div>
                                    <div class="col-md-3"><?php
                                        $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//                                              print_r($classs);  
                                        ?>  <select id="class_id" name="class_id" class="form-control " onchange="this.form.submit()"  >
                                        <?php
                                        foreach ($classs as $class) {
                                            if ((@$selected_class == $class['class_no']) && (@$selected_class != NULL)) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                                <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                    <?= $class['class_name']; ?>
                                                </option>
                                            <?php } ?>

                                        </select>
                                    </div>
                                    <div class="col-md-3"><label>Subject:<span class="text-red">*</span></label></div>
                                    <div class="col-md-3"> <?php
                                        $subjects = Master::get_School_subject($MSID, '', @$selected_class)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                                        ?>   <select id="subject" name="subject" class="form-control"  onchange="this.form.submit()"  >


                                            <?php
                                            foreach ($subjects as $subject) {
                                                if (@$selected_subject == $subject['name']) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $subject['name']; ?>" <?= $selected ?>  >
                                                    <?= $subject['name']; ?>
                                                </option>
                                            <?php } ?>
                                        </select></div>
                                    <div class="col-md-4"></div>

                                </div>
                            </div>
                        </div>
                        <?php
                        $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($classs as $class) {
                            if ((@$selected_class == $class['class_no']) && (@$selected_class != NULL) && (@$selected_subject)) {
                                ?>

                                <p>&nbsp;</p>

                                <div class="box box-success">
                                    <div class="box-header">
                                        <h3 class="box-title">Type Your Question Here</h3>
                                        <br/> <br/>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <textarea id="editor1" name="editor1"> 
                                                </textarea><script>
                                                    CKEDITOR.replace('editor1', {
                                                         filebrowserBrowseUrl: '/browser/browse.php',
                                                          filebrowserUploadUrl: '/uploader/upload.php',
                                                        extraPlugins: 'mathjax',
                                                        
                                                        mathJaxLib: 'http://cdn.mathjax.org/mathjax/2.2-latest/MathJax.js?config=TeX-AMS_HTML',
                                                        height: 150
                                                    });
                                                    CKEDITOR.replace('editor1', {
                                                        extraPlugins: 'imageuploader'
                                                    });
                                                  
                                                    
                                                    
if (CKEDITOR.env.ie && CKEDITOR.env.version == 8) {
                                                        document.getElementById('ie8-warning').className = 'tip alert';
                                                    }
                                 </script>
                                            </div>
                                        </div>

                                        <br/> <br/>
                                        <h3 class="box-title">Question Discription </h3>
                                        <br/> <br/>

                                        <div class="row">
                                            <div class="col-md-2">  
                                                <h4> Marks</h4> </div>

                                            <div class="col-md-2">  
                                                <h4> Chapter</h4> </div>
                                            <div class="col-md-2">  

                                                <h4>  Level  </h4> </div>
                                            <div class="col-md-2">  
                                                <h4>  Importance </h4></div>
                                            <div class="col-md-2">  
                                                <h4> Type </h4></div>

                                            <!--                             <div class="col-md-2">  
                                                                             <h4> Type </h4></div>-->

                                        </div>

                                        <div class="row">
                                            <div class="col-md-2"> 
                                                <input type="text" class="form-control " name="marks" value=""/>
                                            </div>
                                            <div class="col-md-2"> 
                                                <input type="text" class="form-control " name="chapter" value=""/>

                                            </div>
                                            <div class="col-md-2">  <select class="form-control " name="level">
                                                    <?php
                                                    $options_type = QuestionBank::get_questions_options('ms_q_level')->fetchAll(PDO::FETCH_ASSOC);
                                                    foreach ($options_type as $qtype) {

                                                        if ($qtype['ID'] == 2) {
                                                            $selected = "selected";
                                                        } else {
                                                            $selected = "";
                                                        }
                                                        ?>
                                                        <option value="<?= $qtype['ID'] ?>" <?= $selected ?> ><?= $qtype['NAME'] ?></option>         
                                                    <?php } ?>   </select>
                                            </div>
                                            <div class="col-md-2">
                                                <select class="form-control" name="imp">
                                                    <?php
                                                    $imp_type = QuestionBank::get_questions_options('ms_q_importance')->fetchAll(PDO::FETCH_ASSOC);
                                                    foreach ($imp_type as $itype) {

                                                        if ($itype['ID'] == 2) {
                                                            $selected = "selected";
                                                        } else {
                                                            $selected = "";
                                                        }
                                                        ?><option value="<?= $itype['ID'] ?>" <?= $selected ?>><?= $itype['NAME'] ?></option>
            <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-md-2"> 
                                                <select class="form-control " name="type">
            <?php $q_type = QuestionBank::get_questions_options('ms_q_type', $MSID, $selected_class, $selected_subject)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($q_type as $questype) {
                ?>

                                                        <option value="<?= $questype['ID'] ?>"><?= $questype['TYPE_NAME'] ?></option> <?php } ?>
                                                </select>
                                            </div>

                                        </div>

                                        <br/> <br/>
                                        <div class="row"> <div class="col-md-4"></div><div class="col-md-4">
                                                <button type="submit" value="add" name="insert_que"  class="btn btn-lg btn-success btn-block">Submit</button><div class="col-md-4"></div> </div></div></div></div></form>

            <?php
        }
    }
} else {
    ?>

                    <form  method="post" id="print_question">
                        <div class="box-body">
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-3"><label>Class:<span class="text-red">*</span></label></div>
                                    <div class="col-md-3">  <select id="class_id" name="class_id" class="form-control " onchange='this.form.submit()' ><option>Select</option>


                                            <?php
                                            $classs = QuestionBank::get_exam_questions_class($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                            ?>

                                                <?php
                                                foreach ($classs as $class) {
                                                    if (@$selected_class == $class['CLASS']) {
                                                        $selected = 'selected = "selected"';
                                                    } else {
                                                        $selected = "";
                                                    }
                                                    ?>
                                                <option value="<?= $class['CLASS']; ?>" <?= $selected ?> >
                                                <?php $class_na = Master::get_class_names($MSID, $class['CLASS'])->fetch(PDO::FETCH_OBJ); ?><?= $class_na->class_name ?>
                                                </option>
                                                <?php
                                            }
//                                            if (@$selected_class)
//                                                {
//                                                
//                                                }
//                                            else
//                                                {
//                                                
                                            ?>
                                            <!--                                                <option value="" selected="selected" >
                                                                                                Select Class
                                                                                            </option>-->
    <?php //}
    ?>
                                        </select>
                                    </div>

                                            <?php
                                            if (@$selected_class) {
                                                ?> 

                                        <div class="col-md-3"><label>Subject:<span class="text-red">*</span></label></div>
                                        <div class="col-md-3">   <select id="subject" name="subject" class="form-control " onchange="this.form.submit()"  ><option value="">Select</option>
                                                <?php
                                                $subjects = QuestionBank::get_exam_questions_subject($MSID, $selected_class)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                                                ?>

                                                    <?php
                                                    foreach ($subjects as $subject) {
                                                        if (@$selected_subject == $subject['SUBJECT']) {
                                                            $selected = 'selected = "selected"';
                                                        } else {
                                                            $selected = "";
                                                        }
                                                        ?>
                                                    <option value="<?= $subject['SUBJECT']; ?>"  <?= $selected ?> >
            <?= $subject['SUBJECT']; ?>
                                                    </option>
                                <?php } ?>
                                            </select>
                                        </div>

                                    </div>
    <?php } ?>


                            </div>
                            <br/>
                                    <?php if (@$selected_subject) { ?>
                                <div class="row">

                                    <div class="col-md-3">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" checked class="checkbox"  id="selectall1"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Sub Subjects</label>
                                        </div>
        <?php
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'SUBSUBJECT', $selected_subject);
        while ($rowvs = $get_su->fetch()) {
            ?>&nbsp;&nbsp;&nbsp;<input type="checkbox" checked  class="checkbox1" value="<?= $rowvs['SUBSUBJECT']; ?>" name="sub_group[]"> <?= $rowvs['SUBSUBJECT']; ?>

                                            <br>                                          
        <?php } ?>


                                    </div>         
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" checked class="checkbox"  id="selectall2"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Chapter</label>
                                        </div>
        <?php
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'CHAPTER', $selected_subject);
        while ($rowvs = $get_su->fetch()) {
            ?>&nbsp;&nbsp;&nbsp;<input type="checkbox" checked  class="checkbox2" value="<?= $rowvs['CHAPTER']; ?>" name="chapter[]"> <?= $rowvs['CHAPTER']; ?>

                                            <br>                                          
        <?php } ?>


                                    </div>  

                                    <div class="col-md-3">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" checked class="checkbox"  id="selectall3"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Difficulty Level</label>
                                        </div>
        <?php
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'LEVEL_ID', $selected_subject);
        while ($rowvs = $get_su->fetch()) {
            ?>&nbsp;&nbsp;&nbsp;<input type="checkbox"  checked class="checkbox3" value="<?= $rowvs['LEVEL_ID']; ?>" name="d_level[]"> <?= $rowvs['LEVEL_ID']; ?>

                                            <br>                                          
        <?php } ?>


                                    </div>  
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" checked class="checkbox"  id="selectall4"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Importance</label>
                                        </div>
        <?php
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'IMPORTANCE_LEVEL', $selected_subject);
        while ($rowvs = $get_su->fetch()) {
            ?>&nbsp;&nbsp;&nbsp;<input type="checkbox" checked  class="checkbox4" value="<?= $rowvs['IMPORTANCE_LEVEL']; ?>" name="importance[]"> <?= $rowvs['IMPORTANCE_LEVEL']; ?>

                                            <br>                                          
        <?php } ?>


                                    </div>  
                                </div><?php } ?>






                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="submit" value="fds" name="psubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div></form> 
                </div>  <?php } ?>
        </div>
        <!-- /.box -->
    </div> 
</div>
</section><!-- Main content -->

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        
         $('#selectall1').click(function (event) {
            if (this.checked) {
                $('.checkbox1').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox1').each(function () {
                    this.checked = false;
                });
            }
        });    $('#selectall2').click(function (event) {
            if (this.checked) {
                $('.checkbox2').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox2').each(function () {
                    this.checked = false;
                });
            }
        });    $('#selectall3').click(function (event) {
            if (this.checked) {
                $('.checkbox3').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox3').each(function () {
                    this.checked = false;
                });
            }
        }); 
           $('#selectall4').click(function (event) {
            if (this.checked) {
                $('.checkbox4').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox4').each(function () {
                    this.checked = false;
                });
            }
        }); 
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>