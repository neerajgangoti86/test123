<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title" >
                        <?php
                        if (http_get('param1') == "add" && @$step != "step2")
                            {
                            ?>Create Question Bank 
                            <?php
                            }
                        else
                            {
                            ?>
                            Question paper generator
                            <?php
                            }
                        ?></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <!--          <form method="post" action="" role="form">-->
                <?php
                if (http_get('param1') == "add" && @$step != "step2")
                    {
                    ?><form  method="post" id="attendance_form_id">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>" />
                        <div class="box-body">
                            <div class="row">
                                 <div class="form-group">
                                        <div class="col-md-3"><label>Class:<span class="text-red">*</span></label></div>
                                        <div class="col-md-3"><?php
        $classs = QuestionBank::get_exam_questions_class($MSID)->fetchAll(PDO::FETCH_ASSOC);
//                                              print_r($classs);  ?>  <select id="class_id" name="class_id" class="form-control "  >


        

                                                <?php
                                                foreach ($classs as $class)
                                                    {
                                                    if (@$selected_class == $class['class_no'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                        <?= $class['class_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
//                                            if (@$selected_class)
//                                                {
//                                                
//                                                }
//                                            else
//                                                {
//                                                
                                                ?>
                                                <!--                                                <option value="" selected="selected" >
                                                                                                    Select Class
                                                                                                </option>-->
                                                <?php //}
                                                ?>
                                            </select>
                                        </div>
                                       
                               <div class="form-group">
                                        <div class="col-md-3"><label>Subject:<span class="text-red">*</span></label></div>
                                        <div class="col-md-3">   <select id="subject" name="subject" class="form-control "  >
                                                <?php
                                                $subjects = QuestionBank::get_exam_questions_subject($MSID, $selected_class, $selected_subject) ->fetchAll(PDO::FETCH_ASSOC);
                                            print_r($subjects) ;    
                                                ?>

                                                <?php
                                                foreach ($subjects as $subject)
                                                    {
                                                    ?>
                                                    <option value="<?= $subject['name']; ?>"  >
                                                        <?= $subject['name']; ?>
                                                    </option>
                                                <?php } ?>
                                            </select></div>
                                        </div>
                                <!--                                <div class="col-md-8">
                                                                    <div class="form-group">
                                                                        <div class="col-md-4"><label>Assesment:<span class="text-red">*</span></label></div>
                                                                        <div class="col-md-4">   <select id="subject" name="assesment" class="form-control "  >
                                <?php
//                                                $subjects = SuperAdmin::get_schoolwise_subject($MSID)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
//                                                foreach ($assesments as $assesment)
//                                                    {
//                                                    if ($selected_assesment == $assesment['assesment_id'])
//                                                        {
//                                                        $selected = 'selected = "selected"';
//                                                        }
//                                                    else
//                                                        {
//                                                        $selected = "";
//                                                        }
                                ?>
                                                                                    <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                <?= $assesment['title']; ?>
                                                                                    </option>
                                <?php // }     ?>
                                                                            </select></div>
                                                                        <br><br></div></div>-->

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Section :<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <select id="dlevel" name="section" class="form-control "  >

                                                <option value="A"  >A  </option>
                                                <option value="B"  >B  </option>
                                                <option value="C"  >C  </option>
                                                <option value="D"  >D  </option>

                                            </select></div>
                                        <br><br> </div></div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Section Title:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input type="text" name="section_title" class="form-control "  required>


                                        </div>
                                        <br><br> </div></div> <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Chapter No:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="chapter" required></div>
                                        <br><br></div></div>

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Question Title:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="question_title" required></div>
                                        <br><br></div></div>

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Difficulty Level:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <select id="dlevel" name="dlevel" class="form-control"  required>

                                                <option value="1"  >Easy  </option>
                                                <option value="2"  >Moderate  </option>
                                                <option value="3"  >High  </option>

                                            </select></div>
                                        <br><br> </div></div><div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Number of Questions:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="noq" required></div>
                                        <br><br> </div></div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Maximum Marks:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="max_marks" required></div>
                                        <br><br></div></div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>
                    </form><?php
                    }
                else if (@$step == "step2" && http_get('param1') == "add")
                    {
                    ?>
                    <form  method="post" id="attendance_form_id">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="noq" value="<?= $_POST['noq'] ?>" /> 
                        <input type="hidden" name="max_marks" value="<?= $_POST['max_marks'] ?>" />
                        <input type="hidden" name="dlevel" value="<?= $_POST['dlevel'] ?>" />
                        <input type="hidden" name="question_title" value="<?= $_POST['question_title'] ?>" />
                        <input type="hidden" name="chapter" value="<?= $_POST['chapter'] ?>" /> 
                        <input type="hidden" name="section_title" value="<?= $_POST['section_title'] ?>" />
                        <input type="hidden" name="section" value="<?= $_POST['section'] ?>" /> 
                        <input type="hidden" name="subject" value="<?= $_POST['subject'] ?>" />
                        <input type="hidden" name="class_id" value="<?= $_POST['class_id'] ?>" /> 
                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>" />
                        <div class="box-body">
                            <div class="row"><div class="col-md-8">
                                    <?php
                                    $all = $_POST['noq'];
                                    for ($i = 0; $i < $all; $i++)
                                        {
                                        ?> 
                                        <div class="row"><div class="form-group">
                                                <div class="col-md-4"><label>Question No:<span class="text-red">*</span></label></div>
                                                <div class="col-md-4">    
                                                    <input type="hidden" value="<?= $i + 1 ?>" name="q_no[]"><label><?= $i + 1 ?></label>


                                                </div></div>
                                        </div>
                                        <div class="row"><div class="form-group">
                                                <div class="col-md-4"><label>Question :<span class="text-red">*</span></label></div>
                                                <div class="col-md-4">    <textarea name="question[]" rows="7" cols="100" required="required"></textarea>


                                                </div></div>
                                        </div> <hr><?php } ?> 
                                </div></div>
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="submit" name="ssubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div></div>
                    </form><?php
                    }
                else if (@$state == "true")
                    {
                    ?>
                    <form  method="post" id="attendance_form_id">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="noq" value="<?php echo @$_POST['noq']; ?>" /> 
                        <br> <div class="row" >

                            <div class="col-md-1">
                            </div><div class="col-md-4"><b>Time</b></div>
                            <div class="col-md-5"><select id="dlevel" class="form-control" name="time"  required>

                                    <option value="1"  >1 Hr  </option>
                                    <option value="2"  >2 Hr</option>
                                    <option value="3"  >3 Hr  </option>

                                </select></div>
                            <div class="col-md-1"></div>
                        </div>
                        <div class="row" >

                            <div class="col-md-1">
                            </div><div class="col-md-4"><b>Instructions</b></div>
                            <div class="col-md-5">
                                <input type="text" value="All questions are compulsory. " name="i1" required class="form-control">
                                <input type="text" value="Handwriting should be legible." name="i2"  class="form-control">
                                <input type="text" value="" name="i3"  class="form-control">
                                <input type="text" value="" name="i4"  class="form-control">
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                        <br>
                        <?php
                        if ($totalrecords > 0)
                            {
                            ?>
                            <table class="table table-hover" id="example1">
                                <thead style="background:#ddd;">
                                    <tr>
                                        <th>Q.No </th>
                                        <th>Question Title</th>
                                        <th>Question</th>
                                        <th>Difficulty Level</th>
                                        <th>Marks</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
//                                while ($rowv = $homeworks->fetch()) {
//                                $hw = Homework::get_homeworks($MSID, '', $id, $section_id);



                                    while ($rowv = $questions->fetch())
                                        {
//                                        print_r($rowv);
//                                        exit();
                                        $class_work = Master::get_classes($MSID, '', '', '', $rowv['class'])->fetch(PDO::FETCH_ASSOC);
                                        ?>
                                        <tr> <td><?= $rowv['q_no']; ?></td>
                                            <td><?= $rowv['sub_group']; ?></td>
                                            <td><?= $rowv['question']; ?></td>
                                            <td><?php
//                                                if ($rowv['d_level'] == "1")
//                                                    {
//                                                    echo "";
//                                                    }
//                                                else 
                                                if ($rowv['d_level'] == "2")
                                                    {
                                                    echo "Moderate";
                                                    }
                                                else if ($rowv['d_level'] == "3")
                                                    {
                                                    echo "High";
                                                    }
                                                else
                                                    {
                                                    echo "Easy";
                                                    }
                                                ?></td>
                                            <td><?= $rowv['marks'] ?></td>                                                
                                    <input type="hidden" name="assesment" value="<?php echo $_POST['assesment']; ?>">
                                    <input type="hidden" name="class" value="<?php echo $_POST['class_id'] ?>">
                                    <input type="hidden" name="subject" value="<?= $rowv['subject'] ?>">
                                                <!--<td><?= $rowv['subject']; ?></td>-->

                                    <td> <input type="checkbox" value="<?= $rowv['q_id']; ?>" name="ques[]"></td>
                                    </tr>
                                    <?php
                                    $i++;
                                    }
                                ?>
                                </tbody>
                            </table>
                            <?php
                            }
                        else
                            {
                            echo '<div class="text-center margin">No records found.</div>';
                            }
                        ?>
                        <div class="row">
                            <div class="col-md-4"></div><div class="col-md-4">
                                <button type="submit" name="spssubmit"  value="asd" class="btn btn-lg btn-success btn-block">Submit</button></div><div class="col-md-4"></div>
                        </div> 
                    </form><?php
                    }
                
                 else   {
                    ?>

                    <form  method="post" id="print_question">
                        <div class="box-body">
                            <div class="row">
                                 <div class="form-group">
                                   <div class="col-md-3"><label>Class:<span class="text-red">*</span></label></div>
                                        <div class="col-md-3">  <select id="class_id" name="class_id" class="form-control " onchange='this.form.submit()' >


                                                <?php
                                                $classs = QuestionBank::get_exam_questions_class($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                                ?>

                                                <?php
                                                foreach ($classs as $class)
                                                    {
                                                    if (@$selected_class == $class['class'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class['class']; ?>" <?= $selected ?> >
                                                        <?php $class_na= Master::get_class_names($MSID, $class['class'])->fetch(PDO::FETCH_OBJ);   ?><?= $class_na->class_name ?>
                                                    </option>
                                                    <?php
                                                    }
//                                            if (@$selected_class)
//                                                {
//                                                
//                                                }
//                                            else
//                                                {
//                                                
                                                ?>
                                                <!--                                                <option value="" selected="selected" >
                                                                                                    Select Class
                                                                                                </option>-->
                                                <?php //}
                                                ?>
                                            </select>
                                        </div>
                                      
                                <?php
                                if (@$selected_class)
                                    {
                                    ?> 
                                       
                                            <div class="col-md-3"><label>Subject:<span class="text-red">*</span></label></div>
                                            <div class="col-md-3">   <select id="subject" name="subject" class="form-control " onchange="this.form.submit()"  >
                                                    <?php
                                                   $subjects = QuestionBank::get_exam_questions_subject($MSID, $selected_class) ->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                                                    ?>

                                                    <?php
                                                    foreach ($subjects as $subject)
                                                        {
                                                          if (@$selected_subject == $subject['subject'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = ""; ?>
                                                    <option value="">Select</option>
                                                    <?php    }
                                                        ?>
                                                        <option value="<?= $subject['subject']; ?>"  <?= $selected ?> >
                                                            <?= $subject['subject']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                            
                            </div>
                                   <?php } ?>


                            </div>
                            <br/>
                            <?php if(@$selected_subject){ ?>
                            <div class="row">
                                
                            <div class="col-md-3">
                               <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" class="checkbox"  id="selectall1"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Sub Subjects</label>
                                        </div>
                                <?php 
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'sub_group', $selected_subject);
        while ($rowvs = $get_su->fetch())
                                        {
        ?>&nbsp;&nbsp;&nbsp;<input type="checkbox"  class="checkbox1" value="<?= $rowvs['sub_group']; ?>" name="sub_group[]"> <?= $rowvs['sub_group']; ?>
                                            
  <br>                                          
                                <?php } ?>

                                            
                            </div>         
                                <div class="col-md-3">
                                    <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" class="checkbox"  id="selectall2"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Chapter</label>
                                        </div>
                                <?php 
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'chapter', $selected_subject);
        while ($rowvs = $get_su->fetch())
                                        {
        ?>&nbsp;&nbsp;&nbsp;<input type="checkbox"  class="checkbox2" value="<?= $rowvs['chapter']; ?>" name="sub_group[]"> <?= $rowvs['chapter']; ?>
                                            
  <br>                                          
                                <?php } ?>

                                            
                            </div>  
                          
                                <div class="col-md-3">
                                    <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" class="checkbox"  id="selectall3"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Difficulty Level</label>
                                        </div>
                                <?php 
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'd_level', $selected_subject);
        while ($rowvs = $get_su->fetch())
                                        {
        ?>&nbsp;&nbsp;&nbsp;<input type="checkbox"  class="checkbox3" value="<?= $rowvs['d_level']; ?>" name="sub_group[]"> <?= $rowvs['d_level']; ?>
                                            
  <br>                                          
                                <?php } ?>

                                            
                            </div>  
                           <div class="col-md-3">
                               <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" class="checkbox"  id="selectall4"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2">Sub Subjects</label>
                                        </div>
                                <?php 
        $get_su = QuestionBank::get_questions_subsubject($MSID, $selected_class, 'sub_group', $selected_subject);
        while ($rowvs = $get_su->fetch())
                                        {
        ?>&nbsp;&nbsp;&nbsp;<input type="checkbox"  class="checkbox4" value="<?= $rowvs['sub_group']; ?>" name="sub_group[]"> <?= $rowvs['sub_group']; ?>
                                            
  <br>                                          
                                <?php } ?>

                                            
                            </div>  
                            </div>
                                
                                
                                
                                
                                
                            </div><?php } ?>
                            <!-- \row end -->
                            <div class="row">
                     <div class="col-md-3">
                                    <button type="submit" name="psubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>
                                 <?php } ?>
            </div> 
            <!-- /.box -->
        </div> </form> 
    </div>
</section><!-- Main content -->

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        
         $('#selectall1').click(function (event) {
            if (this.checked) {
                $('.checkbox1').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox1').each(function () {
                    this.checked = false;
                });
            }
        });    $('#selectall2').click(function (event) {
            if (this.checked) {
                $('.checkbox2').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox2').each(function () {
                    this.checked = false;
                });
            }
        });    $('#selectall3').click(function (event) {
            if (this.checked) {
                $('.checkbox3').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox3').each(function () {
                    this.checked = false;
                });
            }
        }); 
           $('#selectall4').click(function (event) {
            if (this.checked) {
                $('.checkbox4').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox4').each(function () {
                    this.checked = false;
                });
            }
        }); 
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>