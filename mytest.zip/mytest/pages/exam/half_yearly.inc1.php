<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"> Half Yearly</h3>


                </div>
                <!-- /.box-header -->
                <div class="box-footer clearfix">
                    <table  border="1" align="center" cellpadding="2" cellspacing="2">
                        <tr>
                            <td width="100%">
                                <table width="658" height="491" align="center" bordercolor="#2A3F00">
                                    <tr align="left" valign="top">
                                        <td width="100%" height="76"><table width="99%" align="center">
                                                <tr>
                                                    <td colspan="3" align="center"><span class="m1">
                                                            <?= $oCurrentSchool->name ?>
                                                        </span></td>
                                                </tr>
                                                <tr>
                                                    <td width="90" align="left"><img    src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" width="75" height="75" class="logo"></td>
                                                    <td width="340" valign="top"><table width="333" border="0" align="center">
                                                            <tr>
                                                                <td width="327" align="center" ><span class="b1">
                                                                        <?= $oCurrentSchool->place ?> 
                                                                    </span></td>
                                                            </tr>
                                                            <tr>
                                                                <td align="center" class="b1"><span class="t1">
                                                                        <?= $oCurrentSchool->board ?>
                                                                    </span></td>
                                                            </tr>
                                                            <tr>
                                                                <td align="center" class="t1">&nbsp;</td>
                                                            </tr>
                                                        </table></td>
                                                    <td width="199" align="right" valign="top"><table width="100%" border="0" align="right">
                                                            <tr>
                                                                <td align="center">Phone No:</td>
                                                                <td align="right" class="r"><strong>
                                                                        <?= $oCurrentSchool->phone ?>   
                                                                    </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="107" class="r">Affiliation No.:</td>
                                                                <td width="109" align="right" class="r"><strong>
                                                                        <?= $oCurrentSchool->affNo ?>  
                                                                    </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td class="r"> School Code :</td>
                                                                <td align="right"><span class="r"><strong>
                                                                            <?= $oCurrentSchool->schoolNo ?>   
                                                                        </strong></span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><span class="r">Recognition No.:</span></td>
                                                                <td align="right"><strong class="r">
                                                                        <?= $oCurrentSchool->recNo ?>
                                                                    </strong></td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="22"><hr/></td>
                                    </tr>

                                    <tr align="left" valign="top">
                                        <td valign="top"><br />
                                            <table width="645" border="0" align="center">
                                                <tr>
                                                    <td width="30" rowspan="5" class="st4"></td>
                                                    <td colspan="2" class="b1"> 
                                                        <b><?php echo $student['name']; ?></b> </td>
                                                    <td width="3">&nbsp;</td>
                                                    <td width="179" class="st4">&nbsp;</td>
                                                    <td class="st4">&nbsp;</td>
                                                </tr>

                                                <tr>
                                                  <!--<td width="17" rowspan="5" valign="top"><?PHP //$img= $row['Photo'];        ?></td>-->
                                                    <td width="140" height="29" class="st4">Student Id: </td>
                                                    <td colspan="3" class="st4"><strong><?php echo $student['student_id']; ?> </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class:<strong>
                                                       <?= $class_id  ?> </strong>
                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Overall grade:</td>
                                                    <td width="116" class="st4"><strong>
                                                            <?php
                                                            $grade_sql = "SELECT Q1.student_id, Q1.Point,G.grade FROM (Select student_id, MSID, round(Sum( `marks_obtained`)/SUM(`max_marks`)*100,2) Point from `ms_exam_acedemic_performance`  WHERE   MSID='$MSID' AND `session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "') Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`percent_from` AND G.`percent_to`";
                                                            $oDb = DBConnection::get();
                                                            $grade_sql = $oDb->query($grade_sql);

                                                            while ($gow6 = $grade_sql->fetch()) {
                                                                echo $grade6 = $gow6['grade'];
                                                            }
                                                            ?>
                                                        </strong></td>
                                                </tr>

                                                <tr>
                                                    <td height="28" class="st4">Father's Name:</td>
                                                    <td colspan="3" class="st4"><strong>
                                                            <?php echo "Mr." . ' ' . $student['f_name']; ?>
                                                        </strong></td>
                                                    <td class="st4">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td height="28" class="st4">Mother's Name:</td>
                                                    <td colspan="3" class="st4"><strong>
                                                            <?php echo "Mrs." . ' ' . $student['m_name']; ?>
                                                        </strong></td>
                                                    <td class="st4">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td>&nbsp;</td>
                                                    <td width="151">&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td height="146" colspan="6"><table width="570" border="0" align="center">
                                                            <tr>
                                                                <td colspan="5" align="center"><strong class="st3"><u>Half Yearly Academic Performance<br />
                                                                            <br />
                                                                        </u></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="72" align="left"><strong class="st4">Subjects</strong></td>

                                                                <?php
                                                                $sql_assesments = "SELECT distinct title , id FROM `ms_exam_assesments` Where term='Term 1'  And MSID='$MSID' ";
                                                                $oDb = DBConnection::get();
                                                                $sql_assesments = $oDb->query($sql_assesments);
                                                                while ($rowv = $sql_assesments->fetch()) {
                                                                    ?>
                                                                    <td width="71" align="center" class="st4"><strong class="st4"><?= $rowv['title'] ?>
                                                                        </strong></td><?php } ?>

                                                                <td width="71" align="center" class="st4"><strong>Term grade</strong></td>
                                                            </tr>
                                                            <?php
                                                            $subjects_querry = "SELECT distinct subject_id FROM `ms_exam_acedemic_performance` Where  MSID='$MSID' and session='" . $_SESSION['year'] . "' and student_id='" . $student['student_id'] . "'";
                                                            $oDb = DBConnection::get();
                                                            $subjects_querry = $oDb->query($subjects_querry);
                                                            while ($rowv = $subjects_querry->fetch()) {
                                                                ?>
                                                                <tr class="st4">
                                                                    <?php
                                                                    $subjects = "SELECT subject_f_name FROM `ms_subjects_all` Where subject_id='" . $rowv['subject_id'] . "'";
                                                                    $oDb = DBConnection::get();
                                                                    $subjects = $oDb->query($subjects);
                                                                    while ($rowu
                                                                    = $subjects->fetch()) {
                                                                        ?><td><?= $rowu['subject_f_name'] ?></td>
                                                                        <?php
                                                                    }
                                                                    ?>

                                                                    <td width="132" align="center">
                                                                        <?php
                                                                        $fa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='1' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";

                                                                        $oDb = DBConnection::get();
                                                                        $fa1 = $oDb->query($fa1);
                                                                        while ($rowu
                                                                        = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                                            ?><?= $rowu['grade'] ?>
                                                                            <?php
                                                                        }
                                                                        ?></td>


<td width="147" align="center">
                                                                    <?php
                                                                    $fa2 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='2' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                    $oDb = DBConnection::get();
                                                                    $fa2 = $oDb->query($fa2);
                                                                    while ($rowu
                                                                    = $fa2->fetch()) {
                                                                        ?><?= $rowu['grade'] ?>
                                                                        <?php
                                                                    }
                                                                    ?>
</td>
                                                                <td width="75" align="center">    <?php
                                                                    $sa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='5' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                    $oDb = DBConnection::get();
                                                                    $sa1 = $oDb->query($sa1);
                                                                    while ($rowu
                                                                    = $sa1->fetch()) {
                                                                        ?><?= $rowu['grade'] ?></td>
                                                                        <?php
                                                                    }
                                                                    ?>


                                                                    <td width="122" align="center">
                                                                        <?php
                                                                        $overall
                                                                                = "SELECT Q1.student_id,Q1.subject_id,Q1.Term,Q1.Point,G.grade FROM (SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,SUM(ROUND(RD.`marks_obtained`/RD.`max_marks`*term_wtg,2)) Point FROM `ms_exam_acedemic_performance` RD INNER JOIN ms_exam_weightage W ON W.MSID=RD.MSID AND W.assesment_id=RD.assesment_id WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'  AND RD.`subject_id`='" . $rowv['subject_id'] . "'  And  W.term ='1' GROUP BY RD.student_id,RD.subject_id,W.term) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`percent_from` AND G.`percent_to`";
                                                                        $oDb = DBConnection::get();
                                                                        $overall
                                                                                = $oDb->query($overall);
                                                                        while ($rowu
                                                                        = $overall->fetch()) {
                                                                            ?><?= $rowu['grade'] ?>
    <?php } ?></td>
                                                                </tr><?php } ?>
                                                            <tr>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table>
                                            <br />
                                            <table width="570" border="1" align="center">
                                                <tr>
                                                    <td class="st4">Remarks:
                                                        <hr /><br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                    </td>
                                                </tr>
                                            </table>
                                            <br />
                                            <table width="570" border="0" align="center">
                                                <tr>
                                                    <td align="center">....................</td>
                                                    <td align="center">...........................</td>
                                                    <td align="center">........................</td>
                                                    <td align="center">.....................</td>
                                                </tr>
                                                <tr class="st4">
                                                    <td align="center"><strong>Mother</strong></td>
                                                    <td align="center"><strong>Father/Guardian</strong></td>
                                                    <td align="center"><strong>Class Teacher</strong></td>
                                                    <td align="center"><strong>Principal</strong></td>
                                                </tr>
                                            </table>
                                            <br />
                                            <br /></td>
                                    </tr>




















                                </table></td>
                        </tr>
                    </table>  
                    <br />





                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
    
     <table width="750" height="684" border="1"   align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td height="678"><table width="100%" height="672" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="704" height="140" align="center">
              <table width="100%" height="108" align="center">
                <tr>
                  <td width="87" height="102" align="left"><table width="88" border="0" align="center">
                    <tr>
                      <td width="82" height="92"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
                    </tr>
                  </table></td>
                  <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
                    <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
                    <tr>
                      <td width="539" height="32" align="center" class="m1"> <?php echo $sname;?> </td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="b1"> <? echo   $Place;  ?> </td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="n1">Website:<? echo $Website;?>,E-mail:<? echo $EMail;?>,Ph:<? echo $Phone;?></td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="n1">Affiliated to CBSE ,Delhi ,Affiliation No.:<? echo $AffiliationNo;?></td>
                    </tr>
                  </table>                    <span class="vks">Record of Academic Performance <? echo $session; ?></span></td>
                </tr>
              </table>      </td>
          </tr>
       
            
         <tr align="left" valign="top">
            <td height="184"><table width="100%" height="181" border="0" align="center">
              <tr valign="top" class="st42">
                <td width="139" rowspan="4"><img src="<?php  if($Photo!=""){echo $Photo;} else { 	echo"../../images/myprofile1.png";} ?>" alt="" width="122" height="127" style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" /></td>
                <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                <td height="27"><? echo $Name;?></td>
                <td height="27">&nbsp;</td>
                <td width="106" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                <td width="105" ><? echo $sid;?>&nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="31">Father's Name:</td>
                <td width="238" height="31">Mr. <? echo $FatherName;?></td>
                <td width="11" height="31">&nbsp;</td>
                <td>Roll No.:</td>
                <td><? echo $Roll_No;?>&nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="32">Mother's Name:</td>
                <td height="32">Mrs. <? echo $MotherName;?></td>
                <td height="32">&nbsp;</td>
                <td>Class:</td>
                <td><? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
                  &nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="31">Mobile</td>
                <td height="31"><? echo $F_Mobile;?></td>
                <td height="31">&nbsp;</td>
                <td>Date Of Birth: </td>
                <td><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?>
                  &nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td width="139">&nbsp;</td>
                <td height="38">Address:</td>
                <td height="38" colspan="4"><? echo $Add_ReportC;?></td>
              </tr>
            </table></td>
          </tr>
          <tr align="left" valign="top">
            <td height="78">
            
            <? //if($ULevel=='9'){ ?>
            <table width="100%" height="177" border="1" align="center">
              <tr valign="top" bgcolor="#E8E8E8">
                <td height="44" align="center" class="st411" valign="middle">&nbsp;</td>
                <td height="44" colspan="2" align="center"valign="middle" class="st411"><h3><strong>Unit III</strong></h3></td>
                <td height="44" colspan="2" align="center"valign="middle" class="st411"><strong>Unit IV</strong></td>
              </tr>
              <tr valign="top"  bgcolor="#C9C9C9">
                <td width="277" height="42" class="st411"><strong>Subjects</strong></td>
                <td width="121" class="st411" align="center"><strong>MARKS OBTAINED</strong></td>
                <td width="97" class="st411" align="center"><strong>MAX MARKS</strong></td>
                <td width="105" class="st411"  align="center"><strong>MARKS OBTAINED</strong></td>
                <td width="96" class="st411"  align="center"><strong>MAX MARKS</strong></td>
              </tr>
              <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid' and AssId='3' "); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
              <tr valign="top">
                <td height="39" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
                <td align="center" class="st411">&nbsp;
                  <?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,RD.`MaxMarks` FROM 
`21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){ $Grade8=$gowy8['MarksObtained']; echo round($Grade8); ?>
                  &nbsp;&nbsp;</td>
                <td align="center" class="st411"><? echo $MaxMarks8=$gowy8['MaxMarks']; ?></td><? }?>
                <td align="center" class="st411"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){ $Grade8=$gowy8['MarksObtained']; echo round($Grade8); ?></td>
                <td align="center" class="st411"><? echo $MaxMarks8=$gowy8['MaxMarks']; ?></td>
               
                <? } ?>
              </tr>
              <?php   } ?>
              <tr valign="top">
                <td height="40" class="st411"><strong>Total</strong></td>
                <td align="center" class="st411">&nbsp;
                  <?php   $ghiy10=mysql_query($ghy10="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,Sum(RD.`MarksObtained`)AS tmarks ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy10=mysql_fetch_array($ghiy10)){ $Grade10=$gowy10['tmarks']; echo round($Grade10); } ?>
                  &nbsp;</td>
                <td align="center" class="st411"><?php   $ghiy11=mysql_query($ghy11="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,Sum(RD.`MaxMarks`)AS tmaxmarks FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy11=mysql_fetch_array($ghiy11)){ $Grade11=$gowy11['tmaxmarks']; echo round($Grade11); } ?></td>
                <td align="center" class="st411"><?php   $ghiy10=mysql_query($ghy10="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,Sum(RD.`MarksObtained`)AS tmarks ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy10=mysql_fetch_array($ghiy10)){ $Grade10=$gowy10['tmarks']; echo round($Grade10); } ?></td>
                <td align="center" class="st411"><?php   $ghiy11=mysql_query($ghy11="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,Sum(RD.`MaxMarks`)AS tmaxmarks FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy11=mysql_fetch_array($ghiy11)){ $Grade11=$gowy11['tmaxmarks']; echo round($Grade11); } ?></td>
              </tr>
            </table>
            
            </td>
          </tr>
          
          <tr align="left" valign="top">
            <td height="122" valign="top"><table width="100%" height="103" border="0" align="center">
              <tr>
               <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"> <? $att1=mysql_query($aq1="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='1'"); 
				 while($at1=mysql_fetch_array($att1)){ $Term1WD= $at1['TWD']; $Term1Att= $at1['TERMATT']; $Term1Att ;  $Term1WD ; $tatt= ($Term1Att/$Term1WD) * 100 ;  round($tatt,2) ;} ?> <strong>REMARKS: &nbsp;&nbsp;<? $trjjrm=mysql_query($qjjrm="Select Remarks from 21Remarks where SID='$sid' AND  MSID='$msid'  AND Session='$session'");
				 while($ttjjrm=mysql_fetch_array($trjjrm)){ echo $remarks=$ttjjrm['Remarks']; }?></strong><br/>
                  </td>
              </tr><? //}else {}?>
              <tr>
                <td width="234" height="74" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
              </tr>
            </table></td>
          </tr>
         
        </table></td>
      </tr>
</table>  
