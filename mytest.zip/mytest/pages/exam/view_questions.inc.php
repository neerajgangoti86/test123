<!-- Main content -->

<?php if(@$selected_subject=='Maths'){ ?>
<script type="text/x-mathjax-config">
MathJax.Hub.Config({
  tex2jax: {
   displayMath: [['\(','\)']]
  }
});
</script>
<script type="text/javascript" src="http://cdn.mathjax.org/mathjax/2.2-latest/MathJax.js?config=TeX-AMS_HTML"></script><?php } ?>
<section class="content">
    <div class="row">
        <div class="col-md-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title" >

                        View All Questions
                    </h3>
                    <h3 class="box-title"><a href="<?php echo CLIENT_URL . "/question-bank/add" ?>" type="button" class="btn bg-olive btn-flat margin">Add Questions</a></h3>
                </div>

                <form  method="post" id="add_question">
                    <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                    <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>" />
                    <div class="box-body">
                        <div class="row"> 
                            <div class="form-group">
                                <div class="col-md-3"><label>Class:<span class="text-red">*</span></label></div>
                                <div class="col-md-3">
                                   <select id="class_id" name="class_id" class="form-control " onchange='this.form.submit()' ><option>Select</option>


                                            <?php
                                            $classs = QuestionBank::get_exam_questions_class($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                            ?>

                                            <?php
                                            foreach ($classs as $class) {
                                                if (@$selected_class == $class['CLASS']) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                     }
                                                    ?>
                                                <option value="<?= $class['CLASS']; ?>" <?= $selected ?> >
                                                <?php $class_na = Master::get_class_names($MSID, $class['CLASS'])->fetch(PDO::FETCH_OBJ); ?><?= $class_na->class_name ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                </div>
                              <?php
                                    if (@$selected_class) {
                                        ?> 

                                        <div class="col-md-3"><label>Subject:<span class="text-red">*</span></label></div>
                                        <div class="col-md-3">   <select id="subject" name="subject" class="form-control " onchange="this.form.submit()"  ><option value="">Select</option>
                                                <?php
                                                $subjects = QuestionBank::get_exam_questions_subject($MSID, $selected_class)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                                                ?>

                                                <?php
                                                foreach ($subjects as $subject) {
                                                    if (@$selected_subject == $subject['SUBJECT']) {
                                                        $selected = 'selected = "selected"';
                                                    } else {
                                                        $selected = "";
                                                       }
                                                        ?>
                                                    <option value="<?= $subject['SUBJECT']; ?>"  <?= $selected ?> >
                                                    <?= $subject['SUBJECT']; ?>
                                                    </option>
        <?php } ?>
                                    </select></div><?php } ?>

                          


                        </div>
                    </div>
            </div>
            <div class="box-body success">
                <table class="table table-hover">
                    <tr>
                        <th>Sr.No.</th>
                        <th>Question </th>
                        <th>Marks  </th> 
                        <th>Chapter  </th> 
                        <th>Type</th>   
                        <th>Level </th>  
                        <th>Importance </th>  
                        <th>Status </th> 
                        <th>Action </th> 

                    </tr>
                    <?php
                    $i = 1;


                    $data = QuestionBank::get_questions($MSID, @$selected_class, @$selected_subject);
//                    print_r($data);
                    while ($rowv = $data->fetch()) {
                        ?>


                        <tr>
                            <td><?= $i ?></td>
                            <td><?= $rowv['STATEMENT']; ?></td>
                            <td><?= $rowv['MARKS']; ?></td>
                            <td>Chapter <?= $rowv['CHAPTER']; ?></td>  
                            <td><?php $typename=  QuestionBank::get_questions_options('ms_q_type', $MSID, @$selected_class, @$selected_subject, $rowv['TYPE_ID'])->fetch(PDO::FETCH_OBJ);  ?> <?= $typename->CAPTION ?> </td>  
                            <td><?= $rowv['LEVEL_ID']; ?></td> 
                            <td><?= $rowv['IMPORTANCE_LEVEL']; ?></td> 
                            <td><?= $rowv['STATUS']; ?></td>  
                            <td> <a class="btn btn-info btn-flat" data-title="Edit Questions" href="<?= CLIENT_URL; ?>/Question-bank/edit/<?= $rowv['ID']; ?>">Edit</a>
                                            </td>  



                        </tr> 
                        <?php
                        $i++;
                    }
                    ?>
                </table>






            </div>                             
        </div>
        <!-- /.box -->
    </div> 
</div>
</section><!-- Main content -->

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        
         $('#selectall1').click(function (event) {
            if (this.checked) {
                $('.checkbox1').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox1').each(function () {
                    this.checked = false;
                });
            }
        });    $('#selectall2').click(function (event) {
            if (this.checked) {
                $('.checkbox2').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox2').each(function () {
                    this.checked = false;
                });
            }
        });    $('#selectall3').click(function (event) {
            if (this.checked) {
                $('.checkbox3').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox3').each(function () {
                    this.checked = false;
                });
            }
        }); 
           $('#selectall4').click(function (event) {
            if (this.checked) {
                $('.checkbox4').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox4').each(function () {
                    this.checked = false;
                });
            }
        }); 
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>