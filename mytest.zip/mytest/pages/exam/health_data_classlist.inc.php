<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"> Health Data Report</h3>
                    <a href="<?= CLIENT_URL ?>/health-data" title="View"><h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal">Add Health Details</button></h3></a>


                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <?php // if ($totalrecords > 0) { ?>
                        <table width="907" class="table table-hover">
                            <tr align="center">
                                <td width="63"   rowspan="2"><strong>Class</strong> </td>
                                <td width="58"  rowspan="2"><strong>Total</strong></td>
                                 <td width="89"  rowspan="2"><strong>Health Data</strong> </td>
                                 <td colspan="2" bgcolor="#D0E9C6"><strong>Dental Hygiene</strong> </td>
                                 <td colspan="4"  bgcolor="#c4e6f9"><strong>Weight(Kg)</strong></td>
                                 <td colspan="4"  bgcolor="#d8d8fc"><strong>Height(Cms)</strong></td>
                                 <td width="20" rowspan="2"><strong>View Detail</strong> </td>
                               </tr>
                            <tr align="center">
                              <td width="76" bgcolor="#c0fbe0"><strong>Good</strong> </td>
                              <td width="53" bgcolor="#fbbdb4"><strong>Bad</strong></td>
                              <td width="50" bgcolor="#c4e6f9"><strong>10-20</strong></td>
                              <td width="52" bgcolor="#aadcfa"><strong> 20-30</strong></td>
                              <td width="46" bgcolor="#9bd7fa"><strong>30-40</strong></td>
                              <td width="58" bgcolor="#87d0fb"><strong>Above</strong></td>
                              <td width="67" bgcolor="#d8d8fc"><strong>100-150 </strong></td>
                              <td width="59" bgcolor="#cdcdfc"><strong>150-200</strong></td>
                              <td width="63" bgcolor="#babafc"><strong>200-250</strong></td>
                              <td width="72" bgcolor="#ababfa"><strong>Above</strong></td>
                              </tr>
                            
                            <tbody>
                                <?php
                                $i = 1;
                                while ($rowv = $student_details->fetch()) {
//                    $student = Student::get_students($oCurrentUser->myuid, 'all', $rowv['s_id'])->fetch();
                                    ?>
                                    <tr align="center"> <td><?php $rowv['CClass'];   $classes = Master:: get_class_names3($MSID, $rowv['CClass'])->fetch();
                                                        echo $classes['class_name']; ?></td>
                                        <td><?php echo $classtotal= $rowv['total']; ?></td>
                                        
                                        <td><?php $totalhealth=  Master::count_health_data($MSID, $rowv['CClass']);  echo $totalrecords = $totalhealth->rowCount(); ?>   </td>
                                        <td bgcolor="#c0fbe0"> <?php $dental_good=  Master::count_health_data($MSID, $rowv['CClass'], 'Good');  echo $dentgood = $dental_good->rowCount(); ?>  </td>
                                        <td bgcolor="#fbbdb4"> <?php $dental_bad=  Master::count_health_data($MSID, $rowv['CClass'], 'Bad');  echo $dentbad= $dental_bad->rowCount(); ?> </td>
                                        <td bgcolor="#c4e6f9"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'weight', '10', '20');  echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td bgcolor="#aadcfa"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'weight', '20', '30');  echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td bgcolor="#9bd7fa"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'weight', '30', '40');  echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td bgcolor="#87d0fb"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'weight', '40', '75');  echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td bgcolor="#d8d8fc"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'height', '100', '150'); echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td bgcolor="#cdcdfc"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'height', '150', '200');  echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td bgcolor="#babafc"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'height', '200', '250');  echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td bgcolor="#ababfa"><?php $dental_bad= Master::health_data_range($MSID, $rowv['CClass'], 'height', '250', '450'); echo $dentbad= $dental_bad->rowCount(); ?></td>
                                        <td><a class="btn bg-olive btn-flat"  href="<?= CLIENT_URL ?>/health-list/<?= $rowv['CClass'] ?>" title="View" ><i class="fa fa-eye"> </i></a></td>

                                        </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php
//                    } else {
//                        echo '<div class="text-center margin">No records found.</div>';
//                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
                    <?php // $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php
$sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});	
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>