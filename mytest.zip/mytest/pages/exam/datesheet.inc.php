<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>      <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <!--//headder-->
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title">Exam Schedule</h3>
                            <h3 class="box-title"><a href="<?php echo CLIENT_URL . "/datesheet-add" ?>" type="button" class="btn bg-olive btn-flat margin">Add Exam Schedule</a></h3>


                        </div>   
                        <div class="col-md-9">  
                        </div></div>

                    <?php
                    if (@$text) {
                        ?>
                        <div class="row">
                            <div class="alert messages alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php echo $text; ?>
                            </div>
                        </div>
                    <?php }
                    ?> 
                </div>
                <br>
                <br>



                <br>

                <div class="row">

                    <form class="form-inline " method="post" id="exam_add_datesheet_form_id">
                        <input type="hidden" name="exam_add_datesheet_form" value="xxx" />
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <input type="hidden" name="year" value="<?= $oCurrentUser->mysession ?>" />
                        <!--<input type="hidden" name="exam_add_datesheet_form" value="xxx" />-->
                        <div class="col-md-12">  
                            <div class="col-md-3 no-padding">
                                <div class="col-md-6 no-padding">
                                    <label for="exampleInputName2">Select Class : </label>  

                                </div> 
                                <div class="col-md-6 no-padding">
                                    <select id="class_id" name="class_id" class="form-control"  onchange='this.form.submit()' >

                                        <?php
                                        if ($oCurrentUser->ulevel == "9") {
                                            foreach ($classs as $class) {
                                                if (@$selected_class == $class['class_no']) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                    <?= $class['class_name']; ?>
                                                </option>
                                                <?php
                                            }
                                        } else {
                                            foreach ($classes as $class_no => $class_name) {
                                                if (@$selected_class == $class_no) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $class_no ?>" <?= $selected ?> ><?= $class_name ?></option>
                                                <?php
                                            }
                                        }
                                        if (@$selected_class || @$selected_class != NULL) {
                                            
                                        } else {
                                            ?>
                                            <option value="" selected="selected" >
                                                Select
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div> </div>
                            <?php
                            if (@$selected_class || @$selected_class != NULL) {
                                ?>  <?php
                                if ($oCurrentSchool->section > 1) {
                                    ?>

                                    <div class="col-md-3 no-padding">
                                        <div class="col-md-7 no-padding"> 
                                            <label for="exampleInputName2">Select Section : </label>
                                        </div>  
                                        <div class="col-md-5 no-padding"> 
                                            <select id="section_id" name="section_id" class="form-control"  onchange='this.form.submit()' >
                                                <?php
                                                if ($oCurrentUser->ulevel == 9) {
                                                    while ($row = $sectiondet->fetch(PDO::FETCH_OBJ)) {
                                                        $sections = Master::get_schools_section($MSID, $row->section);
                                                        ?>
                                                        <b> Select Class : - </b>
                                                        <?php
                                                        foreach ($sections as $section) {
                                                            if (@$selected_section == $section['section_id']) {
                                                                $selected = 'selected = "selected"';
                                                            } else {
                                                                $selected = "";
                                                            }
                                                            ?>
                                                            <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                                <?= $section['sec_name']; ?>
                                                            </option>
                                                            <?php
                                                        }
                                                    }
                                                }//------USER LEVEL 9 ENDS HERE
                                                else {
                                                    foreach ($sections as $section_id => $section_name) {
                                                        if (@$selected_section == $section_id) {
                                                            $selected = 'selected = "selected"';
                                                        } else {
                                                            $selected = "";
                                                        }
                                                        ?>
                                                        <option value="<?= $section_id ?>" <?= $selected ?> ><?= $section_name ?></option>
                                                        <?php
                                                    }
                                                }
                                                if (@$selected_section == NULL) {
                                                    ?> <option value="" selected="selected" >
                                                        Select
                                                    </option> 
                                                    <?php
                                                } else {
                                                    
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php
                                } else if ($oCurrentSchool->section < 2) {
                                    ?>
                                    <input type="hidden" name="section_id" value="1">
                                <?php } ?>

                                <div class="col-md-3 no-padding">
                                    <div class="col-md-7 no-padding">
                                        <label for="exampleInputName2">Select Assesment : </label>
                                    </div>
                                    <div class="col-md-5 no-padding">
                                        <select id="assesment" name="assesment" class="form-control "  onchange='this.form.submit()' >
                                            <?php if (!@$selected_assesment) { ?>
                                                <option value=""  selected = "selected" >
                                                    Select
                                                </option> 
                                                <?php
                                            }
                                            foreach ($assesments as $assesment) {
                                                if ($selected_assesment == $assesment['assesment_id']) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                                    <?= $assesment['title']; ?>
                                                </option>
                                            <?php } ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3 no-padding">
                                    <div class="col-md-7 no-padding">
                                        <label for="exampleInputName2">Select Subject : </label>
                                    </div>
                                    <div class="col-md-5 no-padding">
                                        <select id="assesment" name="subject" class="form-control "  onchange='this.form.submit()' >
                                            <?php
                                            if ($oCurrentUser->ulevel == 9) {
                                                
                                            } else {
                                                foreach ($subjects as $sub_id => $sub_name) {
                                                    ?>
                                                    <option value="<?= $sub_id ?>"><?= $sub_name ?></option>
                                                    <?php
                                                }
                                            }

                                            if (!@$selected_subject) {
                                                ?><option value=""  selected = "selected" >
                                                    Select
                                                </option> 
                                            <?php }
                                            ?>
                                        </select>
                                    </div>
                                </div>


                                <?php
                            }
                            ?>

                        </div>

                    </form>
                </div>



                <div class="box-body table-responsive no-padding"> 
                    <form class="form-inline " method="post" id="exam_add_academic_performance_formid">     
                        <input type="hidden" value="xxx" name="academic_performance_posted_form">
                        <input type="hidden" value="<?= $MSID ?> " name="MSID">
                        <?php
                        if ($totalrecord_existing > 0) {
                            ?> <table class="table table-hover">
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>Class  </th>
                                    <th>Section  </th> 
                                    <th>Subject  </th> 
                                    <th>Assessment </th>  
                                    <?php
                                    if ($oCurrentSchool->activity == 1) {
                                        ?>
                                        <th>Activity </th>  
                                    <?php } ?>
                                    <th>Exam Date </th> 
                                    <th>Start Time </th>  
                                    <th>End Time </th> 

                                    <th>Max marks </th> 
                                    <th>Pass marks </th> 
                                    <th>Action </th> 

                                </tr>
                                <?php
                                $i = 1;
                                $j = 1;
                                while ($rowv = $existing_performance->fetch()) {
//                                    pr($rowv);
                                    $class_name = Master::get_classes($MSID, '', '', '', $rowv['class'])->fetch(PDO::FETCH_ASSOC);
                                    $section_name = Master::get_schools_section($MSID, $rowv['section'])->fetch();
                                    $subject_name = SuperAdmin::get_schoolwise_subject2($MSID, $rowv['subject'], array('selectAll' => 'true'))->fetch(PDO::FETCH_ASSOC);
                                    $assesment_name = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), '', $rowv['assessment'])->fetch(PDO::FETCH_ASSOC);
                                    $act_name = Exam::get_student_academic_activity($MSID, $rowv['activity'])->fetch(PDO::FETCH_ASSOC);
                                    if ($oCurrentUser->ulevel == 9) {
                                        ?>
                                        <tr>
                                            <td><?= $i ?></td>
                                            <th><?= $class_name['class_name']; ?></th>
                                            <th><?= $section_name['sec_name']; ?></th>
                                            <th><?= $subject_name['name']; ?></th>  
                                            <th><?= $assesment_name['title']; ?></th>  
                                            <?php if ($oCurrentSchool->activity == 1) { ?>
                                                <th><?= $act_name['name']; ?> </th>  
                                            <?php } ?>
                                            <th><?= $rowv['exam_date']; ?></th>  
                                            <th><?= $rowv['exam_time_from']; ?></th>  
                                            <th><?= $rowv['exam_time_to']; ?></th>  
                                            <th><?= $rowv['max_marks']; ?></th>  
                                            <th><?= $rowv['pass_marks']; ?></th>  
                                            <?php
                                            if ($totalrecord_existing > 0) {
                                                $marks = Exam::get_accademinc_performance($MSID, $rowv['id'])->fetch(PDO::FETCH_OBJ);
                                                if (@$marks) {
                                                    $title = "Alter Marks";
                                                    $colour = "danger";
                                                } else {
                                                    $title = "Assign Marks";
                                                    $colour = "success";
                                                }
                                                ?>
                                                <th> <a name="add_performance" href="<?= CLIENT_URL; ?>/academic-add/add/<?= $rowv['id'] ?>" class="btn btn-sm btn-<?= $colour ?> "><?= $title ?></a></th>
                                            <?php } ?>   
                                        </tr>
                                        <?php
                                    } else {
                                        foreach ($teacher_data as $teacher) {
                                            if ($teacher['Class'] == $class_name['class_name'] && $teacher['Section'] == $rowv['section'] && $teacher['Subject'] == $rowv['subject']) {
                                                ?>
                                                <tr>
                                                    <td><?= $j ?></td>
                                                    <th><?= $class_name['class_name']; ?></th>
                                                    <th><?= $section_name['sec_name']; ?></th>
                                                    <th><?= $subject_name['name']; ?></th>  
                                                    <th><?= $assesment_name['title']; ?></th>  
                                                    <?php if ($oCurrentSchool->activity == 1) { ?>
                                                        <th><?= $act_name['name']; ?> </th>  
                                                    <?php } ?>
                                                    <th><?= $rowv['exam_date']; ?></th>  
                                                    <th><?= $rowv['exam_time_from']; ?></th>  
                                                    <th><?= $rowv['exam_time_to']; ?></th>  
                                                    <th><?= $rowv['max_marks']; ?></th>  
                                                    <th><?= $rowv['pass_marks']; ?></th>  
                                                    <?php
                                                    if ($totalrecord_existing > 0) {

                                                        $marks = Exam::get_accademinc_performance($MSID, $rowv['id'])->fetch(PDO::FETCH_OBJ);
                                                        if (@$marks) {
                                                            $title = "Alter Marks";
                                                            $colour = "danger";
                                                        } else {
                                                            $title = "Assign Marks";
                                                            $colour = "success";
                                                        }
                                                        ?>
                                                        <th> <a name="add_performance" href="<?= CLIENT_URL; ?>/academic-add/add/<?= $rowv['id'] ?>" class="btn btn-sm btn-<?= $colour ?> "><?= $title ?></a></th>
                                                        <?php }//--------End if     ?>   
                                                </tr>
                                                <?php
                                                $j++;
                                            }//------------- End Class Equation if Condition
                                        }
                                    }
                                    $i++;
                                }
                                ?>
                            </table>   <?php
                        } else {
                            echo '<div class="text-center margin">No records found.</div>';
                        }
                        ?>
                        <!--<div class="row">-->

                        <!-- \col -->
                        <!--</div>-->
                    </form> </div>
            </div>
            <!-- /.box -->
        </div> 
    </div>
</section>
<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        // For Datepicker
         $('.exam_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		clearBtn: true
		});
    
		$('.timepicker2').timepicker();
		     $('.morks_obtained').blur(function(){
//  alert('s');       
   var marks = $(this).val();
        var max_marks =$(this).data('id');
          if (marks <= max_marks) {
                    $(this).removeClass('error');
                } else {
   $(this).addClass('error');
                }
              
   });
      $('#btn_submit_id').click(function () { 
           $('#error_div .errorDiv').remove();
                if ($(".morks_obtained").hasClass("error")) {
$("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');
              
                } else {
         $('#form_marks').submit();
//              alert(form_marks'sucess');  
    }
            });
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>

