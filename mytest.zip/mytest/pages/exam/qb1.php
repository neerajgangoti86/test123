
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<style type="text/css">
    <!--
    .style190 {	color: #FFFFFF;

    }
    .style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

    .st3 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 16px;

    }.st2 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 18px;

    }
    .st4 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 13px;

    }
    .t1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 15px;
    }
    .m1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 22px;font-weight: 500;
    }
    .n1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
    }
    .b1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
    }
    .r {font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 11px;
    }
    .maintxt {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
    }
    .hide {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        color: #FFF;
    }.Q1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px;font-weight: bold;
    }.Q2 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;font-weight: bold;
    }
</style>
<ul class="nav nav-pills">
    <li class="dropdown">
        <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
        <ul class="dropdown-menu">
            <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                </a></li>
            <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
            </li>

        </ul>
    </li>
</ul>
<section class="content">
    <div class="row">
        <div class="col-md-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title" >
                        <?php
                        if (http_get('param1') == "add" && @$step != "step2")
                            {
                            ?>Create Question Bank 
                            <?php
                            }
                        else
                            {
                            ?>
                            Question paper generator
                            <?php
                            }
                        ?></h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <!--          <form method="post" action="" role="form">-->
                <?php
                if (http_get('param1') == "add" && @$step != "step2")
                    {
                    ?><form  method="post" id="attendance_form_id">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>" />
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Class:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">  <select id="class_id" name="class_id" class="form-control "  >


                                                <?php
                                                $classs = Master::get_classes($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
                                                ?>

                                                <?php
                                                foreach ($classs as $class)
                                                    {
                                                    if (@$selected_class == $class['class_no'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                        <?= $class['class_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
//                                            if (@$selected_class)
//                                                {
//                                                
//                                                }
//                                            else
//                                                {
//                                                
                                                ?>
                                                <!--                                                <option value="" selected="selected" >
                                                                                                    Select Class
                                                                                                </option>-->
                                                <?php //}
                                                ?>
                                            </select>
                                        </div>
                                        <br><br> </div></div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Subject:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">   <select id="subject" name="subject" class="form-control "  >
                                                <?php
                                                $subjects = SuperAdmin::get_schoolwise_subject($MSID)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                                                ?>

                                                <?php
                                                foreach ($subjects as $subject)
                                                    {
                                                    ?>
                                                    <option value="<?= $subject['name']; ?>"  >
                                                        <?= $subject['name']; ?>
                                                    </option>
                                                <?php } ?>
                                            </select></div>
                                        <br><br></div></div>
                                <!--                                <div class="col-md-8">
                                                                    <div class="form-group">
                                                                        <div class="col-md-4"><label>Assesment:<span class="text-red">*</span></label></div>
                                                                        <div class="col-md-4">   <select id="subject" name="assesment" class="form-control "  >
                                <?php
//                                                $subjects = SuperAdmin::get_schoolwise_subject($MSID)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
//                                                foreach ($assesments as $assesment)
//                                                    {
//                                                    if ($selected_assesment == $assesment['assesment_id'])
//                                                        {
//                                                        $selected = 'selected = "selected"';
//                                                        }
//                                                    else
//                                                        {
//                                                        $selected = "";
//                                                        }
                                ?>
                                                                                    <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                <?= $assesment['title']; ?>
                                                                                    </option>
                                <?php // }     ?>
                                                                            </select></div>
                                                                        <br><br></div></div>-->

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Section :<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <select id="dlevel" name="section" class="form-control "  >

                                                <option value="A"  >A  </option>
                                                <option value="B"  >B  </option>
                                                <option value="C"  >C  </option>
                                                <option value="D"  >D  </option>

                                            </select></div>
                                        <br><br> </div></div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Section Title:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input type="text" name="section_title" class="form-control "  required>


                                        </div>
                                        <br><br> </div></div> <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Chapter No:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="chapter" required></div>
                                        <br><br></div></div>

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Question Title:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="question_title" required></div>
                                        <br><br></div></div>

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Difficulty Level:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <select id="dlevel" name="dlevel" class="form-control"  required>

                                                <option value="1"  >Easy  </option>
                                                <option value="2"  >Moderate  </option>
                                                <option value="3"  >High  </option>

                                            </select></div>
                                        <br><br> </div></div><div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Number of Questions:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="noq" required></div>
                                        <br><br> </div></div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Maximum Marks:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">    <input class="form-control" type="text" size="30" id="name7" name="max_marks" required></div>
                                        <br><br></div></div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>
                    </form><?php
                    }
                else if (@$step == "step2" && http_get('param1') == "add")
                    {
                    ?>
                    <form  method="post" id="attendance_form_id">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="noq" value="<?= $_POST['noq'] ?>" /> 
                        <input type="hidden" name="max_marks" value="<?= $_POST['max_marks'] ?>" />
                        <input type="hidden" name="dlevel" value="<?= $_POST['dlevel'] ?>" />
                        <input type="hidden" name="question_title" value="<?= $_POST['question_title'] ?>" />
                        <input type="hidden" name="chapter" value="<?= $_POST['chapter'] ?>" /> 
                        <input type="hidden" name="section_title" value="<?= $_POST['section_title'] ?>" />
                        <input type="hidden" name="section" value="<?= $_POST['section'] ?>" /> 
                        <input type="hidden" name="subject" value="<?= $_POST['subject'] ?>" />
                        <input type="hidden" name="class_id" value="<?= $_POST['class_id'] ?>" /> 
                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>" />
                        <div class="box-body">
                            <div class="row"><div class="col-md-8">
                                    <?php
                                    $all = $_POST['noq'];
                                    for ($i = 0; $i < $all; $i++)
                                        {
                                        ?> 
                                        <div class="row"><div class="form-group">
                                                <div class="col-md-4"><label>Question No:<span class="text-red">*</span></label></div>
                                                <div class="col-md-4">    
                                                    <input type="hidden" value="<?= $i + 1 ?>" name="q_no[]"><label><?= $i + 1 ?></label>


                                                </div></div>
                                        </div>
                                        <div class="row"><div class="form-group">
                                                <div class="col-md-4"><label>Question :<span class="text-red">*</span></label></div>
                                                <div class="col-md-4">    <textarea name="question[]" rows="7" cols="100" required="required"></textarea>


                                                </div></div>
                                        </div> <hr><?php } ?> 
                                </div></div>
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="submit" name="ssubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div></div>
                    </form><?php
                    }
                else if (@$state == "true")
                    {
                    ?>
                    <form  method="post" id="attendance_form_id">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="noq" value="<?php echo @$_POST['noq']; ?>" /> 
                        <br> <div class="row" >

                            <div class="col-md-1">
                            </div><div class="col-md-4"><b>Time</b></div>
                            <div class="col-md-5"><select id="dlevel" class="form-control" name="time"  required>

                                    <option value="1"  >1 Hr  </option>
                                    <option value="2"  >2 Hr</option>
                                    <option value="3"  >3 Hr  </option>

                                </select></div>
                            <div class="col-md-1"></div>
                        </div>
                        <div class="row" >

                            <div class="col-md-1">
                            </div><div class="col-md-4"><b>Instructions</b></div>
                            <div class="col-md-5">
                                <input type="text" value="All questions are compulsory. " name="i1" required class="form-control">
                                <input type="text" value="Handwriting should be legible." name="i2"  class="form-control">
                                <input type="text" value="" name="i3"  class="form-control">
                                <input type="text" value="" name="i4"  class="form-control">
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                        <br>
                        <?php
                        if ($totalrecords > 0)
                            {
                            ?>
                            <table class="table table-hover" id="example1">
                                <thead style="background:#ddd;">
                                    <tr>
                                        <th>Q.No </th>
                                        <th>Question Title</th>
                                        <th>Question</th>
                                        <th>Difficulty Level</th>
                                        <th>Marks</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
//                                while ($rowv = $homeworks->fetch()) {
//                                $hw = Homework::get_homeworks($MSID, '', $id, $section_id);



                                    while ($rowv = $questions->fetch())
                                        {
//                                        print_r($rowv);
//                                        exit();
                                        $class_work = Master::get_classes($MSID, '', '', '', $rowv['class'])->fetch(PDO::FETCH_ASSOC);
                                        ?>
                                        <tr> <td><?= $rowv['q_no']; ?></td>
                                            <td><?= $rowv['sub_group']; ?></td>
                                            <td><?= $rowv['question']; ?></td>
                                            <td><?php
//                                                if ($rowv['d_level'] == "1")
//                                                    {
//                                                    echo "";
//                                                    }
//                                                else 
                                                if ($rowv['d_level'] == "2")
                                                    {
                                                    echo "Moderate";
                                                    }
                                                else if ($rowv['d_level'] == "3")
                                                    {
                                                    echo "High";
                                                    }
                                                else
                                                    {
                                                    echo "Easy";
                                                    }
                                                ?></td>
                                            <td><?= $rowv['marks'] ?></td>                                                
                                    <input type="hidden" name="assesment" value="<?php echo $_POST['assesment']; ?>">
                                    <input type="hidden" name="class" value="<?php echo $_POST['class_id'] ?>">
                                    <input type="hidden" name="subject" value="<?= $rowv['subject'] ?>">
                                                <!--<td><?= $rowv['subject']; ?></td>-->

                                    <td> <input type="checkbox" value="<?= $rowv['q_id']; ?>" name="ques[]"></td>
                                    </tr>
                                    <?php
                                    $i++;
                                    }
                                ?>
                                </tbody>
                            </table>
                            <?php
                            }
                        else
                            {
                            echo '<div class="text-center margin">No records found.</div>';
                            }
                        ?>
                        <div class="row">
                            <div class="col-md-4"></div><div class="col-md-4">
                                <button type="submit" name="spssubmit"  value="asd" class="btn btn-lg btn-success btn-block">Submit</button></div><div class="col-md-4"></div>
                        </div> 
                    </form><?php
                    }
                else
                    {
                    ?>

                    <form  method="post" id="attendance_form_id">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <div class="col-md-4"><label>Class:<span class="text-red">*</span></label></div>
                                        <div class="col-md-4">  <select id="class_id" name="class_id" class="form-control " onchange='this.form.submit()' >


                                                <?php
                                                $classs = Master::get_classes($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
                                                ?>

                                                <?php
                                                foreach ($classs as $class)
                                                    {
                                                    if (@$selected_class == $class['class_no'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                        <?= $class['class_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
//                                            if (@$selected_class)
//                                                {
//                                                
//                                                }
//                                            else
//                                                {
//                                                
                                                ?>
                                                <!--                                                <option value="" selected="selected" >
                                                                                                    Select Class
                                                                                                </option>-->
                                                <?php //}
                                                ?>
                                            </select>
                                        </div>
                                        <br><br> </div></div>
                                <?php
                                if (@$selected_class)
                                    {
                                    ?> <div class="col-md-8">
                                        <div class="form-group">
                                            <div class="col-md-4"><label>Subject:<span class="text-red">*</span></label></div>
                                            <div class="col-md-4">   <select id="subject" name="subject" class="form-control "  >
                                                    <?php
                                                    $subjects = SuperAdmin::get_schoolwise_subject($MSID, '', array('page' => 1, 'record_per_page' => 10), @$selected_class)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                                                    ?>

                                                    <?php
                                                    foreach ($subjects as $subject)
                                                        {
                                                        ?>
                                                        <option value="<?= $subject['name']; ?>"  >
                                                            <?= $subject['name']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select></div>
                                            <br><br></div></div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <div class="col-md-4"><label>Assesment:<span class="text-red">*</span></label></div>
                                            <div class="col-md-4">   <select id="subject" name="assesment" class="form-control "  >
                                                    <?php
                                                    $subjects = SuperAdmin::get_schoolwise_subject($MSID)->fetchAll(PDO::FETCH_ASSOC);
//                                                    print_r($subjects);
                                                    foreach ($assesments as $assesment)
                                                        {
                                                        if ($selected_assesment == $assesment['assesment_id'])
                                                            {
                                                            $selected = 'selected = "selected"';
                                                            }
                                                        else
                                                            {
                                                            $selected = "";
                                                            }
                                                        ?>
                                                        <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                                            <?= $assesment['title']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select></div>
                                            <br><br></div></div><?php } ?>


                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="submit" name="psubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>
                    </form>                <?php } ?>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<section class="content report_export" id="reg_reports">
    <table width="769" border="0" align="center">
        <tr>  
            <td colspan="4" align="center"  class="st2"> <table width="757" height="60"  border="0" align="center">
                    <tr>
                        <td colspan="4" align="center" class="m1">Class: 
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4" align="center" class="m1"><span class="b1">Subject: </span></td>
                    </tr>

                    <tr>
                        <td colspan="4" align="center" class="m1"><span class="b1">Examination: </span></td>
                    </tr>

                    <tr class="st2">
                        <td colspan="4" align="center"  >Academic Session: ></td>
                    </tr>
                    <tr class="st2">
                        <td width="53" align="left"  >Time:</td>
                        <td width="127" align="left" ></td>
                        <td width="326" align="center" >&nbsp;</td>
                        <td width="233" align="right" >Total Marks:
                        </td>
                    </tr>
                </table></td> 
        </tr>
        <tr>
            <td colspan="4" align="center"  class="st2"> </td>
        </tr>  

        <tr>
            <td colspan="4" align="left" class="st2">Instructions:</td>
        </tr>
        <?php
        $ins1 = $_POST['ins1'];
        if ($ins1 != '')
            {
            ?>
            <tr>
                <td align="left" class="st4"><span class="t1"><?php echo '1' + $g; ?></span></td>
                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $ins1; ?></span></td>
            </tr>
        <?php
            }
        else
            {
            
            }
        ?>
<?php
$ins2 = $_POST['ins2'];
if ($ins2 != '')
    {
    ?>
            <tr>
                <td align="left" class="st4"><span class="t1"><?php echo '2' + $g; ?></span></td>
                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $ins2; ?></span></td>
            </tr>
        <?php
            }
        else
            {
            
            }
        ?>
        <?php
        $ins3 = $_POST['ins3'];
        if ($ins3 != '')
            {
            ?>
            <tr>
                <td align="left" class="st4"><span class="t1"><?php echo '3' + $g; ?></span></td>
                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $ins3; ?></span></td>
            </tr>
<?php
    }
else
    {
    
    }
?>
<?php
$ins4 = $_POST['ins4'];
if ($ins4 != '')
    {
    ?>
            <tr>
                <td align="left" class="st4"><span class="t1"><?php echo '4' + $g; ?></span></td>
                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $ins4; ?></span></td>
            </tr>
        <?php
            }
        else
            {
            
            }
        ?>




        <tr>
            <td colspan="4" class="st4">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4"   class="st2">Answer These Questions  </td>
        </tr>
        <?php /* $resultd56=mysql_query($sqld56="SELECT distinct section,SectionHeading  FROM `61QBank` WHERE MSID='$msid' and section!='Select' and Class='$c'  and Subject='$Subject' and `Assesment`='$as'  and Difficultylevel='$DL'order by Section");
          $nrio=mysql_num_rows($resultd56);
          while($rowd56=mysql_fetch_array($resultd56)){if($nrio>1){ */ ?>
        <tr>
            <td colspan="4" align="center" class="st2"><?php //echo 'Section:'.$se=$rowd56['section'];echo '<br>'; ?> </td>
        </tr>
        <?php
        $i = 1; //}else {} 
//        $sert = mysql_query($ser = "SELECT distinct CR.QNo,CR.Quid,BK.QHeading,BK.Marks FROM `61CreateQP` CR INNER JOIN 61QBank BK ON CR.MSID=BK.MSID And CR.Quid=BK.Quid where CR.QPID='$QPID' and CR.Class='$c' and CR.Subject='$Subject' order by CR.Id asc");
//
//        while ($sertt = mysql_fetch_array($sert))
//            {
//            $QNo = $sertt['QNo'];
//            $QNo = $sertt['QNo'];
//            $QID = $sertt['QID'];
//            $Quid = $sertt['Quid'];
        ?>
        <tr>
            <td colspan="2" class="st2"><?php echo 'Q' . $i; ?></td>
            <td width="681" class="st2"><?php echo $sertt['QHeading']; ?></td>
            <td width="29" class="st2"><?php echo $sertt['Marks'] . '<br>'; ?></td>
        </tr>
<?php
$j = 1;
//    $r364 = mysql_query($sqld364 = "SELECT distinct CR.QID,CR.Quid,BK.QHeading,BK.Marks FROM `61CreateQP` CR INNER JOIN 61QBank BK ON CR.MSID=BK.MSID And CR.Quid=BK.Quid where CR.QPID='$QPID' and CR.Class='$c' and CR.QNo='$QNo' and CR.Subject='$Subject' order by CR.Id asc  ");
//    while ($ro364 = mysql_fetch_array($r364))
//        {
//        $QIDhj = $ro364['QID'];
//        $rtd564 = mysql_query($s564 = "SELECT * FROM `61Questions` WHERE MSID='$msid' And QNO='$QNo'  And Qid='$QIDhj'  And `QUID`='$Quid'");
//        while ($ro564 = mysql_fetch_array($rtd564))
//            {
?>
        <tr>
            <td class="st4">&nbsp;</td>
            <td width="20" class="st4"><?php echo $j . '<br>'; ?></td>
            <td class="st4"><?php $Question = $ro564['Question'];
echo strip_tags($Question) . '<br>';
?></td>
            <td class="st4">&nbsp;</td>
        </tr> <?php $j++;
//        } 
?>
<?php // }  ?>
<?php $i++;
//} 
?>

    </table>  
</section>


<script type='text/javascript'>
    function htmltopdf() {
        var pdf = new jsPDF('p', 'pt', 'a1');
        source = $('#reg_reports')[0];
        specialElementHandlers = {
            '#bypassme': function (element, renderer) {
                return true
            }
        };
        margins = {
            top: 10,
            bottom: 10,
            left: 10,
            width: 800
        };
        pdf.fromHTML(
                source,
                margins.left,
                margins.top, {
                    'width': margins.width,
                    'elementHandlers': specialElementHandlers
                },
                function (dispose) {
                    pdf.save('Download.pdf');
                }, margins);
    }

</script>





