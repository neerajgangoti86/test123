<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>      <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <!--//headder-->
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title"> Academic performance List</h3>
                        </div>   
                        <div class="col-md-9">  
                        </div></div>
                    <br>
                    <br>
                    <div class="row">
                        <div class="col-md-6">
                            <form class="form-inline " method="post" id="exam_add_academic_performance_form_id">
                                <input type="hidden" name="exam_add_academic_performance_form" value="xxx" />
                                <div class="col-md-6">

                                    <label for="exampleInputName2">Select Class : </label>  

                                </div> 
                                <div class="col-md-6">
                                    <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                        <?php
                                        foreach ($classs as $class)
                                            {
                                            if (@$selected_class == $class['class_no'])
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                <?= $class['class_name']; ?>
                                            </option>
                                            <?php
                                            } if (@$selected_class || @$selected_class != NULL)
                                            {
                                            
                                            }
                                        else
                                            {
                                            ?>
                                            <option value="" selected="selected" >
                                                Select Class
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>   <?php
                                if (@$selected_class && $oCurrentSchool->section > 1)
                                    {
                                    ?>

                                    <div class="col-md-6"> 
                                        <label for="exampleInputName2">Select Section : </label></div>

                                    <div class="col-md-6"> 
                                        <select id="section_id" name="section_id" class="form-control wth_div"  onchange='this.form.submit()'>
                                            <?php
                                            $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
                                            while ($row = $sectiondet->fetch(PDO::FETCH_OBJ))
                                                {
                                                $sections = Master::get_schools_section($MSID, $row->section);
//                                        print_r($sections);
                                                ?>
                                                <b> Select Class : - </b>
                                                <?php
                                                foreach ($sections as $section)
                                                    {
                                                    if (@$selected_section == $section['section_id'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>



                                                    <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                        <?= $section['sec_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
//                                                print_r($selected_class);
                                                } if (@$selected_section == NULL)
                                                {
                                                ?> <option value="" selected="selected" >
                                                    Select Section
                                                </option> 
                                                <?php
                                                }
                                            else
                                                {
                                                
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <?php
                                    }
                                else if ($oCurrentSchool->section < 2)
                                    {
                                    ?>
                                    <input type="hidden" name="section_id" value="1">
                                <?php } ?>
                                <?php
//                                if (@$selected_class || @$selected_class != NULL)
//                                    {
                                ?>
                                <div class="col-md-6">

                                    <label for="exampleInputName2">Select Assesment : </label>

                                    <?php //print_r($assesments);   ?>

                                </div><div class="col-md-6"> <select id="assesment" name="assesment" class="form-control wth_div "  onchange='this.form.submit()' >

                                        <?php
                                        if (@$selected_assesment && $selected_assesment != "all")
                                            {
                                            ?><option value="all"  >
                                                All Assesment
                                            </option> 
                                            <?php
                                            }
                                        else
                                            {
                                            ?><option value="all"  selected = "selected" >
                                                All Assesment
                                            </option> 
                                            <?php
                                            }
                                        foreach ($assesments as $assesment)
                                            {
                                            if ($selected_assesment == $assesment['assesment_id'])
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                                <?= $assesment['title']; ?>
                                            </option>
                                        <?php } ?>

                                    </select>
                                </div>
                                <?php // } ?>
                                <?php
                                if ($oCurrentSchool->activity == "1")
                                    {
                                    if (@$selected_class || @$selected_class != NULL)
                                        {
                                        if (@$selected_assesment && @$selected_assesment != "all")
                                            {
                                            if (@$selected_subjects != "all" && @$selected_subjects)
                                                {

//                                                echo $selected_class,$selected_assesment,$selected_subjects;                                                
                                                ?>
                                                <div class="col-md-6">
                                                    <label for="exampleInputName2">Select Activities : </label>

                                                    <?php //print_r($activityes);    ?>

                                                </div><div class="col-md-6">
                                                    <select id="activity" name="activity" class="form-control  wth_div"  onchange='this.form.submit()' >

                                                        <?php
                                                        //print_r($activityes);
                                                        foreach ($activityes as $activitye)
                                                            {

                                                            $activiy_name = Exam::get_student_academic_activity($MSID, $activitye->activity_id)->fetch();

                                                            if (@$selected_activity == $activitye->activity_id)
                                                                {
                                                                $selected = 'selected = "selected"';
                                                                }
                                                            else
                                                                {
                                                                $selected = "";
                                                                }
                                                            ?>
                                                            <option value="<?= $activitye->activity_id; ?>" <?= $selected ?> >
                                                                <?= $activiy_name['name']; ?>
                                                            </option>
                                                        <?php } ?>

                                                    </select> </div>
                                                <?php
                                                }
                                            }
                                        }
                                    }
                                ?>

                                <div class="col-md-6">

                                    <label for="exampleInputName2">Select Subjects : </label>

                                </div>
                                <div class="col-md-6"><select id="subjects" name="sub_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                        <?php
                                        $i = 0;
                                        if (@$selected_subjects && $selected_subjects != "all")
                                            {
                                            ?><option value="all"  >
                                                All Subjects
                                            </option> 
                                            <?php
                                            }
                                        else
                                            {
                                            ?><option value="all"  selected = "selected" >
                                                All Subjects
                                            </option> 
                                            <?php
                                            }
                                        foreach ($subjects as $subject)
                                            {
                                            if ($selected_subjects == $subject->subject_id)
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $subject->subject_id; ?>" <?= $selected ?> >
                                                <?= $subject->name ?>
                                            </option>
                                            <?php
                                            $i++;
                                            }
                                        ?>
                                    </select>
                                </div>

                        </div>
                        </form>
                    </div><div class="col-md-6">
                    </div>

                </div>
                <br>
                <div class="row">
                    <div class="col-md-10">                   

                    </div>   
                    <div class="col-md-2 ">  <a href="<?= CLIENT_URL ?>/academic-add " type="button" class="btn bg-olive pull-right " >Add Academic Marks</a>
                    </div></div>
            </div>
            <!-- /.box-header -->






            <div class="box-body table-responsive no-padding"> 
                <form class="form-inline " method="post" id="exam_add_academic_performance_formid">     
                    <input type="hidden" value="xxx" name="academic_performance_posted_form">
                    <input type="hidden" value="<?= $MSID ?> " name="MSID">
                    <?php
                    if ($totalrecord_existing > 0)
                        {
                        ?> <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Class  </th>
                                <th>Section  </th> 
                                <th>Subject  </th> 
                                <th>Assesment </th>   
                                <th>Start Time </th>  
                                <th>End Time </th> 
                                <th>Exam Date </th>  
                                <th>Max marks </th> 
                                <th>Pass marks </th> 
                                <th>Action </th> 

                            </tr>
                            <?php
                            $i = 1;



                            while ($rowv = $existing_performance->fetch())
                                {
                                $class_name = Master::get_classes($MSID, '', '', '', $rowv['class'])->fetch(PDO::FETCH_ASSOC);
                                $section_name = Master::get_schools_section($MSID, $rowv['section'])->fetch();
                                $subject_name = SuperAdmin::get_schoolwise_subject2($MSID, $rowv['subject_id'], array('selectAll' => 'true'))->fetch(PDO::FETCH_ASSOC);
                                $assesment_name = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), '', $rowv['assesment_id'])->fetch(PDO::FETCH_ASSOC);
                                ?>

                                <input type="hidden" value="<?= $rowv['assesment_id'] ?> " name="assesment_id">
                                <input type="hidden" value="<?= $rowv['subject_id'] ?> " name="sub_id">
                                <input type="hidden" value="<?= $rowv['class'] ?> " name="class">
                                <input type="hidden" value="<?= $rowv['max_marks'] ?> " name="max_marks">
                                <tr>
                                    <td><?= $i ?></td>
                                    <th><?= $class_name['class_name']; ?></th>
                                    <th><?= $section_name['sec_name'];
                        ; ?></th>
                                    <th><?= $subject_name['name']; ?></th>  
                                    <th><?= $assesment_name['title']; ?></th>  
                                    <th><?= $rowv['date']; ?></th>  
                                    <th><?= $rowv['start_time']; ?></th>  
                                    <th><?= $rowv['end_time']; ?></th>  
                                    <th><?= $rowv['max_marks']; ?></th>  
                                    <th><?= $rowv['passing_marks']; ?></th>  
                                    <?php
                                    if ($totalrecord_existing > 0)
                                        {
                                        ?>
                                        <th> <a name="edit_performance" href="<?= CLIENT_URL; ?>/academic-add/edit/<?= $rowv['class'] ?>/<?= $rowv['assesment_id'] ?>/<?= $rowv['activity_id'] ?>/<?= $rowv['subject_id'] ?>/<?= $rowv['section'] ?>" class="btn btn-sm btn-warning ">Edit Performance</a>
                                            &nbsp; <a data-bb="confirm" class="btn btn-danger btn-flat" href="<?= CLIENT_URL; ?>/academic-performance/del/<?= $rowv['class'] ?>/<?= $rowv['assesment_id'] ?>/<?= $rowv['activity_id'] ?>/<?= $rowv['subject_id'] ?>/<?= $rowv['section'] ?>">Delete</a>
                                        </th>
                                <?php } ?>   

                                </tr>
                                <?php
                                $i++;
                                }
                            ?>
                        </table>   <?php
                        }
                    else
                        {
                        echo '<div class="text-center margin">No records found.</div>';
                        }
                    ?>
                    <!--<div class="row">-->

                    <!-- \col -->
                    <!--</div>-->
                </form> </div>



        </div>
        <!-- /.box -->
    </div>
</div>
<input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
</section>

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        
        var siteurl = $("#site_url").val();
        //alert(siteurl);
                $('.morks_obtained').blur(function(){
//   alert('s');       
   var marks = $(this).val();
        var max_marks =$(this).data('id');
       
          if (marks <= max_marks) {
                    $(this).removeClass('error');
                } else {
                    $(this).addClass('error');
                }
              
   });
       $('#btn_submit_id').click(function () { 
            $('#error_div .errorDiv').remove();
                if ($(".morks_obtained").hasClass("error")) {
//alert('error');
//        form_marks
$("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');
              
                } else {
         $('#form_marks').submit();
//              alert(form_marks'sucess');  
    }
            });
	 $('#myModal').on('click','#submit',function(){
          $('#ajaxForm .errorDiv').remove();
         var errors = '';
                var class_id = $("#class_id_get");
                var assesment = $("#assesment_ajax");
                var subjects = $("#subjects_ajax");
        
                
                var max_marks = $("#max_marks");
        
                var activity = $("#activity_ajax");
        
                if (class_id.val() == '') {
                    class_id.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    class_id.parent('.form-group').removeClass('has-error');
                }
                if (assesment.val() == '') {
                    assesment.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    assesment.parent('.form-group').removeClass('has-error');
                }
                if (subjects.val() == '') {
                    subjects.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    subjects.parent('.form-group').removeClass('has-error');
                }
                if (max_marks.val() == '') {
                    max_marks.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {      
                    max_marks.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
        				$("#onajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                    return false;
                }
//        alert('df');
            $('#onajaxForm').submit();
        

		// end
		return false;
	 });
	 	 //edit model
	 $('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
        
     
//   $("#class_id_get").change(function()
//   {
//       
//       var class_id = $(this).val();
//        
//        //alert(class_id);
//        
//       $.ajax({
//			url: siteurl+"/ajax-page-load/exam_select",
//			type: "post",
//			data: { classid: class_id} ,
//			success: function (response) {
////                          alert(response);
//                        $("#show_content_div").html('');
//                         $("#show_content_div").html(response);
//                  
//			},
//			error: function(jqXHR, textStatus, errorThrown) {
//			   console.log(textStatus, errorThrown);
//                          alert(errorThrown);
//         
//			}
//        
//
//	});
//    });  
//        
        
        
        
        
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>