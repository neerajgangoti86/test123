<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"> Half Yearly</h3>


                </div>
                <!-- /.box-header -->
                <div class="box-footer clearfix">
                    <table  border="1" align="center" cellpadding="2" cellspacing="2">
                        <tr>
                            <td width="100%">
                                <table width="658" height="491" align="center" bordercolor="#2A3F00">
                                    <tr align="left" valign="top">
                                        <td width="100%" height="76"><table width="99%" align="center">
                                                <tr>
                                                    <td colspan="3" align="center"><span class="m1">
                                                            <?= $oCurrentSchool->name ?>
                                                        </span></td>
                                                </tr>
                                                <tr>
                                                    <td width="90" align="left"><img    src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" width="75" height="75" class="logo"></td>
                                                    <td width="340" valign="top"><table width="333" border="0" align="center">
                                                            <tr>
                                                                <td width="327" align="center" ><span class="b1">
                                                                        <?= $oCurrentSchool->place ?> 
                                                                    </span></td>
                                                            </tr>
                                                            <tr>
                                                                <td align="center" class="b1"><span class="t1">
                                                                        <?= $oCurrentSchool->board ?>
                                                                    </span></td>
                                                            </tr>
                                                            <tr>
                                                                <td align="center" class="t1">&nbsp;</td>
                                                            </tr>
                                                        </table></td>
                                                    <td width="199" align="right" valign="top"><table width="100%" border="0" align="right">
                                                            <tr>
                                                                <td align="center">Phone No:</td>
                                                                <td align="right" class="r"><strong>
                                                                        <?= $oCurrentSchool->phone ?>   
                                                                    </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="107" class="r">Affiliation No.:</td>
                                                                <td width="109" align="right" class="r"><strong>
                                                                        <?= $oCurrentSchool->affNo ?>  
                                                                    </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td class="r"> School Code :</td>
                                                                <td align="right"><span class="r"><strong>
                                                                            <?= $oCurrentSchool->schoolNo ?>   
                                                                        </strong></span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><span class="r">Recognition No.:</span></td>
                                                                <td align="right"><strong class="r">
                                                                        <?= $oCurrentSchool->recNo ?>
                                                                    </strong></td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="22"><hr/></td>
                                    </tr>

                                    <tr align="left" valign="top">
                                        <td valign="top"><br />
                                            <table width="645" border="0" align="center">
                                                <tr>
                                                    <td width="30" rowspan="5" class="st4"></td>
                                                    <td colspan="2" class="b1"> 
                                                        <b><?php echo $student['name']; ?></b> </td>
                                                    <td width="3">&nbsp;</td>
                                                    <td width="179" class="st4">&nbsp;</td>
                                                    <td class="st4">&nbsp;</td>
                                                </tr>

                                                <tr>
                                                  <!--<td width="17" rowspan="5" valign="top"><?PHP //$img= $row['Photo'];        ?></td>-->
                                                    <td width="140" height="29" class="st4">Student Id: </td>
                                                    <td colspan="3" class="st4"><strong><?php echo $student['student_id']; ?> </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class:<strong>
                                                       <?= $class_id  ?> </strong>
                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Overall grade:</td>
                                                    <td width="116" class="st4"><strong>
                                                            <?php
                                                            $grade_sql = "SELECT Q1.student_id, Q1.Point,G.grade FROM (Select student_id, MSID, round(Sum( `marks_obtained`)/SUM(`max_marks`)*100,2) Point from `ms_exam_acedemic_performance`  WHERE   MSID='$MSID' AND `session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "') Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`percent_from` AND G.`percent_to`";
                                                            $oDb = DBConnection::get();
                                                            $grade_sql = $oDb->query($grade_sql);

                                                            while ($gow6 = $grade_sql->fetch()) {
                                                                echo $grade6 = $gow6['grade'];
                                                            }
                                                            ?>
                                                        </strong></td>
                                                </tr>

                                                <tr>
                                                    <td height="28" class="st4">Father's Name:</td>
                                                    <td colspan="3" class="st4"><strong>
                                                            <?php echo "Mr." . ' ' . $student['f_name']; ?>
                                                        </strong></td>
                                                    <td class="st4">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td height="28" class="st4">Mother's Name:</td>
                                                    <td colspan="3" class="st4"><strong>
                                                            <?php echo "Mrs." . ' ' . $student['m_name']; ?>
                                                        </strong></td>
                                                    <td class="st4">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td>&nbsp;</td>
                                                    <td width="151">&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td height="146" colspan="6"><table width="570" border="0" align="center">
                                                            <tr>
                                                                <td colspan="5" align="center"><strong class="st3"><u>Half Yearly Academic Performance<br />
                                                                            <br />
                                                                        </u></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="72" align="left"><strong class="st4">Subjects</strong></td>

                                                                <?php
                                                                $sql_assesments = "SELECT distinct title , id FROM `ms_exam_assesments` Where term='Term 1'  And MSID='$MSID' ";
                                                                $oDb = DBConnection::get();
                                                                $sql_assesments = $oDb->query($sql_assesments);
                                                                while ($rowv = $sql_assesments->fetch()) {
                                                                    ?>
                                                                    <td width="71" align="center" class="st4"><strong class="st4"><?= $rowv['title'] ?>
                                                                        </strong></td><?php } ?>

                                                                <td width="71" align="center" class="st4"><strong>Term grade</strong></td>
                                                            </tr>
                                                            <?php
//                                                            $subjects_querry = "SELECT distinct subject_id FROM `ms_exam_acedemic_performance` Where  MSID='$MSID' and session='" . $_SESSION['year'] . "' and student_id='" . $student['student_id'] . "'";
                                                         $subjects_querry =  Exam::get_accademinc_performance($MSID, '', '', '', '', $student['student_id'], $_SESSION['year'], array('selectAll' => 'true'));
//                                                            $oDb = DBConnection::get();
//                                                            $subjects_querry = $oDb->query($subjects_querry);
                                                            while ($rowv = $subjects_querry->fetch()) {
                                                                ?>
                                                                <tr class="st4">
                                                                    <?php
//                                                                    $subjects = "SELECT subject_f_name FROM `ms_subjects_all` Where subject_id='" . $rowv['subject_id'] . "'";
                                                                  $subjects= SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'),'','','YES','') ;
//                                                                    $oDb = DBConnection::get();
//                                                                    $subjects = $oDb->query($subjects);
                                                                    while ($rowu
                                                                    = $subjects->fetch()) {
                                                                        ?><td><?= $rowu['name'] ?></td>
                                                                        <?php
                                                                    }
                                                                    ?>

                                                                    <td width="132" align="center">
                                                                        <?php
                                                                        $fa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='1' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";

                                                                        $oDb = DBConnection::get();
                                                                        $fa1 = $oDb->query($fa1);
                                                                        while ($rowu
                                                                        = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                                            ?><?= $rowu['grade'] ?>
                                                                            <?php
                                                                        }
                                                                        ?></td>


<td width="147" align="center">
                                                                    <?php
                                                                    $fa2 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='2' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                    $oDb = DBConnection::get();
                                                                    $fa2 = $oDb->query($fa2);
                                                                    while ($rowu
                                                                    = $fa2->fetch()) {
                                                                        ?><?= $rowu['grade'] ?>
                                                                        <?php
                                                                    }
                                                                    ?>
</td>
                                                                <td width="75" align="center">    <?php
                                                                    $sa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='5' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                    $oDb = DBConnection::get();
                                                                    $sa1 = $oDb->query($sa1);
                                                                    while ($rowu
                                                                    = $sa1->fetch()) {
                                                                        ?><?= $rowu['grade'] ?></td>
                                                                        <?php
                                                                    }
                                                                    ?>


                                                                    <td width="122" align="center">
                                                                        <?php
                                                                        $overall
                                                                                = "SELECT Q1.student_id,Q1.subject_id,Q1.Term,Q1.Point,G.grade FROM (SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,SUM(ROUND(RD.`marks_obtained`/RD.`max_marks`*term_wtg,2)) Point FROM `ms_exam_acedemic_performance` RD INNER JOIN ms_exam_weightage W ON W.MSID=RD.MSID AND W.assesment_id=RD.assesment_id WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'  AND RD.`subject_id`='" . $rowv['subject_id'] . "'  And  W.term ='1' GROUP BY RD.student_id,RD.subject_id,W.term) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`percent_from` AND G.`percent_to`";
                                                                        $oDb = DBConnection::get();
                                                                        $overall
                                                                                = $oDb->query($overall);
                                                                        while ($rowu
                                                                        = $overall->fetch()) {
                                                                            ?><?= $rowu['grade'] ?>
    <?php } ?></td>
                                                                </tr><?php } ?>
                                                            <tr>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                                <td align="center">&nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table>
                                            <br />
                                            <table width="570" border="1" align="center">
                                                <tr>
                                                    <td class="st4">Remarks:
                                                        <hr /><br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                        <br />
                                                    </td>
                                                </tr>
                                            </table>
                                            <br />
                                            <table width="570" border="0" align="center">
                                                <tr>
                                                    <td align="center">....................</td>
                                                    <td align="center">...........................</td>
                                                    <td align="center">........................</td>
                                                    <td align="center">.....................</td>
                                                </tr>
                                                <tr class="st4">
                                                    <td align="center"><strong>Mother</strong></td>
                                                    <td align="center"><strong>Father/Guardian</strong></td>
                                                    <td align="center"><strong>Class Teacher</strong></td>
                                                    <td align="center"><strong>Principal</strong></td>
                                                </tr>
                                            </table>
                                            <br />
                                            <br /></td>
                                    </tr>




















                                </table></td>
                        </tr>
                    </table>  
                    <br />





                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>