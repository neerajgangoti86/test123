<!--https://www.youtube.com/watch?v=TSWQK_1qF3A-->
<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>      <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <!--//headder-->
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title"> Academic performance Add</h3>
                        </div>   
                        <div class="col-md-9">         <?php
                            if ($oCurrentSchool->grades_in_acc_perf == "1")
                                {
                                ?>    <form class="form-inline " method="post" id="exam">
                                    <input type="hidden" name="exam_type" value="xxx" />
                                    <div class="col-md-3">

                                        <label for="exampleInputName2">Marks Submit Type : </label>  

                                    </div> 
                                    <div class="col-md-3">
                                        <select id="type" name="type" class="form-control wth_div"  onchange='this.form.submit()' >
                                            <option value="1"  <?php echo (@$exam_type == 1) ? "selected='selected'" : ""; ?> >Grades</option>
                                            <option value="0" <?php echo (@$exam_type == 0) ? "selected='selected'" : ""; ?>>Marks</option>

                                        </select>

                                    </div>  </form>
                            <?php } ?> </div></div>

                    <?php
                    if (@$text)
                        {
                        ?>
                        <div class="row">
                            <div class="alert messages alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php echo $text; ?>
                            </div> </div>
                    <?php }
                    ?> 
                </div>
                <br>
                <br>



                <br>


                <!-- /.box-header -->



                <?php
//                print_r($display);
                if (@http_get('param1') == "add")
                    {
                 
          
                    ?>      <div class="box-body table-responsive no-padding"> 
                        <form class="form-inline " method="post" id="form_marks">     
                            <input type="hidden" value="xxx" name="add_marks_students">
                            <input type="hidden" value="<?= $MSID ?> " name="MSID">
                            <input type="hidden" value="<?= $selected_class ?> " name="class_id">
                            <input type="hidden" value="<?= $selected_section ?> " name="section">
                            <input type="hidden" value="<?= $id ?>" name="datesheet_id">
                            <input type="hidden" value="<?= $exam_type ?> " name="type">
    <!--                                <input type="hidden" value="<?= $selected_subjects ?> " name="sub_id">
                            <input type="hidden" value="<?= $oCurrentUser->mysession ?> " name="year">
                            
                            <input type="hidden" value="<?= $max_marks ?> " name="max_marks">
                            <input type="hidden" value="<?= $selected_activity ?> " name="activity_id">
                            <input type="hidden" value="<?= $passing_marks ?> " name="passing_marks">
                            <input type="hidden" value="<?= $exam_date ?>" name="date">
                            <input type="hidden" value="<?= $end_time ?>" name="end_time">
                            <input type="hidden" value="<?= $start_time ?> " name="start_time">-->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="col-md-6">
                                        <lable>Class</lable>
                                    </div><div class="col-md-6">
                                        <lable><?php
                                            $classes = Master::get_class_names2($MSID, $selected_class)->fetch();
                                            echo $classes['class_name'];
                                            ?></lable>
                                    </div> 
                                    <div class="col-md-6">
                                        <lable> Section</lable>
                                    </div><div class="col-md-6">
                                        <lable><?php
                                            $section_name = Master::get_schools_section($MSID, $selected_section)->fetch();

                                            echo $section_name['sec_name'];
                                            ?></lable>
                                    </div>
                                    <div class="col-md-6">
                                        <lable>Assesment</lable>
                                    </div><div class="col-md-6">
                                        <lable><?php
                                            $assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class, $selected_assesment)->fetch(PDO::FETCH_ASSOC);
                                            echo $assesments['title'];
                                            ?></lable>
                                    </div>                             <div class="col-md-6">
                                        <lable>Subject</lable>
                                    </div><div class="col-md-6">
                                        <lable><?php
                                            $subjects = SuperAdmin::get_schoolwise_subject2($MSID, $selected_subjects, array('selectAll' => 'true'), '', '', 'YES')->fetch(PDO::FETCH_OBJ);
                                            echo $subjects->name;
                                            ?></lable>
                                    </div>

                                    <div class="col-md-6">
                                        <lable> Activity</lable>
                                    </div><div class="col-md-6">
                                        <lable><?php
                                            $activityes = Master::get_activetyes_list($MSID, $selected_activity)->fetch(PDO::FETCH_OBJ);
                                            echo $activityes->name;
                                            ?></lable>
                                    </div></div>

                                <div class="col-md-6">
                                    <div class="col-md-6">
                                        <lable> Exam Date</lable>
                                    </div><div class="col-md-6">
                                        <lable><?= $exam_date ?></lable>
                                    </div> <div class="col-md-6">
                                        <lable> Max Marks</lable>
                                    </div><div class="col-md-6">
                                        <lable><?= $max_marks ?></lable>
                                    </div> <div class="col-md-6">
                                        <lable> Passing Marks</lable>
                                    </div><div class="col-md-6">
                                        <lable><?= $passing_marks ?></lable>
                                    </div> 
                                    <div class="col-md-6">
                                        <lable> Start Time</lable>
                                    </div><div class="col-md-6">
                                        <lable><?= $start_time ?></lable>
                                    </div> 
                                    <div class="col-md-6">
                                        <lable> End Time</lable>
                                    </div><div class="col-md-6">
                                        <lable><?= $end_time ?></lable>
                                    </div> </div>
                            </div>
                            <table class="table table-hover">
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>Student Id  </th> 
                                    <th>Student Name </th>   
                                    <?php
                                    if ($oCurrentSchool->grades_in_acc_perf == "1" && @$exam_type == "1")
                                        {
                                        ?><th>Grade Obtained</th>
                                            <?php
                                            }
                                        else
                                            {
                                            ?>
                                        <th>Marks Obtained </th> 

                                    <?php } ?>
                                    <th>Attendance</th> 

                                </tr>
                                <?php
                                $i = 1;
//                                print_r($students);
                                while ($rowv = $students->fetch())
                                    {

// pr($rowv);
                                    ?>
                                    <tr>
                                        <td><?= $i ?></td>
                                        <td><?= $rowv['student_id']; ?></td>
                                        <td><?= $rowv['name']; ?></td>  
                                        <?php
                                        $students_marks['marks_obtained'] = '';
                                        $students_marks['grade'] = '';
                                        $students_marks = Exam::get_accademinc_performance($MSID, $id, $selected_class, $rowv['student_id'], $selected_section, array('selectAll' => 'true'))->fetch(PDO::FETCH_ASSOC);
                                        $max_marks = $datesheet->max_marks;
                                        $attendance = $students_marks['attendance'];
//                                        print_r($attendance);
                                        ?>

                                    <input type="hidden"  value="<?= $rowv['student_id'] ?>" name="id[<?= $rowv['student_id'] ?>]" >
                                    <?php
                                    if ($oCurrentSchool->grades_in_acc_perf == "1" && @$exam_type == "1")
                                        {
                                        ?>

                                        <input type="hidden" class="" value="0" name="marks[]" >    
                                        <td><input type="text" class="" placeholder="A"  value="<?= $students_marks['grade'] ?>" name="grade[]" ></td>                      <?php
                                        }
                                    else
                                        {
                                        ?><td><input type="text" class="morks_obtained" data-id="<?= $max_marks; ?>" value="<?= $students_marks['marks_obtained'] ?>" name="marks[]" ></td>                      


                                        <input type="hidden" class="" value="0" name="grade[]" >    

                                    <?php } ?>
                                    <td><input type="checkbox"  <?php echo (@$attendance) ? 'checked="checked"' : ((@$attendance == "1") ? 'checked="checked"' : ""); ?> name="cid[<?= $rowv['student_id'] ?>]" ></td>

                                    </th>
                                    </tr>
                                    <?php
                                    $i++;
                                    }
                                ?>
                            </table>
                            <div class="col-md-7"><div id="error_div"> </div> </div> <div class="col-md-3">
                                <a id="btn_submit_id" name="exam_add_performance" class="btn btn-lg btn-success btn-block">Submit</a>
                            </div> <div class="col-md-1"></div>
                            <!-- \col -->
                            <!--</div>-->
                        </form>

                        <?php
                        }
                    else
                        {
                        ?>
                        <div class="row">

                            <form class="form-inline " method="post" id="exam_add_academic_performance_form_id">
                                <input type="hidden" name="exam_add_academic_performance_form" value="xxx" />
                                <div class="col-md-6">  <div class="col-md-6">

                                        <label for="exampleInputName2">Select Class : </label>  

                                    </div> 
                                    <div class="col-md-6">
                                        <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                            <?php
                                            foreach ($classs as $class)
                                                {
                                                if (@$selected_class == $class['class_no'])
                                                    {
                                                    $selected = 'selected = "selected"';
                                                    }
                                                else
                                                    {
                                                    $selected = "";
                                                    }
                                                ?>
                                                <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                    <?= $class['class_name']; ?>
                                                </option>
                                                <?php
                                                } if (@$selected_class || @$selected_class != NULL)
                                                {
                                                
                                                }
                                            else
                                                {
                                                ?>
                                                <option value="" selected="selected" >
                                                    Select Class
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div> 
                                    <?php
                                    if (@$selected_class || @$selected_class != NULL)
                                        {
                                        ?>  <?php
                                        if ($oCurrentSchool->section > 1)
                                            {
                                            ?>

                                            <div class="col-md-6"> 
                                                <label for="exampleInputName2">Select Section : </label></div>

                                            <div class="col-md-6"> 
                                                <select id="section_id" name="section_id" class="form-control wth_div" >
                                                    <?php
                                                    while ($row = $sectiondet->fetch(PDO::FETCH_OBJ))
                                                        {
                                                        $sections = Master::get_schools_section($MSID, $row->section);
                                                        ?>
                                                        <b> Select Class : - </b>
                                                        <?php
                                                        foreach ($sections as $section)
                                                            {
                                                            if (@$selected_section == $section['section_id'])
                                                                {
                                                                $selected = 'selected = "selected"';
                                                                }
                                                            else
                                                                {
                                                                $selected = "";
                                                                }
                                                            ?>



                                                            <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                                <?= $section['sec_name']; ?>
                                                            </option>
                                                            <?php
                                                            }
                                                        } if (@$selected_section == NULL)
                                                        {
                                                        ?> <option value="" selected="selected" >
                                                            Select Section
                                                        </option> 
                                                        <?php
                                                        }
                                                    else
                                                        {
                                                        
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                            <?php
                                            }
                                        else if ($oCurrentSchool->section < 2)
                                            {
                                            ?>
                                            <input type="hidden" name="section_id" value="1">
                                        <?php } ?>

                                        <div class="col-md-6">

                                            <label for="exampleInputName2">Select Assesment : </label>

                                            <?php //print_r($assesments);                         ?>

                                        </div><div class="col-md-6">
                                            <select id="assesment" name="assesment" class="form-control wth_div "  onchange='this.form.submit()' >

                                                <?php
                                                if (@$selected_assesment)
                                                    {
                                                    ?><option value=""  >
                                                        All Assesment
                                                    </option> 
                                                    <?php
                                                    }
                                                else
                                                    {
                                                    ?><option value=""  selected = "selected" >
                                                        All Assesment
                                                    </option> 
                                                    <?php
                                                    }
                                                foreach ($assesments as $assesment)
                                                    {
                                                    if ($selected_assesment == $assesment['assesment_id'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                                        <?= $assesment['title']; ?>
                                                    </option>
                                                <?php } ?>

                                            </select>
                                        </div>

                                        <?php
                                        if ($selected_class > 10 && $school_sub->rowCount() > 0)
                                            {
                                            ?> <div class="col-md-6">

                                                <label for="exampleInputName2">Subject Group : </label>

                                            </div>  
                                            <div class="col-md-6" >

                                                <select class="form-control wth_div" id="groupid" name="groupid">
                                                    <option value="">Select</option>
                                                    <?php
                                                    while ($rowv = $school_sub->fetch())
                                                        {
//                                                    pr($rowv);
                                                        $subjects = SuperAdmin::get_subject_group($rowv['subject_gp_id'])->fetch(PDO::FETCH_OBJ);
                                                        ?> 
                                                        <option value="<?= $subjects->group_id ?>"><?= $subjects->Subjects ?></option>
                                                    <?php } ?>

                                                </select>

                                            </div> 
                                        <?php }
                                        ?>
                                        <div class="col-md-6">

                                            <label for="exampleInputName2">Select Subjects : </label>

                                        </div>
                                        <div class="col-md-6">
                                            <select id="subjects" name="sub_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                                <?php
                                                $i = 0;
                                                if (@$selected_subjects)
                                                    {
                                                    ?><option value="">
                                                        All Subjects
                                                    </option> 
                                                    <?php
                                                    }
                                                else
                                                    {
                                                    ?><option value=""  selected = "selected" >
                                                        All Subjects
                                                    </option> 
                                                    <?php
                                                    }
                                                foreach ($subjects as $subject)
                                                    {
                                                    if ($selected_subjects == $subject->subject_id)
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $subject->subject_id; ?>" <?= $selected ?> >
                                                        <?= $subject->name ?>
                                                    </option>
                                                    <?php
                                                    $i++;
                                                    }
                                                ?>
                                            </select>
                                        </div>

                                        <?php
                                        if (@$selected_subjects && @$selected_assesment)
                                            {
                                            if ($oCurrentSchool->activity == "1")
                                                {
                                                ?>
                                                <div class="col-md-6">
                                                    <label for="exampleInputName2">Select Activities : </label>

                                                    <?php //print_r($activityes);                            ?>

                                                </div><div class="col-md-6">
                                                    <select id="activity" name="activity" class="form-control  wth_div"  onchange='this.form.submit()' >

                                                        <?php
                                                        //print_r($activityes);
                                                        foreach ($activityes as $activitye)
                                                            {

                                                            $activiy_name = Exam::get_student_academic_activity($MSID, $activitye->activity_id)->fetch();

                                                            if (@$selected_activity == $activitye->activity_id)
                                                                {
                                                                $selected = 'selected = "selected"';
                                                                }
                                                            else
                                                                {
                                                                $selected = "";
                                                                }
                                                            ?>
                                                            <option value="<?= $activitye->activity_id; ?>" <?= $selected ?> >
                                                                <?= $activiy_name['name']; ?>
                                                            </option>
                                                        <?php } ?>

                                                    </select> </div>

                                                <?php
                                                }
                                            ?>



                                            <?php
                                            }
                                        ?>

                                        <!-- \col -->

                                        <div class="row"> 
                                            <div class="col-md-6"> </div>
                                            <div class="col-md-6" style="margin-top: 10px">
                                                <button value="test" name="exam_add_performance" class="btn btn-lg btn-success btn-block">Add Marks</button> 


                                            </div>
                                        </div>

                                        <?php
                                        }
                                    ?>

                                </div>
                                <div class="col-md-6">
                                    <div class="col-md-6">

                                        <label>Exam Date</label>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="exam_date" id="attendance_date_id" value="<?= (@$_POST['exam_date']) ? $_POST['exam_date'] : "" ?>" class="form-control  exam_date"/>
                                    </div>
                                    <div class="col-md-6">

                                        <label>Max Marks</label>
                                    </div>
                                    <div class="col-md-6">
                                        <input class="form-control" type="text" name="max_marks" id="max_marks" value="<?php
                                        if (@$_POST['max_marks'])
                                            {
                                            echo $_POST['max_marks'];
                                            }
                                        else
                                            {
                                            if (@$assesment_detail->max_marks > 0)
                                                {
                                                echo $assesment_detail->max_marks;
                                                }
                                            else
                                                {
                                                echo "";
                                                }
                                            }
                                        ?>" />

                                    </div>
                                    <div class="col-md-6">
                                        <label>Passing Marks</label>
                                    </div>
                                    <div class="col-md-6">
                                        <input class="form-control" type="text" name="pasing_marks" id="max_marks" value="<?php echo (@$_POST['pasing_marks']) ? $_POST['pasing_marks'] : "" ?>" />
                                    </div>
                                    <?php
                                    if (@$selected_subjects)
                                        {
                                        ?>
                                        <div class="col-md-6">
                                            <label>Start Time</label>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="input-group bootstrap-timepicker timepicker">
                                                <input name="start_time"  value="<?php echo (@$_POST['start_time']) ? $_POST['start_time'] : "" ?>" type="text" class="form-control timepicker2">
                                                <div class="input-group-addon">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <label>End Time</label>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="input-group bootstrap-timepicker timepicker">
                                                <input name="end_time" value="<?php echo (@$_POST['end_time']) ? $_POST['end_time'] : "" ?>" type="text" class="form-control timepicker2">
                                                <div class="input-group-addon">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>

                                </div>
                            </form>
                        </div>

                        <?php
                        }
//                    pr($_POST);
                    ?>


                </div>
                <!-- /.box -->
            </div> 
        </div>
</section>
<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        // For Datepicker
         $('.exam_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		clearBtn: true
		});
    
		$('.timepicker2').timepicker();
		     $('.morks_obtained').blur(function(){
//  alert('s');       
   var marks = $(this).val();
        var max_marks =$(this).data('id');
          if (marks <= max_marks) {
                    $(this).removeClass('error');
                } else {
   $(this).addClass('error');
                }
              
   });
      $('#btn_submit_id').click(function () { 
           $('#error_div .errorDiv').remove();
                if ($(".morks_obtained").hasClass("error")) {
$("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');
              
                } else {
         $('#form_marks').submit();
//              alert(form_marks'sucess');  
    }
            });
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>

