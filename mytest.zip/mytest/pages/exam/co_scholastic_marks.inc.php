<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>    <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3"> <h3 class="box-title"> Co - Scholastic Marks List</h3>
                        </div>   
                        <div class="col-md-9">
                            <form class="form-inline " method="post" id="remarks_form_id">
                                <input type="hidden" name="marks_form_areas" value="xxx" />
                                <label for="exampleInputName2">Select Class : </label>
                                <select id="class_id" name="class_id" class="form-control"  onchange='this.form.submit()' >

                                    <b> Select Class : - </b>
                                    <?php
                                    if ($oCurrentUser->ulevel == "9")
                                        {
                                        foreach ($classs as $class)
                                            {
                                            if (@$selected_class == $class['class_no'])
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                <?= $class['class_name']; ?>
                                            </option>
                                            <?php
                                            }
                                        }
                                    else
                                        {
                                        foreach ($classes as $class_no => $class_name)
                                            {
                                            if (@$selected_class == $class_no)
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $class_no ?>" <?= $selected ?> ><?= $class_name ?></option>
                                            <?php
                                            }
                                        }
                                    if (@$selected_class || @$selected_class != NULL)
                                        {
                                        
                                        }
                                    else
                                        {
                                        ?>
                                        <option value="" selected="selected" >
                                            Select Class
                                        </option>
                                    <?php } ?>
                                </select>

                                <?php
//pr($oCurrentSchool->no_of_term);
//exit();
                                if ($oCurrentSchool->no_of_term != '0')
                                    {
                                    ?>

                                    <label for="exampleInputName2">Select Term : </label>
                                    <?php //echo $selected_term  ?>
                                    <select id="term" name="term" class="form-control" onchange="this.form.submit()">
                                        <b> Select Term : - </b>

                                        <option value="1" <?php
                                        if (@$selected_term)
                                            {
                                            echo (@$selected_term == '1') ? 'selected = "selected"' : "";
                                            }
                                        ?>>Term1</option>
                                                <?php
                                                if ($oCurrentSchool->no_of_term == '2')
                                                    {
                                                    ?>
                                            <option value="2" <?php
                                            if (@$selected_term)
                                                {
                                                echo ($_SESSION['term'] == '2') ? 'selected = "selected"' : "";
                                                }
                                            ?>>Term2</option>
                                                    <?php
                                                    }
                                                ?> 
                                                <?php
                                                if ($oCurrentSchool->no_of_term == '3')
                                                    {
                                                    ?>
                                            <option value="2" <?php
                                            if (@$selected_term)
                                                {
                                                echo ($selected_term == '2') ? 'selected = "selected"' : "";
                                                }
                                            ?>>Term2</option>
                                            <option value="3" <?php
                                            if (@$selected_term)
                                                {
                                                echo ($selected_term == '3') ? 'selected = "selected"' : "";
                                                }
                                            ?>>Term3</option>
                                                    <?php
                                                    }
                                                ?>   

                                    </select>


                                    <?php
                                    }
                                ?>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.box-header -->


                <?php
                if (@$selected_class != NULL)
                    {
                    ?>
                    <div class="box-body table-responsive no-padding"> 
                        <?php // if ($totalrecords > 0) {     ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Student Id  </th> 
                                <th>Student Name </th>   
                                <th >Action </th> 

                            </tr>
                            <?php
                            $i = 1;
                            while ($rowv = $students->fetch())
                                {
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= $rowv['student_id']; ?></td>
                                    <td><?= $rowv['name']; ?></td>  

                                    <td>


                                        <?php
                                        // @$selected_term;
                                        if (!@$selected_term)
                                            {
                                            @$selected_term = '0';
                                            }

                                        $marks = Exam::get_exam_co_scholastic_marks($MSID, '', $data = array('selectAll' => 'true'), $rowv['student_id'], $oCurrentUser->mysession, '', @$selected_term);

                                        // print_r($marks);


                                        $marks_count = $marks->rowCount();



                                        if ($marks_count > 0)
                                            {
                                            ?>
                                                                                                                    <!--<a class="btn btn-danger btn-flat" data-title="Edit Co Scholastic Marks" data-ms="modal" href="<?= CLIENT_URL; ?>/exam-load/exam_co_scholastic_marks/<?php echo $rowv['student_id']; ?>/<?= @$selected_class ?>/<?= @$selected_term ?>">Edit Co Scholastic Marks</a>-->
                                            <?php
                                            $LINK = CLIENT_URL . '/exam-load/exam_co_scholastic_marks/' . $rowv['student_id'] . '/' . @$selected_class . '/' . @$selected_term;
                                            $BTNS = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                            print_r($BTNS);
                                            ?>
                                            <?php
                                            }
                                        else
                                            {
                                            ?>
                                                                                                                    <!--<a class="btn btn-success btn-flat " data-title="Add Co Scholastic Marks" data-ms="modal" href="<?= CLIENT_URL; ?>/exam-load/exam_co_scholastic_marks/<?php echo $rowv['student_id']; ?>/<?= @$selected_class ?>/<?= @$selected_term ?>">Add Co Scholastic Marks</a>-->

                                            <?php
                                            $LINK = CLIENT_URL . '/exam-load/exam_co_scholastic_marks/' . $rowv['student_id'] . '/' . @$selected_class . '/' . @$selected_term;
                                            $BTNS = check_privlages($LINK, NULL, NULL, $oCurrentUser->myuid, $MSID);
                                            print_r($BTNS);
                                            ?>
                                            <?php
                                            }
                                        ?>



                                    </td>
                                </tr>
                                <?php
                                $i++;
                                }
                            ?>
                        </table>
                        <!--<div class="row">-->
                        <div class="col-md-7">  </div> <div class="col-md-3">
                            <!--                     <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                            -->
                        </div> <div class="col-md-1"></div>
                        <!-- \col -->
                        <!--</div>-->
                    </div>
                <?php } ?>
            </div>
            <!-- /.box -->
        </div>
    </div></section>

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
 
	 $('#myModal').on('click','#submit',function(){
	   var datastring = $("#onajaxForm").serialize();
	   $(".errorDiv").remove();
	   $.ajax({
			type: "POST", // type
			url: "$siteurl/exam-post", // request file
			data: datastring, // post data
			success: function (responseText) { // get the response
				
   alert(responseText);
       responseText = $.trim(responseText);
				if (responseText != 'error') {
//					location.reload(); 
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
				}
			}, // end success
			error: function (jqXHR, textStatus, errorThrown) {
				if (jqXHR.status == 500) {
					$("#onajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
				}
			}
		});
		// end
		return false;
	 });
	 	 //edit model
	 $('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>