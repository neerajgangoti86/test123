<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <?php
            if (@$id)
                {
                ?>
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title"> </h3>


                    </div>
                    <!-- /.box-header -->
                    <div class="box-footer clearfix">
                        <table width="200" border="1" align="center">
                            <tr>
                                <td><table width="200" border="0">
                                        <tr valign="top">

                                            <td>&nbsp;&nbsp;&nbsp;</td>
                                            <td><table width="587" border="0" align="center" cellpadding="2" cellspacing="2">
                                                    <tr>
                                                        <td width="575"><table width="575" height="696" align="center" bordercolor="#2A3F00" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat">
                                                                <tr align="left" valign="top">
                                                                    <td width="567" height="76"><table width="535">
                                                                            <tr>
                                                                                <td colspan="3" align="center"><span class="m1">
                                                                                        <?= $oCurrentSchool->name ?>
                                                                                    </span></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td width="78" align="left"><table width="69" border="0" align="center">
                                                                                        <tr>
                                                                                            <td width="63"><img  src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" height="80" width="70" /></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                                <td width="245" valign="top"><table width="232" border="0" align="center">
                                                                                        <tr>
                                                                                            <td width="226" align="center" ><span class="b1">
                                                                                                    <?= $oCurrentSchool->place ?>
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td align="center" class="b1"><span class="t1">
                                                                                                    <?= $oCurrentSchool->board ?>
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td align="center" class="t1">&nbsp;</td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                                <td width="200" align="right" valign="top"><table width="200" border="0" align="right">
                                                                                        <tr>
                                                                                            <td align="center">Phone No:</td>
                                                                                            <td align="right" class="r"><strong>
                                                                                                    <?= $oCurrentSchool->phone ?>
                                                                                                </strong></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="144" class="r">Affiliation No.:</td>
                                                                                            <td width="46" align="right" class="r"><strong>
                                                                                                    <?= $oCurrentSchool->affNo ?>
                                                                                                </strong></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td class="r"> School Code :</td>
                                                                                            <td align="right"><span class="r"><strong>
                                                                                                        <?= $oCurrentSchool->schoolNo ?>
                                                                                                    </strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="r">Recognition No.:</span></td>
                                                                                            <td align="right"><strong class="r">
                                                                                                    <?= $oCurrentSchool->recNo ?>
                                                                                                </strong></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                                <tr align="left" valign="top">
                                                                    <td height="22"><hr/></td>
                                                                </tr>
                                                                <tr align="left" valign="top">
                                                                    <td height="539" valign="top"><table width="553" height="185" border="1" align="center">
                                                                            <tr valign="top">
                                                                                <td width="521" height="179" colspan="2"><table width="553" border="0">
                                                                                        <tr>
                                                                                            <td height="27" colspan="6"><span class="b1"><?= $student['name']; ?></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="27" colspan="6" class="st4">Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student['student_id']; ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class/House:&nbsp;
                                                                                                <strong>
                                                                                                    <?= $class_id ?>
                                                                                                </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style19">Birth Date: </span>&nbsp;&nbsp;                      <span class="style19">
                                                                                                    <strong>
                                                                                                        <?php
                                                                                                        $dob = $student['birth_date'];
                                                                                                        echo $new_date = date('d-m-Y', strtotime($dob));
                                                                                                        ?>
                                                                                                    </strong>                        </span></td>
                                                                                        </tr>

                                                                                        <tr>
                                                                                            <td width="161" height="26"><span class="style19">Father's Name: </span></td>
                                                                                            <td colspan="4"><span class="style19"><strong><?php echo "Mr." . ' ' . $student['f_name']; ?></strong></span></td>
                                                                                            <td width="7">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="24"><span class="style19">Mother's Name: </span></td>
                                                                                            <td colspan="5"><span class="style19"><strong><?php echo "Mrs." . ' ' . $student['m_name']; ?></strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="26" colspan="6"><span class="style19">Village/Town:<strong><?= $student['village'] ?></strong><span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> <strong>

                                                                                                    </strong>                        <span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phones:<strong><?php echo $student['f_mobile']; ?></strong></span></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="32" rowspan="2" valign="bottom"><span class="style19">Total Attendance:</span></td>
                                                                                            <td width="217" height="15" align="center"><span class="style19">Term 1</span></td>
                                                                                            <td width="20" rowspan="2" align="center">&nbsp;</td>
                                                                                            <td width="119" align="center"><span class="style19">term2</span></td>
                                                                                            <td colspan="2" rowspan="2" align="center">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="15" align="center"><span class="style19"><strong  ></strong></span></td>
                                                                                            <td width="119" align="center"><span class="style19"><strong  >

                                                                                                    </strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="21"><span class="style19">Total Working Days:</span></td>
                                                                                            <td height="21" align="center"><span class="style19">

                                                                                                </span></td>
                                                                                            <td height="21" align="center">&nbsp;</td>
                                                                                            <td align="center"><span class="style19">
                                                                                                </span></td>
                                                                                            <td colspan="2" align="center">&nbsp;</td>
                                                                                        </tr>
                                                                                        <?php //}       ?>
                                                                                    </table></td>
                                                                            </tr>
                                                                        </table>
                                                                        <br />

                                                                        <br />
                                                                        <table width="557" border="0" align="center">
                                                                            <tr>
                                                                                <td width="121" align="center">....................</td>
                                                                                <td width="184" align="center">...........................</td>
                                                                                <td width="153" align="center">........................</td>
                                                                                <td width="81" align="center">.....................</td>
                                                                            </tr>
                                                                            <tr class="st4">
                                                                                <td align="center"><strong>Mother</strong></td>
                                                                                <td align="center"><strong>Father/Guardian</strong></td>
                                                                                <td align="center"><strong>Class Teacher</strong></td>
                                                                                <td align="center"><strong><!--<a href="reportcardp2.php?id=<? //echo " . $rowv['subject_id'] . ";?>&cno=<? //echo $cno;?>" style="text-decoration:none" target="_blank">-->Principal<!--</a>--></strong></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>
                        <br />
                        <table width="200" align="center" >
                            <tr>
                                <td><table width="200" border="1">
                                        <tr valign="top">
                                            <td align="center" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><table width="100%" border="0">
                                                    <tr>
                                                        <td width="329" class="st3"><strong>Part 1:Academic Performance:Scholastic Areas</strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center"><strong class="style19">term 1</strong></td>
                                                    </tr>
                                                </table>
                                                <table width="556" border="1">
                                                    <tr class="style19">
                                                        <td width="137" align="left" class="st4"><strong class="st4">Subjects</strong></td>
                                                        <?php
                                                        $sql_assesments = "SELECT distinct title , id FROM `ms_exam_assesments` Where term='term 1'  And MSID='$MSID' ";
                                                        $oDb = DBConnection::get();
                                                        $sql_assesments = $oDb->query($sql_assesments);
                                                        while ($rowv = $sql_assesments->fetch())
                                                            {
                                                            ?>
                                                            <td width="71" align="left" class="st4"><strong class="st4"><?= $rowv['title'] ?>
                                                                </strong></td><?php } ?>
                                                        <td width="68" align="left" class="st4"><strong class="st4">term|GR</strong></td>
                                                    </tr>
                                                    <?php
                                                    $subjects_querry = "SELECT distinct subject_id FROM `ms_exam_acedemic_performance` Where  MSID='$MSID' and session='" . $_SESSION['year'] . "' and student_id='" . $student['student_id'] . "'";
                                                    $oDb = DBConnection::get();
                                                    $subjects_querry = $oDb->query($subjects_querry);
//                                                    if()
                                                    while ($rowv = $subjects_querry->fetch())
                                                        {
                                                        ?>
                                                        <tr class="style19" >

                                                            <?php
                                                            $subjects = "SELECT subject_f_name FROM `ms_subjects_all` Where subject_id='" . $rowv['subject_id'] . "'";
                                                            $oDb = DBConnection::get();
                                                            $subjects = $oDb->query($subjects);
                                                            while ($rowu = $subjects->fetch())
                                                                {
                                                                ?><td><?= $rowu['subject_f_name'] ?></td>
                                                                <?php
                                                                }
                                                            ?>
                                                            <td width="132" align="center">
                                                                <?php
                                                                $fa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='1' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";

                                                                $oDb = DBConnection::get();
                                                                $fa1 = $oDb->query($fa1);
                                                                while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC))
                                                                    {
                                                                    ?><?= $rowu['grade'] ?>
                                                                    <?php
                                                                    }
                                                                ?></td>


                                                            <td width="147" align="center">
                                                                <?php
                                                                $fa2 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='2' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                $oDb = DBConnection::get();
                                                                $fa2 = $oDb->query($fa2);
                                                                while ($rowu = $fa2->fetch())
                                                                    {
                                                                    ?><?= $rowu['grade'] ?>
                                                                    <?php
                                                                    }
                                                                ?>
                                                            </td>
                                                            <td width="75" align="center">    <?php
                                                                $sa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='5' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                $oDb = DBConnection::get();
                                                                $sa1 = $oDb->query($sa1);
                                                                while ($rowu = $sa1->fetch())
                                                                    {
                                                                    ?><?= $rowu['grade'] ?>
                                                                    <?php
                                                                    }
                                                                ?></td>


                                                            <td width="122" align="center">
                                                                <?php
                                                                $overall = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade FROM (SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,SUM(ROUND(RD.`marks_obtained`/RD.`max_marks`*term_wtg,2)) point FROM `ms_exam_acedemic_performance` RD INNER JOIN ms_exam_weightage W ON W.MSID=RD.MSID AND W.assesment_id=RD.assesment_id WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'  AND RD.`subject_id`='" . $rowv['subject_id'] . "'  And  W.term ='1' GROUP BY RD.student_id,RD.subject_id,W.term) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
                                                                $oDb = DBConnection::get();
                                                                $overall = $oDb->query($overall);
                                                                while ($rowu = $overall->fetch())
                                                                    {
                                                                    ?><?= $rowu['grade'] ?>
                                                                <?php } ?></td></tr>
                                                        <?php
                                                        }
                                                    ?>
                                                </table>


                                            </td>
                                            <td>&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <table width="587" border="0" align="center" cellpadding="2" cellspacing="2">
                                                    <tr>
                                                        <td width="575" height="670"><table width="575" height="666" align="center" bordercolor="#2A3F00">

                                                                <tr align="left" valign="top">
                                                                    <td height="660" valign="top" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><table width="556" border="0" >
                                                                            <tr>
                                                                                <td width="541" align="right" valign="top" class="st4"><span class="style19"><strong>Student Id :<?= $student['student_id']; ?>  Overall Grade  :
                                                                                            <?php
                                                                                            $qry = "SELECT Q1.student_id, Q1.point,G.Grade FROM (Select student_id, MSID, round(Sum( `marks_obtained`)/SUM(`max_marks`)*100,2) point from `ms_exam_acedemic_performance`  WHERE   MSID='$MSID' AND `session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "') Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
//print_r($qry);
                                                                                            $oDb = DBConnection::get();
                                                                                            $qry = $oDb->query($qry);
                                                                                            while ($rowu = $qry->fetch())
                                                                                                {
                                                                                                echo $rowu['Grade'];
                                                                                                }
                                                                                            ?>
                                                                                        </strong></span></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="center"><span class="style19"><strong>Term 2</strong></span></td>
                                                                            </tr>
                                                                        </table>
                                                                        <table width="556" border="1">
                                                                            <tr>
                                                                                <td width="95" align="left"><span class="style19"><strong class="st4">Subjects</strong></span></td>
                                                                                <?php
                                                                                $sql_assesments = "SELECT distinct title , id FROM `ms_exam_assesments` Where term='term 2'  And MSID='$MSID' ";
                                                                                $oDb = DBConnection::get();
                                                                                $sql_assesments = $oDb->query($sql_assesments);
                                                                                while ($rowv = $sql_assesments->fetch())
                                                                                    {
                                                                                    ?>
                                                                                    <td width="38" align="center" class="st4"><strong class="st4"><?= $rowv['title'] ?>
                                                                                        </strong></td><?php } ?>
                                                                                <td width="56" align="center"><span class="style19"><strong class="st4">term|GR</strong></span></td>
                                                                                <td width="63" align="center"><span class="style19"><strong class="st4">OA Gr</strong></span></td>

                                                                                <td width="99" align="center"><span class="style19"><strong class="st4">Grade point</strong></span></td>

                                                                            </tr>
                                                                            <?php
                                                                            $subjects_querry = "SELECT distinct subject_id FROM `ms_exam_acedemic_performance` Where  MSID='$MSID' and session='" . $_SESSION['year'] . "' and student_id='" . $student['student_id'] . "'";
                                                                            $oDb = DBConnection::get();
                                                                            $subjects_querry = $oDb->query($subjects_querry);
                                                                            while ($rowv = $subjects_querry->fetch())
                                                                                {
                                                                                ?><tr>  <?php
                                                                                    $subjects = "SELECT subject_f_name FROM `ms_subjects_all` Where subject_id='" . $rowv['subject_id'] . "'";
                                                                                    $oDb = DBConnection::get();
                                                                                    $subjects = $oDb->query($subjects);
                                                                                    while ($rowu = $subjects->fetch())
                                                                                        {
                                                                                        ?><td><?= $rowu['subject_f_name'] ?></td>
                                                                                        <?php
                                                                                        }
                                                                                    ?><td width="22" align="center">
                                                                                        <?php
                                                                                        $fa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='3' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";

                                                                                        $oDb = DBConnection::get();
                                                                                        $fa1 = $oDb->query($fa1);
                                                                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC))
                                                                                            {
                                                                                            ?><?= $rowu['grade'] ?>
                                                                                            <?php
                                                                                            }
                                                                                        ?></td>

                                                                                    <td width="38" align="center">
                                                                                        <?php
                                                                                        $fa2 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='4' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                                        $oDb = DBConnection::get();
                                                                                        $fa2 = $oDb->query($fa2);
                                                                                        while ($rowu = $fa2->fetch())
                                                                                            {
                                                                                            ?><?= $rowu['grade'] ?>
                                                                                            <?php
                                                                                            }
                                                                                        ?>
                                                                                    </td>
                                                                                    <td width="56" align="center">    <?php
                                                                                        $sa1 = "SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,ROUND(RD.`marks_obtained`/RD.`max_marks`*100,2) Percent,G.`grade` FROM 
`ms_exam_acedemic_performance` RD INNER Join ms_exam_grades G ON (RD.`marks_obtained`/RD.`max_marks`*100) Between G.`percent_from` AND 
G.`percent_to` AND RD.MSID=G.MSID WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND RD.student_id='" . $student['student_id'] . "'  AND RD.`assesment_id`='6' AND RD.`subject_id`='" . $rowv['subject_id'] . "' ORDER BY 
`student_id`,`assesment_id`,`subject_id`";
                                                                                        $oDb = DBConnection::get();
                                                                                        $sa1 = $oDb->query($sa1);
                                                                                        while ($rowu = $sa1->fetch())
                                                                                            {
                                                                                            ?><?= $rowu['grade'] ?>
                                                                                            <?php
                                                                                            }
                                                                                        ?></td>


                                                                                    <td width="63" align="center">
                                                                                        <?php
                                                                                        $overall = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade FROM (SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,SUM(ROUND(RD.`marks_obtained`/RD.`max_marks`*term_wtg,2)) point FROM `ms_exam_acedemic_performance` RD INNER JOIN ms_exam_weightage W ON W.MSID=RD.MSID AND W.assesment_id=RD.assesment_id WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'  AND RD.`subject_id`='" . $rowv['subject_id'] . "'  And  W.term ='2' GROUP BY RD.student_id,RD.subject_id,W.term) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
                                                                                        $oDb = DBConnection::get();
                                                                                        $overall = $oDb->query($overall);
                                                                                        while ($rowu = $overall->fetch())
                                                                                            {
                                                                                            ?><?= $rowu['grade'] ?>
                                                                                        <?php } ?></td>
                                                                                    <td width="99" align="center">
                                                                                        <?php
                                                                                        $oa = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade FROM (Select RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,round(Sum(RD.`marks_obtained`)/SUM(W.overall_wtg)*100,2) point from ms_exam_weightage W inner JOIN `ms_exam_acedemic_performance` RD ON W.assesment_id=RD.assesment_id AND W.overall_wtg=RD.max_marks WHERE  RD.MSID='$MSID' AND  W.MSID='$MSID' AND `session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'  AND  `subject_id`='" . $rowv['subject_id'] . "'   GROUP BY RD.student_id,RD.subject_id ) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
//                                                                                    
//                                                                                    print_r($oa);
//                                                                                    $a        = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade FROM (SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,SUM(ROUND(RD.`marks_obtained`/RD.`max_marks`*term_wtg,2)) point FROM `ms_exam_acedemic_performance` RD INNER JOIN ms_exam_weightage W ON W.MSID=RD.MSID AND W.assesment_id=RD.assesment_id WHERE RD.MSID='$MSID' AND RD.`session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'  AND RD.`subject_id`='" . $rowv['subject_id'] . "'  And  W.term ='2' GROUP BY RD.student_id,RD.subject_id,W.term) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
                                                                                        $oDb = DBConnection::get();
                                                                                        $oa = $oDb->query($oa);
                                                                                        while ($rowu = $oa->fetch())
                                                                                            {
                                                                                            ?><?= $rowu['grade'] ?>
                                                                                        <?php } ?></td>
                                                                                    <td width="64" align="center">
                                                                                        <?php
                                                                                        $grade_points = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade ,G.grade_point FROM (Select RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,round(Sum(RD.`marks_obtained`)/SUM(W.overall_wtg)*100,2) point from ms_exam_weightage W inner JOIN `ms_exam_acedemic_performance` RD ON W.assesment_id=RD.assesment_id AND W.overall_wtg=RD.max_marks WHERE  RD.MSID='$MSID' AND  W.MSID='$MSID' AND `session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'  AND  `subject_id`='" . $rowv['subject_id'] . "'   GROUP BY RD.student_id,RD.subject_id ) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
//                                                                                    print_r($grade_points); 
                                                                                        $oDb = DBConnection::get();
                                                                                        $grade_points = $oDb->query($grade_points);
                                                                                        while ($rowu = $grade_points->fetch())
                                                                                            {
                                                                                            ?><?= $rowu['grade_point'] ?>
                                                                                        <?php } ?></td>



                                                                                </tr>  
                                                                            <?php } ?>
                                                                            <tr>
                                                                                <td colspan="5" class="r"><strong>Grading Scale:</strong>A1=91%-100%;A2=81%-90%;B1=71%-80%;B2=61%-70%;C1=51%-60%;C2=41%-%50%;D=33%-40%;E1=21%-32%;E2=20% AND BELOW</td>
                                                                                <td width="64" align="center"><span class="style19"><strong>CGPA</strong></span></td>
                                                                                <td width="95" align="center"><span class="style19"><strong>

                                                                                            <?php
                                                                                            $grade_points = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade ,G.grade_point FROM (Select RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,round(Sum(RD.`marks_obtained`)/SUM(W.overall_wtg)*100,2) point from ms_exam_weightage W inner JOIN `ms_exam_acedemic_performance` RD ON W.assesment_id=RD.assesment_id AND W.overall_wtg=RD.max_marks WHERE  RD.MSID='$MSID' AND  W.MSID='$MSID' AND `session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'     GROUP BY RD.student_id,RD.subject_id ) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
//                                                                                    print_r($grade_points); 
                                                                                            $oDb = DBConnection::get();
                                                                                            $grade_points = $oDb->query($grade_points);
                                                                                            while ($rowu = $grade_points->fetch())
                                                                                                {
                                                                                                ?><?= $rowu['grade_point'] ?>
                                                                                            <?php } ?> </strong></span></td>
                                                                            </tr>

                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>       





                    </div>
                </div>
                <!-- /.box --><?php
                }
            else
                {
                ?>

                <div class = "box">
                    <div class = "box-header">

                        <div class = "row">
                            <div class = "col-md-3"> <h3 class = "box-title"> Remarks List</h3>
                            </div>
                            <div class = "col-md-9">
                                <form class = "form-inline " method = "post" id = "remarks_form_id">
                                    <input type = "hidden" name = "remarks_form" value = "xxx" />
                                    <label for = "exampleInputName2">Select Class : </label>
                                    <select id = "class_id" name = "class_id" class = "form-control wth_div" onchange
                                            = 'this.form.submit()' >
                                                <?php
                                                $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                                ?>
                                        <b> Select Class : - </b>
                                        <?php
                                        foreach ($classs as $class)
                                            {
                                            if ($_SESSION['class_id'] == $class['class_no'])
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                <?= $class['class_name']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>

                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->



                <?php } ?>
            </div>

        </div>
    </div>
</section>
<table width="653" border="1" align="center">
    <tr>
        <td width="643" height="595"><table width="575" height="587" align="center" bordercolor="#2A3F00"  style="background-size:45%; background-position:center; background-repeat:no-repeat">
                <tr align="left" valign="top">
                    <td width="567" height="88"><table width="694">
                            <tr>
                                <td colspan="3" align="center"><span class="m1">
                                        <?= $oCurrentSchool->name ?>
                                    </span></td>
                            </tr>
                            <tr>
                                <td width="78" height="108" align="left"><table width="69" border="0" align="center">
                                        <tr>
                                            <td width="63"><img    src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" width="75" height="75" class="logo"></td>
                                        </tr>
                                    </table></td>
                                <td width="245" valign="top"><table width="232" border="0" align="center">
                                        <tr>
                                            <td width="226" align="center" ><span class="b1">
                                                    <?= $oCurrentSchool->place . '  ' . $oCurrentSchool->board ?>
                                                </span></td>
                                        </tr>
                                        <tr>
                                            <td align="center" class="n1">Website:<? echo $Website;?><? //echo ,E-mail:$EMail;?>,Ph:<? echo $Phone;?></td>
                                        </tr>
                                    </table></td>
                                <td width="200" align="right" valign="top"><table width="200" border="0" align="right">
                                        <tr>
                                            <td align="center">Phone No:</td>
                                            <td align="right" class="r"><strong>
                                                    <?= $oCurrentSchool->phone ?> 
                                                </strong></td>
                                        </tr>
                                        <tr>
                                            <td width="144" class="r">Affiliation No.:</td>
                                            <td width="46" align="right" class="r"><strong>
                                                    <?= $oCurrentSchool->affNo ?>  
                                                </strong></td>
                                        </tr>
                                        <tr>
                                            <td class="r"> School Code :</td>
                                            <td align="right"><span class="r"><strong>
                                                        <?= $oCurrentSchool->schoolNo ?>   
                                                    </strong></span></td>
                                        </tr>
                                        <tr>
                                            <td><span class="r">Recognition No.:</span></td>
                                            <td align="right"><strong class="r">
                                                    <?= $oCurrentSchool->recNo ?>
                                                </strong></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table></td>
                </tr>

                <tr align="left" valign="top">
                    <td height="441" valign="top"><table width="694" height="121" border="0" align="center">
                            <tr valign="top">
                                <td width="521" height="117" colspan="2"><table width="694" border="0">
                                        <tr>
                                            <td height="37" colspan="2" align="left"><span class="st41">Name :&nbsp;&nbsp;<strong>&nbsp;<?php echo $student['name']; ?></strong></span></td>
                                            <td width="91"><span class="st41">Id:<strong><?php echo $student['student_id']; ?></strong></span></td>
                                            <td width="165" height="37" colspan="2">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td height="39" align="left"><span class="st41">Father's Name: &nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            <td width="245" height="39" align="left"><strong><span class="st41"><?php echo "Mr." . ' ' . $student['f_name']; ?></span></strong></td>
                                            <td height="39" colspan="3" ><span class="st41">Class/House:&nbsp;<strong>
                                                        <?= $class_id ?>
                                                    </strong></span></td>
                                        </tr>
                                        <tr>
                                            <td width="175" height="34" align="left"><span class="st41">Mother's Name: </span></td>
                                            <td align="left" class="st41"><strong><span class="style41"><?php echo "Mrs." . ' ' . $student['m_name']; ?></span></strong></td>
                                            <td colspan="3"><span class="st41">Phones: <strong><?php echo $student['f_mobile']; ?></strong></span></td>
                                        </tr>
                                        <tr>
                                            <td height="39" align="left"><span class="st41">Village/Town:</span></span></td>
                                            <td align="left" class="st41"><strong><span class="style41"><?= $student['village'] ?></span></strong></td>
                                            <td colspan="3"><span class="st41">District:<strong><?= $student['village'] ?></strong></span></td>
                                        </tr>
                                        <?php //}?>
                                    </table></td>
                            </tr>
                        </table>
                        <table width="694" border="0" align="center">
                            <tr valign="top" class="st41">
                                <td height="20" align="center"><span class="style2">Academic Performance:<?php echo $_SESSION['year'], '-', $_SESSION['year'] + 1; ?></span><br />
                                    <br /></td>
                            </tr>
                        </table>
                        <table width="694" height="142" border="1" align="center">
                            <tr valign="top">
                                <td height="35" class="st41">&nbsp;</td>
                                <td colspan="3" align="center" class="st41"><strong>TERM I</strong></td>
                                <td colspan="3" align="center" class="st41"><strong>TERM II</strong></td>
                                <td colspan="3" align="center" class="st41"><strong>Final Term</strong></td>
                            </tr>
                            <tr valign="top">
                                <td width="85" height="46" class="st41"><strong>Subjects</strong></td>
                                <td width="58" align="center" class="st41"><strong>Mx.
                                        Marks</strong></td>
                                <td width="58" align="center" class="st41"><strong>Pass Marks</strong></td>
                                <td width="68" align="center" class="st41"><strong>Marks Ob</strong></td>
                                <td width="40" align="center" class="st41"><strong>Mx.<br />
                                        Marks</strong></td>
                                <td width="43" align="center" class="st41"><strong>Pass Marks</strong></td>
                                <td width="66" align="center" class="st41"><strong>Marks Ob</strong></td>
                                <td width="60" align="center" class="st41"><strong>Mx.<br />
                                        Marks</strong></td>
                                <td width="69" align="center" class="st41"><strong>Pass Marks</strong></td>
                                <td width="83" align="center" class="st41"><strong>Marks Ob</strong></td>
                            </tr> 
                            <?php
                            $subjects_querry = "SELECT distinct subject_id FROM `ms_exam_acedemic_performance` Where  MSID='$MSID' and session='" . $_SESSION['year'] . "' and student_id='" . $student['student_id'] . "'";
                            $oDb = DBConnection::get();
                            $subjects_querry = $oDb->query($subjects_querry);
                            while ($rowv = $subjects_querry->fetch())
                                {
                                ?><tr valign="top">
                                    <?php
                                    $subjects = "SELECT subject_f_name FROM `ms_subjects_all` Where subject_id='" . $rowv['subject_id'] . "'";
                                    $oDb = DBConnection::get();
                                    $subjects = $oDb->query($subjects);
                                    while ($rowu = $subjects->fetch())
                                        {
                                        ?><td class="st41"><?= $rowu['subject_f_name'] ?></td>
                                        <?php
                                        }
                                    ?>  
                                    <td align="center" class="st41"><?php $phigf1 = mysql_query($phgf1 = "SELECT MaxMarks FROM `21Repodata1` Where  `MSID`='$msid' And  `Session`='$session' And   `AssId`='1'  And StudentId='$sid'  And SubjectId='$sb'");
                                while ($powgf1 = mysql_fetch_array($phigf1))
                                    {
                                    echo $MaxMarks = $powgf1['MaxMarks'];
                                } ?></td>
                                    <td align="center" class="st41"></td>
                                    <td align="center" class="st41"></td>
                                    <td align="center" class="st41"></td>
                                    <td align="center" class="st41"></td>
                                    <td align="center" class="st41"></td>
                                    <td align="center" class="st41"></td>
                                    <td align="center" class="st41"></td>
                                    <td align="center" class="st41"></td>

                                </tr>
<?php } ?>
                            <tr valign="top">
                                <td height="26" align="center" class="st41">Result:</td>
                                <td height="26" colspan="3" align="center" class="st41"></td>
                                <td height="26" colspan="3" align="center" class="st41"></td>
                                <td height="26" colspan="3" align="center" class="st41"></td>
                            </tr>
                        </table>
                        <table width="694" border="0" align="center">
                            <tr>
                                <td height="21" align="center" class="st41">&nbsp;</td>
                                <td align="center" class="st41">&nbsp;</td>
                                <td align="center" class="st41">&nbsp;</td>
                                <td align="center" class="st41">&nbsp;</td>
                                <td align="center">&nbsp;</td>
                            </tr>
                            <tr>
                                <td height="21" align="center" class="st41">&nbsp;</td>
                                <td align="center" class="st41">&nbsp;</td>
                                <td align="center" class="st41">&nbsp;</td>
                                <td align="center" class="st41">&nbsp;</td>
                                <td align="center">&nbsp;</td>
                            </tr>
                            <tr>
                                <td width="206" height="21" align="center" class="st41"><strong>Remarks:</strong></td>
                                <td width="112" align="center" class="st41"><strong>
                                  <!--<img src="<?php
                                        if ($limg != "")
                                            {
                                            echo $limg;
                                            }
                                        else
                                            {
                                            echo "../../Upload/aboutlogo.jpg";
                                            }
                                        ?> " width="70" height="70" />-->
                                        Excellent</strong></td>
                                <td width="134" align="center" class="st41"><strong>Very Good</strong></td>
                                <td width="81" align="center" class="st41"><strong>Good </strong></td>
                                <td width="139" align="center"><strong><span class="st41">Average</span></strong></td>
                            </tr>
                        </table>
                        <br />
                        <br />
                        <table width="694" border="0" align="center">
                            <tr>
                                <td width="201" height="21" align="center" class="st41"><strong>Class Teacher</strong></td>
                                <td width="261" align="center"><strong>
                                  <!--<img src="<?php
                                        if ($limg != "")
                                            {
                                            echo $limg;
                                            }
                                        else
                                            {
                                            echo "../../Upload/aboutlogo.jpg";
                                            }
                                        ?> " width="70" height="70" />-->
                                    </strong></td>
                                <td width="218" align="center"><strong><span class="st41">Principal</span></strong></td>
                            </tr>
                        </table></td>
                </tr>
            </table></td>
    </tr>
</table>

