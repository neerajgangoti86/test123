<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>      <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <!--//headder-->
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title">Result</h3>
                            <?php
                if (@$display == "1")
                    {
                    ?>  <h3 class="box-title"><a href="<?php echo CLIENT_URL . "/result" ?>" type="button" class="btn bg-olive btn-flat margin" >Check Next Result</a></h3>
                    <?php } ?>
                        </div>   
                        <div class="col-md-9">  
                        </div></div>
                    <?php
//                    if (@$text)
//                        {
//                        
                    ?>
                    <!--                        <div class="row">
                                                <div class="alert messages alert-danger alert-dismissable">
                                                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                                    //<?php echo $text; ?>
                                                </div> </div>-->
                    <?php
//}
//                    
                    ?> 
                </div>
                <br>
                <br>



                <br>



                <?php
                if (@$display == "1")
                    {
                    ?> <div class="box-body table-responsive no-padding"> 
                        <form class="form-inline " method="post" id="exam_add_academic_performance_formid">     
                            <input type="hidden" value="xxx" name="academic_performance_posted_form">
                            <input type="hidden" value="<?= $MSID ?> " name="MSID">
                            <?php
                            if ($ttlcount > 0)
                                {
                                ?> <table class="table table-hover">
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Name  </th>
                                        <th>Max Marks  </th> 
                                        <th>Scored Marks  </th> 
                                        <th>Percentage </th>   
                                        <th>Grade </th>  
                                        <th>Rank </th> 
                                        <th>Result </th>  
                                        <th>Report </th> 

                                    </tr>
                                    <?php
                                    $i = 1;



                                    while ($rowv = $get_records->fetch())
                                        {

                                        $student = Student::get_students($oCurrentUser->myuid, 'all', $rowv['student_id'])->fetch();
//                                        print_r($rowv);
//                                        exit();
                                        ?>


                                        <tr>
                                            <td><?= $i ?></td>
                                            <td><?= $student['name']; ?></td>
                                            <td><?= $get_activity_datail['max_marks']; ?></td>
                                            <td><?= $rowv['marks_obtained']; ?></td>  
                                            <td><?php if (@$rowv['marks_obtained'])
                                {
                                echo round(($rowv['marks_obtained'] /$get_activity_datail['max_marks'])  * 100,2);
                            }
                            else
                                {
                                 echo 0 ;
                                }
                            ?></td>  
                                            <td>-</td>  
                                            <td>-</td>  
                                            <td><?php echo ($rowv['marks_obtained'] >= $get_activity_datail['pass_marks']) ? "Pass" : "Fail" ?></td>  
                                            <td>-</td>  



                                        </tr> 
                                    <?php
                                    $i++;
                                    }
                                ?>
                                </table>   <?php
                        }
                    else
                        {
                        echo '<div class="text-center margin">No records found.</div>';
                        }
                            ?>
                            <!--<div class="row">-->

                            <!-- \col -->
                            <!--</div>-->
                        </form> </div>
    <?php
    }
else
    {
    ?>       <div class="row">
                        <form class="form-inline " method="post" id="exam_add_datesheet_form_id">
                            <input type="hidden" name="exam_add_datesheet_form" value="xxx" />
                            <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                            <input type="hidden" name="year" value="<?= $oCurrentUser->mysession ?>" />
                            <!--<input type="hidden" name="exam_add_datesheet_form" value="xxx" />-->
                            <div class="col-md-6">  <div class="col-md-6">

                                    <label for="exampleInputName2">Select Class : </label>  

                                </div> 
                                <div class="col-md-6">
                                    <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                        <?php
                                        foreach ($classs as $class)
                                            {
                                            if (@$selected_class == $class['class_no'])
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                            <?= $class['class_name']; ?>
                                            </option>
                                            <?php
                                            } if (@$selected_class || @$selected_class != NULL)
                                            {
                                            
                                            }
                                        else
                                            {
                                            ?>
                                            <option value="" selected="selected" >
                                                Select Class
                                            </option>
                                <?php } ?>
                                    </select>
                                </div> 
                                <?php
                                if (@$selected_class || @$selected_class != NULL)
                                    {
                                    ?>  <?php
                                    if ($oCurrentSchool->section > 1)
                                        {
                                        ?>

                                        <div class="col-md-6"> 
                                            <label for="exampleInputName2">Select Section : </label></div>

                                        <div class="col-md-6"> 
                                            <select id="section_id" name="section_id" class="form-control wth_div" >
                                                <?php
                                                while ($row = $sectiondet->fetch(PDO::FETCH_OBJ))
                                                    {
                                                    $sections = Master::get_schools_section($MSID, $row->section);
                                                    ?>
                                                    <b> Select Class : - </b>
                                                    <?php
                                                    foreach ($sections as $section)
                                                        {
                                                        if (@$selected_section == $section['section_id'])
                                                            {
                                                            $selected = 'selected = "selected"';
                                                            }
                                                        else
                                                            {
                                                            $selected = "";
                                                            }
                                                        ?>



                                                        <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                        <?= $section['sec_name']; ?>
                                                        </option>
                                                        <?php
                                                        }
                                                    } if (@$selected_section == NULL)
                                                    {
                                                    ?> <option value="" selected="selected" >
                                                        Select Section
                                                    </option> 
                                                    <?php
                                                    }
                                                else
                                                    {
                                                    
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                        <?php
                                        }
                                    else if ($oCurrentSchool->section < 2)
                                        {
                                        ?>
                                        <input type="hidden" name="section_id" value="1">
                                        <?php } ?>

                                    <div class="col-md-6">

                                        <label for="exampleInputName2">Select Assesment : </label>

                                            <?php //print_r($assesments);                       ?>

                                    </div><div class="col-md-6">
                                        <select id="assesment" name="assesment" class="form-control wth_div "  onchange='this.form.submit()' >

                                            <?php
                                            if (@$selected_assesment)
                                                {
                                                ?><option value=""  >
                                                    All Assesment
                                                </option> 
                                                <?php
                                                }
                                            else
                                                {
                                                ?><option value=""  selected = "selected" >
                                                    All Assesment
                                                </option> 
                                                <?php
                                                }
                                            foreach ($assesments as $assesment)
                                                {
                                                if ($selected_assesment == $assesment['assesment_id'])
                                                    {
                                                    $selected = 'selected = "selected"';
                                                    }
                                                else
                                                    {
                                                    $selected = "";
                                                    }
                                                ?>
                                                <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                        <?= $assesment['title']; ?>
                                                </option>
                                    <?php } ?>

                                        </select>
                                    </div>

        <?php
        if ($selected_class > 10 && $school_sub->rowCount() > 0)
            {
            ?> <div class="col-md-6">

                                            <label for="exampleInputName2">Subject Group : </label>

                                        </div>  
                                        <div class="col-md-6" >

                                            <select class="form-control wth_div" id="groupid" name="groupid">
                                                <option value="">Select</option>
                                                <?php
                                                while ($rowv = $school_sub->fetch())
                                                    {
//                                                    pr($rowv);
                                                    $subjects = SuperAdmin::get_subject_group($rowv['subject_gp_id'])->fetch(PDO::FETCH_OBJ);
                                                    ?> 
                                                    <option value="<?= $subjects->group_id ?>"><?= $subjects->Subjects ?></option>
                                        <?php } ?>

                                            </select>

                                        </div> 
        <?php }
        ?>
                                    <div class="col-md-6">

                                        <label for="exampleInputName2">Select Subjects : </label>

                                    </div>
                                    <div class="col-md-6">
                                        <select id="subjects" name="sub_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                            <?php
                                            $i = 0;
                                            if (@$selected_subjects)
                                                {
                                                ?><option value="">
                                                    All Subjects
                                                </option> 
                                                <?php
                                                }
                                            else
                                                {
                                                ?><option value=""  selected = "selected" >
                                                    All Subjects
                                                </option> 
                                                <?php
                                                }
                                            foreach ($subjects as $subject)
                                                {
                                                if ($selected_subjects == $subject->subject_id)
                                                    {
                                                    $selected = 'selected = "selected"';
                                                    }
                                                else
                                                    {
                                                    $selected = "";
                                                    }
                                                ?>
                                                <option value="<?= $subject->subject_id; ?>" <?= $selected ?> >
            <?= $subject->name ?>
                                                </option>
                                        <?php
                                        $i++;
                                        }
                                    ?>
                                        </select>
                                    </div>

        <?php
        if (@$selected_subjects && @$selected_assesment)
            {
            if ($oCurrentSchool->activity == "1")
                {
                ?>
                                            <div class="col-md-6">
                                                <label for="exampleInputName2">Select Activities : </label>

                                                    <?php //print_r($activityes);                          ?>

                                            </div><div class="col-md-6">
                                                <select id="activity" name="activity" class="form-control  wth_div"  onchange='this.form.submit()' >

                                                    <?php
                                                    //print_r($activityes);
                                                    foreach ($activityes as $activitye)
                                                        {

                                                        $activiy_name = Exam::get_student_academic_activity($MSID, $activitye->activity_id)->fetch();

                                                        if (@$selected_activity == $activitye->activity_id)
                                                            {
                                                            $selected = 'selected = "selected"';
                                                            }
                                                        else
                                                            {
                                                            $selected = "";
                                                            }
                                                        ?>
                                                        <option value="<?= $activitye->activity_id; ?>" <?= $selected ?> >
                                                <?= $activiy_name['name']; ?>
                                                        </option>
                                            <?php } ?>

                                                </select> </div>

                                            <?php
                                            }
                                        ?>



            <?php
            }
        ?>

                                    <!-- \col -->

                                    <div class="row"> 
                                        <div class="col-md-6"> </div>
                                        <div class="col-md-6" style="margin-top: 10px">
                                            <button value="test" name="exam_add_performance" class="btn btn-lg btn-success btn-block">Get Result</button> 


                                        </div>
                                    </div>

        <?php
        }
    ?>

                            </div>

                        </form>
                    </div>
<?php } ?>




            </div>
            <!-- /.box -->
        </div> 
    </div>
</section>
<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        // For Datepicker
         $('.exam_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		clearBtn: true
		});
    
		$('.timepicker2').timepicker();
		     $('.morks_obtained').blur(function(){
//  alert('s');       
   var marks = $(this).val();
        var max_marks =$(this).data('id');
          if (marks <= max_marks) {
                    $(this).removeClass('error');
                } else {
   $(this).addClass('error');
                }
              
   });
      $('#btn_submit_id').click(function () { 
           $('#error_div .errorDiv').remove();
                if ($(".morks_obtained").hasClass("error")) {
$("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');
              
                } else {
         $('#form_marks').submit();
//              alert(form_marks'sucess');  
    }
            });
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>

