<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"> Promoted Students List</h3>
                    <h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal" data-target="#myModal">Add  New</button></h3>

                    <form class="form-inline right_ft column_hide_show" method="post">
                        <div class="btn-group">
                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                Select Columns 
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu"  aria-labelledby="dropdownMenu1">
                                <?php
                                foreach ($failed_array as $key => $val) {
                                    if (in_array($key, @$selected_columns_failed)) {
                                        $checked = "checked ='checked'";
                                    } else {
                                        $checked = "";
                                    }
                                    ?>
                                    <li>
                                        <input type="checkbox" value="<?= $key ?>"  name="column1[]" <?= $checked ?>><?= $val ?>
                                    </li> 
                                <?php } ?>
                                <li><button type="submit" name="columnsubmit" class="btn btn-block btn-sm btn-warning btn-flat">Submit</button></li>
                            </ul>
                        </div>
                    </form>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
<?php if ($totalrecords > 0) {
    ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                        <?php if (!@$selected_columns_failed) {
                            ?>
                                    <th>Student ID</th>
                                    <th>Name </th> 
                                    <th>Father Name</th>
                                    <th>Mother Name</th>    
                                    <th>Birth Date</th>    
                                    <th>House</th>
                                    <th>Class</th>
                                    <th>Result Date</th>     

        <?php
    } else {
        if (in_array('id', $selected_columns_failed)) {
            ?><th>Student Id</th><?php } ?>
                                    <?php
                                    if (in_array('name', $selected_columns_failed)) {
                                        ?><th>Name</th><?php } ?>
                                    <?php
                                    if (in_array('f_name', $selected_columns_failed)) {
                                        ?><th>Father Name</th><?php } ?>
                                    <?php
                                    if (in_array('m_name', $selected_columns_failed)) {
                                        ?><th>Mother Name</th><?php } ?> 
                                    <?php
                                        if (in_array('birth_date', $selected_columns_failed)) {
                                            ?><th>Birth Date</th><?php } ?>  
                                        <?php
                                        if (in_array('house', $selected_columns_failed)) {
                                            ?><th>House</th><?php } ?>   <?php
                                        if (in_array('class', $selected_columns_failed)) {
                                            ?><th>Class</th><?php } ?>   <?php
                                        if (in_array('result_date', $selected_columns_failed)) {
                                            ?><th>Result Date</th><?php } ?>


                                        <?php
                                    }
                                    ?>

                                <th>Action</th>
                            </tr>
                                    <?php
                                    $i = 1;
                                    while ($rowv = $promoted_students->fetch()) {

                                        $student_data = Student::get_students($oCurrentUser->myuid, '', $rowv['s_id'])->fetch(PDO::FETCH_OBJ);
                                        print_r($rowv);
                                        ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <?php if (!@$selected_columns_failed) {
                                        ?>
                                        <th><?= $student_data->student_id; ?></th>
                                        <th><?= $student_data->name; ?></th>
                                        <th><?= $student_data->f_name; ?></th>
                                        <th><?= $student_data->m_name; ?></th>
                                        <th><?= $student_data->birth_date; ?></th>
                                        <th><?= $student->house; ?></th>
                                        <th><?= $student->class; ?></th>
                                        <th><?= $rowv['date_result']; ?></th>

                                    <?php
                                } else {
                                    if (in_array('id', $selected_columns_failed)) {
                                        ?><th><?= $student_data->student_id; ?></th><?php } ?>
                                        <?php
                                        if (in_array('name', $selected_columns_failed)) {
                                            ?><th><?= $student_data->name; ?></th><?php } ?>
            <?php
            if (in_array('f_name', $selected_columns_failed)) {
                ?><th><?= $student_data->f_name; ?></th><?php }
            ?>
            <?php
            if (in_array('m_name', $selected_columns_failed)) {
                ?><th><?= $student_data->m_name; ?></th><?php
            }

            if (in_array('birth_date', $selected_columns_failed)) {
                ?><th><?= date('d M,Y', strtotime($student_data->birth_date)); ?></th><?php
                                        }
                                        if (in_array('house', $selected_columns_failed)) {
                                            ?><?php ?>   <th><?= $student_data->house ?></th><?php } ?><?php
                                        if (in_array('class', $selected_columns_failed)) {
                                            ?><?php ?>   <th><?= $student_data->class ?></th><?php } ?><?php
                                        if (in_array('result_date', $selected_columns_failed)) {
                                            ?><?php ?>   <th><?= $rowv['date_result'] ?></th><?php } ?><?php
                                        }
                                        ?>

                                    <td>
                                        <a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $student_data->student_id; ?>" data-ms="modal" data-title="Student Profile">View</a>
                                        <?php
                                        $LINK = CLIENT_URL . '/exam-load/promoted_students/' . $rowv['id'];
                                        $BTNS = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                        print_r($BTNS);
                                        ?>
                                        &nbsp; 
                                        <?php
                                        $LINK = CLIENT_URL . '/promoted-students/del/' . $rowv['id'];
                                        $BTNS = check_privlages(NULL, NULL, $LINK, $oCurrentUser->myuid, $MSID);
                                        print_r($BTNS);
                                        ?>
                                    </td>
                                </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                        </table>
                                    <?php
                                } else {
                                    echo '<div class="text-center margin">No records found.</div>';
                                }
                                ?>
                </div>
                <div class="box-footer clearfix">
                                <?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Add Promoted Student</h4>
                </div>
                <div class="modal-body">
                    <form method="post" action="" role="form" id="onajaxForm">
                        <input type="hidden" name="add_failed_student" value="true" />

                        <input type="hidden" name="MSID" value="<?= $MSID ?>" /> 
                        <input type="hidden" name="result" value="1" />
<!--                        <input type="hidden" name="type" value="exam_grade" />-->
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Student Id</label>
                                        <input class="form-control" type="text" name="s_id" id="title" placeholder="15001"/>
                                    </div>
                                </div>
                                <!-- \col --> 
                            </div>
                            <div class="form-group ">
                                <label  for="exampleInputName2">Result Date:</label>
                                <div class="input-group ">
                                    <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>

                                    <input type="text" name="date_result" id="date_result" value="" class="form-control failed_date"/>
                                </div>
                                <!-- /.input group -->
                            </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="submit">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

</section>

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
 $('.failed_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		
        clearBtn: true
		});
          $('.failed_date').on('changeDate', function (ev) {
                $(this).datepicker('hide');
            });
	 $('#myModal').on('click','#submit',function(){
	   var datastring = $("#onajaxForm").serialize();
	   $(".errorDiv").remove();
	   $.ajax({
			type: "POST", // type
			url: "$siteurl/exam-post", // request file
			data: datastring, // post data
			success: function (responseText) { // get the response
				
//   alert(responseText);
       responseText = $.trim(responseText);
				if (responseText != 'error') {
					location.reload(); 
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
				}
			}, // end success
			error: function (jqXHR, textStatus, errorThrown) {
				if (jqXHR.status == 500) {
					$("#onajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
				}
			}
		});
		// end
		return false;
	 });
	 	 //edit model
	 $('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
  $('.column_hide_show li').on('click', function (event) {
        event.stopPropagation();
    });
});                                    
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>


