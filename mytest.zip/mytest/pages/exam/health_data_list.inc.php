<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"> Health Data Report</h3>
                    <a href="<?= CLIENT_URL ?>/health-data" title="View"><h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal">Add Health Details</button></h3></a>


                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <?php if ($totalrecords > 0) { ?>
                        <table width="882" class="table table-hover">
                            <tr>
                                <th width="39" rowspan="2">Sr.No</th>
                                <th width="66" rowspan="2">Student ID</th>
                                <th width="80" rowspan="2">Student Name</th>
                                <th width="37" rowspan="2">Class</th>
                                <th width="45" rowspan="2">Height</th>
                                <th width="48" rowspan="2">Weight</th>
                                <th width="101" rowspan="2">dental_hygiene</th>
                                <th width="76" rowspan="2">Vision (L)-(R)</th>
                                <th width="36" rowspan="2">Pulse</th>
                                <th width="65" rowspan="2">Any Allergy</th>
                                <td colspan="6" align="center">Vaccination</td>




                            </tr>
                            <tr>
                              <th>Hepatitis</th>
                              <th>Chickenpox</th>
                              <th>Typhoid</th>
                              <th>DT.OPA</th>
                              <th>MMR</th>
                              <th>Measles</th>
                            </tr>
                            <tbody>
                                <?php
                                $i = 1;
                                while ($rowv = $students->fetch()) {
                    $student = Student::get_students($oCurrentUser->myuid, 'all', $rowv['s_id'])->fetch();
                                    ?>
                                    <tr> <td><?= $i ?></td>
                                        <td><?= $rowv['s_id']; ?></td>
                                        <td><?= $student['name']; ?></td>
                                        <td><?= $student['class_name']; ?></td>
                                        <td><?= $rowv['height']; ?></td>
                                        <td><?= $rowv['weight']; ?></td>
                                        <td><?php echo $dental_hygiene=$rowv['dental_hygiene'];?>  </td>
                                        <td>(<?= $rowv['vision_l']; ?>)-(<?= $rowv['vision_r']; ?>)</td>
                                        <td><?= $rowv['pulse']; ?></td>
                                        <td><?= $rowv['alergy']; ?></td>
                                        <td width="17"><?php if($rowv['hepatitis_a']=='Yes'){?><img src="<?= ASSETS_FOLDER ?>/img/right.png"> <?php }else{?><img src="<?= ASSETS_FOLDER ?>/img/wrong.png">  <?php } ?></td>
                                        <td width="84"><?php if($rowv['chickenpox']=='Yes') { ?><img src="<?= ASSETS_FOLDER ?>/img/right.png"> <?php }else{?><img src="<?= ASSETS_FOLDER ?>/img/wrong.png">  <?php } ?></td>
                                        <td width="53"><?php if($rowv['typhoid']=='Yes'){  ?><img src="<?= ASSETS_FOLDER ?>/img/right.png"> <?php }else{?><img src="<?= ASSETS_FOLDER ?>/img/wrong.png">  <?php } ?></td>
                                     <td width="29"><?php if($rowv['dt_opa']=='Yes') { ?><img src="<?= ASSETS_FOLDER ?>/img/right.png"> <?php }else{?><img src="<?= ASSETS_FOLDER ?>/img/wrong.png">  <?php } ?></td>
                                        <td width="21"><?php if($rowv['mmr']=='Yes'){ ?><img src="<?= ASSETS_FOLDER ?>/img/right.png"> <?php }else{?><img src="<?= ASSETS_FOLDER ?>/img/wrong.png">  <?php } ?></td>
                                        <td width="17"><?php if($rowv['measles']=='Yes') { ?><img src="<?= ASSETS_FOLDER ?>/img/right.png"> <?php }else{?><img src="<?= ASSETS_FOLDER ?>/img/wrong.png">  <?php } ?></td>


                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php
                    } else {
                        echo '<div class="text-center margin">No records found.</div>';
                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
                    <?php // $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php
$sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});	
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>