<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>

            <div class = "box">
                <div class = "box-header">
                    <div class = "row">
                        <div class = "col-md-4"> 
                            <h3 class = "box-title"> Report Cards </h3>
                        </div>
                        <?php if (@$show_result) { ?>

                        <?php } else {
                            ?>

                            <div class = "col-md-8">
                                <?php // if ($param1 == "half-yearly" || $param1 == "final-report") { ?>
                                    <form class="form-inline " method="post">
                                        <input type="hidden" name="report_card_form" value="xxx" />
                                        <label for="exampleInputName2">Select Class : </label>

                                        <div class = "row">
                                            <div class = "col-md-4"> 
                                                <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >
                                                    <?php
                                                    if ((@$selected_class)&&($selected_class!= NULL)) {
//     exit();
                                                    } else {
                                                        ?> <option>Select Class</option>
                                                        <?php
                                                    }
                                                    $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                                    ?>
                                                    <?php
                                                    foreach ($classs as $class) {
                                                        if ($selected_class == $class['class_no'] && $selected_class != NULL) {
                                                            $selected = 'selected = "selected"';
                                                        } else {
                                                            $selected = "";
                                                        }
                                                         ?>
                                                        <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                            <?= $class['class_name']; ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class = "col-md-4"> 
                                                <?php
//                                            echo $selected_section;
                                                if ((@$selected_class)&&($selected_class!= NULL)) {
                                                    ?>
                                                 <?php
                                if ($oCurrentSchool->section > 1)
                                    {
                                    ?>

                                    <div class="col-md-6"> 
                                        <label for="exampleInputName2">Select Section : </label></div>

                                    <div class="col-md-6"> 
                                        <select id="section_id" name="section_id" class="form-control wth_div" >
                                            <?php
                                            while ($row = $sectiondet->fetch(PDO::FETCH_OBJ))
                                                {
                                                $sections = Master::get_schools_section($MSID, $row->section);
                                                ?>
                                                <b> Select Class : - </b>
                                                <?php
                                                foreach ($sections as $section)
                                                    {
                                                    if (@$selected_section == $section['section_id'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>



                                                    <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                        <?= $section['sec_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
                                                } if (@$selected_section == NULL)
                                                {
                                                ?> <option value="" selected="selected" >
                                                    Select Section
                                                </option> 
                                                <?php
                                                }
                                            else
                                                {
                                                
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <?php
                                    }
                                else if ($oCurrentSchool->section < 2)
                                    {
                                    ?>
                                    <input type="hidden" name="section_id" value="1">
                                <?php } ?>


                                                <?php } ?>

                                            </div></div>
                                    </form> 
                                <?php // } else {
                                    ?>
<!--                                    <div class = "row">
                                        <div class = "col-md-6">
                                            <a class=""  href="<?= CLIENT_URL; ?>/report-cards/half-yearly">Half Yearly Report Card</a>
                                        </div>
                                        <div class = "col-md-6">
                                            <a class=""  href="<?= CLIENT_URL; ?>/report-cards/final-report">Final Report Card</a>
                                        </div>

                                    </div>-->
                                <?php // } ?>


                            </div>
                        <?php } ?>
                    </div>

                </div>
                <?php if (@$show_result) { ?>
                    <div class="box-body table-responsive no-padding"> 
                        <?php // if ($totalrecords > 0) {  ?>

                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Student Id  </th> 
                                <th>Student Name </th>   
                                <th>FA 1 </th>
                                <th>FA 2 </th>
                                <th>FA 3 </th>
                                <th>FA 4 </th>
                                <th>SA 1 </th>
                                <th>SA 2 </th>
                                <th>Term 1 </th>
                                <th>Final Term </th>

                            </tr>
                            <?php
                            $i = 1;
                            while ($rowv = $students->fetch()) {
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <th><?= $rowv['student_id']; ?></th>
                                    <th><?= $rowv['name']; ?></th>  
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardFA1.php/<?= $rowv['student_id'] ?>/FA1" target="_blank">Print</a></th>
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardFA1.php/<?= $rowv['student_id'] ?>/FA2" target="_blank">Print</a></th>
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardFA1.php/<?= $rowv['student_id'] ?>/FA3" target="_blank">Print</a></th>
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardFA1.php/<?= $rowv['student_id'] ?>/FA4" target="_blank">Print</a></th>
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardFA1.php/<?= $rowv['student_id'] ?>/SA1" target="_blank">Print</a></th>
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardFA1.php/<?= $rowv['student_id'] ?>/SA2" target="_blank">Print</a></th>
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardS6hyap6.php/<?= $rowv['student_id'] ?>/HP" target="_blank">Print</a></th>
                                    <th><a href="<?= CLIENT_URL ?>/report-card/reportcardS62.php/<?= $rowv['student_id'] ?>/Final" target="_blank">Print</a></th>



                                </tr>
                                <?php
                                $i++;
                            }
                            ?>
                        </table>
                    </div>
                <?php } ?>
            </div>

        </div>
    </div>
</section>
