<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>      <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <!--//headder-->
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title">Add Exam Schedule</h3>
                        </div>   
                        <div class="col-md-9">  
                        </div></div>

                    <?php
                    if (@$text) {
                        ?>
                        <div class="row">
                            <div class="alert messages alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php echo $text; ?>
                            </div> </div>
                    <?php }
                    ?> 
                </div>
                <br>
                <br>



                <br>

                <div class="row">

                    <form class="form-inline " method="post" id="exam_add_datesheet_form_id">
                        <input type="hidden" name="exam_add_datesheet_form" value="xxx" />
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <input type="hidden" name="year" value="<?= $oCurrentUser->mysession ?>" />
                        <!--<input type="hidden" name="exam_add_datesheet_form" value="xxx" />-->
                        <div class="col-md-6">  <div class="col-md-6">

                                <label for="exampleInputName2">Select Class<span style="color:red">* </span>: </label>  

                            </div> 
                            <div class="col-md-6">
                                <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                    <?php
                                    if ($oCurrentUser->ulevel == 9) {
                                        foreach ($classs as $class) {
                                            if (@$selected_class == $class['class_no']) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                <?= $class['class_name']; ?>
                                            </option>
                                            <?php
                                        }
                                    } else {
                                        foreach ($teach_classes as $class_id => $class_name) {
                                            if (@$selected_class == $class_id) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $class_id ?>" <?= $selected ?> > <?= $class_name ?> </option>
                                            <?php
                                        }
                                    }
                                    if (@$selected_class || @$selected_class != NULL) {
                                        
                                    } else {
                                        ?>
                                        <option value="" selected="selected" >
                                            Select Class
                                        </option>
                                    <?php } ?>
                                </select>
                            </div> 
                            <?php
                            if (@$selected_class || @$selected_class != NULL) {
                                ?>  <?php
                                if ($oCurrentSchool->section > 1) {
                                    ?>

                                    <div class="col-md-6"> 
                                        <label for="exampleInputName2">Select Section<span style="color:red">* </span> : </label></div>

                                    <div class="col-md-6"> 
                                        <select id="section_id" name="section_id" class="form-control wth_div" >
                                            <?php
                                            while ($row = $sectiondet->fetch(PDO::FETCH_OBJ)) {
                                                $sections = Master::get_schools_section($MSID, $row->section);
                                                ?>
                                                <b> Select Class : - </b>
                                                <?php
                                                if ($oCurrentUser->ulevel == 9) {
                                                    foreach ($sections as $section) {
                                                        if (@$selected_section == $section['section_id']) {
                                                            $selected = 'selected = "selected"';
                                                        } else {
                                                            $selected = "";
                                                        }
                                                        ?>
                                                        <option value="<?= $section['section_id']; ?>" <?= $selected ?> ><?= $section['sec_name']; ?></option>
                                                        <?php
                                                    }
                                                } else {
                                                    foreach ($teach_sections as $section_id => $section_name) {
                                                        if (@$selected_section == $section_id) {
                                                            $selected = 'selected = "selected"';
                                                        } else {
                                                            $selected = "";
                                                        }
                                                        ?>
                                                        <option value="<?= $section_id ?>" <?= $selected ?> ><?= $section_name ?></option>
                                                        <?php
                                                    }
                                                }
                                            } if (@$selected_section == NULL) {
                                                ?> <option value="" selected="selected" >
                                                    Select Section
                                                </option> 
                                                <?php
                                            } else {
                                                
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <?php
                                } else if ($oCurrentSchool->section < 2) {
                                    ?>
                                    <input type="hidden" name="section_id" value="1">
                                <?php } ?>

                                <div class="col-md-6">

                                    <label for="exampleInputName2">Select Assessment<span style="color:red">* </span> : </label>

                                    <?php //print_r($assesments);                       ?>

                                </div><div class="col-md-6"> <?php // print_r($assesments);                     ?>
                                    <select id="assesment" name="assesment" class="form-control wth_div "  onchange='this.form.submit()' >

                                        <?php
                                        if (@$selected_assesment) {
                                            ?><option value=""  >
                                                All Assessment
                                            </option> 
                                            <?php
                                        } else {
                                            ?><option value=""  selected = "selected" >
                                                All Assessment
                                            </option> 
                                            <?php
                                        }
//                                            print_r($assesments);
                                        foreach ($assesments as $assesment) {
                                            if ($selected_assesment == $assesment['assesment_id']) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                                <?= $assesment['title']; ?>
                                            </option>
                                        <?php } ?>

                                    </select>
                                </div>

                                <?php
                                if ($selected_class > 10) {
                                    ?> <div class="col-md-6">

                                        <label for="exampleInputName2">Stream<span style="color:red">* </span> : </label>

                                    </div>  
                                    <div class="col-md-6" >

                                        <select class="form-control wth_div" id="stream" name="stream" onchange='this.form.submit()'>
                                            <option value="">Select </option>
                                            <?php
                                            $stream = SuperAdmin::get_stream($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($stream as $streams) {
                                                if ($selected_stream == $streams['stream']) {
                                                    $selected = 'selected="selected"';
                                                } else {
                                                    $selected = '';
                                                }
                                                ?>
                                                <option value="<?= $streams['stream'] ?>" <?= $selected ?>><?= $streams['stream'] ?></option>

                                            <?php } ?>
                                        </select>

                                    </div> 
                                <?php }
                                ?>
                                <div class="col-md-6">

                                    <label for="exampleInputName2">Select Subjects<span style="color:red">* </span> : </label>

                                </div>
                                <div class="col-md-6">
                                    <select id="subjects" name="sub_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                        <?php
                                        $i = 0;
                                        if (@$selected_subjects) {
                                            ?><option value="">
                                                All Subjects
                                            </option> 
                                            <?php
                                        } else {
                                            ?><option value=""  selected = "selected" >
                                                All Subjects
                                            </option> 
                                            <?php
                                        }
                                        if ($oCurrentUser->ulevel == 9) {
                                            foreach ($subjects as $subject) {
                                                if ($selected_subjects == $subject->subject_id) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $subject->subject_id; ?>" <?= $selected ?> >
                                                    <?= $subject->name ?>
                                                </option>
                                                <?php
                                                $i++;
                                            }
                                        } else {
                                            foreach ($teach_subjects as $subject_id => $subject_name) {
                                                if ($selected_subjects == $subject_id) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $subject_id ?>" <?= $selected ?> > <?= $subject_name ?> </option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>

                                <?php
                                if (@$selected_subjects && @$selected_assesment) {
                                    if ($oCurrentSchool->activity == "1") {
                                        ?>
                                        <div class="col-md-6">
                                            <label for="exampleInputName2">Select Activities<span style="color:red">* </span> : </label>

                                            <?php //print_r($activityes);                            ?>

                                        </div><div class="col-md-6">
                                            <select id="activity" name="activity" class="form-control  wth_div"  onchange='this.form.submit()' >

                                                <?php
                                                //print_r($activityes);
                                                foreach ($activityes as $activitye) {

                                                    $activiy_name = Exam::get_student_academic_activity($MSID, $activitye->activity_id)->fetch();

                                                    if (@$selected_activity == $activitye->activity_id) {
                                                        $selected = 'selected = "selected"';
                                                    } else {
                                                        $selected = "";
                                                    }
                                                    ?>
                                                    <option value="<?= $activitye->activity_id; ?>" <?= $selected ?> >
                                                        <?= $activiy_name['name']; ?>
                                                    </option>
                                                <?php } ?>

                                            </select> </div>

                                        <?php
                                    }
                                    ?>



                                    <?php
                                }
                                ?>

                                <!-- \col -->

                                <div class="row"> 
                                    <div class="col-md-6"> </div>
                                    <div class="col-md-6" style="margin-top: 10px">
                                        <button value="test" name="exam_add_performance" class="btn btn-lg btn-success btn-block">Add Marks</button> 


                                    </div>
                                </div>

                                <?php
                            }
                            ?>

                        </div>
                        <div class="col-md-6">
                            <div class="col-md-6">

                                <label>Exam Date</label>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="exam_date" id="attendance_date_id" value="<?= (@$_POST['exam_date']) ? $_POST['exam_date'] : "" ?>" class="form-control  exam_date"/>
                            </div>
                            <div class="col-md-6">

                                <label>Max Marks <span style="color:red">* </span></label>
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" type="text" name="max_marks" id="max_marks" value="<?php
                                if (@$_POST['max_marks']) {
                                    echo $_POST['max_marks'];
                                } else {
                                    if (@$assesment_detail->max_marks > 0) {
                                        echo $assesment_detail->max_marks;
                                    } else {
                                        echo "";
                                    }
                                }
                                ?>" />

                            </div>
                            <div class="col-md-6">
                                <label>Passing Marks</label>
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" type="text" name="pasing_marks" id="max_marks" value="<?php echo (@$_POST['pasing_marks']) ? $_POST['pasing_marks'] : "" ?>" />
                            </div>
                            <?php
                            if (@$selected_subjects) {
                                ?>
                                <div class="col-md-6">
                                    <label>Start Time</label>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group bootstrap-timepicker timepicker">
                                        <input name="start_time"  value="<?php echo (@$_POST['start_time']) ? $_POST['start_time'] : "" ?>" type="text" class="form-control timepicker2">
                                        <div class="input-group-addon">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>End Time</label>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group bootstrap-timepicker timepicker">
                                        <input name="end_time" value="<?php echo (@$_POST['end_time']) ? $_POST['end_time'] : "" ?>" type="text" class="form-control timepicker2">
                                        <div class="input-group-addon">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>

                        </div>
                    </form>
                </div>




            </div>
            <!-- /.box -->
        </div> 
    </div>
</section>
<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        // For Datepicker
         $('.exam_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		clearBtn: true
		});
    
		$('.timepicker2').timepicker();
		     $('.morks_obtained').blur(function(){
//  alert('s');       
   var marks = $(this).val();
        var max_marks =$(this).data('id');
          if (marks <= max_marks) {
                    $(this).removeClass('error');
                } else {
   $(this).addClass('error');
                }
              
   });
      $('#btn_submit_id').click(function () { 
           $('#error_div .errorDiv').remove();
                if ($(".morks_obtained").hasClass("error")) {
$("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');
              
                } else {
         $('#form_marks').submit();
//              alert(form_marks'sucess');  
    }
            });
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>

