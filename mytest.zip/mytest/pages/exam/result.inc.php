<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>      <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <!--//headder-->
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title">Result</h3>
                            <?php
//                            if (@$display == "1")
//                                {
                            ?>  
                            <!--<h3 class="box-title"><a href="<?php // echo CLIENT_URL . "/result"      ?>" type="button" class="btn bg-olive btn-flat margin" >Check Next Result</a></h3>-->
                            <?php // } ?>

                        </div>   
                        <div class="col-md-9">  
                        </div></div>
                    <?php
//                    if (@$text)
//                        {
//                        
                    ?>
                    <!--                        <div class="row">
                                                <div class="alert messages alert-danger alert-dismissable">
                                                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                                    //<?php echo $text; ?>
                                                </div> </div>-->
                    <?php
//}
//                    
                    ?> 
                </div>
                <br>
                <br>



                <br>

                <div class="row">
                    <form class="form-inline " method="post" id="exam_add_datesheet_form_id">
                        <input type="hidden" name="exam_add_datesheet_form" value="xxx" />
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <input type="hidden" name="year" value="<?= $oCurrentUser->mysession ?>" />
                        <!--<input type="hidden" name="exam_add_datesheet_form" value="xxx" />-->
                        <div class="col-md-6">  
                            <div class="col-md-6">

                                <label for="exampleInputName2">Select Class : </label>  

                            </div> 
                            <div class="col-md-6">
                                <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                    <?php
                                    foreach ($classs as $class)
                                        {
                                        if (@$selected_class == $class['class_no'])
                                            {
                                            $selected = 'selected = "selected"';
                                            }
                                        else
                                            {
                                            $selected = "";
                                            }
                                        ?>
                                        <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                            <?= $class['class_name']; ?>
                                        </option>
                                        <?php
                                        } if (@$selected_class || @$selected_class != NULL)
                                        {
                                        
                                        }
                                    else
                                        {
                                        ?>
                                        <option value="" selected="selected" >
                                            Select Class
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <?php
                            if (@$selected_class || @$selected_class != NULL)
                                {
                                ?>  <?php
                                if ($oCurrentSchool->section > 1)
                                    {
                                    ?>

                                    <div class="col-md-6"> 
                                        <label for="exampleInputName2">Select Section : </label></div>

                                    <div class="col-md-6"> 
                                        <select id="section_id" name="section_id" class="form-control wth_div" >
                                            <?php
                                            while ($row = $sectiondet->fetch(PDO::FETCH_OBJ))
                                                {
                                                $sections = Master::get_schools_section($MSID, $row->section);
                                                ?>
                                                <b> Select Class : - </b>
                                                <?php
                                                foreach ($sections as $section)
                                                    {
                                                    if (@$selected_section == $section['section_id'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>



                                                    <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                        <?= $section['sec_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
                                                } if (@$selected_section == NULL)
                                                {
                                                ?> <option value="" selected="selected" >
                                                    Select Section
                                                </option> 
                                                <?php
                                                }
                                            else
                                                {
                                                
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <?php
                                    }
                                else if ($oCurrentSchool->section < 2)
                                    {
                                    ?>
                                    <input type="hidden" name="section_id" value="1">
                                <?php } ?>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-6">

                                    <label for="exampleInputName2">Select Assesment : </label>

                                    <?php //print_r($assesments);                        ?>

                                </div><div class="col-md-6">
                                    <select id="assesment" name="assesment" class="form-control wth_div ">

                                        <?php
                                        foreach ($assesments as $assesment)
                                            {
                                            if ($selected_assesment == $assesment['assesment_id'])
                                                {
                                                $selected = 'selected = "selected"';
                                                }
                                            else
                                                {
                                                $selected = "";
                                                }
                                            ?>
                                            <option value="<?= $assesment['assesment_id']; ?>" <?= $selected ?> >
                                                <?= $assesment['title']; ?>
                                            </option>
                                        <?php } ?>

                                    </select>
                                </div>

                            </div>

                            <!-- \col -->

                            <div class="row"> 
                                <div class="col-md-9"> </div>
                                <div class="col-md-3" style="margin-top: 10px;">
                                    <button value="test" name="exam_add_performance" class="btn bg-olive btn-flat margin">Get Result</button> 


                                </div>
                            </div>

                            <?php
                            }
                        ?>

                </div>

                </form>


                <?php
                if ((@$selected_class || @$selected_class != NULL) && @$selected_assesment)
                    {

                    if (@$display == "1")
                        {
                        ?> <div class="box-body table-responsive no-padding"> 
                            <form class="form-inline " method="post" id="exam_add_academic_performance_formid">     
                                <input type="hidden" value="xxx" name="academic_performance_posted_form">
                                <input type="hidden" value="<?= $MSID ?> " name="MSID">
                                <?php
                                if ($ttlcount > 0)
                                    {
                                    ?> <table class="table table-hover">
                                        <tr>
                                            <th>Sr.No.</th>
                                            <th>Name  </th>
                                            <th>Max Marks  </th> 
                                            <th>Scored Marks  </th> 
                                            <th>Percentage </th>   
                                            <th>Grade </th>  
                                            <th>Rank </th>  
                                            <th>Result </th>  
                                            <th>Report </th> 

                                        </tr>
                                        <?php
                                        $i = 1;


                                        $data = Exam::get_performance($oCurrentUser->myuid, $selected_class, $selected_section, $selected_assesment);                                        
//                                        print_r($data);
                                        while ($rowv = $data->fetch())
                                            {
                                           
                                            $student = Student::get_students($oCurrentUser->myuid, 'all', $rowv['student_Id'])->fetch();


//                                        pr($rowv);
//                                        pr($student);
//                                        exit();
                                            ?>


                                            <tr>
                                                <td><?= $i ?></td>
                                                <td><?= $student['name']; ?></td>
                                                <td><?= $rowv['max_marks']; ?></td>
                                                <td><?= $rowv['MO']; ?></td>  
                                                <td><?php echo $percent = $rowv['percent']; ?></td>  

                                                <td><?php
                                                    $grades = Exam::get_exam_grades($MSID, $percent)->fetch();
                                                    echo $grades['grade'];
                                                    ?></td> 
                                                <td><?= $rowv['rank']; ?></td> 
                                                <td><?php
                                                    if ($percent > 30)
                                                        {
                                                        ?> Pass <?php
                                                        }
                                                    else
                                                        {
                                                        ?> Fail<?php } ?></td>  
                                                <td>-</td>  



                                            </tr> 
                                            <?php
                                            $i++;
                                            }
                                        ?>
                                    </table>   <?php
                                    }
                                else
                                    {
                                    echo '<div class="text-center margin">No records found.</div>';
                                    }
                                ?>
                                <!--<div class="row">-->

                                <!-- \col -->
                                <!--</div>-->
                            </form> </div>
                        <?php
                        }
                    else
                        {
                        ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-danger alert-dismissible">
                                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                    <!--<h4><i class="icon fa fa-ban"></i> Alert!</h4>-->
                                    No Result Found
                                </div>
                            </div></div>
                        <?php
                        }
                    }
                ?>   



            </div>

        </div>
        <!-- /.box -->
    </div> 
</div>
</section>
<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        // For Datepicker
         $('.exam_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		clearBtn: true
		});
    
		$('.timepicker2').timepicker();
		     $('.morks_obtained').blur(function(){
//  alert('s');       
   var marks = $(this).val();
        var max_marks =$(this).data('id');
          if (marks <= max_marks) {
                    $(this).removeClass('error');
                } else {
   $(this).addClass('error');
                }
              
   });
      $('#btn_submit_id').click(function () { 
           $('#error_div .errorDiv').remove();
                if ($(".morks_obtained").hasClass("error")) {
$("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');
              
                } else {
         $('#form_marks').submit();
//              alert(form_marks'sucess');  
    }
            });
      
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>

