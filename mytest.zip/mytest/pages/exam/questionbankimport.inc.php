<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12"> <?php $message = new Messages(); echo $message->display(); ?>
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title" >Import Question Bank</h3>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
<!--          <form method="post" action="" role="form">-->
              <form  method="post" id="attendance_form_id" enctype="multipart/form-data">
            <input type="hidden" name="MSID" value="<?= $MSID ?>" />
            <div class="box-body">
              <div class="row">
                <div class="col-md-8">
                  <div class="form-group">
                      <div class="col-md-4"><label>Download file format:<span class="text-red">*</span></label></div>
                      <div class="col-md-4"> <a href="<?= ASSETS_FOLDER?>/csv_file/ms_exam_question_bank.csv"><img src="<?= ASSETS_FOLDER?>/img/excel.png"   width="28" height="28"></a>  </div>
                 <br><br> </div></div>
                   <div class="col-md-8">
                  <div class="form-group">
                      <div class="col-md-4"><label>Upload File:<span class="text-red">*</span></label></div>
                      <div class="col-md-4">   <input type="file" name="file">   </div>
                  <br><br></div></div>
                 
                  
                <!-- \col -->
              </div>
              <!-- \row end -->
              <div class="row">
                <div class="col-md-3">
                  <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                </div>
                <!-- \col -->
              </div>
              <!-- \row end -->
            </div>
          </form>
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section><!-- Main content -->
                            
  