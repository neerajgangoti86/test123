<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"> Activities List</h3>
                    <h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal" data-target="#myModal">Add Activities</button></h3>


                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <?php
                    if ($totalrecords > 0) {
                        ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr No</th>
                                <th>Name</th>
                                <th>Action</th>
                            </tr>
                            <tbody>
                                <?php
                                $i = 1;
                                while ($rowv = $activityes->fetch()) {
                                    ?>
                                    <tr>

                                        <td><?= $i ?></td>
                                        <td><?= $rowv['name']; ?></td>
                                        <td>
                                            <?php
                                            $LINK = CLIENT_URL . '/exam-load/update_activities/' . $rowv['id'];
                                            $BTNS = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                            print_r($BTNS);
                                            ?>
                                            &nbsp; 
                                            <?php
                                            $LINK = CLIENT_URL . '/activities/delete/'.$rowv['id'];
                                            $BTNS = check_privlages(NULL, NULL, $LINK, $oCurrentUser->myuid, $MSID);
                                            print_r($BTNS);
                                            ?>
                                        </td>

                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </tbody>

                        </table>
                        <?php
                    } else {
                        echo '<div class="text-center margin">No records found.</div>';
                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
                    <?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Add Activities</h4>
                </div>
                <div class="modal-body">
                    <form method="post" action="" role="form" id="onajaxForm">
                        <input type="hidden" name="add_activities" value="true" />
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <div class="row">
                            <div class="col-md-12"><div class="row">
                                    <div class="col-md-12">

                                        <div class="form-group">
                                            <label>Name<span class="text-red">*</span></label>
                                            <input type="hidden" name="MSID" value="<?= $MSID ?>">
                                            <input type="text" name="name" size="30" class="form-control">
                                        </div>

                                    </div>
                                    <!-- \col -->
                                </div>
                            </div>
                            <!-- \col -->
                        </div>
                    </form>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="submit">Save changes</button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->

</section>

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
	 $('#myModal').on('click','#submit',function(){
	   var datastring = $("#onajaxForm").serialize();
	   $(".errorDiv").remove();
	   $.ajax({
			type: "POST", // type
			url: "$siteurl/exam-post", // request file
			data: datastring, // post data
			success: function (responseText) { // get the response
				
//   alert(responseText);
       responseText = $.trim(responseText);
				if (responseText != 'error') {
					location.reload(); 
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
				}
			}, // end success
			error: function (jqXHR, textStatus, errorThrown) {
				if (jqXHR.status == 500) {
					$("#onajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
				}
			}
		});
		// end
		return false;
	 });
	 	 //edit model
	 $('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>