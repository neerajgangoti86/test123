<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Grades List</h3>
                    <h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal" data-target="#myModal">Add Grade</button></h3>

                    <form class="form-inline right_ft column_hide_show" method="post">
                        <div class="btn-group">
                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                Select Columns 
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu"  aria-labelledby="dropdownMenu1">
                                <?php
                                foreach ($grade_array as $key => $val) {
                                    if (in_array($key, @$selected_columns_grades)) {
                                        $checked = "checked ='checked'";
                                    } else {
                                        $checked = "";
                                    }
                                    ?>
                                    <li>
                                        <input type="checkbox" value="<?= $key ?>"  name="column1[]" <?= $checked ?>><?= $val ?>
                                    </li> 
                                <?php } ?>
                                <li><button type="submit" name="columnsubmit" class="btn btn-block btn-sm btn-warning btn-flat">Submit</button></li>
                            </ul>
                        </div>
                    </form>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <?php if ($totalrecords > 0) { ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <?php if (!@$selected_columns_grades) { ?>
                                    <th>Route Name</th> 
                                    <th>Percent From</th>
                                    <th>Percent To</th>
                                    <th>5 Point Grade</th> 
                                    <th>Grade Point</th>
                                    <th>Classes</th>
                                    <?php
                                } else {

                                    if (in_array('grade', $selected_columns_grades)) {
                                        ?><th>Grade</th><?php } ?>
                                        <?php
                                        if (in_array('percent_from', $selected_columns_grades)) {
                                            ?><th>Percent From</th><?php } ?>
                                        <?php
                                        if (in_array('percent_to', $selected_columns_grades)) {
                                            ?><th>Percent To</th><?php } ?>
                                        <?php
                                        if (in_array('5_point_grade', $selected_columns_grades)) {
                                            ?><th>5 Point Grade</th><?php } ?>
                                        <?php
                                        if (in_array('grade_point', $selected_columns_grades)) {
                                            ?><th>Grade Point</th><?php } ?>
                                        <?php
                                        if (in_array('for_class', $selected_columns_grades)) {
                                            ?><th>Classes</th><?php } ?>

                                    <?php
                                }
                                ?>

                                <th>Action</th>
                            </tr>
                            <?php
                            $i = 1;
                            while ($rowv = $exam_grade->fetch()) {
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <?php if (!@$selected_columns_grades) { ?>

                                        <th><?= $rowv['grade']; ?></th>
                                        <th><?= $rowv['percent_from']; ?></th><th><?= $rowv['percent_to']; ?></th>
                                        <th><?= $rowv['5_point_grade']; ?></th>
                                        <th><?= $rowv['grade_point']; ?></th><th><?= $rowv['for_class']; ?></th>
                                        <?php
                                    } else {

                                        if (in_array('grade', $selected_columns_grades)) {
                                            ?><th><?= $rowv['grade']; ?></th><?php } ?>
                                                <?php
                                                if (in_array('percent_from', $selected_columns_grades)) {
                                                    ?><th><?= $rowv['percent_from']; ?></th><?php }
                                                ?>
                                            <?php
                                            if (in_array('percent_to', $selected_columns_grades)) {
                                                ?><th><?= $rowv['percent_to']; ?></th><?php } ?><?php
                                            if (in_array('5_point_grade', $selected_columns_grades)) {
                                                ?><th><?= $rowv['5_point_grade']; ?></th><?php } ?><?php
                                            if (in_array('grade_point', $selected_columns_grades)) {
                                                ?><th><?= $rowv['grade_point']; ?></th><?php } ?><?php
                                            if (in_array('for_class', $selected_columns_grades)) {
                                                ?><th><?= $rowv['for_class']; ?></th><?php } ?>
                                            <?php
                                        }
                                        ?>

                                    <td>
                                        <?php
                                        $LINK = CLIENT_URL . '/ajax-page-load/exam_grade/' . $rowv['id'];
                                        $BTNS = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                        print_r($BTNS);
                                        ?>
                                        &nbsp; 
                                        <?php
                                        $LINK = CLIENT_URL . '/exam-grades/del/' . $rowv['id'];
                                        $BTNS = check_privlages(NULL, NULL, $LINK, $oCurrentUser->myuid, $MSID);
                                        print_r($BTNS);
                                        ?>
                                </tr>
                                <?php
                                $i++;
                            }
                            ?>
                        </table>
                        <?php
                    } else {
                        echo '<div class="text-center margin">No records found.</div>';
                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
                    <?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Add Grades</h4>
                </div>
                <div class="modal-body">
                    <form method="post" action="" role="form" id="onajaxForm">
                        <input type="hidden" name="add_grade" value="true" />

                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <input type="hidden" name="type" value="exam_grade" />
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Grade</label>
                                        <input class="form-control" type="text" name="grade" id="grade" />
                                    </div>
                                </div>
                                <!-- \col --> 
                            </div><div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Percent From</label>
                                        <input class="form-control" type="text" name="percent_from" id="percent_from" />
                                    </div>
                                </div>
                                <!-- \col --> 
                            </div><div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Percent To</label>
                                        <input class="form-control" type="text" name="percent_to" id="percent_to" />
                                    </div>
                                </div>
                                <!-- \col --> 
                            </div><div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>5 Point Grade </label>
                                        <input class="form-control" type="text" name="5_point_grade" id="5_point_grade" />
                                    </div>
                                </div>
                                <!-- \col --> 
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Grade Point</label>
                                        <input class="form-control" type="text" name="grade_point" id="grade_point" />
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <input type="checkbox" class="checkbox"  id="selectall"> 
                                    </span>
                                    <label class="form-control" for="exampleInputName2">Classes</label>
                                </div>



                                <?php
                                $get_classes = Master::get_classes($MSID);
//print_r($get_classes);
                                while ($rowv = $get_classes->fetch(PDO::FETCH_ASSOC)) {
                                    ?><div class="col-md-4"><input type="checkbox"  class="checkbox1" value="<?= $rowv['class_no']; ?>" name="for_class[]"> <?= $rowv['class_name']; ?></div>

                                    <?php
                                }
                                ?>
                            </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="submit">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</div>
</section>

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {

	 $('#myModal').on('click','#submit',function(){
	   var datastring = $("#onajaxForm").serialize();
	   $(".errorDiv").remove();
	   $.ajax({
			type: "POST", // type
			url: "$siteurl/ajax-page-post", // request file
			data: datastring, // post data
			success: function (responseText) { // get the response
				
//   alert(responseText);
       responseText = $.trim(responseText);
				if (responseText != 'error') {
					location.reload(); 
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
				}
			}, // end success
			error: function (jqXHR, textStatus, errorThrown) {
				if (jqXHR.status == 500) {
					$("#onajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
				}
			}
		});
		// end
		return false;
	 });
	 	 //edit model
	 $('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
    $(document).ready(function () {
//        alert('');
        $('#selectall').click(function (event) {
            if (this.checked) {
                $('.checkbox1').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox1').each(function () {
                    this.checked = false;
                });
            }
        });
    });



</script>
<?php
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
  $('.column_hide_show li').on('click', function (event) {
        event.stopPropagation();
    });
});                                    
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>