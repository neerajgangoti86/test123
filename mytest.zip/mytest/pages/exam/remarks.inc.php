<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box"  id="celebs">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                     
                            <h3 class="box-title heading"> Remarks List</h3>
                        </div>   
                        <div class="col-md-9">
                            <form class="form-inline " method="post" id="remarks_form_id">
                                <input type="hidden" name="remarks_form" value="xxx" />
                                <div class="row">
                                    <div class="col-md-4"> 
                                        <label for="exampleInputName2">Select Class : </label>  
                                    </div> 
                                    <?php
                                    if (@$selected_class && $oCurrentSchool->section > 1)
                                        {
                                        ?>      <div class="col-md-4"> 
                                            <label for="exampleInputName2">Select Section : </label>  
                                        </div> 
                                    <?php } ?>
                                    <div class="col-md-4"> 
                                        <label for="exampleInputName2">Select Term : </label>  
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-4"> 
                                        <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                            <?php
                                            if ($oCurrentUser->ulevel == "9")
                                                {
                                                foreach ($classs as $class)
                                                    {
                                                    if (@$selected_class == $class['class_no'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                        <?= $class['class_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
                                                }
                                            else
                                                {
                                                foreach ($classes as $class_no => $class_name)
                                                    {
                                                    if (@$selected_class == $class_no)
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class_no ?>" <?= $selected ?> ><?= $class_name ?></option>
                                                    <?php
                                                    }
                                                }
                                                if (@$selected_class || @$selected_class != NULL)
                                                {
                                                
                                                }
                                            else
                                                {
                                                ?>
                                                <option value="" selected="selected" >
                                                    Select Class
                                                </option>
                                            <?php } ?>
                                        </select></div> 
                                    <?php
                                    if (@$selected_class && $oCurrentSchool->section > 1)
                                        {
                                        ?>   <div class="col-md-4"> 
                                            <select id="section_id" name="section_id" class="form-control wth_div"  onchange='this.form.submit()'>
                                                <?php
                                                $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
                                                while ($row = $sectiondet->fetch(PDO::FETCH_OBJ))
                                                    {
                                                    $sections = Master::get_schools_section($MSID, $row->section);
//                                        print_r($sections);
                                                    ?>
                                                    <b> Select Class : - </b>
                                                    <?php
                                                    foreach ($sections as $section)
                                                        {
                                                        if (@$selected_section == $section['section_id'])
                                                            {
                                                            $selected = 'selected = "selected"';
                                                            }
                                                        else
                                                            {
                                                            $selected = "";
                                                            }
                                                        ?>  <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                            <?= $section['sec_name']; ?>
                                                        </option>
                                                        <?php
                                                        }
                                                    } if (@$selected_section == NULL)
                                                    {
                                                    ?> <option value="" selected="selected" >
                                                        Select Section
                                                    </option> 
                                                    <?php
                                                    }
                                                else
                                                    {
                                                    
                                                    }
                                                ?>
                                            </select>
                                        </div> 
                                        <?php
                                        }
                                    else if ($oCurrentSchool->section < 2)
                                        {
                                        ?>
                                        <input type="hidden" name="section_id" value="1">
                                    <?php } ?>
                                    <?php
                                    if ($oCurrentSchool->no_of_term != '0')
                                        {
                                        ?>  <div class="col-md-4"> 
                                            <select id="term" name="term" class="form-control" onchange="this.form.submit()">
                                                <b> Select Term : - </b>

                                                <option value="1" <?php
                                                if (@$term_selected)
                                                    {
                                                    echo (@$term_selected == '1') ? 'selected = "selected"' : "";
                                                    }
                                                ?>>Term1</option>
                                                        <?php
                                                        if ($oCurrentSchool->no_of_term == '2')
                                                            {
                                                            ?>
                                                    <option value="2" <?php
                                                    if (@$term_selected)
                                                        {
                                                        echo ($term_selected == '2') ? 'selected = "selected"' : "";
                                                        }
                                                    ?>>Term2</option>
                                                            <?php
                                                            }
                                                        ?> 
                                                        <?php
                                                        if ($oCurrentSchool->no_of_term == '3')
                                                            {
                                                            ?>
                                                    <option value="2" <?php
                                                    if (@$term_selected)
                                                        {
                                                        echo ($term_selected == '2') ? 'selected = "selected"' : "";
                                                        }
                                                    ?>>Term2</option>
                                                    <option value="3" <?php
                                                    if (@$term_selected)
                                                        {
                                                        echo ($term_selected == '3') ? 'selected = "selected"' : "";
                                                        }
                                                    ?>>Term3</option>
                                                            <?php
                                                            }
                                                        ?>   

                                            </select> </div> 
                                    <?php } ?>
                                </div>





                            </form>


                        </div>
                    </div>



                </div>
                <!-- /.box-header -->


                <?php
                if (((@$selected_class != NULL) && (@$term_selected != NULL)) && (@$selected_section != NULL || $oCurrentSchool->section < 2))
                    {
                    ?>
                    <div class="box-body table-responsive no-padding"> 
                        <?php // if ($totalrecords > 0) {         ?>
                        <form class="form-inline " method="post" id="remarks_form_id">
                            <input type="hidden" name="remarks" value="xxx" />
                            <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                            <input type="hidden" name="year" value="<?= $oCurrentUser->mysession ?>" />
                            <input type="hidden" name="section" value="<?= $selected_section ?>" />
                            <input type="hidden" name="term" value="<?= $term_selected ?>" />
                            <input type="hidden" name="class" value="<?= $selected_class ?>" />
                            <table class="table table-hover data">
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>Student Id  </th> 
                                    <th>Student Name </th>   
                                    <th>Remarks </th> 

                                </tr>
                                <?php
                                $i = 1;
                                while ($rowv = $students->fetch())
                                    {
                                    ?>
                                    <tr>
                                        <td><?= $i ?></td>
                                        <th><?= $rowv['student_id']; ?></th>
                                        <th><?= $rowv['name']; ?></th>  
                                        <?php
                                        $remark = Exam::get_exam_remarks($MSID, '', '', $rowv['student_id'], $_SESSION['year'], $term_selected, $selected_class)->fetch(PDO::FETCH_ASSOC);
                                        ?>
                                        <th>
                                            <input type="hidden" name="s_id[<?= $rowv['student_id']; ?>]">
                                            <input type="hidden" name="class" value="<?= $selected_class ?>">

                                            <?php
                                            if (empty($term_selected) && !isset($term_selected))
                                                {
                                                ?>

                                                <input type="hidden" name="term_id" value="0"/>
                                                <?php
                                                }
                                            else
                                                {
                                                ?>
                                                <input type="hidden" name="term_id" value="<?= $term_selected ?>"/>

                                                <?php
                                                }
                                            ?>
                                            <textarea rows="1" cols="50" name="remarks[]"><?= $remark['remark'] ?></textarea></th>



                                    </tr>
                                    <?php
                                    $i++;
                                    }
                                ?>
                            </table>
                            <!--<div class="row">-->
                            <div class="col-md-7">  </div> <div class="col-md-3">
                                <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                            </div> <div class="col-md-1"></div>
                            <!-- \col -->
                            <!--</div>-->
                        </form></div>
                <?php }
                ?>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>

<!--<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>-->
<script>
//   $(function(){
//    $('#celebs td:even').css('background-color','#dddddd');
//    
//    
//   });



</script>