<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title"> Consolidated data </h3>
                        </div>   
                        <form class="form-inline " method="post" id="exam_add_academic_performance_form_id">
                            <div class="col-md-3">

                                <input type="hidden" name="colsolidated_report" value="xxx" />
                                <label for="exampleInputName2">Select Class : </label>
                                <select id="class_id" name="class_id" class="form-control "  onchange='this.form.submit()' >

                                    <?php
                                    if (@$selected_class) {
                                        ?>
                                        <?php
                                    } else {
                                        ?><option value=""  selected = "selected" >
                                            Select Class 
                                        </option> 
                                        <?php
                                    }
                                    if ($oCurrentUser->ulevel == "9") {
                                        foreach ($classs as $class) {
                                            if (@$selected_class == $class['class_no']) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                <?= $class['class_name']; ?>
                                            </option>
                                            <?php
                                        }
                                    } else {
                                        foreach ($teach_classes as $class_no => $class_name) {
                                            if (@$selected_class == $class_no) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $class_no ?>" <?= $selected ?> ><?= $class_name ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <?php
                                if (@$selected_class) {
                                    ?>
                                    <label for="exampleInputName2">Subjects :
                                        <?php
//                                    echo "<pre>";
//                                    print_r($subjects);
//                                    echo "</pre>";
                                        ?> 
                                    </label>
                                    <select id="subjects" name="sub_id" class="form-control "  onchange='this.form.submit()' >

                                        <?php
                                        $i = 0;
                                        if (@$selected_subjects) {
                                            ?>
                                            <?php
                                        } else {
                                            ?><option value=""  selected = "selected" >
                                                Select Subject
                                            </option> 
                                            <?php
                                        }
                                        if ($oCurrentUser->ulevel == 9) {
                                            foreach ($subjects as $subject) {
                                                if ($selected_subjects == $subject->subject_id) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $subject->subject_id; ?>" <?= $selected ?> > <?= $subject->name ?> </option>
                                                <?php
                                                $i++;
                                            }
                                        } else {
                                            foreach ($teach_subjects as $subject_id => $subject_name) {
                                                if ($selected_subjects == $subject_id) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $subject_id ?>" <?= $selected ?> ><?= $subject_name ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                <?php } ?> </div>
                        </form>
                        <?php
                        if (@$selected_subjects && @$selected_class) {
                            ?>
                            <!-- /.box-header -->
                            <div class="row">
                                <div class="col-md-12">     
                                    <div class="box-body table-responsive no-padding">
                                        <br><br><br>
                                        <table border="1" width="812" align="center"  >
                                            <tr> 
                                                <td width="100%" height="180"><table width="100%" height="146" align="center" bordercolor="#2A3F00">
                                                        <tr align="left" valign="top">
                                                            <td width="799" height="140">
                                                                <table width="100%" align="center" cellpadding="2" cellspacing="2">
                                                                    <tr><td height="22" colspan="3" align="center"><span class="m1"><?= $oCurrentSchool->name ?></span></td> </tr>
                                                                    <tr>
                                                                        <td width="13%" align="center" valign="top"><img class="logo" src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" width="70" height="70"></td>
                                                                        <td width="56%" align="center" valign="top"><table width="98%" height="77" border="0" align="center">
                                                                                <tr>
                                                                                    <td width="376" height="40" align="center" ><span class="b1"><?= $oCurrentSchool->place ?></span></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td height="20" align="center" class="b1"><span class="t1"><?php
                                                                                            $board_data = Master::get_school_board($oCurrentSchool->board)->fetch();
                                                                                            echo $board_data['name'];
                                                                                            ?></span>
                                                                                    </td>
                                                                                </tr>

                                                                            </table>
                                                                            <br /> 
                                                                            <u>
                                                                                <br /><?php
                                                                                $class = Master::get_classes($MSID, '', '', '', $selected_class)->fetch(PDO::FETCH_OBJ);
                                                                                $subj = SuperAdmin::get_schoolwise_subject($MSID, $selected_subjects, array('selectAll' => 'true'))->fetch(PDO::FETCH_OBJ);
                                                                                ?>
                                                                                <span class="b1" align="Center">Consolidated Record Sheet for Class :<?= $class->class_name; ?> For Subject:  <?= $subj->name; ?> <br />
                                                                                    <br />
                                                                                </span>
                                                                            </u> 
                                                                        </td>
                                                                        <td width="31%" align="right" valign="top"><table width="98%" align="right"> 
                                                                                <tr>
                                                                                    <td align="center">Phone No:</td>
                                                                                    <td align="right" class="r"><strong><?= $oCurrentSchool->phone ?></strong></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td width="104" class="r">Affiliation No.:</td>
                                                                                    <td width="106" align="right" class="r"><strong><?= $oCurrentSchool->affNo ?></strong></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td class="r"> School Code :</td>
                                                                                    <td align="right"><span class="r"><strong><?= $oCurrentSchool->schoolNo ?></strong></span></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td><span class="r">Recognition No.:</span></td>
                                                                                    <td align="right"><strong class="r"><?= $oCurrentSchool->recNo ?></strong></td>
                                                                                </tr>
                                                                            </table></td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td height="22" colspan="3" align="center"><br /><form name="myform" method="post" action="../examination/Marks_SMS.php?c=<? echo $c; ?>">
                                                                                <table class="table">
                                                                                    <tbody>
                                                                                        <tr class="Top">
                                                                                            <td align="center"  colspan="2">Assessment</td>

                                                                                            <?php
                                                                                            $q1 = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES');
                                                                                            while ($rowv = $q1->fetch()) {
                                                                                                ?>       
                                                                                                <td align="center" colspan="2"><?= $rowv['title'] ?></td>
                                                                                            <?php } ?>

                                                                                        </tr>
                                                                                        <tr class="Top">

                                                                                            <td align="center" class="simple">Id</td>
                                                                                            <td align="center" class="simple">Name</td>
                                                                                            <?php
                                                                                            $q2 = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES');
                                                                                            while ($rowv1 = $q2->fetch()) {
                                                                                                ?>       
                                                                                                <td align="center" class="simple">M</td>
                                                                                                <td align="center" class="simple">G</td>

                                                                                            <?php } ?>
                                                                                        </tr>
                                                                                        <?php
                                                                                        $data = array(
                                                                                            'class' => $selected_class
                                                                                        );

                                                                                        $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
                                                                                        while ($rowv = $students->fetch()) {
                                                                                            ?>
                                                                                            <tr>
                                                                                                <td align="center" >
                                                                                                    <a class="style24" href="<?= CLIENT_URL ?>/students/<?= $rowv['student_id']; ?>"><?= $rowv['student_id']; ?></a> </td>

                                                                                                <td align="center" >
                                                                                                    <a class="style24" href="<?= CLIENT_URL ?>/students/<?= $rowv['student_id']; ?>"><?= $rowv['name']; ?></a> </td>

                                                                                                <?php
                                                                                                $q3 = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES');
                                                                                                while ($rowv1 = $q3->fetch()) {
                                                                                                    $marks_sql = Exam::get_accademinc_performance($MSID, '', $rowv1['assesment_id'], '', $selected_subjects, $selected_class, $rowv['student_id'], $_SESSION['year']);
                                                                                                    $marks = $marks_sql->fetch();
                                                                                                    $grade_calculater = Exam::exam_grade_calculater($MSID, $rowv['student_id'], $rowv1['assesment_id'], $selected_subjects);
                                                                                                    $grade = $grade_calculater->fetch();
                                                                                                    ?>  
                                                                                                    <td align="center" ><a href="">

                                                                                                            <?= $marks['marks_obtained'] ?></a></td>
                                                                                                    <td align="center" ><a href="">
                                                                                                            <?= $grade['Grade'] ?></a></td>  
                                                                                                <?php } ?>
                                                                                            </tr>
                                                                                        <?php } ?>
                                                                                    </tbody>
                                                                                </table>
                                                                            </form>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php }
                        ?>

                    </div>
                </div>
                <!-- /.box-header -->



            </div>
            <!-- /.box -->
        </div>
    </div></section>
