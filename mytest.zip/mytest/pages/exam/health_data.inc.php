<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title"> Health Data List</h3>
                        </div>  
                        <div class="col-md-9">                   

                            <form class="form-inline " method="post" id="exam_add_health_data_form_id">
                                <input type="hidden" name="exam_add_health_data_form" value="xxx" />
                                <div class="row">
                                    <div class="col-md-4"> 
                                        <label for="exampleInputName2">Select Class : </label>  
                                    </div>  
                                    <?php
                                    if (@$selected_class && $oCurrentSchool->section > 1)
                                        {
                                        ?>      <div class="col-md-4"> 
                                            <label for="exampleInputName2">Select Section : </label>  
                                        </div> 
                                    <?php } ?>
                                    <div class="col-md-4"> 
                                        <label for="exampleInputName2">Select Term : </label>  
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="col-md-4"> 
                                        <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >

                                            <?php
                                              if ($oCurrentUser->ulevel == "9")
                                                {
                                                foreach ($classs as $class)
                                                    {
                                                    if (@$selected_class == $class['class_no'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                        <?= $class['class_name']; ?>
                                                    </option>
                                                    <?php
                                                    }
                                                }
                                            else
                                                {
                                                foreach ($classes as $class_no => $class_name)
                                                    {
                                                    if (@$selected_class == $class_no)
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $class_no ?>" <?= $selected ?> ><?= $class_name ?></option>
                                                    <?php
                                                    }
                                                }
                                             
                                                if (@$selected_class || @$selected_class != NULL)
                                                {
                                                
                                                }
                                            else
                                                {
                                                ?>
                                                <option value="" selected="selected" >
                                                    Select Class
                                                </option>
                                            <?php } ?>
                                        </select></div> 
                                    <?php
                                    if (@$selected_class && $oCurrentSchool->section > 1)
                                        {
                                        ?>   <div class="col-md-4"> 
                                            <select id="section_id" name="section_id" class="form-control wth_div"  onchange='this.form.submit()'>
                                                <?php
                                                $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
                                                while ($row = $sectiondet->fetch(PDO::FETCH_OBJ))
                                                    {
                                                    $sections = Master::get_schools_section($MSID, $row->section);
//                                        print_r($sections);
                                                    ?>
                                                    <b> Select Class : - </b>
                                                    <?php
                                                    foreach ($sections as $section)
                                                        {
                                                        if (@$selected_section == $section['section_id'])
                                                            {
                                                            $selected = 'selected = "selected"';
                                                            }
                                                        else
                                                            {
                                                            $selected = "";
                                                            }
                                                        ?>  <option value="<?= $section['section_id']; ?>" <?= $selected ?> >
                                                            <?= $section['sec_name']; ?>
                                                        </option>
                                                        <?php
                                                        }
                                                    } if (@$selected_section == NULL)
                                                    {
                                                    ?> <option value="" selected="selected" >
                                                        Select Section
                                                    </option> 
                                                    <?php
                                                    }
                                                else
                                                    {
                                                    
                                                    }
                                                ?>
                                            </select>
                                        </div> 
                                        <?php
                                        }
                                    else if ($oCurrentSchool->section < 2)
                                        {
                                        ?>
                                        <input type="hidden" name="section_id" value="1">
                                    <?php } ?>
                                    <?php
                                    if ($oCurrentSchool->no_of_term != '0')
                                        {
                                        ?>  <div class="col-md-4"> 
                                            <select id="term" name="term" class="form-control" onchange="this.form.submit()">
                                                <b> Select Term : - </b>

                                                <option value="1" <?php
                                                if (@$term_selected)
                                                    {
                                                    echo (@$term_selected == '1') ? 'selected = "selected"' : "";
                                                    }
                                                ?>>Term1</option>
                                                        <?php
                                                        if ($oCurrentSchool->no_of_term == '2')
                                                            {
                                                            ?>
                                                    <option value="2" <?php
                                                    if (@$term_selected)
                                                        {
                                                        echo ($term_selected == '2') ? 'selected = "selected"' : "";
                                                        }
                                                    ?>>Term2</option>
                                                            <?php
                                                            }
                                                        ?> 
                                                        <?php
                                                        if ($oCurrentSchool->no_of_term == '3')
                                                            {
                                                            ?>
                                                    <option value="2" <?php
                                                    if (@$term_selected)
                                                        {
                                                        echo ($term_selected == '2') ? 'selected = "selected"' : "";
                                                        }
                                                    ?>>Term2</option>
                                                    <option value="3" <?php
                                                    if (@$term_selected)
                                                        {
                                                        echo ($term_selected == '3') ? 'selected = "selected"' : "";
                                                        }
                                                    ?>>Term3</option>
                                                            <?php
                                                            }
                                                        ?>   

                                            </select> </div> 
                                    <?php } ?>
                                </div>

                            </form></div>
                    </div>
                </div>
                <!-- /.box-header -->


                <?php
                if (((@$selected_class != NULL) && (@$term_selected != NULL)) && (@$selected_section != NULL || $oCurrentSchool->section < 2))
                    {
                    ?>
                    <div class="box-body table-responsive no-padding"> 
                        <form class="form-inline " method="post" id="exam_add_health_data_formid">     
                            <input type="hidden" value="xxx" name="health_data_posted_form">
                            <input type="hidden" value="<?= $MSID ?> " name="MSID">
                            <input type="hidden" name="year" value="<?= $oCurrentUser->mysession ?>" />
                            <input type="hidden" name="section" value="<?= $selected_section ?>" />
                            <input type="hidden" name="term" value="<?= $term_selected ?>" />
                            <input type="hidden" name="class" value="<?= $selected_class ?>" />
                            <table class="table table-hover tablesorter">
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>Student Id  </th> 
                                    <th>Student Name </th>   
                                    <th>Height(cm) </th> 
                                    <th>Weight(kg) </th> 
                                    <th>Action </th> 

                                </tr>
                                <?php
                                $i = 1;
                                while ($rowv = $students->fetch())
                                    {
                                    ?>
                                    <tr>
                                        <td><?= $i ?></td>
                                        <th><?= $rowv['student_id']; ?></th>
                                        <th><?= $rowv['name']; ?></th>  
                                        <?php
                                        $existing_healths = Exam::get_exam_health_data($MSID, '', array('selectAll' => 'true'), $rowv['student_id'], $oCurrentUser->mysession, $term_selected);
                                        $totalrecord = $existing_healths->rowCount();
                                        if ($totalrecord > 0)
                                            {
                                            $existing_healths_data = $existing_healths->fetch(PDO::FETCH_ASSOC);
                                            }
                                        else
                                            {
                                            $existing_healths_data['height'] = "";
                                            $existing_healths_data['weight'] = "";
                                            }
                                        ?>
                                        <th><input type="text"  value="<?= @$existing_healths_data['height']; ?>" name="height[]" ></th> 
                                        <th><input type="text"  value="<?= @$existing_healths_data['weight']; ?>" name="weight[]" ></th>                      


                                        <th><input type="hidden"  value="<?= $rowv['student_id'] ?>" name="id[<?= $rowv['student_id'] ?>]" >

                                            <?php
                                            if ($totalrecord > 0)
                                                {
                                                ?>
                                                <a class="btn btn-danger btn-flat" data-title="Edit Health Data" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax-page-load/exam_health_data/<?php echo $rowv['student_id']; ?>/<?= $term_selected ?>/<?= $selected_class ?>/<?= $selected_section ?>">Edit Health Data</a>
                                                <?php
                                                }
                                            else
                                                {
                                                ?> <a class="btn btn-info btn-flat" data-title="Add Health Data" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax-page-load/exam_health_data/<?php echo $rowv['student_id']; ?>/<?= $term_selected ?>/<?= $selected_class ?>/<?= $selected_section ?>">Add Health Data</a>
                                            <?php } ?>   
                                        </th>
                                    </tr>
                                    <?php
                                    $i++;
                                    }
                                ?>
                            </table>
                            <!--<div class="row">-->
                            <div class="col-md-7">  </div> <div class="col-md-3">
                                <button type="submit" name="exam_add_health_data" class="btn btn-lg btn-success btn-block">Submit</button>
                            </div> <div class="col-md-1"></div>
                            <!-- \col -->
                            <!--</div>-->
                        </form> </div>
                <?php } ?>
            </div>
            <!-- /.box -->
        </div>
    </div></section>

<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        
       $('.tablesorter').tablesorter();
  

	 $('#myModal').on('click','#submit',function(){
	   var datastring = $("#onajaxForm").serialize();
	   $(".errorDiv").remove();
	   $.ajax({
			type: "POST", // type
			url: "$siteurl/ajax-page-post", // request file
			data: datastring, // post data
			success: function (responseText) { // get the response
				
//   alert(responseText);
       responseText = $.trim(responseText);
				if (responseText != 'error') {
					location.reload(); 
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
				}
			}, // end success
			error: function (jqXHR, textStatus, errorThrown) {
				if (jqXHR.status == 500) {
					$("#onajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
				}
			}
		});
		// end
		return false;
	 });
	 	 //edit model
	 $('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
  });
        
 
           
 
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>