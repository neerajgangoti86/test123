<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title"> GradeWise List</h3>
                        </div>   
                        <div class="col-md-9">

                        </div>
                    </div>
                </div>
                <!-- /.box-header -->

                <table width="100%">
                    <tr>
                        <td background="../../images/pattern6.png" style="background-repeat:repeat; border-radius:5px 5px 0px 0px" width="100%" align="left"><table width="100%">
                                <tr>
                                    <td width="100%" align="center" valign="middle"><div class="session"><span class="style9"><strong>&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; Examination </strong></div><div align="right"><a href="exammodule.php">    <input class="back" type="button" value="Back" onClick="goBack()"></a> </div>

                                    </td>
                                </tr>
                            </table>   </td> 

                    </tr>
                    <tr> <td>  
                            <div id="justify" align="justify">
                                <table class="maintable" width="76%" align="center">
                                    <tr class="Tophead">
                                        <td colspan="7" align="center">Grade Wise List </td></tr>
                                    <tr class="Top">
                                        <td width="21%" align="center">Class</td>
                                        <td width="15%" align="center">A</td>
                                        <td width="20%" align="center">B</td>      
                                        <td width="15%" align="center">C</td>
                                        <td width="14%" align="center">D</td>
                                        <td width="15%" align="center">E</td>

                                    </tr>        
                                    <?php
                                    $Begins = "2015-04-01";
                                    $Ends = "2016-1-21";
                                    $ClassTo= "11";
                                    $sql_data = "Select QQ.CClass,QQ.MSID,QQ.section,Sum(IF(5_point_grade='A',1,0)) A,Sum(IF(5_point_grade='B',1,0)) B,Sum(IF(5_point_grade='C',1,0)) C,Sum(IF(5_point_grade='D',1,0)) D,Sum(IF(5_point_grade='E',1,0)) E From ( SELECT S.id,S.MSID,S.section,(S.`adm_classno`+".$_SESSION['year']."-Year(S.`fees_date`)+ COALESCE(SumResult,0)) AS CClass,PG.PointGrade,G.5_point_grade FROM ms_students S LEFT JOIN ( SELECT E.s_id,E.MSID, Sum(E.result) AS SumResult FROM ms_exams E WHERE (((E.MSID)=$MSID) AND ((E.date_result)<'$Begins')) GROUP BY E.s_id ) AS Q1 ON S.id = Q1.S_Id  And S.MSID =Q1.MSID LEFT JOIN (SELECT `student_id`,Round(sum(`marks_obtained`/`max_marks`*`overall_wtg`)/sum(`overall_wtg`)*100,2) PointGrade FROM `ms_exam_acedemic_performance` R LEFT JOIN ms_exam_weightage W ON R.MSID=W.MSID AND R.assesment_id=W.assesment_id WHERE `session`=".$_SESSION['year']." And R.MSID='$MSID' And W.MSID='$MSID' Group By R.student_id  ) AS PG ON PG.student_id=S.id Left Join ms_exam_grades G On PG.PointGrade BETWEEN G.`percent_from` AND G.`percent_to` WHERE S.MSID=$MSID  And S.fees_date<=".$_SESSION['user_date']." AND S.sl_date>".$_SESSION['user_date']." GROUP BY S.id, COALESCE(SumResult,0),S.section) QQ where CClass<='$ClassTo' And MSID='$MSID' Group By CClass,QQ.section";
                                    print_r($sql_data);                                    exit();      $oDb = DBConnection::get();
                                    $sql_data = $oDb->query($sql_data);

                                    while ($row = $sql_data->fetch()) {
//                                                                print_r($row);
                                        $CClass = $row['CClass'];
                                        $Section = $row['section'];
                                        $A = $row['A'];
                                        $B = $row['B'];
                                        $C = $row['C'];
                                        $D = $row['D'];
                                        $E = $row['E'];
                                        $sql_sec = "Select * from `ms_schools_section` where `MSID`='$MSID' And `section_id`='$Section'";
                                        $oDb = DBConnection::get();
                                        $sql_sec = $oDb->query($sql_sec); 

                                        while ($rowv = $sql_sec->fetch()) {
                                            $hs = $rowv['sec_name'];
                                        }
                                        ?>   
                                        <tr valign="top" >
                                            <td align="center"><?php
                                        ?>
                                                <a  target="_blank" href=""><?php
                                            $sql_sec_title = "select distinct class_name,class_no,MSID from `ms_classes` where  class_no='$CClass' And MSID='$MSID' order by class_no ASC ";
                                            $oDb = DBConnection::get();
                                            $sql_sec_title = $oDb->query($sql_sec_title);

                                            while ($rowu = $sql_sec_title->fetch()) {
                                                echo $rowu['class_name'] . ' ' . $hs;
                                            }
                                        ?></a>  
                                            </td>  
                                            <td align="center"><a href="classwisegradelist.php?cl=<?php echo $CClass; ?>&gr=<?php echo A; ?>"><?php echo $A; ?></a></td>
                                            <td align="center"><a href="classwisegradelist.php?cl=<?php echo $CClass; ?>&gr=<?php echo B; ?>"><?php echo $B; ?></a></td>
                                            <td align="center"><a href="classwisegradelist.php?cl=<?php echo $CClass; ?>&gr=<?php echo C; ?>"><?php echo $C; ?></a></td>
                                            <td align="center"><a href="classwisegradelist.php?cl=<?php echo $CClass; ?>&gr=<?php echo D; ?>"><?php echo $D; ?></a></td>
                                            <td align="center"><a href="classwisegradelist.php?cl=<?php echo $CClass; ?>&gr=<?php echo E; ?>"><?php echo $E; ?></a></td>
                                        </tr>
                                    <?php } ?>

                                </table>
                            </div> 
                        </td>
                    </tr>
                </table>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
