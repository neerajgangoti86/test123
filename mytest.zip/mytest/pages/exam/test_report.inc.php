<section class="content">
    <div class="row">
        <div class="col-xs-12"> 
            <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title"> Test Report </h3>
                        </div>   
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <div class="col-md-12">
                        <div class="row">
                            <hr>
                        </div>
                        <form method="post">
                            <div class="row">
                                <div class="col-md-3">

                                </div>
                                <div class="col-md-3 form-group text-aqua text-center text-capitalize">
                                    <h4>Select Class :</h4>
                                </div>
                                <div class="col-md-3 text-center form-group">
                                    <select class="form-control" name="ClassID" onchange="this.form.submit()">
                                        <option>Select Class</option>
                                        <?php
                                        while ($Class = $getClass->fetch()) {
                                            if (@$selectedClass == $Class['class_no']) {
                                                $selected = 'selected="selected"';
                                            } else {
                                                $selected = NULL;
                                            }
                                            ?>
                                            <option value="<?= $Class['class_no'] ?>" <?= $selected ?>><?= $Class['class_name'] ?></option>
                                        <?php }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-3">

                                </div>
                            </div>
                            <?php if (@$_POST['Class'] && $total_record > 0) { ?>
                                <div class="row">
                                    <div class="col-md-3">

                                    </div>
                                    <div class="col-md-3 form-group text-aqua text-center text-capitalize">
                                        <h4>Select Section :</h4>
                                    </div>
                                    <div class="col-md-3 text-center form-group">
                                        <select class="form-control" name="section">
                                            <option>Select Section</option>
                                            <?php
                                            while ($Section = $getSection->fetch()) {
                                                ?>
                                                <option value="<?= $Section['section_id'] ?>"><?= $Section['sec_name'] ?></option>
                                            <?php }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">

                                    </div>
                                </div>
                            <?php } ?>
                            <div class="row">
                                <div class="col-md-3">

                                </div>
                                <div class="col-md-3 form-group text-aqua text-center text-capitalize">
                                    <h4>Report Type :</h4>
                                </div>
                                <div class="col-md-3 text-center form-group">
                                    <select class="form-control" name="reportType" onchange="this.form.submit()">
                                        <option>Select Type</option>
                                        <option value="weekly" <?= @$rTypeW ?>>Weekly Test Record</option>
                                        <option value="monthly" <?= @$rTypeM ?>>Monthly Test Record</option>
                                    </select>
                                </div>
                                <div class="col-md-3">

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">

                                </div>
                                <div class="col-md-4 form-group text-aqua text-center text-capitalize">
                                    <!--<a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL ?>/" target="_blank">View Detailed Report</a>-->
                                </div>
                                <div class="col-md-4">

                                </div>
                            </div>
                        </form>
                        <?php if (@$_POST['reportType'] == 'monthly' || @$_POST['reportType'] == 'weekly') { ?>
                            <div class="row">
                                <hr>
                                <form method="post">
                                <div class="col-md-12">
                                    <ul class="nav nav-pills">
                                        <li class="dropdown">
                                            <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                                            <ul class="dropdown-menu">
                                                <li><a  href="javascript:void(0);" title="Export to Excel" onclick="$('#test_reports').tableExport({type: 'excel', escape: 'false'});"><img src="<?= ASSETS_FOLDER ?>/img/excel.png" title="export to excel" width="30" height="30"/></a></li>
                                                <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                                                    </a></li>
                                                <!--<li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>-->
                                        </li>

                                    </ul>
                                    </li>
                                    <li class="dropdown open">
                                        <button class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true" type="submit">
                                            <i class="fa fa-envelope-o"></i>
                                            SMS
                                        </button>
                                    </li>
                                    </ul>
                                </div>
                                    </form>
                                <?php
                                if (@$_POST['reportType'] == 'monthly') {
                                    $TestType = 'Monthly Test';
                                }
                                ?>
                                <?php
                                if (@$_POST['reportType'] == 'weekly') {
                                    $TestType = 'Weekly Test';
                                }
                                ?>
                                <div class="col-md-12 report_export" id="test_report">
                                    <table class="table table-hover" id="test_reports">
                                        <thead>
                                            <tr>
                                        <h1 class="text-center"><?= $TestType ?> Record Sheet</h1>
                                        <h4 class="text-center">for Class : <span class="text-green text-capitalize"><?= $forClass['class_name'] ?></span></h4>
                                        <h5 class="text-center">Date: <span class="text-aqua"><?= $StartDate ?></span> to <span class="text-aqua"><?= $EndDate ?></span></h5>
                                        </tr>
                                        <tr>
                                            <th colspan="3" class="" style="border-right: 1px solid #00a65a">Test Dates</th>
                                            <?php while ($Date = @$getDate->fetch()) { ?>
                                                <th colspan="2" class="text-center" ><?= $Date['Date'] ?></th>
                                            <?php } ?>
                                        </tr>
                                        <tr>
                                            <th colspan="3" class="" style="border-right: 1px solid #00a65a">Test Subjects</th>
                                            <?php
                                            $td = 0;
                                            while ($Subject = @$getSubject->fetch()) {
                                                $sub = Student::get_student_subject_detail($MSID, $Subject['SubjectId'])->fetch();
                                                ?>
                                                <th colspan="2" class="text-center" style="border-bottom: 1px solid"><?= $sub['name'] ?></th>
                                                <?php
                                                $td++;
                                            }
                                            ?>  
                                        </tr>
                                        <tr>
                                            <th>Sr No.</th>
                                            <th>ID</th>
                                            <th>NAME</th>
                                            <?php for ($i = 1; $i <= $td; $i++) { ?>
                                                <th class="text-green text-center" style="border-left: 1px solid">Marks</th>
                                                <th class="text-warning text-center">Grade</th>
                                            <?php } ?>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            while ($student = @$Student->fetch()) {
                                                $report = Student::get_student_test_report($MSID, $StartDate, $EndDate, $selectedClass, $student['student_id'], $oCurrentUser->mysession);
                                                //print_r($report);echo "<br>";
                                                ?>
                                                <tr>
                                                    <td><?= $i ?></td>
                                                    <td><?= $student['student_id'] ?></td>
                                                    <td><?= $student['name'] ?></td>
                                                    <?php while ($a = $report->fetch()) {
                                                        ?>
                                                        <td class="text-green text-center" style="border-left: 1px solid"><?= $a['MarksObtained'] ?></td>
                                                        <?php
                                                        $grades = Exam::get_exam_grades_by_marks($MSID, $selectedClass, (($a['MarksObtained'] / $a['MaxMarks']) * 100))->fetch();
                                                        ?>
                                                        <td class="text-warning text-center"><?php (@$a['MarksObtained']) ? print $grades['grade'] : " "; ?></td>
                                                    <?php } ?>
                                                </tr>
                                                <?php
                                                $i++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div><?php } ?>
                    </div>
                </div>
            </div><!-- /.box -->
        </div>
    </div>


    <?php
//************************SMS FUNCTION************************************//
    if (@$_POST) {
        $sent = "1";
//    pr($_POST['sms']);
        $sms_array = array();
        if (@$_POST['sms']) {

            foreach ($_POST['sms'] as $key => $val) {
                if (strlen($val) > 9) {
                    $sms_array[] = $val;
                }
            }
        }
        $dm = date("Y-m-d");

        $sms = SMS::get_sms_detail($MSID)->fetch(PDO::FETCH_OBJ);
//    pr($sms);

        $SenderID = $sms->SenderID;
        $UserName = $sms->UserName;
        $Pass = $sms->Pass;
//    $Default_no = $sms->Default_no;
        $Default_no = "8894054847";
//    $Default_no = "9041370797,8894054847";

        $num1 = implode(",", $sms_array);
        $num = $Default_no . ',' . $num1 . ',' . $_POST['num'];

        //  sds;dflgj;slkdfjg
//    print_r($num);
//    exit();
//    $num = "9041370797,8894054847";
        $message = $_POST['message'];
//    $template = $_POST['msg'];
        $sid = $oCurrentSchool->SMSSID;
        if ($message == '') {
            $msg = $template;
        } else {
            $msg = $message;
        }


//initialize the request variable
        $request = "sms.vmosms.com/submitsms.jsp?";
//this is the username of our TM4B account
        $param["user"] = "$UserName";
//this is the password of our TM4B account
        $param["key"] = "$Pass";
//this is the message that we want to send
        $param["mobile"] = "$num";
//this is the message that we want to send
        $param["message"] = "$msg";
//these are the recipients of the message
        $param["senderid"] = "$SenderID";
//this is our sender
        $param["accusage"] = "1";
//this is our sender
//traverse through each member of the param array
        foreach ($param as $key => $val) {
            //we have to urlencode the values
            $request.= $key . "=" . urlencode($val);
            //append the ampersand (&) sign after each paramter/value pair
            $request.= "&";
        }
//remove the final ampersand sign from the request
        $request = substr($request, 0, strlen($request) - 1);
        $handle = curl_init($request);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, TRUE);
        /* Get the HTML or whatever is linked in $url. */
        $response = curl_exec($handle);

        $data = array();

        $number = array();
        $sucess = array();

        $data = explode('sent', $response);
//    $data = explode('sent', "sent,success,305733060,1425864270,+919041370797 sent,success,362970071,1468911536,+918894054847 ");
        foreach ($data as $key => $val) {
            $number = explode(",", $val);
            if (@$number[1] == "success") {
                $sucess[] = $number[4];
            }
//        echo "The number is" . $number[4];
        }
//    curl_close($handle);
//    pr($sucess);
    } else {
        $sent = "0";
    }
    ?>



</section>
<style>
    .dropdown-toggle{
        border-bottom: 1px solid !important; 
    }
</style>
<script type='text/javascript'>
    function htmltopdf() {
        var pdf = new jsPDF('p', 'pt', 'a1');
        source = $('#test_report')[0];
        specialElementHandlers = {
            '#bypassme': function (element, renderer) {
                return true
            }
        };
        margins = {
            top: 10,
            bottom: 10,
            left: 10,
            width: 800
        };
        pdf.fromHTML(
                source,
                margins.left,
                margins.top, {
                    'width': margins.width,
                    'elementHandlers': specialElementHandlers
                },
                function (dispose) {
                    pdf.save('Download.pdf');
                }, margins);
    }

</script>
</script>
<?php
$sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
      //alert("hi");              
   $('.date_from').datepicker({ format: 'dd-mm-yyyy', todayHighlight: true, clearBtn: true});
   $('.date_from').on('changeDate', function(ev){
    $(this).datepicker('hide');
}) ;

	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});	
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
