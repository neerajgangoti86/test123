<?php if ($_POST['subject'] == 'Maths') { ?>
    <script type="text/x-mathjax-config">
        MathJax.Hub.Config({
        tex2jax: {
        displayMath: [['\(','\)']]
        }
        });
    </script>
    <script type="text/javascript" src="http://cdn.mathjax.org/mathjax/2.2-latest/MathJax.js?config=TeX-AMS_HTML"></script><?php } ?>
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<style type="text/css">

    .style190 {	color: #FFFFFF;

    }
    .style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

    .st3 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 16px;

    }.st2 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 18px;

    }
    .st4 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 13px;

    }
    .t1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 15px;
    }
    .m1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 22px;font-weight: 500;
    }
    .n1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 20px; 
    }
    table {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 20px; 
    }
    .b1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
    }
    .r {font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 11px;
    }
    .maintxt {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
    }
    .hide {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        color: #FFF;
    }.Q1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px;font-weight: bold;
    }.Q2 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;font-weight: bold;
    }
    p.page { page-break-after: always; }
</style>



<section class="content">
    <div class="row">
        <div class="col-md-12"> 
            <?php
            $message = new Messages();
            echo $message->display();
//            $stringlen = 0;

            $i = 0;
            $tno = 0;
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <!--                <div class="box-header">
                                    <h3 class="box-title" >
                Question paper generator
                                    </h3>
                                    <ul class="nav nav-pills">
                                        <li class="dropdown">
                                            <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                                            <ul class="dropdown-menu">
                                                <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                                                    </a></li>
                                                <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                                                </li>
                
                                            </ul>
                                        </li>
                                    </ul>
                                </div>-->
                <p class="page"></p>
                <div class="box-body table-responsive no-padding report_export" id="pdf_question">
                    <table width="750"  align="center" border="1">
                        <tr><td><table width="100%" align="right" style="border:1px solid #000;">
                                    <tr>
                                        <td colspan="4" align="center" class="m1">Class:  <?php $class = Master::get_class_names($MSID, $_POST['class_id'])->fetch(PDO::FETCH_OBJ); ?> <?= $class->class_name ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" align="center" class="m1"><span class="b1">Subject: <?= $_POST['subject'] ?></span></td>
                                    </tr>

                                    <tr>
                                        <td colspan="4" align="center" class="m1"><span class="b1">Examination:
                                            </span></td>
                                    </tr>

                                    <tr class="st2">
                                        <td colspan="4" align="center"  >Academic Session: <?php echo $oCurrentUser->mysession; ?> </td>
                                    </tr>
                                    <?php
                                    $class = $_POST['class_id'];
                                    $subject = $_POST['subject'];
                                    $chapter = implode("','", @$_POST['chapter']);
                                    $d_level = implode("','", @$_POST['d_level']);
                                    $sub_group = implode("','", @$_POST['sub_group']);
                                    $importance = implode("','", @$_POST['importance']);



                                    $format = QuestionBank:: get_paper_format($MSID, $_POST['class_id'], $_POST['subject']);
                                    while ($rows = $format->fetch()) {
                                        ?>
                                        <tr><td align="center" valign="top"><b><?php
                                                    $tno++;
                                                    echo $tno;
                                                    ?></b></td><td colspan="2"><b><?php
                                                    $q_type = QuestionBank::get_questions_options('ms_q_type', $MSID, $_POST['class_id'], $_POST['subject'], $rows ['ID'], $rows ['SUBSUBJECT'])->fetch();

                                                    echo $q_type['CAPTION'];
                                                    ?> 
                                                </b></td>  </tr>
                                        <?php
                                        //Match Previous Row
                                        $questionpaper = Exam::genrate_question_paper($MSID, $class, $subject, $chapter, $d_level, $sub_group, $importance, $rows ['ID'], $rows ['SUBSUBJECT']);
                                        $pre_row_number = "";
                                        $pre_row_num = "";
                                        $totalrecords = $questionpaper->rowCount();
                                        while ($rowv = $questionpaper->fetch()) {
                                            ?> 
                                            <tr class="n1">
                                                <?php
                                                $curr_row_num = $rowv['row_num'];
                                                $curr_row_number = $rowv['row_number'];
                                                $option = $rowv['OPTIONS'];
                                                if ($curr_row_number != "") {
                                                if (($pre_row_number != $curr_row_number) && ($pre_row_num != $curr_row_num)||($option==0)) {
                                                        ?>   <td width="57" align="center" valign="top"> <?php
                                                    
                                                           
                                                        if ($totalrecords > 1) {
                                                            echo $rowv['row_numbers'];
                                                          }
                                                        $pre_row_number = $curr_row_number;
                                                        $pre_row_num = $curr_row_num;
                                                        ?></td>
                                                        <?php } else { ?></tr><tr><td></td> <td width="57" align="center" valign="top"> <?php echo "OR"; ?>
                                                        
                                                      <?php //   $pre_row_number = $curr_row_number;
//                                                          $pre_row_num = $curr_row_num;
                                                            ?> </td><td></td></tr><tr><td></td>
                                                        <?php
                                                        }
                                                    }
                                                    ?></td> 
                                                <td width="576"> <?php
                                                    echo $question = $rowv['STATEMENT'];

//                                                    $string = strip_tags($question);
//                                                    $stringlen += (strlen($string));
                                                    ?> </td> 
                                                <td width="57" align="left"> <?= $rowv['MARKS'] ?>  </td> 
                                            </tr><?php
                                }
                            }
                                            ?>
                            </td> 
                        </tr>
                    </table> 
                    </td><tr></table>

                </div>
                <div class="col-md-12">
                    <div class="col-md-6 col-md-offset-3">
                        <div id="editor"></div>
                        <a class="btn" href="javascript:void(0);" onclick="javascript:htmltopdf();">Save Link</a>
                        <button id="savepaper" onclick="javascript:htmltopdf();">Save</button>
                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.1.135/jspdf.min.js"></script>
<!--<script type="text/javascript" src="http://cdn.uriit.ru/jsPDF/libs/adler32cs.js/adler32cs.js"></script>-->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2014-11-29/FileSaver.min.js"></script>
<script type='text/javascript'>
                            function htmltopdf() {
                                var pdf = new jsPDF('p', 'pt', 'a1');
                                source = $('#pdf_question')[0];
                                specialElementHandlers = {
                                    '#bypassme': function (element, renderer) {
                                        return true
                                    }
                                };
                                margins = {
                                    top: 10,
                                    bottom: 10,
                                    left: 10,
                                    width: 800
                                };
                                pdf.fromHTML(
                                        source,
                                        margins.left,
                                        margins.top, {
                                            'width': margins.width,
                                            'elementHandlers': specialElementHandlers
                                        },
                                        function (dispose) {
                                            pdf.save('Download.pdf');
                                        }, margins);
                            }

</script>




<script>
    $('.mobile').click(function () {
        var id = this.id;
        if ($('#' + id).is(":checked"))
        {
            $('#message' + id).prop('checked', true);
        } else {
            $('#message' + id).prop('checked', false);
        }
    });
    $('#checkall').click(function () {
        if ($('#checkall').is(":checked"))
        {
            $('.message, .mobile').prop('checked', true);
        } else {
            $('.message, .mobile').prop('checked', false);
        }
    });
</script>

