
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<style type="text/css">

    .style190 {	color: #FFFFFF;

    }
    .style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

    .st3 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 16px;

    }.st2 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 18px;

    }
    .st4 {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 13px;

    }
    .t1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 15px;
    }
    .m1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 22px;font-weight: 500;
    }
    .n1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
    }
    .b1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
    }
    .r {font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 11px;
    }
    .maintxt {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
    }
    .hide {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        color: #FFF;
    }.Q1 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px;font-weight: bold;
    }.Q2 {
        font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;font-weight: bold;
    }
</style>



<section class="content">
    <div class="row">
        <div class="col-md-12"> 
            <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title" >

                        Question paper generator
                    </h3>
                    <ul class="nav nav-pills">
                        <li class="dropdown">
                            <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                            <ul class="dropdown-menu">
                                <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                                    </a></li>
                                <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                                </li>

                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="box-body table-responsive no-padding report_export" id="fee_report"> 
                    <table width="769" border="0" align="center" id="fee_reports">
                        <tr>  
                            <td colspan="4" align="center"  class="st2"> <table width="757" height="60"  border="0" align="center">
                                    <tr>
                                        <td colspan="4" align="center" class="m1">Class:  <?= $_POST['class'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" align="center" class="m1"><span class="b1">Subject: <?= $_POST['subject'] ?></span></td>
                                    </tr>

                                    <tr>
                                        <td colspan="4" align="center" class="m1"><span class="b1">Examination: <?php
                                                if ($_POST['assesment'] == "1") echo "FA1";
                                                else if ($_POST['assesment'] == "2") echo "FA2";
                                                else if ($_POST['assesment'] == "3") echo "FA3";
                                                else if ($_POST['assesment'] == "4") echo "FA4";
                                                else if ($_POST['assesment'] == "5") echo "SA1";
                                                else if ($_POST['assesment'] == "6") echo "SA2";
                                                ?></span></td>
                                    </tr>

                                    <tr class="st2">
                                        <td colspan="4" align="center"  >Academic Session: <?php echo $oCurrentUser->mysession; ?> </td>
                                    </tr>
                                    <tr class="st2">
                                        <td width="53" align="left"  >Time:</td>
                                        <td width="127" align="left" ></td>
                                        <td width="326" align="center" >&nbsp;</td>
                                        <td width="233" align="right" >Total Marks:
                                        </td>
                                    </tr>
                                </table></td> 
                        </tr>
                        <tr>
                            <td colspan="4" align="center"  class="st2"> </td>
                        </tr>  

                        <tr>
                            <td colspan="4" align="left" class="st2">Instructions:</td>
                        </tr>
                        <?php
                        if (@$_POST['i1'])
                            {
                            $i1 = $_POST['i1'];
                            ?>
                            <tr>
                                <td align="left" class="st4"><span class="t1"><?php echo '1' + @$g; ?></span></td>
                                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $i1; ?></span></td>
                            </tr>
                            <?php
                            }
                        else
                            {
                            
                            }
                        ?>
                        <?php
                        if (@$_POST['i2'])
                            {
                            $i2 = $_POST['i2'];
                            ?>
                            <tr>
                                <td align="left" class="st4"><span class="t1"><?php echo '2' + @$g; ?></span></td>
                                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $i2; ?></span></td>
                            </tr>
                            <?php
                            }
                        else
                            {
                            
                            }
                        ?>
                        <?php
                        if (@$_POST['i4'])
                            {
                            $i3 = $_POST['i3'];
                            echo 'sad';
                            ?>
                            <tr>
                                <td align="left" class="st4"><span class="t1"><?php echo '3' + @$g; ?></span></td>
                                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $i3; ?></span></td>
                            </tr>
                            <?php
                            }
                        else
                            {
                            
                            }
                        ?>
                        <?php
                        if (@$_POST['i4'])
                            {
                            $i4 = $_POST['i4'];
                            ?>
                            <tr>
                                <td align="left" class="st4"><span class="t1"><?php echo '4' + @$g; ?></span></td>
                                <td colspan="3" align="left" class="st4"><span class="t1"><?php echo $i4; ?></span></td>
                            </tr>
                            <?php
                            }
                        else
                            {
                            
                            }
                        ?>




                        <tr>
                            <td colspan="4" class="st4">&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="4"   class="st2">Answer These Questions  </td>
                        </tr>
                        <?php
                        $i = 1;
                        foreach ($_POST['ques'] as $key => $val)
                            {
                            if ($key == 0)
                                {
                                $ids = $val;
                                }
                            else
                                {
                                $ids = $ids . "," . $val;
                                }
                            }

                        $data = QuestionBank::get_exam_distinct_questions($MSID, $_POST['class'], $_POST['subject'], $ids);
                        while ($row = $data->fetch())
                            {
                            ?>
                            <?php
                            echo '<br>';
                            ?>
                            <tr>
                                <td colspan="2" class="st2"><?php echo 'Q' . $i; ?></td>
                                <td width="681" class="st2"><?php echo $row['qheading']; ?></td>
                                <td width="29" class="st2"><?php // echo $row['Marks'] . '<br>';                ?></td>
                            </tr>
                            <?php
                            $data_all = QuestionBank::get_exam_question_for_genrater($MSID, $_POST['class'], $_POST['subject'], $ids, $row['qheading']);
                            $j = 1;
                            while ($row_all = $data_all->fetch())
                                {
                                ?>
                                <tr>
                                    <td class="st4">&nbsp;</td>
                                    <td width="20" class="st4"><?php echo $j . '<br>'; ?></td>
                                    <td class="st4"><?php
                                        echo strip_tags($row_all['question']) . '<br>';
                                        ?></td>
                                    <td class="st4">&nbsp;<?php echo $row_all['marks']; ?></td>
                                </tr> <?php
                                $j++;
                                }
                            $i++;
                            ?>
                        <?php } ?>
                        <?php
                        ?>

                    </table> 
                </div></div>
            <!-- /.box -->
        </div>
    </div>
</section>












<script type='text/javascript'>
    function htmltopdf() {
        var pdf = new jsPDF('p', 'pt', 'a1');
        source = $('#reg_reports')[0];
        specialElementHandlers = {
            '#bypassme': function (element, renderer) {
                return true
            }
        };
        margins = {
            top: 10,
            bottom: 10,
            left: 10,
            width: 800
        };
        pdf.fromHTML(
                source,
                margins.left,
                margins.top, {
                    'width': margins.width,
                    'elementHandlers': specialElementHandlers
                },
                function (dispose) {
                    pdf.save('Download.pdf');
                }, margins);
    }

</script>





