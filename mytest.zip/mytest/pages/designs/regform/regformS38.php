<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<script language="javascript">
    function printpage()
    {
        window.print();
    }
</script><section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
//                print_r($student);
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                ?>
                <form id="contactform" name="contactform" method="post" action="admin.php">
                    <table width="700" background="../../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
                        <tr>
                            <td width="100%">
                                <table width="698" height="794" align="center" bordercolor="#2A3F00" background="<?= ASSETS_FOLDER ?>/img/svnlogo.png" style="background-size:60%; background-repeat:no-repeat; background-position:center" >
                                    <tr align="left" valign="top">
                                        <td width="652" height="161">
                                            <table width="707" border="0" align="center" cellpadding="2" cellspacing="2">
                                                <tr>
                                                    <td width="699">
                                                        <table width="699" height="105" border="0" align="center">

                                                            <tr>
                                                                <td width="693" height="23" colspan="3" align="center" valign="baseline">
                                                                    <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
                                                            </tr>


                                                        </table></td>
                                                </tr>
                                            </table>







                                        </td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="4" align="left"><hr/></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="220"><table width="100%" height="46" border="0" align="left">
                                                <tr valign="top" class="st4">
                                                   <td width="34" align="left" valign="top"><img    src="<?php
                                                        if ($student->std_image != "") {
                                                            echo $student->std_image;
                                                        } else {
                                                            echo ASSETS_FOLDER . "/img//myprofile1.png";
                                                        }
                                                        ?>" width="105" height="117">



                                                    </td>
                                                    <td width="623" height="42"><table width="100%" height="212" border="0" align="center">
                                                            <tr valign="top" class="st4">
                                                                <td height="49" colspan="3" class="style15"><?= $student->name; ?> <br />                      <br /></td>
                                                            </tr>
                                                            <tr valign="top" class="st4">
                                                                <td width="28%" height="36"><?php if ($oCurrentSchool->ViewOption != '1') { ?>Student&nbsp;Id:&nbsp;&nbsp;<strong><?= $student->student_id; ?></strong><?php } else { ?>Admission No:<strong><?= $student->admno; ?></strong><?php } ?></td>
                                                                <td width="39%">Admission class:<strong>
<?php echo $student->adm_class_name;
?>
                                                                    </strong></td>
                                                                <td width="33%">Date of Birth:<strong>
<?php
$DateOfBirth = $student->birth_date;
echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
?>
                                                                    </strong></td>
                                                            </tr>
                                                            <tr valign="top" class="st4">
                                                                <td height="36">Category:&nbsp;&nbsp;&nbsp;&nbsp;<strong>
<?= $student->Category_short; ?>
                                                                    </strong></strong></td>
                                                                <td height="36">Admission Date:<strong>
                                                                <?php
                                                                $AdmDate = $student->adm_date;
                                                                echo $new_dat1e = date('d-m-Y', strtotime($AdmDate));
                                                                ?>
                                                                    </strong></td>
<?Php if ($oCurrentSchool->section > '1') { ?>   <td height="36">Section:<strong>&nbsp;&nbsp;&nbsp;&nbsp;
    <?=
    $student->sec_name;
    ?>  <?php } ?></td>
                                                            </tr>
                                                            <tr valign="top" class="st4">
                                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                                        <?Php if ($oCurrentSchool->house > '0') { ?>   <td height="36">House:<strong>&nbsp;&nbsp;&nbsp;&nbsp;
    <?=
    $student->house;
    ?>
                                                            <?php } ?>

                                                                    </strong></td>
                                                            </tr>
<?php // if ($student->class > 10) { ?>
                                                                <tr valign="top" class="st4">
                                                                    <td height="28">Stream:<strong>
                                                                <?php // $stream = SuperAdmin::get_stream($student->stream)->fetch(PDO::FETCH_OBJ); ?>          <?php //echo $stream->stream; ?>
                                                                        </strong></td>
                                                                   
                                                                    <td height="28">Subject Group:<strong>
    <?php ?>
                                                                        </strong></td>
                                                                </tr>
<?php // } else {
    
//} ?>
                                                        </table></td>
                                                </tr>
                                            </table></td>
                                    </tr> 

                                    <tr align="left" valign="top">
                                        <td height="211"><table width="677" height="221" border="0" align="center">
                                                <tr valign="top" class="b1">
                                                    <td height="49" colspan="2" align="center"><u>Father's Info:</u>
                                                    </td>
                                                    <td colspan="2" align="center"><u>Mother's Info:</u></td>
                                                </tr>

                                                <tr valign="top">
                                                    <td width="93" height="27"><span class="st4">Name </span></td>
                                                    <td width="283"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;Mr. <?= $student->f_name; ?></strong></span></td>
                                                    <td width="90"><span class="st4">Name </span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;Mrs. <?= $student->m_name; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="31"><span class="st4">Occupation</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->f_occupation; ?></strong></span></td>
                                                    <td width="90"><span class="st4">Occupation</span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_occupation; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="30"><span class="st4">Qualification</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->f_qualification; ?></strong></span></td>
                                                    <td width="90"><span class="st4">Qualification</span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_qualification; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="33"><span class="st4">Mobile No:</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->f_mobile; ?></strong></span></td>
                                                    <td><span class="st4">Mobile No:</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_mobile; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="31"><span class="st4">Ph.Office</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<? ?></strong></span></td>
                                                    <td width="90"><span class="st4">Ph.Office</span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<? ?></strong></span></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="128"><strong class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="b1"><u>Local Address: </u></span><br />
                                            <br />
                                            <table width="667" height="28" border="0" align="center">
                                                <tr valign="top" class="st4">
                                                    <td width="367" height="24">Village/Town/City:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->village ?></strong></td>
                                                    <td width="272">Post Office:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->postoffice ?></strong></td>
                                                </tr>
                                            </table>
                                            <table width="667" border="0" align="center">
                                                <tr valign="top" class="st4">
                                                    <td width="169" height="16">Tehsil:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->tehsil ?></strong></td>
                                                    <td width="172">District:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->district ?></strong></td>
                                                    <td width="172">State:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->state ?></strong></td>

                                                    <td width="132">Pin:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->pincode ?></strong></td>
                                                </tr>
                                                <tr valign="top" class="st4">
                                                    <td height="17">School Transport:</td>
                                                    <td width="172">&nbsp;&nbsp;&nbsp;&nbsp;<strong>

                                                        </strong>&nbsp;&nbsp;
</td>
                                                    <td width="156">&nbsp;</td>
                                                    <td width="132">&nbsp;</td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="66"><table width="667" border="0" align="center">
                                                <tr bgcolor="#FFFFFF">
                                                    <td width="209" height="21">.....................................................</td>
                                                    <td width="208">.....................................................</td>
                                                    <td width="218">.....................................................</td>
                                                </tr>
                                                <tr valign="top" bgcolor="#FFFFFF" class="st4">
                                                    <td height="35"><div align="center">Father/Guardian</div></td>
                                                    <td width="208"><div align="center">Mother</div></td>
                                                    <td width="218"><div align="center">Principal</div></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                </table></td>
                        </tr>
                    </table>
                    <input type="button" value="Print" onclick="printpage();">
                    <input type="submit" name="Submit" value="Exit" />
                </form>