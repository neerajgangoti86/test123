<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<script language="javascript">
    function printpage()
    {
        window.print();
    }
</script><section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);												
                print_r($student);
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                ?>




                <form id="contactform" name="contactform" method="post" action="admin.php">
                    <table width="766" background="../../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
                        <tr>
                            <td width="100%"><table width="100%" height="794" align="center" bordercolor="#2A3F00">
                                    <tr align="left" valign="top">
                                        <td width="652" height="161">
                                            <table width="707" border="0" align="center" cellpadding="2" cellspacing="2">
                                                <tr>
                                                    <td width="699"><table width="699" height="105" border="0" align="center">

                                                            <tr>
                                                                <td width="693" height="23" colspan="3" align="center" valign="baseline">
                                                                    <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
                                                            </tr>


                                                        </table></td>
                                                </tr>
                                            </table>







                                        </td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="4" align="left"><hr/></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="220"><table width="100%" height="46" border="0" align="left">
                                                <tr valign="top" class="st4">

                                                    <td width="623" height="42"><table width="100%" height="584" border="0" align="center">
                                                            <tr>
                                                                <td height="31">1.</td>
                                                                <td width="21%">Student&nbsp;Id :&nbsp;&nbsp;<strong><?= $student->student_id; ?></strong></td>
                                                                <td height="31" colspan="2"> Student Name :&nbsp;&nbsp;<strong><?= $student->name; ?></strong></td>
                                                                <td width="22%">Gender : &nbsp;&nbsp;<strong>
<?php $Gender = $student->gender;
if ($Gender == 'F') {
    echo "Female";
} elseif ($Gender == 'M') {
    echo "Male";
} else {
    
} ?>
                                                                    </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="4%" height="31">2.</td>
                                                                <td height="31" colspan="4">Class in which admission is sought : <strong>

                                                                    </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="4%" height="31">3.</td>
                                                                <td height="31" colspan="4">Father's /Guardian's Name:<strong>&nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;<?php echo 'Mr.' . $student->f_name;; ?></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="31">4.</td>
                                                                <td height="31" colspan="2">Father's Qualification : <strong>&nbsp;   &nbsp; &nbsp;   &nbsp;</strong><strong>&nbsp;</strong><strong> &nbsp;</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_qualification; ?></strong></strong></td>
                                                                <td colspan="2">Father's Occupation :<strong><?= $student->f_occupation; ?></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="31">5.</td>
                                                                <td height="31" colspan="4">Mother's Name : <strong>&nbsp;   &nbsp; </strong><strong> &nbsp;   &nbsp;&nbsp;   &nbsp; </strong><strong> &nbsp;   &nbsp;</strong><strong>&nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;Mrs. <?= $student->m_name; ?></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="31">6.</td>
                                                                <td height="31" colspan="2">Mother's Qualification :<strong> &nbsp;   &nbsp;&nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong> </strong> <strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_occupation; ?></s</td>
                                                                <td height="31" colspan="2">Mother's Occupation : <strong><?= $student->f_qualification; ?></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="31">7.</td>
                                                                <td height="31" colspan="2">Mobile No. for SMS :<strong> &nbsp;   &nbsp; </strong><strong> &nbsp;   &nbsp;&nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong> </strong> <strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->mobile_sms; ?></strong></strong></td>
                                                                <td height="31" colspan="2">Mobile: (Parents) : <strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->f_mobile; ?></strong><?= $student->m_mobile; ?></strong></td>
                                                            </tr>
                                                            <!--<tr>
                                                              <td height="26">8.</td>
                                                              <td colspan="4">Email : </td>
                                                            </tr>-->
                                                            <tr>
                                                                <td height="25">9.</td>
                                                                <td colspan="4">Brother's Sister's Name and class :<strong> </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="25">10.</td>
                                                                <td colspan="2">Date Of Birth : <strong> &nbsp;   &nbsp; </strong><strong> &nbsp;   &nbsp; </strong><strong> &nbsp;   &nbsp; </strong><strong> &nbsp;   &nbsp;&nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong> </strong><strong>
																		<?php                                                                        $DateOfBirth = $student->birth_date;                                                                        echo $new_date = date('d-m-Y', strtotime($DateOfBirth));                                                                        ?>
                                                                    </strong></td>
                                                                <td colspan="2"> Nationality :<strong> &nbsp;</strong> <strong>Indian</strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="26">11.</td>
                                                                <td colspan="2">Annual Family Income : <strong>&nbsp; </strong><strong>&nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong><?php echo $student->annual_income; ?></strong></td>
                                                                <td colspan="2">Category :<strong> &nbsp;   &nbsp;
                                                                
                                                                <?= $student->Category_short; ?>  </strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="41">12.</td>
                                                                <td colspan="4"><p>Person With Disability<strong> : No/Locomotor/Disability/Dislexic/Hearing Impairment/Visual  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;   &nbsp;  &nbsp;  &nbsp;  &nbsp;   &nbsp;  &nbsp;  &nbsp;  &nbsp;   &nbsp;  &nbsp;  &nbsp;  &nbsp;   &nbsp;  &nbsp;  &nbsp;  &nbsp;   &nbsp;  &nbsp;  &nbsp;  &nbsp;   &nbsp;  &nbsp;  &nbsp;  &nbsp;   &nbsp;  &nbsp;Impairment/ Spastic Austistic</strong>.</p></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="27">13.</td>
                                                                <td colspan="4">Minority :<strong> &nbsp;   &nbsp;&nbsp;   &nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong>&nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong> </strong><strong> <?php //echo $Religion = $row['Religion']; ?></strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="30">14.</td>
                                                                <td colspan="2">School Bus : <strong> &nbsp;   &nbsp;   &nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong>&nbsp; </strong><strong></strong></td>
                                                                <td colspan="2">Stoppage : &nbsp;    <strong>
                                                                    </strong>  &nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                            </tr>                                                         
                                                            <tr>
                                                                <td height="55" valign="top">15.</td>
                                                                <td colspan="4" valign="top">Address of correspondence:																																<br />                                            <table width="667" height="28" border="0" align="center">                                                <tr valign="top" class="st4">                                                    <td width="367" height="24">Village/Town/City:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->village ?></strong></td>                                                    <td width="272">Post Office:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->postoffice ?></strong></td>                                                </tr>                                            </table>                                            <table width="667" border="0" align="center">                                                <tr valign="top" class="st4">                                                    <td width="169" height="16">Tehsil:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->tehsil ?></strong></td>                                                    <td width="172">District:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->district ?></strong></td>                                                    <td width="172">State:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->state ?></strong></td>                                                    <td width="132">Pin:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->pincode ?></strong></td>                                                </tr>                                                <tr valign="top" class="st4">                                                    <td height="17">School Transport:</td>                                                    <td width="172">&nbsp;&nbsp;&nbsp;&nbsp;<strong>                                                            <?php /* $rs=mysql_query($sql = "SELECT * FROM `35SATpt` Where S_id='$s_id' and end_date ='3000-12-31' and MSID='$msid'"); 	 	 	                                                              while($row = mysql_fetch_assoc($rs)) {                                                              echo $row['Tptstation']; */ ?>                                                        </strong>&nbsp;&nbsp;<?php /// }           ?>&nbsp;</td>                                                    <td width="156">&nbsp;</td>                                                    <td width="132">&nbsp;</td>                                                </tr>                                            </table>																																</td>
                                                            </tr>
                                                            <tr>
                                                                <td height="55"  valign="top">16.</td>
                                                                <td colspan="4" valign="top">Permanent Address :<br />                                            <table width="667" height="28" border="0" align="center">                                                <tr valign="top" class="st4">                                                    <td width="367" height="24">Village/Town/City:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->village ?></strong></td>                                                    <td width="272">Post Office:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->postoffice ?></strong></td>                                                </tr>                                            </table>                                            <table width="667" border="0" align="center">                                                <tr valign="top" class="st4">                                                    <td width="169" height="16">Tehsil:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->tehsil ?></strong></td>                                                    <td width="172">District:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->district ?></strong></td>                                                    <td width="172">State:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->state ?></strong></td>                                                    <td width="132">Pin:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->pincode ?></strong></td>                                                </tr>                                                <tr valign="top" class="st4">                                                    <td height="17">School Transport:</td>                                                    <td width="172">&nbsp;&nbsp;&nbsp;&nbsp;<strong>                                                            <?php /* $rs=mysql_query($sql = "SELECT * FROM `35SATpt` Where S_id='$s_id' and end_date ='3000-12-31' and MSID='$msid'"); 	 	 	                                                              while($row = mysql_fetch_assoc($rs)) {                                                              echo $row['Tptstation']; */ ?>                                                        </strong>&nbsp;&nbsp;<?php /// }           ?>&nbsp;</td>                                                    <td width="156">&nbsp;</td>                                                    <td width="132">&nbsp;</td>                                                </tr>                                            </table> </td>
                                                            </tr>
                                                            <tr valign="top" class="st4">
                                                                <td height="49" colspan="5"  ><p>I/We have read the school rules and conditions carefully regarding admission given in the prospectus and I/We will abide by them and certify that all the pariticular's given above are correct to the best of my knowledge and belief.</p>
                                                                    <table width="667" border="0" align="center">
                                                                        <tr bgcolor="#FFFFFF" class="st4">
                                                                            <td width="276" height="41"><b>Date :</b></td>
                                                                            <td width="10">&nbsp;</td>
                                                                            <td width="367"><b>Signature Of Father/ Guardian :</b></td>
                                                                        </tr>
                                                                        <tr valign="top" bgcolor="#FFFFFF" class="st4">
                                                                            <td height="35"><b>Place : </b></td>
                                                                            <td width="10">&nbsp;</td>
                                                                            <td width="367"><b>Signature Of the Principal :</b></td>
                                                                        </tr>
                                                                    </table></td>
                                                            </tr>

                                                        </table></td> 
                                                </tr>
                                            </table></td>
                                    </tr>

                                </table></td>
                        </tr>
                    </table>
                    <input type="button" value="Print" onclick="printpage();">
                    <input type="submit" name="Submit" value="Exit" />
                </form>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>












