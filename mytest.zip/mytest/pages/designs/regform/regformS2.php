
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<script language="javascript">
    function printpage()
    {
        window.print();
    }
</script>
<style type="text/css" media="print">
    @media print
    {    
        .main-footer
        {
            display: none !important;
        }
    }
</style>
<style>
    .box .watermark {
        position: absolute;
        top: 300px;
        bottom: 0;
        left: 250px;
        right: 0;

        background: url(<?= CLIENT_URL ?>/uploads/photo_1458715104.jpg);
        background-size: 50%;
        background-repeat:no-repeat;
        background-position:center;
        width:60%;
        opacity: .1;
    } 
</style>
<!--<ul class="nav nav-pills">
                <li class="dropdown">
                    <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                    <ul class="dropdown-menu">
                        <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                            </a></li>
                        <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                        </li>

                    </ul>
                </li>
            </ul>-->

<section class="content report_export" id="reg_reports">
    <div class="row">
        <div class='col-md-12'> 
                    </div></div>

    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">


                <?php if ($oCurrentSchool->watermark == 1) { ?>   <div class="watermark"></div> <?php } ?>

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);




                //print_r($student);
//           
//             exit();
                ?>
                <br>
                <br><?php
                //print_r($oCurrentSchool);
                ?>
                <form id="contactform" name="contactform" method="post" action="admin.php">
                    <table width="723" border="1" align="center" cellpadding="2" cellspacing="2" id="reg_report">
                        <tr>
                            <td width="715">
                                <table width="658" height="902" align="center" bordercolor="#2A3F00" >
                                    <tr align="left" valign="top">
                                        <td width="652" height="161">
                                            <table width="707" border="0" align="center" cellpadding="2" cellspacing="2">
                                                <tr>
                                                    <td width="699"><table width="699" height="105" border="0" align="center">

                                                            <tr>
                                                                <td width="693" height="23" colspan="3" align="center" valign="baseline">
                                                                    <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
                                                            </tr>


                                                        </table></td>
                                                </tr>
                                            </table>
</td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="4" align="left"><hr/></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="220">
                                            <table width="100%" height="46" border="0" align="left">
                                                <tr valign="top" class="st4">
                                                    <td width="34" align="left" valign="top"><img    src="<?php
                                                        if ($student->photo != "") {
                                                            echo CLIENT_URL . '/uploads/' . $student->photo;
                                                        } else {
                                                            echo ASSETS_FOLDER . "/img/myprofile1.png";
                                                        }
                                                        ?>" >



                                                    </td>
                                                    <td width="623" height="42">
                                                        <table width="100%" height="212" border="0" align="center">
                                                            <tr valign="top" class="st4">
                                                                <td height="49" colspan="3" class="style15"><?= $student->name; ?> <br />                      <br /></td>
                                                            </tr>
                                                            <tr valign="top" class="st4">
                                                                <td width="30%" height="36">Student&nbsp;Id:&nbsp;&nbsp;<strong><?= $student->student_id; ?></strong> &nbsp;</td>

                                                                <td width="37%">Date of Birth: &nbsp; <strong>
                                                                        <?php
                                                                        $DateOfBirth = $student->birth_date;
                                                                        echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                                                        ?>
                                                                    </strong></td>
                                                            </tr>
                                                            <tr valign="top" class="st4">
                                                                <td height="36">Admission No:<strong><?= $student->admno ?></strong></td>
                                                                <td height="36">Admission class:<strong><?php
                                                                        echo $student->adm_class_name;
                                                                        ?>
                                                                    </strong></td>
                                                                <td height="36">Admission Date:<strong><?php
                                                                        $AdmDate = $student->adm_date;
                                                                        echo $new_dat1e = date('d-m-Y', strtotime($AdmDate));
                                                                        ?>
                                                                    </strong></td>
                                                            </tr>
                                                            <tr valign="top" class="st4">
                                                                <td height="36">Category:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php
                                                                        echo $student->Category_short;
                                                                        ?></strong></td>
                                                                <?Php if ($oCurrentSchool->house > '0') { ?>   <td height="36">House:<strong>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                            <?=
                                                                            $student->house;
                                                                            ?>

                                                                        </strong></td>    <?php } ?> 
                                                                <?Php if ($oCurrentSchool->section > '1') { ?>   <td height="36">Section:<strong>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                            <?php
                                                                            echo $student->sec_name;
                                                                            ?>

                                                                        </strong></td>    <?php } ?>
                                                            </tr> <?php
//                                                            $stream = SuperAdmin::get_stream($student->stream)->fetch(PDO::FETCH_OBJ);
                                                            //print_r($stream);
                                                            ?>


                                                            <?php if ($student->class > 10) { ?>
                                                                <tr valign="top" class="st4">
                                                                    <td height="28">Stream:<strong>
                                                                            <?php // echo $stream->stream;  ?>
                                                                        </strong></td>
                                                                    <td height="28">Group:<strong>
                                                                            <?php
                                                                            $gr = $row['Group'];
                                                                            if ($gr == 'M') {
                                                                                echo "Med";
                                                                            } else if ($gr == 'N') {
                                                                                echo "Non-Med";
                                                                            } else if ($gr == 'T') {
                                                                                echo "Maths";
                                                                            } else if ($gr == 'E') {
                                                                                echo "Eco";
                                                                            } else {
                                                                                echo "Geo";
                                                                            }
                                                                            ?>
                                                                        </strong></td>
                                                                    <td height="28">Sub Group:<strong>
                                                                            <?php
                                                                            $Sbgp = $row['SubGroup'];
                                                                            if ($Sbgp == 'I') {
                                                                                echo "IT";
                                                                            } else {
                                                                                echo "P Edu";
                                                                            }
                                                                            ?>
                                                                        </strong></td>
                                                                </tr>
                                                                <?php
                                                            } else {
                                                                
                                                            }
                                                            ?>
                                                        </table></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="211">
                                            <table width="677" height="221" border="0" align="center">
                                                <tr valign="top" class="b1">
                                                    <td height="49" colspan="2" align="center"><u>Father's Info:</u>
                                                    </td>
                                                    <td colspan="2" align="center"><u>Mother's Info:</u></td>
                                                </tr>

                                                <tr valign="top">
                                                    <td width="93" height="27"><span class="st4">Name </span></td>
                                                    <td width="283"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;Mr. <?= $student->f_name; ?></strong></span></td>
                                                    <td width="90"><span class="st4">Name </span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;Mrs. <?= $student->m_name; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="31"><span class="st4">Occupation</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->f_occupation; ?></strong></span></td>
                                                    <td width="90"><span class="st4">Occupation</span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_occupation; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="30"><span class="st4">Qualification</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->f_qualification; ?></strong></span></td>
                                                    <td width="90"><span class="st4">Qualification</span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_qualification; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="33"><span class="st4">Mobile No:</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->f_mobile; ?></strong></span></td>
                                                    <td><span class="st4">Mobile No:</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->m_mobile; ?></strong></span></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="31"><span class="st4">Ph.Office</span></td>
                                                    <td><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<? ?></strong></span></td>
                                                    <td width="90"><span class="st4">Ph.Office</span></td>
                                                    <td width="193"><span class="st4"><strong>&nbsp;&nbsp;&nbsp;&nbsp;<? ?></strong></span></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="128"><strong class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span class="b1"><u>Local Address: </u></span><br />
                                            <br />
                                            <table width="667" height="28" border="0" align="center">
                                                <tr valign="top" class="st4">
                                                    <td width="367" height="24">Village/Town/City:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->village ?></strong></td>
                                                    <td width="272">Post Office:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->postoffice ?></strong></td>
                                                </tr>
                                            </table>
                                            <table width="667" border="0" align="center">
                                                <tr valign="top" class="st4">
                                                    <td width="169" height="16">Tehsil:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student->tehsil ?></strong></td>
                                                    <td width="172">District:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->district ?></strong></td>
                                                    <td width="172">State:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->state ?></strong></td>

                                                    <td width="132">Pin:<strong>&nbsp;&nbsp;&nbsp;&nbsp;<?= $student->pincode ?></strong></td>
                                                </tr>
                                                <tr valign="top" class="st4">
                                                    <td height="17">School Transport:</td>
                                                    <td width="172">&nbsp;&nbsp;&nbsp;&nbsp;<strong>
                                                            <?php /* $rs=mysql_query($sql = "SELECT * FROM `35SATpt` Where S_id='$s_id' and end_date ='3000-12-31' and MSID='$msid'"); 	 	 	
                                                              while($row = mysql_fetch_assoc($rs)) {
                                                              echo $row['Tptstation']; */ ?>
                                                        </strong>&nbsp;&nbsp;
                                                        <?php /// }            ?>&nbsp;</td>
                                                    <td width="156">&nbsp;</td>
                                                    <td width="132">&nbsp;</td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="66"><table width="667" border="0" align="center">
                                                <tr bgcolor="#FFFFFF">
                                                    <td width="209" height="21">.....................................................</td>
                                                    <td width="208">.....................................................</td>
                                                    <td width="218">.....................................................</td>
                                                </tr>
                                                <tr valign="top" bgcolor="#FFFFFF" class="st4">
                                                    <td height="35"><div align="center">Father/Guardian</div></td>
                                                    <td width="208"><div align="center">Mother</div></td>
                                                    <td width="218"><div align="center">Principal</div></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                </table></td>
                        </tr>
                    </table>
                    <input type="button" value="Print" onclick="printpage();">
                    <input type="submit" name="Submit" value="Exit" />
                </form>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>


<script type='text/javascript'>
    function htmltopdf() {
        var pdf = new jsPDF('p', 'pt', 'a1');
        source = $('#reg_reports')[0];
        specialElementHandlers = {
            '#bypassme': function (element, renderer) {
                return true
            }
        };
        margins = {
            top: 10,
            bottom: 10,
            left: 10,
            width: 800
        };
        pdf.fromHTML(
                source,
                margins.left,
                margins.top, {
                    'width': margins.width,
                    'elementHandlers': specialElementHandlers
                },
                function (dispose) {
                    pdf.save('Download.pdf');
                }, margins);
    }

</script>





