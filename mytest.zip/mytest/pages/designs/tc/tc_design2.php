<?php
$id = http_get('param2');

$stu_data_get = Student::get_old_stu_check($MSID, $id);

$stu_data_fetch = $stu_data_get->fetch();


if (isset($_POST['rsubmit']))
    {
    ?>
    <link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
    <script language="javascript">
        function printpage()
        {
            window.print();
        }
    </script>
    <section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>
                <div class="box">

                    <?php
                    $id = http_get('param2');
                    $students = Student::get_students($oCurrentUser->myuid, '1', $id);
//                    print_r($students);
                    $count = $students->rowcount();
                    if ($count > 0)
                        {
                        $student = $students->fetch(PDO::FETCH_OBJ);
                        $fname = $student->f_name;
                        $mname = $student->m_name;
                        $category = $student->category;
                        }
                    else
                        {
                        $student = Student::get_stdnt($MSID, $id)->fetch(PDO::FETCH_OBJ);
                        
                        $old = Student::get_old_stu_check($MSID, $id)->fetch(PDO::FETCH_OBJ);


//                        print_r($student);

                        $parent = Parents::get_parents($MSID, $student->parent_id)->fetch(PDO::FETCH_OBJ);
                        $fname = $parent->f_name;
                        $mname = $parent->m_name;
                        $category = $parent->category;
                        }
//                 print_r($student);
//           
//             exit();
                    ?>
                    <table width="674" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
                        <tr>
                            <td width="662">

                                <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>

                            </td></tr>

                        <tr><td>

                                <table>
                                    <tr>
                                        <td align="center" colspan="3">
                                            <span class="style15"><hr/>School Leaving Certificate <hr/></span></td>
                                        <?php
                                        if (@$stu_data_fetch)
                                            {
//                                            print_r(@$stu_data_fetch);
//                                    $student = Student::get_old_stu_check($MSID, '', $_SESSION['old_std_id'])->fetch(PDO::FETCH_OBJ);
//                                    print_r($student);
//                                            exit();
                                            }
                                        ?>
                                    </tr>
                                    <tr>
                                        <td width="323" height="20" align="left" valign="baseline"><?php print_r($stu_data_fetch); ?><span class="n1">Reg.No.<strong>     </strong></span></td>
                                        <td width="133" height="23" align="center" valign="baseline">&nbsp;</td>
                                        <td width="190" height="23" align="left" valign="baseline"><span class="st4">Admission no...<strong>
                                                    <?php
                                                    if (@$oCurrentSchool->ViewOption == '0')
                                                        {
                                                        echo $student->student_id;
                                                        }
                                                    else
                                                        {
                                                        echo $student->admno;
                                                        }
                                                    ?></strong></span></td>
                                    </tr>

                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">&nbsp;1.&nbsp;&nbsp;&nbsp;Name of the pupil:&nbsp;&nbsp;&nbsp; <strong><?= $student->name ?></strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">&nbsp;2.&nbsp;&nbsp;&nbsp;Father's/ Guardian's Name:&nbsp;&nbsp;&nbsp; <strong>
                                                    <?php echo "Mr." . ' ' . $fname ?>
                                                </strong> </span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">&nbsp;3.&nbsp;&nbsp;&nbsp;Mother's Name:&nbsp;&nbsp;&nbsp; <strong> <?php echo "Mr." . ' ' . $mname ?>
                                                </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="20" colspan="3"><span class="n1">&nbsp;4.&nbsp;&nbsp;&nbsp;Nationality:&nbsp;&nbsp;&nbsp; <strong> Indian</strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="24" colspan="3"><span class="n1">&nbsp;5.&nbsp;&nbsp;&nbsp;Category:&nbsp;&nbsp;&nbsp;</span><span class="n1"><strong>
                                                    <?php
                                                    $category = Master::get_category($MSID, $category)->fetch();
//                                        print_r($category);
                                                    echo $category['name'];
                                                    ?>

                                        </strong></span></td>
                                    </tr>

                                    <tr valign="top">
                                        <td height="21" colspan="3"><span class="n1">&nbsp;6.&nbsp;&nbsp;&nbsp;Date of birth (in Christian era) according to Admission Register.................</span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="23" colspan="3"><span class="n1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="n1">(in figures)..<strong>
                                                    <?php
                                                    $DateOfBirth = $student->birth_date;
                                                    echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                                    ?>
                                                </strong>..(in words)..<strong>
                                                    <?php
//echo $DateOfBirth;
                                                    $new_date = date('d', strtotime($DateOfBirth));
                                                    $nm = date('F', strtotime($DateOfBirth));
                                                    $ny = date('Y', strtotime($DateOfBirth));
                                                    $date = Master::get_dates($new_date)->fetch(PDO::FETCH_OBJ);
                                                    $year = Master::get_years($ny)->fetch(PDO::FETCH_OBJ);

                                                    echo $date->datevn . ' ' . $nm . ' ' . $year->year_name;
                                                    ?>
                                                </strong> .</span><span class="n1">.</span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">&nbsp;7.&nbsp;&nbsp;&nbsp;Date of first Admission in the school:&nbsp;&nbsp;&nbsp; <strong> 
                                                    <?php //echo  $acn ;     ?></strong>
                                                ....
                                                <strong>  <?php
                                                    $adm_date = $student->adm_date;
                                                    echo $new_adm_date = date('d-m-Y', strtotime($adm_date));
                                                    ?>
                                                </strong></span></td>
                                    </tr>
                                    
                                    <?php if($student->class>11){?>   <tr valign="top">
                                        <td height="26" colspan="3">&nbsp;8.&nbsp;&nbsp; Class in which pupil last studied:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['class']; ?> 
                                                </strong>                                
                                    </tr>
                                    
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">&nbsp;9.&nbsp;&nbsp;&nbsp;Subject studied: <strong> <?= @$stu_data_fetch['SubjectSTD']; ?></strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="23" colspan="3"><span class="n1">10.&nbsp;&nbsp;&nbsp;Month up to which the pupil has paid school dues:&nbsp;&nbsp;&nbsp; <strong>
                                                    <?php
                                                    @$FeepaidUpto = $student->feepaidupto;
                                                    echo $new_date2 = date('d-M-y', strtotime(@$FeepaidUpto));
                                                    ?>
                                                    <?php // echo @$new_datepp = date('Y', strtotime(@$FeepaidUpto)); ?></strong> </span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="24" colspan="3"><span class="n1">11.&nbsp;&nbsp;&nbsp;Any fee concession availed:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['Feeconcession']; ?> </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">12.&nbsp;&nbsp;&nbsp;Total No. of working days:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['TotalWdays']; ?>
                                                </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">13.&nbsp;&nbsp;&nbsp;Total No. of Attendance:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['Attendance']; ?>
                                                </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">14.&nbsp;&nbsp;&nbsp;</span><span class="n1">Date of application for certificate:&nbsp;&nbsp;&nbsp; <strong>
                                                    <?php
                                                    @$TcIssueDate = $student->TcIssueDate;
                                                    echo @$new_date2 = date('d-M-y', strtotime(@$TcIssueDate));
                                                    ?> </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">15.&nbsp;&nbsp;&nbsp;Date of issue of certificate:&nbsp;&nbsp;&nbsp; <strong>
                                                    <?php
                                                    @$TcIssueDate = $student->TcIssueDate;
                                                    echo @$new_date2 = date('d-M-y', strtotime(@$TcIssueDate));
                                                    ?></strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="20" colspan="3"><span class="n1">16.&nbsp;&nbsp;&nbsp;Reasons for leaving the school: <strong>On parent's request</strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                      <td height="20" colspan="3"><strong><span class="n1">17.&nbsp;&nbsp;&nbsp;</span>This is to certify that Anurag Sharma bears a good moral character.</strong></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="20" colspan="3"><span class="n1">18.&nbsp;&nbsp;&nbsp;Any other remarks:<strong><?= @$_POST['note'] ?></strong> </span></td>
                                    </tr><?php }else { ?>
                                    <tr valign="top">
                                        <td height="26" colspan="3"><span class="n1">&nbsp;</span>8.&nbsp;&nbsp; Class in which pupil is studing:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['class']; ?> 
                                                </strong>                                
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">&nbsp;9.&nbsp;&nbsp;&nbsp;Whether qualified for promotion to the higher class:&nbsp;&nbsp;&nbsp;<strong>
                                        <?= @$stu_data_fetch['Promotion']; ?>
                                        </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">10.&nbsp;&nbsp;&nbsp;Subject studied: <strong> <?= @$stu_data_fetch['SubjectSTD']; ?></strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="23" colspan="3"><span class="n1">11.&nbsp;&nbsp;&nbsp;Month up to which the pupil has paid school dues:&nbsp;&nbsp;&nbsp; <strong>
                                                    <?php
                                                    @$FeepaidUpto = $student->feepaidupto;
                                                    echo $new_date2 = date('d-M-y', strtotime(@$FeepaidUpto));
                                                    ?>
                                                    <?php // echo @$new_datepp = date('Y', strtotime(@$FeepaidUpto)); ?></strong> </span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="24" colspan="3"><span class="n1">12.&nbsp;&nbsp;&nbsp;Any fee concession availed:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['Feeconcession']; ?> </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">13.&nbsp;&nbsp;&nbsp;Total No. of working days:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['TotalWdays']; ?>
                                                </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">14.&nbsp;&nbsp;&nbsp;Total No. of Attendance:&nbsp;&nbsp;&nbsp;<strong>
                                                    <?= @$stu_data_fetch['Attendance']; ?>
                                                </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">15.&nbsp;&nbsp;&nbsp;</span><span class="n1">Date of application for certificate:&nbsp;&nbsp;&nbsp; <strong>
                                                    <?php
                                                    @$TcIssueDate = $student->TcIssueDate;
                                                    echo @$new_date2 = date('d-M-y', strtotime(@$TcIssueDate));
                                                    ?> </strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="22" colspan="3"><span class="n1">16.&nbsp;&nbsp;&nbsp;Date of issue of certificate:&nbsp;&nbsp;&nbsp; <strong>
                                                    <?php
                                                    @$TcIssueDate = $student->TcIssueDate;
                                                    echo @$new_date2 = date('d-M-y', strtotime(@$TcIssueDate));
                                                    ?></strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="20" colspan="3"><span class="n1">17.&nbsp;&nbsp;&nbsp;Reasons for leaving the school: <strong>On parent's request</strong></span></td>
                                    </tr>
                                    <tr valign="top">
                                      <td height="20" colspan="3"><strong><span class="n1">18.&nbsp;&nbsp;&nbsp;</span>This is to certify that Anurag Sharma bears a good moral character.</strong></td>
                                    </tr>
                                    <tr valign="top">
                                        <td height="20" colspan="3"><span class="n1">19.&nbsp;&nbsp;&nbsp;Any other remarks:<strong><?= @$_POST['note'] ?></strong> </span></td>
                                    </tr><?php }?>
                                    <tr valign="top">
                                        <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
                                        <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
                                        <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
                                    </tr>
                                    <tr valign="top" >
                                        <td height="20" align="left" class="st4">Prepared by            (Store full name and signature)</td>
                                        <td height="20" align="left" class="st4">&nbsp;</td>
                                        <td height="20"><div align="center"><span class="st4">Principal's sign
                                                    With seal </span></div></td>
                                    </tr>
                                </table></td> 
                        </tr>
                    </table>

                </div>
            </div>
        </div>
    </section>


    <?php
    }
else
    {
    //print_r($stu_data_fetch);  
    ?>

    <section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>


                <?php
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);                //print_r($student);
                // print_r($student);
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                ?>

                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">TC Information</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form method="post" action="" role="form" target="_blank">
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Student ID<span class="text-red"></span></label>
                                        <input class="form-control" type="text" size="30" id="student_id" name="student_id"  value="<?= $id ?>"/>
                                    </div>
                                    <div class="form-group">
                                        <label>Ref. No.<span class="text-red"></span></label>
                                        <input class="form-control" value="<?= $stu_data_fetch['Srno'] ?>"type="text" size="30" id="ref_no" name="ref_no"/>
                                    </div>

                                    <div class="form-group">
                                        <label>Name<span class="text-red"></span></label>
                                        <input class="form-control" type="text" size="30" id="stu_name" value="<?= $student->name ?>" name="stu_name"/><input type="hidden" name="stu_class" value="<?= $student->class_name ?>"/>
                                    </div>



                                </div>
                                <!-- \col -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Subject Studied<span class="text-red">*</span></label>
                                        <textarea name="subject_studied"  id="subject_studies" class="form-control"><?= @$stu_data_fetch['SubjectSTD']; ?></textarea>
                                    </div>

                                    <div class="form-group">
                                        <label>Total No of Working Days<span class="text-red"></span></label>
                                        <input class="form-control" value="<?= @$stu_data_fetch['TotalWdays']; ?>" type="text" size="30" id="total_working_days" name="total_working_days"/>
                                    </div>  

                                    <div class="form-group">
                                        <label>Total No Of Attendance<span class="text-red"></span></label>
                                        <input class="form-control" value="<?= @$stu_data_fetch['Attendance']; ?>" type="text" size="30" id="total_attendance" name="total_attendance"/>
                                    </div>  


                                </div>

                                <!-- \col -->
                                <div class="col-md-3">

                                    <div class="form-group">
                                        <label>Fee Paid Upto</label>
                                        <input class="form-control adm_date" type="text" value="<?php if($student->feepaidupto!='0000-00-00 00:00:00'){  echo $fee_paid = date("d-m-Y", strtotime($student->feepaidupto)); } else{ echo $fee_paid = date("d-m-Y", strtotime($oCurrentUser->mydate)); }?>" size="20" id="fee_paid_date" name="fee_paid_date"/>
                                    </div>





                                    <div class="form-group">
                                        <label>T C Issue Date</label>
                                        <input class="form-control adm_date" type="text" value="<?php if($student->TcIssueDate!='0000-00-00 00:00:00'){  echo $fee_paid = date("d-m-Y", strtotime($student->TcIssueDate)); } else{ echo $fee_paid = date("d-m-Y", strtotime($oCurrentUser->mydate)); } ?>" size="20" id="tc_issue_date" name="tc_issue_date"/>
                                    </div>


                                    <div class="form-group">
                                        <label>Result</label>
                                        <select name="result" id="result" class="form-control">



                                            <option value="">Selcet</option>
                                            <option value="Pass" <?php if (@$stu_data_fetch['LastResult'] == 'Pass') echo "selected='selected'"; ?>>Pass</option>
                                            <option value="Pursuing" <?php if (@$stu_data_fetch['LastResult'] == 'Pursuing') echo "selected='selected'"; ?>>Pursuing</option>
                                            <option value="Fail" <?php if (@$stu_data_fetch['LastResult'] == 'Fail') echo "selected='selected'"; ?>>Fail</option>
                                            <option value="Compartment" <?php if (@$stu_data_fetch['LastResult'] == 'Compartment') echo "selected='selected'"; ?>>Compartment</option>
                                            <option value="Board Result Awaited" <?php if (@$stu_data_fetch['LastResult'] == 'Board Result Awaited') echo "selected='selected'"; ?>>Board Result Awaited</option>
                                        </select>
                                    </div>    

                                </div>
                                <!-- \col -->


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Roll No</label>
                                        <input class="form-control" type="text" value="<?= @$stu_data_fetch['RollNo']; ?>" size="20" id="roll_no" name="roll_no"/>
                                    </div>

                                    <div class="form-group">
                                        <label>Marks Obtained</label>
                                        <input class="form-control" type="text" value="<?= @$stu_data_fetch['Mraks_obtained']; ?>" size="20" id="marks_obtained" name="marks_obtained"/>

                                    </div>

                                    <div class="form-group">
                                        <label>Date Last Attended School</label>
                      <input class="form-control adm_date" type="text" value="<?php if($student->sl_date !='3000-12-31'){  echo $fee_paid = date("d-m-Y", strtotime($student->sl_date)); } else { echo " "; } ?>" size="20" id="last_attend" name="last_attend"/>

                                    </div>


                                </div>



                            </div>   
                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Whether Qualified For Promotion To Next Class</label>
                                        <select name="qualifiy_next" id="qualifiy_next" class="form-control">
                                            <option value="Board Result Awaited" <?php if (@$stu_data_fetch['Promotion'] == 'Board Result Awaited') echo "selected='selected'"; ?>>Board Result Awaited</option>
                                            <option value="Pursuing" <?php if (@$stu_data_fetch['Promotion'] == 'Pursuing') echo "selected='selected'"; ?>>Pursuing</option>
                                            <option value="Yes" <?php if (@$stu_data_fetch['Promotion'] == 'Yes') echo "selected='selected'"; ?>>Yes</option>
                                            <option value="No" <?php if (@$stu_data_fetch['Promotion'] == 'No') echo "selected='selected'"; ?>>No</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label>Any Fee Concession Availed</label>
                                        <select name="fees_concession_avail" id="fees_concession_avail" class="form-control">

                                            <option value="No" <?php if (@$stu_data_fetch['Feeconcession'] == 'No') echo "selected='selected'"; ?>>No</option>
                                            <option value="Yes" <?php if (@$stu_data_fetch['Feeconcession'] == 'Yes') echo "selected='selected'"; ?>>Yes</option>
                                        </select>

                                    </div>




                                </div>



                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Extra Activities</label>
                                        <input class="form-control" type="text" value="" size="20" id="extra_activity" name="extra_activity"/>
                                    </div>

                                    <div class="form-group">
                                        <label>Reasons For Leaving The School</label>
                                        <input class="form-control" type="text" value="<?= $stu_data_fetch['Reason']; ?>" size="20" id="reason_leaving" name="reason_leaving"/>

                                    </div>

                                    <div class="form-group">
                                        <label>Note</label>

                                        <textarea name="note" id="note" class="form-control"></textarea> 
                                    </div>



                                </div>



                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-3">
                                    <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>
                    </form>
                </div>     







            </div>



        </div>

    </section> 




    <?php
    }
?>



<input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">  <!-- Main content --><?php
$sBottomJavascript = <<<EOT

<script type="text/javascript">
$(document).ready(function(){
    //$("#subject_group").show();                
    $('#aclass').change(function(e){
     var class_id =  $(this).val();
     
     if(class_id >10)
     {
        $("#subject_group").show();                                                        
        
     } 
    else
    {
        $("#subject_group").hide();
    }
   
                                                                
         
                                                                
     //alert(class_id);
	   $('#selection').html('');
	   var classid = $(this).val();
	   var siteurl = $('#site_url').val();	
	   $('#selection').html('Loading....');
	    $.ajax({
			url: siteurl+"/ajax-page-load/selection_std",
			type: "post",
			data: { classid: classid} ,
			success: function (response) {
                       //alert(response);
			  $('#selection').html(response);
                    $('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
        

	});
        
                
                    
                    
                    
    });

                  
                    
$('.adm_date').datepicker({format: 'dd-mm-yyyy', todayHighlight: true }); 
                    
//$('.adm_date1').datepicker({format: 'yyyy-mm-dd', todayHighlight: true });
                    
                    
$('.adm_date').on('changeDate', function(ev){
    $(this).datepicker('hide');
}) ;

                    
                    
$('body').on('click','[data-ms="modal"]', function(e) {
	var link = $(this);
	var options = {
        url: link.attr("href"),
        title: link.attr("data-title"),
		size : 'lg'
    };
   eModal.setEModalOptions({
        loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
    });
   eModal.ajax(options);
   return false;
});
$('body').on('click','.ajaxselect',function(){
   /*-----*/
        var id    = $(this).attr('data-id');   
        var fname    = $(this).attr('data-fname');
		var mname    = $(this).attr('data-mname');
		var fquali  = $(this).attr('data-fquali');
		var foccu = $(this).attr('data-foccu');
		var fmobile     = $(this).attr('data-fmobile');
		var mquali = $(this).attr('data-mquali');
		var moccu  = $(this).attr('data-moccu');
		var mmobile  = $(this).attr('data-mmobile');
		var category    = $(this).attr('data-category');
		var addline1 = $(this).attr('data-addline1');
		var addline2     = $(this).attr('data-addline2');
		var aincome  = $(this).attr('data-aincome');
		var msms  = $(this).attr('data-msms');
		var local    = $(this).attr('data-local');
		var landline = $(this).attr('data-landline');
		var padd     = $(this).attr('data-padd');
		var religion     = $(this).attr('data-religion');
                var localname = $(this).attr('data-localname');
                    
                var feebook   = $(this).attr('data-feebook');
                    

		$('#name7').val(fname).attr('disabled','disabled');
		$('#mname').val(mname).attr('disabled','disabled');
		$('#f_qualification').val(fquali).attr('disabled','disabled');
		$('#f_occupation').val(foccu).attr('disabled','disabled');
		$('#fmob').val(fmobile).attr('disabled','disabled');
		$('#m_qualification').val(mquali).attr('disabled','disabled');
		$('#m_occupation').val(moccu).attr('disabled','disabled');
		$('#name15').val(mmobile).attr('disabled','disabled');
		$('#category').val(category).attr('disabled','disabled');
		$('#addline1').val(addline1).attr('disabled','disabled');
		$('#name16').val(addline2).attr('disabled','disabled');
		$('#Annual_Income').val(aincome).attr('disabled','disabled');
		$('#mobsms15').val(msms).attr('disabled','disabled');
		//$('#locality').val(local).attr('disabled','disabled');
                 $('#locality').empty().append('<option selected="selected" value="'+local+'">'+localname+'</option>')
;                $('#locality').attr('disabled','disabled'); 
                 
                 $('#sep_fees_book_box').val('');
                    
                 $('#sep_fees_book_box').val(feebook);
                    
                  
                 
                    
   
		$('#name11').val(landline).attr('disabled','disabled');
		$('#padd').val(padd).attr('disabled','disabled');
		$('#religion').val(religion).attr('disabled','disabled');
               // $('#sep_fee').val(id);
	       $('#parentfrm').append('<input type="hidden" name="parent[parentID]" value="'+id+'" />');
                 //$('#sep_fee_book').show();   
                //$('#sep_fee_book').append('<a id="'+id+'" href="" class="sep_link">Seprate Fee Book</a>');
                
                    
                    
                    
                /* $.ajax({
                    
                    url: siteurl+"/ajax-page-load/get_parentid",
			type: "post",
			data: { classid: id} ,
			success: function (response) {
                      alert(response);
                    eModal.close();
			 // $('#selection').html(response);
                    //$('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });*/
                    
                    
                    
                
        eModal.close();
   /**/
});
$(".parent_reset").on("click", function(e) {
        $('#name7').val('').removeAttr('disabled');
		$('#mname').val('').removeAttr('disabled');
		$('#f_qualification').val('').removeAttr('disabled');
		$('#f_occupation').val('').removeAttr('disabled');
		$('#fmob').val('').removeAttr('disabled');
		$('#m_qualification').val('').removeAttr('disabled');
		$('#m_occupation').val('').removeAttr('disabled');
		$('#name15').val('').removeAttr('disabled');
		$('#category').val('').removeAttr('disabled');
		$('#addline1').val('').removeAttr('disabled');
		$('#name16').val('').removeAttr('disabled');
		$('#Annual_Income').val('').removeAttr('disabled');
		$('#mobsms15').val('').removeAttr('disabled');
		$('#locality').val('').removeAttr('disabled');
		$('#name11').val('').removeAttr('disabled');
		$('#padd').val('').removeAttr('disabled');
		$('#religion').val('').removeAttr('disabled');
		$('input[name="parent[parentID]"]').remove();
		return false;
});
                    
    $(".sep_link").on("click", function(e) {                
      alert("hi");     
      //var id = $(this).attr('id');
      alert(id);
    /*$.ajax({
                    
                    url: siteurl+"/ajax-page-load/get_parentid",
			type: "post",
			data: { classid: id} ,
			success: function (response) {
                      alert(response);
                   // eModal.close();
			 // $('#selection').html(response);
                    //$('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    }); */             
                    
                    
              });    
                  
                    
                    
    $("#fmob").keyup(function()
    {
      var f_mob = $(this).val();  
      $("#mobsms15").val(f_mob);
          
    });

});
                                                                
                                                                
                                                                
 function ShowHideDiv() {
        var chkYes = document.getElementById("option1");
        var tpt = document.getElementById("tpt");
        tpt.style.display = chkYes.checked ? "block" : "none";
    } 
        
 function HideDiv()
 {
    var chkYes = document.getElementById("option2");
        var tpt = document.getElementById("tpt");
        tpt.style.display = chkYes.checked ? "none" : "block";                 
 }
                                                                                      
 function ShowHideDiv1() {
        var chkYes = document.getElementById("option11");
        var disc = document.getElementById("disc");
        disc.style.display = chkYes.checked ? "block" : "none";
    } 
        
 function HideDiv1()
 {
    var chkYes = document.getElementById("option21");
        var disc = document.getElementById("disc");
        disc.style.display = chkYes.checked ? "none" : "block";                 
 }
                                                                      
                                                                
                                                                
                                                                
                                                                
                                                                
                    
 function show_list()
 {
    var chkYes = document.getElementById("parent_account_yes");
    var account_no = document.getElementById("account_no");
    account_no.style.display = chkYes.checked ? "block" : "none";
 }
  
   
                    
 function hide_list()
 {
    var chkYes = document.getElementById("parent_account_No");
    var account_no = document.getElementById("account_no");
    account_no.style.display = chkYes.checked ? "none" : "block";
 }                   
                    
</script>

EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>




