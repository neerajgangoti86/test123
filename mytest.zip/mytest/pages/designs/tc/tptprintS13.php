<?php
session_start();
include("../../connect/db.php");    
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else { 
	$foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail']; 
} ?>::T C</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
</head>
<body> 
<form id="contactform" name="contactform" method="post" action="">
  <table width="693" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td width="681" height="876" align="center"><span class="st3">Transfer Certificate</span>
        <table width="694" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td height="22" colspan="5" align="center" class="m1"><?php echo $sname;?></td>
        </tr>
              <tr>
                <td width="89" align="center" valign="middle"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/1001.jpg";} ?> " width="70" height="70"/></td>
                <td colspan="2" align="center" valign="top"><table width="96%" height="69" border="0" align="center">
               <!--   <tr>
                    <td height="20" colspan="2" align="center" class="b1" ><?php //echo $Place; ?></td>
                  </tr>-->
                  <tr>
                    <td height="20" align="center" class="st4">CBSE Affiliated Code No.:<? echo $AffNo;?></td>
                  </tr>
                  <tr class="r">
                    <td height="21" align="center" class="st4">School Code No.:<? echo $SchoolNo;?></td>
                  </tr>
                </table></td>
                <td colspan="2" align="right" valign="top"><table width="81%" align="right">
                  <tr>
                    <td align="right" class="r">Ropar Road</td>
                  </tr>
                  <tr>
                    <td align="right" class="r">Vill. Asmanpur<strong></strong></td>
                  </tr>
                  <tr>
                    <td align="right" class="r"> NURPUR BEDI,Distt.ROPA</td>
                  </tr>
                  <tr>
                    <td align="right" class="r">Mobile No.:<?php echo $Phone; ?></td>
                  </tr>
                  <tr>
                    <td align="right" class="r">email:mvps54@yahoo.com</td>
                  </tr>
                </table></td>
          </tr>
        <?php  
 $sid1=$_GET['id'];     $s_id = mysql_real_escape_string($sid1); $cno1=$_GET['cno'];     $cno = mysql_real_escape_string($cno1);
/* $promotion1=$_GET['promotion'];     $promotion = mysql_real_escape_string($promotion1);
 $tw1=$_GET['tw'];     $tw = mysql_real_escape_string($tw1);
 $ref1=$_GET['ref_no'];     $ref = mysql_real_escape_string($ref1);
 $school1=$_GET['school'];     $school = mysql_real_escape_string($school1);
  $failed1=$_GET['failed'];     $failed = mysql_real_escape_string($failed1);
 $feecon1=$_GET['feecon'];     $feecon = mysql_real_escape_string($feecon1);
 $subjectstd1=$_GET['subjectstd'];     $subjectstd = mysql_real_escape_string($subjectstd1);
*/ 
 $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.*,O.*, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id And S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village  And P.MSID=L.MSID 
 Inner Join  `1OldStudents` O On O.SID= S.Id And O.MSID=S.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid'  And S.Id='$s_id' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0)" );while($row=mysql_fetch_array($result)){  $row['Name'];
 
     $name=$row['Name'];
  $FatherName=$row['FatherName'];
  $MotherName=$row['MotherName'];
$Category=$row['Category'];
 $BirthDate=$row['BirthDate'];
$AdmissionDate=$row['AdmissionDate'];
 $CClass=$row['ClassName'];
  $CClassnum=$row['CClass'];
 $SubjectStuded=$row['SubjectStuded'];
$TcIssueDate=$row['TcIssueDate'];
$FeepaidUpto=$row['FeepaidUpto'];
$AdmissionDate=$row['AdmDate'];
$Attendence=$row['Attendence'];
$A_ClassNo=$row['AdmClassNo'];
$SubjectSTD=$row['SubjectSTD']; 
$TotalWdays=$row['TotalWdays']; 
$Attendance=$row['Attendance'];
 $LastResult=$row['LastResult'];
 $RollNo=$row['RollNo']; 
$Mraks_obtained=$row['Mraks_obtained'];
 $Promotion=$row['Promotion'];
  $Feeconcession=$row['Feeconcession'];
  $Ref=$row['Ref']; 
    $Note=$row['Note']; 
  
   $NCC=$row['NCC'];
 $Gamesplayed=$row['Gamesplayed']; 
$General_conduct=$row['General_conduct'];
 $Reason=$row['Reason'];
  $Bookno=$row['Bookno'];
  $Srno=$row['Srno'];  
 
 

}$resl=mysql_query($slq="Select distinct `ClassName`,ClassNo from `17Class` where ClassNo='$A_ClassNo' And `MSID`='$msid'");while( $tr = mysql_fetch_array($resl)){$acn=$tr['ClassName'];
}?>
        <tr>
          <td width="89" height="20" align="left" valign="baseline" class="n1">Book No.<strong><? echo $Bookno;?></strong></td>
          <td width="173" height="23" align="right" valign="baseline" class="n1">S.No.</td>
          <td width="206" align="left" valign="baseline">.<strong><? echo $Srno;?></strong>......</td>
          <td height="23" colspan="2" align="left" valign="baseline" class="st4">Admission No...<strong><?php echo $s_id;?></strong></td>
        </tr>
        
        <tr valign="top">
          <td height="22" colspan="3" class="n1">&nbsp;1.&nbsp;&nbsp;&nbsp;Name of the Pupil:&nbsp;&nbsp;&nbsp; <strong><?php echo  $name;?></strong></td>
          <td width="94" height="22" class="n1">Nationality:&nbsp;&nbsp;&nbsp;</td>
          <td width="98" class="n1"><strong>Indian</strong></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">&nbsp;2.&nbsp;&nbsp;&nbsp;Father's Name:&nbsp;&nbsp;&nbsp; <strong>
           <?php  echo 'Mr.'.$FatherName;?>
          </strong> </td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">&nbsp;3.&nbsp;&nbsp;&nbsp;Mother's Name:&nbsp;&nbsp;&nbsp; <strong><?php  echo 'Mrs.'.$MotherName;?>
          </strong></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3" class="n1">&nbsp;4.&nbsp;&nbsp;&nbsp;Whether  belonging to Scheduled Caste or Scheduled Tribe:&nbsp;&nbsp;&nbsp;</td>
          <td height="22" colspan="2" class="n1"><strong>
            <?php $rs2=mysql_query($sql2="SELECT * FROM `1Category` WHERE `MSID`='$msid' and `Id`='$Category'");
while($row2=mysql_fetch_array($rs2)){ echo $row2['CategoryName']; }?>
          </strong></td>
        </tr>
        
        
        
        
       <!-- <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;5.&nbsp;&nbsp;&nbsp;Date of birth (in Christian era) according to admission register (in words)......<strong><?php //echo $DateOfBirth;
		 //echo $new_date = date('d-m-Y', strtotime($DateOfBirth)); ?></strong>...........</span></td>
        </tr>-->
        
         <tr valign="top">
           <td height="21" colspan="5" class="n1">&nbsp;5.&nbsp;&nbsp;&nbsp;Date of first Admission in the school with class:&nbsp;&nbsp;&nbsp; <strong>
           <?php    echo  $acn ;?>
           </strong> .... <strong>
           <?php  echo $new_date1 = date('d-m-Y', strtotime($AdmissionDate)); ?>
           </strong></td>
         </tr>
         <tr valign="top">
           <td height="21" colspan="5" class="n1">&nbsp;6.&nbsp;&nbsp;&nbsp;Date of birth (in Christian Era) according to Admission Register.................</td>
         </tr>
         <tr valign="top">
           <td height="23" colspan="5"><span class="n1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="n1">(in figures)..<strong>
             <?php //echo $DateOfBirth;
		 echo $new_date = date('d-m-Y', strtotime($BirthDate)); ?>
             </strong>..(in words)..<strong>
               <?php //echo $DateOfBirth;
		  $new_date = date('d', strtotime($BirthDate));   $nm = date('F', strtotime($BirthDate)); 
		     $ny = date('Y', strtotime($BirthDate));   $rs2=mysql_query($sql2="SELECT  * from dates where DateName=$new_date");
while($row2=mysql_fetch_array($rs2)){
     $DateName=$row2['datevn'];}$rs3=mysql_query($sql3="SELECT  * from years where ID=$ny");
while($row3=mysql_fetch_array($rs3)){
     $YearName=$row3['YearName'];}
  echo $DateName.' '.$nm.' '.$YearName; 
  
  
  
  
		 
		 ?>
             </strong> .</span><span class="n1">.</span></td>
         </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">&nbsp;7.&nbsp;&nbsp;&nbsp;Class in which the pupil last studied (in figures)&nbsp;&nbsp;&nbsp;<strong><? $clname=$cno-1;$ccl=mysql_query ($scl="SELECT * FROM `17Class` WHERE `MSID`='$msid' And `ClassNo`='$clname'"); while($row5=mysql_fetch_array($ccl)){ echo $cnn= $row5['ClassName'] ; }//echo $CClass;?></strong>......</td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5"><span class="n1">&nbsp;8.&nbsp;&nbsp;&nbsp;School/Board Annual examination last last taken with result..<strong><? echo  $LastResult;?></strong> ...<!--Roll No-->..<strong><? //echo $RollNo;?></strong>..<!--Marks Obtained-->..<strong><? //echo $Mraks_obtained;?></strong></span>..</td>
        </tr>
        <!--<tr valign="top">
          <td height="22" colspan="3"><span class="n1">10.&nbsp;&nbsp;&nbsp;Whether failed if so once/twice in the same class:&nbsp;&nbsp;&nbsp; <strong><?php //echo $failed=$_GET['failed']; ?></strong></span></td>
        </tr>-->
        <tr valign="top">
          <td height="22" colspan="5" class="n1">&nbsp;9.&nbsp;&nbsp;&nbsp;Whether failed, if so, once/twice in the same class:&nbsp;&nbsp;&nbsp;<strong><?php echo $Promotion; ?></strong></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">10.&nbsp;&nbsp;&nbsp;Subject Studied: <strong><?php echo $SubjectSTD ;?></strong></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">11.&nbsp;&nbsp;&nbsp;Whether qualified for promotion to the higher class:&nbsp;&nbsp;&nbsp;<strong><?php echo $Promotion; ?></strong></td>
        </tr>
        <tr valign="top">
          <td height="20" colspan="5" class="n1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if so,to which class (in figures)</td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">12.&nbsp;&nbsp;&nbsp;Month up to which the pupil has paid the school dues:&nbsp;&nbsp;&nbsp; <strong>
 <?php   $FeepaidUpto ; echo $new_date2 = date('F', strtotime($FeepaidUpto));?>
   <?php  echo $new_datepp = date('Y', strtotime($FeepaidUpto)); ?></strong> </td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">13.&nbsp;&nbsp;&nbsp;Any fee concession availed of: if so, the nature of such concession&nbsp;&nbsp;&nbsp;<strong><?php if($Feeconcession!='0') {echo $Feeconcession ;} else{}?></strong></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">14(a).&nbsp;&nbsp;&nbsp;Total No. of working days:&nbsp;&nbsp;&nbsp;<strong>
            <?php  echo $TotalWdays ; ?>
          </strong></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5" class="n1">14(b).&nbsp;&nbsp;&nbsp;Total No. of working days present:&nbsp;&nbsp;&nbsp;<strong>
            <?php 

 
echo $Attendance;  ?>
          </strong></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5"><span class="n1">15.&nbsp;&nbsp;&nbsp;</span><span class="n1">Whether NCC Cadet/Boy Scout/Girl Guide (details may be given):&nbsp;&nbsp;&nbsp; <strong>
          <?php echo $NCC ; ?>
         </strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5"><span class="n1">16.&nbsp;&nbsp;&nbsp;</span><span class="n1">Games played or extra-curricular activities in which the pupil usually took part (mention &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;achievement level therein):&nbsp;&nbsp;&nbsp; <strong>
          <?php  echo $Gamesplayed ; ?></strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5"><span class="n1">17.&nbsp;&nbsp;&nbsp;</span><span class="n1">General conduct:&nbsp;&nbsp;&nbsp; <strong>
          <?php  echo $General_conduct ; ?></strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="5"><span class="n1">18.&nbsp;&nbsp;&nbsp;</span><span class="n1">Date of application of the certificate:&nbsp;&nbsp;&nbsp; <strong>
            
            <?php echo $new_date3 = date('d-m-Y', strtotime($TcIssueDate)); ?> </strong></span></td>
        </tr>
        <tr valign="top">
          <td height="20" colspan="5" class="n1">19.&nbsp;&nbsp;&nbsp;Reason for leaving the school: <strong><span class="st4"><?php  echo $Reason ; ?></span></strong></td>
        </tr>
   
        <tr valign="top">
          <td height="20" colspan="5" class="n1">20.&nbsp;&nbsp;&nbsp;Any other remarks: <strong><span class="st4"><?php  echo $Note ; ?></span></strong></td>
        </tr>
        <tr valign="top">
          <td height="16" colspan="5"><table width="683" border="0">
            <tr>
              <td width="195"><span class="maintxt"><span class="st4">Signature of Class Teacher</span></span></td>
              <td width="161"><span class="maintxt">..................</span></td>
              <td width="313"><span class="st4">Checked by</span>.............. </td>
              </tr>
            <tr>
              <td><span class="st4">(Full name)</span></td>
              <td class="maintxt">.....................</td>
              <td><span class="st4">(State full name &amp; ..........</span></td>
              </tr>
            <tr>
              <td><span class="st4">(Counter signature of<br />
CBSE Officials)</span></td>
              <td>.................</td>
              <td class="st4">Designation)................</td>
              </tr>
            <tr>
              <td height="21">&nbsp;</td>
              <td>&nbsp;</td>
              <td class="st4">&nbsp;</td>
            </tr>
            <tr>
              <td height="21"><span class="st4">(Seal)</span></td>
              <td>&nbsp;</td>
              <td class="st4">Principal's Signature.....................</td>
            </tr>
          </table></td>
          </tr>
      </table></td> 
    </tr>
  </table>
  </body>
</html>
<? }?>