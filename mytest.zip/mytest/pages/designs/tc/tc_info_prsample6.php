<?php
session_start();
include("../../connect/db.php");  
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {
?><!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title><?php $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$BankCash= $row['BankCash'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$EMail= $row['EMail']; $ViewOption= $row['ViewOption']; 
}?></title>
		<meta name="description" content="Online School Management System" />
		<meta name="keywords" content="School Management System, Online School Management System,  School Management Software" />
		<meta name="author" content="Visual Media" />
		<link rel="shortcut icon" href="../../../favicon.ico">
		<link rel="stylesheet" type="text/css" href="../../css/default.css" />
		<link rel="stylesheet" type="text/css" href="../../css/component.css" />
		<script src="../../js/modernizr.custom.js"></script>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
         <script src="../../js/stickyMojo.js"></script>
    <style type="text/css">
<!--
.style12 {color: #FF0000}
-->
    </style>
    <!--Start  Back Function Script-->
<script>
function goBack()
  {
  window.history.back()
  }
</script>
<!--End Back Function-->

<!--Calendar Script starts
  <link rel="stylesheet" type="text/css" media="all" href="../../jscripts4cal/jsDatePick_ltr.min.css"/>
  <script type="text/javascript" src="../../jscripts4cal/jsDatePick.min.1.3.js" ></script>
    <script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"inputField",
			dateFormat:"%Y-%m-%d"

		});
		new JsDatePick({
			useMode:2,
			target:"inputField1",
			dateFormat:"%d-%m-%Y"

		});
		new JsDatePick({
			useMode:2,
			target:"inputField2",
			dateFormat:"%d-%m-%Y"

		});
		 
	};
	
</script>-->
  <!--ends calendar script--> <script language="javascript" type="text/javascript"  src="images/datetimepicker.js">

//Date Time Picker script- by TengYong Ng of http://www.rainforestnet.com
//Script featured on JavaScript Kit (http://www.javascriptkit.com)
//For this script, visit http://www.javascriptkit.com 

</script> <!--Start  Back Function Script-->
	</head>
<body>
		<div class="container">

			<div class="cbp-af-header">
				<div class="cbp-af-inner">
					<img class="logo" src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>">
					<h1><?php echo   $sname; ?> </h1>
                   
 <span class="logout"><?php  echo "Welcome :";?>  <?php     $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
 echo  $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } $s_id1=$_GET['id'];   $s_id = mysql_real_escape_string($s_id1);$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 ?>
      | <a href="../logout.php" class="navi3a">Log out</a></span>
      
     	<nav> <a href="../admin.php"  >Dash Board</a> </nav>
			  </div>
			</div>
            
  
            
            <div id="content">
 <div id="content_left">
  <table width="100%" align="left">
  <tr>
                <td height="30" align="center" valign="top" background="../../images/pattern6.png" style="border-radius:5px 5px 0px 0px"><h2>Module:-</h2></td></tr>
              <tr><td id="main" height="25" align="center" valign="middle"> <div id="sidebar">
    
     <div class="nav">
	<ul>   
    
      <li class="current"><a href="../admin.php">DashBoard</a> </li>
		<li class="current"><a href="list.php">Student Details</a> </li>
	    <li><a  href="livesearch.php">Quick Search</a></li>
        <li><a href="asearch.php">Advanced Search</a> </li>
		<li><a  href="newlist.php">New Admissions</a></li>
		<li><a href="alumni.php">Alumni</a></li>
		<li><a href="outgoinglist.php">Out Going</a></li>
     <li><a href="sessionwiselist.php">Session Wise Strength</a></li>
 
	</ul>
</div>
</div>	
   
<script>
  $(document).ready(function(){
    $('#sidebar').stickyMojo({footerID: '#footer', contentID: '#content_right'});
  });
</script></td> </tr>
      </table>
              </div>  <div id="content_right"> 
           <table width="100%">
              <tr>
             <td background="../../images/pattern6.png" style="background-repeat:repeat; border-radius:5px 5px 0px 0px" width="100%" align="left"><table width="100%">
                    <tr>
    <td width="100%" align="center" valign="middle"><div class="session">&nbsp;&nbsp;<span class="style9"><strong> &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Session:<?php echo  $session;?>      
     
                </strong></span><strong>
              <a href="students_pr.php?s_id=<? echo $s_id;?>&cno=<? echo $cno;?>">      <input class="back" type="button" value="Back" onClick="goBack()"></a></strong></div>
<div class="print_icon">		
<a href="../admin.php">
				<img src="../../images/Home-icon.png" width="27px"  alt="Home" title="Dashboard"></a>&nbsp;&nbsp;
		
					<a  href="../Reports/examples/alumni.php"><img src="../../images/print123.png" width="35px"  alt="Print" title="Print Report"></a>
				</div>
</td>
  </tr>
</table>   </td> 
               
              </tr>
           <tr> <td>  
             <div id="justify" align="justify">
                 <table class="maintable" width="100%" align="center">
                 <tr class="Tophead"><td colspan="10" align="center">TC Information</td></tr>
					    <?php
 //
$result=mysql_query ($sql="SELECT * FROM `13Students`  where `Id`='$s_id' and MSID='$msid'");

while($row=mysql_fetch_array($result)){
 $sid= $row['Id']; 
 $Name= 	$row['Name'];
 
$SLDate= 	$row['SLDate'];	
$FeepaidUpto= 	$row['FeepaidUpto'];
$TcIssueDate= 	$row['TcIssueDate'];
$ExtraActivities= 	$row['ExtraActivities'];
$Attendence= 	$row['Attendence'];
$Note= 	$row['Note'];
$AdmNo= 	$row['AdmNo'];
 
 }
 

 ?>
                         <form id="form2" name="form2" method="post" target="_blank" action="tc_info_pr1.php?cno=<? echo $cno;?>?sid=<? echo $sid;?>">
                               <tr>
                                 <td width="530" height="32" valign="top" class="simple"><span class="style19">  1 ) <?php   if($ViewOption=='0'){echo 'Student Id';}else {echo 'Admission No';}  ?> </span></td>
                                 <td width="449" valign="top"><input name="id" type="text" id="id" size="15" value="<?php //echo $sid ;?><?php   if($ViewOption=='0'){echo $sid;}else {echo $AdmNo;}  ?> "/></td>
                               </tr>
                               <tr>
                                 <td height="32" valign="top" class="simple">2 ) S. No.</td>
                                 <td valign="top"><input name="srno" type="text" id="srno" size="15"  /></td>
                               </tr>
                               <tr>
                                 <td height="32" valign="top" class="simple"><span class="style19">3 ) Name</span></td>
                                 <td valign="top"><input name="name" type="text" id="name" value="<?php echo $Name ;?>" size="40" /></td>
                               </tr>
                               <tr>
                                 <td height="43" valign="top" class="simple">4 ) Subject studied</td>
                                 <td valign="top"><textarea name="subjectstd" cols="40" rows="3" id="subjectstd"><? 
		
							/*$res=mysql_query($sq="Select  * from subjects where  '$cno'  between `ClassFrom` And  `ClassTo` And msid='$msid'");
 while($rw=mysql_fetch_array($res)){   echo  $rw['Subject'].',';}*/ 
 $res=mysql_query($sq="Select DISTINCT ClassName from 17Class where ClassNo='$cno' And msid='$msid'");
 while($rw=mysql_fetch_array($res)){   $cn=$rw['ClassName'];}
								  
$result4=mysql_query ($sql4="SELECT distinct Subject FROM `mstr_time_tb` WHERE   Year(`EffectiveDate`)='$session' And `Class`='$cn'  order by Subject ");
 
while($row4=mysql_fetch_array($result4)){
   $sub4= $row4['Subject']; 
   $result=mysql_query ($sql="SELECT * FROM `subjects`  where  MSID='$msid' And ID='$sub4' order by Subject ");
 
while($row=mysql_fetch_array($result)){
   $Subject= $row['Subject'];  echo $Subject.',';} }
 
								 
								  ?>
                                 </textarea></td>
                               </tr>
                               <tr>
                                 <td height="43" valign="top" class="simple">5 ) Total no of working days</td>
                                 <td valign="top"><input name="totalwdays" type="text" id="totalwdays" size="15"  /></td>
                               </tr>
                               <tr>
                                 <td height="33" valign="top" class="simple">6 ) Total no of Attendance</td>
                                 <td valign="top"><input name="totalpdays" type="text" id="totalpdays" size="15" /></td>
                               </tr>
                               <tr>
                                 <td height="33" valign="top" class="simple"><span class="style19">7 ) Fee Paid Upto </span></td>
                                 <td valign="top"><!--<input name="feepaid_upto" type="text"  value="
<?php // $FeepaidUpto; if($FeepaidUpto=='0000-00-00'){ echo  date('d-m-Y', strtotime($dm));}else {echo   date('d-m-Y', strtotime($FeepaidUpto));};?>"  
                                 
                                 id="feepaid_upto" size="15" />-->
                                   <? // id="inputField1"?>
                                   <input name="feepaid_upto" type="text" value="<?php  $FeepaidUpto;  if($FeepaidUpto=='0000-00-00'){ echo  date('d-m-Y', strtotime($dm));}else {echo   date('d-m-Y', strtotime($FeepaidUpto));};?>"  id="demo2" size="25">
                                   <a href="javascript:NewCal('demo2','ddmmyyyy')"><img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></td>
                               </tr>
                               <tr>
                                 <td height="33" valign="top" class="simple"><span class="style19">8 ) T C Issue Date</span></td>
                                 <td valign="top"><input name="tcissue_d" type="text" id="demo3" value="<?php   $TcIssueDate;       if($TcIssueDate=='0000-00-00'){ echo  date('d-m-Y', strtotime($dm));}else {echo   date('d-m-Y', strtotime($TcIssueDate));};?>" size="25">
                                   <a href="javascript:NewCal('demo3','ddmmyyyy')"><img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></td>
                               </tr>
                               <tr>
                                 <td height="43" valign="top" class="simple">9 ) Details of Last Class Attended</td>
                                 <td valign="top">&nbsp;</td>
                               </tr>
                               <tr>
                                 <td height="43" valign="top" class="simple">A )  Result: </td>
                                 <td valign="top">
                                   
                                     <select name="Result" id="Result">
                                       <option>Selcet</option>   <option>Pass</option>
                                       <option>Fail</option>
                                        <option>Compartment</option>
                                       <option>Board Result Awaited</option>
                                     </select>
                                     
                                   <br>
                                 </td>
                               </tr>
                              <!-- <tr>
                                 <td height="43" valign="top" class="simple">Whether failed if so once/twice in the same class: </td>
                                 <td valign="top"><select name="failed" id="failed">
                                   <option value="NA">Select</option>
                                   <option>Once</option>
                                         <option>Twice</option>
                                 </select></td>
                               </tr>-->
                               <tr>
                                 <td height="43" valign="top" class="simple">B ) Roll No:</td>
                                 <td valign="top"><input name="rollno" type="text" id="rollno"   size="40" /></td>
                               </tr>
                               <tr>
                                 <td height="43" valign="top" class="simple">C ) Marks Obtained:</td>
                                 <td valign="top"><input name="marks_obtained" type="text" id="marks_obtained"   size="40" /></td>
                               </tr>
                               <tr>
                                 <td height="43" valign="top" class="simple"><span class="style19"> 10 ) Date Last Attended School</span></td>
                                 <td valign="top"><input name="sldate" type="text" id="demo1"  value="<?  $Ends; echo date('d-m-Y', strtotime($Ends));?>"size="25"><a href="javascript:NewCal('demo1','ddmmyyyy')"><img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></td>
                               </tr>
                               <tr>
                                 <td height="60" valign="top" class="simple"><span class="n1">11 ) Whether qualified for promotion to Next Class</span></td>
                                 <td valign="top"><select name="promotion" id="promotion">
                                  
                                   <option>Board Result Awaited</option>
                                    <option>Pursuing</option>
                                   <option>Yes</option>
                                   <option>No</option>
                                 </select></td>
                               </tr>
                               <tr>
                                 <td height="43" valign="top" class="simple">12 ) Any fee concession availed</td>
                                 <td valign="top"><select name="feecon" id="feecon">
                                   <option>No</option>
                                   <option>Yes</option>
                                   
                                 </select></td>
                               </tr>
                               <tr>
                                 <td height="29" valign="top" class="simple"><span class="style19">13 )<span class="n1">&nbsp;</span><span class="n1">Whether NCC Cadet/Boy Scout/Girl Guide (details may be given)</span></span></td>
                                 <td valign="top"><textarea name="ncc" cols="35" id="ncc"><?php echo $ExtraActivities ;?></textarea></td>
                               </tr>
                               <tr>
                                 <td height="29" valign="top" class="simple"><span class="style19">14 )</span><span class="n1">Games played or extra-curricular activities in which the pupil usually took part (mention achievement level therein):</span></td>
                                 <td valign="top"><textarea name="games" cols="35" id="games"><?php echo $ExtraActivities ;?></textarea></td>
                               </tr>
                               <tr>
                                 <td height="29" valign="top" class="simple"><span class="style19">15 ) <span class="n1">General conduct</span></span></td>
                                 <td valign="top"><input name="genralcdt" type="text" id="genralcdt"   size="40" /></td>
                               </tr>
                               <tr>
                                 <td height="29" valign="top" class="simple"><span class="style19">16 ) <span class="n1">Reason for leaving the school</span></span></td>
                                 <td valign="top"><textarea name="reason" cols="40" rows="3" id="reason">Passed 12th Class Looking For Higher Education</textarea></td>
                               </tr>
                               <tr>
                                 <td height="39" valign="top" class="simple"><span class="style19">17 ) Any other Remarks</span></td>
                                 <td valign="top"><textarea name="note" cols="40" rows="3" id="note" value="<?php echo $Note ;?>"></textarea></td>
                               </tr>
                               <tr valign="top">
                                 <td height="28" colspan="2"><div align="center"><strong>
                                   <input type="submit" name="Submit"  value="Submit" />
                                 </strong></div></td>
                               </tr>
                             </form>
               </table>
          </div> 
				</td>
                 </tr>
                 <tr><td>
<img src="../../images/img-19.jpg" width="100%" height="13" style="margin-top:-5px;" />      </td></tr>          </table>
      </div>
 
</div> </td></tr></table> </div> 
		
			</div> 
       


		<div id="footer"><p>  </p>
</div>    


		<!-- classie.js by @desandro: https://github.com/desandro/classie 
	<script src="../../js/classie.js"></script>
		<script src="../../js/cbpAnimatedHeader.min.js"></script>-->
	</body>
</html>
<?php }?>
