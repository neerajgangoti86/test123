
 <link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
    <script language="javascript">
        function printpage()
        {
            window.print();
        }
    </script>
    <section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>
                <div class="box">

                    <?php
                    $id = http_get('param2');
                    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                    //print_r($student);



//                 print_r($student);
//           
//             exit();
                    ?>
<table width="674" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
    <tr>
        <td width="662">
         
                   <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>
            
        </td></tr>
    
    <tr><td>
   
                    <table>
                        <tr>
                            <td align="center" colspan="3">
            <span class="style15"><hr/>School Leaving Certificate <hr/></span></td>
       
    </tr>
                        <tr>
                            <td width="200" height="20" align="left" valign="baseline"><span class="n1">Reg.No.<strong>     </strong></span></td>
                            <td width="224" height="23" align="center" valign="baseline">&nbsp;</td>
                            <td width="201" height="23" align="left" valign="baseline"><span class="st4">Admission no...<strong>
                                        <?php
                                        if (@$oCurrentSchool->ViewOption == '0') {
                                            echo $student->student_id;
                                        } else {
                                            echo $student->admno;
                                        }
                                        ?></strong></span></td>
                        </tr>

                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">&nbsp;1.&nbsp;&nbsp;&nbsp;Name of the pupil:&nbsp;&nbsp;&nbsp; <strong><?= $student->name ?></strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">&nbsp;2.&nbsp;&nbsp;&nbsp;Father's/ Guardian's Name:&nbsp;&nbsp;&nbsp; <strong>
                                        <?php echo "Mr." . ' ' . $student->f_name ?>
                                    </strong> </span></td>
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">&nbsp;3.&nbsp;&nbsp;&nbsp;Mother's Name:&nbsp;&nbsp;&nbsp; <strong> <?php echo "Mr." . ' ' . $student->m_name ?>
                                    </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="20" colspan="3"><span class="n1">&nbsp;4.&nbsp;&nbsp;&nbsp;Nationality:&nbsp;&nbsp;&nbsp; <strong> Indian</strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="24"><span class="n1">&nbsp;5.&nbsp;&nbsp;&nbsp;Category:&nbsp;&nbsp;&nbsp;</span></td>
                            <td height="24" colspan="2"><span class="n1"><strong>
                                        <?php
                                        $category = Master::get_category($MSID, $student->category)->fetch();
//                                        print_r($category);
                                           echo $category['name'];   ?>

                                    </strong></span></td>
                        </tr>

                        <tr valign="top">
                            <td height="21" colspan="3"><span class="n1">&nbsp;6.&nbsp;&nbsp;&nbsp;Date of birth (in Christian era) according to Admission Register.................</span></td>
                        </tr>
                        <tr valign="top">
                            <td height="23" colspan="3"><span class="n1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="n1">(in figures)..<strong>
                                       <?php
                                            $DateOfBirth = $student->birth_date;
                                            echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                            ?>
                                    </strong>..(in words)..<strong>
                                        <?php
//echo $DateOfBirth;
                                        $new_date = date('d', strtotime($DateOfBirth));
                                        $nm = date('F', strtotime($DateOfBirth));
                                        $ny = date('Y', strtotime($DateOfBirth));
                                        $date = Master::get_dates($new_date)->fetch(PDO::FETCH_OBJ);
                                                            $year = Master::get_years($ny)->fetch(PDO::FETCH_OBJ);

                                                            echo $date->datevn . ' ' . $nm . ' ' . $year->year_name;
                                        ?>
                                    </strong> .</span><span class="n1">.</span></td>
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">&nbsp;7.&nbsp;&nbsp;&nbsp;Date of first Admission in the school:&nbsp;&nbsp;&nbsp; <strong> 
                                        <?php //echo  $acn ;   ?></strong>
                                    ....
                                    <strong>  <?php
                                            $adm_date = $student->adm_date;
                                            echo $new_adm_date = date('d-m-Y', strtotime($adm_date));
                                            ?>
                                    </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="26" colspan="3"><span class="n1">&nbsp;8.&nbsp;&nbsp;&nbsp;Class in which pupil last studied (in figures)&nbsp;&nbsp;&nbsp;<strong>
         <?php
                                                            $cls = Master::get_classes($MSID, '', '', '', $student->class)->fetch(PDO::FETCH_OBJ);
                                                            echo $cls->class_fullname;
                                                            ?></strong>                                
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">&nbsp;9.&nbsp;&nbsp;&nbsp;Details of last class attended: Result..<strong>  LastResult </strong> ...<!--Roll No-->..<strong><?php //echo $RollNo;?></strong>..<!--Marks Obtained-->..<strong><?php //echo $Mraks_obtained;?></strong></span>..</td>
                        </tr>
                      <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">10.&nbsp;&nbsp;&nbsp;Subject studied: <strong> Subject Studied </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="24" colspan="3"><span class="n1">11.&nbsp;&nbsp;&nbsp;Whether qualified for promotion to the higher class:&nbsp;&nbsp;&nbsp;<strong> Promotion </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="23" colspan="3"><span class="n1">12.&nbsp;&nbsp;&nbsp;Month up to which the pupil has paid school dues:&nbsp;&nbsp;&nbsp; <strong>
                                        <?php
                                        $FeepaidUpto = $student->feepaidupto;
                                        echo $new_date2 = date('F', strtotime($FeepaidUpto));
                                        ?>
                                        <?php echo $new_datepp = date('Y', strtotime($FeepaidUpto)); ?></strong> </span></td>
                        </tr>
                        <tr valign="top">
                            <td height="24" colspan="3"><span class="n1">13.&nbsp;&nbsp;&nbsp;Any fee concession availed:&nbsp;&nbsp;&nbsp;<strong>
                                       Fee concession </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">14.&nbsp;&nbsp;&nbsp;Total No. of working days:&nbsp;&nbsp;&nbsp;<strong>
                                         Total Wdays
                                    </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">15.&nbsp;&nbsp;&nbsp;Total No. of Attendance:&nbsp;&nbsp;&nbsp;<strong>
                                   Attendance
                                    </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">16.&nbsp;&nbsp;&nbsp;</span><span class="n1">Date of application for certificate:&nbsp;&nbsp;&nbsp; <strong>
                                        <?php
                                        $TcIssueDate = $student->TcIssueDate;
                                        echo $new_date2 = date('F', strtotime($TcIssueDate));
                                        ?> </strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="22" colspan="3"><span class="n1">17.&nbsp;&nbsp;&nbsp;Date of issue of certificate:&nbsp;&nbsp;&nbsp; <strong>
                                       <?php
                                        $TcIssueDate = $student->TcIssueDate;
                                        echo $new_date2 = date('F', strtotime($TcIssueDate));
                                        ?></strong></span></td>
                        </tr>
                        <tr valign="top">
                            <td height="20" colspan="3"><span class="n1">18.&nbsp;&nbsp;&nbsp;Reason for leaving the school: <strong>On parent's request</strong></span></td>
                        </tr>
                     
                        <tr valign="top">
                            <td height="20" colspan="3"><span class="n1">19.&nbsp;&nbsp;&nbsp;Any other remarks:<strong>Note</strong> </span></td>
                        </tr>
                        <tr valign="top">
                            <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
                            <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
                            <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
                        </tr>
                        <tr valign="top" >
                            <td height="20" align="left" class="st4">Prepaired by(Name and Signature)</td>
                            <td height="20" align="left" class="st4">Checked by
                                (Name and Signature)</td>
                            <td height="20"><div align="center"><span class="st4">Principal's sign
                                        With seal </span></div></td>
                        </tr>
                    </table></td> 
                    </tr>
                    </table>
                  
                </div>
            </div>
        </div>
    </section>
