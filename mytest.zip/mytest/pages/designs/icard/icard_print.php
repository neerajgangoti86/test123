
 <style type="text/css">

.style12 {color: #FF0000}
.style17 {color: #2A0000;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-weight: bold;
}
.b1 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px;
	font-weight: bold;
}
.st4 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px; padding-left:6px; padding-right:6px;
}
.stp { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px; padding-left:6px;
}


.fghij{ width:100%;}
.section{ width:50%; position:relative; float:left; margin-top:20px;}


    </style>
   	</head>
<body>
 <?php
                
                $student = Student::get_students($oCurrentUser->myuid, '1', $id, '')->fetch();
               while ($rowv = $student->fetch()) {
    

//                print_r($student);
                ?>
<div class="fghij">

 <div class="section">
<table width="95%" height="234" style="border:2px solid #000;">
<tr>
<td height="60" colspan="4">
<table width="100%"  bgcolor="#CCCCCC"><tr><td width="16%"><img  src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50"    /></td>
<td width="84%" align="center"><span class="b1"><?= $oCurrentSchool->name ?></span><br/>
    <?= $oCurrentSchool->place ?>
   
</td>
</tr></table><tr>
        <td width="94"  rowspan="7" align="center" valign="middle">
 <img src="<?php $photo= $row['photo'];
                                                        if ( @$photo) {
                                                            echo CLIENT_URL . '/uploads/' . $photo;
                                                        } else {
                                                            echo ASSETS_FOLDER . "/img/myprofile1.png";
                                                        }
                                                        ?>" width="105" height="117">
         </td>
        <td height="20" colspan="3" class="stp"><b>
          <?= $rowv['name']; ?>
        </b></td>
        </tr>
      <tr>
        <td width="62"  height="20"><span class="st4">F.Name:</span></td>
        <td colspan="2" class="st4">Mr. <?= $rowv['f_name']; ?></td>
      </tr>
      <tr>
        <td height="20"><span class="st4">Adm.No:</span></td>
        <td width="229"  class="st4"><?= $rowv['admno']; ?></td>
        <td width="163"  class="st4">&nbsp;</td>
      </tr>
      <tr>
        <td height="20"><span class="st4">D.O.B&nbsp;&nbsp;:</span></td>
        <td colspan="2" class="st4"><?= date('d M,Y', strtotime($rowv['birth_date'])); ?></td>
        </tr>
      <tr>
        <td height="20"><span class="st4">Ph No&nbsp;&nbsp;:</span></td>
        <td colspan="2" class="st4"><?= $rowv['mobile_sms']; ?></td>
        </tr>
      <tr>
        <td height="20"><span class="st4">Add &nbsp;&nbsp;&nbsp;:</span></td>
        <td colspan="2" class="st4"><?= $rowv['mobile_sms']; ?></td>
        </tr>
   
      <tr>
        <td height="20" colspan="2" class="phead"><p>Principal's</p></td>
        <td class="st4"><b>Class <?= $rowv['class_name']; ?> - <?= $rowv['Section']; ?></b></td>
        </tr>
      
      <tr>
        <td height="10" colspan="4" bgcolor="#CCCCCC" valign="top"></td>
</tr></table></div><?php } ?></div>

</body>
</html>

