<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $exam = http_get('param3');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                ?>
                <table width="664" height="845" border="1"   align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td width="652">
                            <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" valign="top" class="vks">
                            Record of Academic Performance <?php echo $oCurrentUser->mysession; ?></td>
                    </tr>

                    <tr align="left" valign="top">
                        <td height="163">
                            <table width="100%" height="161" border="0" align="center">
                                <tr valign="top" class="st42">
                                    <td rowspan="5"><img style="padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php
                                        if ($student->std_image != "") {
                                            echo $student->std_image;
                                        } else {
                                            echo ASSETS_FOLDER . "/img//myprofile1.png";
                                        }
                                        ?>" width="122" height="127" /></td>
                                    <td>Name :</td>
                                    <td height="33"><?= $student->name; ?></td>
                                    <td height="33">&nbsp;</td>
                                    <td>Admission No:<strong></strong></td>
                                    <td><?php
                                        if (@$oCurrentSchool->ViewOption == '0') {
                                            echo $student->student_id;
                                        } else {
                                            echo $student->admno;
                                        }
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="21">Father's Name:</td>
                                    <td width="238" height="21">Mr. <?= $student->f_name; ?>
                                    </td>
                                    <td width="11" height="21">&nbsp;</td>
                                    <td><?php if (@$student->roll_no != '0') { ?>Roll No.: <?php } ?></td>
                                    <td><?php
                                        if (@$student->roll_no != '0') {
                                            echo $student->roll_no;
                                        }
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="24">Mother's Name:</td>
                                    <td height="24">Mrs. <?= $student->m_name; ?></td>
                                    <td height="24">&nbsp;</td>
                                    <td>Class:</td>
                                    <td><?php
                                        $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                        echo $cls->class_name;
                                        ?>
                                        &nbsp;</td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="38">Mobile</td>
                                    <td height="38"><?= $student->f_mobile; ?></td>
                                    <td height="38">&nbsp;</td>
                                    <td>Date Of Birth: </td>
                                    <td><?php
                                        $DateOfBirth = $student->birth_date;
                                        echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                        ?>
                                        &nbsp;</td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="33">Address:</td>
                                    <td height="33" colspan="4"><?= $oCurrentSchool->place; ?> </td>
                                </tr>
                            </table></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td> <? //if($ULevel=='9'){ ?>


                            <table width="100%" height="197" border="1" align="center">
                                <tr valign="top" bgcolor="#E8E8E8">
                                    <td width="237" height="30" class="st411">SCHOLASTIC AREA<br />
                                        (9 point scale)</td>

                                    <td colspan="4" align="center" class="st411">TERM II</td>
                                </tr>
                                <tr valign="top"  bgcolor="#C9C9C9">
                                    <td height="30" class="st411"><strong>Subjects</strong></td>

                                    <td width="166" align="center" class="st411">FA3 (10%)</td>
                                    <td width="156" align="center" class="st411">FA4 (10%)</td>

                                    <td width="48" class="st411">SA2(30%)</td>
                                    <td width="169" class="st411">Overall<br />
                                        (FA+SA=50%)</td>
                                </tr>
                                <?php
                                $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', '', $student->student_id, $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                while ($rowv = $subjects_querry->fetch()) {
                                    ?>   
                                    <tr valign="top">
                                        <td height="41" class="st411"><?php
                                            $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                            while ($rowu = $subjects->fetch()) {
                                                echo $rowu['name'];
                                            }
                                            ?></td>
                                        <td align="center" class="st411"> <?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                ?><?= $rowu['Grade'] ?>
                                                <?php
                                            }
                                            ?></td>
                                        <td class="st411" align="center"> <?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '4', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                ?><?= $rowu['Grade'] ?>
                                                <?php
                                            }
                                            ?></td>
                                        <td class="st411" align="center"> <?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '5', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                ?><?= $rowu['Grade'] ?>
                                                <?php
                                            }
                                            ?></td>

                                        <td class="st411" align="center" >
                                            <?php
                                            $overall = Exam::exam_term_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id']);
                                            while ($rowu = $overall->fetch()) {
                                                ?><?= $rowu['grade'] ?>
                                    <?php } ?>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                <tr valign="top">
                                    <td height="17" class="st411">ATTENDANCE</td>
<?php /* $att1=mysql_query($aq1="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='1'");
  while($at1=mysql_fetch_array($att1)){ $Term1WD= $at1['TWD']; $Term1Att= $at1['TERMATT'];} */ ?>
                                    <td class="st411"><?php //echo $Term1Att ; ?>/ <?php //echo $Term1WD ; ?></td>
                                    <td class="st411"><?php //$tatt= ($Term1Att/$Term1WD) * 100 ; echo round($tatt,2) ; ?>
                                        %</td>
                                    <td class="st411">&nbsp;</td>
                                    <td class="st411">&nbsp;</td>

                                </tr>
                                <tr valign="top">
                                    <td height="63" colspan="5" align="left" class="st2">Nine point grading scale:A1=91%-100%;A2=81%-90%;B1=71%-80%;B2=61%-70%; c1=51%-60%;C2=41%-50%;D=33%-40%;E1=21%-32%;E2 =20% And Below</td>
                                </tr>
                            </table></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td height="123" valign="top"><table width="100%" height="151" border="0" align="center">
                                <tr>
                                    <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: <?php
                                            $remark = Exam::get_exam_remarks($MSID, '', '', $student->student_id, $oCurrentUser->mysession, '2', $student->class);
                                            while ($rowur = $remark->fetch(PDO::FETCH_ASSOC)) {
                                                echo $rowur['remarks'];
                                            }
                                            ?>
                                        </strong><br/></td>
                                </tr>
                                <tr>
                                    <td height="26" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>
                                            Note:</strong>(1)Promotion is based on the day -to -day continuous assessment throughout the year.(2) CGPA=Cumulative Grade Point Average (3) Subject Wise/Overall indicative percentage of Marks=9.5 X GP of the subject /CGPA.</td>
                                </tr>
                                <tr>
                                    <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                                    <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
                                </tr>
                            </table></td>
                    </tr>
                </table></td>
                </tr>
                </table>
                </p></body>
                </html>
