
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $exam = http_get('param3');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                //print_r($student);
                $ttl = 0;
                $i = 0;
                ?>
                <br>
                <br><?php
                ?>
                <table align="center" border="1" width="692">
                    <tbody><tr>
                            <td width="686"><table style="background-size:45%; background-position:center; background-repeat:no-repeat" align="center" height="702" background="../../images/reportlogo.png" bordercolor="#2A3F00" width="673">
                                    <tbody><tr align="left" valign="top">
                                            <td height="138" width="665">
                                                <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>
                                            </td>
                                        </tr>
                                        <tr align="left" valign="top">
                                            <td align="center" height="556" valign="top"><table align="center" height="185" border="0" width="668">
                                                    <tbody><tr valign="top">
                                                            <td colspan="2" align="center" height="179" width="658"><table border="0" width="658">
                                                                    <tbody><tr>
                                                                            <td colspan="6" height="27"><span class="b1"><?= $student->name ?></span></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="6" class="st4" height="36">Id:<strong><?= $student->student_id ?></strong>Class/House:<strong>
                                                                                    <?php
                                                                                    $cls = Master::get_classes($MSID, '', '', '', $student->class)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $cls->class_name;
                                                                                    ?> <?php echo $student->house ?> </strong>
                                                                                <span class="style19">Birth Date: </span>&nbsp;&nbsp;
                                                                                <span class="style19"> <strong>
                                                                                       <?php echo $student->birth_date ?>                  </strong></span></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td height="31" width="159"><span class="style19">Father's Name: </span></td>
                                                                            <td colspan="4"><span class="style19"><strong>  <?php echo "Mr." . ' ' . $student->f_name ?></strong></span></td>
                                                                            <td width="142">&nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td height="36"><span class="style19">Mother's Name: </span></td>
                                                                            <td colspan="5"><span class="style19"><strong><?php echo "Mrs." . ' ' . $student->m_name ?></strong></span></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="6" height="34"><span class="style19">Village/Town:<strong><?= $student->address_line1 ?> </strong><span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>District: <strong>
                                                                                    </strong> <span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phones:<strong>9459079362</strong></span></span></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td height="21" valign="bottom"><span class="style19">Total Working Days:</span></td>
                                                                            <td align="center" width="214"><span class="style19"><strong>
                                                                                    </strong></span></td>
                                                                            <td colspan="2" align="center" width="118"><span class="style19">Total Attendance:</span><span class="style19"><strong> </strong></span></td>
                                                                            <td colspan="2" align="center"><span class="style19">
                                                                                </span></td>
                                                                        </tr>
                                                                    </tbody></table>
                                                                <span class="style2"><u>              <br>
                                                                        PreBoard Result <?php echo $oCurrentUser->mysession; ?>-<?php echo $session2 = $oCurrentUser->mysession + 1; ?></u></span><br>
                                                                <br>
                                                                <table align="center" border="1" width="711">
                                                                    <tbody><tr align="left" valign="top">
                                                                            <td rowspan="2" height="23" width="142"><span class="style19"><strong>Subjects:</strong></span></td>
                                                                            <td rowspan="2" class="st4" width="32"><strong> Unit 3</strong></td>
                                                                            <td rowspan="2" class="st4" width="33"><strong> Unit 4</strong></td>
                                                                            <td rowspan="2" class="st4" width="33"><strong>Unit 5</strong></td>
                                                                            <td colspan="4" class="st4" align="center"><strong>1st PreBoard</strong></td>
                                                                            <td colspan="4" class="st4" align="center"><strong>2nd PreBoard</strong></td>
                                                                        </tr>
                                                                        <tr align="left" valign="top">
                                                                            <td class="st4" align="center" width="71">Theory<br>
                                                                                85/75/60/35</td>
                                                                            <td class="st4" align="center" width="37">Prac.<br>
                                                                                25/50</td>
                                                                            <td class="st4" align="center" width="47">Dic/MCQ/Ass/Pro<br>
                                                                                15</td>
                                                                            <td class="st4" align="center" width="48">Total<br>
                                                                                100</td>
                                                                            <td class="st4" align="center">Theory<br>
                                                                                85/75/60/35</td>
                                                                            <td class="st4" align="center">Prac.<br>
                                                                                25/50</td>
                                                                            <td class="st4" align="center">Dic/MCQ/Ass/Pro<br>
                                                                                15</td>
                                                                            <td class="st4" align="center">Total<br>
                                                                                100</td>
                                                                        </tr>
                                                                        <?php
                                                                        $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student->student_id, $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                                                        while ($rowv = $subjects_querry->fetch()) {
                                                                            ?> 
                                                                            <tr align="left" valign="top">
                                                                                <td height="23"><span class="style19">
                                                                                         <?php
                                                        $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                                        while ($rowu = $subjects->fetch()) {
                                                            echo $rowu['name'];
                                                        }
                                                        ?>               </span></td>
                                                                                <td><span class="style19">
                                                                                        <?php
                                                                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
                                                                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
//                                                        print_r($rowu);
                                                                                            $marks1 = $rowu['marks_obtained'];
                                                                                            $maxm1 = $rowu['max_marks'];
                                                                                        }
                                                                                        ?>                 </span></td>
                                                                                <td><span class="style19">
                                                                                        <?php
                                                                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id'], 'YES');
                                                                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
//                                                        print_r($rowu);
                                                                                            $marks1 = $rowu['marks_obtained'];
                                                                                            $maxm1 = $rowu['max_marks'];
                                                                                        }
                                                                                        ?>                  </span></td>
                                                                                <td><span class="style19">
                                                                                        <?php
                                                                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', $rowv['subject_id'], 'YES');
                                                                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
//                                                       
                                                                                            $marks1 = $rowu['marks_obtained'];
                                                                                            $maxm1 = $rowu['max_marks'];
                                                                                        }
                                                                                        ?>                   </span></td>
                                                                                <td><span class="style19">
                                                                                    </span></td>
                                                                                <td><span class="style19">
                                                                                    </span></td>
                                                                                <td><span class="style19">
                                                                                    </span></td>
                                                                                <td align="center"><span class="style19">
                                                                                        --                  </span></td>
                                                                                <td><span class="style19">
                                                                                    </span></td>
                                                                                <td><span class="style19">
                                                                                    </span></td>
                                                                                <td><span class="style19">
                                                                                    </span></td>
                                                                                <td align="center"><span class="style19">
                                                                                        --                  </span></td>
                                                                            </tr>
                                                                        <?php } ?>
                                                                        <tr align="left" valign="top">
                                                                            <td colspan="12" class="st4" height="58">Remarks  : <?php
                                        // $ghiy1 = mysql_query($ghy1 = "SELECT * from `21Remarks_Inc_Grades` where  MSID ='$msid' And 	Grade='$Grade6'");
//while ($gowy1 = mysql_fetch_array($ghiy1)) {
//    echo $Remarks = $gowy1['Remarks'];
//} 
                                        ?></td>
                                                                        </tr>
                                                                    </tbody></table>
                                                                <br>
                                                                <table border="0" width="630">
                                                                    <tbody><tr>
                                                                            <td>&nbsp;</td>
                                                                            <td>&nbsp;</td>
                                                                            <td>&nbsp;</td>
                                                                        </tr>
                                                                        <tr class="st4">
                                                                            <td width="202">Father's Signature</td>
                                                                            <td width="169">Teacher's signature</td>
                                                                            <td align="right" width="203">Principal Signature</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>&nbsp;</td>
                                                                            <td>&nbsp;</td>
                                                                            <td>&nbsp;</td>
                                                                        </tr>
                                                                    </tbody></table></td>
                                                        </tr>
                                                    </tbody></table></td>
                                        </tr>
                                    </tbody></table></td>
                        </tr>
                    </tbody></table></td>
                </tr>
                </table>
                <p class="page"></p>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>