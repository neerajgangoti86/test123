
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $exam = http_get('param3');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                $ttl = 0;
                $i = 0;
                ?>
                <br>
                <br><?php
                ?>

                <table width="750" height="737" border="1"   align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td >   <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td></tr>
                    <tr><td Align="center">    <p class="vks">Record of Academic Performance <?php echo $oCurrentUser->mysession; ?></p></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td height="103">
                            <table width="100%" height="149" border="0" align="center">
                                <tr valign="top" class="st42">
                                    <td width="139" rowspan="5">
                                        <img style="padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php
                                        if ($student->std_image != "") {
                                            echo $student->std_image;
                                        } else {
                                            echo ASSETS_FOLDER . "/img//myprofile1.png";
                                        }
                                        ?>" width="122" height="127"></td>
                                    <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                                    <td height="27"><?= $student->name; ?></td>
                                    <td height="27">&nbsp;</td>
                                    <td width="106"> Admission No:</td>
                                    <td width="105"><?php
                                        if (@$oCurrentSchool->ViewOption == '0') {
                                            echo $student->student_id;
                                        } else {
                                            echo $student->admno;
                                        }
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="31">Father's Name:</td>
                                    <td width="238" height="31">Mr. <?= $student->f_name; ?></td>
                                    <td width="11" height="31">&nbsp;</td>
                                    <td><?php if (@$student->roll_no != '0') { ?>Roll No.: <?php } ?></td>
                                    <td><?php
                                        if (@$student->roll_no != '0') {
                                            echo $student->roll_no;
                                        }
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="28">Mother's Name:</td>
                                    <td height="28">Mrs. <?php echo $student->m_name; ?></td>
                                    <td height="28">&nbsp;</td>
                                    <td>Class:</td>
                                    <td><?php
                                        $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                        echo $cls->class_name;
                                        ?>
                                        &nbsp;</td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="23">Mobile:</td>
                                    <td height="23"><?php echo $student->f_mobile; ?></td>
                                    <td height="23">&nbsp;</td>
                                    <td>Date Of Birth: </td>
                                    <td><?php
                                        $DateOfBirth = $student->birth_date;
                                        echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                        ?>
                                        &nbsp;</td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="12">Address:</td>
                                    <td height="12" colspan="4"><?php echo $oCurrentSchool->place; ?></td>
                                </tr>
                            </table></td>
                    </tr>
                    <tr align="left" valign="middle">
                        <td height="174">
                            <table width="100%" height="183" border="1" align="center">
                                <tr valign="middle" align="center" bgcolor="#E8E8E8">
                                    <td height="43" class="st411" align="left"><strong>SCHOLASTIC AREA</strong><br /></td>
                                    <td colspan="4" class="st411"><strong>TERM I</strong></td>
                                    <td colspan="4" class="st411"><strong>TERM II</strong></td>
                                    <td colspan="3" class="st411"><strong>Final Assessment</strong></td>
                                </tr>
                                <tr valign="top"  bgcolor="#C9C9C9">
                                    <td height="30" class="st411"><strong>Subjects</strong></td>
                                    <td class="st411">Unit-I</td>
                                    <td class="st411">Unit-II</td>
                                    <td width="47" class="st411">Term-I</td>
                                    <td width="44" class="st411">Total </td>
                                    <td width="50" class="st411">Unit-III</td>
                                    <td width="50" class="st411">Unit-IV</td>
                                    <td width="47" class="st411">Term-II</td>
                                    <td width="39" class="st411">Total </td>
                                    <td width="38" class="st411">Unit</td>
                                    <td width="37" class="st411">Term</td>
                                    <td width="80" class="st411"><span class="st4">Overall<br />
                                            (Unit+Term)</span></td>
                                </tr>
                                <?php
                                $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student->student_id, $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                while ($rowv = $subjects_querry->fetch()) {
                                    ?>       
                                    <tr valign="middle" align="center">
                                        <td width="138" height="38" class="st411" align="left"> <?php
                                            $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                            while ($rowu = $subjects->fetch()) {
                                                echo $rowu['name'];
                                            }
                                            ?>
                                        </td>
                                        <td width="38" class="st411"><?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                $u1 = $rowu['marks_obtained'];
                                                ?><?= $rowu['marks_obtained'] ?>
                                                <?php
                                            }
                                            ?></td>
                                        <td width="46" class="st411"><?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                $u1+=$rowu['marks_obtained'];
                                                ?><?= $rowu['marks_obtained'] ?>
                                                <?php
                                            }
                                            ?></td>
                                        <td class="st411"><?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '5', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                $t1 = $rowu['marks_obtained'];
                                                ?><?= $rowu['marks_obtained'] ?>
        <?php
    }
    ?></td>
                                        <td class="st411"><?php echo $total1 = $u1 + $t1; ?>
                                        </td>
                                        <td class="st411"><?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                $u2 = $rowu['marks_obtained'];
                                                ?><?= $rowu['marks_obtained'] ?>
                                                <?php
                                            }
                                            ?></td>
                                        <td class="st411">
                                            <?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '4', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                $u2+=$rowu['marks_obtained'];
                                                ?><?= $rowu['marks_obtained'] ?>
                                                <?php
                                            }
                                            ?></td>
                                        <td class="st411"><?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '6', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                $t2 = $rowu['marks_obtained'];
                                                ?><?= $rowu['marks_obtained'] ?>
        <?php
    }
    ?></td>
                                        <td class="st411"><?php echo $total2 = $u2 + $t2; ?></td>
                                        <td class="st411"><?php echo $unit = $u1 + $u2;  ?>
                                            &nbsp;</td>
                                        <td class="st411"><?php echo $total = $t1 + $t2; ?></td>
                                        <td class="st411"><?php
                                        echo $grandtotal = $unit + $total;
                                        $ttl+=$grandtotal;
                                        $i++;
                                        ?></td>
                                    </tr>
<?php }
?>
                                <tr valign="middle">
                                    <td height="42" colspan="10" align="left" class="st411"><strong>Total</strong></td>
                                    <td height="42" colspan="2"  align="center" class="st411"><strong>
                                            <br /><?php echo $ttl / $i; ?> (%)</strong>&nbsp;</td>
                                </tr>
                            </table></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td height="153" valign="top"><table width="100%" height="151" border="0" align="center">
                                <tr>
                                    <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: &nbsp;&nbsp;
                                            <?php
                                            $remark = Exam::get_exam_remarks($MSID, '', '', $student->student_id, $oCurrentUser->mysession);
                                            while ($rowur = $remark->fetch(PDO::FETCH_ASSOC)) {
                                                echo $rowur['remarks'];
                                            }
                                            ?>
                                        </strong><br/></td>
                                </tr>

                                <tr></tr>
                                <tr>
                                    <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                                    <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
                                </tr>
                            </table></td>
                    </tr>
                </table></td>
                </tr>
                </table>
                <p class="page"></p>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>