<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }/* $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 $id1=$_GET['id'];$sid = mysql_real_escape_string($id1);*/
if($_POST){$sid=$_POST['c'];
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
}else {
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 $id1=$_GET['id'];$sid = mysql_real_escape_string($id1);}


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$sid' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass']; $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate']; 
$Add_ReportC= $row['Add_ReportC']; 


} ?>::Report Card</title>
 <style>
p.page { page-break-after: always; }
 </style>
<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>       <style type="text/css">
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
-->
</style>
     <table width="750" height="684" border="1"   align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td height="678"><table width="100%" height="672" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="704" height="140" align="center">
              <table width="100%" height="108" align="center">
                <tr>
                  <td width="87" height="102" align="left"><table width="88" border="0" align="center">
                    <tr>
                      <td width="82" height="92"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
                    </tr>
                  </table></td>
                  <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
                    <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
                    <tr>
                      <td width="539" height="32" align="center" class="m1"> <?php echo $sname;?> </td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="b1"> <? echo   $Place;  ?> </td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="n1">Website:<? echo $Website;?>,E-mail:<? echo $EMail;?>,Ph:<? echo $Phone;?></td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="n1">Affiliated to CBSE ,Delhi ,Affiliation No.:<? echo $AffiliationNo;?></td>
                    </tr>
                  </table>                    <span class="vks">Record of Academic Performance <? echo $session; ?></span></td>
                </tr>
              </table>      </td>
          </tr>
       
            
         <tr align="left" valign="top">
            <td height="184"><table width="100%" height="181" border="0" align="center">
              <tr valign="top" class="st42">
                <td width="139" rowspan="4"><img src="<?php  if($Photo!=""){echo $Photo;} else { 	echo"../../images/myprofile1.png";} ?>" alt="" width="122" height="127" style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" /></td>
                <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                <td height="27"><? echo $Name;?></td>
                <td height="27">&nbsp;</td>
                <td width="106" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                <td width="105" ><? echo $sid;?>&nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="31">Father's Name:</td>
                <td width="238" height="31">Mr. <? echo $FatherName;?></td>
                <td width="11" height="31">&nbsp;</td>
                <td>Roll No.:</td>
                <td><? echo $Roll_No;?>&nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="32">Mother's Name:</td>
                <td height="32">Mrs. <? echo $MotherName;?></td>
                <td height="32">&nbsp;</td>
                <td>Class:</td>
                <td><? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
                  &nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="31">Mobile</td>
                <td height="31"><? echo $F_Mobile;?></td>
                <td height="31">&nbsp;</td>
                <td>Date Of Birth: </td>
                <td><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?>
                  &nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td width="139">&nbsp;</td>
                <td height="38">Address:</td>
                <td height="38" colspan="4"><? echo $Add_ReportC;?></td>
              </tr>
            </table></td>
          </tr>
          <tr align="left" valign="top">
            <td height="78">
            
            <? //if($ULevel=='9'){ ?>
            <table width="100%" height="177" border="1" align="center">
              <tr valign="top" bgcolor="#E8E8E8">
                <td height="44" align="center" class="st411" valign="middle">&nbsp;</td>
                <td height="44" colspan="2" align="center"valign="middle" class="st411"><h3><strong>Unit III</strong></h3></td>
                <td height="44" colspan="2" align="center"valign="middle" class="st411"><strong>Unit IV</strong></td>
              </tr>
              <tr valign="top"  bgcolor="#C9C9C9">
                <td width="277" height="42" class="st411"><strong>Subjects</strong></td>
                <td width="121" class="st411" align="center"><strong>MARKS OBTAINED</strong></td>
                <td width="97" class="st411" align="center"><strong>MAX MARKS</strong></td>
                <td width="105" class="st411"  align="center"><strong>MARKS OBTAINED</strong></td>
                <td width="96" class="st411"  align="center"><strong>MAX MARKS</strong></td>
              </tr>
              <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid' and AssId='3' "); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
              <tr valign="top">
                <td height="39" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
                <td align="center" class="st411">&nbsp;
                  <?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,RD.`MaxMarks` FROM 
`21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){ $Grade8=$gowy8['MarksObtained']; echo round($Grade8); ?>
                  &nbsp;&nbsp;</td>
                <td align="center" class="st411"><? echo $MaxMarks8=$gowy8['MaxMarks']; ?></td><? }?>
                <td align="center" class="st411"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){ $Grade8=$gowy8['MarksObtained']; echo round($Grade8); ?></td>
                <td align="center" class="st411"><? echo $MaxMarks8=$gowy8['MaxMarks']; ?></td>
               
                <? } ?>
              </tr>
              <?php   } ?>
              <tr valign="top">
                <td height="40" class="st411"><strong>Total</strong></td>
                <td align="center" class="st411">&nbsp;
                  <?php   $ghiy10=mysql_query($ghy10="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,Sum(RD.`MarksObtained`)AS tmarks ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy10=mysql_fetch_array($ghiy10)){ $Grade10=$gowy10['tmarks']; echo round($Grade10); } ?>
                  &nbsp;</td>
                <td align="center" class="st411"><?php   $ghiy11=mysql_query($ghy11="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,Sum(RD.`MaxMarks`)AS tmaxmarks FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy11=mysql_fetch_array($ghiy11)){ $Grade11=$gowy11['tmaxmarks']; echo round($Grade11); } ?></td>
                <td align="center" class="st411"><?php   $ghiy10=mysql_query($ghy10="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,Sum(RD.`MarksObtained`)AS tmarks ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy10=mysql_fetch_array($ghiy10)){ $Grade10=$gowy10['tmarks']; echo round($Grade10); } ?></td>
                <td align="center" class="st411"><?php   $ghiy11=mysql_query($ghy11="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,Sum(RD.`MaxMarks`)AS tmaxmarks FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy11=mysql_fetch_array($ghiy11)){ $Grade11=$gowy11['tmaxmarks']; echo round($Grade11); } ?></td>
              </tr>
            </table>
            
            </td>
          </tr>
          
          <tr align="left" valign="top">
            <td height="122" valign="top"><table width="100%" height="103" border="0" align="center">
              <tr>
               <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"> <? $att1=mysql_query($aq1="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='1'"); 
				 while($at1=mysql_fetch_array($att1)){ $Term1WD= $at1['TWD']; $Term1Att= $at1['TERMATT']; $Term1Att ;  $Term1WD ; $tatt= ($Term1Att/$Term1WD) * 100 ;  round($tatt,2) ;} ?> <strong>REMARKS: &nbsp;&nbsp;<? $trjjrm=mysql_query($qjjrm="Select Remarks from 21Remarks where SID='$sid' AND  MSID='$msid'  AND Session='$session'");
				 while($ttjjrm=mysql_fetch_array($trjjrm)){ echo $remarks=$ttjjrm['Remarks']; }?></strong><br/>
                  </td>
              </tr><? //}else {}?>
              <tr>
                <td width="234" height="74" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
              </tr>
            </table></td>
          </tr>
         
        </table></td>
      </tr>
</table>  
      <?php }}?>
</p></body>
</html>
