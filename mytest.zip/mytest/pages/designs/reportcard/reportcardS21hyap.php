<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<?php print_r($oCurrentSchool); ?>

</head>
<body>  
    <section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>
                <div class="box">

                    <?php
                    $id = http_get('param2');
                    $exam = http_get('param3');
                    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                    $ttl = 0;
                    $i = 0;
                    ?>
<table width="750" 
 height="636" border="1"   align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td height="630"><table width="100%" height="534" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top">
        <td width="704" height="120" align="center"><table width="100%" height="127" align="center">
          <tr>
            <td width="87" height="92" align="left" valign="top"><table width="88" border="0" align="center">
              <tr>
                <td width="82" height="77" align="center" valign="top"><img src="<img src="<?php
                                    if ($oCurrentSchool->logo_img != "") {
                                        echo CLIENT_URL . "/uploads/thumbs/" . $oCurrentSchool->logo_img;
                                    } else {
                                        echo ASSETS_FOLDER . "/img/aboutlogo.jpg";
                                    }
                                    ?> " alt="" width="75" height="75" /></td>
              </tr>
            </table></td>
            <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
              <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
              <tr>
                <td width="539" height="40" align="center" class="m1"><?php echo $sname.','.' '.$Place;  ?></td>
              </tr>
              <tr>
                <td height="34" align="center" class="n1"><b><? echo $Board_full_name;?>&nbsp;&nbsp;<? echo   '('.'CODE NO'.'.'.$RecNo.')';  ?></b></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="27" colspan="2" class="b1" align="center" valign="middle" bgcolor="#999999"><strong>ACHIEVEMENT RECORD &ndash; SESSION ( <? echo $session; ?>-<? echo $session2=$session+1; ?> )</strong></td>
            </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="86"><table width="100%" height="81" border="0" align="center">
          <tr valign="top" class="st42">
            <td><strong>Name :</strong></td>
            <td height="25"><strong><? echo $Name;?></strong></td>
            <td height="25"><strong>Class:</strong></td>
            <td height="25"><strong>
              <? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
-
<? $result2sec=mysql_query($sql2sec="select * from `4Sections` where  ID='$Section' And MSID='$msid'");
	  while($row2sec=mysql_fetch_array($result2sec)){ echo $row2sec['Sectionname'];  }?>
            </strong></td>
            <td ><strong>Date Of Birth:</strong></td>
            <td ><strong><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?></strong></td>
          </tr>
          <tr valign="top" class="st42">
          
            <td width="121"><strong>Father's Name:</strong></td>
            <td height="25"><strong><? echo   "Mr.".' '.$FatherName;?></strong></td>
            <td height="25"><strong>Roll No.:</strong></td>
            <td height="25"><strong><? echo $Roll_No;?></strong></td>
            <td width="111" ><strong>Admission No:&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td width="89" ><strong><? echo $AdmNo;?></strong>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="23"><strong>Attendance:</strong></td>
            <td width="237" height="23"><b>  <?php   $result7=mysql_query($sql7="SELECT * from `26TWDays` where  SID='$sid' and Term='1' and Session='$session' AND  MSID='$msid' ");
	  while($row7=mysql_fetch_array($result7)){ echo $TERMATT= $row7['TERMATT'].' '.'/'.$TWD= $row7['TWD'];}  
 ?></b></td>
            <td width="65" height="23">&nbsp;</td>
            <td width="81" height="23">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top"> 
        <td height="86"><table width="100%" height="128" border="1" align="center" background="../..<? echo $Watermark;?>" style="background-size:45%;    background-position:bottom; background-repeat:no-repeat" > 
          <tr valign="top" bgcolor="#E8E8E8">
            <td height="37" colspan="5" class="st411" align="center" valign="middle"><h3> SCHOLASTIC AREA</h3></td>
            </tr><!-- bgcolor="#E8E8E8"-->
          <tr valign="top">
            <td rowspan="2" class="st411"><strong>Subject</strong></td>
            <td height="20" colspan="3" align="center" class="st411"><strong>TERM I</strong></td>
            <td align="center" class="st411"><strong>Final Assessment</strong></td>
            </tr>
          
          <tr valign="top"   align="center">
            <td height="36" class="st411"><strong>FA1<br />
              10%</strong></td>
            <td class="st411"><strong>FA2<br />
              10%</strong></td>
            <td class="st411"><strong>SA1<br />
              30%</strong></td>
            <td width="245" class="st411"><strong>Overall<br />
              (FA+SA=50%)</strong></td>
            </tr>
          <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
          <tr valign="top" align="center">
            <td width="142" height="23" align="left" class="st411"><strong>
              <?  $phig=mysql_query($phg="SELECT Subject,Used_for_lib FROM `subjects` Where  MSID='$msid' And ID='$sb' order by ID"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject']; $Used_for_lib= $powg['Used_for_lib'];}?>
              </strong></td>
            <td width="133" class="st411"><strong>
              <?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?>
              </strong></td>
            <td width="94" class="st411"><strong>
              <?php $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?>
              </strong></td>
            <td class="st411"><strong>
              <?php $gr23=mysql_query($ghyn23="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g23=mysql_fetch_array($gr23)){echo $Gn23=$g23['Grade'];}?>
              </strong></td>
            <td class="st411"><strong>
              <?php if($Used_for_lib=='1'){ $gr2=mysql_query($ghyn2="select FL.msid,FL.stu_id,FL.name,FL.house,FL.cclass,FL.cclass,FL.subject,FL.mo as percent,G.grade,G.gradepoint,FL.t from(select TG.msid,TG.stu_id,TG.name,TG.house,TG.cclass,TG.subject,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.name,term1.house,term1.cclass,term1.subject,term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as 

term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.mysession,FA_PER.name,FA_PER.house,FA_PER.cclass,FA_PER.subjectid,FA_PER.subject,
FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from(select 

FA1.msid,FA1.stu_id,FA1.mysession,FA1.name,FA1.house,FA1.cclass,RD.subjectid,sub.subject,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id 

,S.mysession,S.name,S.house,S.admclassno+year(U.mydate)-year(S.fsdate)+COALESCE(sum(E.result),0) as cclass FROM `13Students` S inner join 91Users U on U.msid=S.msid 

and U.mydate between S.fsdate and S.sldate left join 14Exam E on E.msid=S.msid and E.s_id=S.id where U.myuid='$foo' and S.id=$sid) as FA1 inner join 21Repodata1 RD 

on RD.msid=FA1.msid and RD.studentid=FA1.stu_id and RD.session=FA1.mysession inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid) as FA_PER ) as term1 inner join 22Weightage W 

on W.msid=term1.msid and W.assid=term1.assid and term1.cclass between W.classfrom and W.classto) as TG group by TG.subject,TG.t order by TG.t) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and FL.cclass between G.classfrom and G.classto where FL.subjectid='$sb' And FL.t ='1'  ORDER BY FL.subjectid");while($g2=mysql_fetch_array($gr2)){echo $g2['grade'];}} else{ 
$gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $g2['Grade'];} }
?>
              &nbsp;</strong></td>
            </tr>
          <?php   }
		  ?>
          </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="70" valign="bottom"><table width="100%" border="1">
          <tr>
            <td height="28" colspan="2" valign="top" bgcolor="#999999" class="st4"><b>Result&nbsp;&nbsp; :</b><b>
              <? $ghi6=mysql_query($gh6="SELECT Q1.StudentId, Q1.Point,G.Grade FROM (Select StudentId, MSID, round(Sum( `MarksObtained`)/SUM(`MaxMarks`)*100,2) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$sid') Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto` and $cno between `ClassFrom` and `ClassTo`"); while($gow6=mysql_fetch_array($ghi6)){echo $Grade6=$gow6['Grade'];} ?>
            </b></td>
            <td height="28" colspan="4" valign="top" bgcolor="#999999" class="st4"><b>Remarks:
              <?   $jhi=mysql_query($jh="SELECT  * FROM `21Remarks_Inc_Grades` Where  MSID='$msid' and Grade='$Grade6'"); 		
 while($jow=mysql_fetch_array($jhi)){   echo  $Remarks= $jow['Remarks'];}?>
            </b></td>
            </tr>
          <tr>
            <td height="23" colspan="6" bgcolor="#FFFFFF" class="st4"><strong>SCHOLASTIC AREAS              (GRADING ON 9 POINT SCALE)</strong></td>
            </tr>
          <tr>
            <td width="16%" class="st4">MARKS RANGE</td>
            <td width="9%" class="st4">GRADE</td>
            <td width="34%" class="st4">GRADE POINT</td>
            <td width="18%" class="st4">MARKS RANGE</td>
            <td width="8%" class="st4">GRADE</td>
            <td width="15%" class="st4">GRADE POINT</td>
            </tr>
          <tr class="st4">
            <td>91-100</td>
            <td>A1</td>
            <td>10</td>
            <td>51-60</td>
            <td>C1</td>
            <td>6</td>
            </tr>
          <tr class="st4">
            <td>81-90</td>
            <td>A2</td>
            <td>9</td>
            <td>41-50</td>
            <td>C2</td>
            <td>5</td>
            </tr>
          <tr class="st4">
            <td>71-80</td>
            <td>B1</td>
            <td>8</td>
            <td>33-40</td>
            <td>D</td>
            <td>4</td>
            </tr>
          <tr class="st4">
            <td>61-70</td>
            <td>B2</td>
            <td>7</td>
            <td>21-32</td>
            <td>E1</td>
            <td>3</td>
            </tr>
          <tr class="st4">
            <td colspan="3" bgcolor="#999999"><strong>First Term: FA1 (10%) + FA2 (10%) + SA1 (30%) = 50%</strong></td>
            <td>20 And Below</td>
            <td>E2</td>
            <td>2</td>
            </tr>
          </table>
          <table width="100%%" height="74">
            <tr>
              <td width="24%" height="47" class="st4">&nbsp;</td>
              <td width="18%">&nbsp;</td>
              <td width="35%" height="47">&nbsp;</td>
              <td width="23%">&nbsp;</td>
              </tr>
            <tr class="st4">
              <td height="18" colspan="2"><strong>CLASS TEACHER</strong></td>
              <td width="35%" height="18"><strong>PARENT</strong></td>
              <td width="23%"><strong>PRINCIPAL</strong></td>
              </tr>
            </table>
          </td>
      </tr>
    </table></td>
  </tr>
</table>
 </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
 <p class="page"></p>


