<link href="<?php = ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();

            $classID = 6;
            $data = array('class' => $classID);
            $total_no_recrd = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
            while ($rowx = $total_no_recrd->fetch(PDO::FETCH_OBJ)) {

                $id = $rowx->student_id;

//           $id = http_get('param2');
                $exam = http_get('param3');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                $ttl = 0;
                $i = 0;
                ?>

                <table width="774" border="1" align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td width="762"><table width="100%" height="520" align="center" bordercolor="#2A3F00">
                                <tr align="left" valign="top">
                                    <td width="875" height="76">
                                        <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
                                </tr>
                                <tr align="left" valign="top">
                                    <td height="4"></td>
                                </tr>
                                <tr align="left" valign="top">
                                    <td align="center" valign="top" class="vks">
                                        <table width="100%" height="188" border="1">
                                            <tr bgcolor="#E4E4E4">
                                                <td height="42" colspan="7" align="center" class="st4"><strong>Report For Class 
                                                        <?php
                                                        $cls = Master::get_classes($MSID, '', '', '', $classID)->fetch(PDO::FETCH_OBJ);
                                                        echo $cls->class_name;
                                                        ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td width="209" rowspan="2" class="st4"><strong >Subject</strong></td>
                                                <td colspan="6" align="center" class="st4"><strong>MARKS OBTAINED</strong></td>
                                            </tr>
    <?php if ($classID <= 10) { ?>
                                                <tr>
                                                    <td width="85" align="center" class="st4"><strong>FA1</strong></td>
                                                    <td width="73" align="center" class="st4"><strong>FA2</strong></td>
                                                    <td width="73" align="center" class="st4"><strong>SA1</strong></td>
                                                    <td width="86" align="center" class="st4"><strong>FA3</strong></td>
                                                    <td width="95" align="center" class="st4"><strong>FA4</strong></td>
                                                    <td width="87" align="center" class="st4"><strong>SA2</strong></td>
                                                </tr>
    <?php } else { ?>
                                                <tr>
                                                    <td width="209" align="center" class="st4"><strong>Unit 1</strong></td>
                                                    <td width="85" align="center" class="st4"><strong>Unit 2</strong></td>
                                                    <td width="73" align="center" class="st4"><strong>Term 1</strong></td>
                                                    <td width="73" align="center" class="st4"><strong>Unit 3</strong></td>
                                                    <td width="86" align="center" class="st4"><strong>Unit 4</strong></td>
                                                    <td width="95" align="center" class="st4"><strong>Term 2</strong></td>
                                                </tr>
    <?php } ?>

                                            <tr>
                                                <td height="24" colspan="7" align="center" class="st4">
                                                    <strong>Student ID: <?php = $student->student_id ?> 
                                                        Student Name: <?php = $student->name ?> </strong></td></tr>

                                            <?php
                                            $subjects_querry = Exam::get_accademinc_performance($MSID, $id, '', '', '', '', $id, $oCurrentUser->mysession, $data, $distinct)
                                            while ($rowv = $subjects_querry->fetch()) {
                                                ?>
                                                <tr>
                                                    <td height="22" valign="top" class="st4">
                                                        <?php
                                                        $subname = SuperAdmin::get_school_subject($MSID);
                                                        while ($rowv = $subname->fetch()) {

                                                            echo $rowu['name'];
                                                        }
                                                        ?>    

                                                    </td>
                                                    <td align="center" valign="top" class="st4">
                                                    </td>
                                                    <td align="center" valign="top" class="st4">
                                                        <?php
                                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
                                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                            $u1 = $rowu['marks_obtained'];
                                                            $mm1 = $rowu['max_marks'];
                                                             $rowu['Grade'];
                                                        }
                                                        ?></td>
                                                    <td align="center" valign="top" class="st4">&nbsp;<?php
                                                         $ghiy2 = mysql_query($ghy2 = "SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='5' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`");
                                                        while ($gowy2 = mysql_fetch_array($ghiy2)) {
                                                            echo $Marks_obtained2 = $gowy2['MarksObtained'];
                                                        }
                                                        ?></td>
                                                    <td align="center" valign="top" class="st4">&nbsp;<?php
                                                       $ghiy3 = mysql_query($ghy3 = "SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='3' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`");
                                                        while ($gowy3 = mysql_fetch_array($ghiy3)) {
                                                            echo $Marks_obtained3 = $gowy3['MarksObtained'];
                                                        }
                                                        ?></td>
                                                    <td align="center" valign="top" class="st4">&nbsp;<?php
                                                        $ghiy4 = mysql_query($ghy4 = "SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='4' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`");
                                                        while ($gowy4 = mysql_fetch_array($ghiy4)) {
                                                            echo $Marks_obtained4 = $gowy4['MarksObtained'];
                                                        }
                                                        ?></td>
                                                    <td align="center" valign="top" class="st4">&nbsp;<?php
                                                        $ghiy5 = mysql_query($ghy5 = "SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='6' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`");
                                                        while ($gowy5 = mysql_fetch_array($ghiy5)) {
                                                            echo $Marks_obtained5 = $gowy5['MarksObtained'];
                                                        }
                                                        ?></td>
                                                </tr>
    <?php } ?>
                                            <tr>
                                                <td height="22" colspan="7" align="right"><span class="st4">
                                                        <strong>Total Marks:  <?php
                                                            $trj = mysql_query($qj = "Select Sum(MarksObtained )AS tmarks from `21Repodata1` where MSID='$msid' and StudentId='$s_id' And Session='$session'");
                                                            while ($ttj = mysql_fetch_array($trj)) {
                                                                $tmarks = $ttj['tmarks'];
                                                                echo $roundmk = round($tmarks, 2);
                                                            }
                                                            ?>/<?php
                                                            $trj1 = mysql_query($qj1 = "Select Sum(MaxMarks)AS tomarks from `21Repodata1` where MSID='$msid' and StudentId='$s_id' And Session='$session'");
                                                            while ($ttj1 = mysql_fetch_array($trj1)) {
                                                                echo $tomarks = $ttj1['tomarks'];
                                                            }
                                                            ?>&nbsp;&nbsp;&nbsp; Percentage: 
    <?php php echo $xr4 = round($roundmk / $tomarks * 100, 2); ?>%</strong>
                                                    </span></td></tr>
    <?php php
} ?>
                                    </table>
                                    <br />
                                    <br /></td>
                            </tr>
                        </table></td>
                </tr>
            </table>
        <!--<p class="page"></p>--></body>
            </html>
<?php php } ?>