
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $exam = http_get('param3');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                ?>
                <br>
                <br><?php
                ?>




                <table width="708" height="741" border="1"   align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td width="596">        <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td></tr>
                    <tr>
                        <td align="center">     <span class="vks">Record of Academic Performance <?php echo $oCurrentUser->mysession; ?></span></td>
                    </tr>
                    <?php //print_r($student); ?>

                    <tr align="left" valign="top">
                        <td height="103">
                            <table width="100%" height="149" border="0" align="center">
                                <tr valign="top" class="st42">
                                    <td width="139" rowspan="5">
                                        <img style="padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php
                                        if ($student->std_image != "") {
                                            echo $student->std_image;
                                        } else {
                                            echo ASSETS_FOLDER . "/img//myprofile1.png";
                                        }
                                        ?>" width="122" height="127"></td>
                                    <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                                    <td height="27"><?= $student->name; ?></td>
                                    <td height="27">&nbsp;</td>
                                    <td width="106"> Admission No:</td>
                                    <td width="105"><?php
                                        if (@$oCurrentSchool->ViewOption == '0') {
                                            echo $student->student_id;
                                        } else {
                                            echo $student->admno;
                                        }
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="31">Father's Name:</td>
                                    <td width="238" height="31">Mr. <?= $student->f_name; ?></td>
                                    <td width="11" height="31">&nbsp;</td>
                                    <td><?php if (@$student->roll_no != '0') { ?>Roll No.: <?php } ?></td>
                                    <td><?php
                                        if (@$student->roll_no != '0') {
                                            echo $student->roll_no;
                                        }
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="28">Mother's Name:</td>
                                    <td height="28">Mrs. <?php echo $student->m_name; ?></td>
                                    <td height="28">&nbsp;</td>
                                    <td>Class:</td>
                                    <td><?php
                                        $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                        echo $cls->class_name;
                                        ?>
                                        &nbsp;</td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="23">Mobile:</td>
                                    <td height="23"><?php echo $student->f_mobile; ?></td>
                                    <td height="23">&nbsp;</td>
                                    <td>Date Of Birth: </td>
                                    <td><?php
                                        $DateOfBirth = $student->birth_date;
                                        echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                        ?>
                                        &nbsp;</td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="12">Address:</td>
                                    <td height="12" colspan="4"><?php echo $oCurrentSchool->place; ?></td>
                                </tr>
                            </table></td>
                    </tr>

                    <tr align="left" valign="top">
                        <td height="78">

                            <table width="98%" height="174" border="1" align="center">
                                <tr valign="top" bgcolor="#E8E8E8">
                                    <td height="30" class="st411" align="center"><strong>SCHOLASTIC AREA<br />
                                            (5 point scale)</strong></td>
                                          <!--<td colspan="3" class="st411" align="center">TERM I</td><td colspan="3" class="st411" align="center">TERM II</td>
                                         <!-- <td class="st411" align="center">Final Assessment</td>-->
                                    <td align="center" class="st411"><strong>TERM I</strong></td>
                                </tr>
                                <tr valign="top"  bgcolor="#C9C9C9">
                                    <td height="30" class="st411" align="center"><strong>Subjects</strong></td>
                                    <?php
                                    $val = "";
                                    if ($exam == "FA1")
                                        $val = 1;
                                    else if ($exam == "FA2")
                                        $val = 2;
                                    else if ($exam == "FA3")
                                        $val = 3;
                                    else if ($exam == "FA4")
                                        $val = 4;
                                    else if ($exam == "SA1")
                                        $sa = 5;
                                    else if ($exam == "SA2")
                                        $sa = 6;
                                    $sql_assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), '', $val, '', 'Term 1', 'YES');
                                    while ($rowv = $sql_assesments->fetch()) {
                                        ?>
                                        <td width="345" align="center" class="st411"><strong> <?= $rowv['title'] ?></strong></td>
                                    <?php } ?>
                                </tr>  <?php
                                $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student->student_id, $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                while ($rowv = $subjects_querry->fetch()) {
                                    ?>                                 <tr valign="top"> <?php
                                        $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                        while ($rowu = $subjects->fetch()) {
                                            ?>
                                            <td width="315" height="42" class="st411" align="center"><?= $rowu['name'] ?></td>
                                            <?php
                                        }
                                        ?>
                                        <td align="center" class="st411">  <?php
                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                ?><?= $rowu['Grade'] ?>
                                                <?php
                                            }
                                            ?></td>
                                    </tr>
                                <?php }
                                ?>

                                <tr valign="top">
                                    <td height="45" colspan="2" align="left" class="st2">Note:A+=90%-100%;A=75%-89%;B=56%-74%;C=35%-55%;D=Below 35%</td>

                                </tr>
                            </table>
                        </td>
                    </tr>

                    <tr align="left" valign="top">
                        <td height="122" valign="top"><table width="100%" height="90" border="0" align="center">
                                <tr>
                                    <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: 
                                            <?php
                                            $remark = Exam::get_exam_remarks($MSID, '', '', $student->student_id, $oCurrentUser->mysession);
                                            while ($rowur = $remark->fetch(PDO::FETCH_ASSOC)) {
                                                echo $rowur['remarks'];
                                            }
                                            ?>
                                        </strong><br/>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="234" height="61" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                                    <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
                                </tr>
                            </table></td>
                    </tr> </table></td>
                </tr>
                </table> 
                <br />

                <form id="contactform" name="contactform" method="post" action="">

                    <input type="button" value="Print" onclick="printpage();">
                    <input type="submit" name="Submit" value="Exit" />
                </form>












            </div>
            <!-- /.box -->
        </div>
    </div>
</section>









