
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $exam = http_get('param3');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                $ttl = 0;
                $i = 0;
                ?>
                <br>
                <br><?php
                ?>

                <table width="750" height="737" border="1"   align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td >   <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td></tr>
                    <tr><td Align="center">    <p class="vks">Evaluation - 1 Report <?php echo $oCurrentUser->mysession; ?></p></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td height="103">
                            <table width="100%" height="131" border="1" align="center">
                                <tr valign="top" class="st42">
                                    <td width="124" rowspan="3">
                                        <img style="padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php
                                        if ($student->std_image != "") {
                                            echo $student->std_image;
                                        } else {
                                            echo ASSETS_FOLDER . "/img//myprofile1.png";
                                        }
                                        ?>" width="122" height="127"></td>
                                    <td width="118">Student Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                                    <td height="40"><?= $student->name; ?></td>
                                    <td height="40">&nbsp;</td>
                                    <td width="105">Class:</td>
                                    <td width="107"><?php
                                        $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                        echo $cls->class_name;
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                  <td height="34"><?php if (@$student->roll_no != '0') { ?>Roll No.: <?php } ?></td>
                                  <td height="34"><?php
                                        if (@$student->roll_no != '0') {
                                            echo $student->roll_no;
                                        }
                                        ?></td>
                                  <td height="34">&nbsp;</td>
                                  <td>Admission No:</td>
                                  <td><?php
                                        if (@$oCurrentSchool->ViewOption == '0') {
                                            echo $student->student_id;
                                        } else {
                                            echo $student->admno;
                                        }
                                        ?></td>
                                </tr>
                                <tr valign="top" class="st42">
                                    <td height="47">Father's Name:</td>
                                    <td width="234" height="47">Mr. <?= $student->f_name; ?></td>
                                    <td width="10" height="47">&nbsp;</td>
                                    <td>Mother's Name:</td>
                                    <td>Mrs. <?php echo $student->m_name; ?></td>
                                </tr>
                      </table></td>
                    </tr>
                    <tr align="left" valign="middle">
                        <td height="174">
                            <table width="100%" height="183" border="1" align="center">
                                <tr valign="middle" align="center" bgcolor="#E8E8E8">
                                    <td height="43" class="st411" align="left"><strong>SCHOLASTIC AREA</strong><br /></td>
                                    <td class="st411"><strong>Credit-1</strong></td>
                                    <td class="st411"><strong>Credit-2</strong></td>
                                    <td colspan="3" class="st411"><strong>Evaluation-1</strong></td>
                                </tr>
                                <tr valign="top"  bgcolor="#C9C9C9">
                                    <td height="30" class="st411"><strong>Subjects</strong></td>
                                    <td align="center" class="st411">Grade</td>
                                    <td align="center" class="st411">Grade</td>
                                    <td colspan="3" align="center" class="st411">Credit 1+2<span class="st4"></span></td>
                                </tr>
                                <?php
                                $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student->student_id, $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                while ($rowv = $subjects_querry->fetch()) {
                                    ?>       
                                    <tr valign="middle" align="center">
                                        <td width="138" height="38" class="st411" align="left"> <?=$rowv['datesheet_id'];
                                            $subjects = Exam::get_datesheet_dtl($MSID, $rowv['datesheet_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                            while ($rowu = $subjects->fetch()) {
                                                  $rowu['subject'];
                                                
                                                $subject = Exam::get_datesheet_sub($MSID, $rowu['subject'], array('selectAll' => 'true'), '', '', 'YES', '');
                                            while ($rowy = $subject->fetch()) {
                                                echo $rowy['name'];
                                            } 
                                            } 
                                            ?>
                                        </td>
                                        <td class="st411">&nbsp;</td>
                                        <td class="st411">&nbsp;</td>
                                        <td colspan="3" class="st411">&nbsp;</td>
                                    </tr>
<?php }
?>
                                <tr valign="middle">
                                    <td height="42" colspan="4" align="left" class="st411"><strong>Total</strong></td>
                                    <td height="42" colspan="2"  align="center" class="st411"><strong>
                                            <br />
                                            (%)</strong>&nbsp;</td>
                                </tr>
                            </table></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td height="153" valign="top"><table width="100%" height="151" border="0" align="center">
                                <tr>
                                    <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: &nbsp;&nbsp;
                                            <?php
                                            $remark = Exam::get_exam_remarks($MSID, '', '', $student->student_id, $oCurrentUser->mysession);
                                            while ($rowur = $remark->fetch(PDO::FETCH_ASSOC)) {
                                                echo $rowur['remarks'];
                                            }
                                            ?>
                                        </strong><br/></td>
                                </tr>

                                <tr></tr>
                                <tr>
                                    <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                                    <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
                                </tr>
                            </table></td>
                    </tr>
                </table></td>
                </tr>
                </table>
                <p class="page"></p>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>