<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<?php print_r($oCurrentSchool); ?>

</head>
<body>  
    <section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>
                <div class="box">

                    <?php
                    $id = http_get('param2');
                    $exam = http_get('param3');
                    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                    $ttl = 0;
                    $i = 0;
                    ?>
<table width="756" height="556" border="1"   align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td height="550"><table width="100%" height="538" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top">
        <td width="704" height="120" align="center"><table width="100%" height="118" align="center">
          <tr>
            <td width="87" height="83" align="left" valign="top"><table width="88" border="0" align="center">
              <tr>
                <td width="82" height="77" align="center" valign="top"><img src="<?php
                                    if ($oCurrentSchool->logo_img != "") {
                                        echo CLIENT_URL . "/uploads/thumbs/" . $oCurrentSchool->logo_img;
                                    } else {
                                        echo ASSETS_FOLDER . "/img/aboutlogo.jpg";
                                    }
                                    ?>" alt="" width="75" height="75" /></td>
              </tr>
            </table></td>
            <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
              <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
              <tr>
                <td width="539" height="40" align="center" class="m1"> <?= $oCurrentSchool->name ?> <?= $oCurrentSchool->place ?></td>
              </tr>
              <tr>
                <td height="34" align="center" class="n1"><b><?= Board_full_name;?>&nbsp;&nbsp;<?= $oCurrentSchool->place ?> </b></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="27" colspan="2" class="b1" align="center" valign="middle" bgcolor="#999999"><strong>ACHIEVEMENT RECORD &ndash; SESSION ( <? echo $session; ?>-<? echo $session2=$session+1; ?> )</strong></td>
            </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="80"><table width="100%" height="78" border="0" align="center">
          <tr valign="top" class="st42">
            <td><strong>Name :</strong></td>
            <td height="25"><strong><? echo $Name;?></strong></td>
            <td height="25"><strong>Class:</strong></td>
            <td height="25"><strong>
              <? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
-
<? $result2sec=mysql_query($sql2sec="select * from `4Sections` where  ID='$Section' And MSID='$msid'");
	  while($row2sec=mysql_fetch_array($result2sec)){ echo $row2sec['Sectionname'];  }?>
            </strong></td>
            <td ><strong>Date Of Birth:</strong></td>
            <td ><strong><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?></strong></td>
          </tr>
          <tr valign="top" class="st42">
          
            <td width="121"><strong>Father's Name:</strong></td>
            <td height="25"><strong><? echo   "Mr.".' '.$FatherName;?></strong></td>
            <td height="25"><strong>Roll No.:</strong></td>
            <td height="25"><strong><? echo $Roll_No;?></strong></td>
            <td width="111" ><strong>Admission No:&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td width="89" ><strong><? echo $AdmNo;?></strong>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="20"><strong>Attendance:</strong></td>
            <td width="237" height="20"><b>  <?php   $result7=mysql_query($sql7="SELECT * from `26TWDays` where  SID='$sid' and Term='1' and Session='$session' AND  MSID='$msid' ");
	  while($row7=mysql_fetch_array($result7)){ echo $TERMATT= $row7['TERMATT'].' '.'/'.$TWD= $row7['TWD'];}  
 ?></b></td>
            <td width="65" height="20">&nbsp;</td>
            <td width="81" height="20">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="86"><table width="100%" height="167" border="1" align="center" background="../..<? echo $Watermark;?>" style="background-size:44%;    background-position:bottom; background-repeat:no-repeat" > 
        <tr valign="top" bgcolor="#E8E8E8">
            <td height="31" colspan="10" class="st411" align="center" valign="middle"><h3>PART &ndash; 1 : SCHOLASTIC AREA</h3></td>
            </tr><!-- bgcolor="#E8E8E8"-->
          <tr valign="top">
            <td rowspan="2" class="st411"><strong>Subject</strong></td>
            <td height="20" colspan="4" align="center" class="st411"><strong>TERM I</strong></td>
            <td colspan="4" align="center" class="st411"><strong>TERM 2</strong></td>
            <td width="151" align="center" class="st411"><strong>Final Assessment</strong></td>
          </tr>
         
          <tr valign="top"   align="center">
            <td height="36" class="st411"><strong>FA1<br />
              10%</strong></td>
            <td class="st411"><strong>FA2<br />
              10%</strong></td>
            <td width="50" class="st411"><strong>SA1<br />
              30%</strong></td>
            <td width="51" class="st411"><strong>Total<br />
              50%</strong></td>
            <td width="56" class="st411"><strong>FA3<br />
              10%</strong></td>
            <td width="49" class="st411"><strong>FA4<br />
              10%</strong></td>
            <td width="51" class="st411"><strong>SA2<br />
              30%</strong></td>
            <td width="57" class="st411"><strong>Total<br />
              50%</strong></td>
            <td class="st411"><strong>Overall Grade<br />
              100%</strong></td>
            </tr>
          <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
          <tr valign="top" align="center">
            <td height="16" class="st411"><?php
                                                            $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                                            while ($rowu = $subjects->fetch()) {
                                                                echo $rowu['name'];
                                                            }
                                                            ?></td>
            <td class="st411"><?php
                                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                                $u1 = $rowu['marks_obtained'];
                                                                $mm1 = $rowu['max_marks'];
                                                                ?>
              <?= $rowu['Grade'] ?>
              <?php
                                                            }
                                                            ?></td>
            <td class="st411"><?php
                                                            $fa2 = Exam::exam_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa2->fetch()) {
                                                                $u1 += $rowu['marks_obtained'];
                                                                $mm1 += $rowu['max_marks'];
                                                                ?>
              <?= $rowu['Grade'] ?>
              <?php
                                                            }
                                                            ?></td>
            <td class="st411"><?php
                                                            $sa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '5', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $sa1->fetch()) {
                                                                $t1 = $rowu['marks_obtained'];
                                                                $tm1 = $rowu['max_marks'];
                                                                ?>
              <?= $rowu['Grade'] ?>
              <?php
                                                            }
                                                            ?></td>
            <td class="st411"><?php
                                                            $overall = Exam::exam_term_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id']);
                                                            while ($rowu = $overall->fetch()) {
                                                                ?>
              <?= $rowu['grade'] ?>
              <?php } ?></td>
            <td class="st411"><?php
                                                            $fa3 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa3->fetch(PDO::FETCH_ASSOC)) {
                                                                $u2 = $rowu['marks_obtained'];
                                                                $mm2 = $rowu['max_marks'];
                                                                ?>
              <?= $rowu['Grade'] ?>
              <?php
                                                            }
                                                            ?></td>
            <td class="st411"><?php
                                                            $fa4 = Exam::exam_grade_calculater($MSID, $student->student_id, '4', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa4->fetch()) {
                                                                $u2 += $rowu['marks_obtained'];
                                                                $mm2 += $rowu['max_marks'];
                                                                ?>
              <?= $rowu['Grade'] ?>
              <?php
                                                            }
                                                            ?></td>
            <td class="st411"><?php
                                                            $fa5 = Exam::exam_grade_calculater($MSID, $student->student_id, '6', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa5->fetch()) {
                                                                $t2 = $rowu['marks_obtained'];
                                                                $tm2 = $rowu['max_marks'];
                                                                ?>
              <?= $rowu['Grade'] ?>
              <?php
                                                            }
                                                            ?></td>
            <td class="st411"><?php
                                                            $overall = Exam::exam_term_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id']);
                                                            while ($rowu = $overall->fetch()) {
                                                                ?>
              <?= $rowu['grade'] ?>
              <?php } ?></td>
            <td class="st411"><?php
                                                            $oa = Exam::exam_Subjectwise_overallgrade_calculater($MSID, $student->student_id, $rowv['subject_id']);
                                                            while ($rowu = $oa->fetch()) {
                                                                ?>
              <?= $rowu['grade'] ?>
              <?php } ?></td>
            </tr>
          <?php   }
		  ?>
        </table></td>
  </tr>
      <tr align="left" valign="top">
        <td height="198"><table width="100%" border="1" align="center">
          <tr>
            <td height="23" colspan="4" align="center" valign="top" bgcolor="#E8E8E8" class="st4"><strong>PART-2 : CO &ndash; SCHOLASTIC AREAS</strong></td>
            </tr>
          <tr>
            <td height="23" colspan="4" align="center" valign="top" bgcolor="#E8E8E8" class="st4"><strong>PART 2 (A) : LIFE SKILLS</strong></td>
            </tr>
          <tr valign="top" >
            <td width="7%" height="22" valign="middle" class="st4"><strong>Sr.No.</strong></td>
            <td width="29%" valign="middle" class="st4"><strong>Activity</strong></td>
            <td width="10%" align="center" valign="middle" class="st4"><strong> Grade</strong></td>
            <td width="54%" valign="middle" class="st4"><strong>Descriptive Indicators</strong></td>
          </tr>
          <tr valign="top">
            <td height="36" class="st4">01</td>
            <td class="st4">THINKING SKILLS</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='THINKING SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sb1 = $tt['Indicator'];
//                                                        echo "$Name " . " $sb1";
//                                                    }
                                                        ?></td>
          </tr>
          <tr valign="top">
            <td height="34" class="st4">02</td>
            <td class="st4">SOCIAL SKILLS</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='SOCIAL SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi = $tt1['Indicator'];
//                                                        echo "$Name " . " $sbi";
//                                                    }
                                                        ?></td>
          </tr>
          <tr valign="top">
            <td height="35" class="st4">03</td>
            <td class="st4">EMOTIONAL SKILLS </td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='EMOTIONAL SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi1 = $tt2['Indicator'];
//                                                        echo "$Name " . " $sbi1";
//                                                    }
                                                        ?></td>
          </tr>
          <tr valign="top">
            <td height="20" colspan="4" align="center" bgcolor="#E8E8E8" class="st4"><strong>PART 2 (B) : WORK EDUCATION</strong></td>
          </tr>
          <tr valign="top">
            <td height="22" class="st4"><strong>01</strong></td>
            <td class="st4">WORK EDUCATION</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='WORK EDUCATION'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi3 = $tt3['Indicator'];
//                                                        echo "$Name " . " $sbi3";
//                                                    }
                                                        ?></td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
  <p class="page"></p><table width="756"  border="1"   align="center" >
  <tr>
    <td><table width="100%" height="812" align="center" bordercolor="#2A3F00">
      
      <tr align="left" valign="top">
        <td height="78"><table width="100%" height="392" border="1" align="center">
          <tr valign="top">
            <td height="20" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 2 (C) : VISUAL AND PERFORMING ARTS</strong></td>
          </tr>
          <tr valign="top">
            <td height="23" class="st4"><strong>01</strong></td>
            <td width="215" class="st4">VISUAL AND PERFORMING ARTS</td>
            <td width="71" class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='VISUAL AND PERFORMING ARTS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td width="389" class="st4"><?php
//                                                        $sbi4 = $tt4['Indicator'];
//                                                        echo "$Name " . " $sbi4";
//                                                    }
                                                        ?></td>
            </tr>
          <tr valign="top">
            <td height="20" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 2 (D)-ATTITUDE &amp; VALUES</strong></td>
          </tr>
          <tr valign="top">
            <td height="33" class="st4">1.0</td>
            <td colspan="3" class="st4">ATTITUDE TOWARDS</td>
          </tr>
          <tr valign="top">
            <td height="22" class="st4">1.1</td>
            <td class="st4">TEACHERS</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='TEACHERS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi5 = $tt5['Indicator'];
//                                                        echo "$Name " . " $sbi5";
//                                                    }
                                                        ?></td>
            </tr>
          <tr valign="top">
            <td height="22" class="st4">1.2</td>
            <td class="st4">SCHOOL-MATES</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='SCHOOL-MATES'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi16 = $tt16['Indicator'];
//                                                        echo "$Name " . " $sbi16";
//                                                    }
                                                        ?></td>
            </tr>
          <tr valign="top">
            <td height="25" class="st4">1.3</td>
            <td class="st4">SCHOOL PROGRAMMES AND ENVIORNMENT</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='SCHOOL PROGRAMMES AND ENVIORNMENT'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi6 = $tt6['Indicator'];
//                                                        echo "$Name " . " $sbi6";
//                                                    }
                                                        ?></td>
            </tr>
          <tr valign="top">
            <td height="22" class="st4">2.0</td>
            <td class="st4">VALUE SYSTEM</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='VALUE SYSTEM'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi7 = $tt7['Indicator'];
//                                                        echo "$Name " . " $sbi7";
//                                                    }
                                                        ?></td>
            </tr>
          <tr valign="top">
            <td height="32" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 3 (A) CO-SCHOLASTIC ACTIVITIES</strong></td>
          </tr>
          <tr valign="top">
            <td width="35" height="25" class="st4">01</td>
            <td class="st4">LITERARY AND CREATIVE SKILLS</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='LITERARY AND CREATIVE SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi8 = $tt8['Indicator'];
//                                                        echo "$Name " . " $sbi8";
//                                                    }
                                                        ?></td>
            </tr>
          <tr valign="top">
            <td height="22" class="st4">02</td>
            <td class="st4">SCIENTIFIC SKILLS</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='SCIENTIFIC SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi9 = $tt9['Indicator'];
//                                                        echo "$Name " . " $sbi9";
//                                                    }
                                                        ?></td>
            <!-- </tr>
          <tr valign="top">
            <td height="32" class="st4">02</td>
            <td class="st4">Clubs (Eco club, Health and wellness club and others)</td>
            <td class="st4"><?php 
				/* $tr9=mysql_query($q9="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCIENTIFIC SKILLS' and MSID='$msid' and Session='$session'");
				 while($tt9=mysql_fetch_array($tr9)){  $sbg9= $tt9['Marks']; $tr111=mysql_query($q111="Select * from grade2 where GRADE_ID='$sbg9'");
				 while($tt111=mysql_fetch_array($tr111)){echo  $sbo11= $tt111['GRADE_NAME']; }*/ ?></td>
            <td class="st4"><?php /*$sbi9= $tt9['Indicator'];$ophi=mysql_query($oph="SELECT * FROM `25IndicatorDesc` Where Grade='$sbo11' And  PartNo='SCIENTIFIC SKILLS' And  MSID='$msid'"); while($opow=mysql_fetch_array($ophi)){      $opow['Grade'];     $opu1=  $opow['Des']; } echo "$Name "." $opu1";} */ ?></td>
          </tr>-->
          <tr valign="top">
            <td height="26" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 3 (b) HEALTH AND PHYSICAL EDUCATION</strong></td>
          </tr>
          <tr valign="top">
            <td height="22" class="st4">01</td>
            <td class="st4">YOGA</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='YOGA'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi10 = $tt10['Indicator'];
//                                                        echo "$Name " . " $sbi10";
//                                                    }
                                                        ?></td>
            </tr>
          <tr valign="top">
            <td height="35" class="st4">02</td>
            <td class="st4">SPORTS/ INDIGENOUS SPORTS</td>
            <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $oCurrentUser->mysession . "'  And GI.title='Self Awareness'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
            <td class="st4"><?php
//                                                        $sbi11 = $tt11['Indicator'];
//                                                        echo "$Name " . " $sbi11";
//                                                    }
                                                        ?></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="410"><table width="100%" border="1">
         
          <tr>
            <td width="27%" rowspan="2" class="st4" align="center" valign="middle" bgcolor="#E8E8E8" ><strong>HEALTH DATA</strong></td>
            <td width="9%" class="st4" align="center">HEIGHT</td>
            <td width="9%" class="st4" align="center">WEIGHT</td>
            <!--<td width="10%" height="26" class="st4" align="center">BLOOD GROUP</td>-->
            <!--<td width="31%" align="center" class="st4">DENTAL HYGIENE</td>-->
          </tr>
          <?php $health_data = Exam::get_exam_health_data('$MSID', '', '', $student->student_id, $oCurrentUser->mysession, $oCurrentUser->mysession, '2')->fetch(PDO::FETCH_OBJ); ?>
          <tr>
            <td height="23" align="center" class="st4"><?= $health_data->height ?></td>
            <td align="center" class="st4"><?= $health_data->weight ?></td>
            <!--<td align="center" class="st4"><? /*echo $bgroup ;*/ ?></td>-->
            <!-- <td align="center" class="st4"><? //echo $dental ; ?></td>-->
          </tr>
        </table>
          <table width="100%%" height="340">
            <tr>
              <td height="266" colspan="2" rowspan="2" valign="top"><table width="100%" border="1">
                <tr>
                  <td height="33" colspan="3" class="st4"><strong>SCHOLASTIC AREAS<br />
                    (GRADING ON 9 POINT SCALE)</strong></td>
                  </tr>
                <tr>
                  <td width="39%" class="st4"><strong>MARKS RANGE</strong></td>
                  <td width="26%" class="st4"><strong>GRADE</strong></td>
                  <td width="35%" class="st4"><strong>GRADE POINT</strong></td>
                </tr>
                <tr class="st4">
                  <td>91-100</td>
                  <td>A1</td>
                  <td>10</td>
                </tr>
                <tr class="st4">
                  <td>81-90</td>
                  <td>A2</td>
                  <td>9</td>
                </tr>
                <tr class="st4">
                  <td>71-80</td>
                  <td>B1</td>
                  <td>8</td>
                </tr>
                <tr class="st4">
                  <td>61-70</td>
                  <td>B2</td>
                  <td>7</td>
                </tr>
                <tr class="st4">
                  <td>51-60</td>
                  <td>C1</td>
                  <td>6</td>
                </tr>
                <tr class="st4">
                  <td>41-50</td>
                  <td>C2</td>
                  <td>5</td>
                </tr>
                <tr class="st4">
                  <td>33-40</td>
                  <td>D</td>
                  <td>4</td>
                </tr>
                <tr class="st4">
                  <td>21-32</td>
                  <td>E1</td>
                  <td>3</td>
                </tr>
                <tr class="st4">
                  <td>20 And Below</td>
                  <td>E2</td>
                  <td>2</td>
                </tr>
              </table></td>
              <td height="186" colspan="2" valign="top"><table width="100%%" border="1" class="st4">
                <tr>
                  <td height="46" colspan="3"><strong>CO-SCHOLASTIC AREAS/ACTIVITIES<br />
                    (GRADING ON 5 POINT SCALE)</strong></td>
                  </tr>
                <tr >
                  <td width="29%"><strong>GRADE</strong></td>
                  <td width="43%"><strong>GRADE POINT RANGE</strong></td>
                  <td width="28%"><strong>GRADE POINT</strong></td>
                  </tr>
                <tr>
                  <td>A</td>
                  <td>4.1 - 5.0</td>
                  <td>5</td>
                  </tr>
                <tr>
                  <td>B</td>
                  <td>3.1 - 4.0</td>
                  <td>4</td>
                  </tr>
                <tr>
                  <td>C</td>
                  <td>2.1 - 3.0</td>
                  <td>3</td>
                  </tr>
                <tr>
                  <td>D</td>
                  <td>1.1 - 2.0</td>
                  <td>2</td>
                  </tr>
                <tr>
                  <td>E</td>
                  <td>0.1 - 1.0</td>
                  <td>1</td>
                  </tr>
              </table></td>
            </tr>
            <tr>
              <td height="72" colspan="2" valign="top" class="st2"><strong>First Term: FA1 (10%) + FA2 (10%) + SA1 (30%) = 50%<br />
Second Term: FA3 (10%) + FA4 (10%) + SA2 (30%) = 50%<br />
Formative Assessment: FA1 (10%) + FA2 (10%) + FA3 (10%) + FA4 (10%) = 40%<br />
Summative Assessment: SA1 (30%) + SA2 (30%) = 60%</strong></td>
            </tr> <tr>
              <td height="18" colspan="2" valign="top" bgcolor="#999999" class="st4"><strong>RESULT: <b>
                <?php
                                            $grade_sql = Exam::exam_overall_grade_calculater($MSID, $student['student_id']);
                                            while ($gow6 = $grade_sql->fetch()) {
                                                echo $grade6 = $gow6['grade'];
                                            }
                                            ?></b></strong></td>
              <td height="18" colspan="2" valign="top" bgcolor="#999999" class="st4"><b>Remarks:
                 <?php
                                        // $ghiy1 = mysql_query($ghy1 = "SELECT * from `21Remarks_Inc_Grades` where  MSID ='$msid' And 	Grade='$Grade6'");
//while ($gowy1 = mysql_fetch_array($ghiy1)) {
//    echo $Remarks = $gowy1['Remarks'];
//} 
                                        ?>
              </b></td>
              </tr>
            <tr>
              <td width="24%" height="21" class="st4">&nbsp;</td>
              <td width="19%">&nbsp;</td>
              <td width="32%" height="21">&nbsp;</td>
              <td width="25%">&nbsp;</td>
            </tr>
            <tr class="st4">
              <td height="27" colspan="2"><strong>CLASS TEACHER</strong></td>
              <td width="32%" height="27"><strong>PARENT</strong></td>
              <td width="25%"><strong>PRINCIPAL</strong></td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
  </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
