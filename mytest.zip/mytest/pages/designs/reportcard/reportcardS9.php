<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $exam = http_get('param3');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                ?>
                <br>
                <br><?php
                ?>
<table width="653" border="1" align="center">
  <tr>
    <td width="643"> <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
      </tr>
     
      <tr align="left" valign="top">
        <td height="441" valign="top"><table width="694" height="121" border="0" align="center">
          <tr valign="top">
            <td width="521" height="117" colspan="2"><table width="694" border="0">
              <tr>
                <td height="37" colspan="2" align="left"><span class="st41">Name :&nbsp;&nbsp;<strong>&nbsp;<?= $student->name; ?></strong></span></td>
                <td width="91"><span class="st41">Id:<strong><?php if (@$oCurrentSchool->ViewOption == '0') {
                                        echo $student->student_id;
                                    } else {
                                        echo $student->admno;
                                    }
                                    ?></strong></span></td>
                <td width="165" height="37" colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td height="39" align="left"><span class="st41">Father's Name: &nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td width="245" height="39" align="left"><strong><span class="st41"><?php echo "Mr.".' '.$student->f_name; ?></span></strong></td>
                <td height="39" colspan="3" ><span class="st41">Class/House:&nbsp;<strong>
                  <?php
                                    $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                    echo $cls->class_name;
                                    ?>
                </strong></span></td>
              </tr>
              <tr>
                <td width="175" height="34" align="left"><span class="st41">Mother's Name: </span></td>
                <td align="left" class="st41"><strong><span class="style41">Mrs. <?php echo $student->m_name; ?></span></strong></td>
                <td colspan="3"><span class="st41">Phones: <strong><?php echo $student->f_mobile; ?></strong></span></td>
              </tr>
              <tr>
                <td height="39" align="left"><span class="st41">Village/Town:</span></span></td>
                <td align="left" class="st41"><strong><span class="style41"><?php echo $oCurrentSchool->place; ?></span></strong></td>
                <td colspan="3"><span class="st41">District:<strong>Shimla</strong></span></td>
              </tr>
              <?php  //}?>
            </table></td>
          </tr>
        </table>
          <table width="694" border="0" align="center">
            <tr valign="top" class="st41">
              <td height="20" align="center"><span class="style2">Academic Performance:<?php echo $oCurrentUser->mysession; ?>-<?php echo $oCurrentUser->mysession+1; ?></span><br />
                <br /></td>
            </tr>
          </table>
          <table width="694" height="142" border="1" align="center">
            <tr valign="top">
              <td height="35" class="st41">&nbsp;</td>
              <td colspan="3" align="center" class="st41"><strong>TERM I</strong></td>
              <td colspan="3" align="center" class="st41"><strong>TERM II</strong></td>
              <td colspan="3" align="center" class="st41"><strong>Final Term</strong></td>
            </tr>
            <tr valign="top">
              <td width="85" height="46" class="st41"><strong>Subjects</strong></td>
              <td width="58" align="center" class="st41"><strong>Mx.
                Marks</strong></td>
              <td width="58" align="center" class="st41"><strong>Pass Marks</strong></td>
              <td width="68" align="center" class="st41"><strong>Marks Ob</strong></td>
              <td width="40" align="center" class="st41"><strong>Mx.<br />
                Marks</strong></td>
              <td width="43" align="center" class="st41"><strong>Pass Marks</strong></td>
              <td width="66" align="center" class="st41"><strong>Marks Ob</strong></td>
              <td width="60" align="center" class="st41"><strong>Mx.<br />
                Marks</strong></td>
              <td width="69" align="center" class="st41"><strong>Pass Marks</strong></td>
              <td width="83" align="center" class="st41"><strong>Marks Ob</strong></td>
            </tr>
            <?php
                            $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', '', $student->student_id, $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                            while ($rowv = $subjects_querry->fetch()) {
                                ?> 
            <tr valign="top">
              <td class="st41"><?php
                                    $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                    while ($rowu = $subjects->fetch()) { echo $rowu['name']; } ?></td>
              <td align="center" class="st41"><?php
                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                            
                                        echo $max= $rowu['max_marks'];  $passmark= round($max/3,0); } ?>
                                           		</td>
              <td align="center" class="st41"><?= $passmark ?>  
              </td>
              <td align="center" class="st41"><?php
                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['marks_obtained']; }?></td>
             <td align="center" class="st41"><?php
                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id'], 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['max_marks']; $passmark= round($max/3,0); } ?>
                                           		</td>
              <td align="center" class="st41"><?= $passmark ?>  
              </td>
              <td align="center" class="st41"><?php
                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id'], 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['marks_obtained']; }?></td>
              
              <td align="center" class="st41"><?php
                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', $rowv['subject_id'], 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['max_marks']; $passmark= round($max/3,0); } ?>
                                           		</td>
              <td align="center" class="st41"><?= $passmark ?>  
              </td>
              <td align="center" class="st41"><?php
                                        $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', $rowv['subject_id'], 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['marks_obtained']; }?></td>
            </tr>
            <?php }?>
            <tr valign="top">
              <td height="26" align="center" class="st41">Result:</td>
              <td height="26" colspan="3" align="center" class="st41"><?php  
//					 $trkd1=mysql_query($qkd1="Select (Sum(MarksObtained)/Sum(`MaxMarks` )*100) as page1 from 21Repodata1 where StudentId='$sid' and  `MSID`='$msid' And  `Session`='$session' And    `AssId`='1' ");
//				 while($ttkd1=mysql_fetch_array($trkd1)){$page1=$ttkd1['page1'];}
                              $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', '', 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['marks_obtained']; }?>

                (<?php //echo round($page1,2);?>%)</td>
              <td height="26" colspan="3" align="center" class="st41">Total :
                <?php  $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '2', '', 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['marks_obtained']; }?>
                (<?php //echo round($page2,2);?>%) </td>
              <td height="26" colspan="3" align="center" class="st41"><?php  
					$fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', '', 'YES');
                                        while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                        echo $max= $rowu['marks_obtained']; }?>
                (<?php //echo round($page1,2);?>%)</td>
            </tr>
          </table>
          <table width="694" border="0" align="center">
            <tr>
              <td height="21" align="center" class="st41">&nbsp;</td>
              <td align="center" class="st41">&nbsp;</td>
              <td align="center" class="st41">&nbsp;</td>
              <td align="center" class="st41">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td height="21" align="center" class="st41">&nbsp;</td>
              <td align="center" class="st41">&nbsp;</td>
              <td align="center" class="st41">&nbsp;</td>
              <td align="center" class="st41">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td width="206" height="21" align="center" class="st41"><strong>Remarks:</strong></td>
              <td width="112" align="center" class="st41"><strong>
                
                Excellent</strong></td>
              <td width="134" align="center" class="st41"><strong>Very Good</strong></td>
              <td width="81" align="center" class="st41"><strong>Good </strong></td>
              <td width="139" align="center"><strong><span class="st41">Average</span></strong></td>
            </tr>
          </table>
          <br />
          <br />
          <table width="694" border="0" align="center">
            <tr>
              <td width="201" height="26" align="center" class="st41"><strong>Class Teacher</strong></td>
              <td width="261" align="center"><strong>
                
              </strong></td>
              <td width="218" align="center"><strong><span class="st41">Principal</span></strong></td>
            </tr>
            <tr>
              <td height="33" colspan="3" class="st41"><strong>Note: School Will Re-open on 15th Feb 2016.  Practice Cursive Writing</em> at home.</strong></td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<br /><!--<p class="page"></p>-->
<p class="page">
<br />
</p>	
	 </div>
            <!-- /.box -->
        </div>
    </div>
</section>

		
	

