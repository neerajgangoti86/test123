<html><head>
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<?php //print_r($student); ?>

</head>
<body>
<section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>
                <div class="box">

                    <?php
                    $id = http_get('param2');
                    $exam = http_get('param3');
                    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                    $ttl = 0;
                    $i = 0;
                    
                    
                    ?>
                    
<table width="692" height="142" border="1"   align="center" cellpadding="2" cellspacing="2">
<tr>
<td width="680"  ><?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl_2.php'; ?></td>
</tr>
                        <tr>
                            <td width="680" height="350">&nbsp;&nbsp;&nbsp;&nbsp;<table width="100%" height="98" border="0" align="center">
                                    <tr valign="top" class="st42">
                                        <td width="12" rowspan="5"></td>
                                        <td width="337" height="28">Student Name:<?= $student->name; ?></td>
                                        <td width="356" > Class-SEC: <?php echo $student->class_name;
                                         
                                            ?></td>
                                        
                                    </tr>
                                    <tr valign="top" class="st42">
                                        <td height="31">Address:<?= $student->address; ?></td>
                                        <td width="356" height="31"><?php if (@$student->roll_no != '0') { ?><?php } ?>Rollno.:<?php
                                            if (@$student->roll_no != '0') {
                                                echo $student->roll_no;
                                            }
                                            ?></td>
                                     </tr>
                                    <tr valign="top" class="st42">
                                      <td height="31">Exam: <?= $student->f_name; ?></td>
                                        <td width="356" height="31">Date: <?php echo $student->m_name; ?></td>  
                                    </tr>
                                </table>&nbsp;&nbsp;&nbsp;<table width="100%" height="208" align="center" bordercolor="#2A3F00">
                                    <tr align="left" valign="top">
                                        <td height="202">
                                            <table width="100%" height="53" border="1" align="center">
                                                <tr valign="top" bgcolor="#E8E8E8">
                                                  <td height="15" align="center" class="st411">Subjects</td>
                                                  <td width="285" align="center" class="st411">Grades</td>
                                                </tr>
                                                <?php 
   $subjects =  Reportcard::get_reportcard_subjects($MSID,$student->student_id,$student->class);
                                         while ($rowu = $subjects->fetch()) { 
//                                          echo $rowu['subject_id'];
?> 
                                                <tr valign="top" bgcolor="#E8E8E8" style="background-color:#FFF;">
                                                
                                                  <td width="371" height="22" align="center" class="st411"><?= $rowu['name'] ?></td>
                                                  <td align="center" class="st411"><?php
        
        
        $subpr=  Reportcard::get_sub_grades($MSID,$rowu['subject_id'],$student->student_id);      
                                        while ($rpr = $subpr->fetch()) {
                                             $rpr['percentage'];
                                 $subgr=  Reportcard::get_subfinal_grades($MSID,$rpr['percentage'],$student->class);      
                                        while ($drpr = $subgr->fetch()) {
                                           echo  $drpr['grade'];
                                            
                                            
                                        }           
                                            
                                        } ?>
                                                      
                                                       
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                  </td>
                                                </tr><?php $subactivity=  Reportcard::get_act_subject($MSID,$student->student_id,$student->class,$rowu['subject_id']);      
                                        while ($rowv = $subactivity->fetch()) {  ?>
                                                    <tr valign="top" bgcolor="#E8E8E8" style="background-color:#FFF;">
                                                
                                                  <td width="371" height="22" align="center" class="st411"><?= $rowv['name']  ?></td>
                                                  <td align="center" class="st411"><?php  $activitygr=  Reportcard::get_act_grades($MSID,$rowv['id'],$rowv['subject'],$student->student_id )->fetch();
                                                  ?><?= $activitygr['grade']  ?></td>
                                                </tr><?php   } 
												
												
   }?>
                                                 
                                                 
                                                 
                                                
                                            </table>
                                            
                                  </tr>
                                    
                                              
                          </table></td>
  </tr>
                          </table></td>
                        </tr>
                    </table>
                    </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</body>
</html>



















