
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<?php //print_r($student); ?>

</head>
<body>  
    <section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>
                <div class="box">

                    <?php
                    $id = http_get('param2');
                    $exam = http_get('param3');
                    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                    $ttl = 0;
                    $i = 0;
                    ?>
                    <table width="750" height="800" border="1"   align="center" cellpadding="2" cellspacing="2">
                        <tr>
                            <td width="665"  ><?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td></tr>
                        <tr><td><table width="100%" height="149" border="0" align="center">
                                    <tr valign="top" class="st42">
                                        <td width="139" rowspan="5"><img style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php
                                            if ($student->std_image != "") {
                                                echo $student->std_image;
                                            } else {
                                                echo ASSETS_FOLDER . "/img//myprofile1.png";
                                            }
                                            ?>" width="122" height="127"></td>
                                        <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                                        <td height="27"><?= $student->name; ?></td>
                                        <td height="27">&nbsp;</td>
                                        <td width="106" > Admission No:</td>
                                        <td width="105" ><?php
                                            if (@$oCurrentSchool->ViewOption == '0') {
                                                echo $student->student_id;
                                            } else {
                                                echo $student->admno;
                                            }
                                            ?>&nbsp;</td>
                                    </tr>
                                    <tr valign="top" class="st42">
                                        <td height="31">Father's Name:</td>
                                        <td width="238" height="31">Mr. <?= $student->f_name; ?></td>
                                        <td width="11" height="31">&nbsp;</td>
                                        <td><?php if (@$student->roll_no != '0') { ?>Roll No.: <?php } ?></td>
                                        <td><?php
                                            if (@$student->roll_no != '0') {
                                                echo $student->roll_no;
                                            }
                                            ?></td>
                                    </tr>
                                    <tr valign="top" class="st42">
                                        <td height="28">Mother's Name:</td>
                                        <td height="28">Mrs. <?php echo $student->m_name; ?></td>
                                        <td height="28">&nbsp;</td>
                                        <td>Class:</td>
                                        <td><?php
                                            $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                            echo $cls->class_name;
                                            ?>
                                            &nbsp;</td>
                                    </tr>
                                    <tr valign="top" class="st42">
                                        <td height="23">Mobile:</td>
                                        <td height="23"><?php echo $student->f_mobile; ?></td>
                                        <td height="23">&nbsp;</td>
                                        <td>Date Of Birth: </td>
                                        <td><?php
                                            $DateOfBirth = $student->birth_date;
                                            echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                            ?>
                                            &nbsp;</td>
                                    </tr>
                                    <tr valign="top" class="st42">
                                        <td height="12">Address:</td>
                                        <td height="12" colspan="4"><?php echo $oCurrentSchool->place; ?></td>
                                    </tr>
                                </table><table width="100%" height="833" align="center" bordercolor="#2A3F00">
                                    <tr align="left" valign="top">
                                        <td height="174"><?php //if($ULevel=='9'){       ?>
                                            <table width="100%" height="156" border="1" align="center">
                                                <tr valign="top" bgcolor="#E8E8E8">
                                                    <td height="30" class="st411">SCHOLASTIC AREA<br />
                                                        (9 point scale)</td>
                                                    <td colspan="4" class="st411" align="center">TERM I</td>
                                                    <td colspan="4" class="st411" align="center">TERM II</td>
                                                    <td colspan="4" align="center" class="st411">Final Assessment</td>
                                                </tr>
                                                <tr valign="top"  bgcolor="#C9C9C9">
                                                    <td height="30" class="st411"><strong>Subjects</strong></td>
                                                    <td class="st411">FA1
                                                        10%</td>
                                                    <td class="st411">FA2
                                                        10%</td>
                                                    <td width="31" class="st411">SA1
                                                        30%</td>
                                                    <td width="39" class="st411">Total 50%</td>
                                                    <td width="30" class="st411">FA3
                                                        10%</td>
                                                    <td width="32" class="st411">FA4
                                                        10%</td>
                                                    <td width="33" class="st411">SA2
                                                        30%</td>
                                                    <td width="41" class="st411">Total 50%</td>
                                                    <td width="37" class="st411">FA 40%</td>
                                                    <td width="35" class="st411">SA 60%</td>
                                                    <td width="106" class="st411"><span class="st4">Overall<br />
                                                            (FA+SA=100%)</span></td>
                                                    <td width="60" class="st411"><span class="st4">Grade Point</span></td>
                                                </tr>
                                                <?php
                                                $subjects_querry = Exam::get_accademinc_performance($MSID, '','', $student->student_id);
                                               
                                                while ($rowv = $subjects_querry->fetch()) {
                                                    ?>

                                                    <tr valign="top">
                                                        <td width="144" height="16" class="st411">
                                                            //<?php
//                                                            $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
//                                                            while ($rowu = $subjects->fetch()) {
//                                                                echo $rowu['name'];
//                                                            }
//                                                            ?>
                                                        </td>

                                                        <td width="30" class="st411"> 
                                                            <?php
//                                                            $fa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id'], 'YES');
//                                                            while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
//                                                                $u1 = $rowu['marks_obtained'];
//                                                                $mm1 = $rowu['max_marks'];
                                                              //   ?>
                                                            //<?= $rowu['Grade'] ?>
                                                                <?php
//                                                            }
//                                                            ?>
                                                        </td>
                                                        <td width="30" class="st411"> <?php
                                                            $fa2 = Exam::exam_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa2->fetch()) {
                                                                $u1 += $rowu['marks_obtained'];
                                                                $mm1 += $rowu['max_marks'];
                                                                ?><?= $rowu['Grade'] ?>
                                                                <?php
                                                            }
                                                            ?></td>
                                                        <td class="st411"> <?php
                                                            $sa1 = Exam::exam_grade_calculater($MSID, $student->student_id, '5', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $sa1->fetch()) {
                                                                $t1 = $rowu['marks_obtained'];
                                                                $tm1 = $rowu['max_marks'];
                                                                ?><?= $rowu['Grade'] ?>
                                                                <?php
                                                            }
                                                            ?></td>
                                                        <td class="st411"> <?php
                                                            $overall = Exam::exam_term_grade_calculater($MSID, $student->student_id, '1', $rowv['subject_id']);
                                                            while ($rowu = $overall->fetch()) {
                                                                ?><?= $rowu['grade'] ?>
                                                            <?php } ?></td>
                                                        <td class="st411"> <?php
                                                            $fa3 = Exam::exam_grade_calculater($MSID, $student->student_id, '3', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa3->fetch(PDO::FETCH_ASSOC)) {
                                                                $u2 = $rowu['marks_obtained'];
                                                                $mm2 = $rowu['max_marks'];
                                                                ?><?= $rowu['Grade'] ?>
                                                                <?php
                                                            }
                                                            ?></td>
                                                        <td class="st411"> <?php
                                                            $fa4 = Exam::exam_grade_calculater($MSID, $student->student_id, '4', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa4->fetch()) {
                                                                $u2 += $rowu['marks_obtained'];
                                                                $mm2 += $rowu['max_marks'];
                                                                ?><?= $rowu['Grade'] ?>
                                                                <?php
                                                            }
                                                            ?></td>
                                                        <td class="st411"> <?php
                                                            $fa5 = Exam::exam_grade_calculater($MSID, $student->student_id, '6', $rowv['subject_id'], 'YES');
                                                            while ($rowu = $fa5->fetch()) {
                                                                $t2 = $rowu['marks_obtained'];
                                                                $tm2 = $rowu['max_marks'];
                                                                ?><?= $rowu['Grade'] ?>
                                                                <?php
                                                            }
                                                            ?></td>
                                                        <td class="st411"> <?php
                                                            $overall = Exam::exam_term_grade_calculater($MSID, $student->student_id, '2', $rowv['subject_id']);
                                                            while ($rowu = $overall->fetch()) {
                                                                ?><?= $rowu['grade'] ?>
                                                            <?php } ?></td>
                                                        <td class="st411"><?php
                                                            $sumfa = $u1 + $u2;
                                                            $sum_max_marks_fa = $mm1 + $mm2;
                                                            $per = round($sumfa / $sum_max_marks_fa * 100);

                                                            $grades = Exam::get_exam_grades_by_marks($MSID, $student->class, $per)->fetch(PDO::FETCH_OBJ);
                                                            echo $grades->grade;
                                                            ?></td>
                                                        <td class="st411"><?php
                                                            $sumsa = $t1 + $t2;
                                                            $sum_max_marks_sa = $tm1 + $tm2;
                                                            $per_sa = round($sumsa / $sum_max_marks_sa * 100);
                                                            $grades = Exam::get_exam_grades_by_marks($MSID, $student->class, $per_sa)->fetch(PDO::FETCH_OBJ);
                                                            echo $grades->grade;
                                                            ?></td>
                                                        <td class="st411"> <?php
                                                            $oa = Exam::exam_Subjectwise_overallgrade_calculater($MSID, $student->student_id, $rowv['subject_id']);
                                                            while ($rowu = $oa->fetch()) {
                                                                ?><?= $rowu['grade'] ?>
                                                        <?php } ?></td>
                                                        <td class="st411"><?php
                                                        $grade_points = Exam::exam_grade_point($MSID, $student->student_id, $rowv['subject_id']);

                                                        while ($rowu = $grade_points->fetch()) {
                                                          echo $grade_point= $rowu['grade_point'];
                                                            $ttl+=$grade_point;
                                                           $i++;
                                                           
                                                           
                                                            ?>
                                                            <?php } ?></td>
                                                    </tr> <?php } ?>
                                                <tr valign="top">
                                                    <td height="17" class="st411">ATTENDANCE</td>
                                                    <?php
//                                                    $att1 = mysql_query($aq1 = "Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='1'");
//                                                    while ($at1 = mysql_fetch_array($att1)) {
//                                                        $Term1WD = $at1['TWD'];
//                                                        $Term1Att = $at1['TERMATT'];
//                                                    }
                                                    ?>
                                                    <td colspan="2" class="st411"><?php //echo $Term1Att;   ?>/ <?php //echo $Term1WD;   ?></td>
                                                    <td colspan="2" class="st411"><?php
//                                                        $tatt = ($Term1Att / $Term1WD) * 100;
//                                                        echo round($tatt, 2);
                                                        ?>
                                                        %</td>
<?php
//                                                    $att1a2 = mysql_query($aq1a2 = "Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='2'");
//                                                    while ($at1a2 = mysql_fetch_array($att1a2)) {
//                                                        $Term1WDa2 = $at1a2['TWD'];
//                                                        $Term1Atta2 = $at1a2['TERMATT'];
//                                                    }
?>
                                                    <td colspan="2" class="st411"><?php //echo $Term1Atta2;   ?> / <?php //echo $Term1WDa2;   ?></td>
                                                    <td colspan="2" class="st411"><?php
//                                                        $tatta2 = ($Term1Atta2 / $Term1WDa2) * 100;
//                                                        echo round($tatta2, 2);
                                                        ?>
                                                        %</td>
                                                    <td class="st411"><?php //echo $TotalAtt = $Term1Att + $Term1Atta2;   ?> / <?php //echo $TotalWD = $Term1WD + $Term1WDa2;   ?></td>
                                                    <td class="st411"><?php
//                                                        $TotalTermAtt = ($TotalAtt / $TotalWD) * 100;
//                                                        echo round($TotalTermAtt, 2);
                                                        ?>
                                                        %</td>
                                                    <td class="st411">CGPA</td>
                                                    <td class="st411"><?php echo round($ttl/$i,2); ?> </td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="25" colspan="13" align="left" class="st2">Nine point grading scale:A1=91%-100%;A2=81%-90%;B1=71%-80%;B2=61%-70%;c1=51%-60%;C2=41%-50%;D=33%-40%;E1=21%-32%;E2 =20% And Below</td>
                                                </tr>
                                            </table>
                                            <table width="100%" height="167" border="1" align="center">
                                                <tr valign="top" bgcolor="#E8E8E8">
                                                    <td height="28" colspan="2" class="st4" align="center" valign="middle"><strong>SELF AWARENESS</strong></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td width="196" height="27" class="st4">My Goals</td>
                                                    <td width="485" class="st4"><?php ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="24" class="st4">Strengths</td>
                                                    <td class="st4"><?php ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="25" class="st4">My Interests  And Hobbies</td>
                                                    <td class="st4"><?php ?></td>
                                                </tr>

                                            </table></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="123" valign="top"><table width="100%" height="151" border="0" align="center">
                                                <tr>
                                                    <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS:
<?php
$remark = Exam::get_exam_remarks($MSID, '', '', $student->student_id, $oCurrentUser->mysession,'2', $student->class);
while ($rowur = $remark->fetch(PDO::FETCH_ASSOC)) {
    echo $rowur['remarks'];
}
?>
                                                        </strong><br/></td>
                                                </tr>

                                                <tr>
                                                    <td height="26" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>
                                                            <!--Note:</strong>(1)Promotion is based on the day -to -day continuous assessment throughout the year.(2) CGPA=Cumulative Grade Point Average (3) Subject Wise/Overall indicative percentage of Marks=9.5 X GP of the subject /CGPA.--></td>
                                                </tr>
                                                <tr>
                                                    <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                                                    <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                </table></td>
                        </tr>
                    </table>
                    <p class="page"></p>
                    <table width="750" border="1"   align="center" >
                        <tr>
                            <td><table width="100%" height="804" align="center" bordercolor="#2A3F00">
                                    <tr align="left" valign="top">
                                        <td height="19" align="center" class="st4"><strong style="font-family:'Comic Sans MS', cursive; font-size:18px"><u>(Grading On Five Point Scale A,B,C,D,E)</u></strong></td>
                                    </tr>
                                    <tr align="left" valign="top">
                                        <td height="78"><table width="100%" height="693" border="1" align="center">
                                                <tr valign="top">
                                                    <td height="22" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 2 (A)-LIFE SKILLS</strong></td>
                                                </tr>
                                                <tr valign="top" >
                                                    <td width="44" height="32" class="st4" valign="middle">Sr.No.</td>
                                                    <td width="253" class="st4" valign="middle">Area of Assessment</td>
                                                    <td width="38" class="st4" valign="middle">Grade</td>
                                                    <td width="331" class="st4" valign="middle">Descriptive Indicators</td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="36" class="st4">01</td>
                                                    <td class="st4">THINKING SKILLS</td>
                                                    <td class="st4"> <?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='THINKING SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sb1 = $tt['Indicator'];
//                                                        echo "$Name " . " $sb1";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="34" class="st4">02</td>
                                                    <td class="st4">SOCIAL SKILLS</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='SOCIAL SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
                                                    <td class="st4"><?php
//                                                        $sbi = $tt1['Indicator'];
//                                                        echo "$Name " . " $sbi";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="35" class="st4">03</td>
                                                    <td class="st4">EMOTIONAL SKILLS </td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='EMOTIONAL SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi1 = $tt2['Indicator'];
//                                                        echo "$Name " . " $sbi1";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="37" class="st4"><strong>2(B)</strong></td>
                                                    <td class="st4">WORK EDUCATION</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='WORK EDUCATION'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
                                                    <td class="st4"><?php
//                                                        $sbi3 = $tt3['Indicator'];
//                                                        echo "$Name " . " $sbi3";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="37" class="st4"><strong>2(C)</strong></td>
                                                    <td class="st4">VISUAL AND PERFORMING ARTS</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='VISUAL AND PERFORMING ARTS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?></td>
                                                    <td class="st4"><?php
//                                                        $sbi4 = $tt4['Indicator'];
//                                                        echo "$Name " . " $sbi4";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="21" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 2 (D)-ATTITUDE &amp; VALUES</strong></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="33" class="st4">1.0</td>
                                                    <td colspan="3" class="st4">ATTITUDE TOWARDS</td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="33" class="st4">1.1</td>
                                                    <td class="st4">TEACHERS</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='TEACHERS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi5 = $tt5['Indicator'];
//                                                        echo "$Name " . " $sbi5";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="33" class="st4">1.2</td>
                                                    <td class="st4">SCHOOL-MATES</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='SCHOOL-MATES'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi16 = $tt16['Indicator'];
//                                                        echo "$Name " . " $sbi16";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="40" class="st4">1.3</td>
                                                    <td class="st4">SCHOOL PROGRAMMES AND ENVIORNMENT</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='SCHOOL PROGRAMMES AND ENVIORNMENT'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi6 = $tt6['Indicator'];
//                                                        echo "$Name " . " $sbi6";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="37" class="st4">2.0</td>
                                                    <td class="st4">VALUE SYSTEM</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='VALUE SYSTEM'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi7 = $tt7['Indicator'];
//                                                        echo "$Name " . " $sbi7";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="21" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 3 (A) CO-SCHOLASTIC ACTIVITIES</strong></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="35" class="st4">01</td>
                                                    <td class="st4">LITERARY AND CREATIVE SKILLS</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='LITERARY AND CREATIVE SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi8 = $tt8['Indicator'];
//                                                        echo "$Name " . " $sbi8";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="32" class="st4">02</td>
                                                    <td class="st4">SCIENTIFIC SKILLS</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='SCIENTIFIC SKILLS'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi9 = $tt9['Indicator'];
//                                                        echo "$Name " . " $sbi9";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="21" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 3 (b) HEALTH AND PHYSICAL EDUCATION</strong></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="35" class="st4">01</td>
                                                    <td class="st4">YOGA</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='YOGA'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi10 = $tt10['Indicator'];
//                                                        echo "$Name " . " $sbi10";
//                                                    }
                                                        ?></td>
                                                </tr>
                                                <tr valign="top">
                                                    <td height="15" class="st4">02</td>
                                                    <td class="st4">SPORTS/ INDIGENOUS SPORTS</td>
                                                    <td class="st4"><?php
                                                        $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student->student_id . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Self Awareness'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                        $oDb = DBConnection::get();
                                                        $saw1 = $oDb->query($saw1);
                                                        while ($rowu1 = $saw1->fetch()) {
                                                            $gr1 = "";
                                                            $marks1 = $rowu1['marks'];
                                                            $title = $rowu1['title'];
                                                            $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                        }
                                                        ?>
                                                    </td>
                                                    <td class="st4"><?php
//                                                        $sbi11 = $tt11['Indicator'];
//                                                        echo "$Name " . " $sbi11";
//                                                    }
                                                        ?></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <table width="100%" border="1">

<?php $health_data = Exam::get_exam_health_data($MSID, '', array('selectAll' => 'true'), $student->student_id, $oCurrentUser->mysession , '1')->fetch(PDO::FETCH_OBJ); ?>
                                                <tr>
                                                    <td width="27%" rowspan="2" class="st4" align="center" valign="middle" bgcolor="#E8E8E8" ><strong>HEALTH DATA</strong></td>
                                                    <td width="9%" class="st4" align="center">HEIGHT</td>
                                                    <td width="9%" class="st4" align="center">WEIGHT</td>
                                                    <td width="10%" height="26" class="st4" align="center">BLOOD GROUP</td>
                                                    <td width="31%" align="center" class="st4">DENTAL HYGIENE</td>
                                                </tr>
                                                <tr>
                                                    <td height="23" align="center" class="st4"> <?= $health_data->height ?> </td>
                                                    <td align="center" class="st4"> <?= $health_data->weight ?></td>
                                                    <td align="center" class="st4"><?= $health_data->dental_hygiene ?> </td>
                                                    <td align="center" class="st4"> <?= $health_data->dental_hygiene ?></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                </table></td>
                        </tr>
                    </table>
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>



















