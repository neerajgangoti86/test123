<html><head>
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<?php //print_r($student); ?>

</head>
<body>
<section class="content">
        <div class="row">
            <div class="col-xs-12"> <?php
                $message = new Messages();
                echo $message->display();
                ?>
                <div class="box">

                    <?php
                    $id = http_get('param2');
                    $exam = http_get('param3');
                    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
                    $ttl = 0;
                    $i = 0;
                    
                    
                    ?>
                    <h2 align="center">Evaluation-1 Report[2016-2017]</h2>
<table width="692" height="382" border="1"   align="center" cellpadding="2" cellspacing="2">
<tr>
<td width="680"  ><?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
</tr>
                        <tr>
                            <td width="680" height="350">&nbsp;&nbsp;&nbsp;&nbsp;<table width="100%" height="98" border="0" align="center">
                                    <tr valign="top" class="st42">
                                        <td width="12" rowspan="5"></td>
                                        <td width="337" height="28">Student Name:<?= $student->name; ?></td>
                                        <td width="356" > Class-SEC: <?php echo $student->class_name;
                                            ?></td>
                                        
                                    </tr>
                                    <tr valign="top" class="st42">
                                        <td height="31"><?php if (@$student->roll_no != '0') { ?><?php } ?>Rollno.:<?php
                                            if (@$student->roll_no != '0') {
                                                echo $student->roll_no;
                                            }
                                            ?></td>
                                        <td width="356" height="31">Admission No.: <?php
                                            if (@$oCurrentSchool->ViewOption == '0') {
                                                echo $student->student_id;
                                            } else {
                                                echo $student->admno;
                                            }
                                            ?></td>
                                     </tr>
                                    <tr valign="top" class="st42">
                                      <td height="31">Father's Name: <?= $student->f_name; ?></td>
                                        <td width="356" height="31">Mothers Name: <?php echo $student->m_name; ?></td>  
                                    </tr>
                                </table>&nbsp;&nbsp;&nbsp;<table width="100%" height="208" align="center" bordercolor="#2A3F00">
                                    <tr align="left" valign="top">
                                        <td height="202">
                                            <table width="100%" height="164" border="1" align="center">
                                                <tr valign="top" bgcolor="#E8E8E8">
                                                    <td height="30" colspan="2" rowspan="2" class="st411">Academic Performance <br />
                                                        Scholastic Area</td>
                                                    <?php
                                    
                                    
    $sql_assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $student->class, '', '', 'Term 1', 'YES');
                                    while ($rowv = $sql_assesments->fetch()) {
                                        ?>
                                                    <td width="159" align="center" class="st411"><?= $rowv['title'] ?></td><?php } ?>
                                                    
                                                    
                                                 </tr>
                                                <tr valign="top" bgcolor="#E8E8E8">
                                                  <td class="st411" align="center">Grade</td>
                                                  <td align="center" class="st411">Grade</td>
                                                  <td align="center" class="st411">Credit1+2</td>
                                                </tr>
                                                <?php
                                        $subjects = SuperAdmin::get_datesheet_subject($MSID);
                                        while ($rowu = $subjects->fetch()) {
                                            
                                            $sub=  SuperAdmin::get_act_subject2($MSID, $rowu['subject'])->fetch();
                                            
                                            
                                            ?>
                                                <tr valign="top" bgcolor="#E8E8E8" style="background-color:#FFF;">
                                                
                                                  <td width="21" align="center" class="st411">1</td>
                                                  
                                        <td width="124" align="center" class="st411"><?= $sub['name'] ?></td>
                                                  <td align="center" class="st411"></td>
                                                  <td align="center" class="st411"></td>
                                                  <td width="174" align="center" class="st411"></td>
                                                </tr><?php }?>
                                                 
                                                 
                                                 
                                                
                                            </table>
                                            
                                  </tr>
                                    
                                              
                          </table></td>
  </tr>
                          </table></td>
                        </tr>
                    </table>
                    </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</body>
</html>



















