
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />


<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
                ?>
                <br>
                <br><?php
                ?>




                <table  border="1" align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td width="100%">
                            <table width="658" align="center" bordercolor="#2A3F00">
                                <tr align="left" valign="top">
                                    <td width="100%"> <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
                                </tr>
                            </table></td>
                    </tr>

                    <tr align="left" valign="top">
                        <td valign="top"><br />
                            <table width="645" border="0" align="center">
                                <tr>
                                    <td width="30" rowspan="5" class="st4"></td>
                                    <td colspan="2" class="b1"> 
                                        <b><?php echo $student['name']; ?></b> </td>
                                    <td width="3">&nbsp;</td>
                                    <td width="179" class="st4">&nbsp;</td>
                                    <td class="st4">&nbsp;</td>
                                </tr>

                                <tr>

                                    <td width="140" height="29" class="st4">Student Id: </td>
                                    <td colspan="3" class="st4"><strong><?php echo $student['student_id']; ?> </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class:<strong>
                                            <?php
                                            $cls = Master::get_classes($MSID, '', '', '', $student['class'])->fetch(PDO::FETCH_OBJ);
                                            echo $cls->class_name;
                                            ?>  &nbsp; </strong>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Overall grade:</td>
                                    <td width="116" class="st4"><strong>
                                            <?php
                                            $grade_sql = Exam::exam_overall_grade_calculater($MSID, $student['student_id']);
                                            while ($gow6 = $grade_sql->fetch()) {
                                                echo $grade6 = $gow6['grade'];
                                            }
                                            ?>
                                        </strong></td>
                                </tr>

                                <tr>
                                    <td height="28" class="st4">Father's Name:</td>
                                    <td colspan="3" class="st4"><strong>
                                            <?php echo "Mr." . ' ' . $student['f_name']; ?>
                                        </strong></td>
                                    <td class="st4">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td height="28" class="st4">Mother's Name:</td>
                                    <td colspan="3" class="st4"><strong>
                                            <?php echo "Mrs." . ' ' . $student['m_name']; ?>
                                        </strong></td>
                                    <td class="st4">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td>&nbsp;</td>
                                    <td width="151">&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>         <tr>
                                    <td colspan="6" align="center"><strong class="st3"><u><br />
                                                Academic Performance <?php echo $oCurrentUser->mysession; ?>-<?php echo $session2 = $oCurrentUser->mysession + 1; ?><br />
                                                <br />
                                            </u></strong></td>
                                </tr>
                                <tr>
                                    <td height="146" colspan="7"><table width="607" border="1" align="center">
                                            <tr>
                                                <td width="163" rowspan="2" align="left" valign="top" bgcolor="#C9C9C9"><strong class="st4">Subjects</strong></td>
                                                <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>First Term </strong></td>
                                                <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Second Term</strong></td>
                                                <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Final Term</strong></td>
                                                <td width="95" rowspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Term Grade</strong></td>

                                            </tr>
                                            <tr>
                                                <td align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                                                <td align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                                                <td width="55" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                                                <td width="59" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                                                <td width="57" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                                                <td width="32" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                                            </tr>
                                            <?php
                                            $subjects_querry = Exam::get_accademinc_performance($MSID, '', '','', '', '', $student['student_id'], $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                            while ($rowv = $subjects_querry->fetch()) {
                                                ?> 
                                                <tr class="st4">
                                                    <td align="left">&nbsp;&nbsp;
                                                        <?php
                                                        $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                                        while ($rowu = $subjects->fetch()) {
                                                            echo $rowu['name'];
                                                        }
                                                        ?></td>
                                                    <?php
                                                    $fa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '1', $rowv['subject_id'], 'YES');
                                                    while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                         $u1 = $rowu['marks_obtained'];
                                                                $mm1 = $rowu['max_marks'];
                                                        $marks1 = $rowu['marks_obtained'];
                                                        $maxm1 = $rowu['max_marks'];
                                                    }
                                                    ?> <td width="62" align="left">&nbsp;
                                                            <?php
                                                            echo @$marks1
                                                            ?>
                                                    </td>
                                                    <td width="32" align="left"><?php
                                                        if (@$maxm1 == '0') {
                                                            
                                                        } else {
                                                            echo @$maxm1;
                                                        }
                                                        ?></td>
                                                    <?php
                                                    $fa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '2', $rowv['subject_id'], 'YES');
                                                    while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                       $u1 += $rowu['marks_obtained'];
                                                                $mm1 += $rowu['max_marks'];
                                                        $marks2 = $rowu['marks_obtained'];
                                                        $maxm2 = $rowu['max_marks'];
                                                    }
                                                    ?>  <td align="left">&nbsp;
                                                            <?php
                                                            echo @$marks2
                                                            ?>
                                                        &nbsp;</td>
                                                    <td align="left"><?php
                                                        if (@$maxm2 == '0') {
                                                            
                                                        } else {
                                                            echo @$maxm2;
                                                        }
                                                        ?></td>
                                                    <?php
                                                    $fa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '2', $rowv['subject_id'], 'YES');
                                                    while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                         $u1 += $rowu['marks_obtained'];
                                                                $mm1 += $rowu['max_marks'];
                                                        $marks3 = $rowu['marks_obtained'];
                                                        $maxm3 = $rowu['max_marks'];
                                                    }
                                                    ?> <td align="left">&nbsp;
                                                            <?php
                                                            echo @$marks3
                                                            ?>
                                                        &nbsp; </td>
                                                    <td align="left"><?php
                                                        if (@$maxm3 == '0') {
                                                            
                                                        } else {
                                                            echo @$maxm3;
                                                        }
                                                        ?></td>
                                                    <td width="95" align="left">&nbsp;&nbsp;
                                                         <?php
                                                          
                                                             $per = round($u1 / $mm1 * 100);

                                                            $grades = Exam::get_exam_grades_by_marks($MSID, $student['class'], $per)->fetch(PDO::FETCH_OBJ);
                                                            echo $grades->grade;
                                                            ?></td>
                                                </tr>
                                            <?php } ?>
                                        </table></td>
                                </tr>
                            </table>
                            <br />
                            <table width="570" border="1" align="center">
                                <tr>
                                    <td class="st4">Remarks:
                                        <hr /><?php
                                        // $ghiy1 = mysql_query($ghy1 = "SELECT * from `21Remarks_Inc_Grades` where  MSID ='$msid' And 	Grade='$Grade6'");
//while ($gowy1 = mysql_fetch_array($ghiy1)) {
//    echo $Remarks = $gowy1['Remarks'];
//} 
                                        ?><br />
                                        <br />
                                        <br />
                                        <br />
                                    </td>
                                </tr>
                            </table>
                            <br />
                            <table width="570" border="0" align="center">
                                <tr>
                                    <td align="center">....................</td>
                                    <td align="center">...........................</td>
                                    <td align="center">........................</td>
                                    <td align="center">.....................</td>
                                </tr>
                                <tr class="st4">
                                    <td align="center"><strong>Mother</strong></td>
                                    <td align="center"><strong>Father/Guardian</strong></td>
                                    <td align="center"><strong>Class Teacher</strong></td>
                                    <td align="center"><strong>Principal</strong></td>
                                </tr>
                            </table>
                            <br />
                            <br /></td>
                    </tr></table></td>
                </tr>
                </table>  
                <br />

                <form id="contactform" name="contactform" method="post" action="">

                    <input type="button" value="Print" onclick="printpage();">
                    <input type="submit" name="Submit" value="Exit" />
                </form>












            </div>
            <!-- /.box -->
        </div>
    </div>
</section>




