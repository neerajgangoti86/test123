<html>
</head>
<body>
  <form  name="frm" method="post" action="">
    <table width="74%"  border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="100%"><table width="100%" height="320" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="697" height="133">
            <table width="93%" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td height="22" colspan="3" align="center"><span class="m1"></span></td>
              </tr>
            <tr>
              <td width="13%" height="101" align="left" valign="middle"><img src="" height="90" width="70"/></td>
              <td width="60%" valign="top"><table width="100%" height="83" border="0" align="center">
                <tr>
                  <td width="365" height="22" align="center" ><span class="b1"></span></td>
                </tr>
                <tr>
                  <td height="20" align="center" class="b1"><span class="t1"></span></td>
                </tr>
                <tr>
                  <td align="center" > </td>
                </tr>
              </table></td>
              <td width="27%" align="right" valign="top"><table width="100%" align="right">
                <tr>
                  <td align="center"><img src="" width="40" height="40" /></td>
                  <td align="right" class="r"><strong></strong></td>
                </tr>
                 <tr>
              <td width="111" >Affiliation No.:</td>
              <td width="108" align="right" ><strong></strong></td>
            </tr>
            <tr>
              <td > School Code :</td>
              <td align="right"></td>
            </tr>
            <tr>
              <td><span >Recognition No.:</span></td>
              <td align="right"></td>
            </tr>
              </table></td>
          </tr>      
      </table>        
            </td>
          </tr>
          <tr align="left" valign="top">
            <td height="4" align="left"><hr/></td>
          </tr>
          <tr align="left" valign="top">
            <td height="165"> 
              <table width="1030" border="1">
<!--                <tr>
                  <td height="46" colspan="3" align="center" class="st4">Student&nbsp;Id:&nbsp;&nbsp;<strong></strong> &nbsp;</td>
                  <td colspan="4" align="center" class="st4">Student Name:&nbsp;&nbsp;&nbsp;&nbsp;<strong>
                    
                    &nbsp;</strong></td>
                </tr>-->
                <tr>
                  <td width="70" height="45"><strong  ></strong></td>
                  <td width="70" height="45" align="center" ><strong> </strong></td>
                  <td width="110" align="center" ><strong> </strong></td>
                  <td colspan="5" width="240" align="center" >English Language Development</td>
                  <td colspan="5" width="240" align="center" >Hindi Language Development</td>
                  <td colspan="5" width="240" align="center" >Numbers/Maths</td>
       
                </tr>
        <tr>
                  <td height="23" align="center"  >Sr.No.</td>
                  <td align="center"  >R.No.</td>
                  <td align="center"  >Name</td>
                  
            <td align="center" >Ability to write
                    (30)</td>
            <td align="center" >Dictation
(20)
                    </td>
                    <td align="center" >Reading
(20)
                    </td>
                    <td align="center" >H. Writing
(10)
                    </td>
                    <td align="center" >Total
(80)
                    </td>
                            <td align="center" >Ability to write
                    (30)</td>
            <td align="center" >Dictation
(20)
                    </td>
                    <td align="center" >Reading
(20)
                    </td>
                    <td align="center" >H. Writing
(10)
                    </td>
                    <td align="center" >Total
(80)
                    </td>
                                <td align="center" >Ability to write
                    (30)</td>
            <td align="center" >Dictation
(20)
                    </td>
                    <td align="center" >Reading
(20)
                    </td>
                    <td align="center" >H. Writing
(10)
                    </td>
                    <td align="center" >Total
(80)
                    </td>
                 
                </tr>     
                
                
                 <tr>
                  <td height="23" align="center"  >1</td>
                  <td align="center"  ></td>
                  <td align="center"  ></td>
                  
            <td align="center" >
                    </td>
            <td align="center" >

                    </td>
                    <td align="center" >

                    </td>
                    <td align="center" >

                    </td>
                    <td align="center" >

                    </td>
                            <td align="center" >
                    </td>
            <td align="center" >
                    </td>
                    <td align="center" >

                    </td>
                    <td align="center" >

                    </td>
                    <td align="center" >

                    </td>
                                <td align="center" >
                   </td>
            <td align="center" >

                    </td>
                    <td align="center" >

                    </td>
                    <td align="center" >

                    </td>
                    <td align="center" >
                    </td>
                 
                </tr> 
                
                

        
            </table></td>
          </tr>
          
        </table></td>
      </tr>
    </table>
  </form>


</body>
</html>


