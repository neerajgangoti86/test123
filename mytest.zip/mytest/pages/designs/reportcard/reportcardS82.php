<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />


<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
                ?>
                <br>
                <br><?php
                ?>




                <table  border="1" align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td width="100%">
                            <table width="658" align="center" bordercolor="#2A3F00">
                                <tr align="left" valign="top">
                                    <td width="100%"> <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td>
                                </tr>
                            </table></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td height="22"><hr/></td>
                    </tr>
                    <tr align="left" valign="top">
                        <td valign="top"><br />
                            <table width="645" border="0" align="center">
                                <tr>
                                    <td colspan="3" class="b1"> 
                                        <?php echo $student->name ?> </td>
                                    <td width="98">&nbsp;</td>
                                    <td width="121" class="st4">&nbsp;</td>
                                    <td class="st4">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td width="147" height="29" class="st4">Student Id: </td>
                                    <td width="44" class="st4"><strong><?php echo $student->student_id ?></strong></td>
                                    <td width="65" class="st4">Class:</td>
                                    <td class="st4"><strong>
                                            <?php
                                            $cls = Master::get_classes($MSID, '', '', '', $student->class)->fetch(PDO::FETCH_OBJ);
                                            echo $cls->class_name;
                                            ?> 
                                        </strong></td>
                                    <td class="st4">Overall Grade:</td>
                                    <td width="99" class="st4"><strong> <? $ghi6=mysql_query($gh6="SELECT Q1.StudentId, Q1.Point,G.Grade,Q1.Class FROM (Select StudentId, MSID, Class, (Sum( `MarksObtained`)/SUM(`MaxMarks`)*100) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id') Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto` And  Q1.`Class` between  G.ClassFrom And 	G.ClassTo "); while($gow6=mysql_fetch_array($ghi6)){echo $Grade6=$gow6['Grade'];} ?></strong></td>
                                </tr>
                                <tr>
                                    <td height="28" class="st4">Father's Name:</td>
                                    <td colspan="4" class="st4"><strong>
                                            <?php echo "Mr." . ' ' . $student['f_name']; ?>
                                        </strong></td>
                                    <td class="st4">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td height="28" class="st4">Mother's Name:</td>
                                    <td colspan="4" class="st4"><strong>
                                            <?php echo "Mrs." . ' ' . $student['m_name']; ?>
                                        </strong></td>
                                    <td class="st4">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="6" align="center"><strong class="st3"><u><br />
                                                Academic Performance <?php echo $oCurrentUser->mysession; ?>-<?php echo $session2 = $oCurrentUser->mysession + 1; ?><br />
                                            </u></strong></td>
                                </tr>
                                <tr>
                                    <td height="146" colspan="7"><table width="583" border="1" align="center">
                                            <tr>
                                                <td width="158" rowspan="2" align="left" valign="top" bgcolor="#C9C9C9"><strong class="st4">Subjects</strong></td>
                                                <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>First Term </strong></td>
                                                <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Second Term</strong></td>
                                                <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Final Term</strong></td>
                                                <td width="99" rowspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Term Grade</strong></td>  
                                            </tr>
                                            <tr>
                                                <td align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                                                <td align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                                                <td width="52" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                                                <td width="49" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                                                <td width="40" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                                                <td width="47" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                                            </tr>
                                            <?php
                                            $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student['student_id'], $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                            while ($rowv = $subjects_querry->fetch()) {
                                            ?> 
                                            <tr class="st4">
                                                <td align="left"><?php
                                                    $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                                    while ($rowu = $subjects->fetch()) {
                                                    echo $rowu['name'];
                                                    }
                                                    ?></td>

                                                <td width="54" align="left"><?php
                                                    $fa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '1', $rowv['subject_id'], 'YES');
                                                    while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                        $marks1 = $rowu['marks_obtained'];
                                                        $maxm1 = $rowu['max_marks'];
                                                    }
                                                    ?></td>
                                                <td width="32" align="left"><?php
                                                            echo @$marks1
                                                            ?></td> 

                                                <td align="left">&nbsp;&nbsp;<?php $ghiy2 = mysql_query($ghy2 = "SELECT (MarksObtained) as marks2, MaxMarks FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='2'  And `Class`= '$cl'");
                                                    while($gowy2 = mysql_fetch_array($ghiy2)){echo $MarksObtained2 = $gowy2['marks2'];
                                                    $MaxMarks2 = $gowy2['MaxMarks'];
                                                    } ?></td>
                                                <td align="left"><?   if($MaxMarks2=='0'){}else{ echo $MaxMarks2;}?></td> 

                                                <td align="left">&nbsp;&nbsp;<?php $ghiy3 = mysql_query($ghy3 = "SELECT (MarksObtained) as marks3, MaxMarks FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='3'  And `Class`= '$cl'");
                                                    while($gowy3 = mysql_fetch_array($ghiy3)){echo $MarksObtained3 = $gowy['marks3'];
                                                    $MaxMarks3 = $gowy3['MaxMarks'];
                                                    } ?> </td>
                                                <td align="left"><?   if($MaxMarks3=='0'){}else{ echo $MaxMarks3;}?></td> 


                                                <td width="99" align="left">&nbsp;&nbsp;<?    if($sb!='2054'&&$sb!='2056'&&$sb!='2060'){
                                                    $ghiyz=mysql_query($ghyz1="SELECT  (Sum(`MarksObtained`)/Sum(MaxMarks)*100) as per  FROM `21Repodata1`  WHERE MSID='$msid' AND  `Session`='$session' AND StudentId='$s_id'  AND  `SubjectId`='$sb'   "); while($gowyz1=mysql_fetch_array($ghiyz)){    $per=$gowyz1['per'];    }  ?><?  $ghiy1=mysql_query($ghy1="SELECT   Grade FROM   23Grades   where   MSID='$msid' AND '$per' BETWEEN  `PercentFrom` AND  `Percentto`"); while($gowy1=mysql_fetch_array($ghiy1)){  $StudentId=$gowy1['StudentId'];   echo $Grade1=$gowy1['Grade']; } 			}else {}?></td> 
                                            </tr><?php } ?>
                                        </table></td>
                                </tr>
                            </table>
                            <br />
                            <table width="570" border="1" align="center">
                                <tr>
                                    <td class="st4">Remarks:
                                        <hr /><?  $ghiy1=mysql_query($ghy1="SELECT * from `21Remarks_Inc_Grades` where  MSID ='$msid' And 	Grade='$Grade6'"); while($gowy1=mysql_fetch_array($ghiy1)){  echo $Remarks=$gowy1['Remarks']; }?><br />
                                        <br />
                                        <br />
                                        <br />
                                    </td>
                                </tr>
                            </table>
                            <br />
                            <table width="570" border="0" align="center">
                                <tr>
                                    <td align="center">....................</td>
                                    <td align="center">...........................</td>
                                    <td align="center">........................</td>
                                    <td align="center">.....................</td>
                                </tr>
                                <tr class="st4">
                                    <td align="center"><strong>Mother</strong></td>
                                    <td align="center"><strong>Father/Guardian</strong></td>
                                    <td align="center"><strong>Class Teacher</strong></td>
                                    <td align="center"><strong>Principal</strong></td>
                                </tr>
                            </table>
                            <br />
                            <br /></td>
                    </tr>
                </table></td>
                </tr>
                </table>  <form id="contactform" name="contactform" method="post" action="../student_detail/reports/admin.php">

                    <input type="button" value="Print" onclick="printpage();">
                    <input type="submit" name="Submit" value="Exit" />
                </form>
<?php }} ?>

                </body>
                </html>
                <? }?>