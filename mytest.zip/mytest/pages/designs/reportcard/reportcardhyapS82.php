<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } if($_POST){  $sid=$_POST['c'];
$cno1=$_GET['cno'];  $cno = mysql_real_escape_string($cno1);
}else {
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 $id1=$_GET['id'];$sid = mysql_real_escape_string($id1);}


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$sid' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $s_id= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass']; $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; $AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail']; 
} ?>::Half Yearly Report Card</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
</head>
 
<body>

    <table width="674" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"  border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="100%"><table width="658" height="491" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="100%" height="76"><table width="99%" align="center">
              <tr>
                <td colspan="3" align="center"><span class="m1">
                  <?php  echo $sname;?>
                </span></td>
              </tr>
              <tr>
                <td width="90" align="left"><img    src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/mspslogo.jpg";} ?>" width="75" height="75" class="logo"></td>
                <td width="340" valign="top"><table width="333" border="0" align="center">
                  <tr>
                    <td width="327" align="center" ><span class="b1">
                      <?php  echo $Place; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="b1"><span class="t1">
                      <?php  echo $Board; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="t1">&nbsp;</td>
                  </tr>
                </table></td>
                <td width="199" align="right" valign="top"><table width="100%" border="0" align="right">
                  <tr>
                    <td align="center"><img src="../student_detail/reports/phone.jpg" width="25" height="23" /></td>
                    <td align="right" class="r"><strong>
                      <?php  echo $Phone; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td width="107" class="r">Affiliation No.:</td>
                    <td width="109" align="right" class="r"><strong>
                      <?php  echo $AffiliationNo; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td class="r"> School Code :</td>
                    <td align="right"><span class="r"><strong>
                      <?php  echo $SchoolNo; ?>
                    </strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="r">Recognition No.:</span></td>
                    <td align="right"><strong class="r">
                      <?php  echo $Reconiation_no; ?>
                    </strong></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr align="left" valign="top">
            <td height="22"><hr/></td>
          </tr><?php  
 $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.Village, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' and  S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$s_id' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0) " );while($row=mysql_fetch_array($result)){$s_id=$row['sid'];$class=$row['CClass'];$name=$row['Name'];$mn=$row['MotherName'];
$fn=$row['FatherName']; $Photo=$row['Photo'];
  ?>
          <tr align="left" valign="top">
            <td valign="top"><br />
              <table width="645" border="0" align="center">
                <tr>
                 <!-- <td width="41" rowspan="5" class="st4"><?php  //if($Photo!=""){echo '<img src="'.$Photo=$row['Photo'].'" width="99" height="126"/>';?><? //}else {}?></td>-->
                  <td colspan="3" class="b1"> 
                    <?php  echo $name;?> </td>
                  <td width="98">&nbsp;</td>
                  <td width="121" class="st4">&nbsp;</td>
                  <td class="st4">&nbsp;</td>
                </tr>
                <tr>
                  <!--<td width="17" rowspan="5" valign="top"><?PHP  //$img= $row['Photo'];?></td>-->
                <td width="147" height="29" class="st4">Student Id: </td>
                <td width="44" class="st4"><strong><?php echo $s_id;?></strong></td>
                <td width="65" class="st4">Class:</td>
                <td class="st4"><strong>
                  <?php  $result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$class' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){   echo $row2['ClassName'];   $cl=$row2['ClassNo']; }?>
                </strong></td>
                <td class="st4">Overall Grade:</td>
                <td width="99" class="st4"><strong> <? $ghi6=mysql_query($gh6="SELECT Q1.StudentId, Q1.Point,G.Grade,Q1.Class FROM (Select StudentId, MSID, Class, (Sum( `MarksObtained`)/SUM(`MaxMarks`)*100) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id') Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto` And  Q1.`Class` between  G.ClassFrom And 	G.ClassTo "); while($gow6=mysql_fetch_array($ghi6)){echo $Grade6=$gow6['Grade'];} ?></strong></td>
              </tr>
              <tr>
                <td height="28" class="st4">Father's Name:</td>
                <td colspan="4" class="st4"><strong>
                  <?php  echo "Mr.".' '.$fn;?>
                </strong></td>
                <td class="st4">&nbsp;</td>
              </tr>
              <tr>
                <td height="28" class="st4">Mother's Name:</td>
                <td colspan="4" class="st4"><strong>
                  <?php  echo  "Mrs.".' '.$mn;?>
                </strong></td>
                <td class="st4">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="6" align="center"><strong class="st3"><u><br />
                  Half Yearly Academic Performance <? echo $session; ?><br />
                  <br />
                </u></strong></td>
                </tr>
              <tr>
                <td height="146" colspan="7"><table width="583" border="1" align="center">
                  <tr>
                    <td width="158" rowspan="2" align="left" valign="top" bgcolor="#C9C9C9"><strong class="st4">Subjects</strong></td>
                    <?php $ghi=mysql_query($gh="SELECT distinct Assesment , AssID FROM `assesments` Where Term='Term 1' And `MSID`='$msid' "); while($gow=mysql_fetch_array($ghi)){ ?> <?php   $ann=$gow['Assesment'];$AssID=$gow['AssID'];?> <?php }?>
                    <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>First Term </strong></td>
                    
                    <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Second Term</strong></td>
                    <td colspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Final Term</strong></td>
                    <td width="99" rowspan="2" align="left" valign="top" bgcolor="#C9C9C9" class="st4"><strong>Term Grade</strong></td>  <!---->
                  </tr>
                  <tr>
                    <td align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                    <td align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                    <td width="52" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                    <td width="49" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                    <td width="40" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MO</td>
                    <td width="47" align="left" valign="top" bgcolor="#C9C9C9" class="st4">MM</td>
                  </tr>
                 <?php  //echo "";
				
				 
			
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){ 
				 
				?>
            <tr class="st4">
            <td align="left">&nbsp;&nbsp;<?php    $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></td>
 
           <td width="54" align="left">&nbsp;&nbsp;<?php  $ghiy=mysql_query($ghy="SELECT (MarksObtained) as marks, MaxMarks FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='1'  And `Class`= '$cl'"); while($gowy=mysql_fetch_array($ghiy)){echo $MarksObtained=$gowy['marks'] ;   $MaxMarks5=$gowy['MaxMarks'];}
?></td>
           <td width="32" align="left"><?   if($MaxMarks5=='0'){}else{ echo $MaxMarks5;}?></td> 
         
            <td align="left">&nbsp;&nbsp;<?php  $ghiy2=mysql_query($ghy2="SELECT (MarksObtained) as marks2, MaxMarks FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='2'  And `Class`= '$cl'"); while($gowy2=mysql_fetch_array($ghiy2)){echo $MarksObtained2=$gowy2['marks2'] ;   $MaxMarks2=$gowy2['MaxMarks'];}?></td>
            <td align="left"><?   if($MaxMarks2=='0'){}else{ echo $MaxMarks2;}?></td> 
             
            <td align="left">&nbsp;&nbsp;<?php $ghiy3=mysql_query($ghy3="SELECT (MarksObtained) as marks3, MaxMarks FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='3'  And `Class`= '$cl'"); while($gowy3=mysql_fetch_array($ghiy3)){echo $MarksObtained3=$gowy['marks3'] ;   $MaxMarks3=$gowy3['MaxMarks'];}?> </td>
            <td align="left"><?   if($MaxMarks3=='0'){}else{ echo $MaxMarks3;}?></td> 
 
 
            <td width="99" align="left">&nbsp;&nbsp;<?    if($sb!='2054'&&$sb!='2056'&&$sb!='2060'){
				 $ghiyz=mysql_query($ghyz1="SELECT  (Sum(`MarksObtained`)/Sum(MaxMarks)*100) as per  FROM `21Repodata1`  WHERE MSID='$msid' AND  `Session`='$session' AND StudentId='$s_id'  AND  `SubjectId`='$sb'   "); while($gowyz1=mysql_fetch_array($ghiyz)){    $per=$gowyz1['per'];    }  ?><?  $ghiy1=mysql_query($ghy1="SELECT   Grade FROM   23Grades   where   MSID='$msid' AND '$per' BETWEEN  `PercentFrom` AND  `Percentto`"); while($gowy1=mysql_fetch_array($ghiy1)){  $StudentId=$gowy1['StudentId'];   echo $Grade1=$gowy1['Grade']; } 			}else {}?></td> 
          </tr><?php  }?>
                </table></td>
              </tr>
            </table>
              <br />
            <table width="570" border="1" align="center">
              <tr>
                <td class="st4">Remarks:
                <hr /><?  $ghiy1=mysql_query($ghy1="SELECT * from `21Remarks_Inc_Grades` where  MSID ='$msid' And 	Grade='$Grade6'"); while($gowy1=mysql_fetch_array($ghiy1)){  echo $Remarks=$gowy1['Remarks']; }?><br />
<br />
<br />
<br />
</td>
              </tr>
              </table>
            <br />
            <table width="570" border="0" align="center">
              <tr>
                <td align="center">....................</td>
                <td align="center">...........................</td>
                <td align="center">........................</td>
                <td align="center">.....................</td>
              </tr>
              <tr class="st4">
                <td align="center"><strong>Mother</strong></td>
                <td align="center"><strong>Father/Guardian</strong></td>
                <td align="center"><strong>Class Teacher</strong></td>
                <td align="center"><strong>Principal</strong></td>
              </tr>
            </table>
            <br />
            <br /></td>
          </tr>
        </table></td>
      </tr>
    </table>  <form id="contactform" name="contactform" method="post" action="../student_detail/reports/admin.php">

    <input type="button" value="Print" onclick="printpage();">
  <input type="submit" name="Submit" value="Exit" />
  </form>
<?php  }}?>

</body>
</html>
<? }?>