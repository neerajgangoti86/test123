<?php
session_start();
include("../../connect/db.php");  
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffiliationNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['Reconiation_no'];
$EMail= $row['EMail']; 
} ?>::Registration Form</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
</head>
 
<body>

  <form id="contactform" name="contactform" method="post" action="../student_detail/reports/admin.php">
    <table width="54%" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="100%"><table width="89%" height="320" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="697" height="133">
            <table width="93%" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td height="22" colspan="3" align="center"><span class="m1"><?php echo $sname;?></span></td>
              </tr>
            <tr>
              <td width="13%" height="101" align="center" valign="middle">		<img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="60" height="60" class="logo"></td>
              <td width="60%" valign="top"><table width="100%" height="83" border="0" align="center">
                <tr>
                  <td width="365" height="22" align="center" ><span class="b1"><?php echo $Place; ?></span></td>
                </tr>
                <tr>
                  <td height="20" align="center" class="b1"><span class="t1"><?php echo $Board; ?></span></td>
                </tr>
                <tr>
                  <td align="center" class="t1">Record of Academic Performance <? echo $session; ?></td>
                </tr>
              </table></td>
              <td width="27%" align="right" valign="top"><table width="100%" align="right">
                <tr>
                  <td align="center"><img src="../student_detail/reports/phone.jpg" width="25" height="23" /></td>
                  <td align="right" class="r"><strong><?php echo $Phone; ?></strong></td>
                </tr>
                 <tr>
              <td width="111" class="r">Affiliation No.:</td>
              <td width="108" align="right" class="r"><strong><?php echo $AffiliationNo; ?></strong></td>
            </tr>
            <tr>
              <td class="r"> School Code :</td>
              <td align="right"><span class="r"><strong><?php echo $SchoolNo; ?></strong></span></td>
            </tr>
            <tr>
              <td><span class="r">Recognition No.:</span></td>
              <td align="right"><strong class="r"><?php echo $Reconiation_no; ?></strong></td>
            </tr>
              </table></td>
          </tr>
         
         
      </table>
            
            
            
            
            
            
            
            </td>
          </tr>
          <tr align="left" valign="top">
            <td height="4" align="left"><hr/></td>
          </tr>
          <tr align="left" valign="top">
            <td height="165"> <?php  $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
		  
  $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.*, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' and  S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno'  And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0) " );while($row=mysql_fetch_array($result)){  $row['Name'];
  ?>
              <table width="701" border="1">
                <tr>
                  <td height="46" colspan="3" align="center" class="st4">Student&nbsp;Id:&nbsp;&nbsp;<strong><?php echo $s_id=$row['sid']; ?></strong> &nbsp;</td>
                  <td colspan="4" align="center" class="st4">Student Name:&nbsp;&nbsp;&nbsp;&nbsp;<strong>
                    <?php  echo $row['Name']; ?>
                    &nbsp;</strong></td>
                </tr>
                <tr>
                  <td width="127" height="35"><strong class="st4" >Subject</strong></td>
                  <td width="79" align="center" class="st4"><strong>Unit 1</strong></td>
                  <td width="87" align="center" class="st4"><strong>Unit 2</strong></td>
                  <td width="85" align="center" class="st4"><strong>1st Semester </strong></td>
                  <td width="83" align="center" class="st4"><strong>Unit 3</strong></td>
                  <td width="100" align="center" class="st4"><strong>Unit 4</strong></td>
                  <td width="94" align="center" class="st4"><strong>Unit 5</strong></td>
                </tr>
              <? $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){ ?>  <tr>
                  <td height="33" align="left"  class="st4"><? $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
                  <td align="center"  class="st4"><?php  $ghiy8=mysql_query($ghy8="SELECT * from `21Repodata1` RD  WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['MarksObtained'];}?></td>
                  <td align="center"  class="st4"><?php $gr2=mysql_query($ghyn2="SELECT * from `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['MarksObtained'];}?></td>
                  <td align="center"  class="st4"><?php  $ghiy3=mysql_query($ghy3=" SELECT * from `21Repodata1` RD  WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy3=mysql_fetch_array($ghiy3)){echo $Grade3=$gowy3['MarksObtained'];}?></td>
                  <td align="center" class="st4"> <?php  $ghiy8=mysql_query($ghy8="SELECT * from `21Repodata1` RD  WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo  $gowy8['MarksObtained'];}?></td>
                  <td align="center" class="st4"> <?php $gr2=mysql_query($ghyn2="SELECT * from `21Repodata1` RD  WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $g2['MarksObtained'];}?></td>
                  <td align="center" class="st4"> <?php   $ghiy3=mysql_query($ghy3="SELECT * from `21Repodata1` RD  WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='6' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy3=mysql_fetch_array($ghiy3)){echo $gowy3['MarksObtained'];}?></td>
                </tr>      <? }?>
              <tr>
                <td height="17" colspan="6" align="right"  class="st4"><strong>Total</strong></td>
                <td align="center" class="st4"><? $ghih=mysql_query($ghh="Select StudentId, MSID, Sum( `MarksObtained`) TMO,SUM(`MaxMarks`) TM from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id'"); while($gowh=mysql_fetch_array($ghih)){
					echo  $gowh['TMO'].'/'.$gowh['TM'];} ?><? $ghi6=mysql_query($gh6="Select StudentId, MSID, round(Sum( `MarksObtained`)/SUM(`MaxMarks`)*100,2) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id'"); while($gow6=mysql_fetch_array($ghi6)){    $per=$gow6['Point'];} echo '('.$per.'%'.')';?></td>
              </tr>
        
            </table><? }/*SELECT Q1.StudentId, Q1.Point,G.Grade FROM (Select StudentId, MSID, round(Sum( `MarksObtained`)/SUM(`MaxMarks`)*100,2) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id') Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto`*/?></td>
          </tr>
          
        </table></td>
      </tr>
    </table>
  </form>


</body>
</html>
<? }?>