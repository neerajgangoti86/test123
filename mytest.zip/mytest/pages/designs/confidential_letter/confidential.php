<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
<style>
    .box .watermark {
        position: absolute;
        z-index: -1;
        top: 50px;
        bottom: 0;
        left: 150;
        right: 0;
        background: url(<?= CLIENT_URL ?>/uploads/photo_1458715104.jpg) center; 
        background-repeat:no-repeat;
        background-position:center;
        width:60%;
        opacity: .1;
    } 
</style>

<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
<?php if ($oCurrentSchool->watermark == 1) { ?>   <div class="watermark"></div> <?php } ?>
       <table width="706" border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="694">
            <table width="709" align="center" bordercolor="#2A3F00">
        <tr align="left" valign="top">
              <td  class="st4">   <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?></td></tr>
          <tr>  <td colspan="2" class="st4">
                  <table width="100%" cellpadding="5" class="b1">
  <tr>
    <td height="48" colspan="4" align="center" class="style15"><hr/>Confidential Letter<hr/></td>
    </tr>
  <tr>
    <td width="30%"><strong>Student's Name</strong></td>
    <td width="42%"><strong>:&nbsp;&nbsp;&nbsp;<?php echo $student['name']; ?></strong></td>
    <td width="10%" ><strong>Class</strong></td>
    <td width="18%"><strong>:&nbsp;&nbsp;&nbsp;   <?php
                                                                        $cls = Master::get_classes($MSID, '', '', '', $student['class'])->fetch(PDO::FETCH_OBJ);
                                                                        echo $cls->class_name;
                                                                        ?></strong></td>
  </tr>
 <tr>
    <td ><strong>Father's/Guardian's Name</strong></td>
    <td colspan="3"><strong>:&nbsp;&nbsp;&nbsp;<?php echo "Mr." . ' ' . $student['f_name']; ?></strong></td>
  </tr>
  <tr>
    <td colspan="4"><p>Dear Parents, <br />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Greetings from <?= $oCurrentSchool->name ?> ,<br />
      Congratulations! Now you can enjoy uninterrupted communication with teachers and can see your ward's details and activities online.</p></td>
  </tr>
  <tr>
    <td colspan="4">To Login to '<?= $oCurrentSchool->name ?>' Panel follow the steps</td>
    </tr>
  <tr>
    <td colspan="4">1) Visit official website of school <?php echo $oCurrentSchool->Website ;?></td>
  </tr>
  <tr>
    <td colspan="4">2) You will find a Link for Login.</td>
  </tr>
  <tr>
    <td colspan="4">3) There will be a space in that block to insert username and password.</td>
  </tr>
  <tr>
    <td colspan="4">4) Enter The username and password given below and enjoy browsing.</td>
  </tr>
  <tr>
    <td colspan="4"><table width="100%" cellpadding="5">
      <tr>
        <td width="25%">Student's Username</td>
        <td width="75%"><strong>:&nbsp;&nbsp;&nbsp;<?php echo $student['s_uid'];?></strong></td>
      </tr>
      <tr>
        <td>Student's Password</td>
        <td><strong>:&nbsp;&nbsp;&nbsp;<?php echo $student['s_pwd'];?></strong></td>
      </tr>
    <tr>
        <td>Parents Username:</td>
        <td><strong>:&nbsp;&nbsp;&nbsp;<?php echo  $student['uid'];?></strong></td>
      </tr>
      <tr>
        <td>Parents Password:</td>
        <td><strong>:&nbsp;&nbsp;&nbsp;<?php echo $student['password'];?></strong></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td colspan="4">FEATURES:</td>
    </tr>
  <tr>
    <td colspan="4"><p>1) View your ward's teacher and communicate directly.<br />
      2) See and download Time Table, Syllabus, Attendance records, Assignments, Date Sheets, Activity &nbsp;&nbsp;&nbsp;&nbsp;Calendar, Homework etc.<br />
      3) Ask your academic questions through online 'Questionnaire'.<br />
    </p></td>
  </tr>
  <tr>
    <td colspan="4">Important Note:</td>
  </tr>
  <tr>
    <td colspan="4"><p>1) You can login and change your password for your privacy.<br />
      2) Parents will be able to update and make any changes in personal details through their login.<br />
      3) In case of any enquiry or problem you can mail us at "<? if(@$oCurrentSchool->EMail!='No'){ echo $oCurrentSchool->EMail;}else{}?>"</p></td>
  </tr>
 <!-- <tr>
    <td colspan="4"><p>Thanks,<br />
      AM Visual Media Team</p></td>
  </tr>-->
  <tr>
    <td>Parent's/Guardian's Signature</td>
    <td colspan="3" align="right">Date:___________________</td>
  </tr>
            </table>
</td>
          </tr>
       
        </table></td>
      </tr>
    </table>




            </div>
            <!-- /.box -->
        </div>
    </div>
</section>









    
    
    
    
    
    
    