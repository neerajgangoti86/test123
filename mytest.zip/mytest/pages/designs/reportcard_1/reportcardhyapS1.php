
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<script language="javascript">
    function printpage()
    {
        window.print();
    }
</script>
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
                ?>
                <br>
                <br><?php
                ?>




                <table  border="1" align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td width="100%">
                            <table width="658" height="491" align="center" bordercolor="#2A3F00">
                                <tr align="left" valign="top">
                                    <td width="100%" height="76"><table width="99%" align="center">
                                            <tr>
                                                <td colspan="3" align="center"><span class="m1">
                                                        <?= $oCurrentSchool->name ?>
                                                    </span></td>
                                            </tr>
                                            <tr>
                                                <td width="90" align="left"><img class="logo" src="<?php
                                                    if ($oCurrentSchool->logo_img != "") {
                                                        echo CLIENT_URL . "/uploads/thumbs/" . $oCurrentSchool->logo_img;
                                                    } else {
                                                        echo ASSETS_FOLDER . "/img/aboutlogo.jpg";
                                                    }
                                                    ?>"  width="90" height="100"></td>
                                                <td width="340" valign="top"><table width="333" border="0" align="center">
                                                        <tr>
                                                            <td width="327" align="center" ><span class="b1">
                                                                    <?= $oCurrentSchool->place ?> 
                                                                </span></td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center" class="b1"><span class="t1">
                                                                    <?= $oCurrentSchool->board ?>
                                                                </span></td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center" class="t1">&nbsp;</td>
                                                        </tr>
                                                    </table></td>
                                                <td width="199" align="right" valign="top"><table width="100%" border="0" align="right">
                                                        <tr>
                                                            <td align="center"><img src="<?= ASSETS_FOLDER ?>/img/phone.jpg" width="26" height="17" /></td>
                                                            <td align="right" class="r"><strong><?= $oCurrentSchool->phone; ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="107" class="r">Affiliation No.:</td>
                                                            <td width="109" align="right" class="r"><strong>
                                                                    <?= $oCurrentSchool->affNo ?>  
                                                                </strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="r"> School Code :</td>
                                                            <td align="right"><span class="r"><strong>
                                                                        <?= $oCurrentSchool->schoolNo ?>   
                                                                    </strong></span></td>
                                                        </tr>
                                                        <tr>
                                                            <td><span class="r">Recognition No.:</span></td>
                                                            <td align="right"><strong class="r">
                                                                    <?= $oCurrentSchool->recNo ?>
                                                                </strong></td>
                                                        </tr>
                                                    </table></td>
                                            </tr>
                                        </table></td>
                                </tr>
                                <tr align="left" valign="top">
                                    <td height="22"><hr/></td>
                                </tr>

                                <tr align="left" valign="top">
                                    <td valign="top"><br />
                                        <table width="645" border="0" align="center">
                                            <tr>
                                                <td width="30" rowspan="5" class="st4"></td>
                                                <td colspan="2" class="b1"> 
                                                    <b><?php echo $student['name']; ?></b> </td>
                                                <td width="3">&nbsp;</td>
                                                <td width="179" class="st4">&nbsp;</td>
                                                <td class="st4">&nbsp;</td>
                                            </tr>

                                            <tr>

                                                <td width="140" height="29" class="st4">Student Id: </td>
                                                <td colspan="3" class="st4"><strong><?php echo $student['student_id']; ?> </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class:<strong>
                                                      <?php
                                                                        $cls = Master::get_classes($MSID, '', '', '', $student['class'])->fetch(PDO::FETCH_OBJ);
                                                                        echo $cls->class_name;
                                                                        ?>  </strong>
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Overall grade:</td>
                                                <td width="116" class="st4"><strong>
                                                        <?php
                                                        $grade_sql = Exam::exam_overall_grade_calculater($MSID, $student['student_id']);
                                                        while ($gow6 = $grade_sql->fetch()) {
                                                            echo $grade6 = $gow6['grade'];
                                                        }
                                                        ?>
                                                    </strong></td>
                                            </tr>

                                            <tr>
                                                <td height="28" class="st4">Father's Name:</td>
                                                <td colspan="3" class="st4"><strong>
                                                        <?php echo "Mr." . ' ' . $student['f_name']; ?>
                                                    </strong></td>
                                                <td class="st4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td height="28" class="st4">Mother's Name:</td>
                                                <td colspan="3" class="st4"><strong>
                                                        <?php echo "Mrs." . ' ' . $student['m_name']; ?>
                                                    </strong></td>
                                                <td class="st4">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td width="151">&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td height="146" colspan="6"><table width="570" border="0" align="center">
                                                        <tr>
                                                            <td colspan="5" align="center"><strong class="st3"><u>Half Yearly Academic Performance<br />
                                                                        <br />
                                                                    </u></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="72" align="left"><strong class="st4">Subjects</strong></td>

                                                            <?php
                                                            $sql_assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), '', '', '', 'Term 1', 'YES');
                                                            while ($rowv = $sql_assesments->fetch()) {
                                                                ?>
                                                                <td width="71" align="center" class="st4"><strong class="st4"><?= $rowv['title'] ?>
                                                                    </strong></td><?php } ?>

                                                            <td width="71" align="center" class="st4"><strong>Term grade</strong></td>
                                                        </tr>
                                                        <?php
                                                        $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student['student_id'], $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                                        while ($rowv = $subjects_querry->fetch()) {
                                                            ?>
                                                            <tr class="st4">
                                                                <?php
                                                                $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                                                while ($rowu = $subjects->fetch()) {
                                                                    ?><td><?= $rowu['name'] ?></td>
                                                                    <?php
                                                                }
                                                                ?>

                                                                <td width="132" align="center">
                                                                    <?php
                                                                    $fa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '1', $rowv['subject_id'], 'YES');
                                                                    while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                                        ?><?= $rowu['Grade'] ?>
                                                                        <?php
                                                                    }
                                                                    ?></td>


                                                                <td width="147" align="center">
                                                                    <?php
                                                                    $fa2 = Exam::exam_grade_calculater($MSID, $student['student_id'], '2', $rowv['subject_id'], 'YES');
                                                                    while ($rowu = $fa2->fetch()) {
                                                                        ?><?= $rowu['Grade'] ?>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </td>
                                                                <td width="75" align="center">
                                                                    <?php
                                                                    $sa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '5', $rowv['subject_id'], 'YES');
                                                                    while ($rowu = $sa1->fetch()) {
                                                                        ?><?= $rowu['Grade'] ?>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </td>


                                                                <td width="122" align="center">
                                                                    <?php
                                                                    $overall = Exam::exam_term_grade_calculater($MSID, $student['student_id'], '1', $rowv['subject_id']);
                                                                    while ($rowu = $overall->fetch()) {
                                                                        ?><?= $rowu['grade'] ?>
                                                                    <?php } ?></td>
                                                            </tr><?php } ?>
                                                        <tr>
                                                            <td align="center">&nbsp;</td>
                                                            <td align="center">&nbsp;</td>
                                                            <td align="center">&nbsp;</td>
                                                            <td align="center">&nbsp;</td>
                                                            <td align="center">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                        </tr>
                                                    </table></td>
                                            </tr>
                                        </table>
                                        <br />
                                        <table width="570" border="1" align="center">
                                            <tr>
                                                <td class="st4">Remarks:
                                                    <hr /><br />
                                                    <br />
                                                    <br />
                                                    <br />
                                                    <br />
                                                    <br />
                                                    <br />
                                                    <br />
                                                </td>
                                            </tr>
                                        </table>
                                        <br />
                                        <table width="570" border="0" align="center">
                                            <tr>
                                                <td align="center">....................</td>
                                                <td align="center">...........................</td>
                                                <td align="center">........................</td>
                                                <td align="center">.....................</td>
                                            </tr>
                                            <tr class="st4">
                                                <td align="center"><strong>Mother</strong></td>
                                                <td align="center"><strong>Father/Guardian</strong></td>
                                                <td align="center"><strong>Class Teacher</strong></td>
                                                <td align="center"><strong>Principal</strong></td>
                                            </tr>
                                        </table>
                                        <br />
                                        <br /></td>
                                </tr></table></td>
                    </tr>
                </table>  
                <br />

                <form id="contactform" name="contactform" method="post" action="">

                    <input type="button" value="Print" onclick="printpage();">
                    <input type="submit" name="Submit" value="Exit" />
                </form>












            </div>
            <!-- /.box -->
        </div>
    </div>
</section>








