<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate'];  
$Add_ReportC= $row['Add_ReportC'];

} ?>::Report Card</title>
<?  $cno1=$_GET['cno']; $cno = mysql_real_escape_string($cno1);
 //$id1=$_GET['id'];$sid = mysql_real_escape_string($id1);


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $CClass= $gow5['CClass'];  $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?>


<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.b11 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; font-weight:500; 
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>
      <table width="711" height="702" border="1"   align="center" cellpadding="2" cellspacing="2">
        <tr>
          <td width="699" height="696"><table width="100%" height="706" align="center" bordercolor="#2A3F00">
            <tr align="left" valign="top">
              <td width="710" height="135" align="center"><table width="100%" height="132" align="center">
                <tr>
                  <td width="133" height="25" align="center" valign="top"><span class="n1">Affiliation No.:<? echo $AffiliationNo;?></span></td>
                  <td width="569" rowspan="3" align="center" valign="top"><table width="100%" border="0" align="center">
                    <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
                    <tr>
                      <td width="539" height="32" align="center" class="m1"><?php echo $sname;?></td>
                    </tr>
                    <tr>
                      <td height="19" align="center" class="b11">(SENIOR SECONDARY)</td>
                    </tr>
                    <tr>
                      <td height="14" align="center" class="b11"><? echo   $Place;  ?></td>
                    </tr>
                    <tr>
                      <td height="14" align="center" class="b11">(Affiliated to C.B.S.E. , New Delhi)</td>
                    </tr>
                    <tr>
                      <td height="24" align="center" class="b11"><!--Website:<? //echo $Website;?>,-->
                        E-mail:<? echo $EMail;?></td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td height="20" align="center" valign="top"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
                </tr>
                <tr>
                  <td height="20" align="center" valign="top"><span class="n1">School No.:<? echo $SchoolNo;?></span></td>
                </tr>
              </table></td>
            </tr>
            <tr align="left" valign="top">
              <td height="21" align="center"><hr/>
                <span class="vks">Record of Academic Performance <? echo $session; ?>
                  <hr/>
                </span></td>
            </tr>
            <tr align="left" valign="top">
              <td height="136" align="center"><table width="100%" height="134" border="0" align="center">
                <tr valign="top" class="st42">
                  <td width="111" rowspan="5"><img style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php  if($Photo!=""){echo $Photo;} else { 	echo"../../images/myprofile1.png";} ?>" width="86" height="105" /></td>
                  <td width="124">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                  <td height="33"><strong><? echo $Name;?></strong></td>
                  <td height="33">&nbsp;</td>
                  <td width="102" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                  <td width="99" ><strong><? echo $sid;?><strong></td>
                </tr>
                <tr valign="top" class="st42">
                  <td height="21">Father's Name:</td>
                  <td width="228" height="21"><strong>Mr. <? echo $FatherName;?></strong></td>
                  <td width="1" height="21">&nbsp;</td>
                </tr>
                <tr valign="top" class="st42">
                  <td height="24">Mother's Name:</td>
                  <td height="24"><strong>Mrs. <? echo $MotherName;?></strong></td>
                  <td height="24">&nbsp;</td>
                  <td>Class:</td>
                  <td><strong>
                    <? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
                  </strong> &nbsp;</td>
                </tr>
                <tr valign="top" class="st42">
                  <td height="24">Mobile</td>
                  <td height="24"><strong><? echo $F_Mobile;?></strong></td>
                  <td height="24">&nbsp;</td>
                  <td>Date Of Birth: </td>
                  <td><strong>
                    <? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?>
                  </strong> &nbsp;</td>
                </tr>
                
              </table></td>
            </tr>
            <tr align="left" valign="top">
              <td height="199"><br/>
                <table width="100%" height="176" border="1" align="center">
                  <tr valign="top" bgcolor="#E8E8E8">
                    <td height="44" align="center" class="st411" valign="middle">&nbsp;</td>
                    <td height="44" colspan="2" align="center"valign="middle" class="st411"><h3><strong>Unit I</strong></h3></td>
                    <td height="44" colspan="2" align="center"valign="middle" class="st411"><h3><strong>Unit II</strong></h3></td>
                    <td height="44" colspan="2" align="center"valign="middle" class="st411"><h3><strong>Terminal I</strong></h3></td>
                    <td height="44" align="center"valign="middle" class="st411"><strong>Final Assessment</strong></td>
                  </tr>
                  <tr valign="top"  bgcolor="#C9C9C9">
                    <td width="92" height="42" class="st411"><strong>Subjects</strong></td>
                    <td width="74" class="st411" align="center"><strong>MARKS OBTAINED</strong></td>
                    <td width="62" class="st411"  align="center"><strong>MAX MARKS</strong></td>
                    <td width="81" class="st411"  align="center"><strong>MARKS OBTAINED</strong></td>
                    <td width="58" class="st411"  align="center"><strong>MAX MARKS</strong></td>
                    <td width="74"  align="center" class="st411"><strong>MARKS OBTAINED</strong></td>
                    <td width="69"  align="center" class="st411"><strong>MAX MARKS</strong></td>
                    <td width="83" class="st411"  align="center"><strong>Total </strong></td>
                  </tr>
                  <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
                  <tr valign="top">
                    <td height="39" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
                    <td class="st411">&nbsp;
                      <?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,RD.`MaxMarks` FROM 
`21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){ $Grade8=$gowy8['MarksObtained']; echo round($Grade8); ?>
                      &nbsp;</td>
                    <td class="st411">&nbsp;<? echo $MaxMarks8=$gowy8['MaxMarks']; ?></td>
                    <? }?>
                    <td class="st411">&nbsp;
                      <?php   $ghiy9=mysql_query($ghy9="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy9=mysql_fetch_array($ghiy9)){ $Grade9=$gowy9['MarksObtained']; echo round($Grade9); ?></td>
                    <td class="st411">&nbsp;<? echo $MaxMarks9=$gowy9['MaxMarks']; ?></td>
                    <? } ?>
                    <td class="st411"><?php $ghiy16=mysql_query($ghy16="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,RD.`MaxMarks` FROM 
`21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy16=mysql_fetch_array($ghiy16)){ $Grade16=$gowy16['MarksObtained']; echo round($Grade16); ?></td>
                    <td class="st411"><? echo $MaxMarks16=$gowy16['MaxMarks']; ?></td>
                    <? } ?>
                    <td class="st411"><?php $ghiy3sum=mysql_query($ghy3sum= "SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,SUM(RD.`MarksObtained`)as summarks ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb' OR RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'  OR RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`");
			
			while($gowy3sum=mysql_fetch_array($ghiy3sum)){echo $Grade3sum=$gowy3sum['summarks'];}?>
                      &nbsp;</td>
                  </tr>
                  <?php   } ?>
                  <tr valign="top">
                    <td height="39" class="st411"><strong>Total</strong></td>
                    <td class="st411">&nbsp;
                      <?php   $ghiy10=mysql_query($ghy10="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,Sum(RD.`MarksObtained`)AS tmarks ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy10=mysql_fetch_array($ghiy10)){ $Grade10=$gowy10['tmarks']; echo round($Grade10); } ?></td>
                    <td class="st411">&nbsp;
                      <?php   $ghiy11=mysql_query($ghy11="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,Sum(RD.`MaxMarks`)AS tmaxmarks FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy11=mysql_fetch_array($ghiy11)){ $Grade11=$gowy11['tmaxmarks']; echo round($Grade11); } ?></td>
                    <td class="st411">&nbsp;
                      <?php   $ghiy12=mysql_query($ghy12="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,Sum(RD.`MarksObtained`)AS tmarks1 ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy12=mysql_fetch_array($ghiy12)){ $Grade12=$gowy12['tmarks1']; echo round($Grade12); } ?></td>
                    <td class="st411"><?php   $ghiy13=mysql_query($ghy13="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,Sum(RD.`MaxMarks`)AS tmaxmarks1 FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy13=mysql_fetch_array($ghiy13)){ $Grade13=$gowy13['tmaxmarks1']; echo round($Grade13); } ?></td>
                    <td class="st411"><?php   $ghiy14=mysql_query($ghy14="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,Sum(RD.`MarksObtained`)AS tmarks14 ,RD.`MaxMarks` FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy14=mysql_fetch_array($ghiy14)){ $Grade14=$gowy14['tmarks14']; echo round($Grade14); } ?></td>
                    <td class="st411"><?php   $ghiy15=mysql_query($ghy15="SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,RD.`MarksObtained` ,Sum(RD.`MaxMarks`)AS tmaxmarks14 FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy15=mysql_fetch_array($ghiy15)){ $Grade15=$gowy15['tmaxmarks14']; echo round($Grade15); } ?></td>
                    <td class="st411"><?php $ghiy3sum1=mysql_query($ghy3sum1= "SELECT RD.MSID, RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,SUM(RD.`MarksObtained`)as summarks1 ,SUM(RD.`MaxMarks`)as summax1 FROM `21Repodata1` RD WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' OR RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' OR RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' ORDER BY `StudentId`,`AssId`");
			
			while($gowy3sum1=mysql_fetch_array($ghiy3sum1)){echo $Grade3sum1=$gowy3sum1['summarks1'];?>
                      / <? echo $Grade3summax1=$gowy3sum1['summax1'];}?></td>
                  </tr>
              </table></td>
            </tr>
            <tr align="left" valign="top">
              <td height="153" valign="top"><table width="100%" height="151" border="0" align="center">
                <tr>
                  <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: &nbsp;&nbsp;
                    <? $trjjrm=mysql_query($qjjrm="Select Remarks from 21Remarks where SID='$sid' AND  MSID='$msid'  AND Session='$session'");
				 while($ttjjrm=mysql_fetch_array($trjjrm)){ echo $remarks=$ttjjrm['Remarks']; }?>
                  </strong><br/></td>
                </tr>
                
                <tr>
                  <td height="26" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>
                    <!--Note:</strong>(1)Promotion is based on the day -to -day continuous assessment throughout the year.(2) CGPA=Cumulative Grade Point Average (3) Subject Wise/Overall indicative percentage of Marks=9.5 X GP of the subject /CGPA.--></td>
                </tr>
                <tr>
                  <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                  <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
                </tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table>
      <p class="page"></p><p class="page"></p> 
      
<?php }}?>  
</body>
</html>
