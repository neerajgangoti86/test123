<?php // print_r($student); ?>

<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}

p.page { page-break-after: always; }
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>       <style type="text/css">
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
-->
</style>
<script language="javascript">
    function printpage()
    {
        window.print();
    }
</script><section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <?php
            if (@$id) {
                ?>
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title"> </h3>


                    </div>
                    <!-- /.box-header -->
                    <div class="box-footer clearfix">
                        <table width="748" height="822" border="1"   align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="736" height="816">  <table width="100%" height="810" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="733" height="140" align="center">
              <table width="100%" height="108" align="center">
                <tr>
                  <td width="87" height="102" align="left"><table width="88" border="0" align="center">
                    <tr>
                      <td width="82" height="92"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
                    </tr>
                  </table></td>
                  <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
                    <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
                    <tr>
                      <td width="539" height="32" align="center" class="m1"> <?php echo $sname;?> </td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="b1"> <? echo   $Place;  ?> </td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="n1">Website:<? echo $Website;?>,E-mail:<? echo $EMail;?>,Ph:<? echo $Phone;?></td>
                    </tr>
                    <tr>
                      <td height="21" align="center" class="n1">Affiliated to CBSE ,Delhi ,Affiliation No.:<? echo $AffiliationNo;?></td>
                    </tr>
                  </table>                    <span class="vks">Record of Academic Performance <? echo $session; ?></span></td>
                </tr>
              </table>      </td>
          </tr>
       
            
         <tr align="left" valign="top">
            <td height="103"><table width="100%" height="149" border="0" align="center">
              <tr valign="top" class="st42">
                <td width="139" rowspan="5"><img style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php  if($Photo!=""){echo $Photo;} else { 	echo"../../images/myprofile1.png";} ?>" width="122" height="127"></td>
                <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                <td height="27"><? echo $Name;?></td>
                <td height="27">&nbsp;</td>
                <td width="106" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                <td width="105" ><? echo $sid;?>&nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="31">Father's Name:</td>
                <td width="238" height="31">Mr. <? echo $FatherName;?></td>
                <td width="11" height="31">&nbsp;</td>
                <td>Roll No.:</td>
                <td><? echo $Roll_No;?>&nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="28">Mother's Name:</td>
                <td height="28">Mrs. <? echo $MotherName;?></td>
                <td height="28">&nbsp;</td>
                <td>Class:</td>
                <td><? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
                  &nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="23">Mobile:</td>
                <td height="23"><? echo $F_Mobile;?></td>
                <td height="23">&nbsp;</td>
                <td>Date Of Birth: </td>
                <td><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?>
                  &nbsp;</td>
              </tr>
              <tr valign="top" class="st42">
                <td height="12">Address:</td>
                <td height="12" colspan="4"><? echo $Add_ReportC;?></td>
              </tr>
            </table></td>
          </tr>
          
          <tr align="left" valign="top">
            <td height="78">
             <? //if($ULevel=='9'){ ?>
             <table width="100%" height="177" border="1" align="center">
               <tr valign="top" bgcolor="#E8E8E8">
                 <td height="30" class="st411">SCHOLASTIC AREA<br />
                   (5 point scale)</td>
                 <td colspan="4" class="st411" align="center">TERM I</td>
                 <td colspan="4" class="st411" align="center">TERM II</td>
                 <td colspan="4" align="center" class="st411">Final Assessment</td>
               </tr>
               <tr valign="top"  bgcolor="#C9C9C9">
                 <td height="30" class="st411"><strong>Subjects</strong></td>
                 <td class="st411">FA1
                   10%</td>
                 <td class="st411">FA2
                   10%</td>
                 <td width="31" class="st411">SA1
                   30%</td>
                 <td width="39" class="st411">Total 50%</td>
                 <td width="33" class="st411">FA3
                   10%</td>
                 <td width="30" class="st411">FA4
                   10%</td>
                 <td width="31" class="st411">SA2
                   30%</td>
                 <td width="39" class="st411">Total 50%</td>
                 <td width="37" class="st411">FA 40%</td>
                 <td width="37" class="st411">SA 60%</td>
                 <td width="102" class="st411"><span class="st4">Overall<br />
                   (FA+SA=100%)</span></td>
                 <td width="55" class="st411"><span class="st4">Grade Point</span></td>
               </tr>
               <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 	 $num_rows = mysql_num_rows($phi);  	while($pow=mysql_fetch_array($phi)){ $sb= $pow['SubjectId']; 
				 ?>
               <tr valign="top">
                 <td width="136" height="27" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
                 <td width="40" class="st411"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></td>
                 <td width="36" class="st411"><?php $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?></td>
                 <td class="st411"><?php $gr23=mysql_query($ghyn23="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g23=mysql_fetch_array($gr23)){echo $Gn23=$g23['Grade'];}?></td>
                 <td class="st411"><?php $gr2=mysql_query($ghyn2="select FL.msid,FL.stu_id,FL.cclass,FL.mo as percent,G.grade,G.gradepoint,FL.t from(select TG.msid,TG.stu_id,TG.cclass,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.cclass, term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.mysession,FA_PER.cclass,FA_PER.subjectid,
FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from(select 
FA1.msid,FA1.stu_id,FA1.mysession,FA1.cclass,RD.subjectid,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id ,S.mysession,S.admclassno+year(U.mydate)-year(S.fsdate)+COALESCE(sum(E.result),0) as cclass FROM `13Students` S inner join 91Users U on U.msid=S.msid left join 14Exam E on E.msid=S.msid and E.s_id=S.id where U.myuid='$foo' and S.id=$sid) as FA1 inner join 21Repodata1 RD 
on RD.msid=FA1.msid and RD.studentid=FA1.stu_id and RD.session=FA1.mysession inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid) as FA_PER ) as term1 inner join 22Weightage W 
on W.msid=term1.msid and W.assid=term1.assid and term1.cclass between W.classfrom and W.classto) as TG group by TG.subjectid,TG.t order by TG.t) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and FL.cclass between G.classfrom and G.classto where FL.subjectid='$sb' And FL.t ='1'  ORDER BY FL.subjectid"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['grade'];}?>
                   &nbsp;</td>
                 <td class="st411"><?php $gr232=mysql_query($ghyn232="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g232=mysql_fetch_array($gr232)){ echo $Gn232=$g232['Grade'];}?></td>
                 <td class="st411">&nbsp;
                   <?php $gr233=mysql_query($ghyn233="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g233=mysql_fetch_array($gr233)){echo $Gn233=$g233['Grade'];}?></td>
                 <td class="st411"><?php $gr234=mysql_query($ghyn234="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='6' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g234=mysql_fetch_array($gr234)){echo $Gn234=$g234['Grade'];}?></td>
                 <td class="st411"><?php $gr2t2=mysql_query($ghyn2t2="select FL.msid,FL.stu_id,FL.cclass,FL.mo as percent,G.grade,G.gradepoint,FL.t from(select TG.msid,TG.stu_id,TG.cclass,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.cclass, term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.mysession,FA_PER.cclass,FA_PER.subjectid,
FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from(select 
FA1.msid,FA1.stu_id,FA1.mysession,FA1.cclass,RD.subjectid,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id ,S.mysession,S.admclassno+year(U.mydate)-year(S.fsdate)+COALESCE(sum(E.result),0) as cclass FROM `13Students` S inner join 91Users U on U.msid=S.msid left join 14Exam E on E.msid=S.msid and E.s_id=S.id where U.myuid='$foo' and S.id=$sid) as FA1 inner join 21Repodata1 RD 
on RD.msid=FA1.msid and RD.studentid=FA1.stu_id and RD.session=FA1.mysession inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid) as FA_PER ) as term1 inner join 22Weightage W 
on W.msid=term1.msid and W.assid=term1.assid and term1.cclass between W.classfrom and W.classto) as TG group by TG.subjectid,TG.t order by TG.t) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and FL.cclass between G.classfrom and G.classto where FL.subjectid='$sb' And FL.t ='2'  ORDER BY FL.subjectid"); while($g2t2=mysql_fetch_array($gr2t2)){echo $Gn2t2=$g2t2['grade'];}?></td>
                 <td class="st411"><?php $gr2f=mysql_query($ghyn2f="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(SUM(RD.`MarksObtained`)/ SUM(RD.`MaxMarks`)*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/ RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`<'5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And G.ClassTo"); while($g2f=mysql_fetch_array($gr2f)){ echo $Gn2f=$g2f['Grade'];}?>
                   &nbsp;</td>
                 <td class="st411"><?php $gr2f1=mysql_query($ghyn2f1="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(SUM(RD.`MarksObtained`)/ SUM(RD.`MaxMarks`)*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/ RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`>'4' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And G.ClassTo"); while($g2f1=mysql_fetch_array($gr2f1)){echo $Gn2f1=$g2f1['Grade'];}?></td>
                 <td class="st411"><?php $gr2f11=mysql_query($ghyn2f11="select FL.msid,FL.stu_id,FL.cclass,FL.mo as percent,G.grade,G.gradepoint,FL.t from(select TG.msid,TG.stu_id,TG.cclass,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.cclass, term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.mysession,FA_PER.cclass,FA_PER.subjectid,
FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from(select 
FA1.msid,FA1.stu_id,FA1.mysession,FA1.cclass,RD.subjectid,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id ,S.mysession,S.admclassno+year(U.mydate)-year(S.fsdate)+COALESCE(sum(E.result),0) as cclass FROM `13Students` S inner join 91Users U on U.msid=S.msid left join 14Exam E on E.msid=S.msid and E.s_id=S.id where U.myuid='$foo' and S.id=$sid) as FA1 inner join 21Repodata1 RD 
on RD.msid=FA1.msid and RD.studentid=FA1.stu_id and RD.session=FA1.mysession inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid) as FA_PER ) as term1 inner join 22Weightage W 
on W.msid=term1.msid and W.assid=term1.assid and term1.cclass between W.classfrom and W.classto) as TG group by TG.subjectid,TG.t) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and FL.cclass between G.classfrom and G.classto where FL.subjectid='$sb' GROUP by FL.stu_id ORDER BY FL.subjectid");  while($g2f11=mysql_fetch_array($gr2f11)){echo $Gn2f11=$g2f11['grade']; $gradepoint=$g2f11['gradepoint']; $totalgrd=$gradepoint+$totalgrd; }?></td>
                 <td class="st411"><? echo $gradepoint; ?></td>
               </tr>
               <?php   }
		  ?>
               <tr valign="top">
                 <td height="17" class="st411">ATTENDANCE</td>
                 <?php 
				 $att1=mysql_query($aq1="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='1'"); 
				
				 while($at1=mysql_fetch_array($att1)){ $Term1WD= $at1['TWD']; $Term1Att= $at1['TERMATT'];} ?>
                 <td colspan="2" class="st411"><? echo $Term1Att ;?>/ <? echo $Term1WD ;?></td>
                 <td colspan="2" class="st411"><? $tatt= ($Term1Att/$Term1WD) * 100 ; echo round($tatt,2) ;?>
                   %</td>
                 <?php 
				 $att1a2=mysql_query($aq1a2="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='2'");
				
				 while($at1a2=mysql_fetch_array($att1a2)){ $Term1WDa2= $at1a2['TWD']; $Term1Atta2= $at1a2['TERMATT'];} ?>
                 <td colspan="2" class="st411"><? echo $Term1Atta2 ;?>
                   /
                   <? echo $Term1WDa2 ;?></td>
                 <td colspan="2" class="st411"><? $tatta2= ($Term1Atta2/$Term1WDa2) * 100 ; echo round($tatta2,2) ;?>
                   %</td>
                 <td class="st411"><? echo $TotalAtt=$Term1Att+$Term1Atta2 ;?>
                   /
                   <?  echo $TotalWD=$Term1WD+$Term1WDa2 ;?></td> 
                 <td class="st411"><? $TotalTermAtt= ($TotalAtt/$TotalWD) * 100 ; echo round($TotalTermAtt,2) ;?>
                   %</td>
                 <td class="st411">CGPA</td>
                 <td class="st411"><?  $grandtotal=($totalgrd/$num_rows); echo round($grandtotal,1); ?></td>
               </tr>
               <tr valign="top">
                 <td height="25" colspan="13" align="left" class="st2">Note:A+=90%-100%;A=75%-89%;B=56%-74%;C=35%-55%;D=Below 35%</td>
               </tr>
             </table>
             <table width="100%" height="221" border="1" align="center">
               <tr valign="top" bgcolor="#E8E8E8">
                 <td height="46" class="st41">Co-SCHOLASTIC AREA <br />
                   (Grading Scale A*,A,B,C,D)</td>
                 <td colspan="4" align="center" class="st41">Grade</td>
                 <td colspan="4" align="center" class="st41">Co-SCHOLASTIC AREA <br />
                   (Grading Scale A*,A,B,C,D)</td>
                 <td align="center" class="st41">Grade</td>
                 <td colspan="4" align="center" class="st41">Health Status</td>
               </tr>
               <tr valign="top" >
                 <td height="12" class="st41">GAMES</td>
                 <td colspan="4" class="st41"><?php 
				 $tr=mysql_query($q="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='GAMES' and MSID='$msid' and Term='2' ");
				 while($tt=mysql_fetch_array($tr)){ $sb0= $tt['Marks']; } 
				 $tr101=mysql_query($q101="Select * from grade2 where GRADE_ID='$sb0'");
				 while($tt101=mysql_fetch_array($tr101)){echo  $sb101= $tt101['GRADE_NAME']; } ?></td>
                 <td colspan="4" class="st41">GENERAL AWARENESS</td>
                 <td class="st41"><span class="st412">
                   <?php 
				 $tr1=mysql_query($q1="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='General Awareness' and MSID='$msid' and Term='2' ");
				 while($tt1=mysql_fetch_array($tr1)){  $sb1= $tt1['Marks']; }  $tr102=mysql_query($q102="Select * from grade2 where GRADE_ID='$sb1'");
				 while($tt102=mysql_fetch_array($tr102)){echo  $sb102= $tt102['GRADE_NAME']; } ?>
                 </span></td>
                 <td width="46" class="st41">&nbsp;</td>
                 <td width="47" class="st41">BMI</td>
                 <td width="55" class="st41">HEIGHT<br />
                   (in CM)</td>
                 <td width="51" class="st41">WEIGHT<br />
                   (in KG)</td>
               </tr>
               <tr valign="top"  >
                 <td height="12" class="st41">ART/CRAFT</td>
                 <td colspan="4" class="st41"><?php 
				 $tr2=mysql_query($q2="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='ART/CRAFT' and MSID='$msid' and Term='2' ");
				 while($tt2=mysql_fetch_array($tr2)){ $sb2= $tt2['Marks']; }  $tr103=mysql_query($q103="Select * from grade2 where GRADE_ID='$sb2'");
				 while($tt103=mysql_fetch_array($tr103)){echo  $sb103= $tt103['GRADE_NAME']; } ?></td>
                 <td colspan="4" class="st41">REGULARITY AND PUNCTUALITY</td>
                 <td class="st41"><span class="st412">
                   <?php 
				 $tr3=mysql_query($q3="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='REGULARITY AND PUNCTUALITY' and MSID='$msid' and Term='2' ");
				 while($tt3=mysql_fetch_array($tr3)){ $sb3= $tt3['Marks']; }  $tr104=mysql_query($q104="Select * from grade2 where GRADE_ID='$sb3'");
				 while($tt104=mysql_fetch_array($tr104)){echo  $sb104= $tt104['GRADE_NAME']; }   ?>
                 </span></td>
                 <td class="st41">Term-I</td>
                 <?php 
				 $trh3=mysql_query($qh3="Select * from 21Repodata4healthsts where StudentId='$sid' and Session='$session' And MSID='$msid' and Term='1'");
				
				 while($tth3=mysql_fetch_array($trh3)){ $height1= $tth3['Height']; $weight1= $tth3['Weight']; }  ?>
                 <td class="st41"><? $height=$height1/100;   $bmi=$weight1/$height; $bmii=$bmi/$height; echo round($bmii,2) ; ?></td>
                 <td class="st41"><? echo $height1; ?></td>
                 <td class="st41"><? echo $weight1; ?></td>
               </tr>
               <tr valign="top"  >
                 <td height="12" class="st41">MUSIC/DANCE</td>
                 <td colspan="4" class="st41"><span class="st412">
                   <?php 
				 $tr4=mysql_query($q4="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='MUSIC/DANCE' and MSID='$msid'  and Term='2' ");
				 while($tt4=mysql_fetch_array($tr4)){  $sb4= $tt4['Marks']; }   $tr105=mysql_query($q105="Select * from grade2 where GRADE_ID='$sb4'");
				 while($tt105=mysql_fetch_array($tr105)){echo  $sb105= $tt105['GRADE_NAME']; } ?>
                 </span></td>
                 <td colspan="4" class="st41">NEATNESS</td>
                 <td class="st41"><span class="st412">
                   <?php 
				 $tr5=mysql_query($q5="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='NEATNESS' and MSID='$msid'  and Term='2' ");
				 while($tt5=mysql_fetch_array($tr5)){  $sb5= $tt5['Marks']; }  $tr106=mysql_query($q106="Select * from grade2 where GRADE_ID='$sb5'");
				 while($tt106=mysql_fetch_array($tr106)){echo  $sb106= $tt106['GRADE_NAME']; } ?>
                 </span></td>
                 <td class="st41">Term-II</td>
                 <?php 
				$trh33=mysql_query($qh33="Select * from 21Repodata4healthsts where StudentId='$sid' and Session='$session' And MSID='$msid' and Term='2'");
				
				 while($tth33=mysql_fetch_array($trh33)){ $height11= $tth33['Height']; $weight11= $tth33['Weight']; }  ?>
                 <td class="st41"><? $height22=$height11/100;   $bmi2=$weight11/$height22; $bmi22=$bmi2/$height22; echo round($bmi22,2) ; ?>
                   &nbsp;</td>
                 <td class="st41"><? echo $height11; ?>
                   &nbsp;</td>
                 <td class="st41"><? echo $weight11; ?>
                   &nbsp;</td>
               </tr>
               <tr valign="top"  >
                 <td height="12" class="st41">COURTEOUSNESS</td>
                 <td colspan="4" class="st41"><span class="st412">
                   <?php 
				 $tr6=mysql_query($q6="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='COURTEOUSNESS' and MSID='$msid' and Term='2'");
				 while($tt6=mysql_fetch_array($tr6)){ $sb6= $tt6['Marks'];  }  $tr107=mysql_query($q107="Select * from grade2 where GRADE_ID='$sb6'");
				 while($tt107=mysql_fetch_array($tr107)){echo  $sb107= $tt107['GRADE_NAME']; } ?>
                 </span></td>
                 <td colspan="4" class="st41">SELF CONTROL</td>
                 <td class="st41"><span class="st412">
                   <?php 
 $tr7=mysql_query($q7="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SELF CONTROL' and MSID='$msid' and Term='2'");
				 while($tt7=mysql_fetch_array($tr7)){  $sb7= $tt7['Marks']; }  $tr108=mysql_query($q108="Select * from grade2 where GRADE_ID='$sb7'");
				 while($tt108=mysql_fetch_array($tr108)){echo  $sb108= $tt108['GRADE_NAME']; } ?>
                 </span></td>
                 <td colspan="4" rowspan="3" class="st41"><span class="st2">
                   Note:(1)Promotion is based on the day -to -day continuous assessment throughout the year.(2) CGPA=Cumulative Grade Point Average (3) Subject Wise/Overall indicative percentage of Marks=20 X GP of the subject /CGPA.(4)BMI=Wt in KG/(Height in m)2
                 </span></td>
               </tr>
               <tr valign="top"  >
                 <td height="12" class="st41">CONFIDENCE</td>
                 <td colspan="4" class="st41"><span class="st412">
                   <?php 
				 $tr8=mysql_query($q8="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='CONFIDENCE' and MSID='$msid' and Term='2' ");
				 while($tt8=mysql_fetch_array($tr8)){  $sb8= $tt8['Marks']; }  $tr109=mysql_query($q109="Select * from grade2 where GRADE_ID='$sb8'");
				 while($tt109=mysql_fetch_array($tr109)){echo  $sb109= $tt109['GRADE_NAME']; }  ?>
                 </span></td>
                 <td colspan="4" class="st41">RESPECT FOR OTHER'S PROPERTY</td>
                 <td class="st41"><span class="st412">
                   <?php $res="RESPECT FOR OTHERS PROPERTY";
				 $tr9=mysql_query($q9="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='Respect for Others property sharing and caring' and MSID='$msid' and Term='2' ");
				 while($tt9=mysql_fetch_array($tr9)){$sb9= $tt9['Marks'];  }  $tr110=mysql_query($q110="Select * from grade2 where GRADE_ID='$sb9'");
				 while($tt110=mysql_fetch_array($tr110)){echo  $sb110= $tt110['GRADE_NAME']; } ?>
                 </span></td>
               </tr>
               <tr valign="top"  >
                 <td width="147" height="37" class="st41">CARE OF BELONGINGS</td>
                 <td colspan="4" class="st41"><span class="st412">
                   <?php 
				 $tr10=mysql_query($q10="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='CARE OF BELONGINGS' and MSID='$msid' and Term='2' ");
				 while($tt10=mysql_fetch_array($tr10)){$sb10= $tt10['Marks'];}  $tr111=mysql_query($q111="Select * from grade2 where GRADE_ID='$sb10'");
				 while($tt111=mysql_fetch_array($tr111)){echo  $sb101= $tt111['GRADE_NAME']; }  ?>
                 </span></td>
                 <td colspan="4" class="st41">SHARING AND CARING</td>
                 <td width="38" class="st41"><span class="st412">
                   <?php 
				 $tr11=mysql_query($q11="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='Respect for Others property sharing and caring' and MSID='$msid' and Term='2' ");
				 while($tt11=mysql_fetch_array($tr11)){$sb11= $tt11['Marks']; }  $tr112=mysql_query($q112="Select * from grade2 where GRADE_ID='$sb11'");
				 while($tt112=mysql_fetch_array($tr112)){echo  $sb112= $tt112['GRADE_NAME']; } ?>
                 </span></td>
               </tr>
            
             </table>
<? //}else {?> <!--Coming Soon--><? //}?>
             </td>
          </tr>
          
          <tr align="left" valign="top">
            <td height="92" valign="top"><table width="100%" height="90" border="0" align="center">
              <tr>
                <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: &nbsp;&nbsp;Congratulations<? $trjjrm=mysql_query($qjjrm="Select Remarks from 21Remarks where SID='$sid' AND  MSID='$msid'  AND Session='$session'");
				 while($ttjjrm=mysql_fetch_array($trjjrm)){ echo $remarks=$ttjjrm['Remarks']; }?></strong><br/>
                  </td>
              </tr>
              <tr>
                <td width="234" height="61" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
                <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
              </tr>
            </table></td>
          </tr>
         
        </table></td>
      </tr>
</table> 
                </div>
            </div>

        </div>
    </div>
</section>















