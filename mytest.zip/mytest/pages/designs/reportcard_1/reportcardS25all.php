<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$TermDate= $row['TermDate']; 


} ?>::Report Card</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<style type="text/css">
.style2 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
</style>
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
</head>
 <? $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);

$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $s_id= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass'];  $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 
?>
<body><style>
p.page { page-break-after: always; }
</style>
<table width="1148" border="0" align="center">
  <tr>
    <td width="1142"><table width="200" border="0">
      <tr valign="top">
        <td height="659" align="center" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><table width="543" height="654" border="1" align="center" bordercolor="#2A3F00" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat">
          <tr align="left" valign="top">
            <td width="533" height="76"><table width="535">
              <tr>
                <td colspan="3" align="center"><span class="m1">
                  <?php  echo $sname;?>
                </span></td>
              </tr>
              <tr>
                <td width="78" align="left"><table width="69" border="0" align="center">
                  <tr>
                    <td width="63"><img src="<?php   if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " width="78" height="75" /></td>
                  </tr>
                </table></td>
                <td width="245" valign="top"><table width="232" border="0" align="center">
                  <tr>
                    <td width="226" align="center" ><span class="b1">
                      <?php  echo $Place; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="b1"><span class="t1">
                      <?php  echo $Board; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="t1">&nbsp;</td>
                  </tr>
                </table></td>
                <td width="200" align="right" valign="top"><table width="200" border="0" align="right">
                  <tr>
                    <td align="center"><img  src="../student_detail/reports/phone.jpg"  width="25" height="25" /></td>
                    <td align="right" class="r"><strong>
                      <?php  echo $Phone; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td width="144" class="r">Affiliation No.:</td>
                    <td width="46" align="right" class="r"><strong>
                      <?php  echo $AffiliationNo; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td class="r"> School Code :</td>
                    <td align="right"><span class="r"><strong>
                      <?php  echo $SchoolNo; ?>
                    </strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="r">Recognition No.:</span></td>
                    <td align="right"><strong class="r">
                      <?php  echo $Reconiation_no; ?>
                    </strong></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <?php   
 $result=mysql_query($sql="SELECT (S.Id)as sid,S.*,P.*,L.Village,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.Id='$s_id' And P.MSID='$msid'"  );while($gow=mysql_fetch_array($result)){$sid=$gow['sid'];$ClassName=$gow['ClassName'];$name=$gow['Name'];$mn=$gow['MotherName'];
$fn=$row['FatherName']; 
  ?>
          <tr align="left" valign="top">
            <td height="493" align="center" valign="top"><table width="535" height="178" border="0" align="center">
              <tr valign="top">
                <td width="525" height="172" colspan="2"><table width="529" border="0">
                  <tr>
                    <td height="27" colspan="8" align="center" class="b1">Student's Profile</td>
                  </tr>
                  <tr>
                    <td height="27" colspan="8" class="b1"><?php echo $gow['Name'];?></td>
                  </tr>
                  <tr>
                    <td height="27" colspan="8" class="st4">&nbsp;&nbsp;Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $sid;?></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="26" class="st4">&nbsp;&nbsp;Class:&nbsp;</td>
                    <td width="144" class="st4"><strong>
                      <?  $cl= $gow['CClass'];$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$cl' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){  echo $row2['ClassName']; }  if($nos>'0'){  $Section= $gow['Section']; $d1=mysql_query($sql1="select * from `4Sections` where `MSID`='$msid'  And `ID`='$Section'   ORDER BY `ID` ASC  "); while($row12=mysql_fetch_array($d1)){  echo $Sectionname12= $row12['Sectionname'];}}else {} if($noh>'0'){?>
                      <?php  $house=$gow['House'];  $d=mysql_query($sql="select * from `3Houses` where `MSID`='$msid' And `Id`='$house'  ORDER BY `ID` ASC "); while($row1=mysql_fetch_array($d)){echo $h= $row1['HouseFName'] ;}?>
                      <?php }else {} ?>
                      &nbsp;</strong></td>
                    <td width="144" class="st4"><strong><span class="style19">Birth Date:</span></strong></td>
                    <td colspan="4"><span class="style19"><strong>
                      <?php   $dob=$gow['BirthDate'];echo $new_date = date('d-m-Y', strtotime($dob));?>
                    </strong></span></td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="29" class="st4">&nbsp;&nbsp;Mobile Number: </td>
                    <td colspan="2" class="style19"><span class="st4"><strong><?php echo $gow['F_Mobile'];?></strong></span></td>
                    <td colspan="4">&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="126" height="28" class="style19"><span class="st4">&nbsp;</span>Father's Name: </td>
                    <td colspan="6" class="style19"><strong><?php echo "Mr.".' '.$gow['FatherName'];?></strong></td>
                    <td width="1">&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="27" class="style19"><span class="st4">&nbsp;</span>Mother's Name: </td>
                    <td height="27" colspan="7" class="style19"><strong><?php echo "Mrs.".' '.$gow['MotherName'];?></strong></td>
                  </tr>
                  <tr>
                    <td height="29" colspan="8" class="style19"><span class="st4">&nbsp;</span>Locality:<strong><?php echo $gow['Village1'];?></strong><span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>District: <strong>
                      <?php   echo $gow['District'];?>
                    </strong> <span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></td>
                  </tr>
                </table></td>
              </tr>
            </table>
              <span class="st4"><strong class="st3">Non-Scholastic Achievements </strong></span><br />
              <table width="483" height="137" border="1" align="center">
                <tr valign="top">
                  <td width="162" height="23" class="st4">Discipline</td>
                  <td width="67">&nbsp;</td>
                  <td width="131" class="st4">Academics</td>
                  <td width="95" height="23">&nbsp;</td>
                </tr>
                <tr valign="top">
                  <td width="162" height="23" class="st4">Uniform</td>
                  <td>&nbsp;</td>
                  <td width="131" class="st4">Sports</td>
                  <td width="95" height="23">&nbsp;</td>
                </tr>
                <tr valign="top">
                  <td width="162" height="23" class="st4">Cleanliness</td>
                  <td>&nbsp;</td>
                  <td width="131" class="st4">Literal Activities</td>
                  <td width="95" height="23">&nbsp;</td>
                </tr>
                <tr valign="top">
                  <td height="23" class="st4">Project Works</td>
                  <td>&nbsp;</td>
                  <td class="st4">Cultural Activities</td>
                  <td height="23">&nbsp;</td>
                </tr>
                <tr valign="top">
                  <td height="23" class="st4">Art &amp; Craft</td>
                  <td>&nbsp;</td>
                  <td class="st4">Attendance</td>
                  <td height="23">&nbsp;</td>
                </tr>
              </table>
              <span class="st3"> RESULT</span><br />
              <table width="537" border="0" align="center">
                <tr>
                  <td colspan="2" align="center"><span class="st4">This is certified that Master/Miss&nbsp;............... ................................has been</span></td>
                </tr>
                <tr class="st4">
                  <td colspan="2" align="center">granted promotion/fail/re-appear to class............with grade....................</td>
                </tr>
                <tr class="st4">
                  <td width="255" align="center"><strong><br />
                    Class Teacher</strong>...................</td>
                  <td width="272" align="center"><strong>Exam Incharge </strong>
                    <!--<a href="reportcardp2.php?id=<? //echo 149;?>&cno=<? //echo $cno;?>" style="text-decoration:none" target="_blank">-->
                    .....................
                    <!--</a>--></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td><table width="555" border="0" align="center" cellpadding="2" cellspacing="2">
          <tr>
            <td width="547"><table width="546" height="545" border="1" align="center" bordercolor="#2A3F00" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat">
              <tr align="left" valign="top">
                <td width="538" height="319" align="center"><span class="style15">Scholastic Achievement</span><br />
                  <br />
                  <table width="542" border="1">
                    <tr class="style19">
                      <td width="118" height="30" align="left" class="st4"><strong class="st4">Subjects</strong></td>
                      <?php /*$ghi=mysql_query($gh="SELECT distinct Assesment , AssID FROM `assesments` Where Term='Term 1'  And MSID='$msid' "); while($gow=mysql_fetch_array($ghi)){ */ ?>
                      <?php //echo $ann=$gow['Assesment'];$AssID=$gow['AssID'];?>
                      <?php //} ?>
                      <td colspan="2" align="left" class="st4"><strong class="st4">1st Term</strong></td>
                      <td colspan="2" align="left" class="st4"><strong class="st4">2nd Term</strong></td>
                      <td colspan="2" align="left" class="st4"><strong class="st4">Annual Exams</strong></td>
                      <td width="100" colspan="3" align="left" class="st4"><strong class="st4">Grand Total</strong></td>
                    </tr>
                    <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){ 
				 
				  ?>
                    <tr class="style19" >
                      <td height="25"><?php    $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></td>
                      <td width="48"><?php  $ghiy=mysql_query($ghy="SELECT round(MarksObtained) as marks, MaxMarks FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='1'  And `Class`= '$cl'"); while($gowy=mysql_fetch_array($ghiy)){echo $MarksObtained=$gowy['marks']; $MaxMarks=$gowy['MaxMarks'];}


?></td>
                      <td width="33"><? echo $MaxMarks ;?></td>
                      <td width="45"><?php $gr2=mysql_query($ghyn2="SELECT round(MarksObtained) as marks, MaxMarks  FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='2'  And `Class`= '$cl'"); while($g2=mysql_fetch_array($gr2)){
					echo $Gn2=$g2['marks'];  $MaxMarks2=$g2['MaxMarks'];}?></td>
                      <td width="33"><? echo $MaxMarks2;?></td>
                      <td width="58"><?php  $ghiy3=mysql_query($ghy3="SELECT round(MarksObtained) as marks, MaxMarks  FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb' And  `AssId`='3'  And `Class`= '$cl'"); while($gowy3=mysql_fetch_array($ghiy3)){echo $marks3=$gowy3['marks'];$MaxMarks3=$gowy3['MaxMarks'];}?></td>
                      <td width="55"><? echo $MaxMarks3;?></td>
                      <td width="100"><? $ghiy1=mysql_query($ghy1="Select round(Sum(`MarksObtained`))as tmaxobtained,Sum(`MaxMarks`)as tmarks FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `SubjectId`='$sb'  And `Class`= '$cl' "); 
				while($gowy1=mysql_fetch_array($ghiy1)){  echo $tmaxobtained=$gowy1['tmaxobtained'];?>
                        /<? echo   $tmarks=$gowy1['tmarks'];  } ?></td>
                      <!--<td width="37">&nbsp;</td>
                <td width="75">&nbsp;</td>-->
                    </tr>
                    <?php  } ?>
                    <tr class="style19" >
                      <td height="24">Total </td>
                      <td colspan="2"><?php  $ghiyt1=mysql_query($ghyt1="SELECT Sum(round(MarksObtained)) as termmaxob  ,Sum(MaxMarks) as termmax   FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `AssId`='1'  And `Class`= '$cl'"); while($gowyt1=mysql_fetch_array($ghiyt1)){echo $termmaxob=$gowyt1['termmaxob'].'/'; $termmax=$gowyt1['termmax'];}?>
                        <? echo  $termmax;?></td>
                      <td colspan="2"><?php  $ghiyt2=mysql_query($ghyt2="SELECT Sum(round(MarksObtained)) as termmaxob2  ,Sum(MaxMarks) as termmax2   FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `AssId`='2'  And `Class`= '$cl'"); while($gowyt2=mysql_fetch_array($ghiyt2)){echo $termmaxob2=$gowyt2['termmaxob2'].'/'; $termmax2=$gowyt2['termmax2'];}?>
                        <? echo  $termmax2;?></td>
                      <td colspan="2"><?php  $ghiyt3=mysql_query($ghyt3="SELECT Sum(round(MarksObtained)) as termmaxob3  ,Sum(MaxMarks) as termmax3   FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `AssId`='3'  And `Class`= '$cl'"); while($gowyt3=mysql_fetch_array($ghiyt3)){echo $termmaxob3=$gowyt3['termmaxob3'].'/'; $termmax3=$gowyt3['termmax3'];}?>
                        <? echo  $termmax3;?></td>
                      <td width="100"><? $ghiyto1=mysql_query($ghyto1="Select round(Sum(`MarksObtained`))as tmaxobtainedto,Sum(`MaxMarks`)as tmarksto FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id'  And `Class`= '$cl' Group by  StudentId"); 
				while($gowyto1=mysql_fetch_array($ghiyto1)){  echo $tmaxobtainedto=$gowyto1['tmaxobtainedto'];?>
                        /<? echo   $tmarksto=$gowyto1['tmarksto'];  } ?></td>
                    </tr>
                    <tr class="style19" >
                      <td height="31">Percentage</td>
                      <td colspan="2"><?php  /*$ghiyp1=mysql_query($ghyp1="SELECT  Sum(ROUND( `MarksObtained`/RD.`MaxMarks`*100,2) Percent FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `AssId`='1'  And `Class`= '$cl'"); while($gowyp1=mysql_fetch_array($ghiyp1)){echo $Percent=$gowyp1['Percent'];  }*/?></td>
                      <td colspan="2"><?php  /*$ghiyp2=mysql_query($ghyp2="SELECT  Sum(ROUND( `MarksObtained`/RD.`MaxMarks`*100,2) Percent2 FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `AssId`='2'  And `Class`= '$cl'"); while($gowyp2=mysql_fetch_array($ghiyp2)){echo $Percent2=$gowyp2['Percent2'];  }*/?></td>
                      <td colspan="2"><?php  /*$ghiyp3=mysql_query($ghyp3="SELECT  Sum(ROUND( `MarksObtained`/RD.`MaxMarks`*100,2) Percent3 FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id' And  `AssId`='3'  And `Class`= '$cl'"); while($gowyp3=mysql_fetch_array($ghiyp3)){echo $Percent3=$gowyp3['Percent3'];  }*/?></td>
                      <td><?php  /*$ghiypt=mysql_query($ghypt="SELECT  Sum(ROUND( `MarksObtained`/RD.`MaxMarks`*100,2) Percentt FROM `21Repodata1` WHERE `MSID`='$msid' And `Session`='$session'  And  `StudentId`='$s_id'    And `Class`= '$cl'"); while($gowypt=mysql_fetch_array($ghiypt)){
					echo $Percentt=$gowypt['Percentt'];  }*/?></td>
                    </tr>
                    <tr class="style19" >
                      <td height="26">Grade</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr class="style19" >
                      <td height="28">Class Teacher</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr class="style19" >
                      <td height="27">Checked by</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr class="style19" >
                      <td height="27">Principal</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr class="style19" >
                      <td height="27">Parents</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td colspan="2">&nbsp;</td>
                      <td width="100">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
              <tr align="left" valign="top">
                <td height="215" valign="top"><br />
                  <br />
                  <table width="527" border="0" align="center">
                    <tr>
                      <td colspan="2" align="center" class="st3"><br />
                        Remarks</td>
                    </tr>
                    <tr>
                      <td width="121" align="center"><strong class="st4">First Term</strong></td>
                      <td width="396" align="center">........................................................................</td>
                    </tr>
                    <tr class="st4">
                      <td align="center"><strong>Sec. Term</strong></td>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr class="st4">
                      <td align="center"><strong>Fin. Term</strong></td>
                      <td align="center"><strong> </strong><strong>
                        <!--</a>-->
                      </strong></td>
                    </tr>
                    <tr class="st4">
                      <td height="39" align="center">Note</td>
                      <td align="center"></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<br />
<p class="page"></p>
<p class="page"></p>	
	

		<!-- classie.js by @desandro: https://github.com/desandro/classie
	<script src="../../js/classie.js"></script>
		<script src="../../js/cbpAnimatedHeader.min.js"></script> -->
	</body>
   <? }} ?> 
</html>
<?php  } ?>

