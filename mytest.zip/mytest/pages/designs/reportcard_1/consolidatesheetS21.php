<?php
session_start();
include("../../connect/db.php");  
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);  $sec1=$_GET['s'];$sec = mysql_real_escape_string($sec1);
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session1= $kr['MySession'];
$Begins1= $kr['Begins'];     
$Ends1= $kr['Ends'];        
$ULevel= $kr['ULevel']; } $cw=mysql_query($cl="select * from `2Sessions` where '$dm' Between `Begins` And `Ends` And  `MSID`='$msid'"); while($cr=mysql_fetch_array($cw)){ 
    $session= $cr['ID']; $Begins= $cr['Begins']; $Ends= $cr['Ends'];   } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board_full_name'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffiliationNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['Reconiation_no'];
$EMail= $row['EMail']; 
} ?>

</title>
<link rel="stylesheet" type="text/css"  href="../../css/report.css"  /></head>
 
 <style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 15px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 { text-transform:capitalize; font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.vks {
	font-family: "Comic Sans MS", cursive;
}
</style>

<body> 
<style>
p.page { page-break-after: always; }
</style>

<table width="774" border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="762"><table width="100%" height="520" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="875" height="76"><table width="99%" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td height="22" colspan="3" align="center"><span class="m1"><?php echo $sname;?></span></td>
              </tr>
              <tr>
                <td width="13%" height="101" align="center" valign="middle"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="60" height="60" class="logo"></td>
                <td width="60%" valign="top"><table width="100%" height="83" border="0" align="center">
                  <tr>
                    <td width="365" height="22" align="center" ><span class="b1"><?php echo $Place; ?></span></td>
                  </tr>
                  <tr>
                    <td height="20" align="center" class="b1"><span class="t1"><?php echo $Board; ?></span></td>
                  </tr>
                  <tr>
                    <td align="center" class="t1">Record of Academic Performance <? echo $session; ?></td>
                  </tr>
                </table></td>
                <td width="27%" align="right" valign="top"><table width="100%" align="right">
                  <tr>
                    <td align="center"><img src="../student_detail/reports/phone.jpg" width="25" height="23" /></td>
                    <td align="right" class="r"><strong><?php echo $Phone; ?></strong></td>
                  </tr>
                  <tr>
                    <td width="111" class="r">Affiliation No.:</td>
                    <td width="108" align="right" class="r"><strong><?php echo $AffiliationNo; ?></strong></td>
                  </tr>
                  <tr>
                    <td class="r"> School Code :</td>
                    <td align="right"><span class="r"><strong><?php echo $SchoolNo; ?></strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="r">Recognition No.:</span></td>
                    <td align="right"><strong class="r"><?php echo $Reconiation_no; ?></strong></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr align="left" valign="top">
            <td height="4"></td>
          </tr>
          <tr align="left" valign="top">
            <td align="center" valign="top" class="vks">
              <table width="100%" height="187" border="1">
                    <tr bgcolor="#E4E4E4">
                      <td height="43" colspan="13" align="center" class="st4"><strong>Report For Class 
                      <?php $result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$cno' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){     $ClassName=$row2['ClassName'];    } echo $ClassName;?></strong></td>
                    </tr>
                                         <tr>
                      <td width="95" rowspan="3" class="st4"><strong >Subject</strong></td>
                      <td colspan="12" align="center" class="st4"><strong>MARKS OBTAINED</strong></td>
                    </tr>
                    <? if($cno<=10){ ?>
                    <tr>
                      <td width="86" colspan="2" align="center" class="st4">FA1</td>
                      <td width="97" colspan="2" align="center" class="st4">FA2</td>
                      <td width="88" colspan="2" align="center" class="st4">SA1</td>
                      <td width="107" colspan="2" align="center" class="st4">FA3</td>
                      <td width="107" colspan="2" align="center" class="st4">FA4</td>
                      <td width="121" colspan="2" align="center" class="st4">SA2</td>
                    </tr>
                    <tr>
                      <td align="center" class="st4">Marks</td>
                      <td align="center" class="st4">Grade</td>
                      <td width="47" align="center" class="st4"><span class="st41">Marks</span></td>
                      <td width="48" align="center" class="st4"><span class="st41">Grade</span></td>
                      <td width="43" align="center" class="st4"><span class="st41">Marks</span></td>
                      <td width="43" align="center" class="st4"><span class="st41">Grade</span></td>
                      <td width="52" align="center" class="st4"><span class="st41">Marks</span></td>
                      <td width="53" align="center" class="st4"><span class="st41">Grade</span></td>
                      <td width="52" align="center" class="st4"><span class="st41">Marks</span></td>
                      <td width="53" align="center" class="st4"><span class="st41">Grade</span></td>
                      <td width="59" align="center" class="st4"><span class="st41">Marks</span></td>
                      <td width="60" align="center" class="st4"><span class="st41">Grade</span></td>
                    </tr>
                    <? } else{ ?>
                         <tr>
                      <td width="86" align="center" class="st4">Unit 1</td>
                      <td width="97" colspan="2" align="center" class="st4">Unit 2</td>
                      <td width="88" colspan="2" align="center" class="st4">Term 1</td>
                      <td width="107" colspan="2" align="center" class="st4">Unit 3</td>
                      <td width="107" colspan="2" align="center" class="st4">Unit 4</td>
                      <td width="121" colspan="2" align="center" class="st4">Term 2</td>
                    </tr>
                    <? }?>
                    <? $result=mysql_query($gh="SELECT (S.Id) as sid,S.*,P.*,L.*, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' and  S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Section='$sec' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0)  Order by sid,S.Name Asc"); while($row=mysql_fetch_array($result)){  $s_id=$row['sid'];
$name=$row['Name']; //$stream=$row['Stream']; ?>
<tr><td height="22" colspan="13" align="center" class="st4"><strong>Student ID:&nbsp;&nbsp;<? echo $s_id; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Name:&nbsp;&nbsp;<? echo $name; ?> </strong></td></tr>
                     
					<?php $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){ ?>
                   <tr>
                      <td height="22" valign="top" class="st4"><? $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy=mysql_query($ghy="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='1' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId` "); while($gowy=mysql_fetch_array($ghiy)){echo $Marks_obtained=$gowy['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?>&nbsp;</td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy1=mysql_query($ghy1="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='2' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy1=mysql_fetch_array($ghiy1)){echo $Marks_obtained1=$gowy1['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy9=mysql_query($ghy9="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy9=mysql_fetch_array($ghiy9)){echo $Grade9=$gowy9['Grade'];}?>
                      </span></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy2=mysql_query($ghy2="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='5' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy2=mysql_fetch_array($ghiy2)){echo $Marks_obtained2=$gowy2['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy10=mysql_query($ghy10="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy10=mysql_fetch_array($ghiy10)){echo $Grade10=$gowy10['Grade'];}?>
                      </span></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy3=mysql_query($ghy3="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='3' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy3=mysql_fetch_array($ghiy3)){echo $Marks_obtained3=$gowy3['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy11=mysql_query($ghy11="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy11=mysql_fetch_array($ghiy11)){echo $Grade11=$gowy11['Grade'];}?>
                      </span></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy4=mysql_query($ghy4="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='4' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy4=mysql_fetch_array($ghiy4)){echo $Marks_obtained4=$gowy4['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy12=mysql_query($ghy12="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy12=mysql_fetch_array($ghiy12)){echo $Grade12=$gowy12['Grade'];}?>
                      </span></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy5=mysql_query($ghy5="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='6' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy5=mysql_fetch_array($ghiy5)){echo $Marks_obtained5=$gowy5['MarksObtained'];}?></td>
                     <td align="center" valign="top" class="st4"><span class="st41">
                       <?php   $ghiy13=mysql_query($ghy13="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='6' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy13=mysql_fetch_array($ghiy13)){echo $Grade13=$gowy13['Grade'];}?>
                     </span></td>
                    </tr>
                    <? }?>
                    <tr>
                      <td height="22" colspan="13" align="right"><span class="st4">
                      <strong>Total Marks:  <? $trj=mysql_query($qj="Select Sum(MarksObtained )AS tmarks from `21Repodata1` where MSID='$msid' and StudentId='$s_id' And Session='$session'");
				 while($ttj=mysql_fetch_array($trj)){    echo $tmarks=$ttj['tmarks'];} ?>/<? $trj1=mysql_query($qj1="Select Sum(MaxMarks)AS tomarks from `21Repodata1` where MSID='$msid' and StudentId='$s_id' And Session='$session'");
				 while($ttj1=mysql_fetch_array($trj1)){ echo $tomarks=$ttj1['tomarks'];} ?><!--&nbsp;&nbsp;&nbsp; Percentage: 
				 <?php //echo $xr4= round($tmarks/100*100,2);?>%--></strong>
                      </span></td></tr>
                    <?php }?>
              </table>
              <br />
            <br /></td>
          </tr>
        </table></td>
      </tr>
    </table>
<!--<p class="page"></p>--></body>
</html>
<? }?>