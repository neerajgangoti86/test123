<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name']; $Photo= $gow5['Photo'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 
 

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; $AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail']; 
} ?>::Half Yearly Report Card</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<style type="text/css">
.st41 {	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
</style>
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
</head>
 
<body> <style>
p.page { page-break-after: always; }
 </style>

    <table width="688" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"  border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="100%" height="780"><table width="676" height="774" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="100%" height="76"><table width="99%" align="center">
              <tr>
                <td colspan="3" align="center"><span class="m1">
                  <?php  echo $sname;?>
                </span></td>
              </tr>
              <tr>
                <td width="90" align="left"><img    src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/mspslogo.jpg";} ?>" width="75" height="75" class="logo"></td>
                <td width="340" valign="top"><table width="333" border="0" align="center">
                  <tr>
                    <td width="327" align="center" ><span class="b1">
                      <?php  echo $Place; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="b1"><span class="t1">
                      <?php  echo $Board; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="t1">&nbsp;</td>
                  </tr>
                </table></td>
                <td width="199" align="right" valign="top"><table width="100%" border="0" align="right">
                  <tr>
                    <td align="center"><img src="../student_detail/reports/phone.jpg" width="25" height="23" /></td>
                    <td align="right" class="r"><strong>
                      <?php  echo $Phone; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td width="107" class="r">Affiliation No.:</td>
                    <td width="109" align="right" class="r"><strong>
                      <?php  echo $AffiliationNo; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td class="r"> School Code :</td>
                    <td align="right"><span class="r"><strong>
                      <?php  echo $SchoolNo; ?>
                    </strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="r">Recognition No.:</span></td>
                    <td align="right"><strong class="r">
                      <?php  echo $Reconiation_no; ?>
                    </strong></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr align="left" valign="top">
         <td height="4" align="center">  <span class="t1"><strong class="st3"><u>
                <br />
            Academic Performance <? echo $session; ?> - <? echo $nsession=$session+1; ?><br />
            <br />
            </u></strong></span></td>
          </tr><?php  
 $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.Village, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' and  S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$sid' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0) " );while($row=mysql_fetch_array($result)){$s_id=$row['sid'];$class=$row['CClass'];$name=$row['Name'];$mn=$row['MotherName'];
$fn=$row['FatherName']; $Photo=$row['Photo'];$Section=$row['Section'];
  ?>
          <tr align="left" valign="top">
            <td height="580" valign="top"><table width="100%" border="0" align="center">
              <tr>
                <td width="94" rowspan="5" class="st41" valign="top"><?php  if($Photo!=""){echo '<img src="'.$Photo=$row['Photo'].'" width="99" height="126"/>';?>
                  <? }else {}?></td>
                <td colspan="3" class="b1"><?php  echo $name;?></td>
                <td colspan="2">&nbsp;</td>
                <td width="86" class="st41">&nbsp;</td>
                <td colspan="2" class="st41">&nbsp;</td>
              </tr>
              <tr>
                <!--<td width="17" rowspan="5" valign="top"><?PHP  //Student Id:$img= $row['Photo'];?></td>-->
                <td width="109" height="29" class="st41"><? if($ViewOption=='0'){echo 'Student Id:';}else {echo 'Admission No:';}?></td>
                <td width="48" class="st41"><strong>
                  <? if($ViewOption=='0'){echo $s_id;}else {echo $AdmNo;}?>
                </strong></td>
                <td width="41" class="st41">Class:</td>
                <td width="53" class="st41"><strong>
                  <?php  $result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$class' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){   echo $row2['ClassName'];   $cl=$row2['ClassNo']; }  ?>
                </strong></td>
                <td width="60" class="st41">Section:</td>
                <td class="st41"><strong>
                  <?  $d1=mysql_query($sql1="select * from `4Sections` where `MSID`='$msid'  And `ID`='$Section'   ORDER BY `ID` ASC  "); while($row12=mysql_fetch_array($d1)){
	 echo $Sectionname12= $row12['Sectionname'];}?>
                </strong></td>
                <td width="103" class="st41">Overall Grade:</td>
                <td width="42" class="st41"><strong>
                  <?  $ghi6=mysql_query($gh6="SELECT Q1.StudentId, Q1.Point,G.Grade,Q1.Class FROM (Select StudentId, MSID, Class, (Sum(`MarksObtained`)/SUM(`MaxMarks`)*100) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id') Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto` And  Q1.`Class` between  G.ClassFrom And 	G.ClassTo "); while($gow6=mysql_fetch_array($ghi6)){echo $Grade6=$gow6['Grade'];}  ?>
                </strong></td>
              </tr>
              <tr>
                <td height="28" colspan="2" class="st41">Father's Name:</td>
                <td colspan="4" class="st41"><strong>
                  <?php  echo "Mr.".' '.$fn;?>
                </strong></td>
                <td colspan="2" class="st41">&nbsp;</td>
              </tr>
              <tr>
                <td height="28" colspan="2" class="st41">Mother's Name:</td>
                <td colspan="4" class="st41"><strong>
                  <?php  echo  "Mrs.".' '.$mn;?>
                </strong></td>
                <td colspan="2" class="st41">&nbsp;</td>
              </tr>
              <tr>
                <td height="13" class="st41">Health Status</td>
                <td class="st41">Height:</td>
                <td class="st41"><? 		
 $hshi=mysql_query($hsh="SELECT Height,Weight From `21Repodata4healthsts` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($hsow=mysql_fetch_array($hshi)){  echo $Height= $hsow['Height'];   $Weight= $hsow['Weight']; }  	?></td>
                <td class="st41">Weight:</td>
                <td class="st41"><? echo $Weight;?></td>
                <td class="st41">Attendance:</td>
                <td colspan="2" class="st41"><?  $ashi=mysql_query($ash="SELECT * From `26TWDays` Where  MSID='$msid' and Session='$session'  and SID='$s_id' and Term='1'"); 		while($asow=mysql_fetch_array($ashi)){  echo $TERMATT= $asow['TERMATT'].' '.'/'.' '.$TWD= $asow['TWD']; } ?></td>
              </tr>
            </table>
              <table>
                <tr>
                  <td height="126" colspan="9" valign="top"><br />
                    <table width="666" height="120" border="1" align="center">
                      <tr valign="middle" align="center" bgcolor="#C9C9C9" class="st4">
                        <td width="263" height="32" class="st4" align="left"><strong>Subjects</strong></td>
                        <td width="116" class="st4"><strong>Term 1</strong></td>
                        <td width="140"  class="st4"><strong>Term 2</strong></td>
                        <td width="122" class="st4"><strong>Term 3</strong></td>
                      </tr>
                      <?php  
 $tr=mysql_query($q="SELECT * FROM `21Repodata1` where  `MSID`='$msid' And  `Session`='2014' And   `AssId`='1'  And StudentId='$sid' order by SubjectId ");
				 while($tt=mysql_fetch_array($tr)){}  ?>
                      <tr valign="middle" align="center">
                        <td class="st41" align="left"><?php    $sb= $tt['SubjectId'];
		    $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></td>
                        <td class="st41"><?php    
		   $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];} ?></td>
                        <td height="47" class="st41"><?php  $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?></td>
                        <td class="st41"><?php    
		    $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></td>
                      </tr>
                      <?php // }?>
                      <tr valign="top">
                        <td height="31" colspan="3" align="center" class="st41">Result:</td>
                        <td width="122" class="st41"><?php  
					 $trkd1=mysql_query($qkd1="Select (Sum(MarksObtained)/Sum(`MaxMarks` )*100) as page1 from 21Repodata1 where StudentId='$s_id' and  `MSID`='$msid' And  `Session`='2014' And    `AssId`='1' ");
				 while($ttkd1=mysql_fetch_array($trkd1)){$page1=$ttkd1['page1'];}
$tnhkd1=mysql_query($nhkd1="Select Sum(MarksObtained) as mks1  from 21Repodata1 where StudentId='$s_id' and  `MSID`='$msid' And  `Session`='2014' And    `AssId`='1' ");

				 while($tntkd1=mysql_fetch_array($tnhkd1)){    echo  $MarksObtained1=$tntkd1['mks1'];
				 
				  }   ?>
                          (<?php echo round($page1,2);?>%)</td>
                      </tr>
                  </table></td>
                </tr>
              </table>
              <table width="100%" border="1">
                <tr>
                  <td width="27%" rowspan="2" class="st4" align="center" valign="middle" bgcolor="#E8E8E8" ><strong>HEALTH DATA</strong></td>
                  <td width="9%" height="30" align="center" class="st4"  bgcolor="#C9C9C9">HEIGHT</td>
                  <td width="9%" class="st4" align="center"  bgcolor="#C9C9C9">WEIGHT</td>
                  <!--<td width="10%" height="26" class="st4" align="center">BLOOD GROUP</td>-->
                  <td width="31%" align="center" class="st4"  bgcolor="#C9C9C9">Attendance</td>
                </tr>
                <tr>
                  <td height="29" align="center" class="st4"><?  
 $result=mysql_query($sql="SELECT * from `21Repodata4healthsts`  where `MSID`='$msid' And `Session`='$session' And `StudentId`='$sid'" );
 while($row=mysql_fetch_array($result)){ $Height= $row['Height']; $Weight= $row['Weight'];} ?></td>
                  <td align="center" class="st4"><? echo $Height;?></td>
                  <td align="center" class="st4"><? echo $Weight;?></td>
                </tr>
              </table>
             
              <table width="100%" border="0" align="center">
                <tr>
                  <td colspan="4" align="center" class="st41"><table width="100%" border="1">
                    <tr>
                      <td height="40" align="left" valign="middle" class="st4" ><strong>Comments For Parents</strong></td>
                      <td width="69%" align="center" class="st4">&nbsp;</td>
                    </tr>
                    <tr>
                      <td width="31%" height="37" align="left" valign="middle" class="st4" ><strong>Comments For Students</strong></td>
                      <td align="center" class="st4">&nbsp;</td>
                      <!--<td width="10%" height="26" class="st4" align="center">BLOOD GROUP</td>-->
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td height="31" align="center" class="st41">Promoted To Class</td>
                  <td align="center">&nbsp;</td>
                  <td align="center" class="st41">Section</td>
                  <td align="center">&nbsp;</td>
                </tr>
                <tr>
                  <td height="27" align="center" class="st41">With Effect From</td>
                  <td align="center">&nbsp;</td>
                  <td align="center">&nbsp;</td>
                  <td align="center">&nbsp;</td>
                </tr>
                <tr>
                  <td align="center" class="st41">&nbsp;</td>
                  <td align="center">&nbsp;</td>
                  <td align="center">&nbsp;</td>
                  <td align="center" class="st41">&nbsp;</td>
                </tr>
                <tr>
                  <td width="200" height="28" align="center" class="st41"><strong>Class Teacher</strong></td>
                  <td width="128" align="center"><strong><!--<img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " width="70" height="70" />-->
                  <span class="st41">Headmistress</span></strong></td>
                  <td width="129" align="center"><strong><span class="st41">Principal</span></strong></td>
                  <td width="187" align="center" class="st41"><strong>Parent</strong></td>
                </tr>
              </table>
            </td>
          </tr>
        </table></td>
      </tr>
    </table>  <!--<form id="contactform" name="contactform" method="post" action="../student_detail/reports/admin.php">

    <input type="button" value="Print" onclick="printpage();">
  <input type="submit" name="Submit" value="Exit" />
  </form>-->  <p class="page"></p> 
<?php  }}?>

</body>
</html>
<? }?>