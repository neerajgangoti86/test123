<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate'];  
$Add_ReportC= $row['Add_ReportC'];

} ?>::Report Card</title>
<?  $cno1=$_GET['cno']; $cno = mysql_real_escape_string($cno1);
 //$id1=$_GET['id'];$sid = mysql_real_escape_string($id1);


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass'];  $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?>


<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>
      <table width="653" border="1" align="center">
        <tr>
          <td width="643" height="595"><table width="575" height="587" align="center" bordercolor="#2A3F00"  style="background-size:45%; background-position:center; background-repeat:no-repeat">
            <tr align="left" valign="top">
              <td width="567" height="88"><table width="694">
                <tr>
                  <td colspan="2" align="center"><span class="m1">
                    <?php  echo $sname;?>
                  </span></td>
                </tr>
                <tr>
                  <td width="138" height="108" align="left"><table width="69" border="0" align="center">
                    <tr>
                      <td width="63"><img class="logo" src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Uplaod/aboutlogo.jpg";} ?>"  width="90" height="100" /></td>
                    </tr>
                  </table></td>
                  <td width="544" valign="top"><table width="536" border="0" align="center">
                    <tr>
                      <td width="530" align="center" ><span class="b1">
                        <?php  echo $Place.' '.$Board; ?>
                      </span></td>
                    </tr>
                    <tr>
                      <td align="center" class="n1">Website:<? echo $Website;?><? //echo ,E-mail:$EMail;?>,Ph:<? echo $Phone;?></td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
            </tr>
            <?php   
 $result=mysql_query($sql="SELECT (S.Id)as sid,S.*,P.*,L.Village,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.Id='$sid' And P.MSID='$msid'"  );while($gow=mysql_fetch_array($result)){$sid=$gow['sid'];$ClassName=$gow['ClassName'];$name=$gow['Name'];$mn=$gow['MotherName'];
$fn=$row['FatherName']; 
  ?>
            <tr align="left" valign="top">
              <td height="441" valign="top"><table width="694" height="121" border="0" align="center">
                <tr valign="top">
                  <td width="521" height="117" colspan="2"><table width="694" border="0">
                    <tr>
                      <td height="37" colspan="2" align="left"><span class="st412">Name :&nbsp;&nbsp;<strong>&nbsp;<?php echo $gow['Name'];?></strong></span></td>
                      <td width="91"><span class="st412">Id:<strong><?php echo $sid;?></strong></span></td>
                      <td width="165" height="37" colspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td height="39" align="left"><span class="st412">Father's Name: &nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                      <td width="245" height="39" align="left"><strong><span class="st412"><?php echo "Mr.".' '.$gow['FatherName'];?></span></strong></td>
                      <td height="39" colspan="3" ><span class="st412">Class/House:&nbsp;<strong>
                        <?  $cl= $gow['CClass'];$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$cl' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){  echo $row2['ClassName'].'/'; }  if($nos>'0'){  $Section= $gow['Section']; $d1=mysql_query($sql1="select * from `4Sections` where `MSID`='$msid'  And `ID`='$Section'   ORDER BY `ID` ASC  "); while($row12=mysql_fetch_array($d1)){  echo $Sectionname12= $row12['Sectionname'];}}else {} if($noh>'0'){?>
                        <?php  $house=$gow['House'];  $d=mysql_query($sql="select * from `3Houses` where `MSID`='$msid' And `Id`='$house'  ORDER BY `ID` ASC "); while($row1=mysql_fetch_array($d)){echo $h= $row1['HouseFName'] ;}?>
                        <?php }else {} ?>
                      </strong></span></td>
                    </tr>
                    <tr>
                      <td width="175" height="34" align="left"><span class="st412">Mother's Name: </span></td>
                      <td align="left" class="st412"><strong><span class="style41"><?php echo "Mrs.".' '.$gow['MotherName'];?></span></strong></td>
                      <td colspan="3"><span class="st412">Phones: <strong><?php echo $gow['F_Mobile'];?></strong></span></td>
                    </tr>
                    <tr>
                      <td height="39" align="left"><span class="st412">Village/Town:</span></span></td>
                      <td align="left" class="st412"><strong><span class="style41"><?php echo $gow['Village1'];?></span></strong></td>
                      <td colspan="3"><span class="st412">District:<strong>Shimla</strong></span></td>
                    </tr>
                    <?php  //}?>
                  </table></td>
                </tr>
              </table>
                <table width="694" border="0" align="center">
                  <tr valign="top" class="st412">
                    <td height="20" align="center"><span class="style2">Half Yearly Academic Performance:<? echo $session; echo '-'; echo $session+1;?></span><br />
                      <br />
                      Exam:<strong>1st Term</strong> <br />
                      <br /></td>
                  </tr>
                </table>
                <table width="694" height="74" border="1" align="center">
                  <tr valign="top">
                    <td width="181" bgcolor="#C9C9C9" class="st412"><strong>Subjects</strong></td>
                    <td width="92" bgcolor="#C9C9C9" class="st412"><strong>Max.Marks</strong></td>
                    <td width="107" bgcolor="#C9C9C9" class="st412"><strong>Pass Marks</strong></td>
                    <td width="79" bgcolor="#C9C9C9" class="st412"><strong>Avg.Marks</strong></td>
                    <!--   <td width="96" bgcolor="#C9C9C9"  class="st41"><strong><span >Top Score </span></strong></td> -->
                    <td width="99" bgcolor="#C9C9C9" class="st412"><strong>Marks Obtained</strong></td>
                  </tr>
                  <?php  
 $tr=mysql_query($q="SELECT * FROM `21Repodata1` where  `MSID`='$msid' And  `Session`='$session' And   `AssId`='1'  And StudentId='$sid' order by SubjectId ");
				 while($tt=mysql_fetch_array($tr)){  ?>
                  <tr valign="top">
                    <td class="st412"><?php    $sb= $tt['SubjectId'];
		    $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></td>
                    <td class="st412"><?php   
		    $phigf1=mysql_query($phgf1="SELECT MaxMarks FROM `21Repodata1` Where  `MSID`='$msid' And  `Session`='$session' And   `AssId`='1'  And StudentId='$sid'  And SubjectId='$sb'"); 		while($powgf1=mysql_fetch_array($phigf1)){echo $MaxMarks= $powgf1['MaxMarks'];}  ?></td>
                    <td class="st412"><?php  $tr1=mysql_query($q1="SELECT round(MaxMarks/3,0) as pmk FROM `21Repodata1` Where  `MSID`='$msid' And  `Session`='$session' And   `AssId`='1'  And StudentId='$sid'  And SubjectId='$sb'");
				 while($tt1=mysql_fetch_array($tr1)){  echo   $pmk=$tt1['pmk']; }  ?></td>
                    <td class="st412"><?php    // 
		    $phigf3=mysql_query($phgf3="SELECT Avg(MarksObtained)As avgmk   FROM `21Repodata1` Where  `MSID`='$msid' And  `Session`='$session' And   `AssId`='1'   And SubjectId='$sb'  And `Class`='$cl'  "); 		while($powgf3=mysql_fetch_array($phigf3)){$avgmk= $powgf3['avgmk'];} echo round($avgmk,2); ?></td>
                    <!--    <td height="13" class="st41">
              <?php  
			 /* $tr123=mysql_query($q123="Select Max(MarksObtained) as Mmk  from 21Repodata1 where `MSID`='$msid' And  `Session`='$session' And   `AssId`='1'    And SubjectId='$sb' And Class='-1'");
				 while($tt123=mysql_fetch_array($tr123)){      $Mm=$tt123['Mmk']; echo round($Mm,2);} */?>
              
              
              
              
              </td>
-->
                    <td class="st412"><?php    
		    $phigf6=mysql_query($phgf6="SELECT round(MarksObtained,2)as MarksObtained FROM `21Repodata1` Where  `MSID`='$msid' And  `Session`='$session' And   `AssId`='1'  And StudentId='$sid'  And SubjectId='$sb'"); 		while($powgf6=mysql_fetch_array($phigf6)){echo $MarksObtained= $powgf6['MarksObtained'];} ?></td>
                  </tr>
                  <?php }?>
                  <tr valign="top">
                    <td height="22" colspan="4" align="center" class="st412">Result:</td>
                    <td width="99" class="st412"><?php  
					 $trkd1=mysql_query($qkd1="Select (Sum(MarksObtained)/Sum(`MaxMarks` )*100) as page1 from 21Repodata1 where StudentId='$sid' and  `MSID`='$msid' And  `Session`='$session' And    `AssId`='1' ");
				 while($ttkd1=mysql_fetch_array($trkd1)){$page1=$ttkd1['page1'];}
$tnhkd1=mysql_query($nhkd1="Select Sum(MarksObtained) as mks1  from 21Repodata1 where StudentId='$sid' and  `MSID`='$msid' And  `Session`='$session' And    `AssId`='1' ");

				 while($tntkd1=mysql_fetch_array($tnhkd1)){    echo  $MarksObtained1=$tntkd1['mks1'];
				 
				  }   ?>
                      (<?php echo round($page1,2);?>%)</td>
                  </tr>
                </table>
                <table width="694" border="0" align="center">
                  <tr>
                    <td height="21" align="center" class="st412">&nbsp;</td>
                    <td align="center" class="st412">&nbsp;</td>
                    <td align="center" class="st412">&nbsp;</td>
                    <td align="center" class="st412">&nbsp;</td>
                    <td align="center">&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="21" align="center" class="st412">&nbsp;</td>
                    <td align="center" class="st412">&nbsp;</td>
                    <td align="center" class="st412">&nbsp;</td>
                    <td align="center" class="st412">&nbsp;</td>
                    <td align="center">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="206" height="21" align="center" class="st412"><strong>Remarks:</strong></td>
                    <td width="112" align="center" class="st412"><strong>
                      <!--<img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " width="70" height="70" />-->
                      Excellent</strong></td>
                    <td width="134" align="center" class="st412"><strong>Very Good</strong></td>
                    <td width="81" align="center" class="st412"><strong>Good </strong></td>
                    <td width="139" align="center"><strong><span class="st412">Average</span></strong></td>
                  </tr>
                </table>
                <br />
                <br />
                <table width="694" border="0" align="center">
                  <tr>
                    <td width="201" height="21" align="center" class="st412"><strong>Class Teacher</strong></td>
                    <td width="261" align="center"><strong>
                      <!--<img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " width="70" height="70" />-->
                    </strong></td>
                    <td width="218" align="center"><strong><span class="st412">Principal</span></strong></td>
                  </tr>
                </table></td>
            </tr>
          </table></td>
        </tr>
      </table>
      <p class="page"></p>
      
<?php }}}?>  
</body>
</html>
