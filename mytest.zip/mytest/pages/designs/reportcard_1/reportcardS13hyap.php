<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } if($_POST){  $sid=$_POST['c'];
$cno1=$_GET['cno'];  $cno = mysql_real_escape_string($cno1);
}else {
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 $id1=$_GET['id'];$sid = mysql_real_escape_string($id1);}


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$sid' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $s_id= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass']; $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; $AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail']; $AffNo= $row['AffNo'];
} ?>::Half Yearly Report Card</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script><style>

.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 15px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px; padding-left:6px; padding-right:6px;
 
}

.t1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 27px;font-weight: bold;
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.b1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px;
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
 
</style>
</head>
 
<body><style>
p.page { page-break-after: always; }
</style>

    <table width="750" border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="100%"><table width="745" height="711" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="100%" height="76"><table width="99%" align="center">
              <tr>
                <td colspan="3" align="center"><span class="m1">
                  <?php  echo $sname;?>
                </span></td>
              </tr>
              <tr>
                <td width="90" align="left"><img  style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;"  src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/mspslogo.jpg";} ?>" width="70" height="70" class="logo"></td>
                <td width="438" align="center" valign="top"><table width="437" border="0" align="center">
                  <tr>
                    <td width="431" align="center" ><span class="b1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ropar Road Vill. Asmanpur NURPUR BEDI,Distt.Ropar 
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="b1"><span class="t1">
                     CBSE Affiliated Code No.:<? echo $AffNo;?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="t1">email:mvps54@yahoo.com<br />
                      www.madhubanvatika.com</td>
                  </tr>
                </table>
              </td>
                <td width="191" align="right" valign="top"><table width="100%" border="0" align="right">
                  <tr>
                    <td align="center"><img src="../student_detail/reports/phone.jpg" width="20" height="20" /></td>
                    <td align="right" class="r"><strong>
                      <?php  echo $Phone; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td width="112" class="r">Affiliation No.:</td>
                    <td width="40" align="right" class="r"><strong>
                      <?php  echo $AffiliationNo; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td class="r"> School Code :</td>
                    <td align="right"><span class="r"><strong>
                      <?php  echo $SchoolNo; ?>
                    </strong></span></td>
                  </tr>

                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr align="left" valign="top">
            <td height="4" align="center">  <span class="t1"><strong class="st3"><u>
                <br />
            First Term Academic Performance <? echo $session; ?><br />
            <br />
            </u></strong></span></td>
          </tr><?php  
 $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.Village,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' and  S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$s_id' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0) " );while($row=mysql_fetch_array($result)){$s_id=$row['sid'];$class=$row['CClass'];$name=$row['Name'];$mn=$row['MotherName'];
$fn=$row['FatherName']; $Photo=$row['Photo'];$Section=$row['Section'];$Village1=$row['Village1'];$F_Mobile=$row['F_Mobile'];$Roll_No=$row['Roll_No'];$AdmNo=$row['AdmNo'];  $Blood=$row['Blood Group'];
  ?>  	 
          <tr align="left" valign="top">
            <td valign="top">
              <table width="740" border="0" align="center">
                <tr>
                 <td width="41" rowspan="5" class="st4"><?php if($Photo!=""){echo '<img src="'.$Photo=$row['Photo'].'" width="99" height="126"/>';?><? }else {}?></td>
                  <td colspan="10" class="b1"> 
                    &nbsp;<?php  echo $name;?> </td>
                  <td colspan="2" class="st4">&nbsp;</td>
                </tr>
                <tr>
                  <!--<td width="17" rowspan="5" valign="top"><?PHP  //$img= $row['Photo'];?></td>-->
                <td width="119" height="29" class="st4">Admission No: </td>
                <td width="44" class="st4"><strong><?php echo $AdmNo;?></strong></td>
                <td colspan="3" class="st4">Roll No:</td>
                <td width="50" class="st4"><strong><?php echo $Roll_No;?></strong></td>
                <td width="50" class="st4">Class:</td>
                <td width="46" class="st4"><strong>
                  <?php  $result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$class' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){   echo $row2['ClassName'];   $cl=$row2['ClassNo']; }  ?>
                </strong></td>
                <td width="66" class="st4">Section:</td>
                <td width="30" class="st4"><strong>
                  <?  $d1=mysql_query($sql1="select * from `4Sections` where `MSID`='$msid'  And `ID`='$Section'   ORDER BY `ID` ASC  "); while($row12=mysql_fetch_array($d1)){
	 echo $Sectionname12= $row12['Sectionname'];}?>
                </strong></td>
                <td width="60" class="st4">Overall Grade:</td>
                <td width="62" class="st4"><strong>
                  <?  $ghi6=mysql_query($gh6="SELECT Q1.StudentId, Q1.Point,G.Grade,Q1.Class FROM (Select StudentId, MSID, Class, (Sum(`MarksObtained`)/SUM(`MaxMarks`)*100) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id') Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto` And  Q1.`Class` between  G.ClassFrom And 	G.ClassTo "); while($gow6=mysql_fetch_array($ghi6)){echo $Grade6=$gow6['Grade'];}  ?>
                </strong></td>
                </tr>
              <tr>
                <td height="28" colspan="2" class="st4">Father's Name:</td>
                <td colspan="8" class="st4"><strong>
                  <?php  echo "Mr.".' '.$fn;?>
                </strong></td>
                <td colspan="2" class="st4">&nbsp;</td>
              </tr>
              <tr>
                <td height="28" colspan="2" class="st4">Mother's Name:</td>
                <td colspan="8" class="st4"><strong>
                  <?php  echo  "Mrs.".' '.$mn;?>
                </strong></td>
                <td colspan="2" class="st4">&nbsp;</td>
              </tr>
              <tr>
                <td height="36" colspan="2" valign="top" class="st4">Address</td>
                <td colspan="6" valign="top" class="st4"><? echo $Village1;?></td>
                <td colspan="2" valign="top" class="st4">Mobile No:</td>
                <td colspan="2" valign="top" class="st4"><? echo $F_Mobile;?> </td>
              </tr>
              <tr>
                <td height="5" colspan="2" class="st3"><strong>Health Status</strong></td>
                <td width="57" class="st4">&nbsp;</td>
                <td colspan="2" class="st4">&nbsp;</td>
                <td class="st4">&nbsp;</td>
                <td colspan="2" class="st4">&nbsp;</td>
                <td colspan="2" class="st3"><strong>Term 1</strong></td>
                <td colspan="2" class="st3"><strong>Term 2</strong></td>
              </tr>
              <tr>
                <td height="5" class="st4">Height:</td>
                <td height="5" class="st4"><? 		  
 $hshi=mysql_query($hsh="SELECT * From `21Repodata4healthsts` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($hsow=mysql_fetch_array($hshi)){  echo $Height= $hsow['Height'];  $DentalHygiene= $hsow['DentalHygiene'];	  $Weight= $hsow['Weight']; $VisionL= $hsow['VisionL']; $VisionR= $hsow['VisionR']; }  	?></td>
                <td colspan="3" class="st4">Weight:</td>
                <td class="st4"><? echo $Weight;?></td>
                <td colspan="2" class="st4">Attendance:</td>
                <td colspan="2" class="st4"><?  $ashi=mysql_query($ash="SELECT * From `26TWDays` Where  MSID='$msid' and Session='$session'  and SID='$s_id' and Term='1'"); 		while($asow=mysql_fetch_array($ashi)){  echo $TERMATT= $asow['TERMATT'].' '.'/'.' '.$TWD= $asow['TWD']; } ?></td>
                <td colspan="2" class="st4"><? /* $ashi1=mysql_query($ash1="SELECT * From `26TWDays` Where  MSID='$msid' and Session='$session'  and SID='$s_id' and Term='2'"); 		while($asow1=mysql_fetch_array($ashi1)){  echo $TERMATT1= $asow1['TERMATT'].' '.'/'.' '.$TWD1= $asow1['TWD']; }*/ ?></td>
              </tr>
              <tr>
                <td height="32" class="st4">Blood Group</td>
                <td height="32" class="st4"><? echo $Blood;?></td>
                <td class="st4">&nbsp;</td>
                <td colspan="2" class="st4">Vision:(L)</td>
                <td class="st4"><? echo $VisionL;?></td>
                <td colspan="2" class="st4">(R):<? echo $VisionR;?></td>
                <td colspan="3" class="st4">Dental Hygiene</td>
                <td class="st4"><? echo $DentalHygiene;?></td>
                </tr>  
            
              <tr>
                <td height="52" colspan="13" valign="top"><br />
                  <table width="100%" height="112" border="1" align="center">
          <tr valign="top"  bgcolor="#C9C9C9" class="st4">
            <td height="21" class="st411">&nbsp;</td>
            <td colspan="4" align="center" class="st411">Term 1 Grade</td>
            <td colspan="4" align="center" class="st411">Term 2 Grade</td>
            <td colspan="4" align="center" class="st411">(Term 1+Term 2)</td>
            </tr>
          <tr valign="top"  bgcolor="#C9C9C9" class="st4">
            <td height="36" class="st411"><strong>Subjects</strong></td>
            <td class="st411">FA1</td>
            <td class="st411">FA2</td>
            <td width="33" class="st411">SA1</td>
            <td width="49" class="st411">TOT-1</td>
            <td width="30" class="st411">FA3</td>
            <td width="29" class="st411">FA4</td>
            <td width="30" class="st411">SA2</td>
            <td width="47" class="st411">TOT-2</td>
            <td width="22" class="st411">FA </td>
            <td width="24" class="st411">SA</td>
            <td width="118" class="st411">Overall Grade<br />
              (Term 1+Term 2)</td>
            <td width="83" class="st411">Grade Point</td>
            </tr>
          <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
          <tr valign="top" class="st4">
            <td width="136" height="39" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
            <td width="25" class="st411"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></td>
            <td width="26" class="st411"><?php $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?></td>
            <td class="st411"><?php $gr23=mysql_query($ghyn23="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g23=mysql_fetch_array($gr23)){echo $Gn23=$g23['Grade'];}?></td>
            <td class="st411"><?php $gr2=mysql_query($ghyn2="select FL.msid,FL.stu_id,FL.name,FL.house,FL.cclass,FL.cclass,FL.subject,FL.mo as percent,G.grade,G.gradepoint,FL.t from(select TG.msid,TG.stu_id,TG.name,TG.house,TG.cclass,TG.subject,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.name,term1.house,term1.cclass,term1.subject,term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as 

term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.mysession,FA_PER.name,FA_PER.house,FA_PER.cclass,FA_PER.subjectid,FA_PER.subject,
FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from(select 

FA1.msid,FA1.stu_id,FA1.mysession,FA1.name,FA1.house,FA1.cclass,RD.subjectid,sub.subject,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id 

,S.mysession,S.name,S.house,S.admclassno+year(U.mydate)-year(S.fsdate)+COALESCE(sum(E.result),0) as cclass FROM `13Students` S inner join 7FeeUsers U on U.msid=S.msid 

and U.mydate between S.fsdate and S.sldate left join 14Exam E on E.msid=S.msid and E.s_id=S.id where U.myuid='$foo' and S.id='$s_id') as FA1 inner join 21Repodata1 RD 

on RD.msid=FA1.msid and RD.studentid=FA1.stu_id and RD.session=FA1.mysession inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid) as FA_PER ) as term1 inner join 22Weightage W 

on W.msid=term1.msid and W.assid=term1.assid and term1.cclass between W.classfrom and W.classto) as TG group by TG.subject,TG.t order by TG.t) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and FL.cclass between G.classfrom and G.classto where FL.subjectid='$sb'  ORDER BY FL.subjectid"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['grade'];}?>
              &nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
          </tr>
          <?php   }
		  ?>
                </table></td>
              </tr>
            </table>
              <br />
         </td>
          </tr>
        </table></td>
      </tr>
    </table>  
<br />
<p class="page"></p>
<br />
<table width="750" border="1"   align="center" >
  <tr>
    <td height="933"><table width="100%" height="804" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top">
        <td height="78"><table width="100%" height="62" border="1" align="center">
          <tr valign="top">
            <td width="61" height="22" valign="middle" bgcolor="#E8E8E8" class="st4"><strong>PART 2 <br />
              (A)</strong></td>
            <td width="243" height="22" valign="middle" bgcolor="#E8E8E8" class="st4"><strong>Co-Scholastic Areas</strong></td>
            <td width="53" height="22" valign="middle" bgcolor="#E8E8E8" class="st4"><strong>Grade</strong></td>
            <td width="347" height="22" valign="middle" bgcolor="#E8E8E8" class="st4"><strong>Descriptive Indicators</strong></td>
          </tr><?   $lhi=mysql_query($lh="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$sid' And 21R2.`Session`='$session' And `Marks`>'0'   And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low=mysql_fetch_array($lhi)){   $Marks= $low['Marks'];      $pr=$low['Particular'];$ghi=mysql_query($gh="SELECT * FROM `24Cograde` Where '$Marks' between `GradePointRangefm` And `GradePointRangeTo`"); 
			 while($gow=mysql_fetch_array($ghi)){        $gr= $gow['GRADE_NAME'];  }
  $bhi=mysql_query($bh="SELECT * FROM `25IndicatorDesc` Where Grade='$gr' And  PartNo='$pr' And  MSID='$msid'"); while($bow=mysql_fetch_array($bhi)){      $bow['Grade'];      $sb1= $bow['Des']; ?>
          <tr valign="top">
            <td height="32" class="st4"><?php $j=1;echo $g=$j+$g;?></td>
            <td class="st4"><? echo  $pr;?></td>
            <td class="st4"><?php  echo   $gr;  ?></td>
             <td class="st4"><?php   echo "$Name "." $sb1"; }  ?>&nbsp;</td>
          </tr><? }?>
          </table></td> 
      </tr>
      <tr>
        <td><table width="100%" border="1">
          <tr>
            <td align="center" class="st4"><strong>Result Qualified</strong></td>
            </tr>
          <tr>
            <td height="32" class="st4">My Goals:</td>
            </tr>
          <tr>
            <td height="37" class="st4">My Strengths:</td>
          </tr>
          <tr>
            <td height="34" class="st4">My Interests and Hobbies:</td>
            </tr>
          <tr>
            <td height="39" class="st4">Responsibilities Discharged / Exceptional Achievements:</td>
          </tr>
          <tr>
            <td height="66" class="st4"><table width="727" border="0">
              <tr>
                <td width="221" valign="top">Student:<br />
                  Place:<br />
                  Dated:</td>
                <td width="279" align="center" valign="top">Class Teacher:</td>
                <td width="213" valign="top"><p>Principal</p>
                  <p>(with School Seal)</p></td>
              </tr>
              </table></td>
          </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<?php }}?>
<form id="contactform" name="contactform" method="post" action="../student_detail/reports/admin.php">
 <input type="button" value="Print" onclick="printpage();">
<input type="submit" name="Submit" value="Exit" />
</form>
<p class="page"></p>	</body>	
</html><? }?>