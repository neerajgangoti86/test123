<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }
if($_POST){$sid=$_POST['c'];
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
}else {
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 $id1=$_GET['id'];$sid = mysql_real_escape_string($id1);}


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$sid' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass']; $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate'];  
$Add_ReportC= $row['Add_ReportC'];

} ?>::Report Card</title>
 <style>
p.page { page-break-after: always; }
 </style>
<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}
.b1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.m1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.n1 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>       <style type="text/css">
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
-->
</style>
<table width="664" height="845" border="1"   align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td width="652" height="839"><table width="100%" height="833" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top">
        <td width="704" height="140" align="center"><table width="100%" height="202" align="center">
          <tr>
            <td width="87" height="196" align="left" valign="top"><table width="88" border="0" align="center">
              <tr>
                <td width="82" height="92"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
              </tr>
            </table></td>
            <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
              <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
              <tr>
                <td width="539" height="40" align="center" class="m1"><?php echo $sname;?></td>
              </tr>
              <tr>
                <td height="30" align="center" class="b1"><? echo   $Place;  ?></td>
              </tr>
              <tr>
                <td height="31" align="center" class="n1">Website:<? echo $Website;?>,E-mail:<? echo $EMail;?>,Ph:<? echo $Phone;?></td>
              </tr>
              <tr>
                <td height="25" align="center" class="n1">Affiliated to CBSE ,Delhi ,Affiliation No.:<? echo $AffiliationNo;?></td>
              </tr>
            </table>
              <p class="vks">Record of Academic Performance <? echo $session; ?></p></td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="163"><table width="100%" height="161" border="0" align="center">
          <tr valign="top" class="st42">
            <td width="139" rowspan="5"><img style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php  if($Photo!=""){echo $Photo;} else { 	echo"../../images/myprofile1.png";} ?>" width="122" height="127" /></td>
            <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td height="33"><? echo $Name;?></td>
            <td height="33">&nbsp;</td>
            <td width="106" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td width="105" ><? echo $sid;?>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="21">Father's Name:</td>
            <td width="238" height="21">Mr. <? echo $FatherName;?></td>
            <td width="11" height="21">&nbsp;</td>
            <td>Roll No.:</td>
            <td><? echo $Roll_No;?>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="24">Mother's Name:</td>
            <td height="24">Mrs. <? echo $MotherName;?></td>
            <td height="24">&nbsp;</td>
            <td>Class:</td>
            <td><? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
              &nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="38">Mobile</td>
            <td height="38"><? echo $F_Mobile;?></td>
            <td height="38">&nbsp;</td>
            <td>Date Of Birth: </td>
            <td><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?>
              &nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="33">Address:</td>
            <td height="33" colspan="4"><? echo $Add_ReportC;?> </td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td> <? //if($ULevel=='9'){ ?>
        
        
        <table width="90%" height="197" border="1" align="center">
          <tr valign="top" bgcolor="#E8E8E8">
            <td width="237" height="30" class="st411">SCHOLASTIC AREA<br />
              (9 point scale)</td>
            <!--<td colspan="3" class="st411" align="center">TERM I</td> <td colspan="3" class="st411" align="center">TERM II</td>
            <td class="st411" align="center">Final Assessment</td>-->
            <td colspan="2" align="center" class="st411">TERM II</td>
            </tr>
          <tr valign="top"  bgcolor="#C9C9C9">
            <td height="30" class="st411"><strong>Subjects</strong></td>
            <!--<td class="st411">FA1
              (10%)</td>
            <td class="st411">FA2
              (10%)</td>
            <td width="63" class="st411">SA1
              (30%)</td>-->
              <td width="166" align="center" class="st411">FA3
              (10%)</td>
              <td width="156" align="center" class="st411">FA4 (10%)</td>
           
              <!-- <td width="48" class="st411">SA2
              (30%)</td>
            <td width="169" class="st411">Overall<br />
              (FA+SA=50%)</td>-->
          </tr>
          <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
          <tr valign="top">
            <td height="41" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
           <!-- <td width="54" class="st411"><?php  /* $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}*/?></td>
            <td width="64" class="st411"><?php /*$gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}*/?></td>
            <td class="st411"><?php /*$gr23=mysql_query($ghyn23="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g23=mysql_fetch_array($gr23)){echo $Gn23=$g23['Grade'];}*/?></td>
-->
 <td align="center" class="st411"><?php $gr232=mysql_query($ghyn232="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g232=mysql_fetch_array($gr232)){echo $Gn232=$g232['Grade'];}?></td>
<td class="st411" align="center"><?php $gr233=mysql_query($ghyn233="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g233=mysql_fetch_array($gr233)){echo $Gn233=$g233['Grade'];}?></td>
 <!--<td class="st411"><?php /*$gr234=mysql_query($ghyn234="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='6' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g234=mysql_fetch_array($gr234)){echo $Gn234=$g234['Grade'];}*/?></td>-->
            
           <!-- <td class="st411">
			<?php /*$gr2=mysql_query($ghyn2="select FL.msid,FL.stu_id,FL.name,FL.house,FL.cclass,FL.cclass,FL.subject,FL.mo as percent,G.grade,G.gradepoint,FL.t from(select TG.msid,TG.stu_id,TG.name,TG.house,TG.cclass,TG.subject,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.name,term1.house,term1.cclass,term1.subject,term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as 

term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.mysession,FA_PER.name,FA_PER.house,FA_PER.cclass,FA_PER.subjectid,FA_PER.subject,
FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from(select 

FA1.msid,FA1.stu_id,FA1.mysession,FA1.name,FA1.house,FA1.cclass,RD.subjectid,sub.subject,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id 

,S.mysession,S.name,S.house,S.admclassno+year(U.mydate)-year(S.fsdate)+COALESCE(sum(E.result),0) as cclass FROM `13Students` S inner join 91Users U on U.msid=S.msid 

and U.mydate between S.fsdate and S.sldate left join 14Exam E on E.msid=S.msid and E.s_id=S.id where U.myuid='$foo' and S.id=$sid) as FA1 inner join 21Repodata1 RD 

on RD.msid=FA1.msid and RD.studentid=FA1.stu_id and RD.session=FA1.mysession inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid) as FA_PER ) as term1 inner join 22Weightage W 

on W.msid=term1.msid and W.assid=term1.assid and term1.cclass between W.classfrom and W.classto) as TG group by TG.subject,TG.t order by TG.t) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and FL.cclass between G.classfrom and G.classto where FL.subjectid='$sb' And FL.t ='2'  ORDER BY FL.subjectid"); while($g2=mysql_fetch_array($gr2)){ echo $Gn2=$g2['grade'];
}*/?>
              &nbsp;</td>-->
          </tr>
          <?php   }
		  ?>
          <!--<tr valign="top">
            <td height="17" class="st411">ATTENDANCE</td>
            <?php 
				/* $att1=mysql_query($aq1="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='1'");
				 while($at1=mysql_fetch_array($att1)){ $Term1WD= $at1['TWD']; $Term1Att= $at1['TERMATT'];}*/ ?>
            <td class="st411"><? //echo $Term1Att ;?>/ <? //echo $Term1WD ;?></td>
            <td class="st411"><? //$tatt= ($Term1Att/$Term1WD) * 100 ; echo round($tatt,2) ;?>
              %</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
            <td class="st411">&nbsp;</td>
             <td class="st411">&nbsp;</td>
          </tr>-->
          <tr valign="top">
            <td height="63" colspan="3" align="left" class="st2">Nine point grading scale:A1=91%-100%;A2=81%-90%;B1=71%-80%;B2=61%-70%; c1=51%-60%;C2=41%-50%;D=33%-40%;E1=21%-32%;E2 =20% And Below</td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="123" valign="top"><table width="100%" height="151" border="0" align="center">
          <tr>
            <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: &nbsp;&nbsp;Congratulations
              <? $trjjrm=mysql_query($qjjrm="Select Remarks from 21Remarks where SID='$sid' AND  MSID='$msid'  AND Session='$session'");
				 while($ttjjrm=mysql_fetch_array($trjjrm)){ echo $remarks=$ttjjrm['Remarks']; }?>
            </strong><br/></td>
          </tr><? //}else {?> Result Will Be Displayed On 19-09-2015(Saturday)  <? //}?>
          <tr>
            <td height="26" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>
              <!--Note:</strong>(1)Promotion is based on the day -to -day continuous assessment throughout the year.(2) CGPA=Cumulative Grade Point Average (3) Subject Wise/Overall indicative percentage of Marks=9.5 X GP of the subject /CGPA.--></td>
          </tr>
          <tr>
            <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
            <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
  <p class="page"></p>
  <?php }}?>
</p></body>
</html>
