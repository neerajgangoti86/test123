<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
$sec1=$_GET['sec'];    $sect = mysql_real_escape_string($sec1);

 
$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno'   And S.Section='$sect'   And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){$s_id= $gow5['sid'];?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$TermDate= $row['TermDate']; 
} ?>::Report Card</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<style type="text/css">
.style2 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
</style>
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
</head>
 
<body><style>
p.page { page-break-after: always; }
</style>      <?php   
 $result=mysql_query($sql="SELECT (S.Id)as sid,S.*,P.*,L.Village,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.Id='$s_id' And P.MSID='$msid'"  );while($gow=mysql_fetch_array($result)){$sid=$gow['sid'];$ClassName=$gow['ClassName'];$name=$gow['Name'];$mn=$gow['MotherName'];
$fn=$row['FatherName']; 
$Village1=$row['Village1']; 
  ?><table width="692" border="1" align="center">
  <tr>
    <td width="686"><table width="673" height="667" align="center" bordercolor="#2A3F00" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat">
      <tr align="left" valign="top">
        <td width="665" height="138"><table width="713">
          <tr>
            <td colspan="3" align="center"><span class="m1">
              <?php  echo $sname;?>
            </span></td>
          </tr>
          <tr>
            <td width="96" align="left"><table width="69" border="0" align="center">
              <tr>


                <td width="63"><img class="logo" src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Uplaod/aboutlogo.jpg";} ?>"  width="90" height="100" /></td>
              </tr>
            </table></td>
            <td width="401" align="center" valign="top"><table width="406" border="0" align="center">
              <tr>
                <td width="400" align="center" ><span class="b1">
                  <?php  echo $Place; ?>
                </span></td>
              </tr>
              <tr>
                <td align="center" class="b1"><span class="t1">
                  <?php  echo $Board; ?>
                </span></td>
              </tr>
              <tr>
                <td align="center" class="t1"><span class="m1"><u><span class="style2">Session:<? echo $session;?></span></u></span></td>
              </tr>
            </table>
              <span class="m1"><u>Progress Report</u></span></td>
            <td width="200" align="right" valign="top"><table width="200" border="0" align="right">
              <tr>
                <td align="center"><img  src="../student_detail/reports/phone.jpg"  width="25" height="25" /></td>
                <td align="right" class="r"><strong>
                  <?php  echo $Phone; ?>
                </strong></td>
              </tr>
              <tr>
                <td width="144" class="r">Affiliation No.:</td>
                <td width="46" align="right" class="r"><strong>
                  <?php  echo $AffiliationNo; ?>
                </strong></td>
              </tr>
              <tr>
                <td class="r"> School Code :</td>
                <td align="right"><span class="r"><strong>
                  <?php  echo $SchoolNo; ?>
                </strong></span></td>
              </tr>
              <tr>
                <td><span class="r">Recognition No.:</span></td>
                <td align="right"><strong class="r">
                  <?php  echo $Reconiation_no; ?>
                </strong></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>

      <tr align="left" valign="top">
        <td height="521" align="center" valign="top"><table width="668" height="185" border="0" align="center">
          <tr valign="top">
            <td width="658" height="179" colspan="2" align="center"><table width="693" border="0">
              <tr>
                <td height="27" colspan="6"><span class="b1"><?php echo $gow['Name'];?></span></td>
              </tr>
              <tr>
                <td height="36" colspan="6" class="st4">Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $sid;?></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class/House:&nbsp; <strong>
                  <?  $cl= $gow['CClass'];$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$cl' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){  echo $row2['ClassName']; }  if($nos>'0'){  $Section= $gow['Section']; $d1=mysql_query($sql1="select * from `4Sections` where `MSID`='$msid'  And `ID`='$Section'   ORDER BY `ID` ASC  "); while($row12=mysql_fetch_array($d1)){  echo $Sectionname12= $row12['Sectionname'];}}else {} if($noh>'0'){?>
                  <?php  $house=$gow['House'];  $d=mysql_query($sql="select * from `3Houses` where `MSID`='$msid' And `Id`='$house'  ORDER BY `ID` ASC "); while($row1=mysql_fetch_array($d)){echo $h= $row1['HouseFName'] ;}?>
                  <?php }else {} ?>
                  </strong>&nbsp;&nbsp;&nbsp;&nbsp;<span class="style19">Birth Date: </span>&nbsp;&nbsp; <span class="style19"> <strong>
                    <?php   $dob=$gow['BirthDate'];echo $new_date = date('d-m-Y', strtotime($dob));?>
                  </strong></span></td>
              </tr>
              <tr>
                <td width="159" height="31"><span class="style19">Father's Name: </span></td>
                <td colspan="4"><span class="style19"><strong><?php echo "Mr.".' '.$gow['FatherName'];?></strong></span></td>
                <td width="177">&nbsp;</td>
              </tr>
              <tr>
                <td height="36"><span class="style19">Mother's Name: </span></td>
                <td colspan="5"><span class="style19"><strong><?php echo "Mrs.".' '.$gow['MotherName'];?></strong></span></td>
              </tr>
              <tr>
                <td height="34" colspan="6"><span class="style19">Village/Town:<strong><?php echo $gow['Village1'];?></strong><span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>District: <strong>
                  <?php   echo $gow['District'];?>
                </strong> <span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phones:<strong><?php echo $gow['F_Mobile'];?></strong></span></span></td>
              </tr>
              <tr>
                <td height="21" valign="bottom"><span class="style19">Total Working Days:</span></td>
                <td width="214" align="center"><span class="style19"><strong  >
                  <?php 
 $result7=mysql_query($sql7="SELECT * from `26TWDays` where  SID='$sid' and Term='1' and Session='$session' AND  MSID='$msid' ");
	  while($row7=mysql_fetch_array($result7)){  echo $row7['TWD'];    $TERMATT= $row7['TERMATT'];}  
					  
			?>
                  </strong></span></td>
                <td colspan="2" align="center"><span class="style19">Total Attendance:</span><span class="style19"><strong  > </strong></span></td>
                <td colspan="2" align="center"><span class="style19">
                  <?php   $result7=mysql_query($sql7="SELECT * from `26TWDays` where  SID='$sid' and Term='1' and Session='$session' AND  MSID='$msid' ");
	  while($row7=mysql_fetch_array($result7)){  echo  $TERMATT= $row7['TERMATT'];}  
 ?>
                  </span></td>
              </tr>
              <?php  //}?>
            </table>
              <span class="style2"><u><br />
              First Semester Result</u></span><br />
              <br />
              <table width="692" border="1" align="center">
                <tr align="left" valign="top">
                  <td width="169" height="23" rowspan="2"><span class="style19"><strong>Subjects:</strong></span></td>
                  <td width="52" rowspan="2" class="st4"><strong> Unit 1</strong></td>
                  <td width="52" rowspan="2" class="st4"><strong>Unit 2</strong></td>
                  <td colspan="5" align="center" class="st4"><strong>1st Semester Exam</strong></td>
                </tr>
                <tr align="left" valign="top">
                  <td width="92" align="center" class="st4">Theory<br />
                    85/75/60/35</td>
                  <td width="48" align="center" class="st4">Prac.<br />
                    25/50</td>
                  <td colspan="2" align="center" class="st4">Dic./MCQ/Ass/Pro<br />
                    15</td>
                  <td width="72" align="center" class="st4"><p>Total<br />
                    100</p></td>
                </tr>
                <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 	
 	while($pow=mysql_fetch_array($phi)){ 
				 
				  ?>
                <tr align="left" valign="top">
                  <td height="23"><span class="style19">
                    <?php    $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?>
                  </span></td>
                  <td><span class="style19">
                    <?php  $ghiy8=mysql_query($ghy8="SELECT  round(MarksObtained)as marks FROM `21Repodata1` RD   WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`");
			   while($gowy8=mysql_fetch_array($ghiy8)){echo  $submks=$gowy8['marks'];}?>
                  </span></td>
                  <td><span class="style19">
                    <?php  $ghiyg=mysql_query($ghyg="SELECT  round(MarksObtained)as marks FROM `21Repodata1` RD   WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`");
			   while($gowyg=mysql_fetch_array($ghiyg)){echo  $submkg=$gowyg['marks'];}?>
                  </span></td>
                  <td><span class="style19">
                    <?php   $gr3=mysql_query($ghyn3="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='2'  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g3=mysql_fetch_array($gr3)){echo $Gn3=$g3['MarksObtained'].'  '.'/'. $Gnmx=$g3['MaxMarks'];}?>
                  </span></td>
                  <td><span class="style19">
                    <?php   $gr18=mysql_query($ghyn18="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='7'  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g18=mysql_fetch_array($gr18)){echo $Gn18=$g18['MarksObtained'];}?>
                  </span></td>
                  <td colspan="2" align="center"><span class="style19">
                    <?php  /* $gr18=mysql_query($ghyn18="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='3'  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g18=mysql_fetch_array($gr18)){echo $Gn18=$g18['MarksObtained'];}*/?>
                    </span><span class="style19">
                      <?php   $gr7=mysql_query($ghyn7="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='4' OR RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='5' Or  RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='9'  Or  RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='3' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g7=mysql_fetch_array($gr7)){echo $Gn7=$g7['MarksObtained'].'/';}?>
                    </span></td>
                  <td align="center"><span class="style19">
                    <?php $queryA =mysql_query($hnyn4="SELECT MarksObtained,MaxMarks,SubjectId FROM `21Repodata1Oral` WHERE `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='85' And MarksObtained>=28.5 AND StudentId='$s_id'  AND  `SubjectId`='$sb' OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='60' And MarksObtained>=20 AND StudentId='$s_id'  AND  `SubjectId`='$sb'  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='35' And MarksObtained>=12 AND StudentId='$s_id'  AND  `SubjectId`='$sb' OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='75' And MarksObtained>=25 AND StudentId='$s_id'  AND  `SubjectId`='$sb'"); while($nh4=mysql_fetch_array($queryA)){  $nhn4=$nh4['MarksObtained'];} /**/
                    if(mysql_num_rows($queryA) == 1)
 {
                    
                    		$hr4=mysql_query($hhyn4="SELECT Sum(MarksObtained) as  sumoh FROM `21Repodata1Oral` WHERE 
`Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='85' And MarksObtained>=28.5 AND StudentId='$s_id'  AND  `SubjectId`='$sb' 
  OR
   `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='60' And MarksObtained>=20  AND StudentId='$s_id'  AND  `SubjectId`='$sb'
   OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='35' And MarksObtained>=12 AND StudentId='$s_id'  AND  `SubjectId`='$sb'
    OR
	 `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='75' And MarksObtained>=25 AND StudentId='$s_id'  AND  `SubjectId`='$sb'
	  OR 
	  `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='7'  AND StudentId='$s_id'  AND  `SubjectId`='$sb' 
	  
	  
	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='4'  AND StudentId='$s_id'  AND  `SubjectId`='$sb' 
	  
	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='5'  AND StudentId='$s_id'  AND  `SubjectId`='$sb' 
	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='9'  AND StudentId='$s_id'  AND  `SubjectId`='$sb'
	  	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='3'  AND StudentId='$s_id'  AND  `SubjectId`='$sb'"); while($h4=mysql_fetch_array($hr4)){echo $hn4=$h4['sumoh'];$totalsem=$hn4+$totalsem;}
 }else {echo "--";}?>
                  </span></td>
                </tr>
                <? }?>
                <tr align="left" valign="top">
                  <td height="23">&nbsp;</td>
                  <td colspan="2" align="left" class="style19">&nbsp;</td>
                  <td colspan="3" align="center" class="st4">Percentage<span class="style4">:</span></td>
                  <td width="69" align="center" class="style19"><strong>
                    <?  $queryB =mysql_query($hnyn4="SELECT MarksObtained,MaxMarks,SubjectId FROM `21Repodata1Oral` WHERE `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='85' And MarksObtained<28.5 AND StudentId='$s_id' OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='60' And MarksObtained<20 AND StudentId='$s_id'  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='35' And MarksObtained<12 AND StudentId='$s_id'  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='75' And MarksObtained<25 AND StudentId='$s_id' limit 1"); while($nj4=mysql_fetch_array($queryB)){  $njn4=$nj4['MarksObtained'];} /**/
                    if(mysql_num_rows($queryB) == 1)
 { echo "--";}else {
                  $hrj=mysql_query($hhynj="Select round(Sum(q1.MarksObtained)/sum(q1.MaxMarks)*100,2) as per,q1.StudentId from (SELECT MarksObtained,MaxMarks,StudentId ,SubjectId FROM `21Repodata1Oral` WHERE `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='85' And MarksObtained>=28.5 AND StudentId='$s_id'  
  OR    `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='60' And MarksObtained>=20  AND StudentId='$s_id'   
   OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='35' And MarksObtained>=12 AND StudentId='$s_id' 
    OR 	 `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='75' And MarksObtained>=25 AND StudentId='$s_id'   
	  OR   `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='7'  AND StudentId='$s_id'   
 	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='4'  AND StudentId='$s_id'   
 	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='5'  AND StudentId='$s_id'  
	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='9'  AND StudentId='$s_id' 
	   OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='3'  AND StudentId='$s_id' 
	     ) q1 where  q1.`SubjectId`!='9' group by q1.StudentId"); while($hj=mysql_fetch_array($hrj)){echo $hnj=$hj['per'].'%';}  
 } ?>
                  </strong></td>
                  <td align="center" class="style19"><strong>
                    <?  $queryC =mysql_query($hncn4="SELECT MarksObtained,MaxMarks,SubjectId FROM `21Repodata1Oral` WHERE `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='85' And MarksObtained<28.5 AND StudentId='$s_id' OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='60' And MarksObtained<20 AND StudentId='$s_id'  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='35' And MarksObtained<12 AND StudentId='$s_id'  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='75' And MarksObtained<25 AND StudentId='$s_id' limit 1"); while($nc4=mysql_fetch_array($queryC)){  $ncn4=$nc4['MarksObtained'];}  
                    if(mysql_num_rows($queryC) == 1)
 {  
                 echo "--";    }else {
                    		$xhj=mysql_query($xj="Select Sum(q1.MarksObtained) as total,q1.StudentId from (SELECT MarksObtained,MaxMarks,StudentId ,SubjectId FROM `21Repodata1Oral` WHERE `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='85' And MarksObtained>=28.5 AND StudentId='$s_id'  
  OR    `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='60' And MarksObtained>=20  AND StudentId='$s_id'   
   OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='2'  And `MaxMarks`='35' And MarksObtained>=12 AND StudentId='$s_id' 
    OR 	 `Class`='$cno' And `MSID`='$msid' And `Session`='$session' AND `TestName`='2' And `MaxMarks`='75' And MarksObtained>=25 AND StudentId='$s_id'   
	  OR   `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='7'  AND StudentId='$s_id'   
 	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='4'  AND StudentId='$s_id'   
 	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='5'  AND StudentId='$s_id'  
	  OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='9'  AND StudentId='$s_id' 
	    OR `Class`='$cno' And `MSID`='$msid' And `Session`='$session'   AND  `TestName`='3'  AND StudentId='$s_id' 
	     ) q1 where  q1.`SubjectId`!='9' group by q1.StudentId "); while($xxj=mysql_fetch_array($xhj)){echo  $xxj['total'];}/**/
 } ?>
                  </strong></td>
                </tr>
                <tr align="left" valign="top">
                  <td height="58" colspan="8" class="st4">Remarks</td>
                </tr>
              </table>
              <br />
              <table width="589" border="0">
                <tr>
                  <td>&nbsp; </td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
                <tr class="st4">
                  <td width="161">Father's Signature</td>
                  <td width="157">Teacher's signature</td>
                  <td width="157">Principal Signature</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<p class="page"></p>
</body>
   <? } ?> 
</html>
<?php  }} ?>