<?php // print_r($student); ?>

<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

<style type="text/css">
    .style2 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
    }
    .style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
    }

    p.page { page-break-after: always; }
</style>
<script language="javascript">
    function printpage()
    {
        window.print();
    }
</script><section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <?php
            if (@$id) {
                ?>
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title"> </h3>


                    </div>
                    <!-- /.box-header -->
                    <div class="box-footer clearfix">
                        <table width="200" border="1" align="center">
                            <tr>
                                <td><table width="200" border="0">
                                        <tr valign="top">
                                            <td height="710" align="center" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><span class="style2">Self Awarness </span><br />
                                                <br />
                                                <br />
                                                <br />
                                                <table width="550" border="1">
                                                    <tr>
                                                        <td width="540" height="147" valign="top"><span class="style19"><strong>My Goals: </strong></span><strong><br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                            </strong></td>
                                                    </tr>
                                                </table>
                                                <br />
                                                <table width="550" border="1">
                                                    <tr align="left" valign="top">
                                                        <td width="616" height="118"><span class="style19"><strong>Strengths:</strong></span><strong><br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                                <br />
                                                            </strong></td>
                                                    </tr>
                                                </table>
                                                <br />
                                                <br />
                                                <table width="550" height="116" border="1">
                                                    <tr valign="top">
                                                        <td width="403" height="110" align="left"><strong class="style19">My Interests and Hobbies: </strong><br />

                                                            <br />
                                                            <br /></td>
                                                    </tr>
                                                </table>
                                                <br />
                                                <table width="550" height="104" border="1">
                                                    <tr>
                                                        <td width="614" height="98" align="left" valign="top"><p><strong class="style19">Responsibilities Discharged/Exceptional Achievements: </strong><br />  
                                                                <br />
                                                                <br />
                                                                <span class="style19"><strong><br />
                                                                    </strong>Result:<strong>Qualified,Congratulations<br />
                                                                    </strong>Promoted to Class: <strong><?= $student['class'] + 1; ?>
                                                                        <?php
//                                                                        $clplus= $student['class']+1; 
//                                                                        $resulty=mysql_query($sqly="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$clplus' And MSID='$MSID' order by ClassNo ASC ");
//                                                                        while($rowy=mysql_fetch_array($resulty)){  echo $rowy['ClassName']; }
                                                                        ?></strong></span><br />
                                                            </p></td>
                                                    </tr>
                                                </table></td>
                                            <td>&nbsp;&nbsp;&nbsp;</td>
                                            <td><table width="587" border="0" align="center" cellpadding="2" cellspacing="2">
                                                    <tr>
                                                        <td width="575"><table width="575" height="696" align="center" bordercolor="#2A3F00" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat">
                                                                <tr align="left" valign="top">
                                                                    <td width="567" height="76"><table width="535">
                                                                            <tr>
                                                                                <td colspan="3" align="center"><span class="m1">
                                                                                        <?= $oCurrentSchool->name ?>
                                                                                    </span></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td width="78" align="left"><table width="69" border="0" align="center">
                                                                                        <tr>
                                                                                            <td width="63"><img  src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" height="80" width="70" /></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                                <td width="245" valign="top"><table width="232" border="0" align="center">
                                                                                        <tr>
                                                                                            <td width="226" align="center" ><span class="b1">
                                                                                                    <?= $oCurrentSchool->place ?>
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td align="center" class="b1"><span class="t1">
                                                                                                    <?= $oCurrentSchool->board ?>
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td align="center" class="t1">&nbsp;</td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                                <td width="200" align="right" valign="top"><table width="200" border="0" align="right">
                                                                                        <tr>
                                                                                            <td align="center">Phone No:</td>
                                                                                            <td align="right" class="r"><strong>
                                                                                                    <?= $oCurrentSchool->phone ?>
                                                                                                </strong></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="144" class="r">Affiliation No.:</td>
                                                                                            <td width="46" align="right" class="r"><strong>
                                                                                                    <?= $oCurrentSchool->affNo ?>
                                                                                                </strong></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td class="r"> School Code :</td>
                                                                                            <td align="right"><span class="r"><strong>
                                                                                                        <?= $oCurrentSchool->schoolNo ?>
                                                                                                    </strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="r">Recognition No.:</span></td>
                                                                                            <td align="right"><strong class="r">
                                                                                                    <?= $oCurrentSchool->recNo ?>
                                                                                                </strong></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                                <tr align="left" valign="top">
                                                                    <td height="22"><hr/></td>
                                                                </tr>
                                                                <tr align="left" valign="top">
                                                                    <td height="539" valign="top"><table width="553" height="185" border="1" align="center">
                                                                            <tr valign="top">
                                                                                <td width="521" height="179" colspan="2"><table width="553" border="0">
                                                                                        <tr>
                                                                                            <td height="27" colspan="6"><span class="b1"><?= $student['name']; ?></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="27" colspan="6" class="st4">Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student['student_id']; ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class/House:&nbsp;
                                                                                                <strong>
                                                                                                    <?= $student['class']; ?>/<?= $student['house']; ?>                                                                                                </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style19">Birth Date: </span>&nbsp;&nbsp;                      <span class="style19">
                                                                                                    <strong>
                                                                                                        <?php
                                                                                                        $dob = $student['birth_date'];
                                                                                                        echo $new_date = date('d-m-Y', strtotime($dob));
//                                                                                                        print_r($student) ;
//                                                                                                    exit();
                                                                                                        ?>
                                                                                                    </strong>                        </span></td>
                                                                                        </tr>

                                                                                        <tr>
                                                                                            <td width="161" height="26"><span class="style19">Father's Name: </span></td>
                                                                                            <td colspan="4"><span class="style19"><strong><?php echo "Mr." . ' ' . $student['f_name']; ?></strong></span></td>
                                                                                            <td width="7">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="24"><span class="style19">Mother's Name: </span></td>
                                                                                            <td colspan="5"><span class="style19"><strong><?php echo "Mrs." . ' ' . $student['m_name']; ?></strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="26" colspan="6"><span class="style19">Village/Town:<strong><?= $student['village'] ?></strong><span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> <strong>

                                                                                                    </strong>                        <span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phones:<strong><?php echo $student['f_mobile']; ?></strong></span></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="32" rowspan="2" valign="bottom"><span class="style19">Total Attendance:</span></td>
                                                                                            <td width="217" height="15" align="center"><span class="style19">Term 1</span></td>
                                                                                            <td width="20" rowspan="2" align="center">&nbsp;</td>
                                                                                            <td width="119" align="center"><span class="style19">term2</span></td>
                                                                                            <td colspan="2" rowspan="2" align="center">&nbsp;</td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="15" align="center"><span class="style19"><strong  ></strong></span></td>
                                                                                            <td width="119" align="center"><span class="style19"><strong  >

                                                                                                    </strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="21"><span class="style19">Total Working Days:</span></td>
                                                                                            <td height="21" align="center"><span class="style19">

                                                                                                </span></td>
                                                                                            <td height="21" align="center">&nbsp;</td>
                                                                                            <td align="center"><span class="style19">
                                                                                                </span></td>
                                                                                            <td colspan="2" align="center">&nbsp;</td>
                                                                                        </tr>
                                                                                        <?php //}        ?>
                                                                                    </table></td>
                                                                            </tr>
                                                                        </table>
                                                                        <br />
                                                                        <table width="571" height="95" border="1" align="center">
                                                                            <tr valign="top">
                                                                                <td width="561" height="89" colspan="2"><table width="561" border="0">
                                                                                        <tr valign="top">

                                                                                            <td width="106" height="35" align="center" class="style19"><strong><?= $health_data['height']; ?></strong><br />
                                                                                                Height(cm) </td>
                                                                                            <td align="center" class="style19"><strong><?= $health_data['weight']; ?></strong><br />
                                                                                                Weight(kg)</td>
                                                                                        <br />
                                                                                        <td align="center" class="style19"><strong></strong><br />
                                                                                            Blood Group</td>
                                                                                        <td colspan="2" align="center" valign="top"><strong class="style19">Vaccination</strong></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="31" align="center" class="style19"><strong><?= $health_data['vision_l']; ?></strong><br />
                                                                                    Vision-L </td>
                                                                                <td width="109" align="center" class="style19"><strong><?= $health_data['vision_r']; ?></strong><br />
                                                                                    Vision-R</td>
                                                                                <td width="87" align="center" class="style19"><strong><?= $health_data['nose']; ?></strong><br />
                                                                                    Nose</td>
                                                                                <td width="130" align="center" valign="top"><span class="style19">BCG</span><br />
                                                                                    <?php
                                                                                    if ($health_data['bcg_v'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                                <td width="107" align="center" valign="top"><span class="style19">Measles</span><br />
                                                                                    <?php
                                                                                    if ($health_data['measles'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="28" align="center" class="style19"><strong><?= $health_data['ear_l']; ?></strong><br />
                                                                                    Ear-L </td>
                                                                                <td align="center" class="style19"><strong><?= $health_data['ear_r']; ?></strong><br />
                                                                                    Ear-R</td>
                                                                                <td align="center" class="style19"  ><strong><?= $health_data['throat']; ?></strong><br />
                                                                                    Throat</td>
                                                                                <td align="center" valign="top"><span class="style19">Hepatitis B</span><br />
                                                                                    <?php
                                                                                    if ($health_data['hepatitis_b'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                                <td align="center" valign="top"><span class="style19">Hepatitis A</span><br />
                                                                                    <?php
                                                                                    if ($health_data['hepatitis_a'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="31" align="center" class="style19"><strong><?= $health_data['pulse']; ?></strong><br />
                                                                                    Pulse </td>
                                                                                <td align="center" class="style19"><strong><?= $health_data['heart']; ?></strong><br />
                                                                                    Heart</td>
                                                                                <td>&nbsp;</td>
                                                                                <td align="center" valign="top"><span class="style19">DPT</span><br />
                                                                                    <?php
                                                                                    if ($health_data['dpt'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                                <td align="center" valign="top"><span class="style19">Chickenpox</span><br />
                                                                                    <?php
                                                                                    if ($health_data['chickenpox'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="15" align="center" class="style19"><strong><?= $health_data['dental_hygiene']; ?></strong><br />
                                                                                    Dental Hygine </td>
                                                                                <td align="center" class="style19"  ><strong><?= $health_data['alergy']; ?></strong><br />
                                                                                    Allergy?</td>
                                                                                <td>&nbsp;</td>
                                                                                <td align="center" valign="top"><span class="style19">HB</span><br />
                                                                                    <?php
                                                                                    if ($health_data['hb'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                                <td align="center" valign="top"><span class="style19">DT.OPA</span><br />

                                                                                    <?php
                                                                                    if ($health_data['dt_opa'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="31" rowspan="2" align="center" class="style19"><strong><?= $health_data['chronic_diease']; ?></strong><br />
                                                                                    Chronic Diseases</td>
                                                                                <td rowspan="2" align="center" class="style19"  ><strong><?= $health_data['physical_activity_problem']; ?></strong><br />
                                                                                    Physical Activity</td>
                                                                                <td rowspan="2" align="center" class="style19"><strong><?= $health_data['any_other']; ?></strong><br />
                                                                                    <span class="style19"> Any Other ?</td>
                                                                                <td align="center" valign="top"><span class="style19">Oral Polio</span><br />
                                                                                    <?php
                                                                                    if ($health_data['oral_polio'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                                <td align="center" valign="top"><span class="style19">MMR</span><br />
                                                                                    <?php
                                                                                    if ($health_data['mmr'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="center" valign="top"><span class="style19">DPT+OPV+HB</span><br />
                                                                                    <?php
                                                                                    if ($health_data['dpt_opt_hb'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>
                                                                                <td align="center" valign="top"><span class="style19">Typhoid</span><br />
                                                                                    <?php
                                                                                    if ($health_data['typhoid'] == 'on') {
                                                                                        echo "Yes";
                                                                                    } else {
                                                                                        echo "No";
                                                                                    }
                                                                                    ?></td>

                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                            </table>
                                                            <br />
                                                            <table width="557" border="0" align="center">
                                                                <tr>
                                                                    <td width="121" align="center">....................</td>
                                                                    <td width="184" align="center">...........................</td>
                                                                    <td width="153" align="center">........................</td>
                                                                    <td width="81" align="center">.....................</td>
                                                                </tr>
                                                                <tr class="st4">
                                                                    <td align="center"><strong>Mother</strong></td>
                                                                    <td align="center"><strong>Father/Guardian</strong></td>
                                                                    <td align="center"><strong>Class Teacher</strong></td>
                                                                    <td align="center"><strong><!--<a href="reportcardp2.php?id=<? //echo " . $rowv['subject_id'] . ";?>&cno=<? //echo $cno;?>" style="text-decoration:none" target="_blank">-->Principal<!--</a>--></strong></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table></td>
                        </tr>
                        </table>
                        <br />
                        <table width="200" align="center" >
                            <tr>
                                <td><table width="200" border="1">
                                        <tr valign="top">
                                            <td align="center" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><table width="100%" border="0">
                                                    <tr>
                                                        <td width="329" class="st3"><strong>Part 1:Academic Performance:Scholastic Areas</strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center"><strong class="style19">term 1</strong></td>
                                                    </tr>
                                                </table>
                                                <table width="556" border="1">
                                                    <tr class="style19">
                                                        <td width="137" align="left" class="st4"><strong class="st4">Subjects</strong></td>
                                                        <?php
                                                        $sql_assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), '', '', '', 'Term 1', 'YES');
                                                        while ($rowv = $sql_assesments->fetch()) {
                                                            ?>
                                                            <td width="71" align="left" class="st4"><strong class="st4"><?= $rowv['title'] ?>
                                                                </strong></td><?php } ?>
                                                        <td width="68" align="left" class="st4"><strong class="st4">term|GR</strong></td>
                                                    </tr>
                                                    <?php
                                                    $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student['student_id'], $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                                    while ($rowv = $subjects_querry->fetch()) {
                                                        ?>
                                                        <tr class="style19" >

                                                            <?php
                                                            $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                                            while ($rowu = $subjects->fetch()) {
                                                                ?><td><?= $rowu['name'] ?></td>
                                                                <?php
                                                            }
                                                            ?>
                                                            <td width="132" align="center">
                                                                <?php
                                                                $fa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '1', $rowv['subject_id'], 'YES');
                                                                while ($rowu = $fa1->fetch(PDO::FETCH_ASSOC)) {
                                                                    ?><?= $rowu['Grade'] ?>
                                                                    <?php
                                                                }
                                                                ?></td>


                                                            <td width="147" align="center">
                                                                <?php
                                                                $fa2 = Exam::exam_grade_calculater($MSID, $student['student_id'], '2', $rowv['subject_id'], 'YES');
                                                                while ($rowu = $fa2->fetch()) {
                                                                    ?><?= $rowu['Grade'] ?>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </td>
                                                            <td width="75" align="center">    <?php
                                                                $sa1 = Exam::exam_grade_calculater($MSID, $student['student_id'], '5', $rowv['subject_id'], 'YES');
                                                                while ($rowu = $sa1->fetch()) {
                                                                    ?><?= $rowu['Grade'] ?>
                                                                    <?php
                                                                }
                                                                ?></td>


                                                            <td width="122" align="center">
                                                                <?php
                                                                $overall = Exam::exam_term_grade_calculater($MSID, $student['student_id'], '1', $rowv['subject_id']);
                                                                while ($rowu = $overall->fetch()) {
                                                                    ?><?= $rowu['grade'] ?>
                                                                <?php } ?></td></tr>
                                                        <?php
                                                    }
                                                    ?>
                                                </table>
                                                <table width="556" border="0">
                                                    <tr class="style19">
                                                        <td width="249"><strong>Part 2: Co-Scholastic Areas </strong></td>
                                                        <td width="297"><strong>(2 A) Life Skills </strong></td>
                                                    </tr>
                                                </table>

                                                <table width="550" border="0">
                                                    <tr>
                                                        <td width="564" height="13" valign="top"><table width="549" border="1">

                                                                <tr>
                                                                    <td width="192" height="23" valign="top"><span class="style19"><strong>(2 A) Life Skills </strong></span></td>
                                                                    <td width="293" valign="top"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                                                                    <td width="42" valign="top"><span class="style19"><strong>Grade</strong></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="23" colspan="3" valign="top"><span class="style19"><strong>Thinking Skills</strong></span></td>
                                                                </tr>

                                                                <tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Self Awarness</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw1 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Self Awareness'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw1 = $oDb->query($saw1);
                                                                            while ($rowu1 = $saw1->fetch()) {
                                                                                $gr1 = "";
                                                                                $marks1 = $rowu1['marks'];
                                                                                $title = $rowu1['title'];
                                                                                $co_scholastic_id = $rowu1['co_scholastic_id'];
                                                                            }
//                                                                              echo "<pre>";  print_r($rowu);
                                                                            if (@$marks1) {
                                                                                if (@$marks1 == '1') {
                                                                                    $gr1 = 'A';
                                                                                } else {
                                                                                    $gr1 = 'B';
                                                                                }
                                                                                $marks_Desc1 = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr1' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc1 = $oDb->query($marks_Desc1);
                                                                                while ($rowu1 = $marks_Desc1->fetch()) {
                                                                                    echo $rowu1['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr1) {
                                                                                
                                                                            } else {
                                                                                $gr1 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr1; ?>
                                                                        </span></td>
                                                                </tr><tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Decision Making</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw2 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "' And GI.title='Decision Making'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw2 = $oDb->query($saw2);
                                                                            while ($rowu2 = $saw2->fetch()) {
                                                                                $gr2 = "";
                                                                                $marks = $rowu2['marks'];
                                                                                $title = $rowu2['title'];
                                                                                $co_scholastic_id = $rowu2['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks5) {
                                                                                if ($marks == '1') {
                                                                                    $gr2 = 'A';
                                                                                } else {
                                                                                    $gr2 = 'B';
                                                                                }
                                                                                $marks_Desc2 = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr2' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc2 = $oDb->query($marks_Desc2);
                                                                                while ($rowu2 = $marks_Desc2->fetch()) {
                                                                                    echo $rowu2['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr2) {
                                                                                
                                                                            } else {
                                                                                $gr2 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr2; ?>
                                                                        </span></td>
                                                                </tr><tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Critical Thinking</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw3 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Critical Thinking'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw3 = $oDb->query($saw3);
                                                                            while ($rowu3 = $saw3->fetch()) {
                                                                                $gr3 = "";
                                                                                $marks = $rowu3['marks'];
                                                                                $title = $rowu3['title'];
                                                                                $co_scholastic_id = $rowu3['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks1) {
                                                                                if ($marks == '1') {
                                                                                    $gr3 = 'A';
                                                                                } else {
                                                                                    $gr3 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr3' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu3 = $marks_Desc->fetch()) {
                                                                                    echo $rowu3['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr3) {
                                                                                
                                                                            } else {
                                                                                $gr3 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr3; ?>
                                                                        </span></td>
                                                                </tr><tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Creative Thinking</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw4 = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Creative Thinking'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw4 = $oDb->query($saw4);
                                                                            while ($rowu4 = $saw4->fetch()) {

                                                                                $gr4 = "";
                                                                                $marks = $rowu4['marks'];
                                                                                $title = $rowu4['title'];
                                                                                $co_scholastic_id = $rowu4['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks) {
                                                                                if ($marks == '1') {
                                                                                    $gr4 = 'A';
                                                                                } else {
                                                                                    $gr4 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr4' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu4 = $marks_Desc->fetch()) {
                                                                                    echo $rowu4['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr4) {
                                                                                
                                                                            } else {
                                                                                $gr4 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr4; ?>
                                                                        </span></td>
                                                                </tr>

                                                                <tr>
                                                                    <td height="23" colspan="3" valign="top"><strong class="style19">Social Skills</strong></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Inter Personal Relationships</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Inter Personal Relationships'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw = $oDb->query($saw);
                                                                            while ($rowu = $saw->fetch()) {

                                                                                $gr5 = "";
                                                                                $marks5 = $rowu['marks'];
                                                                                $title = $rowu['title'];
                                                                                $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks5) {
                                                                                if ($marks5 == '1') {
                                                                                    $gr5 = 'A';
                                                                                } else {
                                                                                    $gr5 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr5' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu = $marks_Desc->fetch()) {
                                                                                    echo $rowu['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr5) {
                                                                                
                                                                            } else {
                                                                                $gr5 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr5; ?>
                                                                        </span></td>
                                                                </tr><tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Effective Communication</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Effective Communication'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw = $oDb->query($saw);
                                                                            while ($rowu = $saw->fetch()) {

                                                                                $gr6 = "";
                                                                                $marks6 = $rowu['marks'];
                                                                                $title = $rowu['title'];
                                                                                $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks6) {
                                                                                if ($marks6 == '1') {
                                                                                    $gr6 = 'A';
                                                                                } else {
                                                                                    $gr6 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr6' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu = $marks_Desc->fetch()) {
                                                                                    echo $rowu['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr6) {
                                                                                
                                                                            } else {
                                                                                $gr6 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr6; ?>
                                                                        </span></td>
                                                                </tr><tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Empathy</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Empathy'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw = $oDb->query($saw);
                                                                            while ($rowu = $saw->fetch()) {

                                                                                $gr7 = "";
                                                                                $marks7 = $rowu['marks'];
                                                                                $title = $rowu['title'];
                                                                                $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks7) {
                                                                                if ($marks7 == '1') {
                                                                                    $gr7 = 'A';
                                                                                } else {
                                                                                    $gr7 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr7' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu = $marks_Desc->fetch()) {
                                                                                    echo $rowu['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr7) {
                                                                                
                                                                            } else {
                                                                                $gr7 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr7; ?>
                                                                        </span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="23" colspan="3" valign="top"><strong class="style19">Emotional Skills</strong></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Managing Emotions</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Managing Emotions'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw = $oDb->query($saw);
                                                                            while ($rowu = $saw->fetch()) {

                                                                                $gr8 = "";
                                                                                $marks8 = $rowu['marks'];
                                                                                $title = $rowu['title'];
                                                                                $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks8) {
                                                                                if ($marks8 == '1') {
                                                                                    $gr8 = 'A';
                                                                                } else {
                                                                                    $gr8 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr8' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu = $marks_Desc->fetch()) {
                                                                                    echo $rowu['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr8) {
                                                                                
                                                                            } else {
                                                                                $gr8 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr8; ?>
                                                                        </span></td>
                                                                </tr><tr>
                                                                    <td height="23" valign="top" class="style19"><span class="style19">Empathy</span></td>
                                                                    <td valign="top"><span class="style19">
                                                                            <?php
                                                                            $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Dealing With Stress'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw = $oDb->query($saw);
                                                                            while ($rowu = $saw->fetch()) {

                                                                                $gr9 = "";
                                                                                $marks9 = $rowu['marks'];
                                                                                $title = $rowu['title'];
                                                                                $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                            }
                                                                            if (@$marks9) {
                                                                                if ($marks9 == '1') {
                                                                                    $gr9 = 'A';
                                                                                } else {
                                                                                    $gr9 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr9' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu = $marks_Desc->fetch()) {
                                                                                    echo $rowu['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr9) {
                                                                                
                                                                            } else {
                                                                                $gr9 = "";
                                                                            }
                                                                            ?>
                                                                        </span></td>
                                                                    <td valign="top"><span class="style19"> 
                                                                            <?php echo $gr9; ?>
                                                                        </span></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                    <tr>
                                                        <td height="14" valign="top"><strong>2(B)</strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td height="14" valign="top"><table width="549" border="1">
                                                                <tr>
                                                                    <td width="164" rowspan="2"><span class="style19">Work Education</span></td>
                                                                    <td width="321" height="23"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                                                                    <td width="42"><span class="style19"><strong>Grade</strong></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="22"><span class="style19">
                                                                            <?php
                                                                            $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Work Education'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                            $oDb = DBConnection::get();
                                                                            $saw = $oDb->query($saw);
                                                                            while ($rowu = $saw->fetch()) {

                                                                                $gr10 = "";
                                                                                $marks10 = $rowu['marks'];
                                                                                $title = $rowu['title'];
                                                                                $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                            } if (@$marks6) {
                                                                                if ($marks10 == '1') {
                                                                                    $gr10 = 'A';
                                                                                } else {
                                                                                    $gr10 = 'B';
                                                                                }
                                                                                $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr10' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                $oDb = DBConnection::get();
                                                                                $marks_Desc = $oDb->query($marks_Desc);
                                                                                while ($rowu = $marks_Desc->fetch()) {
                                                                                    echo $rowu['description'];
                                                                                }
                                                                            }
                                                                            if (@$gr10) {
                                                                                
                                                                            } else {
                                                                                $gr10 = "";
                                                                            }
                                                                            ?> </span></td>
                                                                    <td><span class="style19">
                                                                            <?php echo $gr10; ?> </span></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                            <td>&nbsp;&nbsp;&nbsp;</td>
                                            <td>
                                                <table width="587" border="0" align="center" cellpadding="2" cellspacing="2">
                                                    <tr>
                                                        <td width="575" height="670"><table width="575" height="666" align="center" bordercolor="#2A3F00">

                                                                <tr align="left" valign="top">
                                                                    <td height="660" valign="top" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><table width="556" border="0" >
                                                                            <tr>
                                                                                <td width="541" align="right" valign="top" class="st4"><span class="style19"><strong>Student Id :<?= $student['student_id']; ?>  Overall Grade  :
                                                                                            <?php
                                                                                            $qry = Exam::exam_overall_grade_calculater($MSID, $student['student_id']);
                                                                                            while ($rowu = $qry->fetch()) {
                                                                                                echo $rowu['grade'];
                                                                                            }
                                                                                            ?>
                                                                                        </strong></span></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="center"><span class="style19"><strong>Term 2</strong></span></td>
                                                                            </tr>
                                                                        </table>
                                                                        <table width="556" border="1">
                                                                            <tr>
                                                                                <td width="95" align="left"><span class="style19"><strong class="st4">Subjects</strong></span></td>
                                                                                <?php
                                                                                $sql_assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), '', '', '', 'Term 2', 'YES');
                                                                                while ($rowv = $sql_assesments->fetch()) {
                                                                                    ?>
                                                                                    <td width="38" align="center" class="st4"><strong class="st4"><?= $rowv['title'] ?>
                                                                                        </strong></td><?php } ?>
                                                                                <td width="56" align="center"><span class="style19"><strong class="st4">term|GR</strong></span></td>
                                                                                <td width="63" align="center"><span class="style19"><strong class="st4">OA Gr</strong></span></td>

                                                                                <td width="99" align="center"><span class="style19"><strong class="st4">Grade point</strong></span></td>

                                                                            </tr>
                                                                            <?php
                                                                            $subjects_querry = Exam::get_accademinc_performance($MSID, '', '', '', '', $student['student_id'], $_SESSION['year'], array('selectAll' => 'true'), 'YES');
                                                                            while ($rowv = $subjects_querry->fetch()) {
                                                                                ?><tr>  <?php
                                                                                    $subjects = SuperAdmin::get_schoolwise_subject($MSID, $rowv['subject_id'], array('selectAll' => 'true'), '', '', 'YES', '');
                                                                                    while ($rowu = $subjects->fetch()) {
                                                                                        ?><td><?= $rowu['name'] ?></td>
                                                                                        <?php
                                                                                    }
                                                                                    ?><td width="22" align="center">
                                                                                        <?php
                                                                                        $fa3 = Exam::exam_grade_calculater($MSID, $student['student_id'], '3', $rowv['subject_id'], 'YES');
                                                                                        while ($rowu = $fa3->fetch(PDO::FETCH_ASSOC)) {
                                                                                            ?><?= $rowu['Grade'] ?>
                                                                                            <?php
                                                                                        }
                                                                                        ?></td>

                                                                                    <td width="38" align="center">
                                                                                        <?php
                                                                                        $fa4 = Exam::exam_grade_calculater($MSID, $student['student_id'], '4', $rowv['subject_id'], 'YES');
                                                                                        while ($rowu = $fa4->fetch()) {
                                                                                            ?><?= $rowu['Grade'] ?>
                                                                                            <?php
                                                                                        }
                                                                                        ?>
                                                                                    </td>
                                                                                    <td width="56" align="center">    <?php
                                                                                        $sa2 = Exam::exam_grade_calculater($MSID, $student['student_id'], '1', $rowv['subject_id'], 'YES');
                                                                                        while ($rowu = $sa2->fetch()) {
                                                                                            ?><?= $rowu['Grade'] ?>
                                                                                            <?php
                                                                                        }
                                                                                        ?></td>


                                                                                    <td width="63" align="center">
                                                                                        <?php
                                                                                        $overall = Exam::exam_term_grade_calculater($MSID, $student['student_id'], '2', $rowv['subject_id']);
                                                                                        while ($rowu = $overall->fetch()) {
                                                                                            ?><?= $rowu['grade'] ?>
                                                                                        <?php } ?></td>
                                                                                    <td width="99" align="center">
                                                                                        <?php
                                                                                        $oa = Exam::exam_Subjectwise_overallgrade_calculater($MSID, $student['student_id'], $rowv['subject_id']);
                                                                                        while ($rowu = $oa->fetch()) {
                                                                                            ?><?= $rowu['grade'] ?>
                                                                                        <?php } ?></td>
                                                                                    <td width="64" align="center">
                                                                                        <?php
                                                                                        $grade_points = Exam::exam_grade_point($MSID, $student['student_id'], $rowv['subject_id']);

                                                                                        while ($rowu = $grade_points->fetch()) {
                                                                                            ?><?= $rowu['grade_point'] ?>
                                                                                        <?php } ?></td>



                                                                                </tr>  
                                                                            <?php } ?>
                                                                            <tr>
                                                                                <td colspan="5" class="r"><strong>Grading Scale:</strong>A1=91%-100%;A2=81%-90%;B1=71%-80%;B2=61%-70%;C1=51%-60%;C2=41%-%50%;D=33%-40%;E1=21%-32%;E2=20% AND BELOW</td>
                                                                                <td width="64" align="center"><span class="style19"><strong>CGPA</strong></span></td>
                                                                                <td width="95" align="center"><span class="style19"><strong>

                                                                                            <?php
                                                                                            $grade_points = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade ,G.grade_point FROM (Select RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,W.term,round(Sum(RD.`marks_obtained`)/SUM(W.overall_wtg)*100,2) point from ms_exam_weightage W inner JOIN `ms_exam_acedemic_performance` RD ON W.assesment_id=RD.assesment_id AND W.overall_wtg=RD.max_marks WHERE  RD.MSID='$MSID' AND  W.MSID='$MSID' AND `session`='" . $_SESSION['year'] . "' AND student_id='" . $student['student_id'] . "'     GROUP BY RD.student_id,RD.subject_id ) Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN G.`percent_from` AND G.`percent_to`";
//                                                                                    print_r($grade_points); 
                                                                                            $oDb = DBConnection::get();
                                                                                            $grade_points = $oDb->query($grade_points);
                                                                                            while ($rowu = $grade_points->fetch()) {
                                                                                                ?><?= $rowu['grade_point'] ?>
                                                                                            <?php } ?> </strong></span></td>
                                                                            </tr>

                                                                        </table>
                                                                        <table width="556" border="0">
                                                                            <tr>
                                                                                <td><strong class="style19">                    2(C)</strong></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td><table width="549" border="1">
                                                                                        <tr>
                                                                                            <td width="168" rowspan="2"><span class="style19">Visual and Performing Arts</span></td>
                                                                                            <td width="317" height="26"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                                                                                            <td width="42"><span class="style19"><strong>Grade</strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="22"><span class="style19">
                                                                                                    <?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Visual and Performing Arts'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr11 = "";
                                                                                                        $marks11 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks11) {
                                                                                                        if ($marks11 == '1') {
                                                                                                            $gr11 = 'A';
                                                                                                        } else {
                                                                                                            $gr11 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr11' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr11) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr11 = "";
                                                                                                    }
                                                                                                    ?></span></td>
                                                                                            <td><span class="style19">
                                                                                                    <?php echo $gr11; ?> 
                                                                                                </span></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td><strong class="style19">                    2(D)Attitudes and Values</strong></td>
                                                                            </tr>
                                                                        </table>
                                                                        <table width="550" border="0">
                                                                            <tr>
                                                                                <td width="564" height="13" valign="top"><table width="549" border="1">

                                                                                        <tr>
                                                                                            <td height="21" valign="top"><span class="style19"><strong>Attitude Towards </strong></span></td>
                                                                                            <td valign="top"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                                                                                            <td valign="top"><span class="style19"><strong>Grade</strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="160" height="9" valign="top"><span class="style19">Teachers</span></td>
                                                                                            <td width="325" valign="top"><span class="style19">
                                                                                                    <?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Teachers'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr12 = "";
                                                                                                        $marks12 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks12) {
                                                                                                        if ($marks12 == '1') {
                                                                                                            $gr12 = 'A';
                                                                                                        } else {
                                                                                                            $gr12 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr12' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr12) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr12 = "";
                                                                                                    }
                                                                                                    ?></span></td>
                                                                                            <td width="42" valign="top"> <span class="style19">
                                                                                                    <?php echo $gr12; ?>
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="10" valign="top"><span class="style19">School Mates</span></td>
                                                                                            <td valign="top"><span class="style19">
                                                                                                    <?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='School Mates'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr13 = "";
                                                                                                        $marks13 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks13) {
                                                                                                        if ($marks13 == '1') {
                                                                                                            $gr13 = 'A';
                                                                                                        } else {
                                                                                                            $gr13 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr13' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr13) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr13 = "";
                                                                                                    }
                                                                                                    ?> </span></td>
                                                                                            <td valign="top"> <span class="style19">
                                                                                                    <?php echo $gr13; ?>
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="10" valign="top"><span class="style19">School Programmes and Environment</span></td>
                                                                                            <td valign="top"><span class="style19">
                                                                                                    <?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='School Programmes and Environment'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr14 = "";
                                                                                                        $marks14 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks14) {
                                                                                                        if ($marks14 == '1') {
                                                                                                            $gr14 = 'A';
                                                                                                        } else {
                                                                                                            $gr14 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr14' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr14) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr14 = "";
                                                                                                    }
                                                                                                    ?>  </span></td>
                                                                                            <td valign="top"> <span class="style19">
                                                                                                    <?php echo $gr14; ?>  
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td height="10" valign="top"><span class="style19">Value Systems</span></td>
                                                                                            <td valign="top"> <span class="style19">
                                                                                                    <?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Value Systems'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr15 = "";
                                                                                                        $marks15 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks15) {
                                                                                                        if ($marks15 == '1') {
                                                                                                            $gr15 = 'A';
                                                                                                        } else {
                                                                                                            $gr15 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr15' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr15) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr15 = "";
                                                                                                    }
                                                                                                    ?>    </span></td>
                                                                                            <td valign="top"><span class="style19">
                                                                                                    <?php echo $gr15; ?>  
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <?php ?>
                                                                                    </table></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="14" valign="top"><span class="style19"><strong>                  3(A):CO-curricular activities</strong></span><strong><br />
                                                                                    </strong></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="14" valign="top"><table width="549" border="1">
                                                                                        <tr>
                                                                                            <td width="168"><span class="style19"><strong>Activity</strong></span></td>
                                                                                            <td width="317" height="23"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                                                                                            <td width="42"><span class="style19"><strong>Grade</strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="style19">Literary and Creative Skills</span></td>
                                                                                            <td> <span class="style19">
                                                                                                    <?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Literary and Creative Skills'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr16 = "";
                                                                                                        $marks16 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks16) {
                                                                                                        if ($marks16 == '1') {
                                                                                                            $gr16 = 'A';
                                                                                                        } else {
                                                                                                            $gr16 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr16' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr16) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr16 = "";
                                                                                                    }
                                                                                                    ?>   </span></td>
                                                                                            <td><span class="style19">
                                                                                                    <?php echo $gr16; ?> 
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="168"><span class="style19">Scientific Skills</span></td>
                                                                                            <td><span class="style19"><?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Scientific Skills'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr17 = "";
                                                                                                        $marks17 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks17) {
                                                                                                        if ($marks17 == '1') {
                                                                                                            $gr17 = 'A';
                                                                                                        } else {
                                                                                                            $gr17 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr17' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr17) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr17 = "";
                                                                                                    }
                                                                                                    ?></span></td>
                                                                                            <td><span class="style19">
                                                                                                    <?php echo $gr17; ?> 
                                                                                                </span></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="14" valign="top"><strong class="style19">                  3(B)</strong></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="14" valign="top"><table width="549" border="1">
                                                                                        <tr>
                                                                                            <td width="168"><span class="style19"><strong>Activity</strong></span></td>
                                                                                            <td width="317" height="23"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                                                                                            <td width="42"><span class="style19"><strong>Grade</strong></span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="style19">Sports/Indigenous Sports</span></td>
                                                                                            <td><span class="style19"><?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Sports/Indigenous Sports'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr18 = "";
                                                                                                        $marks18 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks18) {
                                                                                                        if ($marks18 == '1') {
                                                                                                            $gr18 = 'A';
                                                                                                        } else {
                                                                                                            $gr18 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr18' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr18) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr18 = "";
                                                                                                    }
                                                                                                    ?></span></td>
                                                                                            <td><span class="style19">
                                                                                                    <?php echo $gr18; ?>
                                                                                                </span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="168"><span class="style19">Yoga</span></td>
                                                                                            <td><span class="style19">
                                                                                                    <?php
                                                                                                    $saw = "SELECT ccsm.*,GI.* FROM `ms_exam_co_scholastic_marks` ccsm INNER JOIN ms_exam_co_scholastic_indicators GI ON ccsm.co_scholastic_id=GI.co_scholastic_id where ccsm.`s_id`='" . $student['student_id'] . "' And ccsm.`session`='" . $_SESSION['year'] . "'  And GI.title='Yoga'  And ccsm.MSID='$MSID' And GI.MSID='$MSID'";
//                                                                                                    print_r($saw);
                                                                                                    $oDb = DBConnection::get();
                                                                                                    $saw = $oDb->query($saw);
                                                                                                    while ($rowu = $saw->fetch()) {

                                                                                                        $gr19 = "";
                                                                                                        $marks19 = $rowu['marks'];
                                                                                                        $title = $rowu['title'];
                                                                                                        $co_scholastic_id = $rowu['co_scholastic_id'];
                                                                                                    }
                                                                                                    if (@$marks19) {
                                                                                                        if ($marks19 == '1') {
                                                                                                            $gr19 = 'A';
                                                                                                        } else {
                                                                                                            $gr19 = 'B';
                                                                                                        }
                                                                                                        $marks_Desc = "SELECT * FROM `ms_exam_co_scholastic_indicators` Where grade='$gr19' And  co_scholastic_id='$co_scholastic_id' And  MSID='$MSID'";
                                                                                                        $oDb = DBConnection::get();
                                                                                                        $marks_Desc = $oDb->query($marks_Desc);
                                                                                                        while ($rowu = $marks_Desc->fetch()) {
                                                                                                            echo $rowu['description'];
                                                                                                        }
                                                                                                    }
                                                                                                    if (@$gr19) {
                                                                                                        
                                                                                                    } else {
                                                                                                        $gr19 = "";
                                                                                                    }
                                                                                                    ?> </span></td>
                                                                                            <td><span class="style19">
                                                                                                    <?php echo $gr19; ?>   </span></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>       





                    </div>
                </div>
                <!-- /.box --><?php
            } else {
                ?>

                <div class = "box">
                    <div class = "box-header">

                        <div class = "row">
                            <div class = "col-md-3"> <h3 class = "box-title"> Remarks List</h3>
                            </div>
                            <div class = "col-md-9">
                                <form class = "form-inline " method = "post" id = "remarks_form_id">
                                    <input type = "hidden" name = "remarks_form" value = "xxx" />
                                    <label for = "exampleInputName2">Select Class : </label>
                                    <select id = "class_id" name = "class_id" class = "form-control wth_div" onchange
                                            = 'this.form.submit()' >
                                                <?php
                                                $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                                ?>
                                        <b> Select Class : - </b>
                                        <?php
                                        foreach ($classs as $class) {
                                            if ($_SESSION['class_id'] == $class['class_no']) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                <?= $class['class_name']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>

                                </form>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>

        </div>
    </div>
</section>
