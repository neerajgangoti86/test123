<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session1= $kr['MySession'];
$Begins1= $kr['Begins'];     
$Ends1= $kr['Ends'];        
$ULevel= $kr['ULevel']; } $cw=mysql_query($cl="select * from `2Sessions` where '$dm' Between `Begins` And `Ends` And  `MSID`='$msid'"); while($cr=mysql_fetch_array($cw)){ 
    $session= $cr['ID']; $Begins= $cr['Begins']; $Ends= $cr['Ends'];   } 
 $c1=$_GET['cno'];   $cno = mysql_real_escape_string($c1);$sid1=$_GET['id'];$sid = mysql_real_escape_string($sid1);
	
	?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffiliationNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['Reconiation_no'];
$EMail= $row['EMail']; 
} ?>::Class Wise Fee Report</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<style type="text/css">@import "../__jquery.tablesorter/tests/assets/css/default.css";
 
	
	.tablesimple{border:1px solid #B2B2B2; border-radius:10px 10px 10px 10px; margin-top:-1px;}
	

    .simplefont{color:#333; font-family:Verdana, Geneva, sans-serif; font-size:12px; text-transform:capitalize; padding:2px;}
.simplebold{color:#000; font-family:Verdana, Geneva, sans-serif; font-size:12px; text-transform:capitalize; padding:2px; font-weight:bold}
.tablesorter{border:1px solid #B2B2B2; border-radius:10px 10px 10px 10px; margin-top:-17px;}

.tablesorter td{ height:25px; color:#333; font-family:Verdana, Geneva, sans-serif; font-size:12px; border:1px solid #B2B2B2; text-transform:capitalize; padding:2px;}
.tablesorter th{ height:35px; border:1px solid #B2B2B2; text-transform:capitalize; }

    </style>
	 <!--Calendar Script starts-->
   <link rel="stylesheet" type="text/css" media="all" href="../../jscripts4cal/jsDatePick_ltr.min.css"/>
  <script type="text/javascript" src="../../jscripts4cal/jsDatePick.min.1.3.js" ></script>
    <script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"inputField",
			dateFormat:"%d-%m-%Y"

		});
		 
	};
	
</script>
  <!--ends calendar script-->
	<script type="text/javascript" src="../__jquery.tablesorter/jquery-latest.js" ></script>
	<script type="text/javascript" src="../__jquery.tablesorter/jquery.tablesorter.js"></script>
	<script type="text/javascript">
	
	$(function() {
		$("table").tablesorter({debug: true, headers: {
			9: {
				lockedOrder: 1
			}
		}});
		$("a.append").click(appendData);
		
		
	});
	
	var lastStudent = <? echo $id;?>;
	var limit = <? echo $id;?>;
	
	function appendData() {
		
		var tdTagStart = '<td>';
		var tdTagEnd = '</td>';
		var sex = ['y','u'];
		var major = ['Mathematics','Languages'];
		
		
		for(var i = 0; i < limit; i++) { 
			var rnd = i % 2;
			var row = '<tr>';	
			row += tdTagStart + 'student' + (lastStudent++) + tdTagEnd;
			row += tdTagStart + major[rnd] + tdTagEnd;
			row += tdTagStart + sex[rnd] + tdTagEnd;
			
			row += tdTagStart +  randomNumber() + tdTagEnd;
			row += tdTagStart +  randomNumber() + tdTagEnd;
			row += tdTagStart +  randomNumber() + tdTagEnd;
			row += tdTagStart +  randomNumber() + tdTagEnd;
			
			row += '</tr>';
			
			$("table/tbody:first").append(row);
			
		};
		
		
		$("table").trigger('update');
		return false;
	}
	
	function randomNumber() {
		return Math.floor(Math.random()*101)
	}
	
	</script>
</head>
 
<body>

<table width="812" Class="tablesimple" align="center"  >
<!--<table width="57%" background="../../images/reportlogo.png" Class="tablesimple" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">-->
      <tr>
        <td width="100%" height="180"><table width="100%" height="146" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="799" height="140">
          
            <table width="100%" align="center" cellpadding="2" cellspacing="2">
              <tr>
      <td height="22" colspan="3" align="center"><span class="m1"><?php echo $sname;?></span></td>
              </tr>
            <tr>
              <td width="13%" align="center" valign="top"><img class="logo" src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="70" height="70"></td>
              <td width="56%" align="center" valign="top"><table width="98%" height="77" border="0" align="center">
                <tr>
                  <td width="376" height="40" align="center" ><span class="b1"><?php echo $Place; ?></span></td>
                </tr>
                <tr>
                  <td height="20" align="center" class="b1"><span class="t1"><?php echo $Board; ?></span></td>
                </tr>
              
              </table><br /><? if($_POST) {  $cd=$_POST['inputField'];  $dm = date('Y-m-d', strtotime($cd));}else {$dm;}?>
                <form id="form1" name="form1" method="post" action="">
                  <span class="st4">Change Date:
                  </span>
                 <!-- <input type="text" name="cdate" id="cdate" />-->
                  <input name="inputField" type="text" id="inputField" value="<?php echo $new_date = date('d-m-Y', strtotime($dm)); ?>" size="8"  />  <input type="submit" name="button" id="button" value="Submit" />
              </form>
                <u><br />
            <span class="b1" align="Center">Weekly Test Record Sheet for <br />
            Date:
<?   $dm;?> <?php  $ghiy1=mysql_query($ghy1="SELECT DATE_ADD('$dm', INTERVAL(2-DAYOFWEEK('$dm')) DAY) weekstrts,DATE_ADD('$dm', INTERVAL(7-DAYOFWEEK('$dm')) DAY) weekends");
			 while($gowy1=mysql_fetch_array($ghiy1)){  $weekstrts1=$gowy1['weekstrts'];echo $weekstrts = date('d-m-Y', strtotime($weekstrts1));?> to <?php   $weekends1=$gowy1['weekends'];echo $weekends = date('d-m-Y', strtotime($weekends1));}?><br />
              <br />
              </span></u> </td>
              <td width="31%" align="right" valign="top"><table width="98%" align="right">
                <tr>
                  <td align="center"><img src="../student_detail/reports/phone.jpg" width="25" height="23" /></td>
                  <td align="right" class="r"><strong><?php echo $Phone; ?></strong></td>
                </tr>
                 <tr>
              <td width="104" class="r">Affiliation No.:</td>
              <td width="106" align="right" class="r"><strong><?php echo $AffiliationNo; ?></strong></td>
            </tr>
            <tr>
              <td class="r"> School Code :</td>
              <td align="right"><span class="r"><strong><?php echo $SchoolNo; ?></strong></span></td>
            </tr>
            <tr>
              <td><span class="r">Recognition No.:</span></td>
              <td align="right"><strong class="r"><?php echo $Reconiation_no; ?></strong></td>
            </tr>
              </table></td>
          </tr>
         
          <tr>
      <td height="22" colspan="3" align="center"><br />
        <table width="778" height="139" class="tablesorter" border="0" align="center">
      <!--  <tr>
          <td height="77" colspan="11" align="center" class="style15"><u><br />
            <span class="b1">Fee Accounts for Class :<?php //echo $c;?><br />
              <br />
              </span></u></td>
        </tr> --> 
    <thead>   
      <tr align="center"  class="simplebold" valign="top">
        <th height="2" colspan="3" align="left" >Days</th>
         <?  $ghiys=mysql_query($ghys="SELECT distinct SubjectId from 21weeklytest Where MSID='$msid' and  Date Between '$weekstrts1' And '$weekends1' and Class='$cno' and StudentId='$sid'"); 
			 while($gowys=mysql_fetch_array($ghiys)){  $SubjectId=$gowys['SubjectId']; ?>
        <th align="center"><strong><?  $ghiysd=mysql_query($ghysd="SELECT distinct Date from 21weeklytest Where MSID='$msid' and SubjectId='$SubjectId' and Class='$cno' and  Date Between '$weekstrts1' And '$weekends1'  ");
			 while($gowysd=mysql_fetch_array($ghiysd)){ $Date=$gowysd['Date'];  $ghiysdd=mysql_query($ghysdd="SELECT WEEKDAY('$Date') as dayofweek ");
			 while($gowysdd=mysql_fetch_array($ghiysdd)){ $dayofweek=$gowysdd['dayofweek']; $weekday=$dayofweek+1; 
			  $ghiysddw=mysql_query($ghysddw="SELECT * From 6weekdays where `WDayId`='$weekday' and MSID='$msid' ");
			 while($gowysddw=mysql_fetch_array($ghiysddw)){ echo $Day=$gowysddw['Day']; } }}?></strong></th>
        
        <? } ?>
      </tr>
      <tr align="center"  class="simplebold" valign="top">
        <th height="4" colspan="3" align="left" >Subject</th>
           <?  $ghiys=mysql_query($ghys="SELECT distinct SubjectId from 21weeklytest Where MSID='$msid' and  Date Between '$weekstrts1' And '$weekends1' and Class='$cno' and StudentId='$sid'"); $nr=mysql_num_rows($ghiys);
			 while($gowys=mysql_fetch_array($ghiys)){  $SubjectId=$gowys['SubjectId']; ?>
        <th align="center"><strong><? $SubjectId; $ghiy1sub=mysql_query($ghy1sub="SELECT * from subjects Where MSID='$msid' and ID='$SubjectId'");
			 while($gowy1sub=mysql_fetch_array($ghiy1sub)){echo $Subject12=$gowy1sub['Subject']; }?> </strong></th><? } ?>
      </tr>
      <tr align="center"  class="simplebold" valign="top">
        <th width="47" align="left" >Sr. No.</th>
        <th width="36" height="39" align="left" >Id</th>
        <th width="219" align="left">Name</th>
          <? for($i = 0; $i <$nr; $i++){ if ($c<='10'){?>
          
        <th width="67" align="center">Marks </th>
		<? }else{ ?>
        <th width="62" align="center">Grade</th>
      <? } }?>
        </tr>
      </thead>
      <tbody>   <?   $resultyu=mysql_query($squyl="SELECT (S.Id) as sid,S.*,P.*,L.Village,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$dm' AND S.SLDate>'$dm' and S.Id='$sid' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0)");
  while($rowyu=mysql_fetch_array($resultyu)){  $Id= $rowyu['Id'];  $CClass= $rowyu['CClass']; ?>
        <tr align="center" valign="top">
          <td align="left" ><?php $j=1;echo $g=$j+$g;?></td>
          <td height="39" align="left" ><? echo  $sid= $rowyu['sid'];?></td>
          <td align="left"><? echo $rowyu['Name'];?></td>
          <?  $ghiys2=mysql_query($ghys2="SELECT distinct SubjectId from 21weeklytest Where MSID='$msid' and  Date Between '$weekstrts1' And '$weekends1' and Class='$cno' and StudentId='$sid'");
			 while($gowys2=mysql_fetch_array($ghiys2)){  $SubjectId=$gowys2['SubjectId'];   ?>  
            <? if($c<='10') {?> 
             <td align="center"><?php 
$ghiy2=mysql_query($ghy2="SELECT DATE_ADD('$dm', INTERVAL(2-DAYOFWEEK('$dm')) DAY) weekstrts,DATE_ADD('$dm', INTERVAL(7-DAYOFWEEK('$dm')) DAY) weekends"); while($gowy2=mysql_fetch_array($ghiy2)){ $weekstrts2=$gowy2['weekstrts']; $weekends2=$gowy2['weekends'];
 
$phi2=mysql_query($ph2="SELECT * FROM `21weeklytest` Where Date Between '$weekstrts2' And '$weekends2' And StudentId='$sid'  And SubjectId='$SubjectId'"); while($pow2=mysql_fetch_array($phi2)){  echo $MarksObtained2= $pow2['MarksObtained'];}} ?></td>
<? } else {?>


          <td align="center"><?php    $resl2=mysql_query($slq2="SELECT RD.MSID,RD.`StudentId`,RD.`Date`,RD.`SubjectId`,ROUND(MarksObtained/10*100,2) Percent,G.`Grade` FROM `21weeklytest` RD INNER Join 23Grades G ON (MarksObtained/10*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session'  AND RD.Date Between '$weekstrts2' And '$weekends2'   AND  RD.`StudentId`='$sid'  AND  RD.`SubjectId`='$SubjectId'  And '$cno' Between G.`ClassFrom` And G.`ClassTo`   ");while( $tr2 = mysql_fetch_array($resl2)){  echo $Grade2=$tr2['Grade'];}?></td><? } } ?>
         
          </tr>
        <? }?>	</tbody>
        <tr align="center" valign="top">
          <td colspan="12" align="left" class="st4">&nbsp;</td>
        </tr>
      </table></td>
              </tr>
    </table>
            
            
            
            
            
            
            
            </td>
          </tr>
          
        </table></td>
      </tr>
    </table>
 
 
</body>
</html>
<? }?>