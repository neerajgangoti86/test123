<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){$s_id= $gow5['sid'];?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$TermDate= $row['TermDate']; //$s_id1=$_GET['id'];$s_id = mysql_real_escape_string($s_id1);
} ?>::Report Card</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<style type="text/css">
.style2 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; 
}
</style>
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
</head>
 
<body><style>
p.page { page-break-after: always; }
</style><table width="200" border="1" align="center">
  <tr>
    <td><table width="200" border="0">
      <tr valign="top">
        <td height="710" align="center" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><span class="style2">Self Awarness </span><br />
          <br />
          <br />
<br />
          <table width="550" border="1">
            <tr>
              <td width="540" height="147" valign="top"><span class="style19"><strong>My Goals: </strong></span><strong><br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
                <br />
              </strong></td>
            </tr>
          </table>
          <br />
          <table width="550" border="1">
            <tr align="left" valign="top">
              <td width="616" height="118"><span class="style19"><strong>Strengths:</strong></span><strong><br />
                <br />
                <br />
                <br />
                <br />
                <br />
              </strong></td>
            </tr>
          </table>
          <br />
          <br />
          <table width="550" height="116" border="1">
            <tr valign="top">
              <td width="403" height="110" align="left"><strong class="style19">My Interests and Hobbies: </strong><br />
                
                <br />
                <br /></td>
            </tr>
          </table>
          <br />
          <table width="550" height="104" border="1">
            <tr>
              <td width="614" height="98" align="left" valign="top"><p><strong class="style19">Responsibilities Discharged/Exceptional Achievements: </strong><br />
                <br />
                <br />
                <span class="style19"><strong><br />
                </strong>Result:<strong>Qualified,Congratulations<br />
                </strong>Promoted to Class: <strong><?   $clplus= $cno+1; $resulty=mysql_query($sqly="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$clplus' And MSID='$msid' order by ClassNo ASC ");
	  while($rowy=mysql_fetch_array($resulty)){  echo $rowy['ClassName']; }?></strong></span><br />
              </p></td>
            </tr>
          </table></td>
        <td>&nbsp;&nbsp;&nbsp;</td>
        <td><table width="587" border="0" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="575"><table width="575" height="696" align="center" bordercolor="#2A3F00" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat">
          <tr align="left" valign="top">
            <td width="567" height="76"><table width="535">
              <tr>
                <td colspan="3" align="center"><span class="m1">
                  <?php  echo $sname;?>
                </span></td>
              </tr>
              <tr>
                <td width="78" align="left"><table width="69" border="0" align="center">
                  <tr>
                    <td width="63"><img class="logo" src="../<?php  if($limg!=""){echo $limg;} else { 	echo "../../Uplaod/aboutlogo.jpg";} ?>"  width="90" height="100"></td>
                  </tr>
                </table></td>
                <td width="245" valign="top"><table width="232" border="0" align="center">
                  <tr>
                    <td width="226" align="center" ><span class="b1">
                      <?php  echo $Place; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="b1"><span class="t1">
                      <?php  echo $Board; ?>
                    </span></td>
                  </tr>
                  <tr>
                    <td align="center" class="t1">&nbsp;</td>
                  </tr>
                </table></td>
                <td width="200" align="right" valign="top"><table width="200" border="0" align="right">
                  <tr>
                    <td align="center"><img  src="../newstudentdetail/reports/phone.jpg"  width="25" height="25" /></td>
                    <td align="right" class="r"><strong>
                      <?php  echo $Phone; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td width="144" class="r">Affiliation No.:</td>
                    <td width="46" align="right" class="r"><strong>
                      <?php  echo $AffiliationNo; ?>
                    </strong></td>
                  </tr>
                  <tr>
                    <td class="r"> School Code :</td>
                    <td align="right"><span class="r"><strong>
                      <?php  echo $SchoolNo; ?>
                    </strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="r">Recognition No.:</span></td>
                    <td align="right"><strong class="r">
                      <?php  echo $Reconiation_no; ?>
                    </strong></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr align="left" valign="top">
            <td height="22"><hr/></td>
          </tr><?php   
 $result=mysql_query($sql="SELECT (S.Id)as sid,S.*,P.*,L.Village, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.Id='$s_id' And P.MSID='$msid'"  );while($gow=mysql_fetch_array($result)){$sid=$gow['sid'];$ClassName=$gow['ClassName'];$name=$gow['Name'];$mn=$gow['MotherName'];
$fn=$row['FatherName']; 
  ?>
          <tr align="left" valign="top">
            <td height="539" valign="top"><table width="553" height="185" border="1" align="center">
              <tr valign="top">
                  <td width="521" height="179" colspan="2"><table width="553" border="0">
                    <tr>
                      <td height="27" colspan="6"><span class="b1"><?php echo $gow['Name'];?></span></td>
                      </tr>
                    <tr>
                      <td height="27" colspan="6" class="st4">Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><?php echo $sid;?></strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Class/House:&nbsp;
                        <strong>
                        <?  $cl= $gow['CClass'];$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$cl' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){  echo $row2['ClassName']; }  if($nos>'0'){  $Section= $gow['Section']; $d1=mysql_query($sql1="select * from `4Sections` where `MSID`='$msid'  And `ID`='$Section'   ORDER BY `ID` ASC  "); while($row12=mysql_fetch_array($d1)){  echo $Sectionname12= $row12['Sectionname'];}}else {} if($noh>'0'){?>  
                        <?php  $house=$gow['House'];  $d=mysql_query($sql="select * from `3Houses` where `MSID`='$msid' And `Id`='$house'  ORDER BY `ID` ASC "); while($row1=mysql_fetch_array($d)){echo $h= $row1['HouseFName'] ;}?>            
                        <?php }else {} ?>
                        </strong>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<span class="style19">Birth Date: </span>&nbsp;&nbsp;&nbsp;                      <span class="style19">
                        <strong>
                        <?php   $dob=$gow['BirthDate'];echo $new_date = date('d-m-Y', strtotime($dob));?>
                        </strong>                        </span></td>
                    </tr>
                   
                    <tr>
                      <td width="161" height="26"><span class="style19">Father's Name: </span></td>
                      <td colspan="4"><span class="style19"><strong><?php echo "Mr.".' '.$gow['FatherName'];?></strong></span></td>
                      <td width="7">&nbsp;</td>
                    </tr>
                    <tr>
                      <td height="24"><span class="style19">Mother's Name: </span></td>
                      <td colspan="5"><span class="style19"><strong><?php echo "Mrs.".' '.$gow['MotherName'];?></strong></span></td>
                    </tr>
                    <tr>
                      <td height="26" colspan="6"><span class="style19">Village/Town:<strong><?php echo $gow['Village'];?></strong><span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>District: <strong>
                      <?php   echo $gow['District'];?>
                      </strong> <span class="st4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="st4">&nbsp;Phones:<strong><?php echo $gow['F_Mobile'];?></strong></span></span></td>
                      </tr>
                   
                      <td height="32" valign="bottom"><span class="style19">Total Working Days:</span></td>
                      <td width="217" align="center"><span class="style19"><strong  > 
            <?php 
 $result7=mysql_query($sql7="SELECT * from `26TWDays` where  SID='$sid' and Session='$session' AND  MSID='$msid'  Limit 1");
	  while($row7=mysql_fetch_array($result7)){  echo $row7['TWD'];   $TWP= $row7['TWP'];}  
					  
			?> 
                        </strong></span></td>
                      <td width="20" align="center">&nbsp;</td>
                      <td width="119" align="center"><span class="style19"><strong  > </strong></span></td>
                      <td colspan="2" align="center">&nbsp;</td>
                    </tr>
                    <tr>
                      <td height="21"><span class="style19">Total Attendance:</span></td>
                      <td align="center"><span class="style19">  
                  <?php   echo $TWP; ?>
                      </span></td>
                      <td height="21" align="center">&nbsp;</td>
                      <td align="center"><span class="style19"> </span></td>
                      <td colspan="2" align="center">&nbsp;</td>
                    </tr>
                    <?php  //}?>
                  </table></td>
                </tr>
          </table>
<br />
<table width="571" height="95" border="1" align="center">
  <tr valign="top">
                  <td width="561" height="89" colspan="2"><table width="561" border="0">
                    <tr valign="top">
                        <?php  $hgi=mysql_query($hg="Select * from 21Repodata4healthsts Where StudentId='$s_id' And Session='$session' and MSID='$msid'"); while($hgw=mysql_fetch_array($hgi)){
 $Height= $hgw['Height']; 
 $Weight= $hgw['Weight'];
 $VisionL= $hgw['VisionL']; 
 $VisionR= $hgw['VisionR'];
 $DentalHygiene= $hgw['DentalHygiene'];
 $Ear_l= $hgw['Ear_l'];
 $Ear_r= $hgw['Ear_r'];
 $Pulse= $hgw['Pulse'];
 $Throat= $hgw['Throat'];
 $Heart= $hgw['Heart'];
 $Nose= $hgw['Nose']; 
 $Alergy= $hgw['Alergy'];
 $ChronicD= $hgw['Chronic Diease'];
 $Typhoid= $hgw['Typhoid'];
 $Any = $hgw['Any Other'];
 $Phy_Act= $hgw['Physical_Activity_problem'];
$BCG_V= $hgw['BCG_V'];
$Measles= $hgw['Measles'];
$HepaB = $hgw['Hepatitis B']; 
$DPT= $hgw['DPT'];
$HB= $hgw['HB'];
$Oralp = $hgw['Oral Polio'];
 $HepaA= $hgw['Hepatitis A'];
 $Chickenpox = $hgw['Chickenpox'];
 $DTOPA= $hgw['DT.OPA'];
 $MMR= $hgw['MMR'];
 $DPTOPVHB = $hgw['DPT+OPV+HB'];	?>
                        <td width="106" height="35" align="center" class="style19"><strong><?php echo $Height; ?></strong><br />
                          Height(cm) </td>
                        <td align="center" class="style19"><strong><?php echo $Weight; ?></strong><br />
                          Weight(kg)</td>
                        <br />
                        <td align="center" class="style19"><strong><?php echo $bgroup;?></strong><br />
                          Blood Group</td>
                        <td colspan="2" align="center" valign="top"><strong class="style19">Vaccination</strong></td>
                      </tr>
                      <tr>
                        <td height="31" align="center" class="style19"><strong><?php echo $VisionL; ?></strong><br />
                          Vision-L </td>
                        <td width="109" align="center" class="style19"><strong><?php echo $VisionR; ?></strong><br />
                          Vision-R</td>
                        <td width="87" align="center" class="style19"><strong><?php echo $Nose;?></strong><br />
                          Nose</td>
                        <td width="130" align="center" valign="top"><span class="style19">BCG</span><br />
                          <?php   $BCG_V;if($BCG_V=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                        <td width="107" align="center" valign="top"><span class="style19">Measles</span><br />
                          <?php   $Measles;if($Measles=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                      </tr>
                      <tr>
                        <td height="28" align="center" class="style19"><strong><?php echo $Ear_l;?></strong><br />
                          Ear-L </td>
                        <td align="center" class="style19"><strong><?php echo $Ear_r;?></strong><br />
                          Ear-R</td>
                        <td align="center" class="style19"  ><strong><?php echo $Throat;?></strong><br />
                          Throat</td>
                        <td align="center" valign="top"><span class="style19">Hepatitis B</span><br />
                          <?php   $HepaB;if($HepaB=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                        <td align="center" valign="top"><span class="style19">Hepatitis A</span><br />
                          <?php   $HepaA;if($HepaA=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                      </tr>
                      <tr>
                        <td height="31" align="center" class="style19"><strong><?php echo $Pulse;?></strong><br />
                          Pulse </td>
                        <td align="center" class="style19"><strong><?php echo $Heart;?></strong><br />
                          Heart</td>
                        <td>&nbsp;</td>
                        <td align="center" valign="top"><span class="style19">DPT</span><br />
                          <?php   $DPT;if($DPT=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                        <td align="center" valign="top"><span class="style19">Chickenpox</span><br />
                          <?php   $Chickenpox;if($Chickenpox=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                      </tr>
                      <tr>
                        <td height="15" align="center" class="style19"><strong><?php echo $DentalHygiene; ?></strong><br />
                          Dental Hygine </td>
                        <td align="center" class="style19"  ><strong><?php echo $Alergy;?></strong><br />
                          Allergy?</td>
                        <td>&nbsp;</td>
                        <td align="center" valign="top"><span class="style19">HB</span><br />
                          <?php   $HB;if($HB=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                        <td align="center" valign="top"><span class="style19">DT.OPA</span><br />
                          <?php   $DTOPA;if($DTOPA=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                      </tr>
                      <tr>
                        <td height="31" rowspan="2" align="center" class="style19"><strong><?php echo $ChronicD;?></strong><br />
                          Chronic Diseases</td>
                        <td rowspan="2" align="center" class="style19"  ><strong><?php echo $Phy_Act;?></strong><br />
                          Physical Activity</td>
                        <td rowspan="2" align="center" class="style19"><strong><?php echo $Any;?></strong><br />
                          <span class="style19"> Any Other ?</td>
                        <td align="center" valign="top"><span class="style19">Oral Polio</span><br />
                          <?php   $Oralp;if($Oralp=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                        <td align="center" valign="top"><span class="style19">MMR</span><br />
                          <?php   $MMR;if($MMR=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                      </tr>
                      <tr>
                        <td align="center" valign="top"><span class="style19">DPT+OPV+HB</span><br />
                          <?php   $DPTOPVHB;if($DPTOPVHB=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                        <td align="center" valign="top"><span class="style19">Typhoid</span><br />
                          <?php   $Typhoid;if($Typhoid=='Yes'){ ?>
                          <img src="../newstudentdetail/reports/right-mark.png"  />
                          <?php }else {?>
                          <img src="../newstudentdetail/reports/red_cross_icon.gif" />
                          <?php }?></td>
                        <?PHP }?>
                      </tr>
                  </table></td>
                </tr>
            </table>
              <br />
            <table width="557" border="0" align="center">
              <tr>
                <td width="121" align="center">....................</td>
                <td width="184" align="center">...........................</td>
                <td width="153" align="center">........................</td>
                <td width="81" align="center">.....................</td>
              </tr>
              <tr class="st4">
                <td align="center"><strong>Mother</strong></td>
                <td align="center"><strong>Father/Guardian</strong></td>
                <td align="center"><strong>Class Teacher</strong></td>
                <td align="center"><strong><!--<a href="reportcardp2.php?id=<? //echo $s_id;?>&cno=<? //echo $cno;?>" style="text-decoration:none" target="_blank">-->Principal<!--</a>--></strong></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<br />
<p class="page"></p>
<br />
<table width="200" align="center" >
  <tr>
    <td height="587"><table width="200" border="1">
      <tr valign="top">
        <td height="579" align="center" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><table width="100%" border="0">
          <tr>
            <td width="329" class="st3"><strong>Part 1:Academic Performance:Scholastic Areas</strong></td>
          </tr>
          <tr>
            <td align="center"><strong class="style19">Term 1</strong></td>
          </tr>
        </table>
          <table width="540" border="1">
            <tr class="style19">
              <td width="147" align="left" class="st4"><strong class="st4">Subjects</strong></td>
              <?php $ghi=mysql_query($gh="SELECT distinct Assesment , AssID FROM `assesments` Where Term='Term 1' And MSID='$msid' "); while($gow=mysql_fetch_array($ghi)){  ?>
              <td width="89" align="center" class="st4"><strong class="st4"><?php echo $ann=$gow['Assesment'];$AssID=$gow['AssID'];?></strong></td>
              <?php } ?>
              <td width="89" align="left" class="st4"><strong class="st4">Term|GR</strong></td>
            </tr>
            <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){ 
				 
				  ?>
            <tr class="style19" >
              <td height="22">&nbsp;&nbsp;&nbsp;<?php    $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></td>
              <td width="89" align="center"><?php  $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></td>
              <td width="89" align="center"><?php $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?></td>
              <td width="94" align="center"><?php  $ghiy3=mysql_query($ghy3="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy3=mysql_fetch_array($ghiy3)){echo $Grade3=$gowy3['Grade'];}?></td>
              <td width="87" align="center"><? $ghiy1=mysql_query($ghy1="SELECT Q1.StudentId,Q1.SubjectId,Q1.Term,Q1.Point,G.Grade FROM (Select RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,W.Term,round(Sum(RD.`MarksObtained`)/SUM(W.OverallWt)*SUM(TermWt),2) Point from 22Weightage W inner JOIN `21Repodata1` RD ON W.AssId=RD.AssId AND W.OverallWt=RD.MaxMarks WHERE  RD.MSID='$msid' AND  W.MSID='$msid' AND `Session`='$session' AND StudentId='$s_id'  AND  `SubjectId`='$sb'  And  W.Term ='1' GROUP BY RD.StudentId,RD.SubjectId,W.Term) Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto`  "); while($gowy1=mysql_fetch_array($ghiy1)){  $StudentId=$gowy1['StudentId'];  $SubjectId=$gowy1['SubjectId'];  $Term=$gowy1['Term'];  echo $Grade1=$gowy1['Grade'];  $Point=$gowy1['Point'];} ?></td>
            </tr>
            <?php  } ?>
          </table>
          <table width="540" border="0">
            <tr class="style19">
              <td width="249"><strong>Part 2: Co-Scholastic Areas </strong></td>
              <td width="297"><strong>(2 A) Life Skills </strong></td>
            </tr>
      </table>
        
          <table width="540" border="0">
            <tr>
              <td width="564" height="13" valign="top"><table width="540" border="1">
                <?php  ?>
                <tr>
                  <td height="23" valign="top"><span class="style19"><strong>(2 A) Life Skills </strong></span></td>
                  <td valign="top"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                  <td valign="top"><span class="style19"><strong>Grade</strong></span></td>
                </tr>
                <tr>
                  <td height="23" colspan="3" valign="top"><span class="style19"><strong>Thinking Skills</strong></span></td>
                </tr>
                <tr>
                  <td height="23" valign="top" class="style19"><span class="style19">Self Awarness</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi=mysql_query($lh="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'  And 24G.Particular='Self Awareness'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low=mysql_fetch_array($lhi)){   $Marks= $low['Marks'];      $pr=$low['Particular'];} if($Marks=='1'){$gr='A';}else {$gr='B';} 
  $bhi=mysql_query($bh="SELECT * FROM `25IndicatorDesc` Where Grade='$gr' And  PartNo='$pr' And  MSID='$msid'"); while($bow=mysql_fetch_array($bhi)){      $bow['Grade'];   echo   $bow['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Problem Solving</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi1=mysql_query($lh1="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'  And 24G.Particular='Problem Solving'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low1=mysql_fetch_array($lhi1)){ $Marks1= $low1['Marks'];     $pr1=$low1['Particular'];}  
if($Marks1=='1'){$gr1='A';}else {$gr1='B';}   $bhi1=mysql_query($bh1="SELECT * FROM `25IndicatorDesc` Where Grade='$gr1' And  PartNo='$pr1' And  MSID='$msid'"); while($bow1=mysql_fetch_array($bhi1)){      $bow1['Grade'];   echo   $bow1['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow1['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Decision Making</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi2=mysql_query($lh2="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Decision Making'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low2=mysql_fetch_array($lhi2)){ $Marks2= $low2['Marks'];     $pr2=$low2['Particular'];}  
 if($Marks2=='1'){$gr2='A';}else {$gr2='B';}  $bhi2=mysql_query($bh2="SELECT * FROM `25IndicatorDesc` Where Grade='$gr2' And  PartNo='$pr2' And  MSID='$msid'"); while($bow2=mysql_fetch_array($bhi2)){      $bow2['Grade'];   echo   $bow2['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow2['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Critical Thinking</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi3=mysql_query($lh3="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'  And 24G.Particular='Critical Thinking'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low3=mysql_fetch_array($lhi3)){ $Marks3= $low3['Marks'];     $pr3=$low3['Particular'];}
				     if($Marks3=='1'){$gr3='A';}else {$gr3='B';}
  $bhi3=mysql_query($bh3="SELECT * FROM `25IndicatorDesc` Where Grade='$gr3' And  PartNo='$pr3' And  MSID='$msid'"); while($bow3=mysql_fetch_array($bhi3)){      $bow3['Grade'];   echo   $bow3['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow3['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Creative Thinking</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi4=mysql_query($lh4="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Creative Thinking'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low4=mysql_fetch_array($lhi4)){ $Marks4= $low4['Marks'];     $pr4=$low4['Particular'];}  
     if($Marks4=='1'){$gr4='A';}else {$gr4 ='B';} 
	  $bhi4=mysql_query($bh4="SELECT * FROM `25IndicatorDesc` Where Grade='$gr4' And  PartNo='$pr4' And  MSID='$msid'"); while($bow4=mysql_fetch_array($bhi4)){      $bow4['Grade'];   echo   $bow4['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow4['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" colspan="3" valign="top"><strong class="style19">Social Skills</strong></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Inter Personal Relationships</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi5=mysql_query($lh5="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'  And 24G.Particular='Inter Personal Relationships'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low5=mysql_fetch_array($lhi5)){   $Marks5= $low5['Marks'];     $pr5=$low5['Particular'];}  
  
	   if($Marks5=='2'){$gr5='A';}else if($Marks5=='1'){$gr5='B';}else {$gr5 ='C';} 
	  $bhi5=mysql_query($bh5="SELECT * FROM `25IndicatorDesc` Where Grade='$gr5' And  PartNo='$pr5' And  MSID='$msid'"); while($bow5=mysql_fetch_array($bhi5)){      $bow5['Grade'];   echo   $bow5['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow5['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Effective Communication</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi6=mysql_query($lh6="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'  And 24G.Particular='Effective Communication'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low6=mysql_fetch_array($lhi6)){ $Marks6= $low6['Marks'];     $pr6=$low6['Particular'];}  
   
	  if($Marks6=='2'){$gr6='A';}else if($Marks6=='1'){$gr6='B';} else {$gr6 ='C';} 
	  $bhi6=mysql_query($bh6="SELECT * FROM `25IndicatorDesc` Where Grade='$gr6' And  PartNo='$pr6' And  MSID='$msid'"); while($bow6=mysql_fetch_array($bhi6)){      $bow6['Grade'];   echo   $bow6['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow6['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Empathy</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi7=mysql_query($lh7="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Empathy'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low7=mysql_fetch_array($lhi7)){ $Marks7= $low7['Marks'];     $pr7=$low7['Particular'];}  
     if($Marks7=='1'){$gr7='A';}else {$gr7 ='B';} 
  $bhi7=mysql_query($bh7="SELECT * FROM `25IndicatorDesc` Where Grade='$gr7' And  PartNo='$pr7' And  MSID='$msid'"); while($bow7=mysql_fetch_array($bhi7)){ 
	       $bow7['Grade'];   echo   $bow7['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow7['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" colspan="3" valign="top"><strong class="style19">Emotional Skills</strong></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Managing Emotions</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi8=mysql_query($lh8="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Managing Emotions'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low8=mysql_fetch_array($lhi8)){ $Marks8= $low8['Marks'];     $pr8=$low8['Particular'];}  
     
	 	  if($Marks8=='2.50'){$gr8='A';}else if($Marks8=='2.00'){$gr8='B';}else if($Marks8=='1.50'){$gr8='C';}else if($Marks8=='1'){$gr8='D';}else {$gr8 ='E';}  
  $bhi8=mysql_query($bh8="SELECT * FROM `25IndicatorDesc` Where Grade='$gr8' And  PartNo='$pr8'  And  MSID='$msid'"); while($bow8=mysql_fetch_array($bhi8)){ 
	       $bow8['Grade'];   echo   $bow8['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow8['Grade'];}?>
                  </span></td>
                </tr>
                <tr>
                  <td height="23" valign="top"><span class="style19">Dealing With Stress</span></td>
                  <td valign="top"><span class="style19">
                    <?php   $lhi9=mysql_query($lh8="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Dealing With Stress'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low9=mysql_fetch_array($lhi9)){ $Marks9= $low9['Marks'];     $pr9=$low9['Particular'];}  
     
	 	  if($Marks9=='2.50'){$gr9='A';}else if($Marks9=='2.00'){$gr9='B';}else if($Marks9=='1.50'){$gr9='C';}else if($Marks9=='1'){$gr9='D';}else {$gr9 ='E';}  
  $bhi9=mysql_query($bh9="SELECT * FROM `25IndicatorDesc` Where Grade='$gr9' And  PartNo='$pr9' And  MSID='$msid'"); while($bow9=mysql_fetch_array($bhi9)){ 
	       $bow9['Grade'];   echo   $bow9['Des']; ?>
                  </span></td>
                  <td valign="top"><span class="style19">
                    <?    echo   $bow9['Grade'];}?>
                  </span></td>
                </tr>
                </table></td>
            </tr>
            <tr>
              <td height="14" valign="top"><strong>2(B)</strong></td>
            </tr>
            <tr>
              <td height="14" valign="top"><table width="540" border="1">
                <tr>
                  <td rowspan="2"><span class="style19">Work Education</span></td>
                  <td height="23"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                  <td><span class="style19"><strong>Grade</strong></span></td>
                </tr>
                <tr>
                  <td height="22"><span class="style19">
                    <?php  $lhi10=mysql_query($lh10="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Work Education'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low10=mysql_fetch_array($lhi10)){ $Marks10= $low10['Marks'];     $pr10=$low10['Particular'];}  
     
 if($Marks10=='5'){$gr10='A';}else if($Marks10=='4'){$gr10='B';}else if($Marks10=='3.00'){$gr10='C';}else if($Marks10=='2'){$gr10='D';}else {$gr10 ='E';}  $bhi10=mysql_query($bh10="SELECT * FROM `25IndicatorDesc` Where Grade='$gr10' And  PartNo='$pr10' And  MSID='$msid'"); while($bow10=mysql_fetch_array($bhi10)){ 
	       $bow10['Grade'];   echo   $bow10['Des']; ?>
                  </span></td>
                  <td><span class="style19">
                    <?  echo   $bow10['Grade'];}?>
                  </span></td>
                </tr>
                </table></td>
            </tr>
          </table></td>
        <td>&nbsp;&nbsp;&nbsp;</td>
        <td><table width="587" border="0" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="575" height="568"><table width="575" height="564" align="center" bordercolor="#2A3F00">
          
          <tr align="left" valign="top">
            <td height="558" valign="top" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><table width="556" border="0" >
              <tr>
                <td width="541" align="right" valign="top" class="st4"><span class="style19"><strong>Student Id :<? echo $s_id;?>  Overall Grade:<? $ghi6=mysql_query($gh6="SELECT Q1.StudentId, Q1.Point,G.Grade FROM (Select StudentId, MSID, round(Sum( `MarksObtained`)/SUM(`MaxMarks`)*100,2) Point from `21Repodata1`  WHERE   MSID='$msid' AND `Session`='$session' AND StudentId='$s_id') Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto`"); while($gow6=mysql_fetch_array($ghi6)){echo $Grade6=$gow6['Grade'];} ?></strong></span></td>
              </tr>
              <tr>
                <td align="center"><span class="style19"><strong>Term 2</strong></span></td>
              </tr>
            </table>
              <table width="556" border="1">
                <tr>
                  <td width="95" align="left"><span class="style19"><strong class="st4">Subjects</strong></span></td>
                  <?php  $ghi=mysql_query($gh="SELECT distinct Assesment , AssID FROM `assesments` Where Term='Term 2'  And MSID='$msid' "); while($gow=mysql_fetch_array($ghi)){ ?> 
                  <td width="38" align="center"><span class="style19"><strong class="st4"><?php echo $ann=$gow['Assesment'];$AssID=$gow['AssID'];?></strong></span></td>
                  <?php } ?>
                  <td width="56" align="left"><span class="style19"><strong class="st4">Term|GR</strong></span></td>
                  <td width="63" align="left"><span class="style19"><strong class="st4">OA Gr</strong></span></td>
                  
                   <td width="99" align="left"><span class="style19"><strong class="st4">Grade Point</strong></span></td>
                   
                </tr>
                <?php  $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'");   $nrow = mysql_num_rows($phi);	 	while($pow=mysql_fetch_array($phi)){ 
				 
				?>
                <tr>
                  <td height="22" align="left"><span class="style19">
                    &nbsp;&nbsp;&nbsp;<?php    $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?>
                  </span></td>
                  <td width="38" align="center"><span class="style19">
                    <?php  $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?>
                  </span></td>
                  <td width="56" align="center"><span class="style19">
                    <?php $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?>
                  </span></td>
                  <td width="63" align="center"><span class="style19">
                    <?php   $ghiy3=mysql_query($ghy3="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='6' AND RD.`SubjectId`='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy3=mysql_fetch_array($ghiy3)){echo $Grade3=$gowy3['Grade'];}?>
                  </span></td>
                  <td width="99" align="center"><span class="style19">
                    <?  $ghiy51=mysql_query($ghy51="SELECT Q1.StudentId,Q1.SubjectId,Q1.Term,Q1.Point,G.Grade FROM (Select RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,W.Term,round(Sum(RD.`MarksObtained`)/SUM(W.OverallWt)*SUM(TermWt),2) Point from 22Weightage W inner JOIN `21Repodata1` RD ON W.AssId=RD.AssId AND W.OverallWt=RD.MaxMarks WHERE  RD.MSID='$msid' AND  W.MSID='$msid' AND `Session`='$session' AND StudentId='$s_id'  AND  `SubjectId`='$sb'  And  W.Term ='2' GROUP BY RD.StudentId,RD.SubjectId,W.Term) Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto`"  /*SELECT Q1.StudentId,Q1.SubjectId,Q1.Term,Q1.Point,G.Grade FROM (SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,W.Term,SUM(ROUND(RD.`MarksObtained`/RD.`MaxMarks`*TermWt,2)) Point FROM `21Repodata1` RD INNER JOIN 22Weightage W ON W.MSID=RD.MSID AND W.AssId=RD.AssId WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND StudentId='$s_id'  AND RD.`SubjectId`='$sb'  And  W.Term ='2' GROUP BY RD.StudentId,RD.SubjectId,W.Term) Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto` */ ); while($gowy51=mysql_fetch_array($ghiy51)){  $StudentId=$gowy51['StudentId'];  $SubjectId=$gowy51['SubjectId'];  $Term=$gowy51['Term'];  echo $Grade51=$gowy51['Grade'];  $Point=$gowy51['Point'];} ?>
                  </span></td>
                  <td width="64" align="center"><span class="style19">
                    <?  $ghiu=mysql_query($ghu="SELECT Q1.StudentId,Q1.SubjectId,Q1.Term,Q1.Point,G.Grade FROM (Select RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,W.Term,round(Sum(RD.`MarksObtained`)/SUM(W.OverallWt)*100,2) Point from 22Weightage W inner JOIN `21Repodata1` RD ON W.AssId=RD.AssId AND W.OverallWt=RD.MaxMarks WHERE  RD.MSID='$msid' AND  W.MSID='$msid' AND `Session`='$session' AND StudentId='$s_id'  AND  `SubjectId`='$sb'   GROUP BY RD.StudentId,RD.SubjectId ) Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto`"); while($gowu=mysql_fetch_array($ghiu)){echo $gowu['Grade'];} ?>
                  </span></td>
                  <td width="95" align="center"><span class="style19">
                  
                  
                  
                     <? $ghiyu=mysql_query($ghuy="SELECT Q1.StudentId,Q1.SubjectId,Q1.Term,Q1.Point,G.Grade ,G.GradePoint FROM (Select RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,W.Term,round(Sum(RD.`MarksObtained`)/SUM(W.OverallWt)*100,2) Point from 22Weightage W inner JOIN `21Repodata1` RD ON W.AssId=RD.AssId AND W.OverallWt=RD.MaxMarks WHERE  RD.MSID='$msid' AND  W.MSID='$msid' AND `Session`='$session' AND StudentId='$s_id'  AND  `SubjectId`='$sb'   GROUP BY RD.StudentId,RD.SubjectId ) Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto`"); while($gowiu=mysql_fetch_array($ghiyu)){echo $gowiu['GradePoint'];} ?>
                  </span></td>
                </tr>  <?php }  ?>
                <tr>
                  <td height="43" colspan="5" class="r"><strong>Grading Scale:</strong>A1=91%-100%;A2=81%-90%;B1=71%-80%;B2=61%-70%;C1=51%-60%;C2=41%-%50%;D=33%-40%;E1=21%-32%;E2=20% AND BELOW</td>
                  <td width="64" align="center"><span class="style19"><strong>CGPA</strong></span></td>
                  <td width="95" align="center"> <span class="style19"><strong>
                    <? $g7hiyu=mysql_query($g7huy="SELECT Q1.StudentId,Q1.SubjectId,Q1.Term,Q1.Point,G.Grade  ,round(Sum(G.GradePoint)/$nrow) as cgpa FROM (Select RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,W.Term,round(Sum(RD.`MarksObtained`)/SUM(W.OverallWt)*100,2) Point from 22Weightage W inner JOIN `21Repodata1` RD ON W.AssId=RD.AssId AND W.OverallWt=RD.MaxMarks WHERE  RD.MSID='$msid' AND  W.MSID='$msid' AND `Session`='$session' AND StudentId='$s_id'     GROUP BY RD.StudentId,RD.SubjectId ) Q1 INNER JOIN 23Grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN G.`PercentFrom` AND G.`Percentto`"); while($g7owiu=mysql_fetch_array($g7hiyu)){echo $g7owiu['cgpa'];} ?>
                  </strong></span></td>
                </tr>
              
            </table>
              <table width="556" border="0">
                <tr>
                  <td><strong class="style19">                    2(C)</strong></td>
                </tr>
                <tr>
                  <td><table width="549" border="1">
                    <tr>
                      <td rowspan="2"><span class="style19">Visual and Performing Arts</span></td>
                      <td height="26"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                      <td><span class="style19"><strong>Grade</strong></span></td>
                    </tr>
                    <tr>
                      <td height="22"><span class="style19">
                        <?php  $lhi11=mysql_query($lh11="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Arts'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low11=mysql_fetch_array($lhi11)){ $Marks11= $low11['Marks'];     $pr11=$low11['Particular'];}  
     
 if($Marks11=='5'){$gr11='A';}else if($Marks11=='4.00'){$gr11='B';}else if($Marks11=='3.00'){$gr11='C';}else if($Marks11=='2.00'){$gr11='D';}else {$gr11 ='E';}  $bhi11=mysql_query($bh11="SELECT * FROM `25IndicatorDesc` Where Grade='$gr11' And  PartNo='$pr11' And  MSID='$msid'"); while($bow11=mysql_fetch_array($bhi11)){ 
	       $bow11['Grade'];   echo   $bow11['Des']; ?>
                      </span></td>
                      <td><span class="style19">
                        <?  echo   $bow11['Grade'];}?>
                      </span></td>
                    </tr>
                    </table></td>
                </tr>
                <tr>
                  <td><strong class="style19">                    2(D)Attitudes and Values<br />
                  </strong></td>
                </tr>
            </table>
              <table width="550" border="0">
                <tr>
                <td width="564" height="13" valign="top"><table width="549" border="1">
                 
                  <tr>
                    <td height="21" valign="top"><span class="style19"><strong>Attitude Towards </strong></span></td>
                    <td valign="top"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                    <td valign="top"><span class="style19"><strong>Grade</strong></span></td>
                  </tr>
                  <tr>
                    <td height="9" valign="top"><span class="style19">Teachers</span></td>
                    <td valign="top"><span class="style19">
                      <?php  $lhi12=mysql_query($lh12="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Attitude Towards Teachers'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low12=mysql_fetch_array($lhi12)){ $Marks12= $low12['Marks'];     $pr12=$low12['Particular'];}  
     
 if($Marks12=='5'){$gr12='A';}else if($Marks12=='4'){$gr12='B';}else if($Marks12=='3.00'){$gr12='C';}else if($Marks12=='2'){$gr12='D';}else {$gr12 ='E';}  $bhi12=mysql_query($bh12="SELECT * FROM `25IndicatorDesc` Where Grade='$gr12' And  PartNo='$pr12' And  MSID='$msid'"); while($bow12=mysql_fetch_array($bhi12)){ 
	       $bow12['Grade'];   echo   $bow12['Des']; ?>
                    </span></td>
                    <td valign="top"><span class="style19">
                      <?  echo   $bow12['Grade'];}?>
                    </span></td>
                  </tr>
                  <tr>
                    <td height="10" valign="top"><span class="style19">School Mates</span></td>
                    <td valign="top"><span class="style19">
                      <?php  $lhi13=mysql_query($lh13="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Attitude Towards School-Mates'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low13=mysql_fetch_array($lhi13)){ $Marks13= $low13['Marks'];     $pr13=$low13['Particular'];}  
     
 if($Marks13=='5'){$gr13='A';}else if($Marks13=='4'){$gr13='B';}else if($Marks13=='3.00'){$gr13='C';}else if($Marks13=='2'){$gr13='D';}else {$gr13 ='E';}  $bhi13=mysql_query($bh13="SELECT * FROM `25IndicatorDesc` Where Grade='$gr13' And  PartNo='$pr13' And  MSID='$msid'"); while($bow13=mysql_fetch_array($bhi13)){ 
	       $bow13['Grade'];   echo   $bow13['Des']; ?>
                    </span></td>
                    <td valign="top"><span class="style19">
                      <?  echo   $bow13['Grade'];}?>
                    </span></td>
                  </tr>
                  <tr>
                    <td height="10" valign="top"><span class="style19">School Programmes and Environment</span></td>
                    <td valign="top"><span class="style19">
                      <?php  $lhi14=mysql_query($lh14="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Attitude Towards Environment'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low14=mysql_fetch_array($lhi14)){ $Marks14= $low14['Marks'];     $pr14=$low14['Particular'];}  
     
 if($Marks14=='5'){$gr14='A';}else if($Marks14=='4.00'){$gr14='B';}else if($Marks14=='3.00'){$gr14='C';}else if($Marks14=='2.00'){$gr14='D';}else {$gr14 ='E';}  $bhi14=mysql_query($bh14="SELECT * FROM `25IndicatorDesc` Where Grade='$gr14' And  PartNo='$pr14' And  MSID='$msid'"); while($bow14=mysql_fetch_array($bhi14)){ 
	       $bow14['Grade'];   echo   $bow14['Des']; ?>
                    </span></td>
                    <td valign="top"><span class="style19">
                      <?  echo   $bow14['Grade'];}?>
                    </span></td>
                  </tr>
                  <tr>
                    <td height="10" valign="top"><span class="style19">Value Systems</span></td>
                    <td valign="top"><span class="style19">
                      <?php  $lhi15=mysql_query($lh15="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Value Systems'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low15=mysql_fetch_array($lhi15)){ $Marks15= $low15['Marks'];     $pr15=$low15['Particular'];}  
     
 if($Marks15=='5'){$gr15='A';}else if($Marks15=='4.00'){$gr15='B';}else if($Marks15=='3.00'){$gr15='C';}else if($Marks15=='2.00'){$gr15='D';}else {$gr15 ='E';}  $bhi15=mysql_query($bh15="SELECT * FROM `25IndicatorDesc` Where Grade='$gr15' And  PartNo='$pr15' And  MSID='$msid'"); while($bow15=mysql_fetch_array($bhi15)){ 
	       $bow15['Grade'];   echo   $bow15['Des']; ?>
                    </span></td>
                    <td valign="top"><span class="style19">
                      <?  echo   $bow15['Grade'];}?>
                    </span></td>
                  </tr>
                  <?php  ?>
                </table></td>
              </tr>
              <tr>
                <td height="14" valign="top"><span class="style19"><strong>                  3(A):CO-curricular activities</strong></span><strong><br />
                </strong></td>
              </tr>
              <tr>
                <td height="14" valign="top"><table width="549" border="1">
                  <tr>
                    <td><span class="style19"><strong>Activity</strong></span></td>
                    <td height="23"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                    <td><span class="style19"><strong>Grade</strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="style19">Literary and Creative Skills</span></td>
                    <td><span class="style19">
                      <?php  $lhi16=mysql_query($lh16="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Literary and Creative Skills'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low16=mysql_fetch_array($lhi16)){ $Marks16= $low16['Marks'];     $pr16=$low16['Particular'];}  
     
 if($Marks16=='5'){$gr16='A';}else if($Marks16=='4.00'){$gr16='B';}else if($Marks16=='3.00'){$gr16='C';}else if($Marks16=='2.00'){$gr16='D';}else {$gr16 ='E';}  $bhi16=mysql_query($bh16="SELECT * FROM `25IndicatorDesc` Where Grade='$gr16' And  PartNo='$pr16' And  MSID='$msid'"); while($bow16=mysql_fetch_array($bhi16)){ 
	       $bow16['Grade'];   echo   $bow16['Des']; ?>
                    </span></td>
                    <td><span class="style19">
                      <?  echo   $bow16['Grade'];}?>
                    </span></td>
                  </tr>
                  <tr>
                    <td><span class="style19">Scientific Skills</span></td>
                    <td><span class="style19">
                      <?php  $lhi17=mysql_query($lh17="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Scientific Skills'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low17=mysql_fetch_array($lhi17)){ $Marks17= $low17['Marks'];     $pr17=$low17['Particular'];}  
     
 if($Marks17=='5'){$gr17='A';}else if($Marks17=='4.00'){$gr17='B';}else if($Marks17=='3.00'){$gr17='C';}else if($Marks17=='2.00'){$gr17='D';}else {$gr17 ='E';}  $bhi17=mysql_query($bh17="SELECT * FROM `25IndicatorDesc` Where Grade='$gr17' And  PartNo='$pr17' And  MSID='$msid'"); while($bow17=mysql_fetch_array($bhi17)){ 
	       $bow17['Grade'];   echo   $bow17['Des']; ?>
                    </span></td>
                    <td><span class="style19">
                      <?  echo   $bow17['Grade'];}?>
                    </span></td>
                  </tr>
                  </table></td>
              </tr>
              <tr>
                <td height="14" valign="top"><strong class="style19">                  3(B)<br />
                </strong></td>
              </tr>
              <tr>
                <td height="14" valign="top"><table width="549" border="1">
                  <tr>
                    <td><span class="style19"><strong>Activity</strong></span></td>
                    <td height="23"><span class="style19"><strong>Descriptive Indicators </strong></span></td>
                    <td><span class="style19"><strong>Grade</strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="style19">Sports/Indigenous Sports</span></td>
                    <td><span class="style19">
                      <?php  $lhi18=mysql_query($lh18="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Indigenous Sports'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low18=mysql_fetch_array($lhi18)){ $Marks18= $low18['Marks'];     $pr18=$low18['Particular'];}  
     
 if($Marks18=='5'){$gr18='A';}else if($Marks18=='4.00'){$gr18='B';}else if($Marks18=='3.00'){$gr18='C';}else if($Marks18=='2.00'){$gr18='D';}else {$gr18 ='E';}  $bhi18=mysql_query($bh18="SELECT * FROM `25IndicatorDesc` Where Grade='$gr18' And  PartNo='$pr18' And  MSID='$msid'"); while($bow18=mysql_fetch_array($bhi18)){ 
	       $bow18['Grade'];   echo   $bow18['Des']; ?>
                    </span></td>
                    <td><span class="style19">
                      <?  echo   $bow18['Grade'];}?>
                    </span></td>
                  </tr>
                  <tr>
                    <td><span class="style19">Yoga</span></td>
                    <td><span class="style19">
                      <?php  $lhi19=mysql_query($lh19="SELECT 21R2.*,24G.* FROM `21Repodata2` 21R2 INNER JOIN 24Gradeindectors 24G ON 21R2.Particular=24G.Particular where 21R2.`StudentID`='$s_id' And 21R2.`Session`='$session'   And 24G.Particular='Yoga'  And 21R2.MSID='$msid' And 24G.MSID='$msid'");  while($low19=mysql_fetch_array($lhi19)){ $Marks19= $low19['Marks'];     $pr19=$low19['Particular'];}  
     
 if($Marks19=='5'){$gr19='A';}else if($Marks19=='4.00'){$gr19='B';}else if($Marks19=='3.00'){$gr19='C';}else if($Marks19=='2.00'){$gr19='D';}else {$gr19 ='E';}  $bhi19=mysql_query($bh19="SELECT * FROM `25IndicatorDesc` Where Grade='$gr19' And  PartNo='$pr19' And  MSID='$msid'"); while($bow19=mysql_fetch_array($bhi19)){ 
	       $bow19['Grade'];   echo   $bow19['Des']; ?>
                    </span></td>
                    <td><span class="style19">
                      <?  echo   $bow19['Grade'];}?>
                    </span></td>
                  </tr>
                  </table></td>
              </tr>
          </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
      </tr>
    </table></td>
  </tr>
</table>       
<p class="page"></p>	</body>	
   <? } ?> 
</html>
<?php  } }?>