<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name']; $Photo= $gow5['Photo'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate'];  
$Board_full_name= $row['Board_full_name']; 

} ?>::Report Card</title>
 <style>
p.page { page-break-after: always; }
 </style>
<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}
.b1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.m1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.n1 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>       <style type="text/css">
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
-->
</style>
<table width="750" height="845" border="1"   align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td height="839"><table width="100%" height="725" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top">
        <td width="704" height="137" align="center"><table width="100%" height="147" align="center">
          <tr>
            <td width="87" height="98" align="left" valign="top"><table width="88" border="0" align="center">
              <tr>
                <td width="82" height="92"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
              </tr>
            </table></td>
            <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
              <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
              <tr>
                <td width="539" height="40" align="center" class="m1"><?php echo $sname;?>&nbsp;&nbsp; <? echo   $Place;  ?></td>
              </tr>
              <tr>
                <td height="34" align="center" class="n1"><? echo $Board_full_name;?>&nbsp;&nbsp; <? echo   $RecNo;  ?></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="41" colspan="2" class="st411" align="center" valign="middle" bgcolor="#E8E8E8"><h3>ACHIEVEMENT RECORD &ndash; SESSION ( <? echo $session; ?>-<? echo $session2=$session+1; ?> )</h3></td>
            </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="68"><table width="100%" height="66" border="0" align="center">
          <tr valign="top" class="st42">
          
            <td width="97">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td height="33"><? echo $Name;?></td>
            <td width="90" height="33">Class:</td>
            <td width="88"><? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>- <? $result2sec=mysql_query($sql2sec="select * from `4Sections` where  ID='$Section' And MSID='$msid'");
	  while($row2sec=mysql_fetch_array($result2sec)){ echo $row2sec['Sectionname'];  }?></td>
            <td width="108" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td width="81" ><? echo $sid;?>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="27">Father's Name:</td>
            <td width="240" height="27">Mr. <? echo $FatherName;?></td>
            <td height="27">Date Of Birth: </td>
            <td height="27"><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?></td>
            <td>Roll No.:</td>
            <td><? echo $Roll_No;?>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="174"><table width="100%" height="101" border="1" align="center"> 
        <tr valign="top" bgcolor="#E8E8E8">
            <td height="37" colspan="5" class="st411" align="center" valign="middle"><h3>PART &ndash; 1 : SCHOLASTIC AREA</h3></td>
            </tr>
          <tr valign="top" bgcolor="#E8E8E8">
            <td rowspan="2" class="st411"><strong>Subjects</strong></td>
            <td height="14" colspan="3" align="center" class="st411">TERM I</td>
            <td align="center" class="st411">Final Assessment</td>
          </tr>
         
          <tr valign="top"  bgcolor="#C9C9C9">
            <td height="22" class="st411">FA1</td>
            <td class="st411">FA2</td>
            <td width="82" class="st411">SA1</td>
            <td width="245" class="st411">FA1+FA2+SA1</td>
          </tr>
          <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 		while($pow=mysql_fetch_array($phi)){  $nrow = mysql_num_rows($phi); $sb= $pow['SubjectId']; 
				 ?>
          <tr valign="top">
            <td width="142" height="16" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
            <td width="133" class="st411"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></td>
            <td width="94" class="st411"><?php $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?></td>
            <td class="st411"><?php $gr23=mysql_query($ghyn23="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g23=mysql_fetch_array($gr23)){echo $Gn23=$g23['Grade'];}?></td>
            <td class="st411"><?php $gr2=mysql_query($ghyn2="select FL.msid,FL.stu_id,FL.name,FL.house,FL.cclass,FL.cclass,FL.subject,FL.mo as percent,G.grade,G.gradepoint,FL.t from(select TG.msid,TG.stu_id,TG.name,TG.house,TG.cclass,TG.subject,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.name,term1.house,term1.cclass,term1.subject,term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as 

term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.mysession,FA_PER.name,FA_PER.house,FA_PER.cclass,FA_PER.subjectid,FA_PER.subject,
FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from(select 

FA1.msid,FA1.stu_id,FA1.mysession,FA1.name,FA1.house,FA1.cclass,RD.subjectid,sub.subject,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id 

,S.mysession,S.name,S.house,S.admclassno+year(U.mydate)-year(S.fsdate)+COALESCE(sum(E.result),0) as cclass FROM `13Students` S inner join 7FeeUsers U on U.msid=S.msid 

and U.mydate between S.fsdate and S.sldate left join 14Exam E on E.msid=S.msid and E.s_id=S.id where U.myuid='$foo' and S.id=$sid) as FA1 inner join 21Repodata1 RD 

on RD.msid=FA1.msid and RD.studentid=FA1.stu_id and RD.session=FA1.mysession inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid) as FA_PER ) as term1 inner join 22Weightage W 

on W.msid=term1.msid and W.assid=term1.assid and term1.cclass between W.classfrom and W.classto) as TG group by TG.subject,TG.t order by TG.t) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and FL.cclass between G.classfrom and G.classto where FL.subjectid='$sb'  ORDER BY FL.subjectid"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['grade'];}?>
              &nbsp;</td>
          </tr>
          <?php   }
		  ?>
        </table><br/>
          <table width="100%" height="786" border="1" align="center">
            <tr valign="top">
              <td height="30" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><h3>PART-2 : CO &ndash; SCHOLASTIC AREAS</h3></td>
            </tr>
            <tr valign="top">
              <td height="31" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 2 (A) : LIFE SKILLS</strong></td>
            </tr>
            <tr valign="top" >
              <td width="45" height="32" class="st4" valign="middle">Sr.No.</td>
              <td width="239" class="st4" valign="middle">Activity</td>
              <td width="59" class="st4" valign="middle">Term &ndash; I<br />
                Grade</td>
              <td width="359" class="st4" valign="middle">Descriptive Indicators</td>
            </tr>
            <tr valign="top">
              <td height="36" class="st4">01</td>
              <td class="st4">THINKING SKILLS</td>
              <td class="st4"><?php 
			 $tr=mysql_query($q="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and `Particular`='THINKING SKILLS' and MSID='$msid' and Session='$session' ");
				 while($tt=mysql_fetch_array($tr)){ $sb= $tt['Marks']; $tr102=mysql_query($q102="Select * from grade2 where GRADE_ID='$sb'");
				 while($tt102=mysql_fetch_array($tr102)){ echo  $sb102= $tt102['GRADE_NAME']; } ?></td>
              <td class="st4"><?php  $sb1= $tt['Indicator']; echo "$Name "." $sb1"; } ?></td>
            </tr>
            <tr valign="top">
              <td height="34" class="st4">02</td>
              <td class="st4">SOCIAL SKILLS</td>
              <td class="st4"><?php 
				 $tr1=mysql_query($q1="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SOCIAL SKILLS' and MSID='$msid' and Session='$session'");
				 while($tt1=mysql_fetch_array($tr1)){ $sbg= $tt1['Marks']; $tr102=mysql_query($q102="Select * from grade2 where GRADE_ID='$sbg'");
				 while($tt102=mysql_fetch_array($tr102)){echo  $sb102= $tt102['GRADE_NAME']; } ?></td>
              <td class="st4"><?php $sbi= $tt1['Indicator']; echo "$Name "." $sbi";}   ?></td>
            </tr>
            <tr valign="top">
              <td height="35" class="st4">03</td>
              <td class="st4">EMOTIONAL SKILLS </td>
              <td class="st4"><?php 
				$tr2=mysql_query($q2="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='EMOTIONAL SKILLS' and MSID='$msid' and Session='$session' ");
				 while($tt2=mysql_fetch_array($tr2)){ $sbg1= $tt2['Marks']; $tr103=mysql_query($q103="Select * from grade2 where GRADE_ID='$sbg1'");
				 while($tt103=mysql_fetch_array($tr103)){echo  $sb103= $tt103['GRADE_NAME']; } ?></td>
              <td class="st4"><?php  $sbi1= $tt2['Indicator']; echo "$Name "." $sbi1";}  ?></td>
            </tr>
             <tr valign="top">
              <td height="37" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 2 (B) : WORK EDUCATION</strong></td>
            </tr>
            <tr valign="top">
              <td height="37" class="st4"><strong>01</strong></td>
              <td class="st4">WORK EDUCATION</td>
              <td class="st4"><?php 
				 $tr3=mysql_query($q3="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='WORK EDUCATION' and MSID='$msid' and Session='$session'");
				 while($tt3=mysql_fetch_array($tr3)){ $sbg3= $tt3['Marks']; $tr104=mysql_query($q104="Select * from grade2 where GRADE_ID='$sbg3'");
				 while($tt104=mysql_fetch_array($tr104)){echo  $sb104= $tt104['GRADE_NAME']; }?></td>
              <td class="st4"><?php  $sbi3= $tt3['Indicator']; echo "$Name "." $sbi3";}  ?></td>
            </tr>
            <tr valign="top">
              <td height="37" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 2 (C) : VISUAL AND PERFORMING ARTS</strong></td>
            </tr>
            <tr valign="top">
              <td height="37" class="st4"><strong>01</strong></td>
              <td class="st4">VISUAL AND PERFORMING ARTS</td>
              <td class="st4"><?php 
				 $tr4=mysql_query($q4="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='VISUAL AND PERFORMING ARTS' and MSID='$msid' and Session='$session' ");
				 while($tt4=mysql_fetch_array($tr4)){ $sbg4= $tt4['Marks']; $tr105=mysql_query($q105="Select * from grade2 where GRADE_ID='$sbg4'");
				 while($tt105=mysql_fetch_array($tr105)){echo  $sb105= $tt105['GRADE_NAME']; } ?></td>
              <td class="st4"><?php $sbi4= $tt4['Indicator']; echo "$Name "." $sbi4";}  ?></td>
            </tr>
            <tr valign="top">
              <td height="36" colspan="4" class="st4" valign="middle" align="center" bgcolor="#E8E8E8"><strong>PART 2 (D)-ATTITUDE &amp; VALUES</strong></td>
            </tr>
            <tr valign="top">
              <td height="33" class="st4">1.0</td>
              <td colspan="3" class="st4">ATTITUDE TOWARDS</td>
            </tr>
            <tr valign="top">
              <td height="33" class="st4">1.1</td>
              <td class="st4">TEACHERS</td>
              <td class="st4"><?php 
				 $tr5=mysql_query($q5="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='TEACHERS' and MSID='$msid' and Session='$session' ");
				 while($tt5=mysql_fetch_array($tr5)){ $sbg5= $tt5['Marks']; $tr106=mysql_query($q106="Select * from grade2 where GRADE_ID='$sbg5'");
				 while($tt106=mysql_fetch_array($tr106)){echo  $sb106= $tt106['GRADE_NAME']; } ?></td>
              <td class="st4"><?php $sbi5= $tt5['Indicator']; echo "$Name "." $sbi5";}  ?></td>
            </tr>
            <tr valign="top">
              <td height="33" class="st4">1.2</td>
              <td class="st4">SCHOOL-MATES</td>
              <td class="st4"><?php 
				 $tr16=mysql_query($q16="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCHOOL MATES' and MSID='$msid' and Session='$session' ");
				 while($tt16=mysql_fetch_array($tr16)){$sbg16= $tt16['Marks']; $tr107=mysql_query($q107="Select * from grade2 where GRADE_ID='$sbg16'");
				 while($tt107=mysql_fetch_array($tr107)){echo  $sb107= $tt107['GRADE_NAME']; } ?></td>
              <td class="st4"><?php $sbi16= $tt16['Indicator']; echo "$Name "." $sbi16";}  ?></td>
            </tr>
            <tr valign="top">
              <td height="40" class="st4">1.3</td>
              <td class="st4">SCHOOL PROGRAMMES &amp; ENVIORNMENT</td>
              <td class="st4"><?php 
				 $tr6=mysql_query($q6="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCHOOL PROGRAMMES AND ENVIRONMENT' and MSID='$msid' and Session='$session'");
				 while($tt6=mysql_fetch_array($tr6)){  $sbg6= $tt6['Marks']; $tr108=mysql_query($q108="Select * from grade2 where GRADE_ID='$sbg6'");
				 while($tt108=mysql_fetch_array($tr108)){echo  $sb108= $tt108['GRADE_NAME']; } ?></td>
              <td class="st4"><?php  $sbi6= $tt6['Indicator']; echo "$Name "." $sbi6";}  ?></td>
            </tr>
            <tr valign="top">
              <td height="37" class="st4">2.0</td>
              <td class="st4">VALUE SYSTEM</td>
              <td class="st4"><?php 
				 $tr7=mysql_query($q7="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='VALUE SYSTEMS' and MSID='$msid' and Session='$session'");
				 while($tt7=mysql_fetch_array($tr7)){  $sbg7= $tt7['Marks']; $tr109=mysql_query($q109="Select * from grade2 where GRADE_ID='$sbg7'");
				 while($tt109=mysql_fetch_array($tr109)){echo  $sb109= $tt109['GRADE_NAME']; } ?></td>
              <td class="st4"><?php $sbi7= $tt7['Indicator']; echo "$Name "." $sbi7";}  ?></td>
            </tr></table>
           
          </td>
  </tr>
      <tr align="left" valign="top">
        <td height="123" valign="top"><table width="100%" height="151" border="0" align="center">
         
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
  <p class="page"></p> 
<table width="750" border="1"   align="center" >
  <tr>
    <td><table width="100%" height="865" align="center" bordercolor="#2A3F00">
      
      <tr align="left" valign="top">
        <td height="78"><table width="100%" height="267" border="1" align="center">
          <tr valign="top">
            <td height="45" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 3 (A) CO-SCHOLASTIC ACTIVITIES</strong></td>
          </tr>
          <tr valign="top">
            <td width="44" height="35" class="st4">01</td>
            <td width="253" class="st4">LITERARY &amp; CREATIVE SKILLS</td>
            <td width="38" class="st4"><?php 
				 $tr8=mysql_query($q8="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='LITERARY AND CREATIVE SKILLS' and MSID='$msid' and Session='$session'");
				 while($tt8=mysql_fetch_array($tr8)){  $sbg8= $tt8['Marks']; $tr110=mysql_query($q110="Select * from grade2 where GRADE_ID='$sbg8'");
				 while($tt110=mysql_fetch_array($tr110)){echo  $sb110= $tt110['GRADE_NAME']; } ?></td>
            <td width="331" class="st4"><?php $sbi8= $tt8['Indicator']; echo "$Name "." $sbi8";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="32" class="st4">02</td>
            <td class="st4">SCIENTIFIC SKILLS</td>
            <td class="st4"><?php 
				 $tr9=mysql_query($q9="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCIENTIFIC SKILLS' and MSID='$msid' and Session='$session'");
				 while($tt9=mysql_fetch_array($tr9)){  $sbg9= $tt9['Marks']; $tr111=mysql_query($q111="Select * from grade2 where GRADE_ID='$sbg9'");
				 while($tt111=mysql_fetch_array($tr111)){echo  $sb111= $tt111['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi9= $tt9['Indicator']; echo "$Name "." $sbi9";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="32" class="st4">02</td>
            <td class="st4">Clubs (Eco club, Health and wellness club and others)</td>
            <td class="st4"><?php 
				 $tr9=mysql_query($q9="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCIENTIFIC SKILLS' and MSID='$msid' and Session='$session'");
				 while($tt9=mysql_fetch_array($tr9)){  $sbg9= $tt9['Marks']; $tr111=mysql_query($q111="Select * from grade2 where GRADE_ID='$sbg9'");
				 while($tt111=mysql_fetch_array($tr111)){echo  $sb111= $tt111['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi9= $tt9['Indicator']; echo "$Name "." $sbi9";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="35" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8" align="center"><strong>PART 3 (b) HEALTH AND PHYSICAL EDUCATION</strong></td>
          </tr>
          <tr valign="top">
            <td height="35" class="st4">01</td>
            <td class="st4">YOGA</td>
            <td class="st4"><?php 
				 $tr10=mysql_query($q10="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='Yoga' and MSID='$msid' and Session='$session'");
				 while($tt10=mysql_fetch_array($tr10)){ $sbg10= $tt10['Marks']; $tr112=mysql_query($q112="Select * from grade2 where GRADE_ID='$sbg10'");
				 while($tt112=mysql_fetch_array($tr112)){echo  $sb112= $tt112['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi10= $tt10['Indicator']; echo "$Name "." $sbi10";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="35" class="st4">02</td>
            <td class="st4">SPORTS/ INDIGENOUS SPORTS</td>
            <td class="st4"><?php 
				 $tr11=mysql_query($q11="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SPORTS' and MSID='$msid' and Session='$session'");
				 while($tt11=mysql_fetch_array($tr11)){ $sbg11= $tt11['Marks']; $tr113=mysql_query($q113="Select * from grade2 where GRADE_ID='$sbg11'");
				 while($tt113=mysql_fetch_array($tr113)){echo  $sb113= $tt113['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi11= $tt11['Indicator']; echo "$Name "." $sbi11";}  ?></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="555"><table width="100%" border="1">
          <?php 
				 $tr12=mysql_query($q12="Select * from 21Repodata4healthsts where StudentID='$sid' and Session='$session'");
				 while($tt12=mysql_fetch_array($tr12)){$height= $tt12['Height']; $weight= $tt12['Weight']; $bgroup= $tt12['Blood_group'];
				 $dental= $tt12['DentalHygiene'];  }?>
          <tr>
            <td width="27%" rowspan="2" class="st4" align="center" valign="middle" bgcolor="#E8E8E8" ><strong>HEALTH DATA</strong></td>
            <td width="9%" class="st4" align="center">HEIGHT</td>
            <td width="9%" class="st4" align="center">WEIGHT</td>
            <!--<td width="10%" height="26" class="st4" align="center">BLOOD GROUP</td>-->
            <!--<td width="31%" align="center" class="st4">DENTAL HYGIENE</td>-->
          </tr>
          <tr>
            <td height="23" align="center" class="st4"><? echo $height; ?></td>
            <td align="center" class="st4"><? echo $weight; ?></td>
            <!--<td align="center" class="st4"><? /*echo $bgroup ;*/ ?></td>-->
            <!-- <td align="center" class="st4"><? //echo $dental ; ?></td>-->
          </tr>
        </table>
          <table width="100%%" height="482">
            <tr>
              <td height="266" colspan="2" valign="top"><table width="100%" border="1">
                <tr>
                  <td height="33" colspan="3" class="st4"><strong>SCHOLASTIC AREAS<br />
                    (GRADING ON 9 POINT SCALE)</strong></td>
                  </tr>
                <tr>
                  <td width="39%" class="st4"><strong>MARKS RANGE</strong></td>
                  <td width="26%" class="st4"><strong>GRADE</strong></td>
                  <td width="35%" class="st4"><strong>GRADE POINT</strong></td>
                </tr>
                <tr class="st4">
                  <td>91-100</td>
                  <td>A1</td>
                  <td>10</td>
                </tr>
                <tr class="st4">
                  <td>81-90</td>
                  <td>A2</td>
                  <td>9</td>
                </tr>
                <tr class="st4">
                  <td>71-80</td>
                  <td>B1</td>
                  <td>8</td>
                </tr>
                <tr class="st4">
                  <td>61-70</td>
                  <td>B2</td>
                  <td>7</td>
                </tr>
                <tr class="st4">
                  <td>51-60</td>
                  <td>C1</td>
                  <td>6</td>
                </tr>
                <tr class="st4">
                  <td>41-50</td>
                  <td>C2</td>
                  <td>5</td>
                </tr>
                <tr class="st4">
                  <td>33-40</td>
                  <td>D</td>
                  <td>4</td>
                </tr>
                <tr class="st4">
                  <td>21-32</td>
                  <td>E1</td>
                  <td>3</td>
                </tr>
                <tr class="st4">
                  <td>20 And Below</td>
                  <td>E2</td>
                  <td>2</td>
                </tr>
              </table></td>
              <td colspan="2" valign="top"><table width="100%%" border="1" class="st4">
                <tr>
                  <td height="46" colspan="3"><strong>CO-SCHOLASTIC AREAS/ACTIVITIES<br />
                    (GRADING ON 5 POINT SCALE)</strong></td>
                  </tr>
                <tr >
                  <td width="29%"><strong>GRADE</strong></td>
                  <td width="43%"><strong>GRADE POINT RANGE</strong></td>
                  <td width="28%"><strong>GRADE POINT</strong></td>
                  </tr>
                <tr>
                  <td>A</td>
                  <td>4.1 - 5.0</td>
                  <td>5</td>
                  </tr>
                <tr>
                  <td>B</td>
                  <td>3.1 - 4.0</td>
                  <td>4</td>
                  </tr>
                <tr>
                  <td>C</td>
                  <td>2.1 - 3.0</td>
                  <td>3</td>
                  </tr>
                <tr>
                  <td>D</td>
                  <td>1.1 - 2.0</td>
                  <td>2</td>
                  </tr>
                <tr>
                  <td>E</td>
                  <td>0.1 - 1.0</td>
                  <td>1</td>
                  </tr>
              </table></td>
            </tr>
            <tr>
              <td height="85" colspan="4" class="st4"><p>First Term: FA1 (10%) + FA2 (10%) + SA1 (30%) = 50%<br />
                  Second Term: FA3 (10%) + FA4 (10%) + SA2 (30%) = 50%<br />
                  Formative Assessment: FA1 (10%) + FA2 (10%) + FA3 (10%) + FA4 (10%) = 40%<br />
                Summative Assessment: SA1 (30%) + SA2 (30%) = 60%</p></td>
              </tr>
            <tr>
              <td height="40" colspan="4" class="st4"><strong>RESULT: </strong></td>
              </tr>
            <tr>
              <td width="24%" height="45" class="st4"><strong>Signature:</strong></td>
              <td width="27%">&nbsp;</td>
              <td width="25%" height="45">&nbsp;</td>
              <td width="24%">&nbsp;</td>
            </tr>
            <tr class="st4">
              <td height="27">&nbsp;</td>
              <td width="27%">CLASS TEACHER</td>
              <td width="25%" height="27">PARENT</td>
              <td width="24%">PRINCIPAL</td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<?php }}?>
</p></body>
</html>
