<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
$sec1=$_GET['sec'];    $sect = mysql_real_escape_string($sec1);
$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno'   And S.Section='$sect' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){$s_id= $gow5['sid'];$Name= $gow5['Name'];
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$TermDate= $row['TermDate']; 
} ?>::Report Card</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
<style type="text/css">
.style2 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
</style>
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
</head>
 
<body><style>
p.page { page-break-after: always; }
</style>
<table width="1195" border="0" align="center">
  <tr>
    <td width="1189"><table width="1123" border="1">
      <tr valign="top">
        <td width="502" height="504" align="center" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat"><span class="style2">First Semester Result </span><br />
          <br />
          <br />
          <table width="492" border="1" align="center">  
            <tr align="left" valign="top">
              <td width="141" height="23"><span class="style19"><strong>Subjects:</strong></span></td>
              <td width="76" class="st4"><strong> Unit 1</strong></td>
              <td width="91" align="left" class="st4"><strong>OT/Dic.</strong></td>
              <td width="104" align="center" class="st4"><strong>Semester</strong></td>
              <td width="46" align="center" class="st4"><strong>Final Grade</strong></td>
            </tr>
            <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 	
 	while($pow=mysql_fetch_array($phi)){ 
				 
				  ?>
            <tr align="left" valign="top">
              <td height="23"><span class="style19"><?php    $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></span></td>
              <td><span class="style19">
                <?php  $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM `21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></span></td>
             <td><span class="style19"><?php  $gr6=mysql_query($ghyn6="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM `21Repodata1Oral` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'  AND RD.`TestName`='1' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g6=mysql_fetch_array($gr6)){echo $Gn6=$g6['Grade'].'/';}  $gr3=mysql_query($ghyn3="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM `21Repodata1Oral` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'  AND RD.`TestName`='2' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g3=mysql_fetch_array($gr3)){echo $Gn3=$g3['Grade'];}?>
             </span></td>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
              </tr>
            <? }?>  
            <tr align="left" valign="top">
              <td height="23"><span class="style19"><strong>Total</strong></span><strong>:</strong></td>
              <td align="left" class="style19">   <?php  $ghiyr=mysql_query($ghyr="SELECT  round(SUM(MarksObtained))as tmarks FROM `21Repodata1` RD   WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$s_id'  AND RD.`AssId`='1' ORDER BY `StudentId`,`AssId`");
			   while($gowyr=mysql_fetch_array($ghiyr)){echo  $totsubmks=$gowyr['tmarks'];}?></td>
              <td colspan="3" align="center" class="st4">&nbsp;</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Activity</td>
              <td align="left" class="st4">Grade</td>
              <td colspan="3" class="st4">Attendance</td>
            </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Semester 1 </td>
              <td align="left" class="st4">&nbsp;</td>
              <td colspan="3" class="st4">Punctuality</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Semester 2 </td>
              <td align="left" class="st4">&nbsp;</td>
              <td colspan="3" class="st4">Neatness/Dress</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Exhibition</td>
              <td align="left" class="st4">&nbsp;</td>
              <td colspan="3" class="st4">Behaviour</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Discussion</td>
              <td align="left" class="st4">&nbsp;</td>
              <td colspan="3" align="left" class="st4">Regularity in maintaining notes</td>
              </tr>
            <tr align="left" valign="top">
              <td height="58" colspan="5" class="st4">Remarks</td>
            </tr>
            </table>
          <br />
          <table width="489" border="0">
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr class="st4">
              <td width="161">Father's Signature</td>
              <td width="157">&nbsp;</td>
              <td width="157">Teacher's signature</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td class="st4">Mother's Signature</td>
              <td>&nbsp;</td>
              <td class="st4">Principal</td>
            </tr>
          </table></td>
        <td width="52">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td width="547" align="center"><span class="style2">Second Semester Result </span><br />
          <br />
          <br />
          <table width="492" border="1" align="center">
            <?php 	
/* $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){ 
			*/	 
				  ?>
            <tr align="left" valign="top">
              <td width="109" rowspan="2" class="st4"><strong> Unit 2</strong></td>
              <td width="224" colspan="5" class="st4"><strong>1st Pre Board</strong></td>
              </tr>
            <tr align="left" valign="top">
              <td class="st4">Theory<br />
                85/60/35</td>
              <td class="st4">Prac.<br />
                25/50</td>
              <td class="st4">Dic.<br />
                15</td>
              <td class="st4">MCQ<br />
                /Ass<br />
                15</td>
              <td class="st4"><p>Total</p>
                <p>100</p></td>
              </tr>
               <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 	
 	while($pow=mysql_fetch_array($phi)){ 
				 
				  ?>
            <tr align="left" valign="top">
              <td height="23"><span class="style19"><?php    $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){  $Subject= $powg['Subject'];} ?></span></td>
              <td><span class="style19">
                <?php   $gr3=mysql_query($ghyn3="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='2'  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g3=mysql_fetch_array($gr3)){echo $Gn3=$g3['MarksObtained'];}?>
              </span></td>
              <td><span class="style19">
                <?php   $gr18=mysql_query($ghyn18="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='7'  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g18=mysql_fetch_array($gr18)){echo $Gn18=$g18['MarksObtained'];}?>
              </span></td>
              <td><span class="style19">
                <?php   $gr18=mysql_query($ghyn18="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='3'  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g18=mysql_fetch_array($gr18)){echo $Gn18=$g18['MarksObtained'];}?>
              </span></td>
              <td><span class="style19">
                <?php   $gr7=mysql_query($ghyn7="SELECT * from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb' AND RDO.`TestName`='4'  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g7=mysql_fetch_array($gr7)){echo $Gn7=$g7['MarksObtained'];}?>
              </span></td>
              <td align="center"><span class="style19">
                <?php   $hr4=mysql_query($hhyn4="SELECT SUM(MarksObtained) sumoh from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  AND RDO.`AssId`='1' AND RDO.`SubjectId`='$sb'  Group BY `StudentId`,`AssId`,`SubjectId`"); while($h4=mysql_fetch_array($hr4)){echo $hn4=$h4['sumoh'];}?>
              </span></td>
              </tr>  
            <? }?>  
            <tr align="left" valign="top">
              <td height="11" class="st4"><strong>Total</strong><strong>:</strong></td>
              <td colspan="3" align="center" class="st4">Percentage:</td>
              <td align="center" class="style19"><?  $xr4=mysql_query($xhyn4="SELECT round(SUM(MarksObtained)/ SUM(MaxMarks) *100,2)as prcntage from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  And SubjectId!='9' AND RDO.`AssId`='1' Group BY `StudentId`,`AssId` "); while($x4=mysql_fetch_array($xr4)){echo  $x4['prcntage'].'%';}?></td>
              <td align="center" class="style19"><?  $xr7=mysql_query($xhyn7="SELECT round(SUM(MarksObtained),2)as Gtotla from `21Repodata1Oral` RDO WHERE RDO.MSID='$msid' AND RDO.`Session`='$session' AND RDO.StudentId='$s_id'  And SubjectId!='9' AND RDO.`AssId`='1' Group BY `StudentId`,`AssId` "); while($x7=mysql_fetch_array($xr7)){echo  $x7['Gtotla'];}?></td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Percentage<span class="style4">:</span></td>
              <td colspan="5" class="st4">&nbsp;</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Activity</td>
              <td colspan="5" class="st4">Attendance</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Semester 1 </td>
              <td colspan="5" class="st4">Punctuality</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Semester 2 </td>
              <td colspan="5" class="st4">Neatness/Dress</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Exhibition</td>
              <td colspan="5" class="st4">Behaviour</td>
              </tr>
            <tr align="left" valign="top">
              <td height="11" class="st4">Discussion</td>
              <td colspan="5" align="left" class="st4">Regularity in maintaining notes</td>
              </tr>
            <tr align="left" valign="top">
              <td height="58" colspan="6" class="st4">Remarks</td>
            </tr>
          </table>
          <br />
          <table width="489" border="0">
            <tr>
              <td width="161">&nbsp;</td>
              <td width="157">&nbsp;</td>
              <td width="157">&nbsp;</td>
            </tr>
            <tr class="st4">
              <td colspan="3"><? echo $Name;?> has promoted to class ---Detaind in class--</td>
              </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td class="st4">Teacher's Signature</td>
              <td>&nbsp;</td>
              <td class="st4">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="3" class="st4">The School will reopen on ---------------------Principal</td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<br />
<p class="page"></p>

	</body>
   <? } ?> 
</html>
<?php  } ?>

