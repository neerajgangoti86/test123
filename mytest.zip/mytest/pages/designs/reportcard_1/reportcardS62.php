<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
$n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }
if($_POST){$sid=$_POST['c'];
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
}else {
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 $id1=$_GET['id'];$sid = mysql_real_escape_string($id1);}


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>='$Begins' And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$sid' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass']; $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate'];  
$Add_ReportC= $row['Add_ReportC'];

} ?>::Report Card</title>
 <style>
p.page { page-break-after: always; }
 </style>
<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}
.b1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.m1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.n1 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>       <style type="text/css">
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
-->
</style>
<table width="750" height="845" border="1"   align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td height="839"><table width="100%" height="833" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top">
        <td width="704" height="140" align="center"><table width="100%" height="202" align="center">
          <tr>
            <td width="87" height="196" align="left" valign="top"><table width="88" border="0" align="center">
              <tr>
                <td width="82" height="92"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
              </tr>
            </table></td>
            <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
              <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
              <tr>
                <td width="539" height="40" align="center" class="m1"><?php echo $sname;?></td>
              </tr>
              <tr>
                <td height="30" align="center" class="b1"><? echo   $Place;  ?></td>
              </tr>
              <tr>
                <td height="31" align="center" class="n1">Website:<? echo $Website;?>,E-mail:<? echo $EMail;?>,Ph:<? echo $Phone;?></td>
              </tr>
              <tr>
                <td height="25" align="center" class="n1">Affiliated to CBSE ,Delhi ,Affiliation No.:<? echo $AffiliationNo;?></td>
              </tr>
            </table>
              <p class="vks">Record of Academic Performance <? echo $session; ?></p></td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="163"><table width="100%" height="161" border="0" align="center">
          <tr valign="top" class="st42">
            <td width="139" rowspan="5"><img style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php  if($Photo!=""){echo $Photo;} else { 	echo"../../images/myprofile1.png";} ?>" width="122" height="127" /></td>
            <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td height="33"><? echo $Name;?></td>
            <td height="33">&nbsp;</td>
            <td width="106" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td width="105" ><? echo $sid;?>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="21">Father's Name:</td>
            <td width="238" height="21">Mr. <? echo $FatherName;?></td>
            <td width="11" height="21">&nbsp;</td>
            <td>Roll No.:</td>
            <td><? echo $Roll_No;?>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="24">Mother's Name:</td>
            <td height="24">Mrs. <? echo $MotherName;?></td>
            <td height="24">&nbsp;</td>
            <td>Class:</td>
            <td><? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
              &nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="38">Mobile</td>
            <td height="38"><? echo $F_Mobile;?></td>
            <td height="38">&nbsp;</td>
            <td>Date Of Birth: </td>
            <td><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?>
              &nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="33">Address:</td>
            <td height="33" colspan="4"><? echo $Add_ReportC;?></td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="174"><? //if($ULevel=='9'){ ?>
          <table width="100%" height="156" border="1" align="center">
            <tr valign="top" bgcolor="#E8E8E8">
              <td height="30" class="st411">SCHOLASTIC AREA<br />
                (9 point scale)</td>
              <td colspan="4" class="st411" align="center">TERM I</td>
              <td colspan="4" class="st411" align="center">TERM II</td>
              <td colspan="4" align="center" class="st411">Final Assessment</td>
            </tr>
            <tr valign="top"  bgcolor="#C9C9C9">
              <td height="30" class="st411"><strong>Subjects</strong></td>
              <td class="st411">FA1
                10%</td>
              <td class="st411">FA2
                10%</td>
              <td width="31" class="st411">SA1
                30%</td>
              <td width="39" class="st411">Total 50%</td>
              <td width="30" class="st411">FA3
                10%</td>
              <td width="32" class="st411">FA4
                10%</td>
              <td width="33" class="st411">SA2
                30%</td>
              <td width="41" class="st411">Total 50%</td>
              <td width="37" class="st411">FA 40%</td>
              <td width="35" class="st411">SA 60%</td>
              <td width="106" class="st411"><span class="st4">Overall<br />
                (FA+SA=100%)</span></td>
              <td width="60" class="st411"><span class="st4">Grade Point</span></td>
            </tr>
            <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 	 $num_rows = mysql_num_rows($phi);  	while($pow=mysql_fetch_array($phi)){ $sb= $pow['SubjectId']; 
				 ?>
            <tr valign="top">
              <td width="144" height="16" class="st411"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
              <td width="30" class="st411"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='1' AND RD.`SubjectId`='$sb'   And RD.`Class` between  G.ClassFrom And 	G.ClassTo  ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></td>
              <td width="30" class="st411"><?php $gr2=mysql_query($ghyn2="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='2' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['Grade'];}?></td>
              <td class="st411"><?php $gr23=mysql_query($ghyn23="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g23=mysql_fetch_array($gr23)){echo $Gn23=$g23['Grade'];}?></td>
              <td class="st411"><?php $gr2=mysql_query($ghyn2="select FL.msid,FL.stu_id,FL.name ,FL.subject,FL.mo as percent,G.grade,G.gradepoint,FL.t from (select TG.msid,TG.stu_id,TG.name,TG.subject,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.name, term1.subject,term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.name,FA_PER.subjectid,FA_PER.subject, FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from (select FA1.msid,FA1.stu_id,FA1.name,RD.subjectid,sub.subject,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id ,S.name FROM `13Students` S  where S.id='$sid' And MSID='$msid' ) as FA1 inner join 21Repodata1 RD on RD.msid=FA1.msid and RD.studentid=FA1.stu_id   inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid where RD.Session='$session' And  RD.MSID='$msid' ) as FA_PER  ) as term1  inner join 22Weightage W on W.msid=term1.msid and W.assid=term1.assid and '$CClass' between W.classfrom and W.classto  ) as TG group by TG.subject,TG.t order by TG.t ) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and '$CClass' between G.classfrom and G.classto where FL.subjectid='$sb'  And FL.t ='1'  ORDER BY FL.subjectid"); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['grade'];}?>
                &nbsp;</td>
              <td class="st411"><?php $gr232=mysql_query($ghyn232="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='3' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g232=mysql_fetch_array($gr232)){ echo $Gn232=$g232['Grade'];}?></td>
              <td class="st411">&nbsp;
                <?php $gr233=mysql_query($ghyn233="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='4' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g233=mysql_fetch_array($gr233)){echo $Gn233=$g233['Grade'];}?></td>
              <td class="st411"><?php $gr234=mysql_query($ghyn234="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(RD.`MarksObtained`/RD.`MaxMarks`*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`='6' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And 	G.ClassTo ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($g234=mysql_fetch_array($gr234)){echo $Gn234=$g234['Grade'];}?></td>
              <td class="st411"><?php $gr2t2=mysql_query($ghyn2t2="select FL.msid,FL.stu_id,FL.name ,FL.subject,FL.mo as percent,G.grade,G.gradepoint,FL.t from (select TG.msid,TG.stu_id,TG.name,TG.subject,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.name, term1.subject,term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.name,FA_PER.subjectid,FA_PER.subject, FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from (select FA1.msid,FA1.stu_id,FA1.name,RD.subjectid,sub.subject,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id ,S.name FROM `13Students` S  where S.id='$sid' And MSID='$msid' ) as FA1 inner join 21Repodata1 RD on RD.msid=FA1.msid and RD.studentid=FA1.stu_id   inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid where RD.Session='$session' And  RD.MSID='$msid' ) as FA_PER  ) as term1  inner join 22Weightage W on W.msid=term1.msid and W.assid=term1.assid and '$CClass' between W.classfrom and W.classto  ) as TG group by TG.subject,TG.t order by TG.t ) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and '$CClass' between G.classfrom and G.classto where FL.subjectid='$sb'  And FL.t ='2'  ORDER BY FL.subjectid"); while($g2t2=mysql_fetch_array($gr2t2)){echo $Gn2t2=$g2t2['grade'];}?></td>
              <td class="st411"><?php $gr2f=mysql_query($ghyn2f="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(SUM(RD.`MarksObtained`)/ SUM(RD.`MaxMarks`)*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/ RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`<'5' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And G.ClassTo"); while($g2f=mysql_fetch_array($gr2f)){ echo $Gn2f=$g2f['Grade'];}?>
                &nbsp;</td>
              <td class="st411"><?php $gr2f1=mysql_query($ghyn2f1="SELECT RD.MSID,RD.`StudentId`,RD.`AssId`,RD.`SubjectId`,ROUND(SUM(RD.`MarksObtained`)/ SUM(RD.`MaxMarks`)*100,2) Percent,G.`Grade` FROM 
`21Repodata1` RD INNER Join 23Grades G ON (RD.`MarksObtained`/ RD.`MaxMarks`*100) Between G.`PercentFrom` AND 
G.`Percentto` AND RD.MSID=G.MSID WHERE RD.MSID='$msid' AND RD.`Session`='$session' AND RD.StudentId='$sid'  AND RD.`AssId`>'4' AND RD.`SubjectId`='$sb'  And RD.`Class` between  G.ClassFrom And G.ClassTo"); while($g2f1=mysql_fetch_array($gr2f1)){echo $Gn2f1=$g2f1['Grade'];}?></td>
              <td class="st411"><?php $gr2f11=mysql_query($ghyn2f11="select FL.msid,FL.stu_id,FL.name ,FL.subject,FL.mo as percent,G.grade, (G.gradepoint)as gpoint ,FL.t from (select TG.msid,TG.stu_id,TG.name,TG.subject,TG.subjectid,sum(TG.term_marks) as MO,TG.t from (select term1.msid,term1.stu_id,term1.name, term1.subject,term1.subjectid,term1.assid,term1.percent,ROUND(COALESCE((term1.percent/100)*W.termwt,0),2) as term_marks,W.term as t,W.assid as A from (select FA_PER.msid,FA_PER.stu_id,FA_PER.name,FA_PER.subjectid,FA_PER.subject, FA_PER.assid,ROUND(COALESCE((FA_PER.marksobtained/FA_PER.maxmarks)*100,0),2) as percent from (select FA1.msid,FA1.stu_id,FA1.name,RD.subjectid,sub.subject,RD.assid,RD.marksobtained,RD.maxmarks from (SELECT S.msid,S.id as stu_id ,S.name FROM `13Students` S  where S.id='$sid' And MSID='$msid' ) as FA1 inner join 21Repodata1 RD on RD.msid=FA1.msid and RD.studentid=FA1.stu_id   inner join 23subjects sub on sub.msid=FA1.msid and sub.id=RD.subjectid where RD.Session='$session' And  RD.MSID='$msid' ) as FA_PER  ) as term1  inner join 22Weightage W on W.msid=term1.msid and W.assid=term1.assid and '$CClass' between W.classfrom and W.classto  ) as TG group by TG.subject,TG.t order by TG.t ) as FL inner join 23Grades G on G.msid=FL.msid and FL.mo between G.percentfrom and G.percentto and '$CClass' between G.classfrom and G.classto where FL.subjectid='$sb' GROUP by FL.subject,FL.stu_id ORDER BY FL.subjectid");  while($g2f11=mysql_fetch_array($gr2f11)){echo $Gn2f11=$g2f11['grade']; $gradepoint=$g2f11['gpoint'];
 mysql_query($aq1="DELETE FROM `CGPA_Grade` WHERE `MSID`='$msid' and `SID`='$sid' and `Session`='$session' and `SUBID`='$sb' ");
mysql_query($aq1="INSERT INTO `CGPA_Grade` (`MSID`, `SID`, `SUBID`, `CGPA`, `Session`) VALUES ('$msid', '$sid', '$sb', '$gradepoint', '$session')");}?></td>
              <td class="st411"><? echo $gradepoint; ?></td>
            </tr>
            <?php   }
		  ?>
            <tr valign="top">
              <td height="17" class="st411">ATTENDANCE</td>
              <?php 
				 $att1=mysql_query($aq1="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='1'");
				 while($at1=mysql_fetch_array($att1)){ $Term1WD= $at1['TWD']; $Term1Att= $at1['TERMATT'];} ?>
              <td colspan="2" class="st411"><? echo $Term1Att ;?>/ <? echo $Term1WD ;?></td>
              <td colspan="2" class="st411"><? $tatt= ($Term1Att/$Term1WD) * 100 ; echo round($tatt,2) ;?>
                %</td>
              <?php 
				 $att1a2=mysql_query($aq1a2="Select * from `26TWDays` where SID='$sid' and MSID='$msid' and Session='$session' and Term='2'");
				 while($at1a2=mysql_fetch_array($att1a2)){ $Term1WDa2= $at1a2['TWD']; $Term1Atta2= $at1a2['TERMATT'];}?>
              <td colspan="2" class="st411"><? echo $Term1Atta2 ;?> / <? echo $Term1WDa2 ;?></td>
              <td colspan="2" class="st411"><? $tatta2= ($Term1Atta2/$Term1WDa2) * 100 ; echo round($tatta2,2) ;?>
                %</td>
              <td class="st411"><? echo $TotalAtt=$Term1Att+$Term1Atta2 ;?> / <? echo $TotalWD=$Term1WD+$Term1WDa2 ;?></td>
              <td class="st411"><? $TotalTermAtt= ($TotalAtt/$TotalWD) * 100 ; echo round($TotalTermAtt,2) ;?>
                %</td>
              <td class="st411">CGPA</td>
              <td class="st411"><? $gradeg=mysql_query($gradeg1="Select sum(CGPA)as sumcg from `CGPA_Grade` where MSID='$msid' and SID='$sid' and session='$session' group by SID"); 
				 while($gradeg11=mysql_fetch_array($gradeg)){ $sumcg= $gradeg11['sumcg']; echo $gradepoint= $sumcg/$num_rows;}?></td>
            </tr>
            <tr valign="top">
              <td height="25" colspan="13" align="left" class="st2">Nine point grading scale:A1=91%-100%;A2=81%-90%;B1=71%-80%;B2=61%-70%;c1=51%-60%;C2=41%-50%;D=33%-40%;E1=21%-32%;E2 =20% And Below</td>
            </tr>
          </table>
          <table width="100%" height="167" border="1" align="center">
            <tr valign="top" bgcolor="#E8E8E8">
              <td height="28" colspan="2" class="st4" align="center" valign="middle"><strong>SELF AWARENESS</strong></td>
            </tr>
            <tr valign="top">
              <td width="196" height="27" class="st4">My Goals</td>
              <td width="485" class="st4"><? $att1ss=mysql_query($aq1ss="Select * from `21Repodata4self` where SID='$sid' And `head`='Goals' and session='$session' and msid='$msid'");
				 while($at1ss=mysql_fetch_array($att1ss)){ echo $self1= $at1ss['desc']; } ?></td>
            </tr>
            <tr valign="top">
              <td height="24" class="st4">Strengths</td>
              <td class="st4"><? $att2ss=mysql_query($aq2ss="Select * from `21Repodata4self` where SID='$sid' And `head`='Strength' and session='$session' and msid='$msid'");
				 while($at2ss=mysql_fetch_array($att2ss)){ echo $self2= $at2ss['desc']; } ?></td>
            </tr>
            <tr valign="top">
              <td height="25" class="st4">My Interests  And Hobbies</td>
              <td class="st4"><? $att3ss=mysql_query($aq3ss="Select * from `21Repodata4self` where SID='$sid' And `head`='Interest And hobbies' and session='$session' and msid='$msid'");
				 while($at3ss=mysql_fetch_array($att3ss)){ echo $self3= $at3ss['desc']; } ?></td>
            </tr>
            <!-- <tr valign="top">
                  <td height="44" class="st4">Responsibilities Discharged / Exceptional Achievments</td>
                  <td class="st4"><? /*$att4ss=mysql_query($aq4ss="Select * from `repodata4self` where SID='$sid' And `Grade`='Responsibilities Discharged'");
				 while($at4ss=mysql_fetch_array($att4ss)){ echo $self4= $at4ss['Indicator']; }*/ ?></td>
                </tr>-->
          </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="123" valign="top"><table width="100%" height="151" border="0" align="center">
          <tr>
            <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: &nbsp;&nbsp;Congratulations
              <? $trjjrm=mysql_query($qjjrm="Select Remarks from 21Remarks where SID='$sid' AND  MSID='$msid'  AND Session='$session'");
				 while($ttjjrm=mysql_fetch_array($trjjrm)){ echo $remarks=$ttjjrm['Remarks']; }?>
            </strong><br/></td>
          </tr>
          <? //}else {}?>
          <tr>
            <td height="26" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>
              <!--Note:</strong>(1)Promotion is based on the day -to -day continuous assessment throughout the year.(2) CGPA=Cumulative Grade Point Average (3) Subject Wise/Overall indicative percentage of Marks=9.5 X GP of the subject /CGPA.--></td>
          </tr>
          <tr>
            <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
            <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<p class="page"></p>
<table width="750" border="1"   align="center" >
  <tr>
    <td><table width="100%" height="804" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top">
        <td height="19" align="center" class="st4"><strong style="font-family:'Comic Sans MS', cursive; font-size:18px"><u>(Grading On Five Point Scale A,B,C,D,E)</u></strong></td>
      </tr>
      <tr align="left" valign="top">
        <td height="78"><table width="100%" height="693" border="1" align="center">
          <tr valign="top">
            <td height="22" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 2 (A)-LIFE SKILLS</strong></td>
          </tr>
          <tr valign="top" >
            <td width="44" height="32" class="st4" valign="middle">Sr.No.</td>
            <td width="253" class="st4" valign="middle">Area of Assessment</td>
            <td width="38" class="st4" valign="middle">Grade</td>
            <td width="331" class="st4" valign="middle">Descriptive Indicators</td>
          </tr>
          <tr valign="top">
            <td height="36" class="st4">01</td>
            <td class="st4">THINKING SKILLS</td>
            <td class="st4"><?php 
			 $tr=mysql_query($q="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and `Particular`='THINKING SKILLS' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt=mysql_fetch_array($tr)){ $sb= $tt['Marks']; $tr102=mysql_query($q102="Select * from grade2 where GRADE_ID='$sb'");
				 while($tt102=mysql_fetch_array($tr102)){ echo  $sb102= $tt102['GRADE_NAME']; } ?></td>
            <td class="st4"><?php  $sb1= $tt['Indicator']; echo "$Name "." $sb1"; } ?></td>
          </tr>
          <tr valign="top">
            <td height="34" class="st4">02</td>
            <td class="st4">SOCIAL SKILLS</td>
            <td class="st4"><?php 
				 $tr1=mysql_query($q1="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SOCIAL SKILLS' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt1=mysql_fetch_array($tr1)){ $sbg= $tt1['Marks']; $tr102=mysql_query($q102="Select * from grade2 where GRADE_ID='$sbg'");
				 while($tt102=mysql_fetch_array($tr102)){echo  $sb102= $tt102['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi= $tt1['Indicator']; echo "$Name "." $sbi";}   ?></td>
          </tr>
          <tr valign="top">
            <td height="35" class="st4">03</td>
            <td class="st4">EMOTIONAL SKILLS </td>
            <td class="st4"><?php 
				$tr2=mysql_query($q2="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='EMOTIONAL SKILLS' and MSID='$msid' and Session='$session' and Term='2'  ");
				 while($tt2=mysql_fetch_array($tr2)){ $sbg1= $tt2['Marks']; $tr103=mysql_query($q103="Select * from grade2 where GRADE_ID='$sbg1'");
				 while($tt103=mysql_fetch_array($tr103)){echo  $sb103= $tt103['GRADE_NAME']; } ?></td>
            <td class="st4"><?php  $sbi1= $tt2['Indicator']; echo "$Name "." $sbi1";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="37" class="st4"><strong>2(B)</strong></td>
            <td class="st4">WORK EDUCATION</td>
            <td class="st4"><?php 
				 $tr3=mysql_query($q3="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='WORK EDUCATION' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt3=mysql_fetch_array($tr3)){ $sbg3= $tt3['Marks']; $tr104=mysql_query($q104="Select * from grade2 where GRADE_ID='$sbg3'");
				 while($tt104=mysql_fetch_array($tr104)){echo  $sb104= $tt104['GRADE_NAME']; }?></td>
            <td class="st4"><?php  $sbi3= $tt3['Indicator']; echo "$Name "." $sbi3";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="37" class="st4"><strong>2(C)</strong></td>
            <td class="st4">VISUAL AND PERFORMING ARTS</td>
            <td class="st4"><?php 
				 $tr4=mysql_query($q4="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='VISUAL AND PERFORMING ARTS' and MSID='$msid' and Session='$session' and Term='2'  ");
				 while($tt4=mysql_fetch_array($tr4)){ $sbg4= $tt4['Marks']; $tr105=mysql_query($q105="Select * from grade2 where GRADE_ID='$sbg4'");
				 while($tt105=mysql_fetch_array($tr105)){echo  $sb105= $tt105['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi4= $tt4['Indicator']; echo "$Name "." $sbi4";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="21" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 2 (D)-ATTITUDE &amp; VALUES</strong></td>
          </tr>
          <tr valign="top">
            <td height="33" class="st4">1.0</td>
            <td colspan="3" class="st4">ATTITUDE TOWARDS</td>
          </tr>
          <tr valign="top">
            <td height="33" class="st4">1.1</td>
            <td class="st4">TEACHERS</td>
            <td class="st4"><?php 
				 $tr5=mysql_query($q5="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='TEACHERS' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt5=mysql_fetch_array($tr5)){ $sbg5= $tt5['Marks']; $tr106=mysql_query($q106="Select * from grade2 where GRADE_ID='$sbg5'");
				 while($tt106=mysql_fetch_array($tr106)){echo  $sb106= $tt106['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi5= $tt5['Indicator']; echo "$Name "." $sbi5";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="33" class="st4">1.2</td>
            <td class="st4">SCHOOL-MATES</td>
            <td class="st4"><?php 
				 $tr16=mysql_query($q16="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCHOOL MATES' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt16=mysql_fetch_array($tr16)){$sbg16= $tt16['Marks']; $tr107=mysql_query($q107="Select * from grade2 where GRADE_ID='$sbg16'");
				 while($tt107=mysql_fetch_array($tr107)){echo  $sb107= $tt107['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi16= $tt16['Indicator']; echo "$Name "." $sbi16";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="40" class="st4">1.3</td>
            <td class="st4">SCHOOL PROGRAMMES &amp; ENVIORNMENT</td>
            <td class="st4"><?php 
				 $tr6=mysql_query($q6="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCHOOL PROGRAMMES AND ENVIRONMENT' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt6=mysql_fetch_array($tr6)){  $sbg6= $tt6['Marks']; $tr108=mysql_query($q108="Select * from grade2 where GRADE_ID='$sbg6'");
				 while($tt108=mysql_fetch_array($tr108)){echo  $sb108= $tt108['GRADE_NAME']; } ?></td>
            <td class="st4"><?php  $sbi6= $tt6['Indicator']; echo "$Name "." $sbi6";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="37" class="st4">2.0</td>
            <td class="st4">VALUE SYSTEM</td>
            <td class="st4"><?php 
				 $tr7=mysql_query($q7="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='VALUE SYSTEMS' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt7=mysql_fetch_array($tr7)){  $sbg7= $tt7['Marks']; $tr109=mysql_query($q109="Select * from grade2 where GRADE_ID='$sbg7'");
				 while($tt109=mysql_fetch_array($tr109)){echo  $sb109= $tt109['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi7= $tt7['Indicator']; echo "$Name "." $sbi7";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="21" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 3 (A) CO-SCHOLASTIC ACTIVITIES</strong></td>
          </tr>
          <tr valign="top">
            <td height="35" class="st4">01</td>
            <td class="st4">LITERARY &amp; CREATIVE SKILLS</td>
            <td class="st4"><?php 
				 $tr8=mysql_query($q8="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='LITERARY AND CREATIVE SKILLS' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt8=mysql_fetch_array($tr8)){  $sbg8= $tt8['Marks']; $tr110=mysql_query($q110="Select * from grade2 where GRADE_ID='$sbg8'");
				 while($tt110=mysql_fetch_array($tr110)){echo  $sb110= $tt110['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi8= $tt8['Indicator']; echo "$Name "." $sbi8";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="32" class="st4">02</td>
            <td class="st4">SCIENTIFIC SKILLS</td>
            <td class="st4"><?php 
				 $tr9=mysql_query($q9="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SCIENTIFIC SKILLS' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt9=mysql_fetch_array($tr9)){  $sbg9= $tt9['Marks']; $tr111=mysql_query($q111="Select * from grade2 where GRADE_ID='$sbg9'");
				 while($tt111=mysql_fetch_array($tr111)){echo  $sb111= $tt111['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi9= $tt9['Indicator']; echo "$Name "." $sbi9";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="21" colspan="4" class="st4" valign="middle" bgcolor="#E8E8E8"><strong>PART 3 (b) HEALTH AND PHYSICAL EDUCATION</strong></td>
          </tr>
          <tr valign="top">
            <td height="35" class="st4">01</td>
            <td class="st4">YOGA</td>
            <td class="st4"><?php 
				 $tr10=mysql_query($q10="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='Yoga' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt10=mysql_fetch_array($tr10)){ $sbg10= $tt10['Marks']; $tr112=mysql_query($q112="Select * from grade2 where GRADE_ID='$sbg10'");
				 while($tt112=mysql_fetch_array($tr112)){echo  $sb112= $tt112['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi10= $tt10['Indicator']; echo "$Name "." $sbi10";}  ?></td>
          </tr>
          <tr valign="top">
            <td height="15" class="st4">02</td>
            <td class="st4">SPORTS/ INDIGENOUS SPORTS</td>
            <td class="st4"><?php 
				 $tr11=mysql_query($q11="Select * from 21Repodata2 where StudentID='$sid' and Session='$session' and Particular='SPORTS' and MSID='$msid' and Session='$session' and Term='2' ");
				 while($tt11=mysql_fetch_array($tr11)){ $sbg11= $tt11['Marks']; $tr113=mysql_query($q113="Select * from grade2 where GRADE_ID='$sbg11'");
				 while($tt113=mysql_fetch_array($tr113)){echo  $sb113= $tt113['GRADE_NAME']; } ?></td>
            <td class="st4"><?php $sbi11= $tt11['Indicator']; echo "$Name "." $sbi11";}  ?></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table width="100%" border="1">
          <?php 
				 $tr12=mysql_query($q12="Select * from 21Repodata4healthsts where MSID='$msid' and StudentID='$sid' and Session='$session'");
				 while($tt12=mysql_fetch_array($tr12)){$height= $tt12['Height']; $weight= $tt12['Weight']; $bgroup= $tt12['Blood_group'];
				 $dental= $tt12['DentalHygiene'];  }?>
          <tr>
            <td width="27%" rowspan="2" class="st4" align="center" valign="middle" bgcolor="#E8E8E8" ><strong>HEALTH DATA</strong></td>
            <td width="9%" class="st4" align="center">HEIGHT</td>
            <td width="9%" class="st4" align="center">WEIGHT</td>
            <!--<td width="10%" height="26" class="st4" align="center">BLOOD GROUP</td>-->
            <!--<td width="31%" align="center" class="st4">DENTAL HYGIENE</td>-->
          </tr>
          <tr>
            <td height="23" align="center" class="st4"><? echo $height; ?></td>
            <td align="center" class="st4"><? echo $weight; ?></td>
            <!--<td align="center" class="st4"><? /*echo $bgroup ;*/ ?></td>-->
            <!-- <td align="center" class="st4"><? //echo $dental ; ?></td>-->
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<?php }}?>
</p></body>
</html>
