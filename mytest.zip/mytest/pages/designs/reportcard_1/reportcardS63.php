<?php 
session_start();
include("../../connect/db.php");  
      $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
$n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }
if($_POST){$sid=$_POST['c'];
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
}else {
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
 $id1=$_GET['id'];$sid = mysql_real_escape_string($id1);}


$result5=mysql_query($sql5="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id  and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And '$dm' between S.FSDate AND S.SLDate And S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$sid' And P.MSID='$msid'"  );
while($gow5=mysql_fetch_array($result5)){  $sid= $gow5['sid']; $Name= $gow5['Name'];
$BirthDate= $gow5['BirthDate'];
$PID= $gow5['PID'];  $AdmNo= $gow5['AdmNo']; $Roll_No= $gow5['Roll_No'];$CClass= $gow5['CClass']; $Photo= $gow5['Photo'];
$Section= $gow5['Section'];
$FatherName= $gow5['FatherName'];
$F_Mobile= $gow5['F_Mobile'];
$MobileSMS= $gow5['MobileSMS'];
$MotherName= $gow5['MotherName'];
$Village1= $gow5['Village1'];
 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate'];  
$Add_ReportC= $row['Add_ReportC'];

} ?>::Report Card</title>
 <style>
p.page { page-break-after: always; }
 </style>
<style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

.style12 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.st41 { 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st42 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.st411 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.st412 {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}.vks {
	font-family: "Comic Sans MS", cursive;
}
.b1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.m1 {	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.n1 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
</style>
</head>
      <body>  <style>
p.page { page-break-after: always; }
</style>       <style type="text/css">
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.b1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 15px; 
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
-->
</style>
<table width="750" height="737" border="1"   align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td height="731"><table width="100%" height="725" align="center" bordercolor="#2A3F00">
      <tr align="left" valign="top"></tr>
      <tr align="left" valign="top">
        <td width="704" height="204" align="center"><table width="100%" height="202" align="center">
          <tr>
            <td width="87" height="196" align="left" valign="top"><table width="88" border="0" align="center">
              <tr>
                <td width="82" height="92"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
              </tr>
            </table></td>
            <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
              <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
              <tr>
                <td width="539" height="40" align="center" class="m1"><?php echo $sname;?></td>
              </tr>
              <tr>
                <td height="30" align="center" class="b1"><? echo   $Place;  ?></td>
              </tr>
              <tr>
                <td height="31" align="center" class="n1">Website:<? echo $Website;?>,E-mail:<? echo $EMail;?>,Ph:<? echo $Phone;?></td>
              </tr>
              <tr>
                <td height="25" align="center" class="n1">Affiliated to CBSE ,Delhi ,Affiliation No.:<? echo $AffiliationNo;?></td>
              </tr>
            </table>
              <p class="vks">Record of Academic Performance <? echo $session; ?></p></td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="163"><table width="100%" height="168" border="0" align="center">
          <tr valign="top" class="st42">
            <td width="139" rowspan="5"><img style=" padding:3px; border:1px #333333 solid; border-radius:5px 5px 5px 5px;" src="<?php  if($Photo!=""){echo $Photo;} else { 	echo"../../images/myprofile1.png";} ?>" width="122" height="127" /></td>
            <td width="105">Name :<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td height="33"><? echo $Name;?></td>
            <td height="33">&nbsp;</td>
            <td width="106" >Admission No:<strong>&nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
            <td width="105" ><? echo $sid;?>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="28">Father's Name:</td>
            <td width="238" height="28">Mr. <? echo $FatherName;?></td>
            <td width="11" height="28">&nbsp;</td>
            <td>Roll No.:</td>
            <td><? echo $Roll_No;?>&nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="30">Mother's Name:</td>
            <td height="30">Mrs. <? echo $MotherName;?></td>
            <td height="30">&nbsp;</td>
            <td>Class:</td>
            <td><? 
$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid'");
	  while($row2=mysql_fetch_array($result2)){ echo $row2['ClassName'];  }?>
              &nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="32">Mobile</td>
            <td height="32"><? echo $F_Mobile;?></td>
            <td height="32">&nbsp;</td>
            <td>Date Of Birth: </td>
            <td><? $BirthDate;echo $newdate1 = date('d-m-Y', strtotime($BirthDate));?>
              &nbsp;</td>
          </tr>
          <tr valign="top" class="st42">
            <td height="33">Address:</td>
            <td height="33" colspan="4"><? echo $Add_ReportC;?></td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="middle">
        <td height="174">
          <table width="100%" height="183" border="1" align="center">
            <tr valign="middle" align="center" bgcolor="#E8E8E8">
              <td height="43" class="st411" align="left"><strong>SCHOLASTIC AREA</strong><br /></td>
              <td colspan="4" class="st411"><strong>TERM I</strong></td>
              <td colspan="4" class="st411"><strong>TERM II</strong></td>
              <td colspan="3" class="st411"><strong>Final Assessment</strong></td>
            </tr>
            <tr valign="top"  bgcolor="#C9C9C9">
              <td height="30" class="st411"><strong>Subjects</strong></td>
              <td class="st411">Unit-I</td>
              <td class="st411">Unit-II</td>
              <td width="47" class="st411">Term-I</td>
              <td width="44" class="st411">Total </td>
              <td width="50" class="st411">Unit-III</td>
              <td width="50" class="st411">Unit-IV</td>
              <td width="47" class="st411">Term-II</td>
              <td width="39" class="st411">Total </td>
              <td width="38" class="st411">Unit</td>
              <td width="37" class="st411">Term</td>
              <td width="80" class="st411"><span class="st4">Overall<br />
                (Unit+Term)</span></td>
              </tr>
            <?php 	
 $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$sid'"); 	 $num_rows = mysql_num_rows($phi);  	while($pow=mysql_fetch_array($phi)){ $sb= $pow['SubjectId']; 
				 ?>
            <tr valign="middle" align="center">
              <td width="138" height="38" class="st411" align="left"><?  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];}?></td>
              <td width="38" class="st411"><?php   $ghiy8=mysql_query($ghy8="SELECT * FROM 
`21Repodata1` WHERE MSID='$msid' AND `Session`='$session' AND StudentId='$sid'  AND `AssId`='1' AND `SubjectId`='$sb'"); while($gowy8=mysql_fetch_array($ghiy8)){$Grade8=$gowy8['MarksObtained']; echo round($Grade8);}?></td>
              <td width="46" class="st411"><?php $gr2=mysql_query($ghyn2="SELECT * FROM 
`21Repodata1` WHERE MSID='$msid' AND `Session`='$session' AND StudentId='$sid'  AND `AssId`='2' AND `SubjectId`='$sb'"); while($g2=mysql_fetch_array($gr2)){ $Gn2=$g2['MarksObtained'];  echo round($Gn2); }?></td>
              <td class="st411"><?php $gr23=mysql_query($ghyn23="SELECT * FROM 
`21Repodata1` WHERE MSID='$msid' AND `Session`='$session' AND StudentId='$sid'  AND `AssId`='5' AND `SubjectId`='$sb'"); while($g23=mysql_fetch_array($gr23)){echo $Gn23=$g23['MarksObtained'];}?></td>
              <td class="st411"><?php $gr2=mysql_query($ghyn2="SELECT SUM(`MarksObtained`) as summarks FROM `21Repodata1` Where `MSID`='$msid' and `Session`='$session' And `AssId`='1' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='2' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='5' And `StudentId`='$sid' And `SubjectId`='$sb' "); while($g2=mysql_fetch_array($gr2)){echo $Gn2=$g2['summarks'];}?>
              </td>
              <td class="st411"><?php $gr232=mysql_query($ghyn232="SELECT * FROM 
`21Repodata1` WHERE MSID='$msid' AND `Session`='$session' AND StudentId='$sid'  AND `AssId`='3' AND `SubjectId`='$sb'"); while($g232=mysql_fetch_array($gr232)){ echo $Gn232=$g232['MarksObtained'];}?></td>
              <td class="st411">
                <?php $gr233=mysql_query($ghyn233="SELECT * FROM 
`21Repodata1` WHERE MSID='$msid' AND `Session`='$session' AND StudentId='$sid'  AND `AssId`='4' AND `SubjectId`='$sb'"); while($g233=mysql_fetch_array($gr233)){echo $Gn233=$g233['MarksObtained'];}?></td>
              <td class="st411"><?php $gr234=mysql_query($ghyn234="SELECT * FROM 
`21Repodata1` WHERE MSID='$msid' AND `Session`='$session' AND StudentId='$sid'  AND `AssId`='6' AND `SubjectId`='$sb'"); while($g234=mysql_fetch_array($gr234)){echo $Gn234=$g234['MarksObtained'];}?></td>
              <td class="st411"><?php $gr2t2=mysql_query($ghyn2t2="SELECT SUM(`MarksObtained`) as summarks FROM `21Repodata1` Where `MSID`='$msid' and `Session`='$session' And `AssId`='3' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='4' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='6' And `StudentId`='$sid' And `SubjectId`='$sb'"); while($g2t2=mysql_fetch_array($gr2t2)){echo $Gn2t2=$g2t2['summarks'];}?></td>
              <td class="st411"><?php $gr2f=mysql_query($ghyn2f="SELECT SUM(`MarksObtained`) as summarks FROM `21Repodata1` Where `MSID`='$msid' and `Session`='$session' And `AssId`='1' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='2' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='3' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='4' And `StudentId`='$sid' And `SubjectId`='$sb'"); while($g2f=mysql_fetch_array($gr2f)){ echo $Gn2f=$g2f['summarks'];}?>
                &nbsp;</td>
              <td class="st411"><?php $gr2f1=mysql_query($ghyn2f1="SELECT SUM(`MarksObtained`) as summarks FROM `21Repodata1` Where `MSID`='$msid' and `Session`='$session' And `AssId`='5' And `StudentId`='$sid' And `SubjectId`='$sb' OR `MSID`='$msid' and `Session`='$session' And `AssId`='6' And `StudentId`='$sid' And `SubjectId`='$sb'"); while($g2f1=mysql_fetch_array($gr2f1)){echo $Gn2f1=$g2f1['summarks'];}?></td>
              <td class="st411"><?php $gr2f11=mysql_query($ghyn2f11="SELECT SUM(`MarksObtained`) as summarks FROM `21Repodata1` Where `MSID`='$msid' and `Session`='$session' And `StudentId`='$sid' And `SubjectId`='$sb'");  while($g2f11=mysql_fetch_array($gr2f11)){echo $Gn2f11=$g2f11['summarks']; }?></td>
              </tr>
            <?php   }
		  ?>
           <tr valign="middle">
                  <td height="42" colspan="10" align="left" class="st411"><strong>Total</strong></td>
                  <td height="42" colspan="2"  align="center" class="st411"><strong><?php $gr2f113=mysql_query($ghyn2f113="SELECT SUM(`MarksObtained`) as summarks FROM `21Repodata1` Where `MSID`='$msid' and `Session`='$session' And `StudentId`='$sid'");  while($g2f113=mysql_fetch_array($gr2f113)){echo $Gn2f113=$g2f113['summarks']; }?>/<?php $gr2f1131=mysql_query($ghyn2f1131="SELECT SUM(`MaxMarks`) as summax FROM `21Repodata1` Where `MSID`='$msid' and `Session`='$session' And `StudentId`='$sid'");  while($g2f1131=mysql_fetch_array($gr2f1131)){echo $Gn2f1131=$g2f1131['summax']; }?>
                  <br /> (<? $percentage=($Gn2f113/$Gn2f1131)*100; echo round($percentage,1)?>%)</strong>&nbsp;</td>
                </tr>
          </table></td>
      </tr>
      <tr align="left" valign="top">
        <td height="153" valign="top"><table width="100%" height="151" border="0" align="center">
          <tr>
            <td height="53" colspan="3" align="left" class="st2" valign="middle" style="text-transform:capitalize"><strong>REMARKS: &nbsp;&nbsp;
              <? $trjjrm=mysql_query($qjjrm="Select Remarks from 21Remarks where SID='$sid' AND  MSID='$msid'  AND Session='$session'");
				 while($ttjjrm=mysql_fetch_array($trjjrm)){ echo $remarks=$ttjjrm['Remarks']; }?>
            </strong><br/></td>
          </tr>
       
          <tr></tr>
          <tr>
            <td width="234" height="62" align="center" valign="bottom" class="st411">Class Teacher's Signature</td>
            <td width="197" align="center" valign="bottom"><span class="st411">Principal's Signature</span><strong><span class="st411"></span></strong></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
  <p class="page"></p>
  <?php }}?>
</p></body>
</html>
