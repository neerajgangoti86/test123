<?php
session_start();
include("../../connect/db.php");  
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {   $foo =$_SESSION['admin']; $cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);  $sec1=$_GET['s'];$sec = mysql_real_escape_string($sec1);
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php   $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Post= $row['Post'];
$Distt= $row['Distt'];
$State= $row['State'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail'];
$Website= $row['Website'];
$TermDate= $row['TermDate'];  
$Add_ReportC= $row['Add_ReportC'];

}?>

</title>
<link rel="stylesheet" type="text/css"  href="../../css/report.css"  /></head>
 
 <style type="text/css">
<!--
.style190 {	color: #FFFFFF;
	
}
.style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; }

 .st3 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 15px;
 
}.st2 {
 
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
 
}
.st4 { text-transform:capitalize; font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
}
.vks {
	font-family: "Comic Sans MS", cursive;
}
</style>

<body><style>
p.page { page-break-after: always; }
</style>

<table width="853" border="1" align="center" cellpadding="2" cellspacing="2">
      <tr>
        <td width="841"><table width="100%" height="365" align="center" bordercolor="#2A3F00">
          <tr align="left" valign="top">
            <td width="875" height="76"><table width="100%" height="132" align="center">
          <tr>
            <td width="147" height="25" align="center" valign="top"><span class="n1">Affiliation No.:<? echo $AffiliationNo;?></span></td>
            <td width="864" rowspan="3" align="center" valign="top"><table width="100%" border="0" align="center">
              <!--    <tr>
                        <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                      </tr>-->
              <tr>
                <td width="539" height="32" align="center" class="m1"><?php echo $sname;?></td>
              </tr>
              <tr>
                <td height="19" align="center" class="b1">(SENIOR SECONDARY)</td>
              </tr>
              <tr>
                <td height="14" align="center" class="b1"><? echo   $Place;  ?></td>
              </tr>
              <tr>
                <td height="14" align="center" class="b1">(Affiliated to C.B.S.E. , New Delhi)</td>
              </tr>
              <tr>
                <td height="24" align="center" class="b1"><!--Website:<? //echo $Website;?>,-->E-mail:<? echo $EMail;?></td>
              </tr>
              </table>
             </td>
          </tr>
          <tr>
            <td height="20" align="center" valign="top"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " alt="" width="78" height="75" /></td>
          </tr>
          <tr>
            <td height="20" align="center" valign="top"><span class="n1">School No.:<? echo $SchoolNo;?></span></td>
          </tr>
        </table></td>
          </tr>
          <tr align="left" valign="top">
            <td height="4"></td>
          </tr>
          <tr align="left" valign="top">
            <td height="218" align="center" valign="top" class="vks">
              <table width="100%" height="201" border="1">
                    <tr bgcolor="#E4E4E4">
                      <td height="42" colspan="21" align="center" class="st4"><strong>Report For Class 
                      <?php $result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$cno' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){     $ClassName=$row2['ClassName'];    } echo $ClassName;?></strong></td>
                    </tr>
                                         <tr>
                      <td width="174" rowspan="3" class="st4"><strong >Subject</strong></td>
                      <td colspan="20" align="center" class="st4"><strong>MARKS OBTAINED</strong></td>
                    </tr>
                  
                    <tr>
                      <td colspan="2" align="center" class="st4"><strong>FA1</strong></td>
                      <td colspan="2" align="center" class="st4"><strong>FA2</strong></td>
                      <td colspan="3" align="center" class="st4"><strong>SA1</strong></td>
                      <td colspan="2" align="center" class="st4"><strong>Overall</strong></td>
                      <td colspan="2" align="center" class="st4"><strong>FA3</strong></td>
                      <td colspan="2" align="center" class="st4"><strong>FA4</strong></td>
                      <td colspan="3" align="center" class="st4"><strong>SA2</strong></td>
                      <td colspan="2" align="center" class="st4"><strong>Overall</strong></td>
                      <td colspan="2" align="center" class="st4"><span class="st41"><strong>Overall</strong></span></td>
                    </tr>
                    <tr>
                      <td width="42" align="center" class="st4"><strong>Marks</strong></td>
                      <td width="38" align="center" class="st4"><strong>Grade</strong></td>
                      <td width="41" align="center" class="st4"><strong><span class="st41">Marks</span></strong></td>
                      <td width="27" align="center" class="st4"><strong><span class="st41">Grade</span></strong></td>
                      <td width="22" align="center" class="st4"><strong><span class="st41">Marks</span></strong></td>
                      <td width="22" align="center" class="st4"><strong><span class="st41">Marks(W)</span></strong></td>
                      <td width="39" align="center" class="st4"><strong><span class="st41">Grade</span></strong></td>
                       <td width="46" align="center" class="st4"><strong><span class="st41">FA+SA<br />
                       Total<br />
                       </span></strong></td>
                      <td width="39" align="center" class="st4"><strong><span class="st41">Grade</span></strong></td>
                      <td width="45" align="center" class="st4"><strong><span class="st41">Marks</span></strong></td>
                      <td width="36" align="center" class="st4"><strong><span class="st41">Grade</span></strong></td>
                      <td width="41" align="center" class="st4"><strong><span class="st41">Marks</span></strong></td>
                      <td width="46" align="center" class="st4"><strong><span class="st41">Grade</span></strong></td>
                      <td width="26" align="center" class="st4"><strong><span class="st41">Marks</span></strong></td>
                      <td width="26" align="center" class="st4"><strong><span class="st41">Marks(W)</span></strong></td>
                      <td width="43" align="center" class="st4"><strong><span class="st41">Grade</span></strong></td>
                       <td width="46" align="center" class="st4"><strong><span class="st41">FA+SA<br />
Total</span></strong></td>
                      <td width="18" align="center" class="st4"><strong><span class="st41">Grade</span></strong></td>
                      <td width="19" align="center" class="st4"><strong><span class="st41">T1+T2<br />
Total</span></strong><br />
                        </td>
                      <td width="19" align="center" class="st4"><strong><span class="st41"> Grade</span></strong></td>
                    </tr>
                  
                    <? $result=mysql_query($gh="SELECT (S.Id) as sid,S.*,P.*,L.*, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' and  S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Section='$sec' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0)  Order by S.Name Asc"); while($row=mysql_fetch_array($result)){  $s_id=$row['sid']; $CClass=$row['CClass'];
$name=$row['Name']; //$stream=$row['Stream']; ?>
<tr><td height="24" colspan="21" align="center" class="st4" bgcolor="#C5C5C5"><strong>Student ID:&nbsp;&nbsp;<? echo $s_id; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Name:&nbsp;&nbsp;<? echo $name; ?> </strong></td></tr>
                     
					<?php $phi=mysql_query($ph="SELECT distinct SubjectId FROM `21Repodata1` Where  MSID='$msid' and Session='$session' and StudentId='$s_id'"); 		while($pow=mysql_fetch_array($phi)){ ?>
                   <tr>
                      <td height="22" valign="top" class="st4"><? $sb= $pow['SubjectId'];  $phig=mysql_query($phg="SELECT Subject FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg=mysql_fetch_array($phig)){echo $Subject= $powg['Subject'];} ?></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy=mysql_query($ghy="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='1' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId` "); while($gowy=mysql_fetch_array($ghiy)){echo $Marks_obtained=$gowy['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><?php   $ghiy8=mysql_query($ghy8="SELECT RD.msid,G.`Grade` ,RD.`SubjectId`,(RD.MarksObtained/RD.MaxMarks*W.OverallWt) as whhtge,((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER Join 23Grades G ON ((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100) Between G.`PercentFrom` AND G.`Percentto` AND RD.MSID=G.MSID  WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND RD.`AssId`='1'  AND W.`AssId`='1' and W.`MSID`='$msid' and RD.`SubjectId`='$sb' and '$CClass' between W.classfrom and W.classto  and '$CClass' between G.classfrom and G.classto"); while($gowy8=mysql_fetch_array($ghiy8)){echo $Grade8=$gowy8['Grade'];}?></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy1=mysql_query($ghy1="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='2' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy1=mysql_fetch_array($ghiy1)){echo $Marks_obtained1=$gowy1['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy9=mysql_query($ghy9="SELECT RD.msid,G.`Grade` ,RD.`SubjectId`,(RD.MarksObtained/RD.MaxMarks*W.OverallWt) as whhtge,((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER Join 23Grades G ON ((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100) Between G.`PercentFrom` AND G.`Percentto` AND RD.MSID=G.MSID  WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND RD.`AssId`='2'  AND W.`AssId`='2' and W.`MSID`='$msid' and RD.`SubjectId`='$sb' and '$CClass' between W.classfrom and W.classto  and '$CClass' between G.classfrom and G.classto"); while($gowy9=mysql_fetch_array($ghiy9)){echo $Grade9=$gowy9['Grade'];}?>
                      </span></td>
                      <td align="center" valign="top" class="st4"><? $phig1=mysql_query($phg1="SELECT * FROM `subjects` Where  MSID='$msid' And ID='$sb'"); 		while($powg1=mysql_fetch_array($phig1)){$Overall_grade1= $powg1['Overall_grade']; if($Overall_grade1=='1'){  $ghiy2=mysql_query($ghy2="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='5' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy2=mysql_fetch_array($ghiy2)){echo $Marks_obtained2=$gowy2['MarksObtained'];} }else{} }?></td>



                      <td align="center" valign="top" class="st4"> <?   $nhiy10=mysql_query($nhy10="SELECT RD.msid, RD.`SubjectId`,round(SUM(RD.MarksObtained/RD.MaxMarks*W.OverallWt),2) as whhtge  , round(SUM(RD.MaxMarks/W.OverallWt*10)) as MXMKS,round(sum(RD.MarksObtained/RD.MaxMarks*W.OverallWt)/Sum(W.OverallWt)*100,2)as pge  FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER JOIN subjects S on S.msid=RD.msid and S.ID=RD.SubjectId and '$CClass' between S.ClassFrom and S.ClassTo WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass'  AND W.`AssId`='5'  AND RD.`AssId`='5' and W.`MSID`='$msid' and '$CClass' between W.classfrom and W.classto And S.Overall_grade='1' And SubjectId='$sb'");
					   while($nowy10=mysql_fetch_array($nhiy10)){
						  echo $whhtge10=$nowy10['whhtge'];}  ?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy10=mysql_query($ghy10="SELECT RD.msid,G.`Grade` ,RD.`SubjectId`,(RD.MarksObtained/RD.MaxMarks*W.OverallWt) as whhtge,((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER Join 23Grades G ON ((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100) Between G.`PercentFrom` AND G.`Percentto` AND RD.MSID=G.MSID  WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND RD.`AssId`='5'  AND W.`AssId`='5' and W.`MSID`='$msid' and RD.`SubjectId`='$sb' and '$CClass' between W.classfrom and W.classto  and '$CClass' between G.classfrom and G.classto  "); while($gowy10=mysql_fetch_array($ghiy10)){echo $Grade10=$gowy10['Grade'];}?>
                      </span></td>
                        <td align="center" valign="top" class="st4"> <?  $ghiy112=mysql_query($ghy112="SELECT RD.msid, RD.`SubjectId`,round(SUM(RD.MarksObtained/RD.MaxMarks*W.OverallWt),2) as whhtge  , round(SUM(RD.MaxMarks/W.OverallWt*10)) as MXMKS,round(sum(RD.MarksObtained/RD.MaxMarks*W.OverallWt)/Sum(W.OverallWt)*100,2)as pge  FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER JOIN subjects S on S.msid=RD.msid and S.ID=RD.SubjectId and '$CClass' between S.ClassFrom and S.ClassTo WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass'  AND W.TErm='1'  and W.`MSID`='$msid' and '$CClass' between W.classfrom and W.classto And S.Overall_grade='1' And SubjectId='$sb'");

 while($gowy112=mysql_fetch_array($ghiy112)){
	echo $whhtgeterm1=$gowy112['whhtge'];  } ?></td>
  <td align="center" valign="top" class="st4"><?  $ghiy112=mysql_query($ghy112="SELECT RD.msid, RD.`SubjectId`,round(SUM(RD.MarksObtained/RD.MaxMarks*W.OverallWt),1) as whhtge  , round(sum(RD.MarksObtained/RD.MaxMarks*W.OverallWt)/Sum(W.OverallWt)*100,1)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid  and '$CClass' between W.classfrom and W.classto  WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND W.`Term`='1'    and W.`MSID`='$msid' and RD.`SubjectId`='$sb' and '$CClass' between W.classfrom and W.classto    "); while($gowy112=mysql_fetch_array($ghiy112)){ $whhtge=$gowy112['whhtge']; $pge=$gowy112['pge'];  $ghiy111=mysql_query($ghy111="SELECT `Grade` FROM `23Grades` WHERE `MSID`='$msid' And '$pge' BETWEEN `PercentFrom` And `Percentto` And '$CClass' BETWEEN `ClassFrom` And `ClassTo`"); while($gowy111=mysql_fetch_array($ghiy111)){echo $Grade111=$gowy111['Grade']; } }?></td>
 <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy3=mysql_query($ghy3="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='3' And StudentId='$s_id' And SubjectId='$sb' ORDER BY `StudentId`,`AssId`,`SubjectId`"); while($gowy3=mysql_fetch_array($ghiy3)){echo $Marks_obtained3=$gowy3['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy11=mysql_query($ghy11="SELECT RD.msid,G.`Grade` ,RD.`SubjectId`,(RD.MarksObtained/RD.MaxMarks*W.OverallWt) as whhtge,((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER Join 23Grades G ON ((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100) Between G.`PercentFrom` AND G.`Percentto` AND RD.MSID=G.MSID  WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND RD.`AssId`='3'  AND W.`AssId`='3' and W.`MSID`='$msid' and RD.`SubjectId`='$sb' and '$CClass' between W.classfrom and W.classto  and '$CClass' between G.classfrom and G.classto"); while($gowy11=mysql_fetch_array($ghiy11)){echo $Grade11=$gowy11['Grade'];}?>
                      </span></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy4=mysql_query($ghy4="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='4' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy4=mysql_fetch_array($ghiy4)){echo $Marks_obtained4=$gowy4['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy12=mysql_query($ghy12="SELECT RD.msid,G.`Grade` ,RD.`SubjectId`,(RD.MarksObtained/RD.MaxMarks*W.OverallWt) as whhtge,((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER Join 23Grades G ON ((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100) Between G.`PercentFrom` AND G.`Percentto` AND RD.MSID=G.MSID  WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND RD.`AssId`='4'  AND W.`AssId`='4' and W.`MSID`='$msid' and RD.`SubjectId`='$sb' and '$CClass' between W.classfrom and W.classto  and '$CClass' between G.classfrom and G.classto"); while($gowy12=mysql_fetch_array($ghiy12)){echo $Grade12=$gowy12['Grade'];}?>
                      </span></td>
                      <td align="center" valign="top" class="st4">&nbsp;<?php  $ghiy5=mysql_query($ghy5="SELECT * FROM `21Repodata1` Where MSID='$msid' and Session='$session' And AssId='6' And StudentId='$s_id' And SubjectId='$sb' ORDER BY 
`StudentId`,`AssId`,`SubjectId`"); while($gowy5=mysql_fetch_array($ghiy5)){echo $Marks_obtained5=$gowy5['MarksObtained'];}?></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?   $nhiy10=mysql_query($nhy10="SELECT RD.msid, RD.`SubjectId`,round(SUM(RD.MarksObtained/RD.MaxMarks*W.OverallWt),2) as whhtge  , round(SUM(RD.MaxMarks/W.OverallWt*10)) as MXMKS,round(sum(RD.MarksObtained/RD.MaxMarks*W.OverallWt)/Sum(W.OverallWt)*100,2)as pge  FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER JOIN subjects S on S.msid=RD.msid and S.ID=RD.SubjectId and '$CClass' between S.ClassFrom and S.ClassTo WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass'  AND W.`AssId`='6'  AND RD.`AssId`='6' and W.`MSID`='$msid' and '$CClass' between W.classfrom and W.classto And S.Overall_grade='1' And SubjectId='$sb'"); while($nowy10=mysql_fetch_array($nhiy10)){
						  echo $whhtgeas6=$nowy10['whhtge'];}  ?>
                      </span></td>
                      <td align="center" valign="top" class="st4"><span class="st41">
                        <?php   $ghiy13=mysql_query($ghy13="SELECT RD.msid,G.`Grade` ,RD.`SubjectId`,(RD.MarksObtained/RD.MaxMarks*W.OverallWt) as whhtge,((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER Join 23Grades G ON ((RD.MarksObtained/RD.MaxMarks*W.OverallWt)/W.OverallWt*100) Between G.`PercentFrom` AND G.`Percentto` AND RD.MSID=G.MSID  WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND RD.`AssId`='6'  AND W.`AssId`='6' and W.`MSID`='$msid' and RD.`SubjectId`='$sb' and '$CClass' between W.classfrom and W.classto  and '$CClass' between G.classfrom and G.classto"); while($gowy13=mysql_fetch_array($ghiy13)){echo $Grade13=$gowy13['Grade'];}?>
                      </span></td>
                         <td align="center" valign="top" class="st4"><? $ghiy113=mysql_query($ghy113="SELECT RD.msid, RD.`SubjectId`,round(SUM(RD.MarksObtained/RD.MaxMarks*W.OverallWt),2) as whhtge  , round(SUM(RD.MaxMarks/W.OverallWt*10)) as MXMKS,
round(sum(RD.MarksObtained/RD.MaxMarks*W.OverallWt)/Sum(W.OverallWt)*100,2)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER JOIN subjects S on S.msid=RD.msid and S.ID=RD.SubjectId and '$CClass' between S.ClassFrom and S.ClassTo WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' AND W.`Term`='2'  And W.`MSID`='$msid' and '$CClass' between W.classfrom and W.classto And S.Overall_grade='1'"); while($gowy113=mysql_fetch_array($ghiy113)){
	echo $whhtge2=$gowy113['whhtge2']; } ?></td>
  <td align="center" valign="top" class="st4"><? $ghiy121=mysql_query($ghy121="SELECT `Grade` FROM `23Grades` WHERE `MSID`='$msid' And '$pge2' BETWEEN `PercentFrom` And `Percentto` And '$CClass' BETWEEN `ClassFrom` And `ClassTo`"); while($gowy121=mysql_fetch_array($ghiy121)){echo $Grade121=$gowy121['Grade']; } ?></td>
  <td align="center" valign="top" class="st4">&nbsp;</td>
  <td align="center" valign="top" class="st4">&nbsp;</td>
                    </tr>
                    <? }?>
                    <tr>
                      <td height="30" colspan="21" align="right"><span class="st4">
                      <strong>Total Marks:  <? 
					  $phig=mysql_query($phg="SELECT RD.msid, RD.`SubjectId`,round(SUM(RD.MarksObtained/RD.MaxMarks*W.OverallWt),2) as whhtge  , round(SUM(RD.MaxMarks/W.OverallWt*10)) as MXMKS,
round(sum(RD.MarksObtained/RD.MaxMarks*W.OverallWt)/Sum(W.OverallWt)*100,2)as pge FROM `21Repodata1`  RD INNER JOIN 22Weightage W on W.msid=RD.msid and W.assid=RD.assid and '$CClass' between W.classfrom and W.classto INNER JOIN subjects S on S.msid=RD.msid and S.ID=RD.SubjectId and '$CClass' between S.ClassFrom and S.ClassTo WHERE RD.`MSID`='$msid' AND RD.`StudentId`='$s_id' AND RD.`Session`='$session' AND RD.`Class`='$CClass' And W.`MSID`='$msid' and '$CClass' between W.classfrom and W.classto And S.Overall_grade='1'"); 		while($powg=mysql_fetch_array($phig)){
	
	echo $whhtge= $powg['whhtge'].'/'.$MXMKS= $powg['MXMKS']?>&nbsp;&nbsp;&nbsp;<? echo 'Percentage:'.$MpgeS= $powg['pge'].'%';  ?> &nbsp;&nbsp;&nbsp; Overall Grade : <? $ghiy131=mysql_query($ghy131="SELECT `Grade` FROM `23Grades` WHERE `MSID`='$msid' And '$MpgeS' BETWEEN `PercentFrom` And `Percentto` And '$CClass' BETWEEN `ClassFrom` And `ClassTo`"); while($gowy131=mysql_fetch_array($ghiy131)){echo $Grade131=$gowy131['Grade']; } }?></strong>
                      </span></td></tr>
                    <?php }?>
              </table>
            <br /></td>
          </tr>
        </table></td>
      </tr>
    </table>
<!--<p class="page"></p>--></body>
</html>
<? }?>