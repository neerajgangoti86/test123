
<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
//                print_r($student);
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                ?><table width="674"  border="1" align="center">
                    <tr>
                        <td width="642" height="516">
                            <table width="674">
                                <tr>
                                    <td colspan="3" align="center">
                                        <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>
                                    </td>
                                </tr>
                                
                               
                                <tr><td colspan="4"  background="../../../images/reportlogo.png" style="background-size:30%; background-position:center; background-repeat:no-repeat"><hr />

                                        <table width="100%" height="319" border="0" align="center" >
                                            <tr valign="top" class="st4">
                                                <td height="42" colspan="3" align="center" class="style15"><table width="406" border="0">
                                                        <tr>
                                                            <td width="302" align="center"><strong>TO WHOM IT MAY CONCERN</strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="302" align="center"><hr /></td>
                                                        </tr>
                                                    </table>
                                                    <br />
                                                    <br /></td>
                                            </tr>
                                            <tr valign="top" class="st4">
                                                <?php $g = $student->gender; ?>
                                                <td height="139" colspan="3">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <p>This is to certify that <strong>
                                                            <?php
                                                            if ($g == 'F') {
                                                                echo 'Miss';
                                                            } else {
                                                                echo 'Master';
                                                            }
                                                            ?>
                                                            <?= $student->name; ?></strong>
                                                        <?php if ($g == 'F') { ?> 
                                                            D/O
                                                        <?php } else { ?>
                                                            S/O 
                                                        <?php } ?>
                                                        <strong>Mr. <?= $student->f_name; ?></strong><?php
                                                        $MotherName = $student->m_name;
                                                        if ($MotherName != '') {
                                                            ?> and <strong>Mrs. <?php echo $MotherName; ?></strong> <?php } ?> Resident  Of <?php echo $student->village; ?> &nbsp;is bonafide student of this school of class 
                                                        <strong>
                                                            <?php
                                                            $cls = Master::get_classes($MSID, '', '', '', $student->class)->fetch(PDO::FETCH_OBJ);
                                                            echo $cls->class_name;
                                                            ?>
                                                        </strong>. <br />
                                                        &nbsp;&nbsp;<br />
                                                        As per school record
                                                        <?php if ($g == 'F') { ?>
                                                            her
                                                        <?php } else { ?>
                                                            his
                                                            <?php } ?>
                                                        admission No  is  <strong>
                                                            <?php echo $AdmNo = $student->admno; ?>
                                                        </strong> and date of birth is <strong>
                                                            <?php
                                                            $dob = $student->birth_date;
                                                            echo $new_date = date('d-m-Y', strtotime($dob));
                                                            ?>
                                                        </strong></p>
                                                    <p><strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(
                                                            <?php
                                                            $new_date = date('d', strtotime($dob));
                                                            $nm = date('F', strtotime($dob));
                                                            $ny = date('Y', strtotime($dob));

                                                            $date = Master::get_dates($new_date)->fetch(PDO::FETCH_OBJ);
                                                            $year = Master::get_years($ny)->fetch(PDO::FETCH_OBJ);

                                                            echo $date->datevn . ' ' . $nm . ' ' . $year->year_name;
                                                            ?>
                                                            )</strong>.</p></td>
                                            </tr>




                                            <tr valign="top" class="st4">
                                                <td width="227" rowspan="2" valign="middle"><strong>Dated:
                                                        <?php
                                                        $thisDate = date('d/m/Y');
                                                        echo $thisDate;
                                                        ?>
                                                    </strong></td>
                                                <td width="227" valign="bottom" align="center">.....................</td>
                                                <td width="200" height="50" align="center" valign="bottom">.....................</td>
                                            </tr>
                                            <tr valign="top" class="st4">
                                                <td width="227" valign="top" align="center"><strong>Checked by</strong></td>
                                                <td align="center"><strong>Principal</strong></td>
                                            </tr>
                                        </table></td></tr>
                            </table></td>
                    </tr>
                </table></div>
            <!-- /.box -->
        </div>
    </div>
</section>

