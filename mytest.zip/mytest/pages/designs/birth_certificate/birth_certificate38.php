
    <link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
    <section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
//                print_r($student);
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                ?><table width="674"  border="1" align="center">
                    <tr>
                        <td width="642" height="516"><table width="674">
                                <tr>
                                    <td colspan="3" align="center"><span class="m1">
                                            <?= $oCurrentSchool->name; ?> 
                                         </span></td>
                                </tr>
                                <tr>
                                    <td width="99" align="left">
                                    <img class="logo" src="<?= CLIENT_URL ?>/uploads/thumbs/<?php
                                        if ($oCurrentSchool->logo_img != "") {
                                          echo $oCurrentSchool->logo_img; 
                                        } else {
                                            echo "../../Uplaod/aboutlogo.jpg";
                                        }
                                        ?>"  width="90" height="100">
                                    <td width="493" valign="top"><table width="100%" border="0" align="center">
                                            <tr>
                                                <td width="226" align="center" ><span><h3>
                                                            &nbsp; &nbsp; &nbsp; &nbsp;   <?= $oCurrentSchool->place; ?> P.O.   <?= $oCurrentSchool->post; ?> Distt. <?= $oCurrentSchool->distt; ?>&nbsp;  <?= $oCurrentSchool->state; ?>&nbsp;  <?= $oCurrentSchool->pin; ?> </h3>
                                                    </span></td>
                                            </tr>
                                            <tr>
                                                <td align="center" class="b1"><span class="t1">
                                                        <?php
                                                        if ($oCurrentSchool->Board_full_name == '') {
                                                            echo $oCurrentSchool->board;
                                                        } else {
                                                            echo $oCurrentSchool->Board_full_name;
                                                        }
                                                        ?>
                                                    </span></td>
                                            </tr>
                                            <tr>
                                                <td align="center" class="t1">&nbsp;</td>
                                            </tr>
                                        </table></td>
                                    <td width="230" align="right" valign="top"><table width="100%" border="0" align="right">
                                            <tr>
                                                <td align="center"><img  src="<?= ASSETS_FOLDER ?>/img/phone.jpg"  width="24" height="24" /></td>
                                                <td align="right" class="r"><strong>
<?= $oCurrentSchool->phone; ?> 
                                                    </strong></td>
                                            </tr>
                                            <tr>
                                                <td width="112" class="r">Affiliation No.:</td>
                                                <td width="108" align="right" class="r"><strong>
<?= $oCurrentSchool->affNo; ?>    
                                                    </strong></td>
                                            </tr>
                                            <tr>
                                                <td class="r"> School Code :</td>
                                                <td align="right"><span class="r"><strong>
<?= $oCurrentSchool->schoolNo; ?>      
                                                        </strong></span></td>
                                            </tr>
                                            <tr>
                                                <td><span class="r">Recognition No.:</span></td>
                                                <td align="right"><strong class="r">
<?= $oCurrentSchool->recNo; ?>    
                                                    </strong></td>
                                            </tr>
                                        </table></td>
                                </tr>
                                <tr><td colspan="4"  background="../../../images/reportlogo.png" style="background-size:30%; background-position:center; background-repeat:no-repeat"><hr />
                                     
                                            <table width="100%" height="319" border="0" align="center" background="<?= ASSETS_FOLDER ?>/img/svnlogo.png" style="background-size:49%; background-position:center; background-repeat: no-repeat">
                                                <tr valign="top" class="st4">
                                                    <td height="42" colspan="3" align="center" class="style15"><table width="406" border="0">
                                                            <tr>
                                                                <td width="302" align="center"><strong>TO WHOM IT MAY CONCERN</strong></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="302" align="center"><hr /></td>
                                                            </tr>
                                                        </table>
                                                        <br />
                                                        <br /></td>
                                                </tr>
                                                <tr valign="top" class="st4">
                                                      <?php $g = $student->gender; ?>
                                              <td height="139" colspan="3">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <p>Certified that <strong>
                                                                <?php
                                                                if ($g == 'F') {
                                                                    echo 'Miss';
                                                                } else {
                                                                    echo 'Master';
                                                                }
                                                                ?>
                                                               <?= $student->name; ?></strong>
                                                         <?php if ($g == 'F') { ?> 
                                                                D/O
                                                            <?php } else { ?>
                                                                S/O 
                                                            <?php } ?>
                                                            <strong>Mr.   <?= $student->f_name; ?> </strong><?php
                                                        $MotherName = $student->m_name;
                                                        if ($MotherName == '') {
                                                            
                                                        }else{
                                                        ?> and <strong>Mrs. <?php echo $MotherName;  ?></strong> <?php } ?>&nbsp;is/was a regular student of this school since <strong><? $dob1=$student->adm_date;   echo $new_AdmDate = date('d-m-Y', strtotime($dob1)); ?></strong>. Presently  
                                                            <?php if ($g == 'F') { ?>
                                                                She
                                                                <?php } else { ?>
                                                                He
                                                                <?php } ?> is studying in 
                                                            <strong>
                                                                <?php
                                                            $cls = Master::get_classes($MSID, '', '', '', $student->class)->fetch(PDO::FETCH_OBJ);
                                                            echo $cls->class_name;
                                                            ?>
                                                            </strong> class. <br />
                                                            &nbsp;&nbsp;<br />

                                                            <?php if ($g == 'F') { ?>
                                                                Her
                                                                <?php } else { ?>
                                                                His
    <?php } ?>
                                                            Date of birth according to our school record is <strong>
                                                                <?php $dob =  $student->birth_date;
                                                                echo $new_date = date('d-m-Y', strtotime($dob));
                                                                ?>
                                                            </strong></p>
                                                        <p><strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(
                                                                <?php
                                                              $new_date = date('d', strtotime($dob));
                                                            $nm = date('F', strtotime($dob));
                                                            $ny = date('Y', strtotime($dob));

                                                            $date = Master::get_dates($new_date)->fetch(PDO::FETCH_OBJ);
                                                            $year = Master::get_years($ny)->fetch(PDO::FETCH_OBJ);

                                                            echo $date->datevn . ' ' . $nm . ' ' . $year->year_name;
                                                                ?>
                                                                )</strong>.</p></td>
                                                </tr>
                                                <tr valign="top" class="st4">
                                                    <td width="227" rowspan="2" valign="middle"><strong>Dated:
    <?php $thisDate = date('d/m/Y');
    echo $thisDate;
    ?>
                                                    </strong></td>
                                                <td width="227" valign="bottom" align="center">.....................</td>
                                                <td width="200" height="50" align="center" valign="bottom">.....................</td>
                                            </tr>
                                            <tr valign="top" class="st4">
                                                <td width="227" valign="top" align="center"><strong>Checked by</strong></td>
                                                <td align="center"><strong>Principal</strong></td>
                                            </tr>
                                        </table></td></tr>
                            </table></td>
                    </tr>
                </table></div>
            <!-- /.box -->
        </div>
    </div>
</section>

