<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<style>
    .box .watermark {
        position: absolute;
        z-index: -1;
        top: 50px;
        bottom: 0;
        left: 150;
        right: 0;
        background: url(<?= CLIENT_URL ?>/uploads/photo_1458715104.jpg) center; 
        background-repeat:no-repeat;
        background-position:center;
        width:60%;
        opacity: .1;
    } 
</style>
<!-- Main content -->
<?php
$id = http_get('param1');
//
//print_r($id);
//exit();


$student = Student::get_students($oCurrentUser->myuid, '', $id)->fetch(PDO::FETCH_OBJ);
//print_r($student);
?>
<?php
if (isset($_POST['rsubmit'])) {
    ?>
    <section class="content">
        <div class="box">

    <?php if ($oCurrentSchool->watermark == 1) { ?>   <div class="watermark"></div> <?php } ?>
            <table width="674"  border="1" align="center">

                <tr>

                    <td width="642" height="516">
                        <table width="674">



                            <tr>
                                <td>
    <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>  

                                </td>
                            </tr>
                            <tr><td align="center" >
                                    <hr/>
                                    <span class="style15"> Character Certificate </span>
                                    <hr/>

                                </td></tr>

                            <tr><td colspan="4"  >

    <?php
    $dresult = $_POST['result'];
    $Attendance = $_POST['attendance'];

    $class = $_POST['class_name'];
    //$new_date = date('d-m-Y', strtotime($DateOfBirth)); 
    $heldin = date('d-m-Y', strtotime($_POST['held_in']));
    $rno = $_POST['roll_no'];
    $marks_obtained = $_POST['mark_obtain'];
    $max_marks = $_POST['total_marks'];
    $division = $_POST['division'];
    $conduct = $_POST['conduct'];



    //$result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.Village,L.District, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' and  S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0)='$cno' And S.Id='$s_id' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0) " );while($row=mysql_fetch_array($result)){ 
    ?>

                                    <br />

                                    <table width="100%" height="319" border="0" align="center" background="../../images/svnlogo.png" style="background-size:49%; background-position:center; background-repeat: no-repeat">



                                        <tr valign="top" class="st3">

                                            <td height="20"  >Sr.No :</td>

                                            <td height="20" >Admission No: <?= $student->admno ?></td>

                                            <td height="20" >Dated:  <?php
                                                $AdmDate = $student->adm_date;
                                                echo $new_dat1e = date('d-m-Y', strtotime($AdmDate));
                                                ?></td>

                                        </tr>

                                        <tr valign="top" class="st4">

    <?php $g = $student->gender; ?>

                                            <td height="68" colspan="3">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <p>Certified that <strong>

                                                        <?php if ($g == 'F') {
                                                            echo 'Miss';
                                                        } else {
                                                            echo 'Master';
                                                        } ?>

                                                    <?php echo $student->name ?></strong>

    <?php if ($g == 'F') { ?>

                                                        D/O

    <?php } else { ?>

                                                        S/O

                                                    <?php } ?>

                                                    <strong>Mr. <?php echo $student->f_name; ?></strong> and <strong>Mrs. <?php echo $student->m_name; ?></strong>&nbsp;is a non-resident student of this school.

                                                    Currently

    <?php if ($g == 'F') { ?>

                                                        she

    <?php } else { ?>

                                                        he

                                                        <?php } ?>

                                                    is 



                                                    studying in class <strong>
                                                    <?php
                                                    $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                                    echo $cls->class_name;
                                                    ?>

                                                    </strong>

    <?php if ($g == 'F') { ?>

                                                        She

    <?php } else { ?>

                                                        He

    <?php } ?>

                                                    has been declared <strong><? echo $dresult;?></strong> in class <strong><? echo $class;?></strong> examination held in <strong><? echo $heldin;?></strong> Under roll no <strong><? echo $rno;?></strong> And Secured <strong><? echo $marks_obtained;?></strong> Marks out of <strong><? echo $max_marks;?></strong> and was placed in <strong><? echo $division;?></strong> division.  

    <?php if ($g == 'F') { ?>

                                                        Her

    <?php } else { ?>

                                                        His

    <?php } ?>

                                                    Total Attendance is <strong><? echo $Attendance;?></strong><br />

                                                    &nbsp;&nbsp;<br />

                                                    As Per School Records <?php if ($g == 'F') { ?>

                                                        Her

    <?php } else { ?>

                                                        His

                                                        <?php } ?>

                                                    Date of birth is <strong>

                                                        <?php
                                                        $DateOfBirth = $student->birth_date;
                                                        echo $new_date = date('d-m-Y', strtotime($DateOfBirth));
                                                        ?> </strong></p>
                                                <p><strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(
                                                        <?php
                                                        $new_date = date('d', strtotime($DateOfBirth));

                                                        $nm = date('F', strtotime($DateOfBirth));

                                                        $ny = date('Y', strtotime($DateOfBirth));



                                                        $date = Master::get_dates($new_date)->fetch(PDO::FETCH_OBJ);

                                                        $year = Master::get_years($ny)->fetch(PDO::FETCH_OBJ);



                                                        echo $date->datevn . ' ' . $nm . ' ' . $year->year_name;
                                                        ?>

                                                        )</strong>.</p></td>

                                        </tr>

                                        <tr valign="top" class="st4">

                                            <td height="69" colspan="3"><?php if ($g == 'F') { ?>

                                                    She

                                                <?php } else { ?>

                                                    He

                                                <?php } ?> bears <strong><? echo $conduct;?></strong> Moral Character. We Wish 

    <?php if ($g == 'F') { ?>

                                                    her

    <?php } else { ?>

                                                    him

    <?php } ?> success in life.</td>

                                        </tr>

                                        <tr valign="top" class="st4">

                                            <td width="189" rowspan="2" valign="middle"><strong>Dated:

    <?php $thisDate = date('d/m/Y');
    echo $thisDate; ?>

                                                </strong></td>

                                            <td width="263" valign="bottom" align="center">.....................</td>

                                            <td width="200" height="50" align="center" valign="bottom">.....................</td>

                                        </tr>

                                        <tr valign="top" class="st4">

                                            <td width="263" valign="top" align="center"><strong>Checked by</strong></td>

                                            <td align="center"><strong>Principal</strong></td>

                                        </tr>

                                    </table></td></tr>

                        </table></td>

                </tr>

            </table>
        </div>
    </section>
    <?php ?>

    <?php
} else {
    ?>


    <section class="content">

        <div class="row">

            <div class="col-md-12"> <?php $message = new Messages();
    echo $message->display();
    
    //print_r($student);
    
    ?>

                <!-- general form elements -->

                <div class="box box-primary">

                    <div class="box-header">

                        <h3 class="box-title">Student Name:</h3>

                    </div>

                    <!-- /.box-header -->

                    <!-- form start -->

    <?php
    //print_r($students);
    ?>
                    <form method="post" action="" target="_blank" role="form" enctype="multipart/form-data">



                        <div class="box-body">

                            <div class="row">

                                <div class="col-md-4">

                                    <div class="form-group">

                                        <label> <span>Student ID </span></label>

                                        <input class="form-control"  type="text" value="<?= $students->student_id; ?>" size="15" id="s_uid" name="s_uid"/>

                                    </div>

                                    <div class="form-group">

                                        <label><span> Student Name</span></label>

                                        <input class="form-control" type="text" size="25" id="s_name" value="<?= $students->name ?>" name="s_name" required>

                                    </div>

                                    <div class="form-group">

                                        <label>Result</label>

                                        <select name="result" class="form-control" id="result">
                                            <option>Pass</option>
                                            <option>Fail</option>
                                            <option>Compartment</option>
                                            <option>Result awaited </option>
                                        </select>

                                    </div>
                                </div>

                                <?php
                                //echo $student->adm_classno;
                                // $class = Master::get_classes($MSID,'', '', '',$student->adm_classno);
                                //print_r($class);
                                $class = Master::get_stu_class_names($MSID, $students->class);
                                $classes = $class->fetch();

                                //echo $class['class_name'];
                                ?>  
                                <div class="col-md-4">		  
                                    <div class="form-group">

                                        <label>Class</label>

                                        <input class="form-control" type="text" size="25" id="class_name" value="<?= $classes['class_name'] ?>" name="class_name" required>

                                    </div>

                                    <div class="form-group">

                                        <label>Held In</label>



                                        <input class="form-control" type="text" size="12" id="held_in" name="held_in" autocomplete="off">



                                    </div>


                                    <div class="form-group">

                                        <label>Roll No</label>



                                        <input class="form-control" type="text" size="12" id="roll_no" name="roll_no"/>



                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">

                                        <label>Marks Obtained</label>



                                        <input class="form-control" type="text" size="12" id="mark_obtain" name="mark_obtain"/>



                                    </div>

                                    <div class="form-group">

                                        <label> Out Of (Maximum Marks)</label>



                                        <input class="form-control" type="text" size="12" id="total_marks" name="total_marks"/>



                                    </div>

                                    <div class="form-group">

                                        <label>Division</label>



                                        <input class="form-control" type="text" size="12" id="division" name="division"/>



                                    </div>
                                </div>

                                <div class="col-md-4">	  

                                    <div class="form-group">

                                        <label>Attendance</label>



                                        <input class="form-control" type="text" size="12" id="attendance" name="attendance"/>



                                    </div>

                                    <div class="form-group">

                                        <label>Conduct</label>

                                        <select id="conduct" class="form-control" name="conduct">
                                            <option>Good</option>
                                            <option>Bad</option>
                                        </select>



                                    </div>



                                </div>

                            </div>

                            <!-- \col -->

                        </div>

                        <!-- \row end -->

                        <div class="row">

                            <div class="col-md-3">

                                <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>

                            </div>

                            <!-- \col -->

                        </div>

                        <!-- \row end -->

                </div>

                </form>

            </div>

            <!-- /.box -->

        </div>

    </div>
    </div>

    </section>
    <?php
}
?>
<!-- Main content -->



<?php
$sBottomJavascript = <<<EOT

<script type="text/javascript">

$(document).ready(function(){

$('body').on('click','[data-ms="modal"]', function(e) {

	var link = $(this);

	var options = {

        url: link.attr("href"),

        title: link.attr("data-title"),

		size : 'md'

    };

   eModal.setEModalOptions({

        loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',

    });

   eModal.ajax(options);

   return false;

});

//calender

$('#dobid, #hdate, #epfjdate, #held_in').datepicker({

    format: 'yyyy-mm-dd',

	todayHighlight: true

});

});

</script>

EOT;

$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>