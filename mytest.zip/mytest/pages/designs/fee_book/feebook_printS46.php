<?php
// print_r($oCurrentSchool);       

$tpt = (@http_get('param3') == "tpt" && $oCurrentSchool->SeprateTPTFBook == "1") ? "2" : (($oCurrentSchool->SeprateTPTFBook == "0") ? "1" : "0");
?>
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
$message = new Messages();
echo $message->display();
?>
            <div class="box">
                <?php
                $id = http_get('param2');
                $student = Student::get_students($MSID, '1', $id)->fetch(PDO::FETCH_OBJ);

//                $delete_data = Fee::get_delete_student_from_fee_billing($MSID, $student->acno, $oCurrentUser->mysession);
//                $data_insert = Fee::insert_student_into_fee_billing($oCurrentUser->myuid, $student->acno);
//                print_r($student);
//                exit();
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                //delete previous Entrys of perticular acc no 
//                $delete_previous_user = Fee::get_delete_student_from_fee_billing($MSID, $student->acno, $oCurrentUser->begins, $oCurrentUser->ends);
                //Add new Entrys of perticular acc no 
//                $add_entrys = Fee::insert_student_into_fee_billing($MSID, $student->acno);
                //getting the loop data 
                $loops = Fee::get_fee_billing_loops($MSID, $student->acno);
                while ($rowv = $loops->fetch(PDO::FETCH_OBJ)) {
//                    echo "<pre>";
//                    print_r($rowv);
                    ?>

 <style type="text/css">
                            <!--  
                            .header {
                                font-size: 10px;
                                font-weight:bold;
                                font-family: Verdana, Arial, Helvetica, sans-serif;
                            }
                            .subheader {
                                font-size: 9px;font-family: Verdana, Arial, Helvetica, sans-serif;
                            }
                            .subheader1 {
                                font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 9px;

                            }
                            .subheader2 {
                                font-size: 9px;font-family: Verdana, Arial, Helvetica, sans-serif;

                            }
                            .bpart {

                                font-family: Verdana, Arial, Helvetica, sans-serif;
                                font-size: 8px;
                            }
                            .bpart2 {
                                font-family: Verdana, Arial, Helvetica, sans-serif;
                                font-size: 8px;

                                font-weight: bold;	

                            }
                            .bpart1 {
                                font-family: Verdana, Arial, Helvetica, sans-serif;
                                font-size: 8px;


                            }
                            .bpart11 {
                                font-family: Verdana, Arial, Helvetica, sans-serif;

                                font-size: 8px;
                                font-style:italic

                            }
                            .bpart21 {	font-family: Verdana, Arial, Helvetica, sans-serif;
                                       font-size: 8px;
                            }
                            .bpart3 {font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 8px;
                            }
                            .bpart12 {	font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 8px;
                            }
                            -->
                        </style>
<style>
p.page { page-break-after: always; }
</style>

<div class="tmbanner1">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr> 
    <td align="center" valign="top"><table width="300" height="373" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="373" valign="top"><table width="293" border="1" height="370" cellspacing="0" cellpadding="0">
          <tr>
            <td width="289" height="368" align="center" valign="top"><table width="280" border="0" cellspacing="0" cellpadding="0">
            
              <tr>
                <td width="51" align="center"  ><span class="header"><img src="<?= ASSETS_FOLDER ?>/img/logo single outlined.jpg" alt="" width="58" height="46" /></span></td>
                <td width="237" align="center" valign="top"  ><span class="header">
                   <?= $oCurrentSchool->name; ?>  </span></td>
              </tr>
            
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                  <table width="288" border="0" align="center">
                    <tr>
                      <td width="223" align="center" class="bpart1"><b><?= $oCurrentSchool->Add_ReportC ?></b>
                    </table></td>
              </tr>
            </table>
              
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
               <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="3" align="left" class="bpart"><?= $student->name ?>&nbsp;</td>
                  </tr>
                <tr align="left">
                  <td height="24" colspan="5" align="left"><span class="bpart"> <?php $g = $student->gender; ?>
                                                                        <?php
                                                                        if ($g == 'F') {
                                                                            echo 'D/O';
                                                                        } else {
                                                                            echo 'S/O';
                                                                        }
                                                                        ?> : Mr. <?= $student->f_name ?> : </span>
                     </td>
                </tr>
                <tr>
                  <td width="74" height="28" align="left" class="bpart">Class:</td>
                  <td width="54" align="left" class="bpart"><?php $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                                    echo $cls->class_name; ?></td>
                  <td colspan="2" align="left" class="bpart">Student Id:</td>
                  <td width="63" align="left" class="bpart"><?= $student->student_id ?></td>
                  </tr>
                <tr >
                  <td height="24" colspan="3" align="left" class="bpart">For the month of :</td>
                  <td colspan="2" align="left" class="bpart"><?php
                                                                    $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo);
                                                                    while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                        $count = $fee_schedule->rowCount();
                                                                        if ($count > 0) {
                                                                            $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                            echo $month_name->month . " ";
                                                                        } else {
                                                                            $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                            echo $month_name->month . " ";
                                                                        }
                                                                        $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                    }
                                                                    ?> </td>
                  </tr>
                </table>
              <table width="287" border="1" align="center">
                <tr class="bpart">
                  <td width="212">Particulars of Fee </td>
                  <td width="59" align="right">Amount</td>
                </tr>
                <?php
                                                                $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);
                                                                
                                                                $ttl_amts = Fee::get_fee_book_querry2_subtotal($MSID, $student->acno, $rowv->RSrNo,'', $tpt);
                                                                while ($ttl_amt = $ttl_amts->fetch(PDO::FETCH_OBJ)) {
                                                                    $students = Student::get_students($MSID, '1', $ttl_amt->SID)->fetch(PDO::FETCH_OBJ);
                                                                   
                                                                while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                                                                    $fee_amount = Fee::get_fee_book_querry1($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $fee_name->fee_id, $tpt)->fetch(PDO::FETCH_OBJ);
                                                                    ?>  
                <tr class="bpart">
                  <td><?= $fee_name->fee_group_name ?></td>
                  <td align="right"  class="bpart"><?php echo round(@$fee_amount->FeeAmt); ?>
                    &nbsp;</td>
                </tr>
                <?php  }    }?>
                <tr>
                  <td class="bpart">Total</td>
                  <td align="right" class="bpart" > <?php $ttl_amount = Fee::get_fee_book_querry2_subtotal($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $tpt)->fetch(PDO::FETCH_OBJ); ?>
        <?php echo round($ttl_amount->Sub_Total); ?>
                    &nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Late Fee Fine</td>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Grand Total</td>
                  <td align="right">&nbsp;</td>
                </tr>
              </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="21" colspan="2" class="bpart">Mode : <strong>Cash </strong></td>
                </tr>
                 <tr>
                  <td height="23" colspan="2" class="bpart">
                  User Name :<strong> <?= $oCurrentUser->myuname ?>
              </strong>
                  </td>
                </tr>
            
             <tr>
                  <td height="23" colspan="2" align="right" class="bpart">
                    <strong>Auth. Sign.</strong></td>
                </tr> <tr>
                  <td width="158" height="23" align="right" class="bpart"><strong>Yearly Recievable:</strong></td>
                  <td width="122" align="right" class="bpart">    total due amount</td>
                </tr> 
                <tr>
                  <td height="11" align="right" class="bpart">
                    <strong>Total Paid:</strong></td>
                  <td height="11" align="right" class="bpart"> paid amount</td>
                </tr>
                <tr>
                  <td height="12" align="right" class="bpart"><strong>Balance:</strong></td>
                  <td height="12" align="right" class="bpart">&nbsp;</td>
                </tr>
              </table></td>
          </tr>
        </table></td>
      
        
      </tr>
    </table>   </td>
  </tr>
</table>
</div><p class="page"></p>
    <?php } ?>
            </div>
        </div>
    </div>
</section>