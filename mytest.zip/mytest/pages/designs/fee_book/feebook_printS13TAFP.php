<?php   
session_start();
include("../../connect/db.php");   
$msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {  $s_id1=$_GET['s_id'];   $s_id = mysql_real_escape_string($s_id1);
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
$SrNo1=$_GET['SrNo'];  $SrNo = mysql_real_escape_string($SrNo1);
$TrDate1=$_GET['TrDate'];$TrDate = mysql_real_escape_string($TrDate1);
	  $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
   $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }  ?> 
<style type="text/css">
<!--  
.header {
	font-size: 20px;
	font-weight:bold;
	 font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader {
	font-size: 17px;font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader1 {
font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 11px;
	 
}
.subheader2 {
	font-size: 13px;font-family: Verdana, Arial, Helvetica, sans-serif;
	 
}
.bpart {
 
font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.bpart2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
	 
	font-weight: bold;	

}
.bpart1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
 
}
.bpart11 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
 
	font-size: 12px;
	font-style:italic
 
}
.bpart21 {	font-family: Verdana, Arial, Helvetica, sans-serif;
 font-size: 18px;
}
.bpart3 {font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 13px;
}
.bpart12 {	font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;
}
.header1 {	font-size: 18px;

	 font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader3 {	font-size: 16px;font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style><!--<link href="css/glfee.css"  rel="stylesheet" type="text/css" media="all" />--> <?php 
$nd=mysql_query($nsql="SELECT MN.AcNO,MN.FatherName,MN.Village,Month(MN.DueDate)as MonthNo,Year(MN.DueDate) as feeyr,MN.SID,MN.Name,MN.House,MN.CClass,MN.FeeGroup,MN.RSrNo,Sum(MN.Amt-MN.Disco)as Amount FROM (Select CS.SID,CS.Name,CS.House,CS.SrNo,CS.CClass,CS.DueDate,CS.AcNo,CS.FatherName,CS.Village,FN.Id FGroupId,FN.FeeGroup,IF(FN.Id>0,FF.FeeRate,If(FN.Id=0 And CS.TptStation Is Not Null,TR.TptRate,0)) Amt,IF(FN.Id>0,FF.FeeRate,If(FN.Id=0 And CS.TptStation Is Not Null,TR.TptRate,0))*COALESCE(DR.`PerCent`,0)+COALESCE(DR.`FixedAmt`,0) Disco,FS.`RSrNo` 
FROM(SELECT If(P.SFeebookR=1,S.ID,S.PID) AcNo,P.FeepaymentMode,U.`MSID`,U.`MySession`,U.`MyDate`,U.`Begins`,U.`Ends`,C.ClassFrom,C.ClassTo,S.`Id` SID,S.Name,S.House,S.PID,P.FatherName,P.Village,S.FSDate,S.SLDate,S.`AdmClassNo`+'$session'-Year(S.FSDate)+COALESCE(SR.SumResult,0) CClass,S.`Stream`,S.`MainGroup`,S.`Subgroup`,DD.`DateId` DueDate,If(Year(DD.DateID)=Year(U.Begins),Month(DD.DateId)- Month(U.Begins) 
+'1',Month(DD.DateId)-Month(U.Begins)+'13') AS SrNo,TPT.TptStation,DS.Discount FROM `91Users` U INNER JOIN 13Students S ON U.MSID=S.MSID AND U.MyDate Between S.FSDate AND S.SLDate Left Join (SELECT E.MSID,E.S_Id,Sum(E.`Result`) SumResult,E.DateResult FROM `14Exam` E INNER JOIN 91Users U ON E.MSID=U.MSID And E.`DateResult`<U.`MyDate` WHERE U.MyUId='$foo' Group By E.`S_Id` ) SR ON S.Id=SR.S_ID AND U.MSID=SR.MSID INNER JOIN 10Company C ON C.MSID=U.MSID INNER JOIN 6Dates DD ON DD.DateId Between U.Begins And U.Ends And Day(DD.DateId)='1' Left Join 35SATpt TPT ON TPT.MSID=U.MSID AND DD.DateId Between TPT.DateFrom And TPT.DateTo And S.Id=TPT.S_Id Left Join 34DiscountedStudent DS ON DS.MSID=U.MSID AND DD.DateId Between DS.DateFrom And DS.DateTo And DS.S_Id=S.Id INNER JOIN 12Parents P ON P.MSID=U.MSID AND P.Id=S.PID WHERE U.`MyUId`='$foo') CS  
Inner Join 7FeeNames FN ON FN.MSID=CS.MSID AND FN.ID='0' INNER JOIN 31Fee FF ON FF.MSID=CS.MSID AND CS.DueDate Between FF.DateFrom And FF.DateTo AND CS.DueDate Between CS.FSDate And CS.SLDate And FF.FeeId=FN.Id And CS.CClass Between FF.ClassFrom And FF.ClassTo And If(CS.FSDate=CS.DueDate AND FF.FF='1',CS.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CS.SrNo BETWEEN FF.SrNoFrom 
AND FF.SrNoTo) Left Join 36TptRate TR ON CS.MSID=TR.MSID AND CS.DueDate Between TR.DateFrom And TR.DateTo And CS.TptStation=TR.TptStation LEFT JOIN 33DiscountRule DR ON DR.MSID=CS.MSID And CS.DueDate Between DR.DateFrom And DR.DateTo And DR.Discount=CS.Discount And FN.ID=DR.FeeId And CS.CClass Between DR.ClassFrom And DR.ClassTo And CS.SrNo Between DR.SrNoFrom And DR.SrNoTo Inner Join 31FeeSchedule FS ON FS.MSID=CS.MSID And CS.SrNo Between FS.SrNoFrom And FS.SrNoTo And CS.FeepaymentMode=FS.PayMode Where CS.SID='$s_id') MN WHERE RSrNo='$SrNo' Group By SID,FeeGroup,RSrNo Order By RSRNO,SID,FeeGroup "); while($nrow=mysql_fetch_array($nd)){   $SID= $nrow['SID'];    $Name= $nrow['Name'];  $FatherName= $nrow['FatherName'];$Village= $nrow['Village'];$SrNo= $nrow['RSrNo'];$MonthNo= $nrow['MonthNo']; $CClass= $nrow['CClass'];
$House= $nrow['House']; 
 $feeyr= $nrow['feeyr']; $Amount= $nrow['Amount']; //$FeeName= $nrow['FeeName'];

?>
<title><?php $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
  $Place= $row['Place'];
    $AffNo= $row['AffNo'];
	 $SchoolNo= $row['SchoolNo'];
	 	 $Phone= $row['Phone'];
$Board= $row['Board'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$BankCash= $row['BankCash'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS'];  
$EMail= $row['EMail'];
$SFeebookR= $row['SFeebookR']; 
$FeePaymentmode= $row['FeePaymentmode'];
$bank= $row['Bank']; $branch= $row['Branch']; $acno=$row['ACNo'];
}?></title><body>
<style><script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
p.page { page-break-after: always; }
</style><div class="tmbanner1"><form id="contactform" name="contactform" method="post" action="#">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr> 
    <td height="426" align="center" valign="top"><table width="652" height="353" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="293" height="353" valign="top"><table width="372" border="1" height="425" cellspacing="0" cellpadding="0">
          <tr>
            <td width="368" height="423" align="center" valign="top"><table width="379" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Student Copy)</span></td>
              </tr>
              <tr>
                <td height="66" colspan="2" align="center"  ><span class="header1">
                  <!--<img src="<?php // if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo">-->
                  OM SAI TRANSPORT COMPANY</span><span class="subheader3"><br>
                    V.P.O Nurpur Bedi</span><br>
                  <span class="subheader3">Distt. Ropar Punjab</span></td>
              </tr>
              <tr>
                <td height="27" colspan="2" align="center" valign="top"><span class="subheader3">Monthly Transport Fee</span></td>
              </tr>
              <tr>
                <td width="159" height="27" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?></span></td>
                <td width="220" align="center" valign="top"><span class="subheader2">Date:<?php   $TrDate;echo $new_date = date('d-m-Y', strtotime($TrDate));?></span></td>
              </tr>
            </table>
              <table width="377" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="24" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="2" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                </tr>
                <tr align="left">
                  <td height="19" colspan="4" align="left"><span class="bpart">S/O/D/O :</span><span class="bpart">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo 'Mr.'.$FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="76" height="29" align="left" class="bpart">Class:</td>
                  <td width="56" align="left" class="bpart"><?php  $CClass;	$hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];}?></td>
                  <td width="85" align="left" class="bpart">Student Id:</td>
                  <td width="160" align="left" class="bpart"><?php echo $SID;?></td>
                </tr>
                <tr >
                  <td height="36" colspan="2" align="left" class="bpart">For the month of :</td>
                  <td height="36" colspan="2" align="left" class="bpart"><?php $sq=mysql_query($sqd="Select * from  month WHERE SrNo='$SrNo' And MSID='$msid'");
while($sqw=mysql_fetch_array($sq)){ $sqw['MonthName'];
 $monh=$sqw['MonthName'];
if($monh=='April'){echo 'April';}
else if($monh=='May'){ echo 'May,Jun,Jul';}
else if($monh=='August'){ echo 'Aug,Sep,Oct';}
else if($monh=='November'){ echo 'Nov,Dec';}
else if($monh=='January'){ echo 'Jan,Feb,Mar';}
else {echo $monh;} 

}?>
                    <?php echo $feeyr;?></td>
                </tr>
              </table>
              <br>
              <table width="371" border="1" align="center">
                <tr class="bpart">
                  <td width="212" height="21">Particulars of Fee </td>
                  <td width="143" align="right">Amount</td>
                </tr>
                <tr class="bpart">
                  <td height="27">Transport Charges</td>
                  <td align="right"  class="bpart"><?php   	echo $total=round($Amount);$tAMT=$total+ $tAMT; ?>
                    &nbsp;</td>
                </tr>
                <tr>
                  <td height="32" class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php echo $tAMT;  ?>
                    &nbsp;</td>
                </tr>
              </table>
              <table width="366" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="366" class="bpart" ><br>
                    <br>
                    <br>
                    Signature:</td>
                </tr>
              </table></td>
          </tr>
        </table></td>
        <td width="8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td width="293" align="center" valign="top"><table width="372" border="1" height="421" cellspacing="0" cellpadding="0">
          <tr>
            <td width="368" height="419" align="center" valign="top"><table width="379" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(School Copy)</span></td>
              </tr>
              <tr>
                <td height="66" colspan="2" align="center"  ><span class="header1">
                  <!--<img src="<?php // if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo">-->
                  OM SAI TRANSPORT COMPANY</span><span class="subheader3"><br>
                    V.P.O Nurpur Bedi</span><br>
                  <span class="subheader3">Distt. Ropar Punjab</span></td>
              </tr>
              <tr>
                <td height="27" colspan="2" align="center" valign="top"><span class="subheader3">Monthly Transport Fee</span></td>
              </tr>
              <tr>
                <td width="159" height="27" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?></span></td>
                <td width="220" align="center" valign="top"><span class="subheader2">Date:<?php echo $new_date;?></span></td>
              </tr>
            </table>
              <table width="377" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="23" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="2" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                </tr>
                <tr align="left">
                  <td height="21" colspan="4" align="left"><span class="bpart">S/O/D/O :</span><span class="bpart">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo 'Mr.'.$FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="76" height="26" align="left" class="bpart">Class:</td>
                  <td width="56" align="left" class="bpart"><?php  $CClass;	$hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];}?></td>
                  <td width="85" align="left" class="bpart">Student Id:</td>
                  <td width="160" align="left" class="bpart"><?php echo $SID;?></td>
                </tr>
                <tr >
                  <td height="36" colspan="2" align="left" class="bpart">For the month of :</td>
                  <td height="36" colspan="2" align="left" class="bpart"><?php $sq=mysql_query($sqd="Select * from  month WHERE SrNo='$SrNo' And MSID='$msid'");
while($sqw=mysql_fetch_array($sq)){ $sqw['MonthName'];
 $monh=$sqw['MonthName'];
if($monh=='April'){echo 'April';}
else if($monh=='May'){ echo 'May,Jun,Jul';}
else if($monh=='August'){ echo 'Aug,Sep,Oct';}
else if($monh=='November'){ echo 'Nov,Dec';}
else if($monh=='January'){ echo 'Jan,Feb,Mar';}
else {echo $monh;} 

}?>
                    <?php echo $feeyr;?></td>
                </tr>
              </table>
              <br>
              <table width="371" border="1" align="center">
                <tr class="bpart">
                  <td width="212" height="21">Particulars of Fee </td>
                  <td width="143" align="right">Amount</td>
                </tr>
                <tr class="bpart">
                  <td height="27">Transport Charges</td>
                  <td align="right"  class="bpart"><?php   	echo $ytamt=round($Amount); $yytamt=$ytamt+ $yytamt; ?>
                    &nbsp;</td>
                </tr>
                <tr>
                  <td height="32" class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php   echo $yytamt;  ?>
                    &nbsp;</td>
                </tr>
              </table>
              <table width="366" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="366" height="66" class="bpart" ><br>
                    <br>
                    <br>
                    Signature:</td>
                </tr>
              </table></td>
          </tr>
        </table></td>
        <td width="58">&nbsp;&nbsp;</td>
        </tr>
    </table>   </td>
  </tr>
</table><input type="button" value="Print" onClick="printpage();">
  </form>
</div><!--<p class="page"></p>--></body><?php }}?>