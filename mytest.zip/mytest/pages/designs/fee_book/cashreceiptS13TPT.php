<?php
session_start();
include("../../connect/db.php");  
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {      $foo =$_SESSION['admin'];  ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail']; $ViewOption= $row['ViewOption']; 
}$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
   $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session1= $kr['MySession'];
$Begins1= $kr['Begins'];     
$Ends1= $kr['Ends'];        
$ULevel= $kr['ULevel']; }
$c=mysql_query($cl="select * from `2Sessions` where '$dm' Between `Begins` And `Ends` And  `MSID`='$msid'"); while($cr=mysql_fetch_array($c)){ 
    $session= $cr['ID']; $Begins= $cr['Begins']; $Ends= $cr['Ends'];  //MSID 	ID 	Begins 	Ends 
} ?>::Cash Receipt</title>
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script><style type="text/css">
<!--  
.header {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px;
	 
}
.header2 {
		font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 15px;
	 
}
.subheader {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 17px;
}
.subheader1 {
		font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
 
	 
}
.subheader2 {
	font-size: 13px;
	 
}
.bpart {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
}
.bpart2 {
	font-size: 14px;
	font-weight: bold;	

}
.bpart1 {
		font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
 
}
.bpart11 {
	font-size: 14px;
	font-style:italic
 
}
-->
</style><style type="text/css" media="print">
@page
{
 size: landscape;
 margin: 2cm;
}
</style>
</head>

<body><?      
$s_id1=$_GET['s_id'];    $s_id = mysql_real_escape_string($s_id1);
$SrNo1=$_GET['SrNo'];  $SrNo = mysql_real_escape_string($SrNo1);
$m1=$_GET['m'];   $m = mysql_real_escape_string($m1);
$TrDate1=$_GET['TrDate'];  $TrDate = mysql_real_escape_string($TrDate1); 
$TrId1=$_GET['TrId']; $TrId = mysql_real_escape_string($TrId1);
$TridNo1=$_GET['TridNo']; $TridNo = mysql_real_escape_string($TridNo1);  
?><form id="contactform" name="contactform" method="post" action="#">
   <table width="844" border="0" align="center">
     <tr>
       <td width="838"><table width="850" border="0">
         <tr>
           <td width="417"><table width="418" height="331" border="0" align="center">
             <tr align="center" valign="top">
               <td width="412" height="4"></td>
             </tr>
             <tr valign="top">
               <td height="321"><table width="412" height="320" border="0" align="center">
                 <tr>
                   <td width="406" height="316" valign="top"><table width="413" border="0" cellspacing="0" cellpadding="0">
                     <tr>
                       <td width="630" height="76" colspan="3" align="center" valign="top"><span class="header">OM SAI TRANSPORT COMPANY
                         
                         <br />
                         </span> <span class="header2"> V.P.O Nurpur Bedi Distt. Ropar Punjab<br />
                           </span> <span class="header2">Monthly Transport Fee</span><br /></td>
                     </tr>
                     <tr>
                       <td height="3" colspan="3" align="center" valign="top"><hr /></td>
                     </tr>
                   </table>
                     <table width="409" border="0" cellspacing="0" cellpadding="0">
                       <tr>
                         <td height="49" colspan="2" align="center" class="subheader"><u>Transport Fee Receipt</u><span class="subheader1">&nbsp; No:<?php echo $TrId ;?></span></td>
                       </tr>
                       <tr valign="top" class=" ">
                         <td width="191" height="27" align="center" class="bpart1">Receipt Date:</td>
                         <td width="218" align="left" class="bpart"><?php   echo $new_date = date('d-M-Y', strtotime($TrDate)); ?></td>
                       </tr>
                       <tr valign="top" class=" ">
                         <td height="2" colspan="2" align="left" class="bpart1"><hr/></td>
                       </tr>
                       <tr>
                         <?php 
  
   $result9=mysql_query($sql9="SELECT T.TrDate, T.TrId,T.Narration,Q1.Amt,T.LateFee,T.Session FROM 39Transactions T INNER JOIN (SELECT `TrId`,ROUND(`Rate`) Amt FROM `39TransactionDTL` where Status!='0' GROUP By `TrId`) AS Q1 ON T.TridNo=Q1.TrId WHERE T.MSID='$msid' AND T.Session='$session'  AND T.TrDate='$TrDate' AND T.Costcenter='$s_id' And  Status!='0' And  T.TrId='$TrId'  And  T.TridNo='$TridNo' ORDER BY T.TrDate");while($row9=mysql_fetch_array($result9)){ 
       $TrDate= $row9['TrDate'];  $TrId= $row9['TrId']; $Amt= $row9['Amt'];$Narration= $row9['Narration']; $LateFee= $row9['LateFee']; $Fyear= $row9['Session'];$gtotal=$Amt+$LateFee; 
 }
   $d6=mysql_query($sql6="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.AdmNo='$s_id' And P.MSID='$msid' OR  S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.Id='$s_id' And P.MSID='$msid'");
 while($row6=mysql_fetch_array($d6)){  $AcNo=$row6['sid'];$P_ID=$row6['PID'];$g=$row6['Gender'];$AdmNo=$row6['AdmNo'];$Id=$row6['sid'];
  $Name=$row6['Name'];
 $village=$row6['Village1'];$CClass=$row6['CClass'];   $FatherName=$row6['FatherName']; }$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){    $ClassName=$row2['ClassName']; }
  $m; $j=mysql_query($jsql="select * from month where Monthno='$m' "); while($jrow=mysql_fetch_array($j)){   	    $Month= $jrow['Month'];} $Fyear;  ?>
                         <?php  ?>
                         <td height="70" colspan="2" align="left"><p><span class="bpart1">Received a sum of Rs <strong>
                           <?php  echo $gtotal; ?>
                           </strong> from
                           <?php   echo $Name;?>
                           <?php if($g=='F'){?>
                           D/O
                           <?php }else {?>
                           S/O
                           <?php }?>
                           Mr.<?php echo $FatherName;?> R/O <?php echo $village;?> of <?php echo  $ClassName;?> class Admission No. <strong>
                             <?php  if($ViewOption=='0'){echo $Id;}else {echo $AdmNo;}?>
                             </strong> on A/C of Fees for the month of
                           <?php  echo  $Month;?>
                           ,
                           <?php  echo  $Fyear.' '.$Narration ; ?>
                           .</span></p></td>
                       </tr>
                     </table></td>
                 </tr>
               </table>
                 <br />
                 <table width="290" border="0" align="right">
                   <tr>
                     <td align="right"><span class="bpart1"> </span></td>
                   </tr>
                   <tr>
                     <td align="right"><span class="bpart">Authorised Signatury</span></td>
                   </tr>
                   <tr>
                     <td align="right" class="bpart"><!--<a href="../../../../code/view_billbybill_details.php" style="text-decoration:none" class="bpart"  onclick="printpage();"><?php //echo $un;}?></a>--></td>
                   </tr>
                 </table></td>
             </tr>
           </table>
           </td>
           <td width="10">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
           <td width="418"><table width="418" height="331" border="0" align="center">
             <tr align="center" valign="top">
               <td width="412" height="4"></td>
             </tr>
             <tr valign="top">
               <td height="321"><table width="412" height="317" border="0" align="center">
                 <tr>
                   <td width="406" height="313" valign="top"><table width="413" border="0" cellspacing="0" cellpadding="0">
                     <tr>
                       <td width="630" height="78" colspan="3" align="center" valign="top"><span class="header">OM SAI TRANSPORT COMPANY <br />
                         </span> <span class="header2"> V.P.O Nurpur Bedi Distt. Ropar Punjab<br />
                           </span> <span class="header2">Monthly Transport Fee</span><br /></td>
                     </tr>
                     <tr>
                       <td height="2" colspan="3" align="center" valign="top"><hr /></td>
                     </tr>
                   </table>
                     <table width="409" border="0" cellspacing="0" cellpadding="0">
                       <tr>
                         <td height="42" colspan="2" align="center" class="subheader"><u>Transport Fee Receipt</u><span class="subheader1">&nbsp; No:<?php echo $TrId ;?></span></td>
                       </tr>
                       <tr valign="top" class=" ">
                         <td width="191" height="27" align="center" class="bpart1">Receipt Date:</td>
                         <td width="218" align="left" class="bpart"><?php   echo $new_date = date('d-M-Y', strtotime($TrDate)); ?></td>
                       </tr>
                       <tr valign="top" class=" ">
                         <td height="2" colspan="2" align="left" class="bpart1"><hr/></td>
                       </tr>
                       <tr>
                         <?php 
  
   $result9=mysql_query($sql9="SELECT T.TrDate, T.TrId,T.Narration,Q1.Amt,T.LateFee,T.Session FROM 39Transactions T INNER JOIN (SELECT `TrId`,ROUND(`Rate`) Amt FROM `39TransactionDTL` where Status!='0' GROUP By `TrId`) AS Q1 ON T.TridNo=Q1.TrId WHERE T.MSID='$msid' AND T.Session='$session'  AND T.TrDate='$TrDate' AND T.Costcenter='$s_id' And  Status!='0' And  T.TrId='$TrId'  And  T.TridNo='$TridNo'  ORDER BY T.TrDate");while($row9=mysql_fetch_array($result9)){ 
       $TrDate= $row9['TrDate'];  $TrId= $row9['TrId']; $Amt= $row9['Amt'];$Narration= $row9['Narration'];  $LateFee= $row9['LateFee']; $Fyear= $row9['Session'];$gtotal=$Amt+$LateFee; 
 }
   $d6=mysql_query($sql6="SELECT (S.Id)as sid,S.*,P.*,L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id and S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village and P.MSID=L.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.AdmNo='$s_id' And P.MSID='$msid' OR  S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.Id='$s_id' And P.MSID='$msid'");
 while($row6=mysql_fetch_array($d6)){  $AcNo=$row6['sid'];$P_ID=$row6['PID'];$g=$row6['Gender'];$AdmNo=$row6['AdmNo'];$Id=$row6['sid'];
  $Name=$row6['Name'];
 $village=$row6['Village1'];$CClass=$row6['CClass'];   $FatherName=$row6['FatherName']; }$result2=mysql_query($sql2="select distinct ClassName,ClassNo,MSID from `17Class` where  ClassNo='$CClass' And MSID='$msid' order by ClassNo ASC ");
	  while($row2=mysql_fetch_array($result2)){    $ClassName=$row2['ClassName']; }
  $m; $j=mysql_query($jsql="select * from month where Monthno='$m' "); while($jrow=mysql_fetch_array($j)){   	    $Month= $jrow['Month'];} $Fyear;  ?>
                         <?php  ?>
                         <td height="70" colspan="2" align="left"><p><span class="bpart1">Received a sum of Rs <strong>
                           <?php  echo $gtotal; ?>
                           </strong> from
                           <?php   echo $Name;?>
                           <?php if($g=='F'){?>
                           D/O
                           <?php }else {?>
                           S/O
                           <?php }?>
                           Mr.<?php echo $FatherName;?> R/O <?php echo $village;?> of <?php echo  $ClassName;?> class Admission No. <strong>
                             <?php  if($ViewOption=='0'){echo $Id;}else {echo $AdmNo;}?>
                             </strong> on A/C of Fees for the month of
                           <?php  echo  $Month;?>
                           ,
                           <?php  echo  $Fyear.' '.$Narration ; ?>
                           .</span></p></td>
                       </tr>
                     </table></td>
                 </tr>
               </table>
                 <br />
                 <table width="290" border="0" align="right">
                   <tr>
                     <td align="right"><span class="bpart1"> </span></td>
                   </tr>
                   <tr>
                     <td align="right"><span class="bpart">Authorised Signatury</span></td>
                   </tr>
                   <tr>
                     <td align="right" class="bpart"><!--<a href="../../../../code/view_billbybill_details.php" style="text-decoration:none" class="bpart"  onclick="printpage();"><?php //echo $un;}?></a>--></td>
                   </tr>
                 </table></td>
             </tr>
           </table></td>
         </tr>
       </table></td>
     </tr>
   </table>
  <input type="button" value="Print" onClick="printpage();">
 </form>
</body>
</html><?php }?>