<?php   
session_start();
include("../../connect/db.php");   
$msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {  $s_id1=$_GET['s_id'];   $s_id = mysql_real_escape_string($s_id1);
	  $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
   $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } 

/* ===========================Update Fee======================*/

$result=mysql_query ($sql="SELECT S.Id,S.AcNo FROM `13Students` S INNER JOIN 12Parents P ON S.PID=P.ID AND S.MSID= P.MSID WHERE S.MSID='$msid'   And  S.Id='$s_id' ");  $nr=mysql_num_rows($result);
 while($row=mysql_fetch_array($result)){  		$s_id=$row['Id']; 	  	$AcNo=$row['AcNo']; }
mysql_query($kl="Delete From `39Fee` where `MSID`='$msid' And `FeeId`>='0' And `AcNo` ='$AcNo' and DueDate between  '$Begins' And '$Ends' ");



mysql_query($kl="
INSERT INTO `39Fee`(`MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`, `FeeAmt`, `FeeGroup`, `Session`, `Class`, `FatherName`, `Village`, `MobileSMS`, `FeeName`, `House`, `StudentName`) 
Select CSD.MSID MSID,CSD.AcNo AcNo,CSD.SID SID,CSD.SrNo SrNo,FS.RSrNo RSrNo,CSD.DueDate DueDate,CSD.FeeId FeeId,round(Sum(If(FEE.FeeId=0,COALESCE(TR.TptRate,0), 

FEE.FeeRate))*(1-COALESCE (DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.FeeGroup FeeGroup,CSD.MySession Session,CC.ClassName,CSD.FatherName FatherName,CSD.Village1 Village,CSD.MobileSMS,CSD.FeeName FeeName,HH.HouseFName House,CSD.StudentName Name
From (
Select Q1.*,If(Month(Q1.DueDate)-Month(Q1.Begins)+1 >0,Month(Q1.DueDate)-Month(Q1.Begins)+1,Month(Q1.DueDate)-Month (Q1.Begins)+13) SrNo 

,Q1.AdmClassNo+Year(Q1.Begins)-Year(Q1.FSDate)+COALESCE(Sum(E.Result),0) 

CClass,SFG.FgroupId,SAT.TptStation,DS.Discount,P.FatherName,P.MobileSMS,P.FeePaymentMode,L.Village1 
FROM (
Select S.Id SID,S.PID,S.AcNo,S.Name StudentName,S.AdmClassNo,S.FSDate,S.SLDate,S.GroupId,S.OpeningBal,DD.DateId DueDate,FN.Id 

FeeId,FN.FeeName,FN.FeeGroup,COY.Name SchoolName,COY.SeprateTPTFBook,CU.MSID,CU.Mydate,CU.MySession,CU.Begins,CU.Ends,CU.MyUid,S.House From (SELECT * 

FROM `91Users` WHERE MyUid = '$foo' ) CU	Inner Join 10Company COY On COY.MSID = CU.MSID Inner Join 6Dates DD On DD.DateId Between 

CU.Begins And CU.Ends And Day(DateId) = '1' Inner Join 13Students S On S.MSID =CU.MSID And DD.DateID Between S.FSDate And S.SLDate Inner 

Join 7FeeNames FN On FN.MSID=CU.MSID 
Where S.AcNo='$AcNo'


) Q1 
      
Left Join 
14Exam E On E.MSID = Q1.MSID AND E.S_Id=Q1.SID And E.DateResult<Q1.DueDate 
Inner Join 
100SchoolFeeGrp SFG On SFG.MSID=Q1.MSID AND SFG.GroupId=Q1.GroupId 
Left Join 
35SATpt SAT ON SAT.MSID=Q1.MSID And Q1.DueDate Between SAT.DateFrom And SAT.DateTo And SAT.S_Id=Q1.SID 
Left Join 
34DiscountedStudent DS ON DS.MSID=Q1.MSID And DS.S_Id=Q1.SID And Q1.DueDate Between DS.DateFrom And DS.DateTo 
Inner Join 
12Parents P On P.Id=Q1.PID
Inner Join
11Localities L On L.MSID=Q1.MSID And L.Village=P.Village 
Where 1
Group By Q1.SID, Q1.DueDate,Q1.FeeId

) CSD
inner join 17Class CC on CC.msid=CSD.msid and CC.ClassNo=CSD.CClass left join 3Houses HH on HH.MSID=CSD.MSID and HH.id=CSD.house
 
Inner Join 
31FeeSchedule FS On FS.MSID=CSD.MSID And FS.PayMode=CSD.FeePaymentMode  And CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo
Inner Join 
31Fee1 FEE On FEE.MSID=CSD.MSID And CSD.DueDate Between FEE.DateFrom And FEE.DateTo And FEE.FeeId=CSD.FeeId And CSD.CClass Between 

FEE.ClassFrom And 

FEE.ClassTo And 
(CSD.FGroupId=FEE.FGroupId Or FEE.FGroupId = '0') And If(FEE.FF='1' And CSD.DueDate=CSD.FSDate,CSD.SrNo Between FEE.FFFrom And 

FEE.FFTo,CSD.SrNo Between 

FEE.SrNoFrom And FEE.SrNoTo)
Left Join 
36TptRate TR On TR.MSID=CSD.MSID And CSD.DueDate Between TR.DateFrom And TR.DateTo And CSD.TptStation=TR.TptStation
Left Join 
33DiscountRule DR On DR.MSID=CSD.MSID And CSD.DueDate Between DR.DateFrom And DR.DateTo And DR.Discount=CSD.Discount And 

DR.FeeId=FEE.FeeId And CSD.CClass 

Between DR.ClassFrom And DR.ClassTo And CSD.SrNo Between DR.SrNoFrom And DR.SrNoTo 
Group By AcNo,SrNo,SID,FeeId");

/* ===========================Update Fee End ======================*/

?> 
<style type="text/css">
<!--  
.header {
	font-size: 20px;
	font-weight:bold;
	 font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader {
	font-size: 17px;font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader1 {
font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 11px;
	 
}
.subheader2 {
	font-size: 13px;font-family: Verdana, Arial, Helvetica, sans-serif;
	 
}
.bpart {
 
font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.bpart2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
	 
	font-weight: bold;	

}
.bpart1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
 
}
.bpart11 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
 
	font-size: 12px;
	font-style:italic
 
}
.bpart21 {	font-family: Verdana, Arial, Helvetica, sans-serif;
 font-size: 18px;
}
.bpart3 {font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 13px;
}
.bpart12 {	font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;
}
.bpart4 {	font-size: 13px;
}
.note {font-size: 10px;}
-->
</style><!--<link href="css/glfee.css"  rel="stylesheet" type="text/css" media="all" />--> <?php 
 
  $nd=mysql_query($nsql="SELECT (S.Id)as sid,S.Name,S.*,P.*,F.*,Month(F.`DueDate`)as mon,Year(F.`DueDate`)as Year,(L.Village) as LVill, L.Village1, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village INNER Join 39Fee F ON S.Id=F.SID and S.MSID=F.MSID LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Begins' And S.Id='$s_id' And F.DueDate BETWEEN '$Begins' And '$Ends' And P.MSID='$msid' GROUP BY F.RSrNo,S.Id ORDER BY F.RSrNo"); while($nrow=mysql_fetch_array($nd)){  

$s_id= $nrow['Id']; $SID= $nrow['AcNo'];$FeeId= $nrow['FeeId'];   $Gender= $nrow['Gender']; $SrNoFrom= $nrow['SrNoFrom']; $SrNoTo= $nrow['SrNoTo']; $Name= $nrow['Name']; $FatherName= $nrow['FatherName'];  $Village= $nrow['Village'];$RSrNo= $nrow['RSrNo'];$SrNo= $nrow['SrNo']; $MonthNo= $nrow['mon']; 
 $feeyr= $nrow['Year'];  $FeeGroup= $nrow['FeeGroup'];  $TNetAmt= $nrow['NetAmt'];   $CClass= $nrow['CClass']; $section= $nrow['Section'];
?>
<title><?php $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
  $Place= $row['Place'];
    $AffNo= $row['AffNo'];
	 $SchoolNo= $row['SchoolNo'];
	 	 $Phone= $row['Phone'];
$Board= $row['Board'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$BankCash= $row['BankCash'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$EMail= $row['EMail'];
$LatefeeDate= $row['LatefeeDate'];
$SFeebookR= $row['SFeebookR']; 
$BankCash=$row['BankCash']; 
$FeePaymentmode= $row['FeePaymentmode'];
$bank= $row['Bank']; $branch= $row['Branch'];$acno=$row['ACNo'];
}?></title><body>
<style>
p.page { page-break-after: always; }
</style><div class="tmbanner1">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr> 
    <td height="587" align="center" valign="top"><table width="300" height="539" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="539" valign="top"><table width="293" border="1" height="538" cellspacing="0" cellpadding="0">
          <tr>
            <td width="289" height="536" align="center" valign="top"><table width="280" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Student Copy)</span></td>
              </tr>
              <tr>
                <td width="51" align="center"  ><span class="header"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo"></span></td>
                <td width="237" align="center" valign="top"  ><span class="header">
                  <?php     echo $sname;?>
                  <br>
                </span><span class="subheader"><?php echo $Place;?></span></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                  <table width="288" border="0" align="center">
                    <tr>
                      <td width="223" align="center" class="bpart1"><?php echo $bank.' '.'A/C'.' '.$acno;?></td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?></span></td>
              </tr>
            </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="2" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                </tr>
                <tr align="left">
                  <td height="24" colspan="4" align="left"><span class="bpart">
                    <? if($Gender=='F'){echo "D/O";}else {echo "S/O";}?>
                    : Mr. <?php echo $FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="58" height="28" align="left" class="bpart">Class:</td>
                  <td width="76" align="left" class="bpart"><?php  $CClass;	$hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];} ?>
                    (
                    <? $section;   $dss=mysql_query($sqlss="select * from `4Sections` where MSID='$msid' And ID='$section'"); while($rowss=mysql_fetch_array($dss)){	
echo $Sectionname= $rowss['Sectionname'];}  ?>
                    ) </td>
                  <td width="83" align="left" class="bpart">Student Id:</td>
                  <td width="63" align="left" class="bpart"><?php echo $SID;?></td>
                </tr>
                <tr >
                  <td height="12" colspan="2" align="left" class="bpart">For the month of :</td>
                  <td height="12" colspan="2" align="left" class="bpart"><?php 
				  
				  $sq=mysql_query($sqd="SELECT * FROM `31FeeSchedule` WHERE `MSID`='$msid' and  `RSrNo`='$RSrNo' ORDER BY `RSrNo` ASC ");
				  $numrows=mysql_num_rows($sq);
				  while($sqw=mysql_fetch_array($sq)){  $SrNoFrom=$sqw['SrNoFrom'];  $SrNoTo=$sqw['SrNoTo']; 
				  if($numrows>'1'){
 

 $sq1=mysql_query($sqd1="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `SrNo` ASC ");
while($sqw1=mysql_fetch_array($sq1)){   $mname1=$sqw1['Month']; echo $mname1.' '; }
 }
 else if($SrNoFrom!=$SrNoTo) {  
$sq2=mysql_query($sqd2="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and `SrNo` between '$SrNoFrom' And '$SrNoTo'  ORDER BY `Monthno` ASC ");
while($sqw2=mysql_fetch_array($sq2)){  $mname2=$sqw2['Month']; echo $mname2.' '; } ?>
                    &nbsp;
                    <?  } else{
				  
				   $sq4=mysql_query($sqd4="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `Monthno` ASC ");
while($sqw4=mysql_fetch_array($sq4)){  echo $mname4=$sqw4['Month'];} } }?>
                    <?php echo  $feeyr;?></td>
                </tr>
                <? if($LatefeeDate!='0'){ ?>
                <tr >
                  <td height="12" colspan="2" align="left" class="bpart"><span class="bpart4">Last Date</span> :</td>
                  <td height="12" colspan="2" align="left" class="bpart"><? echo $LatefeeDate;?>
                    <? $sq4=mysql_query($sqd4="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `Monthno` ASC ");
while($sqw4=mysql_fetch_array($sq4)){  echo $mname4=$sqw4['Month'];} ?>
                    <?php echo  $feeyr;?></td>
                </tr>
                <? }else{}?>
              </table>
              <table width="287" border="1" align="center">
                <tr class="bpart">
                  <td width="212">Particulars of Fee </td>
                  <td width="59" align="right">Amount</td>
                </tr>
                <?php  
				 $ghi=mysql_query($gh="SELECT * FROM `7FeeNames` Where   `MSID`='$msid' And `ID`='$FeeId' Group by FeeGroup ");
				 while($gow=mysql_fetch_array($ghi)){     $ann1=$gow['FeeGroup']; 
	 $dt=mysql_query($d="SELECT F. `MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`,S.`FeeGroup`, round(Sum(`FeeAmt`)) as AMT FROM `39Fee` F INNER JOIN `7FeeNames` S ON F.FeeId=S.ID WHERE F.AcNo='$SID' And F.RSrNo='$RSrNo' And F.MSID='$msid' And S.MSID='$msid' And F.DueDate between '$Begins' And '$Ends' And FeeAmt>'0' GROUP BY F.RSrNo ,S.FeeGroup"); 
while($dtw=mysql_fetch_array($dt)){$Amount1=$dtw['AMT']; $SrNoFrom=$dtw['SrNoFrom'];  $SrNoTo=$dtw['SrNoTo'];     
   ?>
                <tr class="bpart">
                  <td><?php  echo    $FeeGroup=$dtw['FeeGroup'];
				  
				     ?></td>
                  <td align="right"  class="bpart"><?php   echo ($Amount1);
 ?>
                    &nbsp;</td>
                </tr>
                <?php  }    }?>
                <tr>
                  <td class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php  $dt4=mysql_query($d4="SELECT F. `MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`,S.`FeeGroup`,  round(SUM(`FeeAmt`))  as TNetAmt FROM `39Fee` F INNER JOIN `7FeeNames` S ON F.FeeId=S.ID WHERE F.AcNo='$SID' And F.RSrNo='$RSrNo' And F.MSID='$msid' And F.DueDate between '$Begins' And '$Ends' And S.MSID='$msid' GROUP BY F.RSrNo"); 
while($dtw4=mysql_fetch_array($dt4)){$TNetAmt=$dtw4['TNetAmt'];     echo  round($TNetAmt);
 }?>
                    &nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Late Fee/Previous Balance,if any</td>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Grand Total</td>
                  <td align="right">&nbsp;</td>
                </tr>
              </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><table width="287" border="0" align="center">
                    <tr class="bpart3">
                      <td height="17" colspan="2" class="bpart3"><u class="bpart12">Received Cash 
                        Rs.(In words)</u></td>
                    </tr>
                    <tr class="bpart3">
                      <td height="24" class="bpart3">_________________</td>
                      <td width="149" rowspan="8"><table width="148" border="1">
                        <tr>
                          <td colspan="2" align="center"><u class="bpart12">Note Details</u></td>
                        </tr>
                        <tr>
                          <td width="67"><span class="bpart12">1000 &nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td width="65"><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">500 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">100 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">50 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">20 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">10 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td align="right"><span class="bpart12">Total</span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                      </table></td>
                    </tr>
                    <tr class="bpart3">
                      <td width="128" height="24">_________________</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="24">_________________</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="24">_________________</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="11">&nbsp;</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="4">Cashier:</td>
                    </tr>
                    <tr class="bpart3">
                      <td>&nbsp;</td>
                    </tr>
                    <tr class="bpart3">
                      <td>Depositor Signature</td>
                    </tr>
                    <tr class="bpart3">
                      <td colspan="2"><p class='note'><b>Note:</b> In Case of any discrepancies please contact school office for the changes in fee slips.</p></td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td align="center" valign="top"><? if($BankCash!='Cash'){?>
          <table width="293" border="1" height="538" cellspacing="0" cellpadding="0">
            <tr>
              <td width="289" height="536" align="center" valign="top"><table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Bank Copy)</span></td>
                </tr>
                <tr>
                  <td width="51" align="center"  ><span class="header"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo"></span></td>
                  <td width="237" align="center" valign="top"  ><span class="header">
                    <?php     echo $sname;?>
                    <br>
                  </span><span class="subheader"><?php echo $Place;?></span></td>
                </tr>
                <tr>
                  <td height="18" colspan="2" align="center" valign="top"><span class="header">
                    <table width="288" border="0" align="center">
                      <tr>
                        <td width="223" align="center" class="bpart1"><?php echo $bank.' '.'A/C'.' '.$acno;?></td>
                      </tr>
                    </table></td>
                </tr>
                <tr>
                  <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?></span></td>
                </tr>
              </table>
                <table width="280" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                    <td colspan="2" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                  </tr>
                  <tr align="left">
                    <td height="24" colspan="4" align="left"><span class="bpart">
                      <? if($Gender=='F'){echo "D/O";}else {echo "S/O";}?>
                      : Mr. <?php echo $FatherName;?></span></td>
                  </tr>
                  <tr>
                    <td width="65" height="28" align="left" class="bpart">Class:</td>
                    <td width="63" align="left" class="bpart"><?php  $CClass;	$hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];} ?>
                      (
                      <? $section;   $dss=mysql_query($sqlss="select * from `4Sections` where MSID='$msid' And ID='$section'"); while($rowss=mysql_fetch_array($dss)){	
echo $Sectionname= $rowss['Sectionname'];}  ?>
                      ) </td>
                    <td width="89" align="left" class="bpart">Student Id:</td>
                    <td width="63" align="left" class="bpart"><?php echo $SID;?></td>
                  </tr>
                  <tr >
                    <td height="12" colspan="2" align="left" class="bpart">For the month of :</td>
                    <td height="12" colspan="2" align="left" class="bpart"><?php 
				  
				  $sq=mysql_query($sqd="SELECT * FROM `31FeeSchedule` WHERE `MSID`='$msid' and  `RSrNo`='$RSrNo' ORDER BY `RSrNo` ASC ");
				  $numrows=mysql_num_rows($sq);
				  while($sqw=mysql_fetch_array($sq)){  $SrNoFrom=$sqw['SrNoFrom'];  $SrNoTo=$sqw['SrNoTo']; 
				  if($numrows>'1'){
 

 $sq1=mysql_query($sqd1="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `SrNo` ASC ");
while($sqw1=mysql_fetch_array($sq1)){   $mname1=$sqw1['Month']; echo $mname1.' '; }
 }
 else if($SrNoFrom!=$SrNoTo) {  
$sq2=mysql_query($sqd2="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and `SrNo` between '$SrNoFrom' And '$SrNoTo'  ORDER BY `Monthno` ASC ");
while($sqw2=mysql_fetch_array($sq2)){  $mname2=$sqw2['Month']; echo $mname2.' '; } ?>
                      &nbsp;
                      <?  } else{
				  
				   $sq4=mysql_query($sqd4="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `Monthno` ASC ");
while($sqw4=mysql_fetch_array($sq4)){  echo $mname4=$sqw4['Month'];} } }?>
                      <?php echo  $feeyr;?></td>
                  </tr>
                  <? if($LatefeeDate!='0'){ ?>
                  <tr >
                    <td height="12" colspan="2" align="left" class="bpart"><span class="bpart4">Last Date</span> :</td>
                    <td height="12" colspan="2" align="left" class="bpart"><? echo $LatefeeDate;?>
                      <? $sq4=mysql_query($sqd4="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `Monthno` ASC ");
while($sqw4=mysql_fetch_array($sq4)){  echo $mname4=$sqw4['Month'];} ?>
                      <?php echo  $feeyr;?></td>
                  </tr>
                  <? }else{}?>
                </table>
                <table width="287" border="1" align="center">
                  <tr class="bpart">
                    <td width="212">Particulars of Fee </td>
                    <td width="59" align="right">Amount</td>
                  </tr>
                  <?php  
				 $ghi=mysql_query($gh="SELECT * FROM `7FeeNames` Where   `MSID`='$msid' And `ID`='$FeeId' Group by FeeGroup ");
				 while($gow=mysql_fetch_array($ghi)){     $ann1=$gow['FeeGroup']; 
	 $dt=mysql_query($d="SELECT F. `MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`,S.`FeeGroup`, round(Sum(`FeeAmt`)) as AMT FROM `39Fee` F INNER JOIN `7FeeNames` S ON F.FeeId=S.ID WHERE F.AcNo='$SID' And F.RSrNo='$RSrNo' And F.MSID='$msid' And S.MSID='$msid' And F.DueDate between '$Begins' And '$Ends' And FeeAmt>'0' GROUP BY F.RSrNo ,S.FeeGroup"); 
while($dtw=mysql_fetch_array($dt)){$Amount1=$dtw['AMT']; $SrNoFrom=$dtw['SrNoFrom'];  $SrNoTo=$dtw['SrNoTo'];     
   ?>
                  <tr class="bpart">
                    <td><?php  echo    $FeeGroup=$dtw['FeeGroup'];
				  
				     ?></td>
                    <td align="right"  class="bpart"><?php   echo ($Amount1);
 ?>
                      &nbsp;</td>
                  </tr>
                  <?php  }    }?>
                  <tr>
                    <td class="bpart">Total</td>
                    <td align="right" class="bpart" ><?php  $dt4=mysql_query($d4="SELECT F. `MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`,S.`FeeGroup`,  round(SUM(`FeeAmt`))  as TNetAmt FROM `39Fee` F INNER JOIN `7FeeNames` S ON F.FeeId=S.ID WHERE F.AcNo='$SID' And F.RSrNo='$RSrNo' And F.MSID='$msid' And F.DueDate between '$Begins' And '$Ends' And S.MSID='$msid' GROUP BY F.RSrNo"); 
while($dtw4=mysql_fetch_array($dt4)){$TNetAmt=$dtw4['TNetAmt'];     echo  round($TNetAmt);
 }?>
                      &nbsp;</td>
                  </tr>
                  <tr>
                    <td class="bpart">Late Fee/Previous Balance,if any</td>
                    <td align="right">&nbsp;</td>
                  </tr>
                  <tr>
                    <td class="bpart">Grand Total</td>
                    <td align="right">&nbsp;</td>
                  </tr>
                </table>
                <table width="280" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><table width="287" border="0" align="center">
                      <tr class="bpart3">
                        <td height="17" colspan="2" class="bpart3"><u class="bpart12">Received Cash 
                          Rs.(In words)</u></td>
                      </tr>
                      <tr class="bpart3">
                        <td height="24" class="bpart3">_________________</td>
                        <td width="149" rowspan="8"><table width="148" border="1">
                          <tr>
                            <td colspan="2" align="center"><u class="bpart12">Note Details</u></td>
                          </tr>
                          <tr>
                            <td width="67"><span class="bpart12">1000 &nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                            <td width="65"><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                          <tr>
                            <td><span class="bpart12">500 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                            <td><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                          <tr>
                            <td><span class="bpart12">100 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                            <td><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                          <tr>
                            <td><span class="bpart12">50 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                            <td><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                          <tr>
                            <td><span class="bpart12">20 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                            <td><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                          <tr>
                            <td><span class="bpart12">10 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                            <td><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                          <tr>
                            <td><span class="bpart12">5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                            <td><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                          <tr>
                            <td align="right"><span class="bpart12">Total</span></td>
                            <td><span class="bpart12">&nbsp;=</span></td>
                          </tr>
                        </table></td>
                      </tr>
                      <tr class="bpart3">
                        <td width="128" height="24">_________________</td>
                      </tr>
                      <tr class="bpart3">
                        <td height="24">_________________</td>
                      </tr>
                      <tr class="bpart3">
                        <td height="24">_________________</td>
                      </tr>
                      <tr class="bpart3">
                        <td height="11">&nbsp;</td>
                      </tr>
                      <tr class="bpart3">
                        <td height="4">Cashier:</td>
                      </tr>
                      <tr class="bpart3">
                        <td>&nbsp;</td>
                      </tr>
                      <tr class="bpart3">
                        <td>Depositor Signature</td>
                      </tr>
                      <tr class="bpart3">
                        <td colspan="2"><p class='note'><b>Note:</b> In Case of any discrepancies please contact school office for the changes in fee slips.</p></td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
            </tr>
          </table>          <? }?></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td align="center" valign="top"><table width="293" border="1" height="538" cellspacing="0" cellpadding="0">
          <tr>
            <td width="289" height="536" align="center" valign="top"><table width="280" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Student Copy)</span></td>
              </tr>
              <tr>
                <td width="51" align="center"  ><span class="header"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo"></span></td>
                <td width="237" align="center" valign="top"  ><span class="header">
                  <?php     echo $sname;?>
                  <br>
                </span><span class="subheader"><?php echo $Place;?></span></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                  <table width="288" border="0" align="center">
                    <tr>
                      <td width="223" align="center" class="bpart1"><?php echo $bank.' '.'A/C'.' '.$acno;?></td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?></span></td>
              </tr>
            </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="2" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                </tr>
                <tr align="left">
                  <td height="24" colspan="4" align="left"><span class="bpart">
                    <? if($Gender=='F'){echo "D/O";}else {echo "S/O";}?>
                    : Mr. <?php echo $FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="60" height="28" align="left" class="bpart">Class:</td>
                  <td width="68" align="left" class="bpart"><?php  $CClass;	$hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];} ?>
                    (
                    <? $section;   $dss=mysql_query($sqlss="select * from `4Sections` where MSID='$msid' And ID='$section'"); while($rowss=mysql_fetch_array($dss)){	
echo $Sectionname= $rowss['Sectionname'];}  ?>
                    ) </td>
                  <td width="89" align="left" class="bpart">Student Id:</td>
                  <td width="63" align="left" class="bpart"><?php echo $SID;?></td>
                </tr>
                <tr >
                  <td height="12" colspan="2" align="left" class="bpart">For the month of :</td>
                  <td height="12" colspan="2" align="left" class="bpart"><?php 
				  
				  $sq=mysql_query($sqd="SELECT * FROM `31FeeSchedule` WHERE `MSID`='$msid' and  `RSrNo`='$RSrNo' ORDER BY `RSrNo` ASC ");
				  $numrows=mysql_num_rows($sq);
				  while($sqw=mysql_fetch_array($sq)){  $SrNoFrom=$sqw['SrNoFrom'];  $SrNoTo=$sqw['SrNoTo']; 
				  if($numrows>'1'){
 

 $sq1=mysql_query($sqd1="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `SrNo` ASC ");
while($sqw1=mysql_fetch_array($sq1)){   $mname1=$sqw1['Month']; echo $mname1.' '; }
 }
 else if($SrNoFrom!=$SrNoTo) {  
$sq2=mysql_query($sqd2="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and `SrNo` between '$SrNoFrom' And '$SrNoTo'  ORDER BY `Monthno` ASC ");
while($sqw2=mysql_fetch_array($sq2)){  $mname2=$sqw2['Month']; echo $mname2.' '; } ?>
                    &nbsp;
                    <?  } else{
				  
				   $sq4=mysql_query($sqd4="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `Monthno` ASC ");
while($sqw4=mysql_fetch_array($sq4)){  echo $mname4=$sqw4['Month'];} } }?>
                    <?php echo  $feeyr;?></td>
                </tr>
                <? if($LatefeeDate!='0'){ ?>
                <tr >
                  <td height="12" colspan="2" align="left" class="bpart"><span class="bpart4">Last Date</span> :</td>
                  <td height="12" colspan="2" align="left" class="bpart"><? echo $LatefeeDate;?>
                    <? $sq4=mysql_query($sqd4="SELECT `MonthName`,`Month` FROM `month` WHERE `MSID`='$msid' and  `SrNo`='$SrNoFrom' ORDER BY `Monthno` ASC ");
while($sqw4=mysql_fetch_array($sq4)){  echo $mname4=$sqw4['Month'];} ?>
                    <?php echo  $feeyr;?></td>
                </tr>
                <? }else{}?>
              </table>
              <table width="287" border="1" align="center">
                <tr class="bpart">
                  <td width="212">Particulars of Fee </td>
                  <td width="59" align="right">Amount</td>
                </tr>
                <?php  
				 $ghi=mysql_query($gh="SELECT * FROM `7FeeNames` Where   `MSID`='$msid' And `ID`='$FeeId' Group by FeeGroup ");
				 while($gow=mysql_fetch_array($ghi)){     $ann1=$gow['FeeGroup']; 
	 $dt=mysql_query($d="SELECT F. `MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`,S.`FeeGroup`, round(Sum(`FeeAmt`)) as AMT FROM `39Fee` F INNER JOIN `7FeeNames` S ON F.FeeId=S.ID WHERE F.AcNo='$SID' And F.RSrNo='$RSrNo' And F.MSID='$msid' And S.MSID='$msid' And F.DueDate between '$Begins' And '$Ends' And FeeAmt>'0' GROUP BY F.RSrNo ,S.FeeGroup"); 
while($dtw=mysql_fetch_array($dt)){$Amount1=$dtw['AMT']; $SrNoFrom=$dtw['SrNoFrom'];  $SrNoTo=$dtw['SrNoTo'];     
   ?>
                <tr class="bpart">
                  <td><?php  echo    $FeeGroup=$dtw['FeeGroup'];
				  
				     ?></td>
                  <td align="right"  class="bpart"><?php   echo ($Amount1);
 ?>
                    &nbsp;</td>
                </tr>
                <?php  }    }?>
                <tr>
                  <td class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php  $dt4=mysql_query($d4="SELECT F. `MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`,S.`FeeGroup`,  round(SUM(`FeeAmt`))  as TNetAmt FROM `39Fee` F INNER JOIN `7FeeNames` S ON F.FeeId=S.ID WHERE F.AcNo='$SID' And F.RSrNo='$RSrNo' And F.MSID='$msid' And F.DueDate between '$Begins' And '$Ends' And S.MSID='$msid' GROUP BY F.RSrNo"); 
while($dtw4=mysql_fetch_array($dt4)){$TNetAmt=$dtw4['TNetAmt'];     echo  round($TNetAmt);
 }?>
                    &nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Late Fee/Previous Balance,if any</td>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Grand Total</td>
                  <td align="right">&nbsp;</td>
                </tr>
              </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><table width="287" border="0" align="center">
                    <tr class="bpart3">
                      <td height="17" colspan="2" class="bpart3"><u class="bpart12">Received Cash 
                        Rs.(In words)</u></td>
                    </tr>
                    <tr class="bpart3">
                      <td height="24" class="bpart3">_________________</td>
                      <td width="149" rowspan="8"><table width="148" border="1">
                        <tr>
                          <td colspan="2" align="center"><u class="bpart12">Note Details</u></td>
                        </tr>
                        <tr>
                          <td width="67"><span class="bpart12">1000 &nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td width="65"><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">500 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">100 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">50 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">20 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">10 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td><span class="bpart12">5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                        <tr>
                          <td align="right"><span class="bpart12">Total</span></td>
                          <td><span class="bpart12">&nbsp;=</span></td>
                        </tr>
                      </table></td>
                    </tr>
                    <tr class="bpart3">
                      <td width="128" height="24">_________________</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="24">_________________</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="24">_________________</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="11">&nbsp;</td>
                    </tr>
                    <tr class="bpart3">
                      <td height="4">Cashier:</td>
                    </tr>
                    <tr class="bpart3">
                      <td>&nbsp;</td>
                    </tr>
                    <tr class="bpart3">
                      <td>Depositor Signature</td>
                    </tr>
                    <tr class="bpart3">
                      <td colspan="2"><p class='note'><b>Note:</b> In Case of any discrepancies please contact school office for the changes in fee slips.</p></td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
      </tr>
    </table>   </td>
  </tr>
</table>
</div><p class="page"></p></body><?php } }?>