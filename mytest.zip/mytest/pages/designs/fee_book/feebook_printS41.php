<header> <style type="text/css">
     
        
        .header {
                                font-size: 16px;
                                font-weight:bold;
                                font-family: Verdana, Arial, Helvetica, sans-serif;
                            } 
							 .bpart {

                                font-family:Arial, Helvetica, sans-serif;
                                font-size: 12px; font-weight:bold;
                            }
							 .bpart1 {

                                font-family:Arial, Helvetica, sans-serif;
                                font-size: 12px;  font-weight:bold;
                            }
                        </style>
      
<style type="text/css">
   <!--
   @page { size:5in 5in; margin-bottom:auto; margin-left:20px; }
   -->
</style>
                        
                        
                        </header>
					
<body>						<?php
// print_r($oCurrentSchool);       

$tpt = (@http_get('param3') == "tpt" && $oCurrentSchool->SeprateTPTFBook == "1") ? "2" : (($oCurrentSchool->SeprateTPTFBook == "0") ? "1" : "0");
if (@http_get('param3') == "month") {
    $rsrno = http_get('param4');
}
$tr_id_no = http_get('param5');
?>
 <?php
            $message = new Messages();
            echo $message->display();
            ?>
          
                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
//                print_r($student);   
                 $trxn = Fee::get_txn($MSID, $tr_id_no)->fetch(PDO::FETCH_OBJ);
                ?>
                <?php
                $loops = Fee::get_fee_billing_loops($oCurrentUser->myuid, $student->acno);
                while ($rowv = $loops->fetch(PDO::FETCH_OBJ)) {
                    if (@$rsrno == $rowv->RSrNo) {
                        ?>
	<section class="content">
 <table width="62%" align="left">
                                <tr> 
                                    <td width="47%" align="left" valign="top"><table width="359">
                                            <tr>
                                                <td width="351" valign="top"><table width="355" border="1" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td width="351" align="center" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">

                                                                   <tr>
                                                                   <td align="right" valign="top" colspan="2">Student Copy</td>
                                                                   </tr> 
                                                                   <tr valign="top">
                                                                        <td width="67" rowspan="2" align="center"  ><span class="header"><img src="<?= CLIENT_URL ?>/uploads/thumbs/<?php echo $oCurrentSchool->logo_img; ?>" class="user-image" alt="User Image" width="76" height="56"/></span></td>
                                                                        
                                                                        <td width="100%" align="center" valign="top"  ><span class="header">
                                                                                <?= $oCurrentSchool->name; ?></span></td>
                                                              </tr>
                                                                    
                                                                    <tr>
                                                                      <td height="18" align="center" valign="top"  ><span class="bpart1"><b>
                                                                        <?= $oCurrentSchool->Add_ReportC ?>
                                                                      </b></span></td>
                                                              </tr>

                                                                    <tr>
                                                                        <td colspan="2" align="center" valign="top">
                                                                                                                                                        </td>
                                                                    </tr>
                                                                    
                                                                </table>

                                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td colspan="2" align="left" class="bpart">Student's Name:</td>
                                                                        <td colspan="3" align="left" class="bpart"><?= $student->name ?>&nbsp;</td>
                                                                  </tr>
                                                                    <tr align="left">
                                                                        <td colspan="2" align="left"><span class="bpart"> <?php $g = $student->gender; ?>
                                                                                <?php
                                                                                if ($g == 'F') {
                                                                                    echo 'D/O';
                                                                                } else {
                                                                                    echo 'S/O';
                                                                                }
                                                                                ?>
                                                                                : </span>
                                                                        </td>
                                                                        <td colspan="3" align="left"><span class="bpart">Mr.
                                                                            <?= $student->f_name ?>
: </span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="49" align="left" class="bpart">Class:</td>
                                                                        <td width="91" align="left" class="bpart"><?= $student->class_name ?></td>
                                                                        <td colspan="2" align="left" class="bpart">Student Id:</td>
                                                                        <td width="119" align="left" class="bpart1"><?= $student->student_id ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="49" align="left" class="bpart">Date : </td>
                                                                        <td width="91" align="left" class="bpart"><?php echo $newdate= date('d-m-Y',strtotime($trxn->tr_date));  ?></td>
                                                                        <td colspan="2" align="left" class="bpart">Receipt No :</td>
                                                                        <td width="119" align="left" class="bpart1"><?= $trxn->party_refference ?></td>
                                                                    </tr>
                                                                    <tr >
                                                                        <td colspan="3" align="left" class="bpart"><?php if(http_get('param6') == 'paywith_adjustment')
                    {   
                        echo "Paid With Adjustment";                                                    
                    }                                                        
                    else {                                                          
                 ?>
                                                                        
                                                                        
                    For the month of :<?php }?>
          
          </td>
                                                                        <td colspan="2" align="left" class="bpart"><?php   
                                                                            $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo, $student->feepaymentmode, $oCurrentUser->mydate);
                                                                            while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                                $count = $fee_schedule->rowCount();
//                                                                                echo $count;
                                                                                if ($count > 0) {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                } else {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    
               if(http_get('param6') == 'paywith_adjustment') {}
               else { echo $month_name->month . " ";}
                                                                                }
                                                                            } $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                            
                       echo date("Y", strtotime($rowv->DueDate)); ?> 
                                                                        </td>
                                                                    </tr>
                                                              </table>
                                                              <table width="98%" align="center">
                                                                    <tr class="bpart">
                                                                        <td width="73%">Particulars of Fee </td>
                                                                        <td width="27%" align="right">Amount</td>
                                                                    </tr>
                                                                    <?php
                                                                   $trxn_detail = Fee::get_txn_detail($tr_id_no);
                                                                    ?>  
                                                                    <?php
                                                                    $ttl_fee = 0;
                                                                    while ($rowu = $trxn_detail->fetch(PDO::FETCH_OBJ)) {
//                    print_r($rowu);
                                                                        $ttl_fee +=$rowu->rate;
                                                                        $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu->item_id)->fetch(PDO::FETCH_OBJ);
                                                                        if ($rowu->item_id < 0) {
//                        echo $rowu->rate ;
//                                                                            if ($rowu->rate > 0) {
                                                                                ?> <tr class="simple4alltext">  

                                                                                    <?php
                                                                                    $fee_name = Fee::get_feename_2($MSID, $rowu->item_id)->fetch(PDO::FETCH_OBJ);
//                                        print_r($fee_name) ; 
                                                                                    ?>
                                                                                    <td valign="bottom" class="simple4alltext" align="left"> <?= $fee_name->FeeName ?> :


                                                                                    </td>
                                                                                    <td align="right" valign="bottom" class="bpart1">
                                                                                        <?php if ($fee_name->type == 2) { ?>
                                                                                            <?php echo abs($rowu->rate); ?>
                                                                                        <?php } else { ?>             <?php echo round($rowu->rate); ?>
                                                                                        <?php } ?>  </td>

                                                                                </tr> 
                                                                                <?php
//                                                                            }
                                                                        } else {
                                                                                if($rowu->rate != 0 ){
                                                                            ?>
                                                                            <tr class="bpart">
                                                                                
                                                                                <td valign="bottom" class="bpart"> <?= $fee->fee_name ?> :

                                                                                </td>

                                                                                <td align="right" valign="bottom" class="bpart1"><?php echo round($rowu->rate); ?></td>

                                                                            </tr> 
                                                                            <?php
                                                                        }}
                                                                      
                                                                    }
                                                                    ?>  <tr class="bpart">
                                                                        <td>Total Amount : </td>
                                                                        <td align="right"  class="bpart1"><?php echo round(@$trxn->ttl_paid); ?>
                                                                            </td>
                                                                    </tr>
                                                                    <?php
                                                                    ?>
                                                                    <tr>
                                                                        <td class="bpart">Late Fee : </td>
                                                                        <td align="right" class="bpart1" >
                                                                            <?php echo (@round($trxn->late_fee)) ? $trxn->late_fee : ""; ?>
                                                                            </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="bpart">Discount : </td>
                                                                        <td align="right" class="bpart1" >
                                                                            <?php echo (@round($trxn->discount)) ? $trxn->discount : ""; ?>
                                                                          </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="bpart">Grand Total : </td>
                                                                        <td align="right" class="bpart1"><?php echo $sum = $trxn->ttl_paid + $trxn->late_fee - $trxn->discount; ?></td>
                                                                    </tr>
                                                                </table>
                                                              <table width="99%" border="0" cellspacing="0" cellpadding="0">
                                                                    
                                                                    <tr>
                                                                        <td colspan="2" class="bpart">
                                                                            User Name :<strong> <?= $oCurrentUser->myuname ?>
                                                                            </strong>
                                                                        </td>
                                                                    </tr>
                                                                    <?php
                                                                    $txn = Fee::get_fee_tsn($MSID, $oCurrentUser->mysession, $student->acno, $oCurrentUser->mydate);
                                                                    $ttl_fee_2 = 0;
                                                                    $ttl_late_fee_2 = 0;
                                                                    $ttl_discount = 0;
                                                                    $net_ttl = 0;
                                                                    while ($rowu = $txn->fetch(PDO::FETCH_ASSOC)) {

                                                                        $TLateFee = $rowu['late_fee'];
                                                                        $Tdiscount = $rowu['discount'];
                                                                        $Rate = $rowu['amt'];

                                                                        $ttl_fee_2 +=$Rate;
                                                                        $ttl_late_fee_2 +=$TLateFee;
                                                                        $ttl_discount +=$Tdiscount;
                                                                        $net_amt = $Rate + $TLateFee - $Tdiscount;
                                                                        $net_ttl +=$net_amt;
                                                                    }
                                                                    $net_ttl;
                                                                    ?>
                                                                    
                                                                    
                                                          </table></td>
                                                        </tr>
                                              </table></td>


                                            </tr>
                                        </table>   </td>
                                        <td width="53%">
                                        <table width="356" border="1" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td width="352" align="center" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">

                                                                    <tr>
                                                                   <td align="right" valign="top" colspan="2">School Copy</td>
                                                                   </tr> 
                                                                    <tr valign="top">
                                                                        <td width="67" rowspan="2" align="center"  ><span class="header"><img src="<?= CLIENT_URL ?>/uploads/thumbs/<?php echo $oCurrentSchool->logo_img; ?>" class="user-image" alt="User Image" width="76" height="56"/></span></td>
                                                                        <td width="100%" align="center" valign="top"  ><span class="header">
                                                                                <?= $oCurrentSchool->name; ?>  </span></td>
                                                                    </tr>
                                                                    <tr>
                                                                      <td height="18" align="center" valign="top"  ><span class="bpart1"><b>
                                                                        <?= $oCurrentSchool->Add_ReportC ?>
                                                                      </b></span></td>
                                                              </tr>

                                                                    <tr>
                                                                        <td colspan="2" align="center" valign="top">                                                                                </td>
                                                                    </tr>
                                                                </table>

                                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td colspan="2" align="left" class="bpart">Student's Name:</td>
                                                                        <td colspan="3" align="left" class="bpart"><?= $student->name ?>&nbsp;</td>
                                                                  </tr>
                                                                    <tr align="left">
                                                                        <td colspan="2" align="left"><span class="bpart"> <?php $g = $student->gender; ?>
                                                                                <?php
                                                                                if ($g == 'F') {
                                                                                    echo 'D/O';
                                                                                } else {
                                                                                    echo 'S/O';
                                                                                }
                                                                                ?>
                                                                                : </span>
                                                                        </td>
                                                                        <td colspan="3" align="left"><span class="bpart">Mr.
                                                                            <?= $student->f_name ?>
: </span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="49" align="left" class="bpart">Class:</td>
                                                                        <td width="90" align="left" class="bpart"><?= $student->class_name ?></td>
                                                                        <td colspan="2" align="left" class="bpart">Student Id:</td>
                                                                        <td width="111" align="left" class="bpart1"><?= $student->student_id ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="49" align="left" class="bpart">Date : </td>
                                                                        <td width="90" align="left" class="bpart"><?php echo $newdate= date('d-m-Y',strtotime($trxn->tr_date));  ?></td>
                                                                        <td colspan="2" align="left" class="bpart">Receipt No :</td>
                                                                        <td width="111" align="left" class="bpart1"><?= $trxn->party_refference ?></td>
                                                                    </tr>
                                                                    <tr >
                                                                        <td colspan="3" align="left" class="bpart"><?php if(http_get('param6') == 'paywith_adjustment')
                    {   
                        echo "Paid With Adjustment";                                                    
                    }                                                        
                    else {                                                          
                 ?>
                                                                        
                                                                        
                    For the month of :<?php }?>
          
          </td>
                                                                        <td colspan="2" align="left" class="bpart"><?php   
                                                                            $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo, $student->feepaymentmode, $oCurrentUser->mydate);
                                                                            while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                                $count = $fee_schedule->rowCount();
//                                                                                echo $count;
                                                                                if ($count > 0) {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                } else {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    
               if(http_get('param6') == 'paywith_adjustment') {}
               else { echo $month_name->month . " ";}
                                                                                }
                                                                            } $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                            
                       echo date("Y", strtotime($rowv->DueDate)); ?> 
                                                                        </td>
                                                                    </tr>
                                                              </table>
                                                              <table width="98%" align="center">
                                                                    <tr class="bpart">
                                                                        <td width="73%">Particulars of Fee </td>
                                                                        <td width="27%" align="right">Amount</td>
                                                                    </tr>
                                                                    <?php
                                                                   $trxn_detail = Fee::get_txn_detail($tr_id_no);
                                                                    ?>  
                                                                    <?php
                                                                    $ttl_fee = 0;
                                                                    while ($rowu = $trxn_detail->fetch(PDO::FETCH_OBJ)) {
//                    print_r($rowu);
                                                                        $ttl_fee +=$rowu->rate;
                                                                        $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu->item_id)->fetch(PDO::FETCH_OBJ);
                                                                        if ($rowu->item_id < 0) {
//                        echo $rowu->rate ;
//                                                                            if ($rowu->rate > 0) {
                                                                                ?> <tr class="simple4alltext">  

                                                                                    <?php
                                                                                    $fee_name = Fee::get_feename_2($MSID, $rowu->item_id)->fetch(PDO::FETCH_OBJ);
//                                        print_r($fee_name) ; 
                                                                                    ?>
                                                                                    <td valign="bottom" class="simple4alltext" align="left"> <?= $fee_name->FeeName ?> :


                                                                                    </td>
                                                                                    <td align="right" valign="bottom" class="bpart1">
                                                                                        <?php if ($fee_name->type == 2) { ?>
                                                                                            <?php echo abs($rowu->rate); ?>
                                                                                        <?php } else { ?>             <?php echo round($rowu->rate); ?>
                                                                                        <?php } ?>  </td>

                                                                                </tr> 
                                                                                <?php
//                                                                            }
                                                                        } else {
                                                                                if($rowu->rate != 0 ){
                                                                            ?>
                                                                            <tr class="bpart">
                                                                                
                                                                                <td valign="bottom" class="bpart"> <?= $fee->fee_name ?> :

                                                                                </td>

                                                                                <td align="right" valign="bottom" class="bpart1"><?php echo round($rowu->rate); ?></td>

                                                                            </tr> 
                                                                            <?php
                                                                        }}
                                                                      
                                                                    }
                                                                    ?>  <tr class="bpart">
                                                                        <td>Total Amount : </td>
                                                                        <td align="right"  class="bpart1"><?php echo round(@$trxn->ttl_paid); ?>
                                                                            </td>
                                                                    </tr>
                                                                    <?php
                                                                    ?>
                                                                    <tr>
                                                                        <td class="bpart">Late Fee : </td>
                                                                        <td align="right" class="bpart1" >
                                                                            <?php echo (@round($trxn->late_fee)) ? $trxn->late_fee : ""; ?>
                                                                            </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="bpart">Discount : </td>
                                                                        <td align="right" class="bpart1" >
                                                                            <?php echo (@round($trxn->discount)) ? $trxn->discount : ""; ?>
                                                                          </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="bpart">Grand Total : </td>
                                                                        <td align="right" class="bpart1"><?php echo $sum = $trxn->ttl_paid + $trxn->late_fee - $trxn->discount; ?></td>
                                                                    </tr>
                                                                </table>
                                                              <table width="99%" border="0" cellspacing="0" cellpadding="0">
                                                                    
                                                                    <tr>
                                                                        <td colspan="2" class="bpart">
                                                                            User Name :<strong> <?= $oCurrentUser->myuname ?>
                                                                            </strong>
                                                                        </td>
                                                                    </tr>
                                                                    <?php
                                                                    $txn = Fee::get_fee_tsn($MSID, $oCurrentUser->mysession, $student->acno, $oCurrentUser->mydate);
                                                                    $ttl_fee_2 = 0;
                                                                    $ttl_late_fee_2 = 0;
                                                                    $ttl_discount = 0;
                                                                    $net_ttl = 0;
                                                                    while ($rowu = $txn->fetch(PDO::FETCH_ASSOC)) {

                                                                        $TLateFee = $rowu['late_fee'];
                                                                        $Tdiscount = $rowu['discount'];
                                                                        $Rate = $rowu['amt'];

                                                                        $ttl_fee_2 +=$Rate;
                                                                        $ttl_late_fee_2 +=$TLateFee;
                                                                        $ttl_discount +=$Tdiscount;
                                                                        $net_amt = $Rate + $TLateFee - $Tdiscount;
                                                                        $net_ttl +=$net_amt;
                                                                    }
                                                                    $net_ttl;
                                                                    ?>
                                                                    
                                                                    
                                                          </table></td>
                                                        </tr>
                                              </table></td>


                                            </tr>
                                        </table>   
                                        
                                        </td>
                                </tr>
                            </table>
                      
                        <?php
                    }
                }
                ?>
              
                </section>
    
    <?php
// print_r($oCurrentSchool);       

$tpt = (@http_get('param3') == "tpt" && $oCurrentSchool->SeprateTPTFBook == "1") ? "2" : (($oCurrentSchool->SeprateTPTFBook == "0") ? "1" : "0");
if (@http_get('param3') == "month") {
    $rsrno = http_get('param4');
}
$tr_id_no = http_get('param5');
?>
 <?php
            $message = new Messages();
            echo $message->display();
            ?>
          
                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
//                print_r($student);   
                 $trxn = Fee::get_txn($MSID, $tr_id_no)->fetch(PDO::FETCH_OBJ);
                ?>
                <?php
                $loops = Fee::get_fee_billing_loops($oCurrentUser->myuid, $student->acno);
                while ($rowv = $loops->fetch(PDO::FETCH_OBJ)) {
                    if (@$rsrno == $rowv->RSrNo) {
                        ?>
	<section class="content">
 
                      
                        <?php
                    }
                }
                ?>
              
                </section>
      </body>