<?php
// print_r($oCurrentSchool);       

$tpt = (@http_get('param3') == "tpt" && $oCurrentSchool->SeprateTPTFBook == "1") ? "2" : (($oCurrentSchool->SeprateTPTFBook == "0") ? "1" : "0");
?>
<style type="text/css">

    .header {
        font-size: 18px;

        font-family: Verdana, Arial, Helvetica, sans-serif;
    }
    .subheader {
        font-size: 15px;font-family: Verdana, Arial, Helvetica, sans-serif;
    }
    .subheader1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 11px;

    }
    .subheader2 {
        font-size: 13px;font-family: Verdana, Arial, Helvetica, sans-serif;

    }
    .bpart {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 12px;
    }
    .bpart2 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 13px;

        font-weight: bold;	

    }
    .bpart1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 12px;


    }
    .bpart11 {
        font-family: Verdana, Arial, Helvetica, sans-serif;

        font-size: 12px;
        font-style:italic

    }
    .bpart21 {	font-family: Verdana, Arial, Helvetica, sans-serif;
               font-size: 18px;
    }
    .bpart3 {font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 13px;
    }
    .bpart12 {	font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;
    }

    p.page { page-break-after: always; }
</style>
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
$message = new Messages();
echo $message->display();
?>
            <div class="box">

                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);

//                $delete_data = Fee::get_delete_student_from_fee_billing($MSID, $student->acno, $oCurrentUser->mysession);
//                $data_insert = Fee::insert_student_into_fee_billing($oCurrentUser->myuid, $student->acno);
//                print_r($student);
//                exit();
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                //delete previous Entrys of perticular acc no 
//                $delete_previous_user = Fee::get_delete_student_from_fee_billing($MSID, $student->acno, $oCurrentUser->begins, $oCurrentUser->ends);
                //Add new Entrys of perticular acc no 
//                $add_entrys = Fee::insert_student_into_fee_billing($MSID, $student->acno);
                //getting the loop data 
                $loops = Fee::get_fee_billing_loops($MSID, $student->acno);
                while ($rowv = $loops->fetch(PDO::FETCH_OBJ)) {
//                    echo "<pre>";
//                    print_r($rowv);
                    ?>


                    <div class="tmbanner1">
                        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
                            <tr> 
                                <td height="587" align="center" valign="top"><table width="300" height="586" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td height="586" valign="top"><table width="300" border="1" height="586" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td height="584" align="center" valign="top" background="../../images/reportlogo.png" style="background-size:55%; background-position:center; background-repeat:no-repeat"><table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(School Copy)</span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="61" colspan="2" align="center" valign="top"><span class="header">
                                                                            <?= $oCurrentSchool->name; ?> 
                                                                            <br />
                                                                        </span> <span class="subheader">  <?= $oCurrentSchool->place; ?> <br />
                                                                        </span> <span class="subheader"> Affiliated To CBSE</span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="141" height="24" align="left" valign="top"><span class="subheader1"> Affiliation No:&nbsp;&nbsp; <?= $oCurrentSchool->affNo; ?> </span></td>
                                                                    <td width="139" align="center" valign="top"><span class="subheader1"> School No:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $oCurrentSchool->schoolNo; ?></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="29" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?= $oCurrentSchool->phone; ?> <br />
                                                                            <?= $oCurrentSchool->bank; ?>  &nbsp;&nbsp; <?= $oCurrentSchool->branch; ?> 
                                                                            <br />
                                                                            Please Credit A/c No  :<?= $oCurrentSchool->acno; ?></span></td>
                                                                </tr>
                                                            </table>

                                                            <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td height="22" align="left" class="bpart1">On A/c Of&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td>
                                                                    <td colspan="4" align="left" class="bpart1"><span class="bpart"><?= $student->acno ?></span></td>
                                                                </tr>
                                                                <tr align="left">
                                                                    <td height="24" align="left"><span class="bpart1">Father's Name&nbsp;&nbsp;:</span><span class="bpart"> &nbsp;&nbsp;</span></td>
                                                                    <td colspan="4" align="left"><span class="bpart"><?php echo 'Mr.' . ' ' . $student->f_name; ?></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="116" height="24" align="left" class="bpart1">Locality&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td>
                                                                    <td colspan="4" align="left" class="bpart"><?= $student->village; ?></td>
                                                                </tr>
                                                                <tr >
                                                                    <td height="22" align="left" class="bpart1">For the month of :</td>
                                                                    <td width="63" align="left" class="bpart1"><span class="bpart">
                                                                            <?php
                                                                            $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo);
                                                                            while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                                $count = $fee_schedule->rowCount();
                                                                                if ($count > 0) {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                } else {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                }
                                                                                $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                            }
                                                                            ?>   </span></td>
                                                                    <td width="63" colspan="3" align="left" class="bpart"><?php
                                                                        echo $date->format("Y");
                                                                        ;
                                                                            ?></td>
                                                                </tr>
                                                                <tr   valign="top">
                                                                    <td height="4" colspan="3"   class="bpart"><hr></td>
                                                                </tr>
                                                            </table>
                                                            <table width="280" border="0">
                                                                <tr align="right" valign="top">
                                                                    <?php
                                                                    $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);
                                                                    while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                                                                        ?>

                                                                        <td height="26"  align="right"  class="bpart"><?= $fee_name->fee_group_name ?>
                                                                            &nbsp;</td>
                                                                    <?php } ?>
                                                                    <td  align="right"width="161" class="bpart">Sub Total</td>
                                                                </tr>
                                                                <?php
                                                                $ttl_amts = Fee::get_fee_book_querry2_subtotal($oCurrentUser->myuid, $student->acno, $rowv->RSrNo, '', $tpt);
                                                                while ($ttl_amt = $ttl_amts->fetch(PDO::FETCH_OBJ)) {
                                                                    $students = Student::get_students($oCurrentUser->myuid, '1', $ttl_amt->SID)->fetch(PDO::FETCH_OBJ);
                                                                    ?>

                                                                    <tr align="left" valign="bottom" class="bpart11">
                                                                        <td height="27" colspan="4"    >

                                                                            <?= $students->student_id . " " . $students->name . " " . $students->class_name . " " . $student->house ?>
                                                                        </td> </tr>

                                                                    <tr align="right" valign="bottom" class="bpart">
                                                                        <?php
                                                                        $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);

                                                                        while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                                                                            $fee_amount = Fee::get_fee_book_querry1($oCurrentUser->myuid, $students->acno, $rowv->RSrNo, $students->student_id, $fee_name->fee_id, $tpt)->fetch(PDO::FETCH_OBJ);
                                                                            ?>
                                                                            <td width="109" height="25" align="right" ><?php echo round(@$fee_amount->FeeAmt); ?> &nbsp; </td>
                                                                        <?php } ?> 

                                                                        <td width="161" align="right" >
                                                                            <?php $ttl_amount = Fee::get_fee_book_querry2_subtotal($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $tpt)->fetch(PDO::FETCH_OBJ); ?>
                                                                            <?php echo round($ttl_amount->Sub_Total); ?>
                                                                        </td>   </tr><?php } ?><tr align="right" valign="bottom">
                                                                    <td colspan="5" align="right" ><hr /></td>
                                                                </tr>
                                                            </table>
                                                            <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td><table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                            <tr class="bpart2">
                                                                                <td width="101" height="23" align="right">Total </td>
                                                                                <td width="99" align="right">
                                                                                    <?php
                                                                                    $ttl_full_amt = Fee::get_fee_book_querry3_total($MSID, $student->acno, $rowv->RSrNo, $tpt)->fetch(PDO::FETCH_OBJ);
//                                                                                                                                                        print_r($ttl_full_amt);
//                                                                                                                                                        exit();
                                                                                    ?>
                                                                                    <?php echo round($ttl_full_amt->Total); ?>

                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="23" align="right" class="bpart">
                                                                                    Late fee if any</td>
                                                                                <td align="right"><span class="bpart2">

                                                                                        *</span>_____</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="23" align="right" class="bpart">
                                                                                    Grand Total</td>
                                                                                <td align="right">
                                                                                    ________</td> 
                                                                            </tr>
                                                                            <tr>
                                                                                <td colspan="2" align="right" class="bpart" height="110">
                                                                                    <table width="267" border="0" align="center">
                                                                                        <tr>
                                                                                            <td align="center" class="subheader"><strong>Late Fee</strong></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="261" align="center" class="subheader">  Rs. 10/- Per Student Per Day                   </td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                            <td>&nbsp;&nbsp;</td>
                                            <td align="center" valign="top"><table width="300" border="1" height="586" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td height="584" align="center" valign="top" background="../../images/reportlogo.png" style="background-size:55%; background-position:center; background-repeat:no-repeat"><table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Student Copy)</span></td>
                                                                </tr>  <tr>
                                                                    <td height="61" colspan="2" align="center" valign="top"><span class="header">
                                                                            <?= $oCurrentSchool->name; ?> 
                                                                            <br />
                                                                        </span> <span class="subheader">  <?= $oCurrentSchool->place; ?> <br />
                                                                        </span> <span class="subheader"> Affiliated To CBSE</span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="141" height="24" align="left" valign="top"><span class="subheader1"> Affiliation No:&nbsp;&nbsp; <?= $oCurrentSchool->affNo; ?> </span></td>
                                                                    <td width="139" align="center" valign="top"><span class="subheader1"> School No:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $oCurrentSchool->schoolNo; ?></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="29" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?= $oCurrentSchool->phone; ?> <br />
                                                                            <?= $oCurrentSchool->bank; ?>  &nbsp;&nbsp; <?= $oCurrentSchool->branch; ?> 
                                                                            <br />
                                                                            Please Credit A/c No  :<?= $oCurrentSchool->acno; ?></span></td>
                                                                </tr>
                                                            </table>

                                                            <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td height="22" align="left" class="bpart1">On A/c Of&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td>
                                                                    <td colspan="4" align="left" class="bpart1"><span class="bpart"><?= $student->acno ?></span></td>
                                                                </tr>
                                                                <tr align="left">
                                                                    <td height="24" align="left"><span class="bpart1">Father's Name&nbsp;&nbsp;:</span><span class="bpart"> &nbsp;&nbsp;</span></td>
                                                                    <td colspan="4" align="left"><span class="bpart"><?php echo 'Mr.' . ' ' . $student->f_name; ?></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="116" height="24" align="left" class="bpart1">Locality&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td>
                                                                    <td colspan="4" align="left" class="bpart"><?= $student->village; ?></td>
                                                                </tr>
                                                                <tr >
                                                                    <td height="22" align="left" class="bpart1">For the month of :</td>
                                                                    <td width="63" align="left" class="bpart1"><span class="bpart">
                                                                            <?php
                                                                            $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo);
                                                                            while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                                $count = $fee_schedule->rowCount();
                                                                                if ($count > 0) {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                } else {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                }
                                                                                $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                            }
                                                                            ?>   </span></td>
                                                                    <td width="63" colspan="3" align="left" class="bpart"><?php
                                                                        echo $date->format("Y");
                                                                        ;
                                                                            ?></td>
                                                                </tr>
                                                                <tr   valign="top">
                                                                    <td height="4" colspan="3"   class="bpart"><hr></td>
                                                                </tr>
                                                            </table>
                                                            <table width="280" border="0">
                                                                <tr align="right" valign="top">
                                                                    <?php
                                                                    $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);
                                                                    while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                                                                        ?>

                                                                        <td height="26"  align="right"  class="bpart"><?= $fee_name->fee_group_name ?>
                                                                            &nbsp;</td>
                                                                    <?php } ?>
                                                                    <td  align="right"width="161" class="bpart">Sub Total</td>
                                                                </tr>
                                                                <?php
                                                                $ttl_amts = Fee::get_fee_book_querry2_subtotal($MSID, $student->acno, $rowv->RSrNo, '', $tpt);
                                                                while ($ttl_amt = $ttl_amts->fetch(PDO::FETCH_OBJ)) {
                                                                    $students = Student::get_students($oCurrentUser->myuid, '1', $ttl_amt->SID)->fetch(PDO::FETCH_OBJ);
                                                                    ?>

                                                                    <tr align="left" valign="bottom" class="bpart11">
                                                                        <td height="27" colspan="4"    >

                                                                            <?= $students->student_id . " " . $students->name . " " . $students->class_name . " " . $student->house ?>
                                                                        </td> </tr>

                                                                    <tr align="right" valign="bottom" class="bpart">
                                                                        <?php
                                                                        $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);
                                                                        while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                                                                            $fee_amount = Fee::get_fee_book_querry1($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $fee_name->fee_id, $tpt)->fetch(PDO::FETCH_OBJ);
                                                                            ?>
                                                                            <td width="109" height="25" align="right" ><?php echo round(@$fee_amount->FeeAmt); ?> &nbsp; </td>
                                                                        <?php } ?> 

                                                                        <td width="161" align="right" >
                                                                            <?php $ttl_amount = Fee::get_fee_book_querry2_subtotal($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $tpt)->fetch(PDO::FETCH_OBJ); ?>
                                                                            <?php echo round($ttl_amount->Sub_Total); ?>
                                                                        </td>   </tr><?php } ?><tr align="right" valign="bottom">
                                                                    <td colspan="5" align="right" ><hr /></td>
                                                                </tr>
                                                            </table>
                                                            <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td><table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                            <tr class="bpart2">
                                                                                <td width="101" height="23" align="right">Total </td>
                                                                                <td width="99" align="right">
                                                                                    <?php $ttl_full_amt = Fee::get_fee_book_querry3_total($MSID, $student->acno, $rowv->RSrNo, $tpt)->fetch(PDO::FETCH_OBJ); ?>
                                                                                    <?php echo round($ttl_full_amt->Total); ?>

                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="23" align="right" class="bpart">
                                                                                    Late fee if any</td>
                                                                                <td align="right"><span class="bpart2">

                                                                                        *</span>_____</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="23" align="right" class="bpart">
                                                                                    Grand Total</td>
                                                                                <td align="right">
                                                                                    ________</td> 
                                                                            </tr>
                                                                            <tr>
                                                                                <td colspan="2" align="right" class="bpart" height="110">
                                                                                    <table width="267" border="0" align="center">
                                                                                        <tr>
                                                                                            <td align="center" class="subheader"><strong>Late Fee</strong></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="261" align="center" class="subheader">  Rs. 10/- Per Student Per Day                   </td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                            <?php if ($oCurrentSchool->bank_reciept == 1) { ?>     <td>&nbsp;&nbsp;</td>
                                                <td align="center" valign="top"><table width="300" border="1" height="586" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td height="586" align="center" valign="top" background="../../images/reportlogo.png" style="background-size:55%; background-position:center; background-repeat:no-repeat"><table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Bank Copy)</span></td>
                                                                    </tr>  <tr>
                                                                        <td height="61" colspan="2" align="center" valign="top"><span class="header">
                                                                                <?= $oCurrentSchool->name; ?> 
                                                                                <br />
                                                                            </span> <span class="subheader">  <?= $oCurrentSchool->place; ?> <br />
                                                                            </span> <span class="subheader"> Affiliated To CBSE</span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="141" height="24" align="left" valign="top"><span class="subheader1"> Affiliation No:&nbsp;&nbsp; <?= $oCurrentSchool->affNo; ?> </span></td>
                                                                        <td width="139" align="center" valign="top"><span class="subheader1"> School No:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $oCurrentSchool->schoolNo; ?></span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td height="29" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?= $oCurrentSchool->phone; ?> <br />
                                                                                <?= $oCurrentSchool->bank; ?>  &nbsp;&nbsp; <?= $oCurrentSchool->branch; ?> 
                                                                            </span><br />
                                                                            Please Credit A/c No  :<span class="bpart2"><?= $oCurrentSchool->acno; ?></span></td>
                                                                    </tr><tr>

                                                                        <td colspan="4" align="left" class="bpart1"><span class="subheader2">On or before   &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; :</span>  <span class="bpart2">
                                                                                <?php
                                                                                $date = Fee::get_fee_due_date($MSID, $student->student_id, $rowv->RSrNo, $oCurrentUser->begins, $oCurrentUser->ends)->fetch(PDO::FETCH_OBJ);
                                                                                echo $date->paydate;
                                                                                ?>                                                      </span><br></td></tr>
                                                                    <tr>
                                                                        <td colspan="4" align="left" class="bpart1"><span class="subheader2">With Exact Amount&nbsp;&nbsp;   : </span>  <span class="bpart2">
                                                                                <?php $ttl_full_amt = Fee::get_fee_book_querry3_total($MSID, $student->acno, $rowv->RSrNo, $tpt)->fetch(PDO::FETCH_OBJ); ?>
                                                                                <?php Echo "Rs " . $ttl_full_amt->Total; ?>                                                      </span><br></td>
                                                                    </tr>
                                                                </table>

                                                                <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr class="bpart2">
                                                                        <td width="116" height="22" align="left" class="bpart2">Naration &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</td>
                                                                        <td colspan="4" align="left" class="bpart2">   <?php
                                                                        $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo)->fetch(PDO::FETCH_OBJ);
                                                                        $month_name = Master::get_months($MSID, $fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                        $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                        $year = substr($date->format("Y"), -2)
                                                                                ?>  <?php echo $student->acno . $month_name->month . $year; ?></td>
                                                                    </tr><tr><td width="63" align="left" class="bpart1"><span class="bpart">
                                                                            </span></td>
                                                                        <td width="63" colspan="3" align="left" class="bpart"></td></tr>
                                                                </table>
                                                                <table width="280" border="0">

                                                                                                          <!-- <tr align="right" valign="bottom">
                                                                                                             <td width="270" colspan="5" align="right" ><hr /></td>
                                                                                                           </tr>
                                                                    -->
                                                                </table>
                                                                <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td><table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                                <tr class="bpart2">
                                                                                    <td height="23" align="right" valign="top"><br>
                                                                                        <br>
                                                                                    </td>
                                                                                    <td align="right" valign="top">&nbsp;</td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td height="23" colspan="2" align="left" class="bpart"> <br>
                                                                                        <br>
                                                                                        After <span class="bpart2">
                                                                                            <?php
                                                                                            $date = Fee::get_fee_due_date($MSID, $student->student_id, $rowv->RSrNo, $oCurrentUser->begins, $oCurrentUser->ends)->fetch(PDO::FETCH_OBJ);
                                                                                            echo $date->paydate;
                                                                                            ?>
                                                                                        </span>dues can be deposited with late fess at home branch only.<span class="bpart2"> </span></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td colspan="2" align="right" class="bpart" height="110">&nbsp;</td>
                                                                                </tr>
                                                                            </table></td>
                                                                    </tr>
                                                                </table><table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td></td>
                                                                    </tr>
                                                                </table></td>
                                                        </tr>
                                                    </table></td>

                                            <?php } ?></tr>
                                    </table>   </td>
                            </tr>
                        </table>
                    </div>
                    <p class="page"></p><?php } ?>







            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php
//echo "<pre>";
//print_r($student);
//print_r($oCurrentUser);
