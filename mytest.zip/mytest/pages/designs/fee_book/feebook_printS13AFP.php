<?php   
session_start();
include("../../connect/db.php");   
$msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {  $s_id1=$_GET['s_id'];   $s_id = mysql_real_escape_string($s_id1);
$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
$TrDate1=$_GET['TrDate'];$TrDate = mysql_real_escape_string($TrDate1);
$SrNo1=$_GET['SrNo'];  $SrNo = mysql_real_escape_string($SrNo1);
$EOD1=$_GET['EOD'];  $EOD = mysql_real_escape_string($EOD1);
	  $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
   $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }  ?> 
<style type="text/css">
<!--  
.header {
	font-size: 20px;
	font-weight:bold;
	 font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader {
	font-size: 17px;font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader1 {
font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 11px;
	 
}
.subheader2 {
	font-size: 13px;font-family: Verdana, Arial, Helvetica, sans-serif;
	 
}
.bpart {
 
font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
.bpart2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
	 
	font-weight: bold;	

}
.bpart1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
 
}
.bpart11 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
 
	font-size: 12px;
	font-style:italic
 
}
.bpart21 {	font-family: Verdana, Arial, Helvetica, sans-serif;
 font-size: 18px;
}
.bpart3 {font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 13px;
}
.bpart12 {	font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;
}
-->
</style><script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
<!--<link href="css/glfee.css"  rel="stylesheet" type="text/css" media="all" />--> <?php 
$nd=mysql_query($nsql="SELECT MN.AcNo, MN.SId Id, MN.CClass,MN.AdmNo, MN.House, MN.FatherName, MN.Village1, MN.DueDate, Year(DueDate)as Year,Month(DueDate)as Month ,MN.RSrNo, MN.Name, MN.FeeGroup, SUM(MN.FeeAmt) NetAmt
FROM(SELECT CSD.AcNo,CSD.SId,CSD.Name,CSD.AdmNo,CSD.FatherName,CSD.Village1,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,CSD.FeeId ,CSD.FeeGroup,CSD.FGroupId,ROUND((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent,CSD.feegrpid  FROM 
(Select CS.MSID,CS.AcNo,CS.SID,CS.Name,CS.House,CS.FatherName,CS.Village1,CS.FSDate,CS.SLDate,CS.groupid,CS.AdmClassNo+CS.MySession-Year(CS.FSDate)+
COALESCE(Sum(E.Result),0) CClass,CS.SrNo,CS.AdmNo,CS.DueDate
,CS.FeeName,CS.FPMode,CS.FeeId,CS.FGroupId,CS.FeeGroup,IF(CS.SeprateTPTFBook='0',SAT.TptStation,null) TptStation,DS.Discount,CS.feegrpid FROM ( 
SELECT S.AcNo, S.id SID,S.name,S.AdmNo,S.House,S.AdmClassNo,S.FSDate,S.SLDate,S.groupid,P.fathername,P.FeePaymentMode FPMode,L.village1,L.Village ,CU.MYUID,CU.MYDATE,CU.MYSESSION,CU.BEGINS,CU.ENDS,CU.MSID,DD.DateId DueDate,If(Year(DD.DateID)=Year(CU.Begins),Month(DD.DateId)- Month(CU.Begins) +'1',Month(DD.DateId)-Month(CU.Begins)+'13') AS SrNo,FN.Id FeeID,FN.FeeName,FN.FGroupId,FN.FeeGroup,C.SeprateTPTFBook,SFG.fgroupid as feegrpid FROM (
SELECT * FROM 7FeeUsers U WHERE U.MyUId= '$foo' ) CU INNER JOIN 10Company C on C.msid= CU.MSID INNER JOIN 13Students S on S.msid=CU.MSID and CU.MYDATE BETWEEN S.FSDATE AND S.SLDATE INNER JOIN 12Parents P on P.id=S.PID    
INNER JOIN 11Localities L on L.Village=P.Village INNER JOIN 6Dates DD ON Day(DD.DateId)='1' And DD.DateId BETWEEN CU.Begins AND CU.Ends and DD.dateid>=S.fsdate
INNER JOIN 7FeeNames FN ON FN.MSID=CU.MSID inner join 100SchoolFeeGrp SFG on SFG.msid= CU.msid and S.groupid=SFG.groupid Where S.AcNo=(select acno from 13Students S where S.id='$s_id' and S.msid='$msid')) CS LEFT JOIN 14Exam E ON E.MSID=CS.MSID And E.S_Id=CS.SID AND E.DateResult< CS.DueDate 
LEFT JOIN 35SATpt SAT ON SAT.S_ID=CS.SID AND SAT.MSId=CS.MSID AND CS.DueDate BETWEEN SAT.DateFrom AND SAT.DateTo 
LEFT JOIN 34DiscountedStudent DS ON DS.MSID=CS.MSID AND DS.S_id=CS.SID AND CS.DueDate BETWEEN DS.DateFrom AND DS.DateTo WHERE 1 Group By CS.SID,CS.SrNo,CS.FeeId Order By AcNo,SrNo,SID)CSD INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode INNER JOIN 31Fee1 FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=CSD.FeeId And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.feegrpid = FF.fgroupid or FF.fgroupid='0') LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And CSD.FeeId=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE MN.FeeAmt>0 And SId='$s_id' And  RSrNo='$SrNo'  GROUP BY RSrNo"); while($nrow=mysql_fetch_array($nd)){
  $s_id= $nrow['AcNo'];   $SID= $nrow['AcNo'];   $Gender= $nrow['Gender'];$Name= $nrow['Name'];  $FatherName= $nrow['FatherName'];  $Village= $nrow['Village'];$RSrNo= $nrow['RSrNo']; $MonthNo= $nrow['Month']; $AdmNo=$nrow['AdmNo'];
 $feeyr= $nrow['Year'];  $FeeGroup= $nrow['FeeGroup'];  $TNetAmt= $nrow['NetAmt'];   $CClass= $nrow['CClass'];
 
?>
<title><?php $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
  $Place= $row['Place'];
    $AffNo= $row['AffNo'];
	 $SchoolNo= $row['SchoolNo'];
	 	 $Phone= $row['Phone'];
$Board= $row['Board'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$BankCash= $row['BankCash'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$EMail= $row['EMail'];
$SFeebookR= $row['SFeebookR']; 
$FeePaymentmode= $row['FeePaymentmode'];
$bank= $row['Bank']; $branch= $row['Branch']; $acno=$row['ACNo'];
}?></title><body>
<style>
p.page { page-break-after: always; }
</style><div class="tmbanner1"> <form id="contactform" name="contactform" method="post" action="#">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr> 
    <td height="420" align="center" valign="top"><table width="678" height="353" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="293" height="353" valign="top"><table width="377" border="1" height="352" cellspacing="0" cellpadding="0">
          <tr>
            <td width="373" height="350" align="center" valign="top"><table width="368" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Student Copy)</span></td>
              </tr>
              <tr>
                <td width="51" height="59" align="center"  ><span class="header"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo"></span></td>
                <td width="317" align="center" valign="top"  ><span class="header">
                  <?php     echo $sname;?>
                  <br>
                  <?php echo $Place;?></span></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                  <table width="288" border="0" align="center">
                    <tr>
                      <td width="223" height="20" align="left" class="bpart1">Date:<?php echo $TrDate;?></td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td height="25" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?></span></td>
              </tr>
            </table>
              <table width="372" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="31" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="3" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                </tr>
                <tr align="left">
                  <td height="21" colspan="5" align="left"><span class="bpart">
                    <? if($Gender=='F'){echo "D/O";}else {echo "S/O";}?>
                    :</span><span class="bpart">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo 'Mr.'.$FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="74" height="28" align="left" class="bpart">Class:</td>
                  <td width="54" align="left" class="bpart"><?php 
 $hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];}    
			 
					
					?></td>
                  <td colspan="2" align="left" class="bpart">Admission No:</td>
                  <td align="left" class="bpart"><?php  if($ViewOption=='0'){echo $SID;}else {echo $AdmNo;}?></td>
                </tr>
                <tr >
                  <td height="24" colspan="3" align="left" class="bpart">For the month of :</td>
                  <td width="105" align="left" class="bpart"><?php $sq=mysql_query($sqd="Select * from  month WHERE SrNo='$RSrNo' And MSID='$msid'");
while($sqw=mysql_fetch_array($sq)){   $sqw['MonthName'];//}

 $monh=$sqw['MonthName'];
if($monh=='April'){echo 'April';}
else if($monh=='May'){ echo 'May,Jun,Jul';}
else if($monh=='August'){ echo 'Aug,Sep,Oct';}
else if($monh=='November'){ echo 'Nov,Dec';}
else if($monh=='January'){ echo 'Jan,Feb,Mar';}
else {echo $monh;} 
}
?></td>
                  <td width="136" align="left" class="bpart"><?php echo $feeyr;?></td> 
                </tr>
              </table>
              <table width="372" border="1" align="center">
                <tr class="bpart">
                  <td width="212" height="21">Particulars of Fee </td>
                  <td width="144" align="right">Amount</td>
                </tr>
                <?php  $ghi=mysql_query($gh="SELECT distinct FeeGroup FROM `7FeeNames` Where   `MSID`='$msid' And FeeGroup!='Tpt' ");
				 while($gow=mysql_fetch_array($ghi)){   $ann1=$gow['FeeGroup'];   //SELECT MN.AcNo,MN.Id,MN.Name, MN.CClass,MN.House,MN.FatherName,MN.Village,MN.DueDate,MN.RSrNo,MN.FeeGroup,MN.FGroupId,SUM(MN.FeeAmt) NetAmt
$dt=mysql_query($d="SELECT MN.AcNo, MN.SId Id, MN.CClass, MN.House, MN.FatherName, MN.Village1, MN.DueDate, MN.RSrNo, MN.Name, MN.FeeGroup, SUM(MN.FeeAmt) NetAmt
FROM(SELECT CSD.AcNo,CSD.SId,CSD.Name,CSD.FatherName,CSD.Village1,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,CSD.FeeId ,CSD.FeeGroup,CSD.FGroupId,ROUND((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent,CSD.feegrpid  FROM 
(Select CS.MSID,CS.AcNo,CS.SID,CS.Name,CS.House,CS.FatherName,CS.Village1,CS.FSDate,CS.SLDate,CS.groupid,CS.AdmClassNo+'$session'-Year(CS.FSDate)+
COALESCE(Sum(E.Result),0) CClass,CS.SrNo,CS.DueDate,CS.FeeName,CS.FPMode,CS.FeeId,CS.FGroupId,CS.FeeGroup,IF(CS.SeprateTPTFBook='0',SAT.TptStation,null) TptStation,DS.Discount,CS.feegrpid FROM ( 
SELECT S.AcNo, S.id SID,S.name,S.House,S.AdmClassNo,S.FSDate,S.SLDate,S.groupid,P.fathername,P.FeePaymentMode FPMode,L.village1,L.Village ,CU.MYUID,CU.MYDATE,CU.MYSESSION,CU.BEGINS,CU.ENDS,CU.MSID,DD.DateId DueDate,If(Year(DD.DateID)=Year(CU.Begins),Month(DD.DateId)- Month(CU.Begins) +'1',Month(DD.DateId)-Month(CU.Begins)+'13') AS SrNo,FN.Id FeeID,FN.FeeName,FN.FGroupId,FN.FeeGroup,C.SeprateTPTFBook,SFG.fgroupid as feegrpid FROM (
SELECT * FROM 7FeeUsers U WHERE U.MyUId= '$foo' ) CU INNER JOIN 10Company C on C.msid= CU.MSID INNER JOIN 13Students S on S.msid=CU.MSID and CU.MYDATE BETWEEN S.FSDATE AND S.SLDATE INNER JOIN 12Parents P on P.id=S.PID    
INNER JOIN 11Localities L on L.Village=P.Village INNER JOIN 6Dates DD ON Day(DD.DateId)='1' And DD.DateId BETWEEN CU.Begins AND CU.Ends and DD.dateid>=S.fsdate
INNER JOIN 7FeeNames FN ON FN.MSID=CU.MSID inner join 100SchoolFeeGrp SFG on SFG.msid= CU.msid and S.groupid=SFG.groupid Where S.AcNo=(select acno from 13Students S where S.id='$s_id' and S.msid='$msid')) CS LEFT JOIN 14Exam E ON E.MSID=CS.MSID And E.S_Id=CS.SID AND E.DateResult< CS.DueDate 
LEFT JOIN 35SATpt SAT ON SAT.S_ID=CS.SID AND SAT.MSId=CS.MSID AND CS.DueDate BETWEEN SAT.DateFrom AND SAT.DateTo 
LEFT JOIN 34DiscountedStudent DS ON DS.MSID=CS.MSID AND DS.S_id=CS.SID AND CS.DueDate BETWEEN DS.DateFrom AND DS.DateTo WHERE 1 Group By CS.SID,CS.SrNo,CS.FeeId Order By AcNo,SrNo,SID)CSD INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode INNER JOIN 31Fee1 FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=CSD.FeeId And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.feegrpid = FF.fgroupid or FF.fgroupid='0') LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And CSD.FeeId=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE MN.FeeAmt>0 And SId='$s_id' And  RSrNo='$RSrNo' And   FeeGroup='$ann1' GROUP BY RSrNo "); 
 while($dtw=mysql_fetch_array($dt)){
 $Amount1=$dtw['NetAmt'];  ?>
                <tr class="bpart">
                  <td height="23"><?php echo      $dtw['FeeGroup'];   ?></td>
                  <td align="right"  class="bpart"><?php  echo round($Amount1);    ?></td>
                </tr>
                <?php }}?>
                <tr>
                  <td height="29" class="bpart">Custom Discount</td>
                  <td align="right" class="bpart" ><? echo $EOD;?></td>
                </tr>
                <tr>
                  <td height="29" class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php   $TNetAmt;    round($TNetAmt);
				   $gdt=mysql_query($gd="SELECT MN.AcNo, MN.SId Id, MN.CClass, MN.House, MN.FatherName, MN.Village1, MN.DueDate, MN.RSrNo, MN.Name, MN.FeeGroup, SUM(MN.FeeAmt) NetAmt FROM(SELECT CSD.AcNo,CSD.SId,CSD.Name,CSD.FatherName,CSD.Village1,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,CSD.FeeId ,CSD.FeeGroup,CSD.FGroupId,ROUND((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent,CSD.feegrpid  FROM 
(Select CS.MSID,CS.AcNo,CS.SID,CS.Name,CS.House,CS.FatherName,CS.Village1,CS.FSDate,CS.SLDate,CS.groupid,CS.AdmClassNo+'$session'-Year(CS.FSDate)+
COALESCE(Sum(E.Result),0) CClass,CS.SrNo,CS.DueDate,CS.FeeName,CS.FPMode,CS.FeeId,CS.FGroupId,CS.FeeGroup,IF(CS.SeprateTPTFBook='0',SAT.TptStation,null) TptStation,DS.Discount,CS.feegrpid FROM ( 
SELECT S.AcNo, S.id SID,S.name,S.House,S.AdmClassNo,S.FSDate,S.SLDate,S.groupid,P.fathername,P.FeePaymentMode FPMode,L.village1,L.Village ,CU.MYUID,CU.MYDATE,CU.MYSESSION,CU.BEGINS,CU.ENDS,CU.MSID,DD.DateId DueDate,If(Year(DD.DateID)=Year(CU.Begins),Month(DD.DateId)- Month(CU.Begins) +'1',Month(DD.DateId)-Month(CU.Begins)+'13') AS SrNo,FN.Id FeeID,FN.FeeName,FN.FGroupId,FN.FeeGroup,C.SeprateTPTFBook,SFG.fgroupid as feegrpid FROM (
SELECT * FROM 7FeeUsers U WHERE U.MyUId= '$foo' ) CU INNER JOIN 10Company C on C.msid= CU.MSID INNER JOIN 13Students S on S.msid=CU.MSID and CU.MYDATE BETWEEN S.FSDATE AND S.SLDATE INNER JOIN 12Parents P on P.id=S.PID    
INNER JOIN 11Localities L on L.Village=P.Village INNER JOIN 6Dates DD ON Day(DD.DateId)='1' And DD.DateId BETWEEN CU.Begins AND CU.Ends and DD.dateid>=S.fsdate
INNER JOIN 7FeeNames FN ON FN.MSID=CU.MSID inner join 100SchoolFeeGrp SFG on SFG.msid= CU.msid and S.groupid=SFG.groupid Where S.AcNo=(select acno from 13Students S where S.id='$s_id' and S.msid='$msid')) CS LEFT JOIN 14Exam E ON E.MSID=CS.MSID And E.S_Id=CS.SID AND E.DateResult< CS.DueDate 
LEFT JOIN 35SATpt SAT ON SAT.S_ID=CS.SID AND SAT.MSId=CS.MSID AND CS.DueDate BETWEEN SAT.DateFrom AND SAT.DateTo 
LEFT JOIN 34DiscountedStudent DS ON DS.MSID=CS.MSID AND DS.S_id=CS.SID AND CS.DueDate BETWEEN DS.DateFrom AND DS.DateTo WHERE 1 Group By CS.SID,CS.SrNo,CS.FeeId Order By AcNo,SrNo,SID)CSD INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode INNER JOIN 31Fee1 FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=CSD.FeeId And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.feegrpid = FF.fgroupid or FF.fgroupid='0') LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And CSD.FeeId=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE MN.FeeAmt>0 And SId='$s_id' And  RSrNo='$RSrNo' GROUP BY RSrNo");// $gnr=mysql_num_rows($gdt);
				   while($gdtw=mysql_fetch_array($gdt)){   $FeeName=$gdtw['FeeName'];   $Samt=$gdtw['NetAmt'];   $stamt1=round($Samt);echo $stamt1-$EOD;
}/**/ ?></td>
                </tr>
                <tr>
                  <td height="23" class="bpart">Late Fee Fine</td>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td height="27" class="bpart">Grand Total</td>
                  <td align="right">&nbsp;</td>
                </tr>
              </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><table width="370" border="0" align="center">
                    <tr class="bpart">
                      <td width="124" height="36"><br>
                        Receipt No:<br></td>
                      <td width="236" align="right"><br>
                        Cashier initials</td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
        <td width="8">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td width="329" align="center" valign="top"><table width="377" border="1" height="352" cellspacing="0" cellpadding="0">
          <tr>
            <td width="373" height="350" align="center" valign="top"><table width="368" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(School Copy)</span></td>
              </tr>
              <tr>
                <td width="51" height="59" align="center"  ><span class="header"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo"></span></td>
                <td width="317" align="center" valign="top"  ><span class="header">
                  <?php     echo $sname;?>
                  <br>
                  <?php echo $Place;?></span></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                  <table width="288" border="0" align="center">
                    <tr>
                      <td width="223" height="20" align="left" class="bpart1">Date:<?php echo $TrDate;?></td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td height="25" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?></span></td>
              </tr>
            </table>
              <table width="372" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="31" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="3" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                </tr>
                <tr align="left">
                  <td height="21" colspan="5" align="left"><span class="bpart">
                    <? if($Gender=='F'){echo "D/O";}else {echo "S/O";}?>
                    :</span><span class="bpart">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo 'Mr.'.$FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="74" height="28" align="left" class="bpart">Class:</td>
                  <td width="54" align="left" class="bpart"><?php 
 $hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];}    
			 
					
					?></td>
                  <td colspan="2" align="left" class="bpart">Admission No:</td>
                  <td align="left" class="bpart"><?php  if($ViewOption=='0'){echo $SID;}else {echo $AdmNo;}?></td>
                </tr>
                <tr >
                  <td height="24" colspan="3" align="left" class="bpart">For the month of :</td>
                  <td width="105" align="left" class="bpart"><?php $sq=mysql_query($sqd="Select * from  month WHERE SrNo='$RSrNo' And MSID='$msid'");
while($sqw=mysql_fetch_array($sq)){   $sqw['MonthName'];//}

 $monh=$sqw['MonthName'];
if($monh=='April'){echo 'April';}
else if($monh=='May'){ echo 'May,Jun,Jul';}
else if($monh=='August'){ echo 'Aug,Sep,Oct';}
else if($monh=='November'){ echo 'Nov,Dec';}
else if($monh=='January'){ echo 'Jan,Feb,Mar';}
else {echo $monh;} 
}
?></td>
                  <td width="136" align="left" class="bpart"><?php echo $feeyr;?></td>
                </tr>
              </table>
              <table width="372" border="1" align="center">
                <tr class="bpart">
                  <td width="212" height="21">Particulars of Fee </td>
                  <td width="144" align="right">Amount</td>
                </tr>
                <?php  $ghi=mysql_query($gh="SELECT distinct FeeGroup FROM `7FeeNames` Where   `MSID`='$msid' And FeeGroup!='Tpt' ");
				 while($gow=mysql_fetch_array($ghi)){   $ann1=$gow['FeeGroup'];   //SELECT MN.AcNo,MN.Id,MN.Name, MN.CClass,MN.House,MN.FatherName,MN.Village,MN.DueDate,MN.RSrNo,MN.FeeGroup,MN.FGroupId,SUM(MN.FeeAmt) NetAmt
$dt=mysql_query($d="SELECT MN.AcNo, MN.SId Id, MN.CClass, MN.House, MN.FatherName, MN.Village1, MN.DueDate, MN.RSrNo, MN.Name, MN.FeeGroup, SUM(MN.FeeAmt) NetAmt
FROM(SELECT CSD.AcNo,CSD.SId,CSD.Name,CSD.FatherName,CSD.Village1,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,CSD.FeeId ,CSD.FeeGroup,CSD.FGroupId,ROUND((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent,CSD.feegrpid  FROM 
(Select CS.MSID,CS.AcNo,CS.SID,CS.Name,CS.House,CS.FatherName,CS.Village1,CS.FSDate,CS.SLDate,CS.groupid,CS.AdmClassNo+'$session'-Year(CS.FSDate)+
COALESCE(Sum(E.Result),0) CClass,CS.SrNo,CS.DueDate,CS.FeeName,CS.FPMode,CS.FeeId,CS.FGroupId,CS.FeeGroup,IF(CS.SeprateTPTFBook='0',SAT.TptStation,null) TptStation,DS.Discount,CS.feegrpid FROM ( 
SELECT S.AcNo, S.id SID,S.name,S.House,S.AdmClassNo,S.FSDate,S.SLDate,S.groupid,P.fathername,P.FeePaymentMode FPMode,L.village1,L.Village ,CU.MYUID,CU.MYDATE,CU.MYSESSION,CU.BEGINS,CU.ENDS,CU.MSID,DD.DateId DueDate,If(Year(DD.DateID)=Year(CU.Begins),Month(DD.DateId)- Month(CU.Begins) +'1',Month(DD.DateId)-Month(CU.Begins)+'13') AS SrNo,FN.Id FeeID,FN.FeeName,FN.FGroupId,FN.FeeGroup,C.SeprateTPTFBook,SFG.fgroupid as feegrpid FROM (
SELECT * FROM 7FeeUsers U WHERE U.MyUId= '$foo' ) CU INNER JOIN 10Company C on C.msid= CU.MSID INNER JOIN 13Students S on S.msid=CU.MSID and CU.MYDATE BETWEEN S.FSDATE AND S.SLDATE INNER JOIN 12Parents P on P.id=S.PID    
INNER JOIN 11Localities L on L.Village=P.Village INNER JOIN 6Dates DD ON Day(DD.DateId)='1' And DD.DateId BETWEEN CU.Begins AND CU.Ends and DD.dateid>=S.fsdate
INNER JOIN 7FeeNames FN ON FN.MSID=CU.MSID inner join 100SchoolFeeGrp SFG on SFG.msid= CU.msid and S.groupid=SFG.groupid Where S.AcNo=(select acno from 13Students S where S.id='$s_id' and S.msid='$msid')) CS LEFT JOIN 14Exam E ON E.MSID=CS.MSID And E.S_Id=CS.SID AND E.DateResult< CS.DueDate 
LEFT JOIN 35SATpt SAT ON SAT.S_ID=CS.SID AND SAT.MSId=CS.MSID AND CS.DueDate BETWEEN SAT.DateFrom AND SAT.DateTo 
LEFT JOIN 34DiscountedStudent DS ON DS.MSID=CS.MSID AND DS.S_id=CS.SID AND CS.DueDate BETWEEN DS.DateFrom AND DS.DateTo WHERE 1 Group By CS.SID,CS.SrNo,CS.FeeId Order By AcNo,SrNo,SID)CSD INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode INNER JOIN 31Fee1 FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=CSD.FeeId And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.feegrpid = FF.fgroupid or FF.fgroupid='0') LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And CSD.FeeId=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE MN.FeeAmt>0 And SId='$s_id' And  RSrNo='$RSrNo' And   FeeGroup='$ann1' GROUP BY RSrNo "); 
 while($dtw=mysql_fetch_array($dt)){
 $Amount1=$dtw['NetAmt'];  ?>
                <tr class="bpart">
                  <td height="23"><?php echo      $dtw['FeeGroup'];   ?></td>
                  <td align="right"  class="bpart"><?php  echo round($Amount1);    ?></td>
                </tr>
                <?php }}?>
                <tr>
                  <td height="29" class="bpart">Custom Discount</td>
                  <td align="right" class="bpart" ><? echo $EOD;?></td>
                </tr>
                <tr>
                  <td height="29" class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php   $TNetAmt;    round($TNetAmt);
				   $gdt=mysql_query($gd="SELECT MN.AcNo, MN.SId Id, MN.CClass, MN.House, MN.FatherName, MN.Village1, MN.DueDate, MN.RSrNo, MN.Name, MN.FeeGroup, SUM(MN.FeeAmt) NetAmt FROM(SELECT CSD.AcNo,CSD.SId,CSD.Name,CSD.FatherName,CSD.Village1,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,CSD.FeeId ,CSD.FeeGroup,CSD.FGroupId,ROUND((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent,CSD.feegrpid  FROM 
(Select CS.MSID,CS.AcNo,CS.SID,CS.Name,CS.House,CS.FatherName,CS.Village1,CS.FSDate,CS.SLDate,CS.groupid,CS.AdmClassNo+'$session'-Year(CS.FSDate)+
COALESCE(Sum(E.Result),0) CClass,CS.SrNo,CS.DueDate,CS.FeeName,CS.FPMode,CS.FeeId,CS.FGroupId,CS.FeeGroup,IF(CS.SeprateTPTFBook='0',SAT.TptStation,null) TptStation,DS.Discount,CS.feegrpid FROM ( 
SELECT S.AcNo, S.id SID,S.name,S.House,S.AdmClassNo,S.FSDate,S.SLDate,S.groupid,P.fathername,P.FeePaymentMode FPMode,L.village1,L.Village ,CU.MYUID,CU.MYDATE,CU.MYSESSION,CU.BEGINS,CU.ENDS,CU.MSID,DD.DateId DueDate,If(Year(DD.DateID)=Year(CU.Begins),Month(DD.DateId)- Month(CU.Begins) +'1',Month(DD.DateId)-Month(CU.Begins)+'13') AS SrNo,FN.Id FeeID,FN.FeeName,FN.FGroupId,FN.FeeGroup,C.SeprateTPTFBook,SFG.fgroupid as feegrpid FROM (
SELECT * FROM 7FeeUsers U WHERE U.MyUId= '$foo' ) CU INNER JOIN 10Company C on C.msid= CU.MSID INNER JOIN 13Students S on S.msid=CU.MSID and CU.MYDATE BETWEEN S.FSDATE AND S.SLDATE INNER JOIN 12Parents P on P.id=S.PID    
INNER JOIN 11Localities L on L.Village=P.Village INNER JOIN 6Dates DD ON Day(DD.DateId)='1' And DD.DateId BETWEEN CU.Begins AND CU.Ends and DD.dateid>=S.fsdate
INNER JOIN 7FeeNames FN ON FN.MSID=CU.MSID inner join 100SchoolFeeGrp SFG on SFG.msid= CU.msid and S.groupid=SFG.groupid Where S.AcNo=(select acno from 13Students S where S.id='$s_id' and S.msid='$msid')) CS LEFT JOIN 14Exam E ON E.MSID=CS.MSID And E.S_Id=CS.SID AND E.DateResult< CS.DueDate 
LEFT JOIN 35SATpt SAT ON SAT.S_ID=CS.SID AND SAT.MSId=CS.MSID AND CS.DueDate BETWEEN SAT.DateFrom AND SAT.DateTo 
LEFT JOIN 34DiscountedStudent DS ON DS.MSID=CS.MSID AND DS.S_id=CS.SID AND CS.DueDate BETWEEN DS.DateFrom AND DS.DateTo WHERE 1 Group By CS.SID,CS.SrNo,CS.FeeId Order By AcNo,SrNo,SID)CSD INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode INNER JOIN 31Fee1 FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=CSD.FeeId And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.feegrpid = FF.fgroupid or FF.fgroupid='0') LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And CSD.FeeId=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE MN.FeeAmt>0 And SId='$s_id' And  RSrNo='$RSrNo' GROUP BY RSrNo");// $gnr=mysql_num_rows($gdt);
				   while($gdtw=mysql_fetch_array($gdt)){   $FeeName=$gdtw['FeeName'];   $Samt=$gdtw['NetAmt'];    $stamt=round($Samt);echo $stamt-$EOD;
}/**/ ?></td>
                </tr>
                <tr>
                  <td height="23" class="bpart">Late Fee Fine</td>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td height="27" class="bpart">Grand Total</td>
                  <td align="right">&nbsp;</td>
                </tr>
              </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><table width="370" border="0" align="center">
                    <tr class="bpart">
                      <td width="124" height="36"><br>
                        Receipt No:<br></td>
                      <td width="236" align="right"><br>
                        Cashier initials</td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
        <td width="48">&nbsp;&nbsp;</td>
        </tr>
    </table>   </td>
  </tr>
</table><a href="feevoucher2.php?id=<? echo $s_id;?>"><input type="button" value="Back" ></a><input type="button" value="Print" onClick="printpage();">
 
  </form>
</div><!--<p class="page"></p>--></body><?php }}?>