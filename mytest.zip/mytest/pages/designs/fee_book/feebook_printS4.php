<?php
// print_r($oCurrentSchool);       

$tpt = (@http_get('param3') == "tpt" && $oCurrentSchool->SeprateTPTFBook == "1") ? "2" : (($oCurrentSchool->SeprateTPTFBook == "0") ? "1" : "0");
?>
<style type="text/css">

    .header {
        font-size: 18px;

        font-family: Verdana, Arial, Helvetica, sans-serif;
    }
    .subheader {
        font-size: 15px;font-family: Verdana, Arial, Helvetica, sans-serif;
    }
    .subheader1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 11px;

    }
    .subheader2 {
        font-size: 13px;font-family: Verdana, Arial, Helvetica, sans-serif;

    }
    .bpart {

        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 12px;
    }
    .bpart2 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 13px;

        font-weight: bold;	

    }
    .bpart1 {
        font-family: Verdana, Arial, Helvetica, sans-serif;
        font-size: 12px;


    }
    .bpart11 {
        font-family: Verdana, Arial, Helvetica, sans-serif;

        font-size: 12px;
        font-style:italic

    }
    .bpart21 {	font-family: Verdana, Arial, Helvetica, sans-serif;
               font-size: 18px;
    }
    .bpart3 {font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 13px;
    }
    .bpart12 {	font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;
    }

    p.page { page-break-after: always; }
</style>
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
$message = new Messages();
echo $message->display();
?>
            <div class="box">
                <?php
                $id = http_get('param2');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);

//                $delete_data = Fee::get_delete_student_from_fee_billing($MSID, $student->acno, $oCurrentUser->mysession);
//                $data_insert = Fee::insert_student_into_fee_billing($oCurrentUser->myuid, $student->acno);
//                print_r($student);
//                exit();
                ?>
                <br>
                <br><?php
//                print_r($oCurrentSchool);
                //delete previous Entrys of perticular acc no 
//                $delete_previous_user = Fee::get_delete_student_from_fee_billing($MSID, $student->acno, $oCurrentUser->begins, $oCurrentUser->ends);
                //Add new Entrys of perticular acc no 
//                $add_entrys = Fee::insert_student_into_fee_billing($MSID, $student->acno);
                //getting the loop data 
                $loops = Fee::get_fee_billing_loops($MSID, $student->acno);
                while ($rowv = $loops->fetch(PDO::FETCH_OBJ)) {
//                    echo "<pre>";
//                    print_r($rowv);
                    ?>

                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
                        <tr> 
                            <td height="587" align="center" valign="top">
                                <table width="300" height="539" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td height="539" valign="top">
                                            <table width="293" border="1" height="538" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td width="289" height="536" align="center" valign="top">
                                                        <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                            <tr>
                                                                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Student Copy)</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="51" align="center"  ><span class="header"><img src="<?php
                                    if ($oCurrentSchool->logo_img != "") {
                                        echo CLIENT_URL . "/uploads/thumbs/" . $oCurrentSchool->logo_img;
                                    } else {
                                        echo ASSETS_FOLDER . "/img/aboutlogo.jpg";
                                    }
                                    ?> " alt="" width="78" height="75" /></span></td>
                                                                <td width="237" align="center" valign="top"  >
                                                                    <span class="header">   <?= $oCurrentSchool->name; ?> 
                                                                        <br> </span><span class="subheader"><?= $oCurrentSchool->place; ?></span></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                                                                        <table width="288" border="0" align="center">
                                                                            <tr>
                                                                                <td width="223" align="center" class="bpart1"><?= $oCurrentSchool->bank; ?> A/C 
                                                                                    <?= $oCurrentSchool->acno; ?>
                                                                                </td>
                                                                            </tr>

                                                                        </table></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?= $oCurrentSchool->phone; ?></span></td>
                                                            </tr>
                                                        </table>
                                                        <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                            <tr>
                                                                <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                                                                <td colspan="2" align="left" class="bpart"><?= $student->name ?>&nbsp;</td>
                                                            </tr>
                                                            <tr align="left">
                                                                <td height="24" colspan="4" align="left"><span class="bpart"> <?php $g = $student->gender; ?>
                                                                        <?php
                                                                        if ($g == 'F') {
                                                                            echo 'D/O';
                                                                        } else {
                                                                            echo 'S/O';
                                                                        }
                                                                        ?> : Mr. <?= $student->f_name ?></span></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="74" height="28" align="left" class="bpart">Class:</td>
                                                                <td width="54" align="left" class="bpart"> <?php $cls = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                                    echo $cls->class_name; ?></td>
                                                                <td align="left" class="bpart">Student Id:</td>
                                                                <td width="63" align="left" class="bpart"><?= $student->student_id ?></td>
                                                            </tr>
                                                            <tr >
                                                                <td height="12" colspan="2" align="left" class="bpart">For the month of :</td>
                                                                <td height="12" colspan="2" align="left" class="bpart"> <?php
                                                                    $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo);
                                                                    while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                        $count = $fee_schedule->rowCount();
                                                                        if ($count > 0) {
                                                                            $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                            echo $month_name->month . " ";
                                                                        } else {
                                                                            $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                            echo $month_name->month . " ";
                                                                        }
                                                                        $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                    }
                                                                    ?> 
                                                                </td>
                                                            </tr>
    <?php if ($oCurrentSchool->LatefeeDate != '0') { ?>
                                                                <tr >
                                                                    <td height="12" colspan="2" align="left" class="bpart"><span class="bpart4">Last Date</span> :</td>
                                                                    <td height="12" colspan="2" align="left" class="bpart"><?= $oCurrentSchool->LatefeeDate ?>
                                                                        <?php $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                        echo $month_name->month . " ";
                                                                        ?></td>
                                                                </tr>
                                                                <?php }else{}?>
                                                            </table>
                                                            <table width="287" border="1" align="center">
                                                                <tr class="bpart">
                                                                    <td width="212">Particulars of Fee </td>
                                                                    <td width="59" align="right">Amount</td>
                                                                </tr>
                                                                <?php
                                                                $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);
                                                                
                                                                $ttl_amts = Fee::get_fee_book_querry2_subtotal($MSID, $student->acno, $rowv->RSrNo,'', $tpt);
                                                                while ($ttl_amt = $ttl_amts->fetch(PDO::FETCH_OBJ)) {
                                                                    $students = Student::get_students($oCurrentUser->myuid, '1', $ttl_amt->SID)->fetch(PDO::FETCH_OBJ);
                                                                   
                                                                while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                                                                    $fee_amount = Fee::get_fee_book_querry1($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $fee_name->fee_id, $tpt)->fetch(PDO::FETCH_OBJ);
                                                                    ?>    
                                                                   
                                                                    <tr class="bpart">
                                                                        <td><?= $fee_name->fee_group_name ?></td>
                                                                        <td align="right"  class="bpart"><?php echo round(@$fee_amount->FeeAmt); ?>
                                                                            &nbsp;</td>
                                                                    </tr>
                                                                <?php } } ?>
                                                                <tr>
                                                                    <td class="bpart">Total</td>
                                                                    <td align="right" class="bpart" > <?php $ttl_amount = Fee::get_fee_book_querry2_subtotal($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $tpt)->fetch(PDO::FETCH_OBJ); ?>
        <?php echo round($ttl_amount->Sub_Total); ?>
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="bpart">Late Fee/Previous Balance,if any</td>
                                                                    <td align="right">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="bpart">Grand Total</td>
                                                                    <td align="right">&nbsp;</td>
                                                                </tr>
                                                            </table>
                                                            <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td>
                                                                        <table width="287" border="0" align="center">
                                                                            <tr class="bpart3">
                                                                                <td height="17" colspan="2" class="bpart3"><u class="bpart12">Received Cash 
                                                                                        Rs.(In words)</u></td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td height="24" class="bpart3">_________________</td>
                                                                                <td width="149" rowspan="8"><table width="148" border="1">
                                                                                        <tr>
                                                                                            <td colspan="2" align="center"><u class="bpart12">Note Details</u></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td width="67"><span class="bpart12">1000 &nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                            <td width="65"><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="bpart12">500 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                            <td><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="bpart12">100 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                            <td><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="bpart12">50 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                            <td><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="bpart12">20 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                            <td><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="bpart12">10 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                            <td><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td><span class="bpart12">5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                            <td><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td align="right"><span class="bpart12">Total</span></td>
                                                                                            <td><span class="bpart12">&nbsp;=</span></td>
                                                                                        </tr>
                                                                                    </table></td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td width="128" height="24">_________________</td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td height="24">_________________</td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td height="24">_________________</td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td height="11">_________________</td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td height="4">Cashier:</td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td>&nbsp;</td>
                                                                            </tr>
                                                                            <tr class="bpart3">
                                                                                <td>Depositor Signature</td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>

                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                            <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                            
                                            <?php if ($oCurrentSchool->bank_reciept == 1) { ?>  
                                            <td height="539" valign="top">
                                                <table width="293" border="1" height="538" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td width="289" height="536" align="center" valign="top">
                                                            <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Bank Copy)</span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="51" align="center"  ><span class="header"><img src="<?php
                                    if ($oCurrentSchool->logo_img != "") {
                                        echo CLIENT_URL . "/uploads/thumbs/" . $oCurrentSchool->logo_img;
                                    } else {
                                        echo ASSETS_FOLDER . "/img/aboutlogo.jpg";
                                    }
                                    ?> " alt="" width="78" height="75" /></span></td>
                                                                    <td width="237" align="center" valign="top"  >
                                                                        <span class="header">   <?= $oCurrentSchool->name; ?> 
                                                                            <br> </span><span class="subheader"><?= $oCurrentSchool->place; ?></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="18" colspan="2" align="center" valign="top"><span class="header">
                                                                            <table width="288" border="0" align="center">
                                                                                <tr>
                                                                                    <td width="223" align="center" class="bpart1"><?= $oCurrentSchool->bank; ?> A/C 
        <?= $oCurrentSchool->acno; ?>
                                                                                    </td>
                                                                                </tr>

                                                                            </table></td>
                                                                </tr>
                                                                <tr>
                                                                    <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?= $oCurrentSchool->phone; ?></span></td>
                                                                </tr>
                                                            </table>
                                                            <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                <tr>
                                                                    <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                                                                    <td colspan="2" align="left" class="bpart"><?= $student->name ?>&nbsp;</td>
                                                                </tr>
                                                                <tr align="left">
                                                                    <td height="24" colspan="4" align="left"><span class="bpart"> <?php $g = $student->gender; ?>
                                                                            <?php
                                                                            if ($g == 'F') {
                                                                                echo 'D/O';
                                                                            } else {
                                                                                echo 'S/O';
                                                                            }
                                                                            ?> : Mr. <?= $student->f_name ?></span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="74" height="28" align="left" class="bpart">Class:</td>
                                                                    <td width="54" align="left" class="bpart"><?= $cls->class_name ?></td>
                                                                    <td align="left" class="bpart">Student Id:</td>
                                                                    <td width="63" align="left" class="bpart"><?= $student->student_id ?></td>
                                                                </tr>
                                                                <tr >
                                                                    <td height="12" colspan="2" align="left" class="bpart">For the month of :</td>
                                                                    <td height="12" colspan="2" align="left" class="bpart"> <?php
                                                                        $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo);
                                                                        while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                            $count = $fee_schedule->rowCount();
                                                                            if ($count > 0) {
                                                                                $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                echo $month_name->month . " ";
                                                                            } else {
                                                                                $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                echo $month_name->month . " ";
                                                                            }
                                                                            $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                        }
                                                                        ?> 
                                                                    </td>
                                                                </tr>
                                                                        <?php if ($oCurrentSchool->LatefeeDate != '0') { ?>
                                                                    <tr >
                                                                        <td height="12" colspan="2" align="left" class="bpart"><span class="bpart4">Last Date</span> :</td>
                                                                        <td height="12" colspan="2" align="left" class="bpart"><?= $oCurrentSchool->LatefeeDate ?>
            <?php $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
            echo $month_name->month . " ";
            ?></td>
                                                                    </tr>
                                                                    <?php }else{}?>
                                                                </table>
                                                                <table width="287" border="1" align="center">
                                                                    <tr class="bpart">
                                                                        <td width="212">Particulars of Fee </td>
                                                                        <td width="59" align="right">Amount</td>
                                                                    </tr>
            <?php
            $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);
            while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                $fee_amount = Fee::get_fee_book_querry1($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $fee_name->fee_id, $tpt)->fetch(PDO::FETCH_OBJ);
                ?>    
                                                                        
                                                                        <tr class="bpart">
                                                                            <td><?= $fee_name->fee_group_name ?></td>
                                                                            <td align="right"  class="bpart"><?php echo round(@$fee_amount->FeeAmt); ?>
                                                                                &nbsp;</td>
                                                                        </tr>
            <?php } ?>
                                                                    <tr>
                                                                        <td class="bpart">Total</td>
                                                                        <td align="right" class="bpart" > <?php $ttl_amount = Fee::get_fee_book_querry2_subtotal($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $tpt)->fetch(PDO::FETCH_OBJ); ?>
            <?php echo round($ttl_amount->Sub_Total); ?>
                                                                            &nbsp;</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="bpart">Late Fee/Previous Balance,if any</td>
                                                                        <td align="right">&nbsp;</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="bpart">Grand Total</td>
                                                                        <td align="right">&nbsp;</td>
                                                                    </tr>
                                                                </table>
                                                                <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td>
                                                                            <table width="287" border="0" align="center">
                                                                                <tr class="bpart3">
                                                                                    <td height="17" colspan="2" class="bpart3"><u class="bpart12">Received Cash 
                                                                                            Rs.(In words)</u></td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td height="24" class="bpart3">_________________</td>
                                                                                    <td width="149" rowspan="8"><table width="148" border="1">
                                                                                            <tr>
                                                                                                <td colspan="2" align="center"><u class="bpart12">Note Details</u></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td width="67"><span class="bpart12">1000 &nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                <td width="65"><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><span class="bpart12">500 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                <td><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><span class="bpart12">100 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                <td><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><span class="bpart12">50 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                <td><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><span class="bpart12">20 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                <td><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><span class="bpart12">10 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                <td><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td><span class="bpart12">5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                <td><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td align="right"><span class="bpart12">Total</span></td>
                                                                                                <td><span class="bpart12">&nbsp;=</span></td>
                                                                                            </tr>
                                                                                        </table></td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td width="128" height="24">_________________</td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td height="24">_________________</td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td height="24">_________________</td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td height="11">_________________</td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td height="4">Cashier:</td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td>&nbsp;</td>
                                                                                </tr>
                                                                                <tr class="bpart3">
                                                                                    <td>Depositor Signature</td>
                                                                                </tr>
                                                                            </table></td>
                                                                    </tr>

                                                                </table></td>
                                                        </tr>
                                                    </table></td>
                <?php } ?>
                                                <td>&nbsp;</td>
                                                <td height="539" valign="top">
                                                    <table width="293" border="1" height="538" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td width="289" height="536" align="center" valign="top">
                                                                <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(School Copy)</span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="51" align="center"  ><span class="header"><img src="<?php
                                    if ($oCurrentSchool->logo_img != "") {
                                        echo CLIENT_URL . "/uploads/thumbs/" . $oCurrentSchool->logo_img;
                                    } else {
                                        echo ASSETS_FOLDER . "/img/aboutlogo.jpg";
                                    }
                                    ?> " alt="" width="78" height="75" /></span></td>
                                                                        <td width="237" align="center" valign="top"  >
                                                                            <span class="header">   <?= $oCurrentSchool->name; ?> 
                                                                                <br> </span><span class="subheader"><?= $oCurrentSchool->place; ?></span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td height="18" colspan="2" align="center" valign="top"><span class="header">
                                                                                <table width="288" border="0" align="center">
                                                                                    <tr>
                                                                                        <td width="223" align="center" class="bpart1"><?= $oCurrentSchool->bank; ?> A/C 
            <?= $oCurrentSchool->acno; ?>
                                                                                        </td>
                                                                                    </tr>

                                                                                </table></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?= $oCurrentSchool->phone; ?></span></td>
                                                                    </tr>
                                                                </table>
                                                                <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                                                                        <td colspan="2" align="left" class="bpart"><?= $student->name ?>&nbsp;</td>
                                                                    </tr>
                                                                    <tr align="left">
                                                                        <td height="24" colspan="4" align="left"><span class="bpart"> <?php $g = $student->gender; ?>
            <?php
            if ($g == 'F') {
                echo 'D/O';
            } else {
                echo 'S/O';
            }
            ?> : Mr. <?= $student->f_name ?></span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="74" height="28" align="left" class="bpart">Class:</td>
                                                                        <td width="54" align="left" class="bpart"><?= $cls->class_name ?></td>
                                                                        <td align="left" class="bpart">Student Id:</td>
                                                                        <td width="63" align="left" class="bpart"><?= $student->student_id ?></td>
                                                                    </tr>
                                                                    <tr >
                                                                        <td height="12" colspan="2" align="left" class="bpart">For the month of :</td>
                                                                        <td height="12" colspan="2" align="left" class="bpart"> <?php
                                                                            $fee_schedule = Fee::get_fee_schedule($MSID, '', 'all', '', $rowv->RSrNo);
                                                                            while ($row_fee_schedule = $fee_schedule->fetch(PDO::FETCH_OBJ)) {


                                                                                $count = $fee_schedule->rowCount();
                                                                                if ($count > 0) {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                } else {
                                                                                    $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                                    echo $month_name->month . " ";
                                                                                }
                                                                                $date = DateTime::createFromFormat("Y-m-d", $rowv->DueDate);
                                                                            }
                                                                            ?> 
                                                                        </td>
                                                                    </tr>
            <?php if ($oCurrentSchool->LatefeeDate != '0') { ?>
                                                                        <tr >
                                                                            <td height="12" colspan="2" align="left" class="bpart"><span class="bpart4">Last Date</span> :</td>
                                                                            <td height="12" colspan="2" align="left" class="bpart"><?= $oCurrentSchool->LatefeeDate ?>
                                                                        <?php $month_name = Master::get_months($MSID, $row_fee_schedule->sr_no_from)->fetch(PDO::FETCH_OBJ);
                                                                        echo $month_name->month . " ";
                                                                        ?></td>
                                                                        </tr>
                                                                        <?php }else{}?>
                                                                    </table>
                                                                    <table width="287" border="1" align="center">
                                                                        <tr class="bpart">
                                                                            <td width="212">Particulars of Fee </td>
                                                                            <td width="59" align="right">Amount</td>
                                                                        </tr>
                                                                        <?php
                                                                        $fee_names = Fee::get_fee_names($MSID, '', 'all', '', '', "True", $tpt);
                                                                        while ($fee_name = $fee_names->fetch(PDO::FETCH_OBJ)) {
                                                                            $fee_amount = Fee::get_fee_book_querry1($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $fee_name->fee_id, $tpt)->fetch(PDO::FETCH_OBJ);
                                                                            ?>    
                                                                            
                                                                            <tr class="bpart">
                                                                                <td><?= $fee_name->fee_group_name ?></td>
                                                                                <td align="right"  class="bpart"><?php echo round(@$fee_amount->FeeAmt); ?>
                                                                                    &nbsp;</td>
                                                                            </tr>
                <?php } ?>
                                                                        <tr>
                                                                            <td class="bpart">Total</td>
                                                                            <td align="right" class="bpart" > <?php $ttl_amount = Fee::get_fee_book_querry2_subtotal($MSID, $students->acno, $rowv->RSrNo, $students->student_id, $tpt)->fetch(PDO::FETCH_OBJ); ?>
                <?php echo round($ttl_amount->Sub_Total); ?>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="bpart">Late Fee/Previous Balance,if any</td>
                                                                            <td align="right">&nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="bpart">Grand Total</td>
                                                                            <td align="right">&nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                    <table width="280" border="0" cellspacing="0" cellpadding="0">
                                                                        <tr>
                                                                            <td>
                                                                                <table width="287" border="0" align="center">
                                                                                    <tr class="bpart3">
                                                                                        <td height="17" colspan="2" class="bpart3"><u class="bpart12">Received Cash 
                                                                                                Rs.(In words)</u></td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td height="24" class="bpart3">_________________</td>
                                                                                        <td width="149" rowspan="8"><table width="148" border="1">
                                                                                                <tr>
                                                                                                    <td colspan="2" align="center"><u class="bpart12">Note Details</u></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td width="67"><span class="bpart12">1000 &nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                    <td width="65"><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span class="bpart12">500 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                    <td><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span class="bpart12">100 &nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                    <td><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span class="bpart12">50 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                    <td><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span class="bpart12">20 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                    <td><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span class="bpart12">10 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                    <td><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td><span class="bpart12">5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="banklogo/multi.png" width="11" height="11"></span></td>
                                                                                                    <td><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td align="right"><span class="bpart12">Total</span></td>
                                                                                                    <td><span class="bpart12">&nbsp;=</span></td>
                                                                                                </tr>
                                                                                            </table></td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td width="128" height="24">_________________</td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td height="24">_________________</td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td height="24">_________________</td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td height="11">_________________</td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td height="4">Cashier:</td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td>&nbsp;</td>
                                                                                    </tr>
                                                                                    <tr class="bpart3">
                                                                                        <td>Depositor Signature</td>
                                                                                    </tr>
                                                                                </table></td>
                                                                        </tr>

                                                                    </table></td>
                                                            </tr>
                                                        </table></td>
                                                </tr>
                                            </table>   </td>
                                    </tr>
                                </table>
                 <p class="page"></p>
            <?php } ?>
            </div>
        </div>
    </div>
    
</section>
