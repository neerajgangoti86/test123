<header> <style type="text/css">
     
        
        .header {
                                font-size: 16px;
                                font-weight:bold;
                                font-family: Verdana, Arial, Helvetica, sans-serif;
                            } 
							 .bpart {

                                font-family:Arial, Helvetica, sans-serif;
                                font-size: 12px; font-weight:bold;
                            }
							 .bpart1 {

                                font-family:Arial, Helvetica, sans-serif;
                                font-size: 12px;  font-weight:bold;
                            }
                        </style>
      
<style type="text/css">
   <!--
   @page { size:5in 5in; margin-bottom:auto; margin-left:20px; }
   -->
</style>
                        
                        
                        </header>
					
<body>						<?php
// print_r($oCurrentSchool);       

//$tpt = (@http_get('param3') == "tpt" && $oCurrentSchool->SeprateTPTFBook == "1") ? "2" : (($oCurrentSchool->SeprateTPTFBook == "0") ? "1" : "0");
//if (@http_get('param3') == "month") {
//    $rsrno = http_get('param4');
//}
//$tr_id_no = http_get('param5');
?>
 <?php
            $message = new Messages();
            echo $message->display();
            ?>
          
                <?php
//                $id = http_get('param2');
               
                 
//                 $trxn = Fee::get_txn($MSID, $tr_id_no)->fetch(PDO::FETCH_OBJ);
                ?> <?php
                $loops = Fee::get_fee_reciept_bulk_print($oCurrentUser->myuid,'','');
               
                while ($rowv = $loops->fetch()) {
//                  pr($rowv);
           $student = Student::get_students($oCurrentUser->myuid, '1', $rowv['student_id'])->fetch(PDO::FETCH_OBJ); ?>
      <section class="content">
         
        
 <table width="100%" align="left">
                                <tr> 
                                    <td align="left" valign="top"><table width="553">
                                            <tr>
                                                <td width="545" valign="top"><table width="549" border="1" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td width="545" align="center" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">

                                                                    <tr valign="top">
                                                                        <td width="67" rowspan="2" align="center"  ><span class="header"><img src="<?= ASSETS_FOLDER ?>/img/logo single outlined.jpg" alt="" width="58" height="46" /></span></td>
                                                                        <td width="100%" align="center" valign="top"  ><span class="header">
                                                                                <?= $oCurrentSchool->name; ?>  </span></td>
                                                                    </tr>
                                                                    <tr>
                                                                      <td height="18" align="center" valign="top"  ><span class="bpart1"><b>
                                                                        <?= $oCurrentSchool->Add_ReportC ?>
                                                                      </b></span></td>
                                                              </tr>

                                                                    <tr>
                                                                        <td colspan="2" align="center" valign="top">                                                                                </td>
                                                                    </tr>
                                                                </table>

                                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td colspan="2" align="left" class="bpart">Student's Name:</td>
                                                                        <td colspan="3" align="left" class="bpart"><?= $student->name ?>&nbsp;</td>
                                                                  </tr>
                                                                    <tr align="left">
                                                                        <td colspan="2" align="left"><span class="bpart"> <?php $g = $student->gender; ?>
                                                                                <?php
                                                                                if ($g == 'F') {
                                                                                    echo 'D/O';
                                                                                } else {
                                                                                    echo 'S/O';
                                                                                }
                                                                                ?>
                                                                                : </span>
                                                                        </td>
                                                                        <td colspan="3" align="left"><span class="bpart">Mr.
                                                                            <?= $student->f_name ?>
: </span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="61" align="left" class="bpart">Class:</td>
                                                                        <td width="85" align="left" class="bpart"><?= $student->class_name ?></td>
                                                                        <td colspan="2" align="left" class="bpart">Student Id:</td>
                                                                        <td width="236" align="left" class="bpart1"><?= $student->student_id ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="61" align="left" class="bpart">Date : </td>
                                                                        <td width="85" align="left" class="bpart"><?php // echo $newdate= date('d-m-Y',strtotime($rowv['tr_date']));  ?></td>
                                                                        <td colspan="2" align="left" class="bpart">Receipt No :</td>
                                                                        <td width="236" align="left" class="bpart1"><?php //  $rowv['party_refference']; ?></td>
                                                                    </tr>
                                                                    <tr >
                                                                        <td colspan="3" align="left" class="bpart"><?php // $p_type= $rowv['type']; 
//                                                                        if( $p_type== 'Adjustment')
//                    {   
//                        echo "Paid With Adjustment";                                                    
//                    }                                                        
//                    else { ?>
                      For the month of :<?php // }?>
          
          </td>  <td colspan="2" align="left" class="bpart">name </td>
                                                                    </tr>
                                                              </table>
                                                             
                                                             </td>
                                                        </tr>
                                              </table></td>


                                            </tr>
                                        </table>   </td>
                                </tr>
                            </table>
                      
 
                  
              
                </section>
         <?php
                    }
                
                ?>
      </body>