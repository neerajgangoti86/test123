<?php   
session_start();
include("../../connect/db.php");   
$msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else {  $s_id1=$_GET['s_id'];   $s_id = mysql_real_escape_string($s_id1);
//$cno1=$_GET['cno'];$cno = mysql_real_escape_string($cno1);
	  $foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
   $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; }  ?> 
<style type="text/css">
<!--  
.header {
	font-size: 20px;
	font-weight:bold;
	 font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader {
	font-size: 17px;font-family: Verdana, Arial, Helvetica, sans-serif;
}
.subheader1 {
font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 11px;
	 
}
.subheader2 {
	font-size: 13px;font-family: Verdana, Arial, Helvetica, sans-serif;
	 
}
.bpart {
 
font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.bpart2 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
	 
	font-weight: bold;	

}
.bpart1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
 
 
}
.bpart11 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
 
	font-size: 12px;
	font-style:italic
 
}
.bpart21 {	font-family: Verdana, Arial, Helvetica, sans-serif;
 font-size: 18px;
}
.bpart3 {font-family: Verdana, Arial, Helvetica, sans-serif;	font-size: 13px;
}
.bpart12 {	font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;
}
-->
</style><!--<link href="css/glfee.css"  rel="stylesheet" type="text/css" media="all" />--> <?php 
$nd=mysql_query($nsql="SELECT MN.AcNo,MN.Id,MN.Name, MN.CClass,MN.House,MN.FatherName,MN.Village,MN.DueDate,MN.RSrNo,MN.FeeGroup,MN.FGroupId,SUM(MN.FeeAmt) NetAmt

FROM(SELECT CSD.AcNo,CSD.Id,CSD.Name,CSD.FatherName,CSD.Village,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,FN.Id FeeId,FN.FeeGroup,FN.FGroupId,(If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0)) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent

FROM (SELECT CS.AcNo,CS.Id,CS.Name,CS.FatherName,CS.Village,DD.DateId AS DueDate,If(Year(DD.DateID)=Year(CS.Begins),Month(DD.DateId)- Month(CS.Begins) +'1',Month(DD.DateId)-Month(CS.Begins)+'13') AS SrNo,CS.MSID,CS.CClass,CS.House, CS.Stream,CS.MainGroup,CS.SubGroup,CS.FPMode,CS.FSDate,CS.TptStation,CS.Discount 

FROM (SELECT U.MSID,U.Begins,U.Ends,If(P.SfeebookR='1',S.Id,S.PID) AcNo ,S.Id,S.FSDate, S.AdmClassNo+ U.MySession-Year(S.FsDate)+COALESCE(Sum(E.Result),0) CClass,S.House,S.Name,S.Stream,S.MainGroup,S.SubGroup,S.SLDate,P.FatherName,L.Village,P.FeePaymentMode AS FPMode ,SAT.TptStation,DS.Discount FROM 13Students S  INNER JOIN 7FeeUsers U ON U.MSID=S.MSID LEFT JOIN 14Exam E ON E.MSID=U.MSID AND E.DateResult< U.MyDate AND S.Id= E.S_Id INNER JOIN 12Parents P ON P.MSID=U.MSID AND P.Id=S.PID INNER JOIN 11Localities L ON L.MSID=U.MSID AND L.Village=P.Village LEFT JOIN 35SATpt SAT ON SAT.MSID=U.MSID AND SAT.S_ID=S.Id AND U.MyDate BETWEEN SAT.DateFROM AND SAT.DateTo LEFT JOIN 34DiscountedStudent DS ON DS.MSID=U.MSID AND DS.S_ID=S.Id AND U.MyDate BETWEEN DS.DateFROM AND DS.DateTo WHERE S.Id= '$s_id' AND U.MyUId = '$foo' GROUP BY S.Id )CS 
      
INNER JOIN 6Dates DD ON DD.DateId BETWEEN CS.Begins AND CS.Ends AND Day(DateId)='1' AND DD.DateId BETWEEN CS.FSDate AND CS.SLDate WHERE 1 ) AS CSD 

INNER JOIN 7FeeNames FN ON FN.MSID=CSD.MSID 

INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode 

INNER JOIN 31Fee FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=FN.Id And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And 
If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.Stream = FF.Stream OR FF.Stream='0') AND (CSD.MainGroup = FF.MainGroup OR FF.MainGroup='0') AND (CSD.SubGroup = FF.SubGroup OR FF.SubGroup='0') 

LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation 

LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And FN.Id=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE FeeAmt>0 And FeeGroup!='Tpt'

GROUP BY RSrNo
ORDER BY RSrNo"); while($nrow=mysql_fetch_array($nd)){
$s_id= $nrow['Id']; $SID= $nrow['AcNo'];   $Gender= $nrow['Gender'];$Name= $nrow['Name'];  $FatherName= $nrow['FatherName'];  $Village= $nrow['Village'];$RSrNo= $nrow['RSrNo']; $MonthNo= $nrow['Month']; 
 $feeyr= $nrow['Year'];  $FeeGroup= $nrow['FeeGroup'];  $TNetAmt= $nrow['NetAmt'];   $CClass= $nrow['CClass'];
 
?>
<title><?php $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
  $Place= $row['Place'];
    $AffNo= $row['AffNo'];
	 $SchoolNo= $row['SchoolNo'];
	 	 $Phone= $row['Phone'];
$Board= $row['Board'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$BankCash= $row['BankCash'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$EMail= $row['EMail'];
$SFeebookR= $row['SFeebookR']; 
$FeePaymentmode= $row['FeePaymentmode'];
$bank= $row['Bank']; $branch= $row['Branch']; $acno=$row['ACNo'];
}?></title><body>
<style>
p.page { page-break-after: always; }
</style><div class="tmbanner1">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" >
  <tr> 
    <td height="587" align="center" valign="top"><table width="731" height="353" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="303" height="353" valign="top"><table width="293" border="1" height="352" cellspacing="0" cellpadding="0">
          <tr>
            <td width="289" height="350" align="center" valign="top"><table width="280" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(Student Copy)</span></td>
              </tr>
              <tr>
                <td width="51" align="center"  ><span class="header"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo"></span></td>
                <td width="237" align="center" valign="top"  ><span class="header">
                  <?php     echo $sname;?>
                  <br>
                  <?php echo $Place;?>
                </span></td>
              </tr>
            
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                  <table width="288" border="0" align="center">
                    <tr>
                      <td width="223" align="left" class="bpart1"><?php echo $acno;?> </td>
                      </tr>
                  
                    </table></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?>
                  </span></td>
              </tr>
            </table>
              
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
               <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="3" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                  </tr>
                <tr align="left">
                  <td height="24" colspan="5" align="left"><span class="bpart"><? if($Gender=='F'){echo "D/O";}else {echo "S/O";}?>:</span><span class="bpart">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo 'Mr.'.$FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="74" height="28" align="left" class="bpart">Class:</td>
                  <td width="54" align="left" class="bpart"><?php 
 $hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];}    
			 
					
					?></td>
                  <td colspan="2" align="left" class="bpart">Student Id:</td>
                  <td align="left" class="bpart"><?php echo $SID;?></td>
                  </tr>
                <tr >
                  <td height="24" colspan="3" align="left" class="bpart">For the month of :</td>
                  <td width="86" align="left" class="bpart"><?php $sq=mysql_query($sqd="Select * from  month WHERE SrNo='$RSrNo' And MSID='$msid'");
while($sqw=mysql_fetch_array($sq)){   $sqw['MonthName'];//}

 $monh=$sqw['MonthName'];
if($monh=='April'){echo 'April';}
else if($monh=='May'){ echo 'May,Jun,Jul';}
else if($monh=='August'){ echo 'Aug,Sep,Oct';}
else if($monh=='November'){ echo 'Nov,Dec';}
else if($monh=='January'){ echo 'Jan,Feb,Mar';}
else {echo $monh;} 
}
?></td>
                  <td width="63" align="left" class="bpart"><?php echo $feeyr;?></td>
                </tr>
                </table>
              <table width="287" border="1" align="center">
                <tr class="bpart">
                  <td width="212">Particulars of Fee </td>
                  <td width="59" align="right">Amount</td>
                </tr>
                <?php  $ghi=mysql_query($gh="SELECT distinct FeeGroup FROM `7FeeNames` Where   `MSID`='$msid' And FeeGroup!='Tpt' ");
				 while($gow=mysql_fetch_array($ghi)){  ?> 
                <tr class="bpart">
                  <td><?php echo    $ann1=$gow['FeeGroup'];   ?></td>
                  <td align="right"  class="bpart"><?php 
$dt=mysql_query($d="SELECT MN.AcNo,MN.Id,MN.Name, MN.CClass,MN.House,MN.FatherName,MN.Village,MN.DueDate,MN.RSrNo,MN.FeeGroup,MN.FGroupId,SUM(MN.FeeAmt) NetAmt

FROM(SELECT CSD.AcNo,CSD.Id,CSD.Name,CSD.FatherName,CSD.Village,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,FN.Id FeeId,FN.FeeGroup,FN.FGroupId,round((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent

FROM (SELECT CS.AcNo,CS.Id,CS.Name,CS.FatherName,CS.Village,DD.DateId AS DueDate,If(Year(DD.DateID)=Year(CS.Begins),Month(DD.DateId)- Month(CS.Begins) +'1',Month(DD.DateId)-Month(CS.Begins)+'13') AS SrNo,CS.MSID,CS.CClass,CS.House, CS.Stream,CS.MainGroup,CS.SubGroup,CS.FPMode,CS.FSDate,CS.TptStation,CS.Discount 

FROM (SELECT U.MSID,U.Begins,U.Ends,If(P.SfeebookR='1',S.Id,S.PID) AcNo ,S.Id,S.FSDate, S.AdmClassNo+ U.MySession-Year(S.FsDate)+COALESCE(Sum(E.Result),0) CClass,S.House,S.Name,S.Stream,S.MainGroup,S.SubGroup,S.SLDate,P.FatherName,L.Village,P.FeePaymentMode AS FPMode ,SAT.TptStation,DS.Discount FROM 13Students S  INNER JOIN 7FeeUsers U ON U.MSID=S.MSID LEFT JOIN 14Exam E ON E.MSID=U.MSID AND E.DateResult< U.MyDate AND S.Id= E.S_Id INNER JOIN 12Parents P ON P.MSID=U.MSID AND P.Id=S.PID INNER JOIN 11Localities L ON L.MSID=U.MSID AND L.Village=P.Village LEFT JOIN 35SATpt SAT ON SAT.MSID=U.MSID AND SAT.S_ID=S.Id AND U.MyDate BETWEEN SAT.DateFROM AND SAT.DateTo LEFT JOIN 34DiscountedStudent DS ON DS.MSID=U.MSID AND DS.S_ID=S.Id AND U.MyDate BETWEEN DS.DateFROM AND DS.DateTo WHERE S.Id= '$s_id' AND U.MyUId = '$foo' GROUP BY S.Id )CS 
      
INNER JOIN 6Dates DD ON DD.DateId BETWEEN CS.Begins AND CS.Ends AND Day(DateId)='1' AND DD.DateId BETWEEN CS.FSDate AND CS.SLDate WHERE 1 ) AS CSD 

INNER JOIN 7FeeNames FN ON FN.MSID=CSD.MSID 

INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode 

INNER JOIN 31Fee FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=FN.Id And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And 
If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.Stream = FF.Stream OR FF.Stream='0') AND (CSD.MainGroup = FF.MainGroup OR FF.MainGroup='0') AND (CSD.SubGroup = FF.SubGroup OR FF.SubGroup='0') 

LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation 

LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And FN.Id=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE RSrNo='$RSrNo'  And FeeGroup='$ann1' GROUP BY RSrNo "); 
 while($dtw=mysql_fetch_array($dt)){
 $Amount1=$dtw['NetAmt'];  echo round($Amount1);   
} 
 ?>
                    &nbsp;</td>
                </tr>
                <?php }?>
                <tr>
                  <td class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php   $TNetAmt;    round($TNetAmt);
				   $gdt=mysql_query($gd="SELECT MN.AcNo,MN.Id,MN.Name, MN.CClass,MN.House,MN.FatherName,MN.Village,MN.DueDate,MN.RSrNo,MN.FeeGroup,MN.FGroupId,SUM(MN.FeeAmt) NetAmt

FROM(SELECT CSD.AcNo,CSD.Id,CSD.Name,CSD.FatherName,CSD.Village,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,FN.Id FeeId,FN.FeeGroup,FN.FGroupId,round((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent

FROM (SELECT CS.AcNo,CS.Id,CS.Name,CS.FatherName,CS.Village,DD.DateId AS DueDate,If(Year(DD.DateID)=Year(CS.Begins),Month(DD.DateId)- Month(CS.Begins) +'1',Month(DD.DateId)-Month(CS.Begins)+'13') AS SrNo,CS.MSID,CS.CClass,CS.House, CS.Stream,CS.MainGroup,CS.SubGroup,CS.FPMode,CS.FSDate,CS.TptStation,CS.Discount 

FROM (SELECT U.MSID,U.Begins,U.Ends,If(P.SfeebookR='1',S.Id,S.PID) AcNo ,S.Id,S.FSDate, S.AdmClassNo+ U.MySession-Year(S.FsDate)+COALESCE(Sum(E.Result),0) CClass,S.House,S.Name,S.Stream,S.MainGroup,S.SubGroup,S.SLDate,P.FatherName,L.Village,P.FeePaymentMode AS FPMode ,SAT.TptStation,DS.Discount FROM 13Students S  INNER JOIN 7FeeUsers U ON U.MSID=S.MSID LEFT JOIN 14Exam E ON E.MSID=U.MSID AND E.DateResult< U.MyDate AND S.Id= E.S_Id INNER JOIN 12Parents P ON P.MSID=U.MSID AND P.Id=S.PID INNER JOIN 11Localities L ON L.MSID=U.MSID AND L.Village=P.Village LEFT JOIN 35SATpt SAT ON SAT.MSID=U.MSID AND SAT.S_ID=S.Id AND U.MyDate BETWEEN SAT.DateFROM AND SAT.DateTo LEFT JOIN 34DiscountedStudent DS ON DS.MSID=U.MSID AND DS.S_ID=S.Id AND U.MyDate BETWEEN DS.DateFROM AND DS.DateTo WHERE S.Id= '$s_id' AND U.MyUId = '$foo' GROUP BY S.Id )CS 
      
INNER JOIN 6Dates DD ON DD.DateId BETWEEN CS.Begins AND CS.Ends AND Day(DateId)='1' AND DD.DateId BETWEEN CS.FSDate AND CS.SLDate WHERE 1 ) AS CSD 

INNER JOIN 7FeeNames FN ON FN.MSID=CSD.MSID 

INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode 

INNER JOIN 31Fee FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=FN.Id And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And 
If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.Stream = FF.Stream OR FF.Stream='0') AND (CSD.MainGroup = FF.MainGroup OR FF.MainGroup='0') AND (CSD.SubGroup = FF.SubGroup OR FF.SubGroup='0') 

LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation 

LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And FN.Id=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE FeeGroup!='Tpt'

 And RSrNo='$RSrNo' Group By RSrNo");// $gnr=mysql_num_rows($gdt);
				   while($gdtw=mysql_fetch_array($gdt)){   $FeeName=$gdtw['FeeName'];   $Samt=$gdtw['NetAmt'];  echo round($Samt);
}/**/ ?>
                    &nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Late Fee Fine</td>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Grand Total</td>
                  <td align="right">&nbsp;</td>
                </tr>
              </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><table width="287" border="0" align="center">
                    <tr class="bpart">
                      <td><br>
                        Receipt No:<br></td>
                      <td align="right"><br>
                        Cashier initials</td>
                    </tr>
                  </table></td>
                </tr>
            
              </table></td>
          </tr>
        </table></td>
        <td width="87">&nbsp;&nbsp;</td>
        <td width="330" align="center" valign="top"><table width="293" border="1" height="352" cellspacing="0" cellpadding="0">
          <tr>
            <td width="289" height="350" align="center" valign="top"><table width="280" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="14" colspan="2" align="right" valign="top"><span class="subheader1">(School Copy)</span></td>
              </tr>
              <tr>
                <td width="51" align="center"  ><span class="header"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/aboutlogo.jpg";} ?>" width="50" height="50" class="logo"></span></td>
                <td width="237" align="center" valign="top"  ><span class="header">
                  <?php     echo $sname;?>
                  <br>
                  <?php echo $Place;?> </span></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="header">
                  <table width="288" border="0" align="center">
                    <tr>
                      <td width="223" align="left" class="bpart1"><?php echo $acno;?></td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td height="18" colspan="2" align="center" valign="top"><span class="subheader2">Ph. No.<?php echo $Phone; ?> </span></td>
              </tr>
            </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="22" colspan="2" align="left" class="bpart">Student's Name:</td>
                  <td colspan="3" align="left" class="bpart"><?php echo $Name;?>&nbsp;</td>
                </tr>
                <tr align="left">
                  <td height="24" colspan="5" align="left"><span class="bpart">
                    <? if($Gender=='F'){echo "D/O";}else {echo "S/O";}?>
                    :</span><span class="bpart">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo 'Mr.'.$FatherName;?></span></td>
                </tr>
                <tr>
                  <td width="74" height="28" align="left" class="bpart">Class:</td>
                  <td width="54" align="left" class="bpart"><?php 
 $hh=mysql_query($h="SELECT Distinct ClassName FROM `17Class` WHERE `ClassNo`='$CClass' And `MSID`='$msid' ");
					while($hhh=mysql_fetch_array($hh)){ echo $ClassName=$hhh['ClassName'];}    
			 
					
					?></td>
                  <td colspan="2" align="left" class="bpart">Student Id:</td>
                  <td align="left" class="bpart"><?php echo $SID;?></td>
                </tr>
                <tr >
                  <td height="24" colspan="3" align="left" class="bpart">For the month of :</td>
                  <td width="86" align="left" class="bpart"><?php $sq=mysql_query($sqd="Select * from  month WHERE SrNo='$RSrNo' And MSID='$msid'");
while($sqw=mysql_fetch_array($sq)){   $sqw['MonthName'];//}

 $monh=$sqw['MonthName'];
if($monh=='April'){echo 'April';}
else if($monh=='May'){ echo 'May,Jun,Jul';}
else if($monh=='August'){ echo 'Aug,Sep,Oct';}
else if($monh=='November'){ echo 'Nov,Dec';}
else if($monh=='January'){ echo 'Jan,Feb,Mar';}
else {echo $monh;} 
}
?></td>
                  <td width="63" align="left" class="bpart"><?php echo $feeyr;?></td>
                </tr>
              </table>
              <table width="287" border="1" align="center">
                <tr class="bpart">
                  <td width="212">Particulars of Fee </td>
                  <td width="59" align="right">Amount</td>
                </tr>
                <?php  $ghi=mysql_query($gh="SELECT distinct FeeGroup FROM `7FeeNames` Where   `MSID`='$msid' And FeeGroup!='Tpt' ");
				 while($gow=mysql_fetch_array($ghi)){  ?>
                <tr class="bpart">
                  <td><?php echo    $ann1=$gow['FeeGroup'];   ?></td>
                  <td align="right"  class="bpart"><?php 
$dt=mysql_query($d="SELECT MN.AcNo,MN.Id,MN.Name, MN.CClass,MN.House,MN.FatherName,MN.Village,MN.DueDate,MN.RSrNo,MN.FeeGroup,MN.FGroupId,SUM(MN.FeeAmt) NetAmt

FROM(SELECT CSD.AcNo,CSD.Id,CSD.Name,CSD.FatherName,CSD.Village,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,FN.Id FeeId,FN.FeeGroup,FN.FGroupId,round((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent

FROM (SELECT CS.AcNo,CS.Id,CS.Name,CS.FatherName,CS.Village,DD.DateId AS DueDate,If(Year(DD.DateID)=Year(CS.Begins),Month(DD.DateId)- Month(CS.Begins) +'1',Month(DD.DateId)-Month(CS.Begins)+'13') AS SrNo,CS.MSID,CS.CClass,CS.House, CS.Stream,CS.MainGroup,CS.SubGroup,CS.FPMode,CS.FSDate,CS.TptStation,CS.Discount 

FROM (SELECT U.MSID,U.Begins,U.Ends,If(P.SfeebookR='1',S.Id,S.PID) AcNo ,S.Id,S.FSDate, S.AdmClassNo+ U.MySession-Year(S.FsDate)+COALESCE(Sum(E.Result),0) CClass,S.House,S.Name,S.Stream,S.MainGroup,S.SubGroup,S.SLDate,P.FatherName,L.Village,P.FeePaymentMode AS FPMode ,SAT.TptStation,DS.Discount FROM 13Students S  INNER JOIN 7FeeUsers U ON U.MSID=S.MSID LEFT JOIN 14Exam E ON E.MSID=U.MSID AND E.DateResult< U.MyDate AND S.Id= E.S_Id INNER JOIN 12Parents P ON P.MSID=U.MSID AND P.Id=S.PID INNER JOIN 11Localities L ON L.MSID=U.MSID AND L.Village=P.Village LEFT JOIN 35SATpt SAT ON SAT.MSID=U.MSID AND SAT.S_ID=S.Id AND U.MyDate BETWEEN SAT.DateFROM AND SAT.DateTo LEFT JOIN 34DiscountedStudent DS ON DS.MSID=U.MSID AND DS.S_ID=S.Id AND U.MyDate BETWEEN DS.DateFROM AND DS.DateTo WHERE S.Id= '$s_id' AND U.MyUId = '$foo' GROUP BY S.Id )CS 
      
INNER JOIN 6Dates DD ON DD.DateId BETWEEN CS.Begins AND CS.Ends AND Day(DateId)='1' AND DD.DateId BETWEEN CS.FSDate AND CS.SLDate WHERE 1 ) AS CSD 

INNER JOIN 7FeeNames FN ON FN.MSID=CSD.MSID 

INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode 

INNER JOIN 31Fee FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=FN.Id And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And 
If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.Stream = FF.Stream OR FF.Stream='0') AND (CSD.MainGroup = FF.MainGroup OR FF.MainGroup='0') AND (CSD.SubGroup = FF.SubGroup OR FF.SubGroup='0') 

LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation 

LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And FN.Id=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE RSrNo='$RSrNo'  And FeeGroup='$ann1' GROUP BY RSrNo"); 
 while($dtw=mysql_fetch_array($dt)){
  $Amount1=$dtw['NetAmt']; echo  round($Amount1);   
} 
 ?>
                    &nbsp;</td>
                </tr>
                <?php }?>
                <tr>
                  <td class="bpart">Total</td>
                  <td align="right" class="bpart" ><?php   $TNetAmt;    round($TNetAmt);
				   $gdt=mysql_query($gd="SELECT MN.AcNo,MN.Id,MN.Name, MN.CClass,MN.House,MN.FatherName,MN.Village,MN.DueDate,MN.RSrNo,MN.FeeGroup,MN.FGroupId,SUM(MN.FeeAmt) NetAmt

FROM(SELECT CSD.AcNo,CSD.Id,CSD.Name,CSD.FatherName,CSD.Village,CSD.CClass,CSD.House,CSD.DueDate,CSD.SrNo,FN.Id FeeId,FN.FeeGroup,FN.FGroupId,round((If(FF.Feeid=0,COALESCE(TR.TptRate,0), FF.FeeRate))*(1-COALESCE(DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt,CSD.TptStation,CSD.Discount,FS.RSrNo ,DR.Percent

FROM (SELECT CS.AcNo,CS.Id,CS.Name,CS.FatherName,CS.Village,DD.DateId AS DueDate,If(Year(DD.DateID)=Year(CS.Begins),Month(DD.DateId)- Month(CS.Begins) +'1',Month(DD.DateId)-Month(CS.Begins)+'13') AS SrNo,CS.MSID,CS.CClass,CS.House, CS.Stream,CS.MainGroup,CS.SubGroup,CS.FPMode,CS.FSDate,CS.TptStation,CS.Discount 

FROM (SELECT U.MSID,U.Begins,U.Ends,If(P.SfeebookR='1',S.Id,S.PID) AcNo ,S.Id,S.FSDate, S.AdmClassNo+ U.MySession-Year(S.FsDate)+COALESCE(Sum(E.Result),0) CClass,S.House,S.Name,S.Stream,S.MainGroup,S.SubGroup,S.SLDate,P.FatherName,L.Village,P.FeePaymentMode AS FPMode ,SAT.TptStation,DS.Discount FROM 13Students S  INNER JOIN 7FeeUsers U ON U.MSID=S.MSID LEFT JOIN 14Exam E ON E.MSID=U.MSID AND E.DateResult< U.MyDate AND S.Id= E.S_Id INNER JOIN 12Parents P ON P.MSID=U.MSID AND P.Id=S.PID INNER JOIN 11Localities L ON L.MSID=U.MSID AND L.Village=P.Village LEFT JOIN 35SATpt SAT ON SAT.MSID=U.MSID AND SAT.S_ID=S.Id AND U.MyDate BETWEEN SAT.DateFROM AND SAT.DateTo LEFT JOIN 34DiscountedStudent DS ON DS.MSID=U.MSID AND DS.S_ID=S.Id AND U.MyDate BETWEEN DS.DateFROM AND DS.DateTo WHERE S.Id= '$s_id' AND U.MyUId = '$foo' GROUP BY S.Id )CS 
      
INNER JOIN 6Dates DD ON DD.DateId BETWEEN CS.Begins AND CS.Ends AND Day(DateId)='1' AND DD.DateId BETWEEN CS.FSDate AND CS.SLDate WHERE 1 ) AS CSD 

INNER JOIN 7FeeNames FN ON FN.MSID=CSD.MSID 

INNER JOIN 31FeeSchedule FS ON FS.MSID=CSD.MSID AND CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo AND CSD.FPMode=FS.PayMode 

INNER JOIN 31Fee FF ON FF.MSID=CSD.MSID AND CSD.DueDate BETWEEN FF.DateFrom And FF.DateTo AND FF.FeeId=FN.Id And CSD.CClass BETWEEN FF.ClassFrom And FF.ClassTo And 
If(FF.FF='1' AND CSD.DueDate=CSD.FSDate,CSD.SrNo BETWEEN FF.FFFrom AND FF.FFTo,CSD.SrNo BETWEEN FF.SrNoFrom AND FF.SrNoTo) AND (CSD.Stream = FF.Stream OR FF.Stream='0') AND (CSD.MainGroup = FF.MainGroup OR FF.MainGroup='0') AND (CSD.SubGroup = FF.SubGroup OR FF.SubGroup='0') 

LEFT JOIN 36TptRate TR ON TR.MSID=CSD.MSID AND CSD.DueDate BETWEEN TR.DateFrom AND TR.DateTo AND CSD.TptStation=TR.TptStation 

LEFT JOIN 33DiscountRule DR ON DR.MSID=CSD.MSID AND CSD.DueDate BETWEEN DR.DateFrom AND DR.DateTo AND CSD.Discount=DR.Discount And FN.Id=DR.FeeId AND CSD.CClass BETWEEN DR.ClassFrom AND DR.ClassTo AND CSD.SrNo BETWEEN DR.SrNoFrom AND DR.SrNoTo ) MN WHERE FeeGroup!='Tpt'

 And RSrNo='$RSrNo' Group By RSrNo");// $gnr=mysql_num_rows($gdt);
				   while($gdtw=mysql_fetch_array($gdt)){   $FeeName=$gdtw['FeeName'];   $Samt=$gdtw['NetAmt'];  echo round($Samt);
}/**/ ?>                    &nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Late Fee Fine</td>
                  <td align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td class="bpart">Grand Total</td>
                  <td align="right">&nbsp;</td>
                </tr>
              </table>
              <table width="280" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><table width="287" border="0" align="center">
                    <tr class="bpart">
                      <td><br>
                        Receipt No:<br></td>
                      <td align="right"><br>
                        Cashier initials</td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
        <td width="11">&nbsp;&nbsp;</td>
        </tr>
    </table>   </td>
  </tr>
</table>
</div><p class="page"></p></body><?php }}?>