<?php // print_r($oCurrentUser);?>
<script language="javascript">
    function printpage()
    {
        window.print();
    }
</script>

<table width="100%" align="center" border="1">
                                    <tr align="left" valign="top">
                                        <td width="704" height="140" align="center">
                                            <table width="100%" height="108" align="center">
                                                <tr>
                                                    <td width="87" height="102" align="left"><table width="88" border="0" align="center">
                                                            <tr>
                                                                <td width="82" height="92"><img src="<?php
                                                                    if ($oCurrentSchool->logo_img != "") {
                                                                        echo CLIENT_URL . "/uploads/10046/" . $oCurrentSchool->logo_img;
                                                                    } else {
                                                                        echo ASSETS_FOLDER . "/img/aboutlogo.jpg";
                                                                    }
                                                                    ?> " alt="" width="78" height="75" /></td>
                                                            </tr>
                                                        </table></td>
                                                    <td width="563" align="center" valign="top"><table width="100%" border="0" align="center">
                                                      <!--    <tr>
                                                          <td width="601" height="27" align="center" class="m1">&nbsp;</td>
                                                        </tr>-->
                                                            <tr>
                                                                <td width="539" height="32" align="center" class="m1"> <?= $oCurrentSchool->name; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21" align="center" class="b1"> <?php echo $oCurrentSchool->place; ?> </td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21" align="center" class="n1">Website:<?php echo $oCurrentSchool->Website?>,E-mail:<?php echo $oCurrentSchool->EMail; ?>,Ph:<?php echo $oCurrentSchool->phone; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td height="21" align="center" class="n1">Affiliated to CBSE ,Delhi ,Affiliation No.:<?php echo $oCurrentSchool->affNo; ?></td>
                                                            </tr>
                                                        </table>   