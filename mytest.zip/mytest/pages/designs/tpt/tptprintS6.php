<?php
session_start();
include("../../connect/db.php");    
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else { 
	$foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['Reconiation_no'];
$EMail= $row['EMail']; 
} ?></title>
<script language="javascript">
 function printpage()
  {
   window.print();
  }
</script>
<style type="text/css">
<!--
.z1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;font-weight: bold;
}
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.maintxt {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.hide {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #FFF;
}
-->
</style>
</head>
<body><?php       
 $ncc=$_GET['ncc'];   $school=$_GET['school']; $fail=$_GET['fail']; 
 
 $sid1=$_GET['id'];      $s_id = mysql_real_escape_string($sid1); 
 $cno1=$_GET['cno'];     $cno = mysql_real_escape_string($cno1);
 $promotion1=$_GET['promotion'];  $promotion = mysql_real_escape_string($promotion1);
 $tw1=$_GET['tw'];     $tw = mysql_real_escape_string($tw1);
 $ref1=$_GET['ref_no'];     $ref = mysql_real_escape_string($ref1);
 $school1=$_GET['school'];     $school = mysql_real_escape_string($school1);
  $failed1=$_GET['failed'];     $failed = mysql_real_escape_string($failed1);
 $feecon1=$_GET['feecon'];     $feecon = mysql_real_escape_string($feecon1);
 $subjectstd1=$_GET['subjectstd'];     $subjectstd = mysql_real_escape_string($subjectstd1);
 $high=$_GET['high']; 
 $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.*, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id INNER Join 11Localities L ON P.Village=L.Village LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid' And S.FSDate<='$Ends' AND S.SLDate>'$Ends' And S.Id='$s_id' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0) " );while($row=mysql_fetch_array($result)){  $row['Name'];
 
     $name=$row['Name'];
 $FatherName=$row['FatherName'];
  $MotherName=$row['MotherName'];
$Category=$row['Category'];
 $BirthDate=$row['BirthDate'];
$AdmissionDate=$row['AdmissionDate'];
 $CClassnum=$row['CClass'];
 $CClass=$row['ClassName'];
 $SubjectStuded=$row['SubjectStuded'];
$TcIssueDate=$row['TcIssueDate'];
$FeepaidUpto=$row['FeepaidUpto'];
$AdmissionDate=$row['AdmissionDate'];
$Attendence=$row['Attendence'];
$A_ClassNo=$row['A_ClassNo'];  
  $Category=$row['Category'];  
 

}$resl=mysql_query($slq="Select distinct `ClassName`,ClassNo from `17Class` where ClassNo='$A_ClassNo'");while( $tr = mysql_fetch_array($resl)){$acn=$tr['ClassName'];
}?>
 
<form id="contactform" name="contactform" method="post" action="">
  <table width="680" border="1" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td width="668"><table width="678" height="860" border="0" align="center">
        <?php
 
 ?>
        <tr>
          <td height="23" colspan="3" align="center" valign="baseline"><style type="text/css">
<!--
.t1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 15px;
}
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px;font-weight: bold;
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.b1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.maintxt {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.hide {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #FFF;
}
-->
</style>
   <table width="100" border="0" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td><table width="629" height="105" border="0" align="center">
        <?php 
 ?>
        <tr>
          <td width="623" height="23" colspan="3" align="center" valign="baseline"><table width="625">
            <tr>
              <td width="79" align="left"><table width="73" border="0" align="center">
                <tr>
                  <td width="67"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../../Upload/aboutlogo.jpg";} ?> " width="70" height="70" /></td>
                </tr>
                </table></td>
              <td width="534" valign="top"><table width="534" border="0" align="center">
                <tr>
                  <td width="528" align="center" class="m1"><?php echo $sname;?></td>
                </tr>
                <tr>
                  <td align="center" class="b1"><?php echo $Place; ?></td>
                </tr>
                <tr>
                  <td align="center" class="n1">Affiliation No.:<? echo $AffiliationNo;?></td>
                </tr>
              </table></td>
              <td width="10" align="right" valign="top"><!--<table width="200" border="0" align="right">
                <tr>
                  <td align="center"><img src="../Upload/phone.jpg" width="26" height="17" /></td>
                  <td align="right" class="r"><strong><?php //echo $Phone; ?></strong></td>
                </tr>
                 <tr>
              <td width="144" class="r">Affiliation No.:</td>
              <td width="46" align="right" class="r"><strong><?php //echo $AffiliationNo; ?></strong></td>
            </tr>
            <tr>
              <td class="r"> School Code :</td>
              <td align="right"><span class="r"><strong><?php //echo $SchoolNo; ?></strong></span></td>
            </tr>
            <tr>
              <td><span class="r">Recognition No.:</span></td>
              <td align="right"><strong class="r"><?php //echo $Reconiation_no; ?></strong></td>
            </tr>
              </table>--></td>
            </tr>
          </table></td>
          </tr>
         
         
      </table></td>
    </tr>
  </table>
 

</td>
          </tr>
        <tr>
          <td width="174" height="23" align="center" valign="baseline">&nbsp;</td>
          <td height="23" align="center" valign="baseline">&nbsp;</td>
          <td height="23" align="center" valign="baseline">&nbsp;</td>
        </tr>
        <tr>
          <td height="23" align="center" valign="baseline"><span class="z1">Sr.No.---<? echo $ref;?>---</span></td>
          <td width="265" height="23" align="center" valign="baseline"><span class="k1">Transfer Certificate</span></td>
          <td width="225" height="23" align="center" valign="baseline"><span class="r"><span class="z1">Admission no...<? echo $s_id;?></span></span></td>
        </tr>
        <tr>
          <td height="26" colspan="3" align="center" valign="baseline">&nbsp;</td>
        </tr>
       <? /*$resl=mysql_query($slq="Select distinct `ClassName`,ClassNo from class where ClassNo='$A_ClassNo'");while( $tr = mysql_fetch_array($resl)){$acn=$tr['ClassName'];
}*/?>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;1.&nbsp;&nbsp;&nbsp;Name of pupil......<strong><? echo $name;?></strong>.... </span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;2.&nbsp;&nbsp;&nbsp;Fathers/ Guardian's Name.....<strong><? echo 'Mr.'.' '.$FatherName;?></strong>...... </span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;3.&nbsp;&nbsp;&nbsp;Mother's Name ....<strong><? echo 'Mrs.'.' '.$MotherName;?></strong>..</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;4.&nbsp;&nbsp;&nbsp;Nationality ......<strong>Indian</strong></span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;5.&nbsp;&nbsp;&nbsp;Whether the candidate belongs to schedule cast or schedule tribe......<strong>
            <?  $reds=mysql_query($sdq="Select * from 1Category where MSID='$msid' and Id='$Category'");
 while($rwd=mysql_fetch_array($reds)){ echo $CategoryName=$rwd['CategoryName'];}  ?>
          </strong>.......</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;6.&nbsp;&nbsp;&nbsp;Date of birth (in Christian era) according to admission register.................</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="n1">(in figures)..<strong>
            <?php //echo $DateOfBirth;
		 echo $new_date = date('d-m-Y', strtotime($BirthDate)); ?>
          </strong>..(in words)..<strong>
          <?php //echo $DateOfBirth;
		  $new_date = date('d', strtotime($BirthDate));   $nm = date('F', strtotime($BirthDate)); 
		     $ny = date('Y', strtotime($BirthDate));   $rs2=mysql_query($sql2="SELECT  * from dates where DateName=$new_date");
while($row2=mysql_fetch_array($rs2)){
     $DateName=$row2['datevn'];}$rs3=mysql_query($sql3="SELECT  * from years where ID=$ny");
while($row3=mysql_fetch_array($rs3)){
     $YearName=$row3['YearName'];}
  echo $DateName.' '.$nm.' '.$YearName; 
  
  
  
  
		 
		 ?>
          </strong> .</span><span class="n1">...</span>&nbsp;</td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;7.&nbsp;&nbsp;&nbsp;Date of first admission in the school with class.....<?php  echo  $acn ;?>......<strong> ......<?php  echo $new_date1 = date('d-m-Y', strtotime($AdmissionDate)); ?>
            
          </strong>.....</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;8.&nbsp;&nbsp;&nbsp;Class in which pupil last studied (in figures)......<strong><? echo $CClass;?></strong>......(in words)...<strong><? $rsf2=mysql_query($sqlf2="SELECT  * from `17ClassNumber` where ID='$CClassnum'");   while($rowf2=mysql_fetch_array($rsf2)){
     $fn=$rowf2['FullName'];}echo $fn;?></strong>...</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;9.&nbsp;&nbsp;&nbsp;School/Board Annual examination last taken with result....<strong><? echo $school;?></strong>....</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">10.&nbsp;&nbsp;&nbsp;Whether failed if so once/twice in the same class....<strong><? echo $failed;?></strong>.....</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">11.&nbsp;&nbsp;&nbsp;Subjects studied.....<strong><? echo $subjectstd;?></strong>....</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">12.&nbsp;&nbsp;&nbsp;Whether qualified for promotion to higher class.....<strong><? echo $promotion;?></strong>....</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">13.&nbsp;&nbsp;&nbsp;Month up to which the (pupil has paid) school dues paid......<strong><?php   $FeepaidUpto ; echo $new_date2 = date('F', strtotime($FeepaidUpto));?>
            <?php  echo $new_datepp = date('Y', strtotime($FeepaidUpto)); ?></strong>........</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">14.&nbsp;&nbsp;&nbsp;Any fee concession availed of :if so the nature of such concession.....................</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">15.&nbsp;&nbsp;&nbsp;Total no.of working days......<?   echo "SELECT count(DateId) as CountOfDateId FROM `6Dates` WHERE DateId NOT IN (SELECT DateId FROM `6Dates`,28FixedHolidays FH WHERE WeekDay(DateId) BETWEEN FH.WDFrom AND FH.WDTo AND Day(DateId) BETWEEN FH.DayFrom AND FH.DayTo AND MONTH(DateId) BETWEEN FH.MonthFrom AND FH.MonthTo AND FH.MSID='$msid') AND DateId NOT IN (SELECT DateId FROM `6Dates` D,27Holidays H WHERE DateId BETWEEN H.DateFrom AND H.DateTo AND H.MSID='$msid') AND DateId BETWEEN '$TermDate' AND '$Ends'"." <br />";

		  echo "SELECT Count(26Attendances.AttDate) AS CountOfAttDate,  26Attendances.SId FROM 26Attendances WHERE   26Attendances.AttDate>'$TermDate' And 26Attendances.AttDate<='$Ends' GROUP BY 26Attendances.SId HAVING (((26Attendances.SId)=$s_id))";
$plk1=mysql_query($hjk1="SELECT count(DateId) as CountOfDateId FROM `6Dates` WHERE DateId NOT IN (SELECT DateId FROM `6Dates`,28FixedHolidays FH WHERE WeekDay(DateId) BETWEEN FH.WDFrom AND FH.WDTo AND Day(DateId) BETWEEN FH.DayFrom AND FH.DayTo AND MONTH(DateId) BETWEEN FH.MonthFrom AND FH.MonthTo AND FH.MSID='$msid') AND DateId NOT IN (SELECT DateId FROM `6Dates` D,27Holidays H WHERE DateId BETWEEN H.DateFrom AND H.DateTo AND H.MSID='$msid') AND DateId BETWEEN '$TermDate' AND '$Ends'");  	while($plkw1 = mysql_fetch_assoc($plk1)) {    $CountOfDateId1=$plkw1['CountOfDateId'];
$rst1=mysql_query($st1="SELECT Count(26Attendances.AttDate) AS CountOfAttDate,  26Attendances.SId FROM 26Attendances WHERE   26Attendances.AttDate>'$TermDate' And 26Attendances.AttDate<='$Ends' GROUP BY 26Attendances.SId HAVING (((26Attendances.SId)=$s_id))");
	  $rwt1 = mysql_fetch_row($rst1);	$absent1= $rwt1[0];  $totalwd1=$CountOfDateId1-$absent1;if($totalwd1<0){echo '0';}else {echo $totalwd1;}} ?>....................</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">16.&nbsp;&nbsp;&nbsp;Total no.of working days present.......................</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">17.&nbsp;&nbsp;&nbsp;Whether NCC Cadet/Boy Scout/Guide(Details my be given)...........</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">18.&nbsp;&nbsp;&nbsp;Games played or extra curricular activities in which the pupil usually took part<br />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(mention achievement level there in)..........</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">19.&nbsp;&nbsp;&nbsp;General conduct.........<strong>Good</strong>.......</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">20.&nbsp;&nbsp;&nbsp;Date of application for certificate................</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">21.&nbsp;&nbsp;&nbsp;Date of issue of certificate.............</span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">22.&nbsp;&nbsp;&nbsp;Reason for leaving the school...........<strong>On parent's request</strong>........ </span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">23.&nbsp;&nbsp;&nbsp;Any other remarks.................... </span></td>
        </tr>
        <tr valign="top">
          <td height="40"><div align="center"><span class="maintxt">.............. </span></div></td>
          <td height="40"><div align="center"><span class="maintxt">.............. </span></div></td>
          <td height="40"><div align="center"><span class="maintxt">.............. </span></div></td>
        </tr>
        <tr valign="top" class="z1">
          <td height="43" align="center"> Singnature of <br />
            Class teacher </td>
          <td height="43"><div align="center">Checked by<br />
            (Store full name and signature)</div></td>
          <td height="43"><div align="center">Principal's sign
            With seal </div></td>
        </tr>
      </table></td>
    </tr>
  </table>
  <br class="hide" />
<?php }?><br />
<br />
<!--<input type="button" value="Print" class="hide"   onclick="printpage();this.style.visibility = 'hidden';"   >-->
  </form>
</body>
</html>
