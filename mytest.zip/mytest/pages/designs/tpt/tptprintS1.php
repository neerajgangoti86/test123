<?php
session_start();
include("../../connect/db.php");    
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else { 
	$foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$ViewOption= $row['ViewOption'];
$EMail= $row['EMail']; 
} ?>::T C</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  />
</head>
<body> 
<form id="contactform" name="contactform" method="post" action="">
  <table width="674" background="../../images/reportlogo.png" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td width="662" height="724"><table width="647" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td height="22" colspan="3" align="center"><span class="m1"><?php echo $sname;?></span></td>
        </tr>
              <tr>
                <td width="200" align="center" valign="middle"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/1001.jpg";} ?> " width="80" height="80"/></td>
                <td width="224" align="center" valign="top"><table width="96%" height="69" border="0" align="center">
                  <tr>
                    <td width="297" height="20" align="center" ><span class="b1"><?php echo $Place; ?></span></td>
                  </tr>
                  <tr>
                    <td height="20" align="center" class="b1"><span class="t1"><?php echo $Board; ?></span></td>
                  </tr>
                  <tr>
                    <td height="21" align="center" class="t1">&nbsp;</td>
                  </tr>
                </table>
                <span class="b1"><strong><u>School Leaving Certificate </u></strong></span></td>
                <td width="201" align="right" valign="top"><table width="100%" align="right">
                  <tr>
                    <td align="center"><img src="reports/phone.jpg" width="25" height="23" /></td>
                    <td align="right" class="r"><strong><?php echo $Phone; ?></strong></td>
                  </tr>
                  <tr>
                    <td width="127" class="r">Affiliation No.:</td>
                    <td width="62" align="right" class="r"><strong><?php echo $AffiliationNo; ?></strong></td>
                  </tr>
                  <tr>
                    <td class="r"> School Code :</td>
                    <td align="right"><span class="r"><strong><?php echo $SchoolNo; ?></strong></span></td>
                  </tr>
                  <tr>
                    <td><span class="r">Recognition No.:</span></td>
                    <td align="right"><strong class="r"><?php echo $Reconiation_no; ?></strong></td>
                  </tr>
                </table></td>
          </tr>
        <?php  
 $sid1=$_GET['id'];     $s_id = mysql_real_escape_string($sid1); $cno1=$_GET['cno'];     $cno = mysql_real_escape_string($cno1);
/* $promotion1=$_GET['promotion'];     $promotion = mysql_real_escape_string($promotion1);
 $tw1=$_GET['tw'];     $tw = mysql_real_escape_string($tw1);
 $ref1=$_GET['ref_no'];     $ref = mysql_real_escape_string($ref1);
 $school1=$_GET['school'];     $school = mysql_real_escape_string($school1);
  $failed1=$_GET['failed'];     $failed = mysql_real_escape_string($failed1);
 $feecon1=$_GET['feecon'];     $feecon = mysql_real_escape_string($feecon1);
 $subjectstd1=$_GET['subjectstd'];     $subjectstd = mysql_real_escape_string($subjectstd1);
*/ 
 $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.*,O.*, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id And S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village  And P.MSID=L.MSID 
 Inner Join  `1OldStudents` O On O.SID= S.Id And O.MSID=S.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid'  And S.Id='$s_id' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0)" );while($row=mysql_fetch_array($result)){  $row['Name'];
 
     $name=$row['Name'];
	 $AdmNo=$row['AdmNo'];
  $FatherName=$row['FatherName'];
  $MotherName=$row['MotherName'];
$Category=$row['Category'];
 $BirthDate=$row['BirthDate'];
$AdmissionDate=$row['AdmissionDate'];
 $CClass=$row['ClassName'];
  $CClassnum=$row['CClass'];
 $SubjectStuded=$row['SubjectStuded'];
$TcIssueDate=$row['TcIssueDate'];
$FeepaidUpto=$row['FeepaidUpto'];
$AdmissionDate=$row['AdmDate'];
$Attendence=$row['Attendence'];
$A_ClassNo=$row['AdmClassNo'];
$SubjectSTD=$row['SubjectSTD']; 
$TotalWdays=$row['TotalWdays']; 
$Attendance=$row['Attendance'];
 $LastResult=$row['LastResult'];
 $RollNo=$row['RollNo']; 
$Mraks_obtained=$row['Mraks_obtained'];
 $Promotion=$row['Promotion'];
  $Feeconcession=$row['Feeconcession'];
  $Ref=$row['Ref']; 
   
  $Note=$row['Note']; 
 

}$resl=mysql_query($slq="Select distinct `ClassName`,ClassNo from `17Class` where ClassNo='$A_ClassNo' And `MSID`='$msid'");while( $tr = mysql_fetch_array($resl)){$acn=$tr['ClassName'];
}?>
        <tr>
          <td width="200" height="20" align="left" valign="baseline"><span class="n1">Reg.No.<strong><?php echo $Ref; ?></strong></span></td>
          <td width="224" height="23" align="center" valign="baseline">&nbsp;</td>
          <td width="201" height="23" align="left" valign="baseline"><span class="st4">Admission no...<strong><?php  if($ViewOption=='0'){echo $s_id;}else {echo $AdmNo;}?></strong></span></td>
        </tr>
        
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">&nbsp;1.&nbsp;&nbsp;&nbsp;Name of the pupil:&nbsp;&nbsp;&nbsp; <strong><?php echo  $name;?></strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">&nbsp;2.&nbsp;&nbsp;&nbsp;Father's/ Guardian's Name:&nbsp;&nbsp;&nbsp; <strong>
           <?php  echo 'Mr.'.$FatherName;?>
          </strong> </span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">&nbsp;3.&nbsp;&nbsp;&nbsp;Mother's Name:&nbsp;&nbsp;&nbsp; <strong><?php  echo 'Mrs.'.$MotherName;?>
          </strong></span></td>
        </tr>
        <tr valign="top">
          <td height="20" colspan="3"><span class="n1">&nbsp;4.&nbsp;&nbsp;&nbsp;Nationality:&nbsp;&nbsp;&nbsp; <strong> Indian</strong></span></td>
        </tr>
        <tr valign="top">
          <td height="24"><span class="n1">&nbsp;5.&nbsp;&nbsp;&nbsp;Category:&nbsp;&nbsp;&nbsp;</span></td>
          <td height="24" colspan="2"><span class="n1"><strong><?php $rs2=mysql_query($sql2="SELECT * FROM `1Category` WHERE `MSID`='$msid' and `Id`='$Category'");
while($row2=mysql_fetch_array($rs2)){ echo $row2['CategoryName']; }?></strong></span></td>
        </tr>
        
        
        
        
       <!-- <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;5.&nbsp;&nbsp;&nbsp;Date of birth (in Christian era) according to admission register (in words)......<strong><?php //echo $DateOfBirth;
		 //echo $new_date = date('d-m-Y', strtotime($DateOfBirth)); ?></strong>...........</span></td>
        </tr>-->
        
         <tr valign="top">
           <td height="21" colspan="3"><span class="n1">&nbsp;6.&nbsp;&nbsp;&nbsp;Date of birth (in Christian era) according to Admission Register.................</span></td>
         </tr>
         <tr valign="top">
           <td height="23" colspan="3"><span class="n1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="n1">(in figures)..<strong>
             <?php //echo $DateOfBirth;
		 echo $new_date = date('d-m-Y', strtotime($BirthDate)); ?>
             </strong>..(in words)..<strong>
               <?php //echo $DateOfBirth;
		  $new_date = date('d', strtotime($BirthDate));   $nm = date('F', strtotime($BirthDate)); 
		     $ny = date('Y', strtotime($BirthDate));   $rs2=mysql_query($sql2="SELECT  * from dates where DateName=$new_date");
while($row2=mysql_fetch_array($rs2)){
     $DateName=$row2['datevn'];}$rs3=mysql_query($sql3="SELECT  * from years where ID=$ny");
while($row3=mysql_fetch_array($rs3)){
     $YearName=$row3['YearName'];}
  echo $DateName.' '.$nm.' '.$YearName; 
  
  
  
  
		 
		 ?>
             </strong> .</span><span class="n1">.</span></td>
         </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">&nbsp;7.&nbsp;&nbsp;&nbsp;Date of first Admission in the school:&nbsp;&nbsp;&nbsp; <strong> 
		  <?php    //echo  $acn ;?></strong>
		  ....
           <strong> <?php  echo $new_date1 = date('d-m-Y', strtotime($AdmissionDate)); ?>
          </strong></span></td>
        </tr>
        <tr valign="top">
          <td height="26" colspan="3"><span class="n1">&nbsp;8.&nbsp;&nbsp;&nbsp;Class in which pupil last studied (in figures)&nbsp;&nbsp;&nbsp;<strong><? $ccl=mysql_query ($scl="SELECT * FROM `17Class` WHERE `MSID`='$msid' And `ClassNo`='$cno'"); while($row5=mysql_fetch_array($ccl)){ echo $cnn= $row5['ClassName'] ; }//echo $CClass;?></strong>......(in words)...<strong><? $rsf2=mysql_query($sqlf2="SELECT  * from `17ClassNumber` where ID='$cno'");   while($rowf2=mysql_fetch_array($rsf2)){
     $fn=$rowf2['FullName'];}echo $fn;?></strong>...</span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">&nbsp;9.&nbsp;&nbsp;&nbsp;Details of last class attended: Result..<strong><? echo  $LastResult;?></strong> ...<!--Roll No-->..<strong><? //echo $RollNo;?></strong>..<!--Marks Obtained-->..<strong><? //echo $Mraks_obtained;?></strong></span>..</td>
        </tr>
        <!--<tr valign="top">
          <td height="22" colspan="3"><span class="n1">10.&nbsp;&nbsp;&nbsp;Whether failed if so once/twice in the same class:&nbsp;&nbsp;&nbsp; <strong><?php //echo $failed=$_GET['failed']; ?></strong></span></td>
        </tr>-->
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">10.&nbsp;&nbsp;&nbsp;Subject studied: <strong><?php echo $SubjectSTD ;?></strong></span></td>
        </tr>
        <tr valign="top">
          <td height="24" colspan="3"><span class="n1">11.&nbsp;&nbsp;&nbsp;Whether qualified for promotion to the higher class:&nbsp;&nbsp;&nbsp;<strong><?php echo $Promotion; ?></strong></span></td>
        </tr>
        <tr valign="top">
          <td height="23" colspan="3"><span class="n1">12.&nbsp;&nbsp;&nbsp;Month up to which the pupil has paid school dues:&nbsp;&nbsp;&nbsp; <strong>
 <?php   $FeepaidUpto ; echo $new_date2 = date('F', strtotime($FeepaidUpto));?>
   <?php  echo $new_datepp = date('Y', strtotime($FeepaidUpto)); ?></strong> </span></td>
        </tr>
        <tr valign="top">
          <td height="24" colspan="3"><span class="n1">13.&nbsp;&nbsp;&nbsp;Any fee concession availed:&nbsp;&nbsp;&nbsp;<strong><?php if($Feeconcession!='0') {echo $Feeconcession ;} else{}?></strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">14.&nbsp;&nbsp;&nbsp;Total No. of working days:&nbsp;&nbsp;&nbsp;<strong>
            <?php  echo $TotalWdays ; ?>
          </strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">15.&nbsp;&nbsp;&nbsp;Total No. of Attendance:&nbsp;&nbsp;&nbsp;<strong>
            <?php 

 
echo $Attendance;  ?>
          </strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">16.&nbsp;&nbsp;&nbsp;</span><span class="n1">Date of application for certificate:&nbsp;&nbsp;&nbsp; <strong>
            <?php  //echo $TcIssueDate ; ?>
            <?php echo $new_date3 = date('d-m-Y', strtotime($TcIssueDate)); ?> </strong></span></td>
        </tr>
        <tr valign="top">
          <td height="22" colspan="3"><span class="n1">17.&nbsp;&nbsp;&nbsp;Date of issue of certificate:&nbsp;&nbsp;&nbsp; <strong>
          <?php // echo $TcIssueDate ; ?>
          <?php echo $new_date4 = date('d-m-Y', strtotime($TcIssueDate)); ?></strong></span></td>
        </tr>
        <tr valign="top">
          <td height="20" colspan="3"><span class="n1">18.&nbsp;&nbsp;&nbsp;Reason for leaving the school: <strong>On parent's request</strong></span></td>
        </tr>
      <!--  <tr valign="top">
          <td height="22" colspan="3"><span class="n1">20.&nbsp;&nbsp;&nbsp;<strong>This is to certify that <?php //echo  $name;?> bears a good moral character.</strong></span></td>
        </tr>-->
        <tr valign="top">
          <td height="20" colspan="3"><span class="n1">19.&nbsp;&nbsp;&nbsp;Any other remarks:<strong><?php  echo $Note ; ?></strong> </span></td>
        </tr>
        <tr valign="top">
          <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
          <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
          <td height="16"><div align="center"><span class="maintxt">.............. </span></div></td>
        </tr>
        <tr valign="top" >
          <td height="20" align="left" class="st4">Prepaired by(Name and Signature)</td>
          <td height="20" align="left" class="st4">Checked by
          (Name and Signature)</td>
          <td height="20"><div align="center"><span class="st4">Principal's sign
            With seal </span></div></td>
        </tr>
      </table></td> 
    </tr>
  </table>
  </body>
</html>
<? }?>