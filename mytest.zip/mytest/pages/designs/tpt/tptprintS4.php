<?php
session_start();
include("../../connect/db.php");    
    $msid=$_SESSION['msid'] ;
 if (!isset($_SESSION['admin'])){
 header("location:../../index.php");
}else { 
	$foo =$_SESSION['admin']; 
$k=mysql_query($kl="select * from `91Users` where `MyUId`='$foo' And `MSID`='$msid'"); while($kr=mysql_fetch_array($k)){ 
    $n= $kr['MyUName']; 
$dm= $kr['MyDate']; 
$session= $kr['MySession'];
$Begins= $kr['Begins'];     
$Ends= $kr['Ends'];        
$ULevel= $kr['ULevel']; } ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php  $d=mysql_query($sql="select * from `10Company` where MSID='$msid'"); while($row=mysql_fetch_array($d)){	
echo $sname= $row['Name'];
 $limg= $row['LogoImage'];
$Board= $row['Board'];
$Place= $row['Place'];
$Transport= $row['Transport'];
$Arts= $row['Arts'];
$Commerce= $row['Commerce'];
$nos= $row['Section'];
$Phone= $row['Phone'];
$Hostel= $row['Hostel'];
$noh= $row['House'];
$nos= $row['Section'];
$ClassTo= $row['ClassTo']; 
$SMS= $row['SMS']; 
$AffiliationNo= $row['AffNo'];
$SchoolNo= $row['SchoolNo'];
$Reconiation_no= $row['RecNo'];
$EMail= $row['EMail']; $ViewOption= $row['ViewOption'];
} ?>::T C</title><link rel="stylesheet" type="text/css"  href="../../css/report.css"  /><style type="text/css">
<!--
.z1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;font-weight: bold;
}
.m1 {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 28px;font-weight: bold;
}
.n1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; 
}
.k1 {
	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 20px;
}
.r {font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.maintxt {
	font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
}
.hide {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #FFF;
}
--> 
</style>

</head>
<body> 
</head>
<body>
<form id="contactform" name="contactform" method="post" action="">
  <table width="200" border="1" align="center" cellpadding="2" cellspacing="2">
    <tr>
      <td><table width="736" height="861" border="0" align="center">
        
        <tr>
          <td height="23" colspan="3" align="center" valign="baseline">
            <table width="727" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td width="719"> <table width="719" height="105" border="0" align="center">
                  <tr>
                    <td width="713" height="23" colspan="3" align="center" valign="baseline"><table width="716">
                      <tr>
                        <td colspan="3" align="center"><span class="m1"><?php echo $sname;?></span></td>
                        </tr>
                      <tr>
                        <td width="103" height="97" align="left"><table width="103" border="0" align="center">
                          <tr>
                            <td width="97"><img src="<?php  if($limg!=""){echo $limg;} else { 	echo "../Upload/1001.jpg";} ?> " width="80" height="80"/></td>
                            </tr>
                          </table></td>
                        <td width="401" valign="top"><table width="391" border="0" align="center">
                          <tr>
                            <td width="385" align="center" ><span class="b1"><?php echo $Place; ?></span></td>
                            </tr>
                          <tr>
                            <td align="center" class="b1"><span class="t1"><?php echo $Board; ?></span></td>
                            </tr>
                          <tr>
                            <td align="center" class="t1">&nbsp;</td>
                            </tr>
                          </table></td>
                        <td width="200" align="right" valign="top"><table width="200" border="0" align="right">
                          <tr>
                            <td align="center"><img src="reports/phone.jpg" width="25" height="23" /></td>
                            <td align="right" class="r"><strong><?php echo $Phone; ?></strong></td>
                            </tr>
                          <tr>
                            <td width="144" class="r">Affiliation No.:</td>
                            <td width="46" align="right" class="r"><strong><?php echo $AffiliationNo; ?></strong></td>
                            </tr>
                          <tr>
                            <td class="r"> School Code :</td>
                            <td align="right"><span class="r"><strong><?php echo $SchoolNo; ?></strong></span></td>
                            </tr>
                          <tr>
                            <td><span class="r">Recognition No.:</span></td>
                            <td align="right"><strong class="r"><?php echo $Reconiation_no; ?></strong></td>
                            </tr>
                          </table></td>  </tr>
                      </table></td>
                    </tr>
                  
                  
                  </table></td>
                </tr>
              </table>
            
            
  </td>
        </tr>
          <? $sid1=$_GET['id']; $s_id = mysql_real_escape_string($sid1); $cno1=$_GET['cno']; $cno= mysql_real_escape_string($cno1); 
 $result=mysql_query($sql="SELECT (S.Id) as sid,S.*,P.*,L.*,O.*, S.`AdmClassNo`+'$session'-Year(S.`FSDate`)+ COALESCE(SumResult,0) AS CClass FROM 13Students S INNER JOIN 12Parents P ON S.PID=P.Id And S.MSID=P.MSID INNER Join 11Localities L ON P.Village=L.Village  And P.MSID=L.MSID 
 Inner Join  `1OldStudents` O On O.SID= S.Id And O.MSID=S.MSID  LEFT JOIN (SELECT E.S_Id, Sum(E.Result) AS SumResult FROM 14Exam E WHERE (((E.MSID)='$msid') AND ((E.DateResult)<'$Begins')) GROUP BY E.S_Id ) AS Q1 ON S.Id = Q1.S_Id WHERE S.MSID='$msid'  And S.Id='$s_id' And P.MSID='$msid' GROUP BY S.Id, COALESCE(SumResult,0)" );while($row=mysql_fetch_array($result)){  $row['Name'];
 
 $AdmNo=$row['AdmNo']; $id=$row['sid'];
	      $name=$row['Name'];
  $FatherName=$row['FatherName'];
  $MotherName=$row['MotherName'];
$Category=$row['Category'];
 $BirthDate=$row['BirthDate'];
$AdmissionDate=$row['AdmissionDate'];
 $CClass=$row['ClassName'];
  $CClassnum=$row['CClass'];
 $SubjectStuded=$row['SubjectStuded'];
$TcIssueDate=$row['TcIssueDate'];
$FeepaidUpto=$row['FeepaidUpto'];
$AdmissionDate=$row['AdmDate'];
$Attendence=$row['Attendence'];
$A_ClassNo=$row['AdmClassNo'];
$SubjectSTD=$row['SubjectSTD']; 
$TotalWdays=$row['TotalWdays']; 
$Attendance=$row['Attendance'];
 $LastResult=$row['LastResult'];
 $RollNo=$row['RollNo']; 
$Mraks_obtained=$row['Mraks_obtained'];
 $Promotion=$row['Promotion'];
  $Feeconcession=$row['Feeconcession'];
  $Ref=$row['Ref']; 
    $Note=$row['Note'];
	    $failed=$row['failed']; 
  
   $NCC=$row['NCC'];
 $Gamesplayed=$row['Gamesplayed']; 
$General_conduct=$row['General_conduct'];
 $Reason=$row['Reason'];
  $Bookno=$row['Bookno'];
  $Srno=$row['Srno'];  
 
 

}$resl=mysql_query($slq="Select distinct `ClassName`,ClassNo from `17Class` where ClassNo='$A_ClassNo' And `MSID`='$msid'");while( $tr = mysql_fetch_array($resl)){$acn=$tr['ClassName'];
}?><tr>
          <td width="171" height="28" align="center" valign="baseline"><span class="z1">Sr.No.--<?php echo $Ref;?>---</span></td>
          <td width="395" height="28" align="center" valign="baseline"><span class="k1">School Leaving Certificate </span></td>
          <td width="156" height="28" align="center" valign="baseline"><span class="r"><span class="z1">Admission no...<?php 
   //if($ViewOption=='0'){echo $id;}else {echo $AdmNo;} 
		  
		  $cno=$_GET['cno']; if($cno>10){ echo $AdmNo;} else{ echo  $id;}?></span></span></td>
        </tr>
      
        <tr valign="top">
          <td height="582" colspan="3">
            <table width="100%">
              <tr>
                <td width="5%" height="24"><span class="n1">&nbsp;1.&nbsp;</span></td>
                <td width="95%" style="text-transform:capitalize;"><span class="n1">Name of pupil......<strong><span style="text-transform:capitalize;"><?php echo  $name;?></span></strong>.... </span></td>
              </tr>
              <tr>
                <td height="21"><span class="n1"> &nbsp;2.&nbsp;</span></td>
                <td><span class="n1">Father's/ Guardian's Name....<strong>Mr.
                      <?php  echo  $FatherName;?>
                </strong>....... </span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">&nbsp;3.&nbsp;</span></td>
                <td><span class="n1">Mother's Name ...<strong>Mrs.
<?php  echo  $MotherName;?>
                </strong>....... </span></td>
              </tr>
              <tr>
                <td height="18"><span class="n1">&nbsp;4.</span></td>
                <td><span class="n1">Nationality ......<strong>Indian</strong></span></td>
              </tr>
              <tr>
                <td height="21"><span class="n1">&nbsp;5.</span></td>
                <td><span class="n1">Whether the candidate belongs to schedule cast or schedule tribe.....<strong><?php $rs2=mysql_query($sql2="SELECT * FROM `1Category` WHERE `MSID`='$msid' and `Id`='$Category'");
while($row2=mysql_fetch_array($rs2)){ echo $row2['CategoryName']; }?></strong>........</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">&nbsp;6.</span></td>
                <td><span class="n1">Date of birth (in Christian era) according to admission register (in figures)......<strong>
                <?php //echo $DateOfBirth;
		 echo $new_date = date('d-m-Y', strtotime($BirthDate)); ?>
                </strong>...........</span></td>
              </tr>
              <tr>
                <td height="21">&nbsp;</td>
                <td><span class="n1">(in words)......<strong>
                <?php //echo $DateOfBirth;
	 $new_date = date('d', strtotime($BirthDate));   $nm = date('F', strtotime($BirthDate)); 
		     $ny = date('Y', strtotime($BirthDate));   $rs2=mysql_query($sql2="SELECT  * from dates where DateName=$new_date");
while($row2=mysql_fetch_array($rs2)){
     $DateName=$row2['datevn'];}$rs3=mysql_query($sql3="SELECT  * from years where ID=$ny");
while($row3=mysql_fetch_array($rs3)){
     $YearName=$row3['YearName'];}
  echo $DateName.' '.$nm.' '.$YearName; 
  
  
  
  
		 
		 ?>
                </strong>...........</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">&nbsp;7.</span></td>
                <td><span class="n1">Date of admission in  school...........<strong>
                <?php //echo  $AdmissionDate ;?>
                <?php  echo $new_date1 = date('d-m-Y', strtotime($AdmissionDate)); ?>
                </strong>.....</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">&nbsp;8.</span></td>
                <td><span class="n1">Class in which student was admitted in  school...........<strong>
                <?php     $acn ;
	  $rsf2334=mysql_query($sqlf2333="SELECT  * from `17ClassName` WHERE `MSID`='$msid' And `ClassNo`='$A_ClassNo'");
while($rowf2334=mysql_fetch_array($rsf2334)){  
     $wfclas334=$rowf2334['ClassFullName']; $ClassName12= $rowf2334['ClassName']; } echo $ClassName12; ?>
                </strong>.....</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">&nbsp;9.</span></td>
                <td><span class="n1">Class in which student Passed (in figure)..........<strong><? $clname=$CClassnum-1;$ccl=mysql_query ($scl="SELECT * FROM `17Class` WHERE `MSID`='$msid' And `ClassNo`='$clname'"); while($row5=mysql_fetch_array($ccl)){ echo $cnn= $row5['ClassName'] ; }//echo $CClass;?></strong>..(in words)......<strong>
                
           <? $cclss=mysql_query ($sclss="SELECT * FROM `17ClassName` WHERE `MSID`='$msid' And `ClassNo`='$clname'"); while($row5ss=mysql_fetch_array($cclss)){ echo $cnnss= $row5ss['ClassFullName'] ; }?>
           
                </strong></span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">10.</span></td>
                <td><span class="n1">School/board Annual examination last taken with result...<strong><? echo  $LastResult;?></strong>....</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">11.</span></td>
                <td><span class="n1">Whether failed if so once/twice in the same class....<strong><?php echo $failed; ?></strong>.....</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">12.</span></td>
                <td><span class="n1">Subject studied...........<strong><?php echo $SubjectSTD ;?></strong>.....</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">13.&nbsp;</span></td>
                <td><span class="n1">Whether qualified for promotion to the higher class :...<strong><?php echo $Promotion; ?></strong>.. In Class......<strong><?php $cclss=mysql_query ($sclss="SELECT * FROM `17Class` WHERE `MSID`='$msid' And `ClassNo`='$CClassnum'"); while($row5ss=mysql_fetch_array($cclss)){ echo $cnnss= $row5ss['ClassName'] ;  }?></strong>.......</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">14.</span></td>
                <td><span class="n1">Date up to which the pupil has paid school dues.......... <strong><?php   $FeepaidUpto ; echo $new_date2 = date('F', strtotime($FeepaidUpto));?>
   <?php  echo $new_datepp = date('Y', strtotime($FeepaidUpto)); ?>
....</strong></span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">15.</span></td>
                <td><span class="n1">Any fee concession availed of :if so the nature of such concession........<strong><?php if($Feeconcession!='0') {echo $Feeconcession ;} else{}?></strong>.............</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">16.</span></td>
                <td><span class="n1">Total no.of working days..........<strong><?php  echo $TotalWdays ; ?></strong>.............</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">17.</span></td>
                <td><span class="n1">Total no.of working days present........<strong>
                   <?php echo $Attendance;  ?>
                </strong>...............</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">18.</span></td>
                <td><span class="n1">Whether NCC cader/Boy Scout/Guide(Details may be given).....  <strong><?php echo $NCC ; ?></strong>.......</span></td>
              </tr>
              <tr>
                <td height="39"><span class="n1">19.</span></td>
                <td><span class="n1">Games played or extra curricular activities in which the pupil usually took part (mention achievement level there in)..... <strong><?php  echo $Gamesplayed ; ?></strong>.....</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">20.</span></td>
                <td><span class="n1">General conduct.........<strong><?php  echo $General_conduct ; ?></strong>.......</span></td>
              </tr>
               <tr>
                <td height="22"><span class="n1">21.</span></td>
                <td><span class="n1"><span class="n1">Date of application for certificate........<strong>
              <?php echo $new_date4 = date('d-m-Y', strtotime($TcIssueDate)); ?>
                </strong>........</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">22.</span></td>
                <td><span class="n1">Date of issue of certificate..........<strong>
                 <?php echo $new_date3 = date('d-m-Y', strtotime($TcIssueDate)); ?>
                </strong>...</span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">23.</span></td>
                <td><span class="n1">Reason for leaving the school...........<strong><?php  echo $Reason ; ?></strong>........ </span></td>
              </tr>
              <tr>
                <td height="20"><span class="n1">24.</span></td>
                <td><span class="n1">Any other remarks..........<strong><?php  echo $Note ; ?></strong>........... </span></td>
              </tr>
            </table></td>
        </tr>
      
        <tr valign="bottom">
          <td height="54"><div align="center"><span class="maintxt">.............. </span></div></td>
          <td height="54"><div align="center"><span class="maintxt">.............. </span></div></td>
          <td height="54"><div align="center"><span class="maintxt">.............. </span></div></td>
        </tr>
        <tr valign="top" class="z1">
          <td height="43" align="center"> Signature of <br />
            Class teacher </td>
          <td height="43"><div align="center">Checked by<br />
            (Store full name and signature)</div></td>
          <td height="43"><div align="center">Principal's sign
            With seal </div></td>
        </tr>
      </table></td>
    </tr>
  </table>
  <br class="hide" />

<br />
<!--<input type="button" value="Print" class="hide"   onclick="printpage();this.style.visibility = 'hidden';"   >-->
  </form>
</body>
</html>
<? }?>