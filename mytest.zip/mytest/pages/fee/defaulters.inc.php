<!-- Main content -->
<?php // print_r($oCurrentSchool) ;?> 
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $totalbal = 0;
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box box-primary">
                <div class="box-header">
                    <div class="row"><div class='col-md-4'> <h3 class="box-title"> <?php
//                                print_r($class) ;
                                if ($type == "defaulters" || $type == "all")
                                    echo "Fee Defaulters";
                                elseif ($type == "advancepayer")
                                    echo "Advanve Payer";
                                elseif ($type == "perfact_payer") {
                                    echo "Balanced Payer";
                                }

                                if ($class == "all")
                                    echo " of All Classes";
                                else
                                    echo " of ", $class;
                                ?></h3></div>
                        <div class='col-md-4'>

                            <ul class="nav nav-pills">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                                    <ul class="dropdown-menu">
                                        <li><a  href="javascript:void(0);" title="Export to Excel" onclick="$('#fee_reports').tableExport({type: 'excel', escape: 'false'});"><img src="<?= ASSETS_FOLDER ?>/img/excel.png" title="export to excel" width="30" height="30"/></a></li>
                                        <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                                            </a></li>
                                        <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                                        </li>

                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class='col-md-4'>

                            <form class="form-inline right_ft column_hide_show" method="post">
                                <div class="btn-group">
                                    <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                        Select Columns 
                                        <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu"  aria-labelledby="dropdownMenu1">
                                        <?php
                                        foreach ($students_array as $key => $val) {
                                            if (in_array($key, @$selected_columns_students)) {
                                                $checked = "checked ='checked'";
                                            } else {
                                                $checked = "";
                                            };
                                            ?>
                                            <li>
                                                <input type="checkbox" value="<?= $key ?>"  name="column1[]" <?= $checked ?>><?= $val ?>
                                            </li> 
                                        <?php } ?>
                                        <li><button type="submit" name="columnsubmit" class="btn btn-block btn-sm btn-warning btn-flat">Submit</button></li>
                                    </ul>
                                </div>
                            </form>
                            <div class="btn-group">
                                <a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL . '/sms/feepayer/' . $type . '/' . $class . '' ?>"> Send SMS</a>
                            </div>

                        </div>

                    </div>

                    <form class="form-inline " method="post">
                        <div class="row">
                            <div class='col-md-12'> 

                                <input type="hidden" name="report_card_form" value="xxx" />
                                <div class="row">
                                    <div class="col-md-4"> 
                                        <label for="exampleInputName2">Type : </label>
                                        <select id="type" name="type" class="form-control wth_div"  onchange='this.form.submit()' >


                                            <option value="defaulters" <?php echo ($type == "all" || $type == "defaulters") ? 'selected = "selected"' : ''; ?> >Fee Defaulters</option>    
                                            <option value="advancepayer" <?php echo ($type == "advancepayer") ? 'selected = "selected"' : ''; ?> >Advanve Payer</option>  
                                            <option value="perfact_payer" <?php echo ($type == "perfact_payer") ? 'selected = "selected"' : ''; ?> >Balanced Payer</option>

                                        </select> 
                                    </div> 
                                    <div class="col-md-4"><label for="exampleInputName2">Select Class : </label>
                                        <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >


                                            <?php
                                            if ($class == "all") {
                                                ?>   <option value="all" selected="selected">Select Class</option>
                                                <?php
                                            } else {
                                                ?><option value="all">Select Class</option>
                                                <?php
                                            }
                                            $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                            ?>
                                            <?php
                                            foreach ($classs as $class) {
                                                if ($class_no == $class['class_no'] && $class_no != Null) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>
                                                <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                    <?= $class['class_name']; ?>
                                                </option>
                                            <?php }
                                            ?>
                                        </select>

                                    </div>

                                </div>      
                            </div> 

                        </div></form>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding" id="fee_reports">
                        <?php
                        if (@$totalrecords > 0) {
                            ?>
                            <table class="table table-hover tablesorter" id="fee_reports">
                                <thead style="background:#ddd;">
                                    <tr>
                                        <th><a href="">Sr.No.</a></th>
                                        <?php
                                        if (!@$selected_columns_students) {
                                            ?>
                                            <th><a href="javascript(0);">SID</a></th>
                                            <th><a href="javascript(0);">&nbsp;</a></th>
                                            <th><a href="javascript(0);">Student Name</a></th>
                                            <th><a href="javascript(0);">Father Name</a></th>
                                            <th><a href="javascript(0);">Class</a></th>
                                            <?php
                                            $classsections = Master::get_schools_section($MSID);
                                            if ($classsections->rowCount() > 1) {
                                                ?><th><a href="javascript(0);">Section</a></th>
                                                <?php } ?>
                                            <th><a href="javascript(0);">Village</a></th>
                                            <th><a href="javascript(0);">Amount</a></th>
                                            <th><a href="javascript(0);">Amount Recived</a></th>
                                            <th><a href="javascript(0);">Late Fee</a></th>
                                            <th><a href="javascript(0);">Balance</a></th>
                                            <th><a href="javascript(0);">Sms Mobile NO</a></th>

                                            <?php
                                        } else {
                                            ?>
                                            <?php
                                            if (in_array('SID', $selected_columns_students)) {
                                                ?><th><a href="javascript(0);">SId</a></th><?php } ?>
                                            <th><a href="javascript(0);">&nbsp;</a></th>
                                            <?php
                                            if (in_array('StudentName', $selected_columns_students)) {
                                                ?><th><a href="javascript(0);">Student Name</a></th><?php } ?>
                                            <th><a href="javascript(0);">&nbsp;</a></th>
                                            <?php
                                            if (in_array('FatherName', $selected_columns_students)) {
                                                ?><th><a href="javascript(0);">Father Name</a></th><?php } ?>
                                                <?php
                                                if (in_array('Class', $selected_columns_students)) {
                                                    ?><th><a href="javascript(0);">Class</a></th><?php } ?>
                                                <?php
                                                $classsections = Master::get_schools_section($MSID);
                                                if ($classsections->rowCount() > 1) {
                                                    ?>    <?php
                                                    if (in_array('section', $selected_columns_students)) {
                                                        ?><th><a href="javascript(0);">section</a></th><?php
                                                    }
                                                }
                                                ?>
                                                <?php
                                                if (in_array('Village', $selected_columns_students)) {
                                                    ?><th><a href="javascript(0);">Village</a></th><?php } ?>
                                                <?php
                                                if (in_array('Amt', $selected_columns_students)) {
                                                    ?><th><a href="javascript(0);">Amount</a></th><?php } ?>
                                                <?php
                                                if (in_array('RdAmt', $selected_columns_students)) {
                                                    ?><th><a href="javascript(0);">Amount Recived</a></th><?php } ?>
                                                <?php
                                                if (in_array('LateFee', $selected_columns_students)) {
                                                    ?><th><a href="javascript(0);">Late Fee</a></th><?php } ?>
                                                <?php
                                                if (in_array('Bal', $selected_columns_students)) {
                                                    ?><th><a href="javascript(0);">Balance</a></th><?php } ?>
                                                <?php
                                                if (in_array('MobileSMS', $selected_columns_students)) {
                                                    ?><th><a href="javascript(0);">Sms Mobile NO</a></th><?php } ?>

                                        <?php } ?>
                                        <td>Action</td>
                                    </tr>
                                </thead>
                                <?php
                                $i = 1;
//                                    print_r($students);
                                while ($rowv = $students->fetch(PDO::FETCH_ASSOC)) {
                                    $secion = Master::get_sections($MSID, $rowv['section'])->fetch(PDO::FETCH_OBJ);
                                    $student = Student::get_students($oCurrentUser->myuid, '', $rowv['SID'])->fetch(PDO::FETCH_OBJ);
//                                     pr($student->sec_name);
//                                    exit();
                                    ?>
                                    <tr>
                                        <td><?= $i ?></td>
                                        <?php
                                        if (!@$selected_columns_students) {
                                            ?>
                                            <td><?= $rowv['SID']; ?></td>
                                            <td><?= $rowv['StudentName']; ?></td>
                                            <td><?= $rowv['FatherName']; ?></td>
                                            <td><?= $rowv['class']; ?></td>
                                            <?php
                                            $classsections = Master::get_schools_section($MSID);
                                            if ($classsections->rowCount() > 1) {
                                                ?><td><?php echo $student->sec_name; ?></td>  <?php } ?>           
                                            <td><?= $rowv['Village']; ?></td>
                                            <td><?php echo round($rowv['Amt']); ?></td>
                                            <td><?php echo round($rowv['RdAmt']); ?></td>
                                            <td><?= $rowv['LateFee']; ?></td>
                                            <td><?= $rowv['Bal']; ?></td>
                                            <td><?= $rowv['MobileSMS']; ?></td>
                                            <?php
                                        } else {
                                            ?> 
                                            <?php
                                            if (in_array('SID', $selected_columns_students)) {
                                                ?><td><?= $rowv['SID']; ?></td><?php } ?>
                                            <td>&nbsp;</td>
                                            <?php
                                            if (in_array('StudentName', $selected_columns_students)) {
                                                ?> <td><?= $rowv['StudentName']; ?></td><?php } ?>
                                            <td><a href="javascript(0);">&nbsp;</a></td>
                                            <?php
                                            if (in_array('FatherName', $selected_columns_students)) {
                                                ?><td><?= $rowv['FatherName']; ?></td><?php } ?>
                                            <?php
                                            if (in_array('Class', $selected_columns_students)) {
                                                ?> <td><?= $rowv['Class']; ?></td><?php } ?>
                                            <?php
                                            $classsections = Master::get_schools_section($MSID);
                                            if ($classsections->rowCount() > 1) {
                                                ?>       <?php
                                                if (in_array('section', $selected_columns_students)) {
                                                    ?> <td><?php echo $student->sec_name; ?></td><?php
                                                }
                                            }
                                            ?>
                                            <?php
                                            if (in_array('Village', $selected_columns_students)) {
                                                ?><td><?= $rowv['Village']; ?></td><?php } ?>
                                            <?php
                                            if (in_array('Amt', $selected_columns_students)) {
                                                ?><td><?php echo round($rowv['Amt']); ?></td><?php } ?>
                                            <?php
                                            if (in_array('RdAmt', $selected_columns_students)) {
                                                ?><td><?php echo round($rowv['RdAmt']); ?></td><?php } ?>
                                            <?php
                                            if (in_array('LateFee', $selected_columns_students)) {
                                                ?><td><?= $rowv['LateFee']; ?></td><?php } ?>
                                            <?php
                                            if (in_array('Bal', $selected_columns_students)) {
                                                ?><td><?php echo round($rowv['Bal']);
                                $totalbal+= round($rowv['Bal']);
                                                ?></td><?php } ?>
                                            <?php
                                                if (in_array('MobileSMS', $selected_columns_students)) {
                                                    ?><td><?= $rowv['MobileSMS']; ?></td><?php } ?>
        <?php } ?>     <th><a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $rowv['SID']; ?>" data-ms="modal" data-title="Student Profile">View</a></th>


                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </table>
                            <table width="100%"><tr><td align="right"><h4>Total Amount Of <?php
                                            if ($type == "defaulters" || $type == "all")
                                                echo "Fee Defaulters";
                                            elseif ($type == "advancepayer")
                                                echo "Advanve Payer";
                                            elseif ($type == "perfact_payer") {
                                                echo "Balanced Payer";
                                            }
                                            ?></h4></td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> <td><strong><?php echo money_format('%n', $totalbal); ?> </strong>  </td><td width="8%"></td></tr></table>
                            <?php
                        } else {
                            echo '<div class="text-center margin">No records found.</div>';
                        }
                        ?>
                    </div>
                    <div class="box-footer clearfix">
                        <?php
                        if (@$totalrecords > 0) {
                            ?>
                            <?= $pagination ?> <?php }
                        ?>                </div>
                </div>
                <!-- /.box -->
            </div>
        </div>
</section>
<script type='text/javascript'>
    function htmltopdf() {
        var pdf = new jsPDF('p', 'pt', 'a1');
        source = $('#fee_report')[0];
        specialElementHandlers = {
            '#bypassme': function (element, renderer) {
                return true
            }
        };
        margins = {
            top: 10,
            bottom: 10,
            left: 10,
            width: 800
        };
        pdf.fromHTML(
                source,
                margins.left,
                margins.top, {
                    'width': margins.width,
                    'elementHandlers': specialElementHandlers
                },
                function (dispose) {
                    pdf.save('Download.pdf');
                }, margins);
    }

</script>
<!-- Main content -->
<?php
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});   
                               //  $('.tablesorter').tablesorter(); 
	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
});
       
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
