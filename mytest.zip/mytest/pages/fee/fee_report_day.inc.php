<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<!-- Main content -->
<section class="content">
    <?php
    setlocale(LC_MONETARY, 'en_IN.UTF-8');
//      print_r($students);
    
   //print_r($oCurrentUser);
    ?>
    <script language="javascript">
        function printpage()
        {
            window.print();
        }
        
    </script>
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box box-primary">
                <div class="box-header"> 
                    <div class="row">
					  <div class='col-md-4'> 
                       
					   <ul class="nav nav-pills">
			               <li class="dropdown">
							<a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
						   <ul class="dropdown-menu">
							<li><a  href="javascript:void(0);" title="Export to Excel" onclick="$('#fee_reports').tableExport({type:'excel',escape:'false'});"><img src="<?= ASSETS_FOLDER?>/img/excel.png" title="export to excel" width="30" height="30"/></a></li>
                           <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER?>/img/word.png" title="export to word" width="30" height="30"/></a>
</a></li>
                          <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
					</li>
                         
            </ul>
        </li>
    </ul>
                                              
					<form method="post" target="_blank">
                    <?php
                        if (@$_POST['rsbtn']) 
						{
                                    ?>
                                    <input type="button" class="btn bg-olive btn-flat" value="Print" onClick="window.print()">    
                                    <?php
                                } else {
                                    ?> <span class="heading_text">
                                        Fee Collection Report As On <?php echo $drdate= date("d-m-Y", strtotime($oCurrentUser->mydate)); ?></span>  
                                    <div>&nbsp;</div>
                                    <div>&nbsp;</div>
                                   
                                    
                                <?php   }?>
                         </form></div>     
                               </div>
                            
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding report_export" id="fee_report">

                        <?php // if (@$totalrecords > 0) {  ?>
                         <?php
                            if (@$_POST['rsbtn']) {
                                ?>
                            <table class="table table-hover tablesorter" id="fee_reports"  align='center' border='1' ><?php } 
						else { ?>
                            
                            <table class="table table-hover tablesorter" id="fee_reports" align='center' > <?php } ?>
                            <?php
                            if (@$_POST['rsbtn']) {
								
								//include_once TEMPLATES_FOLDER . '/WriteHTML.php';
								
                                ?>
                                <tr>
                                    <td colspan="13" align="center">
                                        <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="13" class="vks" align="center">
                                      Student Wise Daily Fee Collection Report (<?= $oCurrentUser->mydate ?> )

                                    </td>
                                </tr>
								<?php

								
?>
                            <?php } ?>

                            <tr style="background:#ddd;">
                                <td><a href="javascript:void(0);">Sr.No.</a></td>
                                <?php // if (!@$selected_columns_students) {  ?>
                               
                               
                                <td> <a href="javascript:void(0);">Student ID</a></td>
                                <td> <a href="javascript:void(0);">Name</a></td>
                                <td> <a href="javascript:void(0);">Class</a></td>
                                <td> <a href="javascript:void(0);">Father Name</a></td>
                               
                                <td> <a href="javascript:void(0);">Amount</a></td>
                                <td> <a href="javascript:void(0);">Late Fee</a></td>
                                <td> <a href="javascript:void(0);">EOD</a></td>
                                <td> <a href="javascript:void(0);">TotalAmt</a></td>
                              </tr>

                            <?php
                            $i = 1;
                            $FeeAmt_T = 0;
                            $late_fee_T = 0;
                            $EOD_T = 0;
                            $TotalAmt_T = 0;

                            while ($rowv = $students->fetch(PDO::FETCH_ASSOC)) {
//                            print_r($rowv);
//                            exit();
//                            $student_details= $student= Student::get_students($oCurrentUser->myuid, 'all', $id)
                                $Student_detail = Student::get_stu_info($MSID, '', $rowv['AcNo'])->fetch(PDO::FETCH_OBJ);
                    $student = Student::get_students($oCurrentUser->myuid, 'all', $Student_detail->student_id)->fetch(PDO::FETCH_ASSOC);
//                            $class_get = Master::get_class_names2($MSID, $student->adm_classno)->fetch();
//                            print_r($student);
                                ?>
                            <tr class='n1'>
                                    <td><?= $i ?></td>
                                  <td><a class="btn-flat" href="<?= CLIENT_URL ?>/feevoucher/redirect/<?= $rowv['AcNo']; ?>"><?= $rowv['AcNo']; ?></a></td>

                                    <td><a class="btn-flat" data-title="Student Profile" data-ms="modal" href="<?= CLIENT_URL?>/ajax-page-load/std_profile/<?= $rowv['AcNo']; ?>"><?= $student['name']; ?></a></td>
                                    <td><?= $student['class_name'] ?></td>
                                    <td><?= $student['f_name']; ?></td>
                                   

                                    <td><?php
                                        $FeeAmt_T += round($rowv['FeeAmt']);
                                        echo round($rowv['FeeAmt']);
                                        ?></td>
                                    <td><?php
                                        $late_fee_T += round($rowv['Late_Fee']);
                                        echo $rowv['Late_Fee'];
                                        ?></td>
                                    <td><?php
                                        $EOD_T += round($rowv['EOD']);
                                        echo $rowv['EOD'];
                                        ?></td>
                                    <td><?php
                                        $TotalAmt_T += round($rowv['TotalAmt']);
                                        echo round($rowv['TotalAmt']);
                                        ?></td>
                                  </tr>
                                <?php
                                $i++;
                            }
                            ?>
                                 <?php  if (@$_POST['rsbtn']) { ?>
                                <tr>

                                    <td>&nbsp;</td>
                                   
                                    <td colspan="7" align='left'> <h4><b>Total</b></h4></td>
                                    
                                    <td><h4><b><?php echo $FeeAmt_T; ?></b></h4></td>
                                    <td><h4><b><?php echo $late_fee_T; ?></b></h4></td>
                                    <td><h4><b><?php echo $EOD_T; ?></b></h4></td>
                                    <td align='right'><h4><b><?php
                                               

                                                echo money_format('%n', $TotalAmt_T); // ₹ 2,11,234.56
//                                                echo $TotalAmt_T;
                                                ?></b></h4></td>
                                     <td>&nbsp;</td>
                                </tr>

                              <?php } else {?>
                              <tr>

                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                   
									<td>&nbsp;</td>
                                    <td> <h4><b>Total</b></h4></td>
                                    <td><h4><b><?php echo $FeeAmt_T; ?></b></h4></td>
                                    <td><h4><b><?php echo $late_fee_T; ?></b></h4></td>
                                    <td><h4><b><?php echo $EOD_T; ?></b></h4></td>
									
                                    <td><h4><b><?php echo $TotalAmt_T; ?></b></h4></td>
                                    
                                </tr>
                           
                        </table>
                        <?php } ?>

                    </div>
                    <!--                <div class="box-footer clearfix">
                    <?php if (@$totalrecords > 0) { ?>
                        <?php //echo  $pagination     ?> <?php }
                    ?>                </div>
                                </div>-->
                    <!-- /.box -->
                </div>
            </div>
            </section>
<script type='text/javascript'>
function htmltopdf() {
    var pdf = new jsPDF('p', 'pt', 'a1');
    source = $('#fee_report')[0];
    specialElementHandlers = {
        '#bypassme': function (element, renderer) {
            return true
        }
    };
    margins = {
        top: 10,
        bottom: 10,
        left: 10,
        width: 800
    };
    pdf.fromHTML(
    source, 
    margins.left,
    margins.top, { 
        'width': margins.width, 
        'elementHandlers': specialElementHandlers
    },

    function (dispose) {
        pdf.save('Download.pdf');
    }, margins);
}

</script>
<?php
            $sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
      //alert("hi");              
   $('.date_from').datepicker({ format: 'dd-mm-yyyy', todayHighlight: true, clearBtn: true});
   $('.date_from').on('changeDate', function(ev){
    $(this).datepicker('hide');
}) ;

	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});	
});
</script>
EOT;
            $oPageLayout->addJavascriptBottom($sBottomJavascript);
   ?>


       
		