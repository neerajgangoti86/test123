<section class="content">
    <div class="row">
        <div class="col-md-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Upload Fee Transaction</h3>
                    
            </div>
            <form id="csv_form" name="csv_form" method="post" action="" enctype="multipart/form-data">
            <div class="row"><div class="form-group">
           <div class="col-md-3"> <label>Upload CSV FILE <span class="text-red"></span></label>
           </div> <div class="col-md-3">  <input type="file" id="csv_file" required="required" name="csv_file">
             </div></div>

            </div>
                
            <div class="row">
                     <div class="col-md-3">
                <input type="hidden" name="file_uplod" value="true"/>
                  <span id="lblError" style="color: red;"></span>
                  <button type="submit" onclick="return ValidateExtension()" name="csv_btn" id="csv_btn" class="btn btn-lg btn-success btn-block">Upload</button>
                      </div>
                   </div>
            </form>
            
            
            
            
        </div>
        
        
        
    </div>
    
</section>

 <input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
                            <?php
                            $sBottomJavascript = <<<EOT

<script type="text/javascript">
$(document).ready(function()
{
   var siteurl = $('#site_url').val();     

    alert(siteurl);
        

});
function ValidateExtension() {
        var allowedFiles = [".csv"];
        var fileUpload = document.getElementById("csv_file");
        var lblError = document.getElementById("lblError");
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + allowedFiles.join('|') + ")$");
        if (!regex.test(fileUpload.value.toLowerCase())) {
            lblError.innerHTML = "Please upload files having extensions: <b>" + allowedFiles.join(', ') + "</b> only.";
            return false;
        }
        lblError.innerHTML = "";
        return true;
                    
</script>

EOT;
                            $oPageLayout->addJavascriptBottom($sBottomJavascript);
                            ?>