<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<!-- Main content -->
<section class="content">
    <?php
    setlocale(LC_MONETARY, 'en_IN.UTF-8');
//      print_r($students);
    //print_r($oCurrentUser);
    ?>
    <script language="javascript">
        function printpage()
        {
            window.print();
        }
    </script>
    <div class="row">
        <div class="col-xs-12"> <?php
    $message = new Messages();
    echo $message->display();
    ?>
            <div class="box box-primary">
                <div class="box-header"> 
                    <div class="row">
                        <div class='col-md-4'> 
                            <form method="post" target="_blank">
                                 <?php
                                   if (@$_POST['rsbtn'])
                                   {
                                 ?>
                              <input type="button" class="btn bg-olive btn-flat" value="Print" onClick="window.print()">      
                                
                                  <?php      
                                   }
                                   else
                                   {
                                 ?>
                               
                                <h3 class="box-title">
                                    Monthly Fee Collection</h3>    
                                <input type="submit" class="btn bg-olive btn-flat" value="Print Preview" name="rsbtn" id="resbn"/> <?php
                                   }
                                ?>

                            </form></div>     

                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding report_export" id="fee_report">

                        <table class="table table-hover tablesorter" id="fee_reports" align='center' > 
                          <?php
                            if (@$_POST['rsbtn']){
                          ?>
                            <tr>
                                    <td colspan="13" align="center">
                                        <?php include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; ?>

                                    </td>
                            </tr>
                          <?php
                            }
                          ?>
                            <tr style="background:#ddd;">
                                <td><a href="javascript:void(0);">Sr.No.</a></td>
                                <td> <a href="javascript:void(0);">Month</a></td>
                                <td align="right"> <a href="javascript:void(0);">Amount</a></td>
                                
                            </tr>

                            <?php
                            $i = 1;
                            $TotalAmt_T = 0;

                            while ($rowv = $students->fetch(PDO::FETCH_ASSOC)) {
                                ?>
                                <tr class='n1'>
                                    <td><?= $i ?></td>
                                    <td><a href="<?= CLIENT_URL?>/fee-report-month-day/<?= $rowv['sr_no']?>/<?= $rowv['Month']; ?>"><?= $rowv['Month']; ?></a></td>

                                    <td align="right"><?php
                                        $TotalAmt_T += round($rowv['AMOUNT']);
                                        echo round($rowv['AMOUNT']);
                                        ?></td>
         
                                </tr>
                                <?php
                                $i++;
                            }
                            ?>

                            <tr>

                                <td>&nbsp;</td>
                                <td> <h4><b>Total</b></h4></td>

                                <td align="right"><h4><b><?php echo $TotalAmt_T; ?></b></h4></td>
                               
                            </tr>

                        </table>

                    </div>

                </div>
            </div>
            </section>