<section class="content">
    <div class="row">
        <div class="col-xs-12" > <?php
            $message = new Messages();
            echo $message->display();
            ?> 
            <div class="sucess_msg"></div>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title heading_text"> Fee Collection</h3>

                        </div>   
                        <?php if ($type != "student") { ?><form class="form-inline" method="post" action="">
                                <div class="col-md-8">

                                    <label for="exampleInputName2">Enter Keyword : </label>
                                    <input type="text" value="<?php
//                                    if (isset($_SESSION['s_id'])) {
//                                        echo $_SESSION['s_id'];
//                                    }
                                    ?>" class="form-control" name="skeyword" id="skeyword" autofocus />

                                    <input type="submit" name="submit" value="Search" />
                                </div> </form>
<?php } ?>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <?php
                    if (@$_SESSION['s_id']) {
//                    print_r($_SESSION['user_date']);
//                    $student_id = '11001';
                        $student_id = $_SESSION['s_id'];
                        $students = Student::get_students($oCurrentUser->myuid, '', $student_id);
                        $rowcount = $students->rowcount();
                        if ($rowcount > 0) {

                            $student = $students->fetch(PDO::FETCH_OBJ);
//                       print_r($student);

                            $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
                            $session_dates = Master::getSchoolSession($MSID, $_SESSION['user_date'])->fetch(PDO::FETCH_OBJ);
                            $fees = Fee::get_fee_due_amt($oCurrentUser->myuid, $oCurrentUser->mydate, $student->acno, $oCurrentUser->begins, $oCurrentUser->ends, 'True', 'True');
//                                   $fees = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->student_id);
                            $ttl_fee = 0;
                            ?>

                            <div class="row">
                                <div class="col-md-3"> 

                                </div>   

                                <div class="col-md-8">
                                    <b>
                                        <?php
                                        $cls = Master::get_classes($MSID, '', '', '', $student->class)->fetch(PDO::FETCH_OBJ);
                                        ?>

                                        <?= $student->student_id ?> &nbsp;<?= $student->name ?> of <?= $cls->class_name ?>  Class <?php if ($student->gender == 'F') { ?> 
                                            D/O
                                        <?php } else { ?>
                                            S/O 
        <?php } ?>&nbsp;<?= $student->f_name ?> &nbsp; of <?= $Village->name ?>&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $student->student_id ?>" data-ms="modal" data-title="Student Profile">View profile</a>
                                    </b>
                                </div> 
                            </div>
                            <br>

                            <table width="90%" align="center" class="table table-hover maintable">
                                <tr>

                                    <td width="450" height="15" align="center" valign="top" class="simple">
                                        <table width="95%" border="1">

                                            <tr>
                                                <?php
                                                $cur_date = date('Y-m-01', strtotime($oCurrentUser->mydate));
                                                $current_date = $oCurrentUser->mydate;
                                                ?>
                                                <td colspan="3" align="center" class="simplebold"><span class="heading_text">Due Amount</span> <?php if($oCurrentUser->ulevel>8){ ?><a class="pull-right" data-title="Fee Collection" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax/fee_submit_headwise/<?= $student->student_id; ?>/<?= $student->class ?>/<?= $current_date ?>">Pay With Adjustment</a><?php } ?></td>
                                            </tr>
                                            <tr>
                                                <td  align="center" class="heading_text">Month</b></td>
                                                <!--<td  align="center"><b>Enter Fee</b></td>-->
                                                <td align="center" class="heading_text">Enter Fee</td>
                                                <td  align="right" class="heading_text">Amount</td>
                                            </tr>
                                            <?php
                                            //                                                                            print_r($oCurrentSchool->Detailed_Headwise);
//                                                                                                                                                        exit();
                                            $fee_state = Fee::get_max_tr_date($oCurrentUser->myuid, $student->acno)->fetch(PDO::FETCH_OBJ);
//                                     print_r($fee_state->tdate);
                                            
                                            while ($rowv = $fees->fetch(PDO::FETCH_OBJ)) {
                                                $ttl_fee += $rowv->fee;
                                                ?>

                                                <tr>

                                                    <?php if ($oCurrentSchool->Detailed_Headwise == "1") { ?>
                                                        <td align="center" valign="top" width="20%"><a data-ms="modal" data-title="Fee detail"  href="<?= CLIENT_URL; ?>/ajax/fee_deteil_headwise/<?= $student->student_id; ?>/<?= $student->class ?>/<?= $rowv->DueDate ?>/<?= $rowv->SrNo ?>/<?= $rowv->RSrNo ?> "><?php echo date("M", strtotime($rowv->DueDate)); ?></a></td>
                                                    <?php } ?>
                                                    <?php if ($oCurrentSchool->Detailed_Headwise == "0") { ?>
                                                        <td align="center" valign="top" width="20%"><a data-ms="modal" data-title="Fee detail"  href="<?= CLIENT_URL; ?>/ajax/fee_deteil/<?= $student->student_id; ?>/<?= $student->class ?>/<?= $rowv->DueDate ?>/<?= $rowv->SrNo ?>"><?php echo date("M", strtotime($rowv->DueDate)); ?></a></td>
                                                    <?php }
                                                    ?>  <?php
                                                    $a = 0;
                                                    if ($a != 0) {
                                                        if ($oCurrentSchool->Detailed_Headwise == "1") {
                                                            ?><td align="center" valign="top" ><?php if($oCurrentUser->ulevel>8){ ?><a  data-title="Fee Collection" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax/fee_submit_headwise/<?= $student->student_id; ?>/<?= $student->class ?>/<?= $rowv->DueDate ?>/<?= $rowv->SrNo ?>">Pay With Adjustment</a><?php } ?></td><?php } ?> 
                                                        <?php if ($oCurrentSchool->Detailed_Headwise == "0") { ?><td align="center" valign="top"><?php if($oCurrentUser->ulevel>8){ ?><a  data-title="Fee Collection" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax/fee_submit/<?= $student->student_id; ?>/<?= $student->class ?>/<?= $rowv->DueDate ?>/<?= $rowv->SrNo ?>">Pay With Adjustment</a><?php } ?></td><?php
                                                        }
                                               }
                                                    ?>
                                                    <?php if(@$fee_state->tdate >= $rowv->DueDate  ) {
                                                        ?>
                                                          <td width="20%" valign="top" align="center">paid</td>
                                                    <?php }else{
                                                        if ($oCurrentSchool->Detailed_Headwise == "1") { ?>
                                                        <td  width="20%" align="center" valign="top"><?php if($oCurrentUser->ulevel>8){ ?><a href="feevoucher/submit_headwise/<?= $student->student_id; ?>/<?= $student->acno ?>/<?= $rowv->DueDate ?>/<?= $rowv->SrNo ?>/<?= $rowv->fee ?>">Pay Now</a><?php } ?></td>
                                                <?php } if ($oCurrentSchool->Detailed_Headwise == "0") { ?>
                                                        <td width="20%" valign="top" align="center"><?php if($oCurrentUser->ulevel>8){ ?><a href="feevoucher/submit/<?= $student->student_id; ?>/<?= $student->acno ?>/<?= $rowv->DueDate ?>/<?= $rowv->SrNo ?>/<?= $rowv->fee ?>">Pay Now</a><?php } ?></td>
                                                    <?php } }?><td width="20%" align="right" valign="top"><?php echo round($rowv->fee); ?></td>
                                                </tr>
        <?php } ?>
                                            <tr class="simplebold">
                                                <td colspan="2" class="heading_text">Total</td> 
                                                <td align="right"><?= $ttl_fee ?></td>
                                            </tr>
                                        </table></td>


                                    <?php
//                                    print_r($oCurrentUser);
                                    $txn = Fee::get_fee_tsn($MSID, $oCurrentUser->mysession, $student->acno, $oCurrentUser->mydate);


                                    $ttl_fee_2 = 0;
                                    $ttl_cal_late_fee_2 = 0;
                                    $ttl_late_fee_2 = 0;
                                    $ttl_discount = 0;
                                    $net_ttl = 0;
                                    ?> 
                                    <td width="550" height="15" align="center" valign="top" class="simple">
                                        <table width="90%"  border="1" align="center">

                                            <tr valign="top" class="simple">
                                                <td colspan="6" align="center" class="simplebold heading_text" >Paid Amount </td>
                                            </tr>
                                            <tr valign="top" class="simple">  
                                                <td width="120" class="simple heading_text"  align="center" >Date</td> 
                                                <td width="104" class="simple heading_text"  align="center">Month</td>
                                                <td width="68" align="center" class="simple heading_text" >Amount</td>
                                                <td width="61"  align="center"  class="simple heading_text">Late Fee</td>
                                                <td width="100"  align="center"  class="simple heading_text"> Discount</td>
                                                <td width="102"  align="center"  class="simple heading_text">Net Recived</td>
                                            </tr>
                                            <?php
                                            while ($rowu = $txn->fetch(PDO::FETCH_ASSOC)) {

//                                            print_r($rowu);
                                                $TrDate = $rowu['tr_date'];
                                                $TLateFee = $rowu['late_fee'];
                                                $TCalLateFee = $rowu['cal_late_fee'];
                                                $Tdiscount = $rowu['discount'];
                                                $Type = $rowu['type'];
                                                $TridNo = $rowu['id'];
//                                        $CalLateFee = $rowu['cal_late_fee'];
//                                        $LateFee = $rowu['late_fee'];
//                                            $TrId = $rowu['tr_id'];
                                                $Rate = $rowu['amt'];
                                                $fDr = $rowu['fee_receipt_id'];
                                                $recipt_id = explode("-", $fDr);
//                                        print_r();
//                                        $monthNum  = 3;
                                                $dateObj = DateTime::createFromFormat('!m', $recipt_id[3]);
                                                $monthName = $dateObj->format('F'); // March
                                                $dgd = substr($fDr, 19);
                                                $coc = strlen($student->acno);
                                                if ($coc == '1') {
                                                    $mno = substr($fDr, 13, 2);
                                                } else if ($coc == '2') {
                                                    $mno = substr($fDr, 14, 2);
                                                } else if ($coc == '3') {
                                                    $mno = substr($fDr, 16, 2);
                                                } else if ($coc == '4') {
                                                    $mno = substr($fDr, 16, 2);
                                                } else {
                                                    
                                                }
                                                $dgm = substr($fDr, 16);
                                                //echo  $mno=substr($fDr,16,2) ; 
                                                ?>
                                                <?php
                                                $ttl_fee_2 +=$Rate;
                                                $ttl_late_fee_2 +=$TLateFee;
                                                $ttl_cal_late_fee_2 +=$TCalLateFee;
                                                $ttl_discount +=$Tdiscount;
                                                ?>
                                                <tr class="simple4alltext"> 
                                                    <td valign="bottom" align="center" class="simple4alltext">
                                                    <?php if($oCurrentUser->ulevel>8){ ?>
                                                                <?php if ($oCurrentSchool->Detailed_Headwise == "1") { ?>
                                                            <a  data-title="Fee Collection" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax/edit_paid_fee_headwise/<?= $student->student_id; ?>/<?= $rowu['id'] ?>">
            <?php } ?><?php if ($oCurrentSchool->Detailed_Headwise == "0") { ?>
                                                                <a  data-title="Fee Collection" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax/edit_paid_fee/<?= $student->student_id; ?>/<?= $rowu['id'] ?>">
                                                            <?php } ?><?= $TrDate ?>

                                                            </a></td>
                                                    <td valign="bottom" class="simple4alltext" align="center"><b> <?php
                                                            if ($rowu['type'] == "Adjustment") {
                                                                echo "Adjustment";
                                                            } else {
                                                                echo substr($monthName, "0", "3");
                                                            }
													}else{  echo $TrDate; }
                                                            ?>
                                                        </b></td>
                                                    <td align="right" valign="bottom" class="simple4alltext"><b><?php echo round($Rate); ?></b></td>

                                                    <td align="right" valign="bottom"  class="simple4alltext"><b><?= $TLateFee ?>
                                                        </b> </td><td align="right" valign="bottom"  class="simple4alltext"><b><?= $Tdiscount ?>
                                                        </b> </td><td align="right" valign="bottom"  class="simple4alltext"><b><?php
                                                echo $net_amt = $Rate + $TLateFee - $Tdiscount;
                                                $net_ttl +=$net_amt;
                                                ?>
                                                        </b> </td>
                                                </tr> <?php } ?>
                                            <tr class="simplebold">
                                                <td height="28" align="center" colspan="2" class="simple heading_text">Total                                     </td>
                                                <td align="right" class="simple4alltext"><span class="simple"><b>
        <?= $ttl_fee_2 ?></b>
                                                    </span></td>
                                                <td align="right" class="simple4alltext"><span class="simple">
                                                        <b><?= $ttl_late_fee_2 ?></b>
                                                    </span></td><td align="right" class="simple4alltext"><span class="simple">
                                                        <b><?= $ttl_discount ?></b>
                                                    </span></td><td align="right" class="simple4alltext"><span class="simple">
                                                        <b><?= $net_ttl ?></b>
                                                    </span></td>
                                            </tr>
                                        </table></td>
                                </tr>
                                <tr>
                                    <td height="15" colspan="2" align="center" valign="top" class="simple"><table width="883" height="70" border="1" align="center"  bordercolor="#000" bgcolor="#FFFFFF">
                                            <tr>
                                                <td width="115" align="center" class="simple heading_text">Opening Balance</td>
                                                <td width="93" align="center" class="simple heading_text">Due Amount</td>
                                                <td width="126" align="center" class="simplebold heading_text">Late Fee Imposed</td>        
                                                <td width="75" align="center" class="simplebold heading_text">Discount </td>
                                                <td width="106" align="center" class="simplebold heading_text">Total Amount</td>
                                                <td width="117" align="center" class="simple heading_text">Amount Received</td>
                                                <td width="54" align="center" class="simple heading_text">Balance</td>
                                                <!--<td width="54" align="center" class="simple" ><b>Balance</b></td>-->
                                                <td width="63" align="center" class="simple heading_text" >CrDr</td>
                                            </tr>
                                            <?php
//                                                                        print_r($student);
//                                     $q =" "; 
//                                    $q = " SET SQL_BIG_SELECTS=1  ;";
//                                    $q = " Select  MN1.feeDate ,MN1.mydate , MN1.sl_date , MN1.DueDate ,MN1.AcNo, Sum(MN1.FeeAmt1) DueAmt From(Select MN.*,Sum(MN.FeeAmt) FeeAmt1 ,CU.mydate ,S.sl_date
//FROM ms_fee_n_fine MN
//Inner Join ms_slusers CU On myuid = '" . $oCurrentUser->user_id . "'
//Inner Join ms_students S on S.acno='" . $student->acno . "' AND S.MSID= '" . $MSID . "'                                                                                                     
//Group By AcNo,RSrNo )MN1
//Where MN1.DueDate Between MN1.feeDate And MN1.sl_date and  MN1.acno='" . $student->acno . "' And MN1.DueDate <= MN1.mydate 
//Group By MN1.AcNo 
//"; 
//                                    print_r($q);
//                                    exit(); 
//                                    $oDb = DBConnection::get();  
//                                    $data = $oDb->query($q)->fetch(PDO::FETCH_OBJ);
//                                   
//                                    print_r($oCurrentSchool);
//                                    print_r($oCurrentUser);
//                                    exit(); 
                                            $due_amt = Fee::get_fee_due_amt($oCurrentUser->myuid, $oCurrentUser->mydate, $student->acno, $oCurrentUser->begins, $oCurrentUser->ends, 'True', 'FALSE')->fetch(PDO::FETCH_OBJ);
                                            ?> 


                                            <tr>
                                                <td align="center" class="simple"><b><?= $student->opening_bal ?></b></td>

                                                <td align="center" class="simple"><b><?php echo $due_amount = (@$due_amt->DueAmt) ? $due_amt->DueAmt : 0 ?></b></td>
                                                <td align="center" class="simple"><b><?= $ttl_cal_late_fee_2 ?></b></td>
                                                <td width="75" align="center" class="simple"><b><?= $ttl_discount ?></b></td>
                                                <td width="106" align="center" class="simple"><b><?php echo $ttl_amt = $student->opening_bal + $due_amount + $ttl_cal_late_fee_2 - $ttl_discount ?></b></td>
                                                <td width="117" align="center" class="simple" ><b><?php
                                                        echo $net_ttl;
                                                        $ttl_recived = $due_amount + $ttl_late_fee_2 - $ttl_discount;
//                                  echo "--";       echo $student->opening_bal ,"-", $ttl_discount,"-", $ttl_late_fee_2 
                                                        ?></b></td>
                                                <td width="54" align="center" class="simple" ><b><?php
                                                        echo $ttl_bal = $ttl_amt - $net_ttl;
//                                  echo "--";       echo $student->opening_bal ,"-", $ttl_discount,"-", $ttl_late_fee_2 
                                                        ?></b></td>
                                                <td width="63" align="center" class="simple" ><b><?php echo ($ttl_bal > 0 ? "DR" : "CR") ?></b></td>
                                            </tr></table>
                                    </td>

                                </tr>

                            </table>

                            <?php
                        } else {
                            ?>
        <?php
        echo "No Record Exist ";
    }
}
?>





                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>

<?php


$sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});	
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
//print_r($_SESSION);
if(@$_SESSION['reset'] == '1')
{
?>
<script type="text/javascript">
  var skeyword = document.getElementById("skeyword").value;
  
  document.getElementById("skeyword").value ='';
  document.getElementById("skeyword").focus();
  
</script>
<?php
 unset($_SESSION['reset']);
}
?>