<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <!--<h3 class="box-title"> Fee Summary</h3>-->
                        </div>   

                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">


                    <link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />

                    <!--type="text/css">@import "../__jquery.tablesorter/tests/assets/css/default.css";-->
                    <style type="text/css">

                        .tablesimple{border:1px solid #B2B2B2; border-radius:10px 10px 10px 10px; margin-top:-1px;}


                        .simplefont{color:#333; font-family:Verdana, Geneva, sans-serif; font-size:12px; text-transform:capitalize; padding:2px;}
                        .simplebold{color:#000; font-family:Verdana, Geneva, sans-serif; font-size:12px; text-transform:capitalize; padding:2px; font-weight:bold}
                        .tablesorter{border:1px solid #B2B2B2; border-radius:10px 10px 10px 10px; margin-top:-17px;}

                        .tablesorter td{ height:25px; color:#333; font-family:Verdana, Geneva, sans-serif; font-size:12px; border:1px solid #B2B2B2; text-transform:capitalize; padding:2px;}
                        .tablesorter th{ height:35px; border:1px solid #B2B2B2; text-transform:capitalize; }

                    </style>
 

                                            <table width="95%" align="center" cellpadding="2" cellspacing="2">
<!--                                                <tr>
                                                    <td height="22" align="center">
													<?php /*include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php'; */?>
                                                    </td></tr>-->
                                                
                                                <tr><td align="center"><h4>Fee Summary Report As On
 <?php echo  $oCurrentUser->mydate ?></h4></td></tr>
                                                    <tr><td>
                                                        <table width="100%" height="176"   border="0" align="center">

                                                            <tr align="center"  valign="top">
                                                                <td height="116" colspan="2" align="left" ><table width="90%" border="0">
                                                                 <tr class="simplebold" >
                                                                     <td colspan="2"><strong>Particular</strong></td>
                                                                     <td width="131" align="right"><strong>Amount</strong></td>
                                                                   </tr>
                                                                        <?php
                                                                        $today = date('Y-m-d');


                                                                        $fee_types = Fee::get_fee_summary($MSID, $oCurrentUser->myuid);
                                                                        $ttl = 0;
                                                                        while ($fee_type = $fee_types->fetch(PDO::FETCH_OBJ)) {
//                                                                            print_r($fee_type);
                                                                            ?>
                                                                            <tr class="simplefont">
                                                                                <td colspan="2"><?= $fee_type->FeeName; ?></td>
                                                                                <td width="131" align="right"><?php echo round($fee_type->total); ?>
                                                                                </td>
                                                                            </tr>
                                                                            <?php
                                                                            $ttl +=$fee_type->total;
                                                                        }
                                                                        ?>
                                                                        <tr class="simplefont">
                                                                            <td colspan="3"><hr></td>
                                                                        </tr>
                                                                        <tr class="simplefont">
                                                                            <td colspan="2"><strong>Total fees Receivable</strong></td>
                                                                            <td align="right" class="simplebold"><?php
                                                                                echo $ttl;
                                                                              
// print_r();
// exit();
                                                                                $defaulters = Fee::get_defaulters($oCurrentUser->myuid, 'advancepayer', 'all', 'all', '', 'True')->fetch(PDO::FETCH_OBJ);
//                                                                                print_r($defaulters);
                                                                                $count = Fee::get_defaulters($oCurrentUser->myuid, 'advancepayer','all');
                                                                                $ttl_count = $count->rowCount();
                                                                                ?></td>  
                                                                        </tr>
                                                                       <tr class="simplefont">
                                                                            <td colspan="2"> Late Fee Receivable</td>
                                                                            <td width="131" align="right"><?php ?></td>
                                                                        </tr>
                                                                        <tr class="simplefont">
                                                                            <td width="185"><a href="fee-defaulter/advancepayer" target="_blank">Advance Fee Received</a></td>
                                                                            <td width="62"><?php echo '(' . $ttl_count . ')'; ?></td>
                                                                            <td width="131" align="right"><?php
                                                                                $ttl +=round(abs($defaulters->balance));
                                                                                echo round(abs($defaulters->balance));
                                                                                ?></td>
                                                                        </tr>
                                                                    </table></td>
                                                                <td colspan="2" align="left" ><table width="90%" border="0">
                                                                        <tr class="simplebold" >
                                                                            <td colspan="2"><strong>Particular</strong></td>
                                                                            <td width="109" align="right"><strong>Amount</strong></td>
                                                                        </tr>

                                                                        <?php
                                                                        $total = 0;
                                                                        $pay_to = Fee::get_credit_deatils( $oCurrentUser->myuid );
                                                                        while ($payers = $pay_to->fetch(PDO::FETCH_OBJ)) {
//                                                                                        print_r($payers);
                                                                            ?><tr class="st4">
                                                                                <td colspan="2" align="left"  ><a href="fee-report-dr/<?= $payers->dr ?>" target="_blank">
    <?php echo $payers->name; ?>
                                                                                    </a></td>
                                                                                <td width="109" height="2" align="right"  ><?php echo round($payers->Total); ?><?php $total += $payers->Total;
                                                                                ?></td>
                                                                            </tr><?php }
?>

                                                                        <tr class="st4">
                                                                            <td height="4" colspan="3" align="left"  ><hr /></td>
                                                                        </tr>

                                                                        <tr class="st4">
                                                                            <td colspan="2" align="left" class="simplebold"  > 
                                                                                Total Fees Received
                                                                            </td>
                                                                            <td width="109" height="2" align="right" class="simplebold"><?php
                                                                                echo round($total);
                                                                                ?></td>
                                                                        </tr>

                                                                        <tr class="st4">
                                                                            <td height="4" colspan="3" align="left"  ><hr /></td>
                                                                        </tr>

                                                                        <tr class="st4">
                                                                            <td width="174" align="left"  ><a href="fee-defaulter/defaulters" target="_blank">Fee to receive</a></td>
                                                                            <?php  $defaulter = Fee::get_defaulters($oCurrentUser->myuid, 'defaulters', 'all', 'all', '', 'True')->fetch(PDO::FETCH_OBJ);
                                                                                $counts = Fee::get_defaulters($oCurrentUser->myuid, 'defaulters','all');
                                                                                $ttl_counts = $counts->rowCount();
                                                                                ?>
                                                                            <td width="56" align="left"  ><?php echo '(' . $ttl_counts . ')'; ?></td>
                                                                            <td height="0" align="right"  ><?php  $total +=round(abs($defaulter->balance));
                                                                                echo round(abs($defaulter->balance));
                                                                               ?></td>
                                                                        </tr>


                                                                    </table></td>
                                                            </tr>
                                                            <tr align="center"  valign="top">
                                                                <td height="4" colspan="4" align="left" ><hr></td>
                                                            </tr>
                                                            <tr align="center"  valign="top">
                                                                <td width="239" height="39" align="left" ><span class="simplebold">Total</span></td>
                                                                <td width="411" align="right"  class="simplebold"><?php echo $ttl; ?></td>
                                                                <td width="361" align="left" ><span class="simplebold">Total</span></td>
                                                                <td width="307" align="right"  class="simplebold"><?php echo $total; ?></td>
                                                            </tr>		 
</table>













                                </div>
                                </div>
                                <!-- /.box -->
                                </div>
                                </div>
                                </section>
<?php //                                                                        print_r( $oCurrentUser->mydate);