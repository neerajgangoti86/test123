<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <?php if ($dpl_acs != NULL) { ?>
            <div class="callout callout-danger lead">
                <h4>Duplicate Entry !</h4>
                <p><?= $dpl_acs ?></p>
            </div>
            <?php } ?>
            <?php if ($scss_acs != NULL) { ?>
            <div class="callout callout-success lead">
                <h4>Successfully Submitted !</h4>
                <p><?= $scss_acs ?></p>
            </div>
            <?php } ?>



            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Quick Reveive Fee</h3>
                    <div class="box-tools pull-right">
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <form method="post" action="">
                            <input type="hidden" name="quick_fee" value="xxx">
                            <div class="col-md-12" style="padding: 0px 200px">
                                <!--                                <div class="col-md-6" style="padding-left: 0px ">
                                                                    <div class="form-group">
                                <?php
                                if (@$_POST['Entries']) {
                                $entry = $_POST['Entries'];
                                }
                                ?>
                                                                        <select class="form-control" name="Entries" id="month" onchange="this.form.submit()" >
                                                                            <option value=""> SELECT NUMBER OF ENTRIES </option>
                                <?php
                                for ($i = 1;
                                $i <= 10;
                                $i++) {
                                ?>
                                <?php
                                $amount = 6 * $i;
                                if ($entry == $amount) {
                                $selected = "selected";
                                } else {
                                $selected = "";
                                }
                                ?>
                                                                                <option value="<?= $amount ?>" <?= $selected ?>><?= $amount ?></option>
                                <?php } ?>
                                                                        </select>
                                                                    </div>
                                                                </div>-->
                                <div class="col-md-12 no-padding">
                                    <div class="form-group">
                                        <select class="form-control" name="month" id="month" >
                                            <option value="">SELECT MONTH</option>    
                                            <option value="<?= $year ?>-01-01">January</option>
                                            <option value="<?= $year ?>-02-01">February</option>
                                            <option value="<?= $year ?>-03-01">March</option>
                                            <option value="<?= $year ?>-04-01">April</option>
                                            <option value="<?= $year ?>-05-01">May</option>
                                            <option value="<?= $year ?>-06-01">June</option>
                                            <option value="<?= $year ?>-07-01">July</option>
                                            <option value="<?= $year ?>-08-01">August</option>
                                            <option value="<?= $year ?>-09-01">September</option>
                                            <option value="<?= $year ?>-10-01">October</option>
                                            <option value="<?= $year ?>-11-01">November</option>
                                            <option value="<?= $year ?>-12-01">December</option>
                                        </select>
                                    </div>
                                </div>
                                <?php
                                for ($i = 1; $i <= 12; $i++) {
                                ?>
                                <div class="col-md-2 no-padding">
                                    <input class="form-control text-center ids" type="text" name="s_id[]" placeholder="Student ID ">
                                </div>
                                <?php
                                }
                                ?>
                                <div class="col-md-12"><div class="form-group"></div></div>
                                <div class="col-md-6 col-md-offset-3 no-padding">
                                    <button class="btn btn-block btn-success btn-lg" type="submit" >Submit</button>
                                </div>
                            </div>
                    </div>
                    </form>  
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<script src="<?= CLIENT_URL ?>/plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script>
    $(document).ready(function () {
        $(".ids").keydown(function (e) {
            if (e.which === 8 || e.which === 9 || (e.which === 65 || e.which === 88 || e.which === 67 || e.which === 86 && (e.ctrlKey === true || e.metaKey === true))) {
                return;
            }
            if ((e.which < 48 || e.which > 57) && (e.which < 96 || e.which > 105))
            {
                e.preventDefault();
            }
        });
    });
</script>