<link href="<?= ASSETS_FOLDER ?>/css/report.css" rel="stylesheet" type="text/css" />
<!-- Main content -->
<section class="content">
    <?php
    setlocale(LC_MONETARY, 'en_IN.UTF-8');
//      print_r($students);
    //print_r($oCurrentUser);
    ?>
    <script language="javascript">
        function printpage()
        {
            window.print();
        }

    </script>
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box box-primary">
                <div class="box-header"> 
                    <div class="row">
                        <div class='col-md-4'> 
                            <h3><?php echo ucfirst(http_get('param2')); ?> Receivable fee</h3>
                            <ul class="nav nav-pills">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                                    <ul class="dropdown-menu">
                                        <li><a  href="javascript:void(0);" title="Export to Excel" onclick="$('#fee_reports').tableExport({type: 'excel', escape: 'false'});"><img src="<?= ASSETS_FOLDER ?>/img/excel.png" title="export to excel" width="30" height="30"/></a></li>
                                        <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                                            </a></li>
                                        <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                                        </li>

                                    </ul>
                                </li>
                            </ul>
                        </div>     

                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding report_export" id="fee_report">


                        <table class="table table-hover tablesorter" id="fee_reports" align='center' > 

                            <tr style="background:#ddd;">
                                <td><a href="javascript:void(0);">Sr.No.</a></td>
                                <td> <a href="javascript:void(0);">FeeName</a></td>
                                <td>&nbsp;</td>  <td style="text-align: right" > <a href="javascript:void(0);">Amount</a></td>

                            </tr>

                            <?php
                            $i = 1;
                            $FeeAmt_T = 0;

                            while ($rowv = $fees->fetch(PDO::FETCH_ASSOC))
                                {
                                ?>
                                <tr class='n1'>
                                    <td><?= $i ?></td>
                                    <td><?= $rowv['FeeName']; ?></td>
                                    <td>&nbsp;</td>    <td style="text-align: right"><?php
                                        $FeeAmt_T += round($rowv['Amount']);
                                        echo round($rowv['Amount']);
                                        ?></td>

                                </tr>
                                <?php
                                $i++;
                                }
                            ?>

                            <tr class='n1'>
                                <td>&nbsp;</td>
                                <td>Total</td>
                                <td>&nbsp;</td>    <td style="text-align: right"><?php
                                    echo $FeeAmt_T;
                                    ?></td>

                            </tr>
                        </table>


                    </div>

                </div>
            </div>
            </section>
            <script type='text/javascript'>
                function htmltopdf() {
                    var pdf = new jsPDF('p', 'pt', 'a1');
                    source = $('#fee_report')[0];
                    specialElementHandlers = {
                        '#bypassme': function (element, renderer) {
                            return true
                        }
                    };
                    margins = {
                        top: 10,
                        bottom: 10,
                        left: 10,
                        width: 800
                    };
                    pdf.fromHTML(
                            source,
                            margins.left,
                            margins.top, {
                                'width': margins.width,
                                'elementHandlers': specialElementHandlers
                            },
                            function (dispose) {
                                pdf.save('Download.pdf');
                            }, margins);
                }

            </script>



