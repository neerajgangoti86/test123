<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Assign Discount</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <form method="post">
                            <div class="form-group">
                          <div class="col-md-2"></div>
                                <div class="col-md-2">
                                    <label>Select Class<span class="text-red">*</span></label></div>
                                    <div class="col-md-2">  <select name="class" class="form-control" onchange="this.form.submit();">
                                            <?php
                                            if ($ClassID == NULL) {
                                                $selected = 'selected="selected"';
                                            }
                                            ?>
                                            <option value="" <?= $selected ?>>Select Class</option>
                                            <?php
                                            while ($class = $getClass->fetch()) {

                                                if ((@$ClassID == $class['class_no']) && ($ClassID != NULL)) {
                                                    $selected = 'selected="selected"';
                                                } else {
                                                    $selected = NULL;
                                                }
                                                ?>
                                                <option value="<?= $class['class_no'] ?>" <?= $selected ?>><?= $class['class_name'] ?></option>
                                            <?php } ?>
                                        </select></div>
                                  <div class="col-md-2">  
                                     <?php
                                 if(@$ClassID && $oCurrentSchool->section > 1){?>
                                        
                                      <label>Section</label></div>
                                          <div class="col-md-2">     <select class="form-control" name="section">
                                                <option>Select Section</option>
                                                <?php
                                                while ($section = $getSection->fetch()) {
                                                    if (@$_POST['section'] == $section['section']) {
                                                        $selected = 'selected="selected"';
                                                    } else {
                                                        $selected = NULL;
                                                    }
                                                     $sec = Master::get_schools_section($MSID, $section['section'])->fetch();
                                                    
                                                    ?>
                                <option  value="<?= $section['section'] ?>" <?= $selected ?>><?= $sec['sec_name'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    <?php } ?>
                         <div class="col-md-2">
                                    <input class="btn bg-olive btn-flat margin" type="submit" name="GetDiscountData" value="Get Student Data">
                         </div> </div>
                               
                           </form>    </div>
                     
                        <div class="col-md-12">
                            <?php if (@$_POST['GetDiscountData']) { ?>
                                <hr>
                                <form method="post">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Sr.</th>
                                                <th>Adm No</th>
                                                <th>Student Name</th>
                                                <th>Discount*</th>
                                                <th>Start Date*</th>
                                                <th>End Date*</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sr = 1;
                                            while ($Students = $GetStudent->fetch()) {
                                                $discount = Discount::get_discount($MSID, NULL, $data = array('selectAll' => 'true'));
                                                $StdntDis = Discount::get_discount_stdnt($MSID, $Students['student_id'])->fetch(PDO::FETCH_ASSOC);
                                                //pr($StdntDis);
                                                ?>
                                                <tr>
                                                    <td><?= $sr ?></td>
                                                    <td><?= $Students['student_id'] ?></td>
                                                    <td><?= $Students['name'] ?></td>
                                                    <td>
                                                        <select class="form-control" name="discount[]">
                                                            <option value="">Select Discount</option>
                                                            <?php
                                                            while ($dis = $discount->fetch()) {
                                                                if ($dis['discount_id'] == $StdntDis['discount_id']) {
                                                                    $selected = 'selected="selected"';
                                                                } else {
                                                                    $selected = "";
                                                                }
                                                                ?>
                                                                <option value="<?= $dis['discount_id'] ?>" <?= $selected ?>><?= $dis['name'] ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </td>
                                                    <?php $year = date("Y", strtotime($oCurrentUser->mydate)); ?>
                                                    <?php
                                                    if (empty($StdntDis['date_from'])): $start = $oCurrentUser->begins ;
                                                    else: $start = $StdntDis['date_from'];
                                                    endif;
                                                    ?>
                                                    <?php
                                                    if (empty($StdntDis['date_to'])): $end = '3000-12-31';
                                                    else: $end = $StdntDis['date_to'];
                                                    endif;
                                                    ?>
                                                    <td>
                                                        <input type="text" class="form-control discount_dates" name="startDate[]" value="<?= $start ?>" required readonly> 
                                                    </td>
                                                    <td>
                                                        <input type="text" class="form-control discount_dates" name="endDate[]" value="<?= $end ?>" required readonly>
                                                    </td>
                                                </tr>
                                            <input type="hidden" value="<?= $Students['student_id'] ?>" name="student[]">
        <?php
        $sr++;
    }
    ?>
                                        </tbody>
                                    </table>
                                    <hr>
                                    <input class="btn btn-block btn-success" type="submit" name="UpdateDiscountData" value="Update">
                                </form>
    <?php
}
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    .discount_dates{
        cursor: pointer !important;
    }
</style>
<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
	 $('.discount_dates').datepicker({ format: 'yyyy-mm-dd', todayHighlight: true, clearBtn: true});
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>