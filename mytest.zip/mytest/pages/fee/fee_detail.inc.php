<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-3">                   
                            <h3 class="box-title"> Fee Details</h3>
                        </div>   

                    </div>
                </div>
                <div class="box-body table-responsive no-padding">


                    <table width="400" border="1" align="center" >
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" >Due Date : <?= $due_date ?>( Fee For month of : <?php echo date("M", strtotime($due_date)); ?>) Amount &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ><?= $student->student_id ?> &nbsp;<?= $student->name ?>&nbsp;<?= $student->class ?>&nbsp;<?= $student->f_name ?> &nbsp; of <?= $Village->name ?>&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td width="86" class="simple" ><b>Sr. No.</b></td>
                            <td width="109" class="simple"  align="center"><b>Fee</b></td>
                            <td width="110" align="right" class="simple" ><b>Amount</b></td>

                        </tr>
                        <?php
                        $i = 1;
                        $ttl_fee = 0;
                        while ($rowu = $fee_dtl->fetch())
                            {
                            $ttl_fee +=$rowu['FeeAmt'];
                            ?>
                            <tr class="simple4alltext">
                                <td valign="bottom" class="simple4alltext">
                                    <?= $i ?></td>
                                <?php $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu['FeeId'])->fetch(PDO::FETCH_OBJ); ?>
                                <td valign="bottom" class="simple4alltext" align="center"><b> <?= $fee->fee_name ?>

                                    </b></td>
                                <td align="right" valign="bottom" class="simple4alltext"><b><?= $rowu['FeeAmt'] ?></b></td>

                            </tr> <?php $i++;
                            }
                            ?>
                        <tr class="simplebold">
                            <td colspan="2">Total</td>
                            <td align="right"><?= $ttl_fee ?></td>
                        </tr>
                        </tr>
                    </table>

<?php ?>





                </div
            </div>
            <!--            <!-- /.box -->
        </div>
    </div>
</section>