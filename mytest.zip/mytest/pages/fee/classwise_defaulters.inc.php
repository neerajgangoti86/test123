
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box box-primary">
                <div class="box-header">
                    <div class = "col-md-3"><h3 class="box-title"> Classwise  Defaulters</h3></div>
                    <div class = "col-md-6">
                        <form class="form-inline " method="post">
                            <input type="hidden" name="report_card_form" value="xxx" />
                            <label for="exampleInputName2">Select Class : </label>

                            <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()' >
                                <?php
                                if (@$selected_class) {
//     exit();
                                } else {
                                    ?> <option>Select Class</option>
                                    <?php
                                }
                                $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                ?>
                                <?php
                                foreach ($classs as $class) {
                                    if ($selected_class == $class['class_no']) {
                                        $selected = 'selected = "selected"';
                                    } else {
                                        $selected = "";
                                    }
                                    ?>
                                    <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                        <?= $class['class_name']; ?>
                                    </option>
                                <?php } ?>
                            </select>

                        </form>

                    </div><div class="col-md-3"><form class="form-inline right_ft column_hide_show" method="post">
                            <div class="btn-group">
                                <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    Select Columns 
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu"  aria-labelledby="dropdownMenu1">
                                    <?php
                                    foreach ($students_array as $key => $val) {
                                        if (in_array($key, @$selected_columns_students)) {
                                            $checked = "checked ='checked'";
                                        } else {
                                            $checked = "";
                                        };
                                        ?>
                                        <li>
                                            <input type="checkbox" value="<?= $key ?>"  name="column1[]" <?= $checked ?>><?= $val ?>
                                        </li> 
                                    <?php } ?>
                                    <li><button type="submit" name="columnsubmit" class="btn btn-block btn-sm btn-warning btn-flat">Submit</button></li>
                                </ul>
                            </div>
                        </form></div>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <?php if ($totalrecords > 0) { ?>
                        <table class="table table-hover">
                            <thead style="background:#ddd;">
                                <tr>
                                    <th>Sr.No.</th>
                                    <?php if (!@$selected_columns_students) { ?>
                                        <th>SID</th>
                                        <th>Student Name</th>
                                        <th>Father Name</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>Village</th>
                                        <th>Amount</th>
                                        <th>Amount Recived</th>
                                        <th>Late Fee</th>
                                        <th>Balance</th>
                                        <th>Sms Mobile NO</th>

                                    <?php } else { ?>
                                        <?php if (in_array('SID', $selected_columns_students)) { ?><th>SId</th><?php } ?>
                                        <?php if (in_array('StudentName', $selected_columns_students)) { ?><th>Student Name</th><?php } ?>
                                        <?php if (in_array('FatherName', $selected_columns_students)) { ?><th>Father Name</th><?php } ?>
                                        <?php if (in_array('Class', $selected_columns_students)) { ?><th>Class</th><?php } ?>
                                        <?php if (in_array('section', $selected_columns_students)) { ?><th>section</th><?php } ?>
                                        <?php if (in_array('Village', $selected_columns_students)) { ?><th>Village</th><?php } ?>
                                        <?php if (in_array('FeeAmt', $selected_columns_students)) { ?><th>Amount</th><?php } ?>
                                        <?php if (in_array('Amt', $selected_columns_students)) { ?><th>Amount Recived</th><?php } ?>
                                        <?php if (in_array('LateFee', $selected_columns_students)) { ?><th>Late Fee</th><?php } ?>
                                        <?php if (in_array('Bal', $selected_columns_students)) { ?><th>Balance</th><?php } ?>
                                        <?php if (in_array('MobileSMS', $selected_columns_students)) { ?><th>Sms Mobile NO</th><?php } ?>

                                    <?php } ?>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <?php
                            $i = 1;
                            while ($rowv = $students->fetch(PDO::FETCH_ASSOC)) {
//                                print_r($rowv);
//                                exit();
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <?php if (!@$selected_columns_students) { ?>
                                        <td><?= $rowv['SID']; ?></td>
                                        <td><?= $rowv['StudentName']; ?></td>
                                        <td><?= $rowv['FatherName']; ?></td>
                                        <td><?= $rowv['class']; ?></td>
                                        <td><?= $rowv['section']; ?></td>            
                                        <td><?= $rowv['Village']; ?></td>
                                        <td><?= $rowv['FeeAmt']; ?></td>
                                        <td><?= $rowv['Amt']; ?></td>
                                        <td><?= $rowv['LateFee']; ?></td>
                                        <td><?= $rowv['Bal']; ?></td>
                                        <td><?= $rowv['MobileSMS']; ?></td>
                                    <?php } else { ?>
                                        <?php if (in_array('SID', $selected_columns_students)) { ?><td><?= $rowv['SID']; ?></td><?php } ?>
                                        <?php if (in_array('StudentName', $selected_columns_students)) { ?> <td><?= $rowv['StudentName']; ?></td><?php } ?>
                                        <?php if (in_array('FatherName', $selected_columns_students)) { ?><td><?= $rowv['FatherName']; ?></td><?php } ?>
                                        <?php if (in_array('Class', $selected_columns_students)) { ?> <td><?= $rowv['Class']; ?></td><?php } ?>
                                        <?php if (in_array('section', $selected_columns_students)) { ?> <td><?= $rowv['section']; ?></td><?php } ?>
                                        <?php if (in_array('Village', $selected_columns_students)) { ?><td><?= $rowv['Village']; ?></td><?php } ?>
                                        <?php if (in_array('FeeAmt', $selected_columns_students)) { ?><td><?= $rowv['FeeAmt']; ?></td><?php } ?>
                                        <?php if (in_array('Amt', $selected_columns_students)) { ?><td><?= $rowv['Amt']; ?></td><?php } ?>
                                        <?php if (in_array('LateFee', $selected_columns_students)) { ?><td><?= $rowv['LateFee']; ?></td><?php } ?>
                                        <?php if (in_array('Bal', $selected_columns_students)) { ?><td><?= $rowv['Bal']; ?></td><?php } ?>
                                        <?php if (in_array('MobileSMS', $selected_columns_students)) { ?><td><?= $rowv['MobileSMS']; ?></td><?php } ?>
                                    <?php } ?>     <td><a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $rowv['SID']; ?>" data-ms="modal" data-title="Student Profile">View</a></td>


                                </tr>
                                <?php
                                $i++;
                            }
                            ?>
                        </table>
                        <?php
                    } else {
                        echo '<div class="text-center margin">No records found.</div>';
                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
                    <?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<!-- Main content -->
<?php
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});   
}); 
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>

