<section class="content">
    <div class="row">
        <style>.error
            {
                border:1px solid red;
            }</style>      <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <!--//headder-->
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-12">                   
                            <h3 class="box-title"> Academic performance List</h3>
                            <h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal" data-target="#myModal">Add Term Attendance</button></h3>
                        </div>   
                        <div class="col-md-9"> </div>
                    </div>
                    <br><div class="row">

                        <form class="form-inline" method="post" id="exam_add_academic_performance_form_id">
                            <input type="hidden" value="test" name="form_term"> 
                            <div class = "col-md-3">
                                <label for="exampleInputName2">    Select Class  : </label>
                                <select id="class_id" name="class_id" class="form-control wth_div" onchange="this.form.submit()" >
                                    <?php
                                    if ($oCurrentUser->ulevel == 9) {
                                        foreach ($classs as $class) {
                                            if (@$class_selected == $class['class_no']) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $class['class_no']; ?>" <?= $selected ?> > <?= $class['class_name']; ?> </option>
                                            <?php
                                        }
                                    } else {
                                        foreach ($teach_classes as $class_no => $class_name) {
                                            if (@$class_selected == $class_no) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $class_no ?>" <?= $selected ?> > <?= $class_name ?> </option>
                                            <?php
                                        }
                                    }
                                    if (@$class_selected || @$class_selected != NULL) {
                                        
                                    } else {
                                        ?>
                                        <option value="" selected="selected" >
                                            Select Class
                                        </option>
                                    <?php } ?>   
                                </select>
                            </div>
                            <div class = "col-md-3">
                                <label for="exampleInputName2">   Section : </label>
                                <select  name="section_id" id="section_id" class="form-control wth_div" onchange="this.form.submit()">
                                    <?php
                                    $sec = Master::get_sections($MSID, '', @$class_selected);
                                    $sect = $sec->rowcount();
                                    if ($sect > 1) {
                                        echo "yes";
                                        $sections = $sec->fetchAll(PDO::FETCH_ASSOC);
                                        foreach ($sections as $section) {
                                            if (@$selected_section == $section['id']) {
                                                $selected_sec = 'selected = "selected"';
                                                //die("<>>");
                                            } else {
                                                $selected_sec = "";
                                            }
                                            ?>
                                            <option value="<?= $section['id']; ?>" <?= $selected_sec ?> >
                                                <?= $section['sec_name']; ?>
                                            </option>
                                            <?php
                                        }
                                    } else {
                                        ?>
                                        <option>A</option><?php }
                                    ?> 
                                </select>
                            </div>

                            <?php
                            if ($oCurrentSchool->no_of_term != '0') {
                                ?>

                                <div class="col-md-3">

                                    <label for="exampleInputName2">Term : </label>
                                    <select id="term" name="term" class="form-control wth_div" onchange="this.form.submit()">
                                        <b> Select Term : - </b>

                                        <option value="1" <?php
                                        if (@$term_selected) {
                                            echo ($term_selected == '1') ? 'selected = "selected"' : "";
                                        }
                                        ?>>Term1</option>
                                                <?php
                                                if ($oCurrentSchool->no_of_term == '2') {
                                                    ?>
                                            <option value="2" <?php
                                            if (@$term_selected) {
                                                echo ($term_selected == '2') ? 'selected = "selected"' : "";
                                            }
                                            ?>>Term2</option><?php
                                                }
                                                if ($oCurrentSchool->no_of_term == '3') {
                                                    ?>
                                            <option value="2" <?php
                                            if (@$term_selected) {
                                                echo ($term_selected == '2') ? 'selected = "selected"' : "";
                                            }
                                            ?>>Term2</option>
                                            <option value="3" <?php
                                            if (@$term_selected) {
                                                echo ($term_selected == '3') ? 'selected = "selected"' : "";
                                            }
                                            ?>>Term3</option>
                                                    <?php
                                                }
                                                ?>   

                                    </select>
                                </div>
                                <?php
                            }
                            ?>
                        </form>
                    </div>
                </div>
                <!-- /.box-header -->
                <?php
                if (@$class_id != NULL) {
                    $data = array(
                        'class' => $class_id
                    );
                    $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
                    $totalrecords_students = $students->rowCount();
                    ?>      <div class="box-body table-responsive no-padding"> 
                        <form class="form-inline " method="post" id="form_attend">     
                            <input type="hidden" value="xxx" name="add_term_atnd">
                            <input type="hidden" value="<?= $MSID ?> " name="MSID">
                            <input type="hidden" value="<?= $class_id ?> " name="class_id">
                            <input type="hidden" value="<?= $section ?> " name="section">
                            <input type="hidden" value="<?= $term ?> " name="term">   
                            <input type="hidden" value="<?= $tw_days ?> " name="tw_days">
                            <table class="table table-hover">
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>Student Id  </th> 
                                    <th>Student Name </th>   
                                    <th>Attended Days </th> 
                                    <th>Total Days </th> 

                                </tr>
                                <?php
                                $i = 1;
                                while ($rowv = $students->fetch()) {
                                    ?>
                                    <tr>
                                        <td><?= $i ?></td>
                                        <th><?= $rowv['student_id']; ?></th>
                                        <th><?= $rowv['name']; ?></th>  
                                        <th><input type="text"  class="ttl_dats"  data-id="<?= $tw_days; ?>" value="0" name="attended_days[]" ></th>  
                                    <input type="hidden"  value="<?= $rowv['student_id'] ?>" name="id[<?= $rowv['student_id'] ?>]" />
                                    <input type="hidden"  value="<?= $oCurrentUser->mysession ?>" name="session" >

                                    <th><?= $tw_days; ?></th>
                                    </th>
                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </table>

                            <!--<div class="row">-->
                            <div class="col-md-7"><div id="error_div"> </div> </div> 
                            <div class="col-md-3">
                                <a id="btn_submit_id1" name="add_term_attendance" class="btn btn-lg btn-success btn-block">Submit</a>
                            </div> <div class="col-md-1"></div>
                            <!-- \col -->
                            <!--</div>-->
                        </form> </div>
                    <?php
                } else {
                    ?><div class="box-body table-responsive no-padding"> 
                        <form class="form-inline " method="post" id="exam_add_academic_performance_formid">     
                            <input type="hidden" value="xxx" name="academic_performance_posted_form">
                            <input type="hidden" value="<?= $MSID ?> " name="MSID">
                            <?php
                            if ($totalrecord_existing > 0) {
                                ?> <table class="table table-hover">
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Class  </th> 
                                        <th>Section  </th> 
                                        <th>Term </th>   
                                        <th>Total Working Days </th> 
                                        <th>Action </th> 

                                    </tr>
                                    <?php
                                    $i = 1;



                                    while ($rowv = $existing_attendance->fetch()) {

                                        print_r($rowv);
                                        $attendance = Attendance::get_exam_attendance($MSID, '', @$term_selected, '', '', $oCurrentUser->mysession, @$class_selected, @$secion_selected)->fetch(PDO::FETCH_ASSOC);
//print_r($rowv);
                                        $class_name = Master::get_classes($MSID, '', '', '', $rowv['class'])->fetch(PDO::FETCH_ASSOC);
                                        $section_name = Master::get_sections($MSID, $rowv['section'])->fetch(PDO::FETCH_ASSOC);
                                        ?>
                                        <input type="hidden" value="<?= $attendance['class'] ?> " name="class">
                                        <input type="hidden" value="<?= $attendance['section'] ?> " name="section">
                                        <input type="hidden" value="<?= $attendance['term'] ?> " name="term">
                                        <input type="hidden" value="<?= $attendance['max_marks'] ?> " name="max_marks">
                                        <tr>
                                            <td><?= $i ?></td>
                                            <th><?= $class_name['class_name']; ?></th>
                                            <th><?= $section_name['sec_name'] ?></th>  
                                            <th><?php echo ($attendance['term'] == 1) ? "Term 1" : "Term 2"; ?></th>  
                                            <th><?= $attendance['tw_days']; ?></th>  

                                            <?php
                                            if ($totalrecord_existing > 0) {
                                                ?>
                                                <th> <a  href="<?= CLIENT_URL; ?>" name="edit_performance" class="btn btn-sm btn-warning" >Edit Performance</a>
                                                    &nbsp; <a data-bb="confirm" class="btn btn-danger btn-flat" href="<?= CLIENT_URL; ?>/academic-performance/del/<?= $rowv['class'] ?>/<?= $rowv['assesment_id'] ?>/<?= $rowv['activity_id'] ?>/<?= $rowv['subject_id'] ?>">Delete</a>
                                                </th>
                                            <?php } ?>   

                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </table>   <?php
                            } else {
                                echo '<div class="text-center margin">No records found.</div>';
                            }
                            ?>
                            <!--<div class="row">-->

                            <!-- \col -->
                            <!--</div>-->
                        </form> </div>

                    <?php
                }
                ?>
            </div>
        </div>
        <!-- /.box -->
    </div>

    <div class="modal fade" tabindex="-1" role="dialog" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Add Term Attendance</h4>
                </div>
                <div class="modal-body">
                    <form method="post" action="" role="form" id="onajaxForm">
                        <input type="hidden" name="add_term_Attendance" value="true" />

                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <input type="hidden" name="type" value="exam_grade" />
                        <div class="box-body">


                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Class </label>
                                        <select id="class_id_get1" name="class_id" class="form-control " >

                                            <?php
                                            foreach ($classs as $class) {
                                                if ($selected_class == $class['class_no']) {
                                                    $selected = 'selected = "selected"';
                                                } else {
                                                    $selected = "";
                                                }
                                                ?>

                                                <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                    <?= $class['class_name']; ?>
                                                </option>
                                                <?php
                                            }
                                            if (@$selected_class || @$selected_class != NULL) {
                                                
                                            } else {
                                                ?>
                                                <option value="" selected="selected" >
                                                    Select Class
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <!-- \col --> 
                            </div>
                            <div id="show_content_div1">

                            </div>
                            <label for="exampleInputName2">Select Term : </label>
                            <select id="term" name="term" class="form-control "  >
                                <b> Select Term : - </b>
                                <option value="1" <?php ?> >Term 1</option>
                                <option value="2" <?php ?>  >Term 2</option>
                            </select>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Total Working Days</label>


                                        <input class="form-control" type="text" name="tw_days" id="tw_days" value="" />
                                    </div>
                                </div>
                                <!-- \col --> 
                            </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="submit">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</section>




<?php // }      ?>
<script src="http://www.flamedevelopers.com/mountshivalik/plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script>
                                    $(document).ready(function ()
                                    {
                                        // validation on blur
                                        $('.ttl_dats').blur(function () {
                                            var attended = $(this).val();
                                            var max = $(this).data('id');
                                            if (attended == '') {
                                                $(this).addClass('error');
                                            } else if (attended <= max) {
                                                $(this).removeClass('error');
                                            } else {
                                                $(this).addClass('error');
                                            }

                                        });

                                        //validation on submit
                                        $('#btn_submit_id1').click(function () {
                                            $('#error_div .errorDiv').remove();
                                            if ($(".ttl_dats").hasClass("error")) {
                                                $("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');

                                            } else {
                                                $('#form_attend').submit();
                                            }
                                        });


                                        // model for add
                                        $('#myModal').on('click', '#submit', function () {
                                            $('#ajaxForm .errorDiv').remove();
                                            var errors = '';
                                            var class_id = $("#class_id_get1");
                                            var section = $("#section_id1");
                                            var term = $("#term");
                                            var tw_days = $("#tw_days");
//            alert(section);
                                            if (class_id.val() == '') {
                                                class_id.parent('.form-group').addClass('has-error');
                                                errors = 'true';
                                            } else {
                                                class_id.parent('.form-group').removeClass('has-error');
                                            }
                                            if (section.val() == '') {
                                                section.parent('.form-group').addClass('has-error');
                                                errors = 'true';
                                            } else {
                                                section.parent('.form-group').removeClass('has-error');
                                            }
                                            if (term.val() == '') {
                                                term.parent('.form-group').addClass('has-error');
                                                errors = 'true';
                                            } else {
                                                term.parent('.form-group').removeClass('has-error');
                                            }
                                            if (tw_days.val() == '') {
                                                tw_days.parent('.form-group').addClass('has-error');
                                                errors = 'true';
                                            } else {
                                                tw_days.parent('.form-group').removeClass('has-error');
                                            }
                                            if (errors != '') {
                                                $("#onajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                                                return false;
                                            }
                                            $('#onajaxForm').submit();

                                            return false;
                                        });

                                        // select class section
                                        $("#class_id_get1").change(function ()
                                        {

                                            var class_id = $(this).val();

                                            //alert(class_id);
                                            var siteurl = "<?php echo CLIENT_URL ?>";
                                            $.ajax({
                                                url: siteurl + "/exam-load/section_select",
                                                type: "post",
                                                data: {classid: class_id},
                                                success: function (response) {
                                                    //alert(response);
                                                    $("#show_content_div1").html('');
                                                    $("#show_content_div1").html(response);

                                                },
                                                error: function (jqXHR, textStatus, errorThrown) {
                                                    console.log(textStatus, errorThrown);
                                                    alert(errorThrown);

                                                }


                                            });
                                        });
                                    });
</script>