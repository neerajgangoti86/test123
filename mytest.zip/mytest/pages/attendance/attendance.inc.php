
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                    <div class="row">
                        <div class="col-md-4">
                            <h3 class="box-title">
                                <?php
                                if ($type == 'present') echo "Present Student List";
                                else if ($type == 'absent') echo "Absent Student List";
                                else if ($type == 'leave') echo "Leave Student List";
                                else if ($type == 'holiday') echo "holiday Student List";
                                else
                                    {
                                    echo "Absent and Leave Students List";
                                    }
                                ?>

                            </h3>
                        </div>
                        <div class="col-md-6"> </div>
                        <div class="col-md-2"> 
                            <?php
                            if (@http_get("param5") == "view")
                                {
                                ?><ul class="nav nav-pills">
                                    <li class="dropdown">
                                        <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                                        <ul class="dropdown-menu">
                                            <li><a  href="javascript:void(0);" title="Export to Excel" onclick="$('#attend_reports').tableExport({type: 'excel', escape: 'false'});"><img src="<?= ASSETS_FOLDER ?>/img/excel.png" title="export to excel" width="30" height="30"/></a></li>
                                            <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                                                </a></li>
                                            <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                                            </li>

                                        </ul>
                                    </li>
                                </ul>
                            <?php } ?>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding ">

                        <div class="col-md-6">
                            <form class="form-inline right_ft" method="post" id="attendance_form_id">

                                <?php
                                if (http_get("param1") != "all")
                                    {
                                    ?>    <div class="col-md-6">
                                        <input type="hidden" name="attendanceFrm" value="xxx" />
                                        <label for="exampleInputName2">Select Class : </label>
                                        <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()'>
                                            <?php $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                            ?>
                                            <b> Select Class : -<?php echo @$selected_class; ?> </b>
                                            <?php
                                            foreach ($classs as $class)
                                                {
                                                if (@$selected_class == $class['class_no'])
                                                    {
                                                    $selected = 'selected = "selected"';
                                                    }
                                                else
                                                    {
                                                    $selected = "";
                                                    }
                                                ?>
                                                <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                                    <?= $class['class_name']; ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>

                                    <?php
                                    if ($oCurrentSchool->section > 1)
                                        {
                                        ?>
                                        <div class="col-md-6">
                                            <?php
                                            $class_section = student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class)->fetchAll();
                                            ?>
                                            <label for="exampleInputName2">Select Section : </label>
                                            <select id="section_id" name="section_id" class="form-control wth_div"  onchange='this.form.submit()'>

                                                <?php
                                                $sections = Master::get_schools_section($MSID)->fetchAll(PDO::FETCH_ASSOC);


//                  print_r($sections);
                                                ?>
                                                <b> Select Class : - </b>
                                                <?php
                                                foreach ($class_section as $section)
                                                    {

                                                    $section_details = Master::get_schools_section($MSID, $section['section'])->fetch();

                                                    if (@$selected_section == $section['section'])
                                                        {
                                                        $selected = 'selected = "selected"';
                                                        }
                                                    else
                                                        {
                                                        $selected = "";
                                                        }
                                                    ?>
                                                    <option value="<?= $section['section']; ?>" <?= $selected ?> >
                                                        <?= $section_details['sec_name']; ?>
                                                    </option>
                                                <?php } ?>
                                            </select>

                                        </div>  
                                        <?php
                                        }
                                    else
                                        {
                                        ?>
                                        <input type="hidden" name="section_id" value="1">
                                        <?php
                                        }
                                    ?>
                                <?php } ?>          </form>
                        </div>

                        <div class="col-md-3">
                            <h2>
                                <?php
                                $date = $oCurrentUser->mydate;
                                echo date('F', strtotime($date)) . ", " . (($date) ? date('Y', strtotime($date)) : $_SESSION['year']);
                                ?>
                            </h2>
                        </div>
                        <div class="col-md-3">  <?php
                            if (http_get("param5") != "view")
                                {
                                ?><h3 class="box-title"> <a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL; ?>/attendances/today"> Save  Attendance</a>
                                </h3><?php } ?>
                        </div>
                        <div class=" report_export"><table class="table" id="attend_reports" >
                                <tbody>
                                    <tr class="Top">
                                        <td>Sr.No</td>
                                        <?php
                                        if ($oCurrentSchool->Roll_No == 1)
                                            {
                                            ?>  <td>Roll No</td><?php
                                            }
                                        else
                                            {
                                            ?><td>Adm No</td><?php } ?>
                                        <td align="center">Name</td>


                                        <?php
                                        foreach ($listdays as $list)
                                            {
                                            $today = $year . ":" . $month . ":" . $list;
                                            if ($today == date('Y-m-d'))
                                                {
                                                $colour = "background:  greenyellow";
                                                $today_date_day = $list;
                                                }
                                            else
                                                {
                                                $colour = "";
                                                }
                                            ?>
                                            <?php
//                                    if ($oCurrentSchool->section > 1) {
//                                        
                                            ?>
                                                                                                                                                                                                                                                                                                                <!--<th  align="center" >Section-->
                                            <?php
//                                            if ($oCurrentSchool->section > 1) {
//                                                @$get_secton_name = Master::get_schools_section($MSID, $selected_section)->fetch();
//                                                echo @$get_secton_name['sec_name'];
//                                            }
//                                            
                                            ?>
                                            <!--</th>-->
                                            <?php
//                                    }
                                            ?>

                                            <td style="<?= $colour ?>" align="center" ><span><?php echo $date = date('d', strtotime($oCurrentUser->mydate)); ?></span></td>
                                            <td></td>      <?php
                                            }
                                        ?>
                                    </tr>
                                    <?php
                                    if (@http_get("param5") != "view")
                                        {
                                        ?><tr class="Top">
                                            <td></td>
                                            <td  align="center" ></td>
                                            <td  align="center" ></td>
                                            <?php
                                            if ($oCurrentSchool->section > 1)
                                                {
                                                ?> 
                                                                                                                                                                                                                <!--<td> &nbsp;</td>-->
                                            <?php } ?>
                                            <td>
                                                <div id="Demo"> <input id="present-check" class="checkall"  name="checkall" type="radio" <?php if ($type == "present") echo 'checked="checked"'; ?> value='p'> &nbsp;Present&nbsp;&nbsp;&nbsp;&nbsp;Absent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Leave&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php if ($type == "redirect")
                                            { ?><input  <?php if ($type == "holiday") echo 'checked="checked"'; ?> id="holiday-check" name="checkall"  class="checkall" type="radio" value='h'> Holiday <?php } ?>
                                                </div></td>
                                            <?php
                                            $colour_check_var = 1;


                                            foreach ($days as $list)
                                                {
                                                $colour_check = ($today_date_day == $colour_check_var) ? "greenyellow" : "";
                                                ?>
                                                <td style="background:  <?= $colour_check ?>" align="center" ><?php echo $date = date('l', strtotime($oCurrentUser->mydate)); ?></td>
                                                <?php
                                                $colour_check_var++;
                                                }
                                            ?>

                                        </tr><?php } ?>

                                    <?php
                                    @$get_holidays = Student::check_holiday($MSID, $oCurrentUser->mydate);
                                    if (@$get_holidays->rowCount() == 0)
                                        {
                                        ?>
                                        <tr>
                                            <td colspan="4" align="center"> Not A Working Day</td>   
                                        </tr>   

                                        <?php
                                        }
                                    else
                                        {
                                        ?>

                                        <?php
                                        $sr_no = 1;
                                        while ($row = $count_result->fetch())
                                            {
//                                    print_r($row);
                                            if (@http_get("param5") == "view")
                                                {
                                                $datecheck = $oCurrentUser->mydate;
                                                if ($att == "All")
                                                    {
                                                    $getattdata = array('AttDate' => "'" . $datecheck . "'", 'role' => "'student'");
                                                    }
                                                else
                                                    {
                                                    $getattdata = array('AttDate' => "'" . $datecheck . "'", 'role' => "'student'", 'Att' => "'" . @$att . "'");
                                                    }
                                                $attendance = Attendance::get_attendances($MSID, $row['student_id'], $getattdata);
                                                $absent = $attendance->fetch();
                                                if (($absent['Att'] == "A") || ($absent['Att'] == "L"))
                                                    {
                                                    ?>    <tr>
                                                        <td><?= $sr_no ?></td>
                                                        <td align="center"><?php echo $row['name'] ?><?php // echo $row['student_id']                                                                       ?></td>

                                                        <?php
                                                        $today_date = 0;
                                                        for ($i = 1; $i <= count($listdays); $i++)
                                                            {
                                                            if ($day_format == 'y')
                                                                {
                                                                $today_date = $i;
                                                                }
                                                            else if ($day_format == 'd')
                                                                {
                                                                $today_date = $start_date;
                                                                }
                                                            else
                                                                {
                                                                $today_date = $start_date + $i - 1;
                                                                }

                                                            $title = ($absent != "") ? ("Reason : " . $absent['Reason']) : "";
                                                            $colour_check = ($absent != "") ? (($absent['Att'] == "Absent") ? "red" : "blue") : (($today_date_day == $i) ? "greenyellow" : "");
                                                            ?>
                                                            <td align="center" style="background:">
                                                                <?php
                                                                if ($absent['Att'] == NULL)
                                                                    {
                                                                    echo "Present";
                                                                    }
                                                                elseif ($absent['Att'] == "A")
                                                                    {
                                                                    echo "Absent";
                                                                    }
                                                                else
                                                                    {
                                                                    echo"Leave";
                                                                    }
                                                                ?>
                                                                </a></td>
                                                            <td  align="center" id="rowid_<?= $row['student_id'] ?>">

                                                                <?php
                                                                if (@$absent['Reason'] != '')
                                                                    {
//                                                                                                                                                                                                                                                                                                                                 pr($absent['Reason']);
                                                                    ?>
                                                                    <a href="javascript:void(0);" id="<?= $row['student_id'] ?>" class="att_link"><?php echo @$absent['Reason']; ?></a>
                                                                    <?php
                                                                    }
                                                                }
                                                            ?>
                                                    </tr>

                                                    <?php
                                                    }
                                                }
                                            else
                                                {
                                                ?>
                                                <tr>
                                                    <td><?= $sr_no ?></td>
                                                    <?php
                                                    if ($oCurrentSchool->Roll_No == 1)
                                                        {
                                                        ?>  <td><?php echo $row['roll_no']; ?></td><?php
                                                        }
                                                    else
                                                        {
                                                        ?><td><?php echo $row['student_id']; ?></td><?php } ?>
                                                    <td><?php echo $row['name'] ?><?php // echo $row['student_id']                                                                      ?></td>

                                                    <?php
                                                    $today_date = 0;
                                                    for ($i = 1; $i <= count($listdays); $i++)
                                                        {
                                                        if ($day_format == 'y')
                                                            {
                                                            $today_date = $i;
                                                            }
                                                        else if ($day_format == 'd')
                                                            {
                                                            $today_date = $start_date;
                                                            }
                                                        else
                                                            {
                                                            $today_date = $start_date + $i - 1;
                                                            } $datecheck = $oCurrentUser->mydate;
                                                        if ($att == "All")
                                                            {
                                                            $getattdata = array('AttDate' => "'" . $datecheck . "'", 'role' => "'student'");
                                                            }
                                                        else
                                                            {
                                                            $getattdata = array('AttDate' => "'" . $datecheck . "'", 'role' => "'student'", 'Att' => "'" . @$att . "'");
                                                            }
                                                        $attendance = Attendance::get_attendances($MSID, $row['student_id'], $getattdata);
                                                        $absent = $attendance->fetch();
                                                        $title = ($absent != "") ? ("Reason : " . $absent['Reason']) : "";
                                                        $colour_check = ($absent != "") ? (($absent['Att'] == "Absent") ? "red" : "blue") : (($today_date_day == $i) ? "greenyellow" : "");
//                                                        pr($absent['Att']);
                                                        ?>
                                                        <td><input type="radio"  align="center" class="present attend" name="<?= $row['student_id'] ?>" id="p_<?= $row['student_id'] ?>" checked="checked"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  class="attend" type="radio" name="<?= $row['student_id'] ?>" id="a_<?= $row['student_id'] ?>"
                                                            <?php
                                                            if (@$absent['Att'] == "A")
                                                                {
                                                                echo "checked='checked'";
                                                                }
                                                            ?>/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  class="attend"  type="radio" name="<?= $row['student_id'] ?>" id="l_<?= $row['student_id'] ?>"
                                                                                                                                                                                                                                                                                                                                                        <?php
                                                                                                                                                                                                                                                                                                                                                        if (@$absent['Att'] == "L")
                                                                                                                                                                                                                                                                                                                                                            {
                                                                                                                                                                                                                                                                                                                                                            echo "checked='checked'";
                                                                                                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                                                                                                        ?> > <?php if ($type == "redirect")
                                                                                                                                                                                                                                                                                                                                            { ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="radio" class="attend holiday" name="<?= $row['student_id'] ?>" id="h_<?= $row['student_id'] ?>"                                                                                                                   <?php
                                                                                                                                                                                                                                                                                                                                                            if (@$absent['Att'] == "H")
                                                                                                                                                                                                                                                                                                                                                                {
                                                                                                                                                                                                                                                                                                                                                                echo "checked='checked'";
                                                                                                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                                                                                            ?> >    <?php } ?> <td  align="center" id="rowid_<?= $row['student_id'] ?>">

                                                            <?php
                                                            if (@$absent['Reason'] != '')
                                                                {
                                                                ?>
                                                                <a href="javascript:void(0);" id="<?= $row['student_id'] ?>" class="att_link"><?php echo @$attend['Reason']; ?></a>
                                                                <?php
                                                                }
                                                            else
                                                                {
                                                                ?>

                                                                <a href="javascript:void(0);" id="<?= $row['student_id'] ?>" class="att_link">Reason For Absent</a></td>

                                                            <?php
                                                            }
                                                        }
                                                    ?>
                                                </tr>
                                                <?php
                                                } $sr_no++;
                                            }
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div></div>
                </div>
                <!-- /.box -->
            </div>
        </div>
</section>

<?php
if (@http_get("param1") != "all")
    {
    @$get_classes_name = Master::get_class_names($MSID, $selected_class)->fetch();
    @$get_secton_name = Master::get_schools_section($MSID, $selected_section)->fetch();
    }
?>
<input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
<input type="hidden" name="select_sec" value="<?= @$get_secton_name['sec_name'] ?>" id="select_sec"/>
<input type="hidden" name="select_class" value="<?= @$get_classes_name['class_name'] ?>" id="select_class"/>
<?php
$aturl = CLIENT_URL . '/attendances';
//                                        $sBottomJavascript = <<<EOT
?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript">
                                                $(document).ready(function () {

//        alert("Sad");
                                                    $('.attendance_date').datepicker({
                                                        format: 'yyyy-mm-dd',
                                                        todayHighlight: true,
                                                        startDate: "$ses_str_dt",
                                                        endDate: "$ses_end_dt",
                                                        clearBtn: true
                                                    });
                                                    $('.attendance_date').change(function () {
                                                        this.form.submit();
                                                    });

                                                    $('body').on('click', '[data-ms="modal"]', function (e) {
                                                        $("a").removeClass("abc");
                                                        $(this).addClass("abc");

                                                        var link = $(this);
                                                        var options = {
                                                            url: link.attr("href"),
                                                            title: link.attr("data-title"),
                                                            size: 'md'
                                                        };
                                                        eModal.setEModalOptions({
                                                            loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
                                                        });
                                                        eModal.ajax(options);
                                                        return false;
                                                    });

                                                    $(".att_link").click(function ()
                                                    {
                                                        var a = $(this).attr('id');

                                                        $("#rowid_" + a).append('<input type="text" placeholder="Please enter reason for absent" name="reason[]" id="reason_' + a + '" onblur="reason_text(' + a + ')" class="reason_textbox"/>');

                                                        $("a#" + a).hide();



                                                    });
//        alert("hf");
                                                    $('.attend').click(function ()
                                                    {
                                                        var stu_id = $(this).attr('name');
                                                        var id = $(this).attr('id');

                                                        var split_name = id.split("_");

                                                        var siteurl = $('#site_url').val();

                                                        var section = $("#select_sec").val();

                                                        var classes = $("#select_class").val();
//    var type = $(".checkall").val();
//                                                       alert("dsa");
                                                        if (split_name[0] == "a" || split_name[0] == "l")
                                                        {

                                                            $("#present-check").prop('checked', false);
                                                            $("#holiday-check").prop('checked', false);
                                                        }
//                                                        var type = $('input[name="checkall"]:checked', '#Demo').val();
                                                        //alert(type);
                                                        var datastring = 'id=' + stu_id + '&attend=' + split_name[0] + '&section=' + section + '&class=' + classes;
                                                        $.ajax({
                                                            url: siteurl + "/ajax-page-load/attend_post",
                                                            type: "POST",
                                                            data: datastring,
                                                            success: function (response)
                                                            {
//                                                                alert(response);

                                                                //  alert(response);

                                                                /* $('#locality').append(response);
                                                                 location.reload();
                                                                 eModal.close();
                                                                 */

                                                            },
                                                            error: function (jqXHR, textStatus, errorThrown) {
                                                                console.log(textStatus, errorThrown);
                                                            }


                                                        });

                                                    });

                                                });

</script>
<script type="text/javascript">
    function reason_text(id)
    {
        var text_box = $("#reason_" + id).val();

        var siteurl = $('#site_url').val();

        var section = $("#select_sec").val();

        var classes = $("#select_class").val();

        var datastring = 'id=' + id + '&reason=' + text_box + '&section=' + section + '&class=' + classes;

        //alert(datastring);

        $.ajax({
            url: siteurl + "/ajax-page-load/attendance_post",
            type: "POST",
            data: datastring,
            success: function (response)
            {
                //alert(response);
                if (response == '')
                {
                } else
                {
                    $("input#reason_" + id).hide();
                    $("#rowid_" + id).append('<a href="javascript;" id="' + id + '" class="att_link" >' + text_box + '</a>');

                    // $("#rowid_"+id).html(response);
                }
                // alert(response);

                /* $('#locality').append(response);
                 location.reload();
                 eModal.close();
                 */

            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }


        });




    }
</script>      
<script type="text/javascript">
    $(function () {

        $('#holiday-check').click(function (event) {
            var siteurl = $('#site_url').val();
            var section = $("#select_sec").val();
            var section_id = $("#section_id").val();
            var class_name = <?php echo "'" . $class_name . "'"; ?>;
            var att = <?php echo "'" . $att . "'"; ?>;
            var page_name = <?php echo "'" . $type . "'"; ?>;
            var classes = $("#select_class").val();
            var datastring = 'section=' + section + '&class=' + classes + '&section_id=' + section_id + '&class_name=' + class_name + '&att=' + att + '&page_name=' + page_name;
            console.log(datastring);
            $.ajax({
                url: siteurl + "/ajax-page-load/holiday_for_all",
                type: "POST",
                data: datastring,
                success: function (response)
                {
                    console.log(response);
//                    alert(response);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log(textStatus, errorThrown);
                }
            });
            if (this.checked) {
                $('.holiday').each(function () {
                    this.checked = true;
                });
            }
        });
        $('#present-check').click(function (event) {
            var siteurl = $('#site_url').val();
            var section = $("#select_sec").val();
            var section_id = $("#section_id").val();
            var class_name = <?php echo "'" . $class_name . "'"; ?>;
            var page_name = <?php echo "'" . $type . "'"; ?>;
            var att = <?php echo "'" . $att . "'"; ?>;
            var classes = $("#select_class").val();
            var datastring = 'section=' + section + '&class=' + classes + '&section_id=' + section_id + '&class_name=' + class_name + '&att=' + att + '&page_name=' + page_name;
            console.log(datastring);
            $.ajax({
                url: siteurl + "/ajax-page-load/present_for_all",
                type: "POST",
                data: datastring,
                success: function (response)
                {
                    console.log(response);
//                    alert(response);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log(textStatus, errorThrown);
                }
            });
            if (this.checked) {
                $('.present').each(function () {
                    this.checked = true;
                });
            }
        });

    });
</script>
<?php
//EOT;
//                                        $oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
