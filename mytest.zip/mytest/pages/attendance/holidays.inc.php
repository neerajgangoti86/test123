<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Holidays List</h3>
                    <h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal" data-target="#myModal">Add Holiday</button></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <?php
                    if ($totalrecords > 0)
                        {
                        ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Holiday Name</th>
                                <th>Date From</th>
                                <th>Date To</th>

                                <th>Action</th>
                            </tr>
                            <?php
                            $i = 1;
                            while ($rowv = $attendance->fetch())
                                {
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <th style="background: <?= $rowv['colour']; ?>"><?= $rowv['Particular']; ?></th>
                                    <th><?= $rowv['DateFrom']; ?></th>
                                    <th><?= $rowv['DateTo']; ?></th>

                                    <td><a class="btn btn-info btn-flat" data-title="Edit Holiday" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax-page-load/update_holdays/<?php echo $rowv['holiday_id']; ?>">Edit</a>&nbsp;
                                        &nbsp; <a data-bb="confirm" class="btn btn-danger btn-flat" href="<?= CLIENT_URL; ?>/attendances/delete/<?php echo $rowv['holiday_id']; ?>">Delete</a></td>

                                </tr>
                                <?php
                                $i++;
                                }
                            ?>
                        </table>
                        <?php
                        }
                    else
                        {
                        echo '<div class="text-center margin">No records found.</div>';
                        }
                    ?>
                </div>
                <div class="box-footer clearfix">

                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Add New Holiday</h4>
                </div>
                <div class="modal-body">
                    <form method="post" action="" role="form" id="onajaxForm">
                        <input type="hidden" name="add_holiday" value="true" />
                        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                        <div class="row">
                            <div class="col-md-12"><div class="form-group">
                                    <label>Holliday Name<span class="text-red">*</span></label>
                                    <input class="form-control" type="text" size="30" id="holiday_name" name="holiday_name" required/>
                                </div>
                            </div>


                            <div class="form-group">
                                <lable> Select Color</lable> <input type="color" name="colour"  value="#FFFFFF">
                            </div>
                            <div class="col-md-12"><div class="form-group">
                                    <label>Date Start From<span class="text-red">*</span></label>
                                    <input class="form-control adm_date" type="text" size="30" id="date_start" name="date_from" required="required"/>
                                </div>
                            </div> 

                            <div class="col-md-12"><div class="form-group">
                                    <label>Date Start To<span class="text-red">*</span></label>
                                    <input class="form-control adm_date" type="text" size="30" id="date_to" name="date_to" required="required" />
                                </div>
                            </div> 



                        </div>
                        <!-- \col -->
                </div>
                </form>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="submit">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
</section>
<?php
$siteurl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script type="text/javascript">
  $(function () {
        
         var nowDate = new Date();
         var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);

        /*$('.adm_date').datepicker({format: 'dd-mm-yyyy',todayHighlight: true,
              minDate: 0});*/
		$('.adm_date').datepicker({format: 'dd-mm-yyyy',todayHighlight: true,startDate: today });	  
			  
        $('.adm_date').on('changeDate', function(ev){
                $(this).datepicker('hide');
        }) ; 

	 $('#myModal').on('click','#submit',function(){
	   var datastring = $("#onajaxForm").serialize();
          //alert(datastring);
           var siteurl = $('#site_url').val();
	   $(".errorDiv").remove();
	   $.ajax({
			type: "POST", // type
			url: siteurl+"/ajax-page-load/add_holiday", // request file
			data: datastring, // post data
			success: function (responseText) { // get the response
	                location.reload();
                        eModal.close();		
        
//        
//                     alert(responseText);
       responseText = $.trim(responseText);
				if (responseText != 'error') {
					location.reload(); 
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">From Date must Be greater then To Date</div>');
				}
			}, // end success
			error: function (jqXHR, textStatus, errorThrown) {
				
                                 // alert(errorThrown);
   
   if (jqXHR.status == 500) {
					$("#onajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
				} else {
					$("#onajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
				}
			}
		});
		// end
		return false;
	 });
	 	 //edit model
	 $('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
  });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>