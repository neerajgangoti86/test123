<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?> 

            <?php
            if (http_get("param1") == "today") {
                ?>
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Employee Attendance List As on :<?php echo date('d-m-Y', strtotime($oCurrentUser->mydate)); ?>
                        </h3>
                        <h3 class="box-title"><a href="<?= CLIENT_URL ?>/emp_attendances/monthly" class="btn bg-olive btn-flat margin">View Monthly Attendance</a></h3>
                    </div>

                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <thead style="background:#ddd;">
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>Departments</th>
                                    <th>Present</th>
                                    <th>Absent</th>
                                    <th>Leave</th>
                                    <th>Total Employee</th>
                                    <th>Actions</th>

                                </tr>
                            </thead>
                            <?php
                            @$get_holidays = Student::check_holiday($MSID, $oCurrentUser->mydate);
                            if (@$get_holidays->rowCount() == 0) {
                                ?>	
                                <tr><td colspan="4">Not A Working Day</td></tr>
                                <?php
                            } else {
                                ?>			  
                                <tbody>
                                    <?php
                                    $i = 1;
                                    $Ts_all = 0;
                                    $ts_present = 0;
                                    $ts_absent = 0;
                                    $ts_leave = 0;
                                    $present = 0;
                                    $absent = 0;
                                    $leave = 0;

                                    while ($emp = $emp_details->fetch()) {
                                        ?>
                                        <tr>
                                            <?php
                                            $total = $emp['ttl_grp'];
                                            $attendance = Attendance::get_attendance_emp($MSID, $oCurrentUser->mydate, $emp['emp_category'])->fetch();
                                            $present = $total - $attendance['Absent'] - $attendance['L'];
                                            ?>
                                            <td><?= $i ?></td>
                                            <td><?php
                                                if ($emp['emp_category'] == "NT") {
                                                    echo "Non Teaching Staff";
                                                } elseif ($emp['emp_category'] == "TS") {
                                                    echo 'Teaching Staff';
                                                } elseif ($emp['emp_category'] == "AS") {
                                                    echo 'Adminstrator Staff';
                                                }
                                                ?></td>
                                            <?php
                                            $absent = $attendance['Absent'];
                                            $leave = $attendance['L'];
                                            $Ts_all = $Ts_all + $total;
                                            $ts_present = $ts_present + $present;
                                            $ts_absent = $ts_absent + $absent;
                                            $ts_leave = $ts_leave + $leave;
                                            //print_r($classss); 
                                            ?>
                                            <td><a  href="<?= CLIENT_URL ?>/emp_attendances/<?= $emp['emp_category'] ?>/present" style="margin:0 10px;"><?= $present ?></a></td>
                                            <td><a  href="<?= CLIENT_URL ?>/emp_attendances/<?= $emp['emp_category'] ?>/absent" style="margin:0 10px;"><?= $absent ?></a></td>
                                            <td><a  href="<?= CLIENT_URL ?>/emp_attendances/<?= $emp['emp_category'] ?>/leave" style="margin:0 10px;"><?= $leave ?></a></td>
                                            <td><a href="<?= CLIENT_URL ?>/emp_attendances/<?= $emp['emp_category'] ?>/all"><?php echo $total; ?></a></td>
                                            <td><a class="btn bg-olive btn-flat"  href="<?= CLIENT_URL ?>/emp_attendances/<?= $emp['emp_category'] ?>/all/view" title="View" ><i class="fa fa-eye"> </i></a>&nbsp;
                                                <?php
                                                $LINK = CLIENT_URL . '/emp_attendances/' . $emp['emp_category'] . '/all';
                                                $btns = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                                print_r($btns);
                                                ?>
                                            </td>
                                        </tr>
                                        <?php
                                        $i++;
                                        ?>
                                    <?php } ?>
                                    <tr>
                                        <td colspan="2" align="center">Total</td>
                                        <td><?= $ts_present ?></td>
                                        <td><a  href="<?= CLIENT_URL ?>/emp_attendances/all/absent" style="margin:0 10px;"><?= $ts_absent ?></a></td>
                                        <td><a  href="<?= CLIENT_URL ?>/emp_attendances/all/leave" style="margin:0 10px;"><?= $ts_leave ?></a></td>
                                        <td><?= $Ts_all ?></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                </div>
                <?php
            } else if (http_get("param1") == "monthly") {
                ?>


                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            <?php
                            $message = new Messages();
                            echo $message->display();
                            ?>
                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title">List of Students</h3>
                                </div>
                                <!-- /.box-header -->
                                <div class="box-body table-responsive no-padding">

                                    <div class="col-md-8">
                                        <form class="form-inline right_ft" method="post" id="attendance_form_id">

                                            <div class="col-md-4">

                                                <?php
//                                       $class_section = Student::count_section_wise_student($MSID,$oCurrentUser->mysession)->fetchAll();
                                                ?>
                                                <label for="exampleInputName2">Select Section : </label>
                                                <select id="role" name="role" class="form-control"  onchange='this.form.submit()' >
                                                    <option value="AS" <?php echo @$selected_section == "AS" ? 'selected = "selected"' : ""; ?> >Adminstrator Staff</option>
                                                    <option value="NT" <?php echo @$selected_section == "NT" ? 'selected = "selected"' : ""; ?> >Non Teaching Staff</option>
                                                    <option value="TS" <?php echo @$selected_section == "TS" ? 'selected = "selected"' : ""; ?> >Teaching Staff</option>
                                                </select> 

                                            </div>  




                                        </form>
                                    </div>
                                    <div class="col-md-4">
                                        <h2>

                                            <?= date("M", strtotime($oCurrentUser->mydate)) . ", " . date("Y", strtotime($oCurrentUser->mydate)); ?>
                                        </h2>
                                    </div>
                                    <table class="table">
                                        <tbody>
                                            <tr class="Top">
                                                <th class="heading_title">Sr.No</th>
                                                <th align="center" class="heading_title">Name</th>
                                                <?php
                                                foreach ($listdays as $list) {
//    if( date('d',strtotime($oCurrentUser->mydate)) >= $list ){
//        print_r($list);
                                                    $today = $year . ":" . $month . ":" . $list;
                                                    if ($today == date('Y-m-d', strtotime($oCurrentUser->mydate))) {
                                                        $colour = "background:  greenyellow";
                                                        $today_date_day = $list;
                                                    } else {
                                                        $colour = "";
                                                    }
                                                    ?>
                                                    <th style="<?= $colour ?>" align="center" class="heading_title"><span><?php echo $list ?></span></th>
                                                    <?php
//}
                                                }
                                                ?>
                                            </tr>
                                            <tr class="Top">
                                                <td> &nbsp;</td>

                                                <td align></td>
                                                <?php
                                                $colour_check_var = 1;


                                                foreach ($days as $list) {
                                                    $colour_check = ($today_date_day == $colour_check_var) ? "greenyellow" : "";
                                                    ?>
                                                    <td style="background:  <?= $colour_check ?>" align="center" class="heading_title" ><?php echo $list ?></td>
                                                    <?php
                                                    $colour_check_var++;
                                                }
                                                ?>
                                                <td>Present &nbsp;&nbsp;&nbsp;Absent &nbsp;&nbsp;&nbsp; Leave</td>
                                            </tr>

                                            <?php
                                            @$get_holidays = Student::check_holiday($MSID, $oCurrentUser->mydate);



//print_r($get_holidays);
//                                            if (@$get_holidays->rowCount() == 0)
//                                                {
                                            ?>
                                <!--                                                <tr>
                                                                                    <td colspan="4" align="center"> Not A Working Day</td>   


                                                                                </tr>   -->

                                            <?php
//                                                }
//                                            else
//                                                {
                                            ?>

                                            <?php
                                            $sr_no = 1;
                                            while ($row = $students->fetch()) {
                                                ?>
                                                <tr>
                                                    <td><?= $sr_no ?></td>
                                                    <td><?php echo $row['emp_name'] ?></td>

                                                    <?php
                                                    $today_date = 0;
                                                    for ($i = 1; $i <= count($listdays); $i++) {
                                                        if (date('d', strtotime($oCurrentUser->mydate)) >= $i) {

                                                            //echo $i;



                                                            $dates = date("Y-m-$i", strtotime($oCurrentUser->mydate));
                                                            $today = date("Y-m-d", strtotime($dates));

                                                            $today1 = date("l", strtotime($today));

                                                            $today_date = date("Y-m-d", strtotime($today1));

                                                            //$d = date();

                                                            /* if ($day_format == 'y') {
                                                              $today_date = $i;
                                                              } else if ($day_format == 'd') {
                                                              $today_date = $start_date;
                                                              } else {
                                                              $today_date = $start_date + $i - 1;
                                                              } */


                                                            $datecheck = date('Y', strtotime($dates)) . "-" . date('m', strtotime($dates)) . "-" . date('d', strtotime($today_date));

                                                            //$datecheck;

                                                            $getattdata = array('AttDate' => "'" . $today . "'", 'role' => "'employee'");
//print_r($getattdata);
                                                            $attendance = Attendance::get_attendances($MSID, $row['employee_id'], $getattdata);
                                                            // print_r($attendance);

                                                            $absent = $attendance->fetch();
                                                            //print_r($absent);


                                                            $title = ($absent != "") ? ("Reason : " . $absent['Reason']) : "";
//                                                                print_r($absent);
                                                            $colour_check = ($absent != "") ? (($absent['Att'] == "A") ? "red" : "blue") : ((date('d', strtotime($oCurrentUser->mydate)) == $i) ? "greenyellow" : "");

                                                            @$hodidays = Attendance::count_holidays($today)->fetch();

                                                            @$special_holidays = Attendance::special_holidays($MSID, $today)->fetch();
                                                            $check_holidays = Attendance::special_holidays($MSID, $today)->rowCount();
                                                            if ($hodidays['SS'] == 'Sunday') {
                                                                $colour_check = "activeborder";
                                                            } else if ($hodidays['SS'] == '2nd Saturday') {
                                                                $colour_check = "activeborder";
                                                            } else {
                                                                if ($check_holidays > 0) {

                                                                    $colour_check = $special_holidays['colour'];
                                                                }
                                                            }
                                                            $dates_select = date("Y-m-$i");




//                                                            echo $colour_check;
                                                            ?>
                                                            <td style="background-color: <?= $colour_check ?>">
                                                                <?php
                                                                //print_r($special_holidays);
                                                                //echo $hodidays['SS'];


                                                                if ($hodidays['SS'] == 'Sunday') {
                                                                    echo 'Sun';
                                                                } else if ($hodidays['SS'] == '2nd Saturday') {
                                                                    echo '2nd Sat';
                                                                } else {
                                                                    if ($check_holidays > 0) {

                                                                        echo $special_holidays['Particular'];
                                                                    } else {
                                                                        if ($absent['Att'] == "A") {
                                                                            echo $absent['Att'];
                                                                        } else if ($absent['Att'] == "L") {
                                                                            echo $absent['Att'];
                                                                        } else {
                                                                            echo "P";
                                                                        }
                                                                    }
                                                                }
                                                                ?>  
                                                            </td>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </tr>
                                                <?php
                                                $sr_no++;
                                            }
//                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- /.box -->
                        </div>
                    </div>
                </section>

                <?php ?>
                <input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
                <input type="hidden" name="select_sec" value="<?= @$get_secton_name['sec_name'] ?>" id="select_sec"/>
                <input type="hidden" name="select_class" value="<?= @$get_classes_name['class_name'] ?>" id="select_class"/>
                <?php
                $aturl = CLIENT_URL . '/attendances';
                $sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
        $('.attendance_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		startDate: "$oCurrentUser->mydate",
        endDate: "$ses_end_dt",
        clearBtn: true
		});
        $('.attendance_date').change(function(){
         this.form.submit();
        });

	$('body').on('click','[data-ms="modal"]', function(e) {
                                    $("a").removeClass("abc");
                  $(this).addClass("abc");
                                     
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
        
  $(".att_link").click(function()
  {
      var a = $(this).attr('id');
      
      $("#rowid_"+a).append('<input type="text" placeholder="Please enter reason for absent" name="reason[]" id="reason_'+a+'" onkeyup="reason_text('+a+')" class="reason_textbox"/>');
        
      $("a#"+a).hide();
      
        
        
  });
        
 $('input:radio').click(function() 
 { 
    var stu_id = $(this).attr('name');
    var id = $(this).attr('id'); 
    
    var split_name = id.split("_");
    
    var siteurl = $('#site_url').val();
        
    var section = $("#select_sec").val();
        
    var classes = $("#select_class").val();
    
    var datastring = 'id='+stu_id+'&attend='+split_name[0]+'&section='+section+'&class='+classes;
    $.ajax({
                    
         url: siteurl+"/ajax-page-load/attend_post",
	  type: "POST",
	  data: datastring,
	 success: function (response)
                    {
                     //alert(response);
                    
                     //  alert(response);
        
                   /* $('#locality').append(response);
                            location.reload();
                            eModal.close();
                    
                    
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
  
    
});
         
});
                                    
</script>
<script type="text/javascript">
function reason_text(id)
{
   var text_box = $("#reason_"+id).val();
        
   var siteurl = $('#site_url').val();
        
  var section = $("#select_sec").val();
        
   var classes = $("#select_class").val();
   
   var datastring = 'id='+id+'&reason='+text_box+'&section='+section+'&class='+classes;
    
   //alert(datastring);
  
   $.ajax({
                    
         url: siteurl+"/ajax-page-load/attendance_post",
	  type: "POST",
	  data: datastring,
	 success: function (response)
                    {
                     //alert(response);
                    
                     $("reason_"+id).hide();
                     $("#rowid_"+id).append('<a href="javascript;">'+text_box+'</a>');
                     
                     
   
                      // alert(response);
        
                   /* $('#locality').append(response);
                            location.reload();
                            eModal.close();
                    
                    
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
  
  
 
        
}
</script>       
EOT;
                $oPageLayout->addJavascriptBottom($sBottomJavascript);
                ?>





                <?php
            } else {
                ?><div class="box">
                    <div class="row"> 
                        <div class="col-md-4"><div class="box-header">
                                <h3 class="box-title">List of Employee</h3>
                            </div>
                            <!-- /.box-header -->
                        </div> 
                        <div class="col-md-6">
                            <h2>
                                <?= date("M", strtotime($oCurrentUser->mydate)) . ", " . date("Y", strtotime($oCurrentUser->mydate)); ?>
                            </h2>
                        </div><div class="col-md-2">
                            <ul class="nav nav-pills">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                                    <ul class="dropdown-menu">
                                        <li><a  href="javascript:void(0);" title="Export to Excel" onclick="$('#attend_reports').tableExport({type: 'excel', escape: 'false'});"><img src="<?= ASSETS_FOLDER ?>/img/excel.png" title="export to excel" width="30" height="30"/></a></li>
                                        <li><a  href="javascript:void(0);" title="Export to Word" class="jquery-word-export"><img src="<?= ASSETS_FOLDER ?>/img/word.png" title="export to word" width="30" height="30"/></a>
                                            </a></li>
                                        <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                                        </li>

                                    </ul>
                                </li>
                            </ul></div> </div>
                    <div class="row">   
                        <?php
                        if (http_get("param1") != "all") {
                            ?> <div class="col-md-4">
                                <form class="form-inline right_ft" method="post" id="attendance_form_id">


                                    <input type="hidden" name="attendanceEmp" value="xxx" />
                                    <label for="exampleInputName2">Select Category : </label>
                                    <select id="role" name="role" class="form-control"  onchange='this.form.submit()' >
                                        <b> Select Class : - </b>
                                        <option value="NT" <?php echo $role == "NT" ? 'selected = "selected"' : ""; ?> >Non Teaching Staff</option>
                                        <option value="TS" <?php echo $role == "TS" ? 'selected = "selected"' : ""; ?> >Teaching Staff</option>
                                    </select>

                                </form>
                            </div>
                        <?php } ?>

                        <div class="col-md-5"></div>
                        <div class="col-md-3"> 
                            <?php
                            if (@http_get("param3") != "view") {
                                ?>   <h3 class="box-title"> <a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL; ?>/emp_attendances/today"> Save  Attendance</a>
                                    <a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL.'/sms/'.http_get('param1').'/'.http_get('param2').'/employees' ?>"> Send SMS</a>
                                </h3>
                            <?php } ?> </div> 
                    </div><div class="box-body table-responsive no-padding report_export" id="attend_report">
                        <table class="table" id="attend_reports">
                            <tbody>
                            <input type="hidden" name="category" id="category" value="<?= $role ?>">
                            <tr class="Top">
                                <td>Sr.No</td>
                                <td>Employee ID</td>
                                <td>Employee Name</td>

                                <td><?php echo $day = date('l', strtotime($oCurrentUser->mydate)) ?></td>

                                <td>Reason</td>
                            </tr>
                            <?php
                            if (@http_get("param3") != "view") {
                                ?>     <tr class="Top">
                                    <th>&nbsp;</th>
                                    <th>&nbsp;</th>
                                    <th align="left"></th>

                                    <th>Present&nbsp;&nbsp;&nbsp;Absent&nbsp;&nbsp;&nbsp;Leave</th>

                                    <th>&nbsp;</th>
                                </tr>
                            <?php } ?>
                            <?php
                            @$get_holidays = Student::check_holiday($MSID, $oCurrentUser->mydate);
                            if (@$get_holidays->rowCount() == 0) {
                                ?>
                                <tr>
                                    <td colspan="4" align="center"> Not A Working Day</td>   
                                </tr>
                                <?php
                            } else {

                                $sr_no = 1;
                                while ($row = $employee->fetch()) {
                                    $datecheck = date('Y-m-d', strtotime($oCurrentUser->mydate));

                                    $getattdata = array('AttDate' => "'" . $datecheck . "'", 'role' => "'employee'");
                                    $attendance = Attendance::get_attendance($MSID, $row['employee_id'], $getattdata);

                                    $absent = $attendance->fetch();

                                    if (@http_get("param3") == "view") {
                                        if (($absent['Att'] == "A") || ($absent['Att'] == "L")) {
                                            ?>
                                            <tr>
                                                <td><?= $sr_no ?></td>
                                                <td>EMP-<?= $row['employee_id'] ?></td>
                                                <td><?php echo $row['emp_name'] ?></td>
                                                <?php
                                                //$today_date = date('d',strtotime($oCurrentUser->mydate));

                                                $title = ($absent != "") ? ("Reason : " . $absent['Reason']) : "";
                                                //$colour_check = ($absent != "") ? (($absent['attendance'] == "Absent") ? "blue");
                                                ?><td style="background:">
                                                <?php
                                                if ($absent['Att'] == NULL) {
                                                    echo "Present";
                                                } elseif ($absent['Att'] == "A") {
                                                    echo "Absent";
                                                } else {
                                                    echo"Leave";
                                                }
                                                ?>
                                                    </a></td>


                                                <td id="rowid_<?= $row['employee_id'] ?>">
                                                    <?php
                                                    if (@$absent['Reason'] != '') {
                                                        if (http_get("param3") != "view") {
                                                            ?>
                                                            <a href="javascript:void(0);" id="<?= $row['employee_id'] ?>" class="att_link"><?php echo @$absent['Reason']; ?></a>
                                                            <?php
                                                        } else {
                                                            echo @$absent['Reason'];
                                                        }
                                                    } else {
                                                        ?><?php
                                                        if (@http_get("param3") != "view") {
                                                            ?> 

                                                            <a href="javascript:void(0);" id="<?= $row['employee_id'] ?>" class="att_link">Reason For Absent</a>

                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </td>
                                            </tr><?php
                                            $sr_no++;
                                        }
                                    } else {
                                        ?>
                                        <tr>
                                            <td><?= $sr_no ?></td>
                                            <td>EMP-<?= $row['employee_id'] ?></td>
                                            <td><?php echo $row['emp_name'] ?></td>
                                            <?php
                                            //$today_date = date('d',strtotime($oCurrentUser->mydate));

                                            $title = ($absent != "") ? ("Reason : " . $absent['Reason']) : "";
                                            //$colour_check = ($absent != "") ? (($absent['attendance'] == "Absent") ? "blue");
                                            ?>

                                            <td style="background:"><input type="radio" name="<?= $row['employee_id'] ?>" id="p_<?= $row['employee_id'] ?>" checked="checked"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;<input  type="radio" name="<?= $row['employee_id'] ?>" id="a_<?= $row['employee_id'] ?>" <?php
                                                if (@$absent['Att'] == "A") {
                                                    echo "checked='checked'";
                                                }
                                                ?>/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="radio" name="<?= $row['employee_id'] ?>" id="l_<?= $row['employee_id'] ?>" <?php
                                                                                                                                                                                                                                                        if (@$absent['Att'] == "L") {
                                                                                                                                                                                                                                                            echo "checked='checked'";
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        ?>/></a></td>
                                            <td id="rowid_<?= $row['employee_id'] ?>">
                                                <?php
                                                if (@$absent['Reason'] != '') {
                                                    ?><?php
                                                    if (@http_get("param3") == "view") {
                                                        echo "SDf";
                                                        ?> 
                                                        <?php echo @$absent['Reason']; ?>
                                                        <?php
                                                    } else {
                                                        ?> 
                                                        <a href="javascript:void(0);" id="<?= $row['employee_id'] ?>" class="att_link"><?php echo @$absent['Reason']; ?></a>
                                                        <?php
                                                    }
                                                } else {
                                                    ?><?php
                                                    if (@http_get("param3") != "view") {
                                                        ?> 

                                                        <a href="javascript:void(0);" id="<?= $row['employee_id'] ?>" class="att_link">Reason For Absent</a>

                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php
                                        $sr_no++;
                                    }
                                }
                            }
                            ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            <?php } ?>
            <!-- /.box -->
        </div>
    </div>
</section>
<input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">

<script type='text/javascript'>
    function htmltopdf() {
        var pdf = new jsPDF('p', 'pt', 'a1');
        source = $('#attend_report')[0];
        specialElementHandlers = {
            '#bypassme': function (element, renderer) {
                return true
            }
        };
        margins = {
            top: 10,
            bottom: 10,
            left: 10,
            width: 800
        };
        pdf.fromHTML(
                source,
                margins.left,
                margins.top, {
                    'width': margins.width,
                    'elementHandlers': specialElementHandlers
                },
                function (dispose) {
                    pdf.save('Download.pdf');
                }, margins);
    }

</script><?php
$aturl = CLIENT_URL . '/attendances';
$sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
        
      

	$('body').on('click','[data-ms="modal"]', function(e) {
                                    $("a").removeClass("abc");
                  $(this).addClass("abc");
                                     
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
        
  $(".att_link").click(function()
  {
      var a = $(this).attr('id');
      
      $("#rowid_"+a).append('<input type="text" placeholder="Please enter Reason for absent" name="Reason[]" id="Reason_'+a+'" onblur="Reason_text('+a+')" class="Reason_textbox"/>');
        
      $("a#"+a).hide();
      
        
        
  });
        
 $('input:radio').click(function() 
 {   
       
         var emp_id = $(this).attr('name');
    var id = $(this).attr('id'); 
      var category =$("#category").val();
    
 
    var split_name = id.split("_");
//    alert(split_name);
    var siteurl = $('#site_url').val();
        
    
    
    var datastring = 'id='+emp_id+'&attend='+split_name[0]+'&category='+category;
//        alert(datastring);
    $.ajax({
        url: siteurl+"/ajax-page-load/attend_emp_post",
	  type: "POST",
	  data: datastring,
	 success: function (response)
                    {
//        alert(response);
//                            location.reload();
//                            eModal.close();
                   			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
  
    
});
         
});
                                    
</script>
<script type="text/javascript">
function Reason_text(id)
{        
   var text_box = $("#Reason_"+id).val();
   var siteurl = $('#site_url').val();
   var datastring = 'id='+id+'&Reason='+text_box;
  $.ajax({
         url: siteurl+"/ajax-page-load/attendance_emp_post",
	  type: "POST",
	  data: datastring,
	 success: function (response)
                    {
                    if(response == '')
                    {
                    }
                    else 
                    {
                     $("input#Reason_"+id).hide();
                     $("#rowid_"+id).append('<a href="javascript;" id="'+id+'" class="att_link" >'+text_box+'</a>');
                     
                      }
             	},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
}
</script>       
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>



