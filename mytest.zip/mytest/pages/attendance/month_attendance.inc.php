<style type="text/css">
    .heading_title { font-size:16px;}


</style>
<?php
$year = date('Y', strtotime($oCurrentSchool->session_start_date));
$ses_str_dt = $year . '-' . date('m-d', strtotime($oCurrentSchool->session_start_date));
$ses_end_dt = ($year + 1) . '-' . date('m-d', strtotime($oCurrentSchool->session_end_date));
if (isset($_POST['attendanceFrm'])) {
        if ($_POST['class_id'] != 0) {
            $selected_class = $_POST['class_id'];
        } else {
            
            $selected_class = "a0";
        }

    // $get_result = Master::get_class_result($MSID, $selected_class2)->fetch();
    //die("<>>>>");

    /* if (empty($_POST['date'])) {

      $date = $ses_str_dt;
      } else {
      $date = $_POST['date'];
      } */
    if (empty($_POST['section_id'])) {
        $selected_section = '1';
    } else {

        $selected_section = $_POST['section_id'];
    }
}
?>
<?php
$day_format = http_get("param2");

//$month = http_get("param3");
$year = http_get("param4");
$add_days = http_get("param5");
$today_date_day = date('d', strtotime($oCurrentUser->mydate));
$day = "";

$day_end = 0;
//$selected_class = http_get("param1");
$monday_check = 0;

if (!@$year) {
    $year = date('Y', strtotime($oCurrentUser->mydate));
}
if (!@$month) {
    $month = date('m', strtotime($oCurrentUser->mydate));
}


if (!@$selected_class) {
    $selected_class = '-1';
}
if ($selected_class == "a0") {
    $selected = explode('a', $selected_class);
    $selected_class = $selected[1];
}

if ($oCurrentSchool->section > 1) {
    if (!@$selected_section) {
        $selected_section = '1';
    }
}


//echo @$selected_class;

if (!@$date) {
    if ($year == date('Y', strtotime($oCurrentUser->mydate))) {
        $date = date('Y-m-d', strtotime($oCurrentUser->mydate));
    } else {
        $date = $ses_str_dt;
    }
}
$month = date('m', strtotime($date));
$year = date('y', strtotime($date));

$day = "";
$end_date = 31;
$start_date = 1;



$dateObj = DateTime::createFromFormat('!m', $month);
$monthName = $dateObj->format('F');
// March
$data = array(
    'class' => $selected_class,
    'section' => @$selected_section
//        ,
//    'attendance_year'=>$year
);

//print_r($data);
$students = Student::get_students3($oCurrentUser->myuid, 'all', '', '', $data);
//print_r($students);

$totalrecords = $students->rowCount();



$listdays = array();
$days = array();

for ($d = $start_date; $d <= $end_date; $d++) {
    $time = mktime(12, 0, 0, $month, $d, $year);
    if (date('m', $time) == $month) {
        $listdays[] = date('d', $time);
        $days[] = date('D', $time);
    }
}
//print_r($date);
//exit();
?>

<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">

                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">

                    <div class="col-md-8">
                        <form class="form-inline right_ft" method="post" id="attendance_form_id">
                            <?php /* <div class="col-md-4">
                              <div class="form-group ">
                              <label  for="exampleInputName2">Date:</label>
                              <div class="input-group ">
                              <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                              <input type="text" name="date" id="attendance_date_id" value="<?= $date ?>" class="form-control  attendance_date"/>
                              </div>
                              <!-- /.input group -->
                              </div>
                              <!-- /.form group -->
                              </div> */ ?>
                            <div class="col-md-4">
                                <input type="hidden" name="attendanceFrm" value="xxx" />
                                <label for="exampleInputName2">Select Class :</label>
                                <select id="class_id" name="class_id" class="form-control wth_div"  onchange='this.form.submit()'>
                                    <?php $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                    ?>

                                    <?php
                                    foreach ($classs as $class) {
                                        if ($selected_class == $class['class_no']) {
                                            $selected = 'selected = "selected"';
                                        } else {
                                            $selected = "";
                                        }
                                        ?>
                                        <option value="<?= $class['class_no']; ?>" <?= $selected ?> >
                                            <?= $class['class_name']; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>

                            <?php
                            if ($oCurrentSchool->section > 1) {
                                ?>
                                <div class="col-md-4">

                                    <?php
                                    $class_section = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class)->fetchAll();
                                    ?>
                                    <label for="exampleInputName2">Select Section : </label>
                                    <select id="section_id" name="section_id" class="form-control wth_div"  onchange='this.form.submit()'>
                                        <?php
                                        foreach ($class_section as $section) {

                                            $section_details = Master::get_schools_section($MSID, $section['section'])->fetch();
                                            if (@$selected_section == $section['section']) {
                                                $selected = 'selected = "selected"';
                                            } else {
                                                $selected = "";
                                            }
                                            ?>
                                            <option value="<?= $section['section']; ?>" <?= $selected ?> >
                                                <?= $section_details['sec_name']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>

                                </div>  
                                <?php
                            }
                            ?>



                        </form>
                    </div>
                    <div class="col-md-4">
                        <ul class="nav nav-pills">
                            <li class="dropdown">
                                <a href="javascript:void(0);" data-toggle="dropdown" class="dropdown-toggle"><i class="fa fa-bars"></i>Export</a>
                                <ul class="dropdown-menu">
                                    <li><a  href="javascript:void(0);" title="Export to Excel" onclick="$('#fee_reports').tableExport({type: 'excel', escape: 'false'});"><img src="<?= ASSETS_FOLDER ?>/img/excel.png" title="export to excel" width="30" height="30"/></a></li>
                                    <li><a  href="javascript:void(0);" title="Export to PDF" onclick="javascript:htmltopdf();"><img src="<?= ASSETS_FOLDER ?>/img/pdf.png" title="export to pdf" width="30" height="30"/></a>
                                    </li>

                                </ul>
                            </li>
                        </ul>
                    </div>
                    <table class="table" id="fee_reports" >
                        <tbody>
                            <tr class="Top"><td colspan="30" align="center">
                                    <h4> Attendance Report For Class <?php $class_namef = Master::get_classes($MSID, '', '', '', @$selected_class)->fetch(PDO::FETCH_OBJ); ?><?= $class_namef->class_name ?>-<?php $section_namef = Master::get_schools_section($MSID, @$selected_section)->fetch(PDO::FETCH_OBJ); ?><?= $section_namef->sec_name ?> For Month   
                                        <?= $monthName . ", " . (($date) ? date('Y', strtotime($date)) : $_SESSION['year']); ?>
                                    </h4>   
                                </td></tr>
                            <tr class="Top">
                                <td class="heading_title">Sr.No</td>
                                <td align="center" class="heading_title">Name</td>
                                <td>&nbsp;</td>
                                <?php
                                foreach ($listdays as $list) {
//    if( date('d',strtotime($oCurrentUser->mydate)) >= $list ){
//        print_r($list);
                                    $today = $year . ":" . $month . ":" . $list;
                                    if ($today == date('Y-m-d', strtotime($oCurrentUser->mydate))) {
                                        $colour = "background:  greenyellow";
                                        $today_date_day = $list;
                                    } else {
                                        $colour = "";
                                    }
                                    ?>
                                    <td style="<?= $colour ?>" align="center" class="heading_title"><?php echo $list ?>&nbsp;</td>  <?php if ($list == "1") {
                                        ?>
                                        <td width="17" align="center" class="heading_title" style="<?= $colour ?>"></td>
                                    <?php } ?>
                                    <?php
//}
                                }
                                ?>
                                <td colspan="3">&nbsp;</td>
                            </tr>

                            <tr class="Top">
                                <td>&nbsp; </td>

                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <?php
                                $colour_check_var = 1;


                                foreach ($days as $list) {
                                    $colour_check = ($today_date_day == $colour_check_var) ? "greenyellow" : "";
                                    ?>
                                    <td style="background:<?= $colour_check ?>" align="center" class="heading_title"><?php echo $list ?></td>
                                    <?php
                                    if ($colour_check_var == 1) {
                                        ?>
                                        <td></td><?php
                                    }
                                    $colour_check_var++;
                                }
                                ?>

                                <td width="64">Total Att</td>
                                <td width="69">Preious Att</td>
                                <td width="15">Grand Total</td>
                            </tr>

                            <?php
                            @$get_holidays = Student::check_holiday($MSID, $oCurrentUser->mydate);



//print_r($get_holidays);
//if (@$get_holidays->rowCount() == 0) {
                            ?>
<!--                                <tr>
                                    <td colspan="4" align="center"> Not A Working Day</td>   


                                </tr>   -->

                            <?php
//                                } else {
                            ?>

                            <?php
                            $sr_no = 1;
                            while ($row = $students->fetch()) {
                                ?>
                                <tr>
                                    <td><?= $sr_no ?></td>
                                    <td><?php echo $row['name'] ?></td>
                                    <td>&nbsp;</td>

                                    <?php
                                    $today_date = 0;
                                    for ($i = 1; $i <= count($listdays); $i++) {
                                        if (date('d', strtotime($oCurrentUser->mydate)) >= $i) {

                                            //echo $i;



                                            $dates = date("Y-m-$i", strtotime($oCurrentUser->mydate));
                                            $today = date("Y-m-d", strtotime($dates));

                                            $today1 = date("l", strtotime($today));

                                            $today_date = date("Y-m-d", strtotime($today1));

                                            //$d = date();

                                            /* if ($day_format == 'y') {
                                              $today_date = $i;
                                              } else if ($day_format == 'd') {
                                              $today_date = $start_date;
                                              } else {
                                              $today_date = $start_date + $i - 1;
                                              } */


                                            $datecheck = date('Y', strtotime($dates)) . "-" . date('m', strtotime($dates)) . "-" . date('d', strtotime($today_date));

                                            //$datecheck;

                                            $getattdata = array('AttDate' => "'" . $today . "'", 'role' => "'student'");
//print_r($getattdata);
                                            $attendance = Attendance::get_attendances($MSID, $row['student_id'], $getattdata);
                                            // print_r($attendance);

                                            $absent = $attendance->fetch();
                                            //print_r($absent);


                                            $title = ($absent != "") ? ("Reason : " . $absent['Reason']) : "";
                                            $colour_check = ($absent != "") ? (($absent['Att'] == "A") ? "red" : "blue") : ((date('d', strtotime($oCurrentUser->mydate)) == $i) ? "greenyellow" : "a");
                                            @$hodidays = Attendance::count_holidays($today)->fetch();
                                            

                                            $check_holidays = Attendance::special_holidays($MSID, $today)->rowCount();

                                            @$special_holidays = Attendance::special_holidays($MSID, $today)->fetch();

                                            if ($hodidays['SS'] == 'Sunday') {
                                                $colour_check = "activeborder";
                                            } else if ($hodidays['SS'] == '2nd Saturday') {
                                                
                                               @$check_SS = Attendance::count_SS_holidays($MSID,$hodidays['SS'])->rowcount(); if($check_SS!=''){
                                                
                                               $colour_check = "activeborder";}else{}
                                            } else {
                                                if ($check_holidays > 0) {

                                                    $colour_check = $special_holidays['colour'];
                                                }
                                            }

                                            $dates_select = date("Y-m-$i");
                                            ?>

                                            <td style="background-color: <?= $colour_check ?>">
                                                <?php
                                                //print_r($special_holidays);
                                                //echo $hodidays['SS'];


                                                if ($hodidays['SS'] == 'Sunday') {
                                                    echo 'Sun';
                                                } else if (($hodidays['SS'] == '2nd Saturday')&&($check_SS!='')) {
                                                    echo '2nd Sat';
                                                } else {
                                                    if ($check_holidays > 0) {

                                                        echo $special_holidays['Particular'];
                                                    } else {
                                                        if ($absent['Att'] == "A") {
                                                            echo $absent['Att'];
                                                        } else if ($absent['Att'] == "L") {
                                                            echo $absent['Att'];
                                                        } else {
                                                            echo "P";
                                                        }
                                                    }
                                                }
                                                ?>  
                                            </td> <?php if ($i == 1) { ?><td></td><?php } ?>
                                            <?php
                                        }
                                    }
                                    ?>
                                    <td><?php
                                        $attstu = Attendance::count_student_att_month($MSID, $row['student_id'], $oCurrentUser->mydate)->fetch();

                                        // print_r($workingdays);
                                        $attttt = $attstu['total'];
                                        $stuatt = $workingd - $attttt;
                                        echo $stuatt;
                                        ?> </td>
                                    <td><?php
                                        $preattstu = Attendance::student_total_att_month($MSID, $row['student_id'], $oCurrentUser->mydate)->fetch();
//    pr($preattstu);

                                        @$preattttt = $preattstu['total'];
                                        $preattstu = $preworkingd - $preattttt;
                                        echo $preattstu;
                                        ?>  </td>
                                    <td><?php echo $grandatt = $stuatt + $preattstu; ?> </td>
                                </tr>
                                <?php
                                $sr_no++;
                            }
//                                }
                            ?>
                            <tr style="color:#fff"><td colspan="4">Class Teacher Signature</td><td></td><td colspan="4">_______________</td><td></td><td colspan="4">Principal Signature</td><td></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>

<?php
@$get_classes_name = Master::get_class_names($MSID, $selected_class)->fetch();
@$get_secton_name = Master::get_schools_section($MSID, $selected_section)->fetch();
?>
<input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
<input type="hidden" name="select_sec" value="<?= @$get_secton_name['sec_name'] ?>" id="select_sec"/>
<input type="hidden" name="select_class" value="<?= @$get_classes_name['class_name'] ?>" id="select_class"/>
<?php
$aturl = CLIENT_URL . '/attendances';
$sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
        $('.attendance_date').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		startDate: "$ses_str_dt",
        endDate: "$ses_end_dt",
        clearBtn: true
		});
        $('.attendance_date').change(function(){
         this.form.submit();
        });

	$('body').on('click','[data-ms="modal"]', function(e) {
                                    $("a").removeClass("abc");
                  $(this).addClass("abc");
                                     
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'md'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});
        
  $(".att_link").click(function()
  {
      var a = $(this).attr('id');
      
      $("#rowid_"+a).append('<input type="text" placeholder="Please enter reason for absent" name="reason[]" id="reason_'+a+'" onkeyup="reason_text('+a+')" class="reason_textbox"/>');
        
      $("a#"+a).hide();
      
        
        
  });
        
 $('input:radio').click(function() 
 { 
    var stu_id = $(this).attr('name');
    var id = $(this).attr('id'); 
    
    var split_name = id.split("_");
    
    var siteurl = $('#site_url').val();
        
    var section = $("#select_sec").val();
        
    var classes = $("#select_class").val();
    
    var datastring = 'id='+stu_id+'&attend='+split_name[0]+'&section='+section+'&class='+classes;
    $.ajax({
                    
         url: siteurl+"/ajax-page-load/attend_post",
	  type: "POST",
	  data: datastring,
	 success: function (response)
                    {
                     //alert(response);
                    
                     //  alert(response);
        
                   /* $('#locality').append(response);
                            location.reload();
                            eModal.close();
                    
                    
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
  
    
});
         
});
                                    
</script>
<script type="text/javascript">
function reason_text(id)
{
   var text_box = $("#reason_"+id).val();
        
   var siteurl = $('#site_url').val();
        
  var section = $("#select_sec").val();
        
   var classes = $("#select_class").val();
   
   var datastring = 'id='+id+'&reason='+text_box+'&section='+section+'&class='+classes;
    
   //alert(datastring);
  
   $.ajax({
                    
         url: siteurl+"/ajax-page-load/attendance_post",
	  type: "POST",
	  data: datastring,
	 success: function (response)
                    {
                     //alert(response);
                    
                     $("reason_"+id).hide();
                     $("#rowid_"+id).append('<a href="javascript;">'+text_box+'</a>');
                     
                     
   
                      // alert(response);
        
                   /* $('#locality').append(response);
                            location.reload();
                            eModal.close();
                    
                    
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
  
  
 
        
}
</script>       
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
<?php
$sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
      //alert("hi");              
   $('.date_from').datepicker({ format: 'dd-mm-yyyy', todayHighlight: true, clearBtn: true});
   $('.date_from').on('changeDate', function(ev){
    $(this).datepicker('hide');
}) ;

	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});	
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
