<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Student Attendance List As on :<?php echo date('d-m-Y', strtotime($oCurrentUser->mydate)); ?>
                    </h3>
                    <h3 class="box-title"><a href="<?= CLIENT_URL ?>/month_attendances" class="btn bg-olive btn-flat margin">View Monthly Attendance</a></h3>
                </div>

                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <thead style="background:#ddd;">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Class</th>
                                <th>Present</th>
                                <th>Absent</th>
                                <th>Leave</th> 
                                <!--<th>Holiday</th>-->
                                <th>Total Students</th>.
                                <th>Actions</th>

                            </tr>
                        </thead>
                        <?php
                        @$get_holidays = Student::check_holiday($MSID, $oCurrentUser->mydate);
                        if (@$get_holidays->rowCount() == 0)
                            {
                            ?>	
                            <tr><td colspan="4">Not A Working Day</td></tr>
                            <?php
                            }
                        else
                            {
                            ?>			  
                            <tbody>
                                <?php
                                $i = 1;
                                $Ts_all = 0;
                                $ts_present = 0;
                                $ts_absent = 0;
                                $ts_leave = 0;
                                $ts_holiday = 0;
                                $holiday = 0; 
                                $present = 0;
                                $absent = 0;
                                $leave = 0;
                                $max = $oCurrentSchool->section;
                                while ($student = $student_details->fetch())
                                    {
                                    ?>
                                    <?php
                                    if ($max > 1)
                                        {
                                        for ($j = 1; $j <= $max; $j++)
                                            {
                                            ?> <tr> 
                                                <?php
                                                $student_sections = Student::count_section_students($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, $student['CClass'], $j);
                                                $count = $student_sections->rowCount();

                                                $sections = $student_sections->fetch();
                                                $total = $sections['0'];
                                                if ($sections['0'] > 0)
                                                    {
                                                    $section_name = Master::section_name_list($MSID, $j)->fetch();
                                                    ?>  <td><?= $i ?></td><td><?php
                                                        $classes = Master:: get_class_names3($MSID, $sections['CClass'])->fetch();
                                                        echo $classes['class_name'], " ", $section_name['sec_name'];
                                                        $attendance = Student::get_attendance($MSID, $oCurrentUser->mydate, $classes['class_name'], $section_name['sec_name'])->fetch();

                                                        $re = Student::get_attendance($MSID, $oCurrentUser->mydate, $classes['class_name'], $j);
                                                        $present = $total - $attendance['Absent'] - $attendance['L'] - $attendance['H'];
                                                        $absent = $attendance['Absent'];
                                                        $leave = $attendance['L'];
                                                        $holiday = $attendance['H'];
                                                        $Ts_all = $Ts_all + $total;
                                                        $ts_present = $ts_present + $present;

                                                        $ts_absent = $ts_absent + $absent;
                                                        $ts_leave = $ts_leave + $leave;
                                                        $ts_holiday = $ts_holiday + $holiday;
                                                        ?> 
                                                    </td>
                                                    <td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/present/<?= $j ?>" style="margin:0 10px;"><?= $present ?></a></td>
                                                    <td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/absent/<?= $j ?>" style="margin:0 10px;"><?= $absent ?></a></td>
                                                    <td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/leave/<?= $j ?>" style="margin:0 10px;"><?= $leave ?></a></td>
                                                    <!--<td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/holiday/<?= $j ?>" style="margin:0 10px;"><?= $holiday ?></a></td>-->
                                                    <td><a href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/redirect/<?= $j ?>"><?php echo $sections['0']; ?></a></td>
                                                    <td><a class="btn bg-olive btn-flat"  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/redirect/<?= $j ?>/view" title="View" ><i class="fa fa-eye"> </i></a>&nbsp;
                                                        <?php
                                                        $LINK = CLIENT_URL . '/attendances/' . $student['CClass'] . '/d/redirect/' . $j;
                                                        $btns = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                                        print_r($btns);
                                                        ?>
                                                    </td>
                                                </tr>
                                                <?php
                                                $i++;
                                                }
                                            }
                                        }
                                    else
                                        {
                                        ?>
                                        <tr>
                                            <?php
                                            $total = $student['total'];
                                            $classss = Master::get_class_names3($MSID, $student['CClass'])->fetch();
                                            $attendance = Student::get_attendance($MSID, $oCurrentUser->mydate, $classss['class_name'])->fetch();
                                            $present = $total - $attendance['Absent'] - $attendance['L'] - $attendance['H'];
                                            ?>
                                            <td><?= $i ?></td>
                                            <td><?php echo $classss['class_name'] ?></td>
                                            <?php
                                            $absent = $attendance['Absent'];
                                            $leave = $attendance['L'];
                                            $holiday = $attendance['H'];
                                            $Ts_all = $Ts_all + $total;
                                            $ts_present = $ts_present + $present;
                                            $ts_absent = $ts_absent + $absent;
                                            $ts_leave = $ts_leave + $leave;
                                            $ts_holiday = $ts_holiday + $holiday;
                                            //print_r($classss); 
                                            ?>
                                            <td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/present/1" style="margin:0 10px;"><?= $present ?></a></td>
                                            <td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/absent/1" style="margin:0 10px;"><?= $absent ?></a></td>
                                            <td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/leave/1" style="margin:0 10px;"><?= $leave ?></a></td>
                                            <!--<td><a  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/holiday/1" style="margin:0 10px;"><?= $holiday ?></a></td>-->
                                            <td><a href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/redirect/1"><?php echo $total; ?></a></td>
                                            <td><a class="btn bg-olive btn-flat"  href="<?= CLIENT_URL ?>/attendances/<?= $student['CClass'] ?>/d/redirect/1/view" title="View" ><i class="fa fa-eye"> </i></a>&nbsp;
                                                <?php
                                                $LINK = CLIENT_URL . '/attendances/' . $student['CClass'] . '/d/redirect/1';
                                                $btns = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                                print_r($btns);
                                                ?>
                                            </td> 
                                        </tr>
                                        <?php
                                        $i++;
                                        }
                                    ?>
                                <?php } ?>
                                <tr>
                                    <td colspan="2" align="center">Total</td>
                                    <td><?= $ts_present ?></td>
                                    <td><a  href="<?= CLIENT_URL ?>/attendances/all/d/absent/1" style="margin:0 10px;"><?= $ts_absent ?></a></td>
                                    <td><a  href="<?= CLIENT_URL ?>/attendances/all/d/leave/1" style="margin:0 10px;"><?= $ts_leave ?></a></td>
                                    <!--<td><a  href="<?= CLIENT_URL ?>/attendances/all/d/holiday/1" style="margin:0 10px;"><?= $ts_holiday ?></a></td>-->
                                    <td><?= $Ts_all ?></td>
                                    <td></td>
                                </tr>
                            </tbody>
                            <?php
                            }
                        ?>
                    </table>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<!-- Main content -->