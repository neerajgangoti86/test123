<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Chat Box</h3>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-3 bg-white ">
                            <div class="chat-box-online-head" style="height: 40px;">
                                Conversations
                            </div>
                            <!--===============================================================--> 
                            <ul class="friend-list"  id="friend-list">
                                <?php
                                while ($conv = $getconversation->fetch()) {
                                    $chat = Chat::get_inbox($MSID, $conv['id'], NULL, NULL, NULL, 'False', 'all', NULL, 'desc')->fetch(PDO::FETCH_ASSOC);
                                    if (@$conv['user_one'] == $user_id) {
                                        $user = UserManager::get_slusers($conv['user_two'], $MSID)->fetch(PDO::FETCH_ASSOC);
                                    } else {
                                        $user = UserManager::get_slusers($conv['user_one'], $MSID)->fetch(PDO::FETCH_ASSOC);
                                    }
                                    $name = $user['myuname'];
                                    $usr_id = $user['user_id'];
                                    if ($user['ulevel'] == 1) {
                                        $role = array('id' => $user['ulevel'], 'label' => '<span class="pull-right label label-success">S</span>');
                                    } elseif ($user['ulevel'] == 2) {
                                        $role = array('id' => $user['ulevel'], 'label' => '<span class="pull-right label label-warning">P</span>');
                                    } elseif ($user['ulevel'] == 3) {
                                        $role = array('id' => $user['ulevel'], 'label' => '<span class="pull-right label label-info">E</span>');
                                    } elseif ($user['ulevel'] == 9) {
                                        $role = array('id' => $user['ulevel'], 'label' => '<span class="pull-right label label-primary">A</span>');
                                    }

                                    if (empty($photo)) {
                                        $photo = "http://eschoolexpert.com/uploads/thumbs/photo_1459302550.jpg";
                                    }
                                    ?>
                                    <li class="active bounceInDown " id="<?= $conv['id'] ?>">                             

                                        <a href="javascript:void(0);" class="clearfix conversation" id="<?= $usr_id ?>">
                                            <img src="<?= $photo ?>" alt="<?= $name ?>" class="img-circle">
                                            <span class="hidden" id="<?= $role['id'] ?>"></span>
                                            <div class="friend-name " id="<?= $name ?>">	
                                                <strong id="nm"><?= $name . "  " . $role['label'] ?> </strong>
                                            </div>
                                            <div class="last-message text-muted"><?= $chat['message']; ?></div>
                                            <?php
                                            $scrollTo = $chat['id'];
                                            if (date('d-M-Y') == date("d-M-Y", strtotime($chat['date_time']))) {

                                                $time = "Today at " . date("h:i:s", strtotime($chat['date_time']));
                                            } else {
                                                $time = date("d-M-Y", strtotime($chat['date_time'])) . " at " . date("h:i:s", strtotime($chat['date_time']));
                                            }
                                            //****************GET UNREAD MESSAGES******************** *//
                                            $data = array(
                                                'status' => 0,
                                                'conversation' => $conv['id'],
                                                'to_id' => $sender,
                                            );
                                            $unreadMsg = Chat::unread_messages($MSID, $data)->rowcount();
                                            ?>
                                            <small class="time text-muted "><?= $time ?></small>
                                            <?php if (!empty($unreadMsg)) { ?>
                                                <small class="chat-alert label label-danger"><?= $unreadMsg ?></small>
                                            <?php } ?>
                                        </a>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="col-md-6 bg-white ">
                            <div class="chat-box-online-head" id="chat-head" style="height: 40px; text-align: center"><?= $name ?> </div>
                            <input type="hidden" id="receiver" value="<?= $usr_id; ?>">
                            <input type="hidden" id="to_role" value="<?= @$_SESSION['to_role'] ?>">
                            <input type="hidden" id="conversation" value="<?= @$_SESSION['chat_id'] ?>">    
                            <div class="chat-message" id="chat-message" <?= $style ?>>
                                <?php
                                if (@$_SESSION['start_chat']) {
                                    ?>
                                    <ul class="chat" id="chat">
                                        <?php
                                        $to_id = $_SESSION['receiver'];
                                        $receiver = $to_id;
                                        $from_id = $sender;

                                        $chats_data = Chat::get_inbox($MSID, NULL, NULL, $from_id, $to_id, "both", 'all', NULL, 'asc');
                                        while ($chats = $chats_data->fetch()) {
                                            if ($chats['from_id'] == $user_id) {
                                                $side = "right";
                                                $name = $oCurrentUser->myuname;
                                            } else {
                                                $side = "left";
                                                $data = UserManager::get_slusers($chats['from_id'], $MSID)->fetch(PDO::FETCH_ASSOC);
                                                $name = $data['myuname'];
                                            }
                                            $id = $chats['to_id'];
                                            $from_id = $chats['from_id'];
                                            $photo = "http://eschoolexpert.com/uploads/thumbs/photo_1459302550.jpg";
                                            ?> <li class="<?= $side ?> clearfix" id="<?= $chats['id'] ?>">
                                                <span class="chat-img pull-<?= $side ?>">
                                                    <img src="<?= $photo ?>" alt="<?= $name ?>">
                                                </span>
                                                <div class="chat-body clearfix">
                                                    <div class="header">
                                                        <strong class="primary-font"><?= $name ?></strong>
                                                        <?php
                                                        if (date('d-M-Y') == date("d-M-Y", strtotime($chats['date_time']))) {
                                                            $time = "Today at " . date("h:i:s", strtotime($chats['date_time']));
                                                        } else {
                                                            $time = date("d-M-Y", strtotime($chats['date_time'])) . " at " . date("h:i:s", strtotime($chats['date_time']));
                                                        }
                                                        $seconds = date('his', strtotime($chats['date_time']));
                                                        $seconds2 = date('his');
                                                        $diff = $seconds2 - $seconds;
                                                        if ($diff == 1) {
                                                            echo '<embed src="http://demo.eschoolexpert.com/pages/chat/notification.mp3" autoplay="true" loop="false" hidden="true"></embed>';
                                                        }
                                                        ?>
                                                        <small class="pull-right text-muted"><i class="fa fa-clock-o"></i>   <?= $time ?></small>
                                                    </div>
                                                    <p id="<?= $chats['message'] ?>">
                                                        <?= $chats['message'] ?>
                                                    </p>
                                                </div>
                                            </li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                <?php } ?>
                            </div>
                            <input type="text" id="message" class="form-control border no-shadow no-rounded <?= $action ?>" placeholder="Type your message here">
                        </div>        
                        <div class="col-md-3 chat-box-online-div">
                            <div class="no-padding chat-box-online-head" style="float: left; width: 100%">
                                <?= $tabs ?>      
                            </div>    
                            <div class="panel-body chat-box-online" id="Teacher-panel-body" <?= $t_panel ?>>
                                <?php
                                if ($oCurrentUser->ulevel == 1) {
                                    $i = 0;
                                    foreach (array_unique($employee) as $key => $val) {
                                        $data = UserManager::get_slusers($val, $MSID)->fetch(PDO::FETCH_ASSOC);
                                        ?>   
                                        <div class="conversation chat-box-online" id="<?= $data['user_id'] ?>" style="cursor: pointer">
                                            <span class="hidden" id="<?= $data['ulevel'] ?>"></span>
                                            <div id="<?= $data['myuname'] ?>"></div>
                                            <i class="fa fa-user">  </i>  -  <?= $data['myuname'] ?>
                                        </div>
                                        <?php
                                        $i++;
                                    }
                                } elseif ($oCurrentUser->ulevel == 2) {
                                    foreach (array_unique($teachers) as $index => $value) {
                                        $data = UserManager::get_slusers($value, $MSID)->fetch(PDO::FETCH_ASSOC);
                                        ?>
                                        <div class="conversation chat-box-online" id="<?= $data['user_id'] ?>" style="cursor: pointer">
                                            <span class="hidden" id="<?= $data['ulevel'] ?>"></span>
                                            <div id="<?= $data['myuname'] ?>"></div>
                                            <i class="fa fa-user">  </i>  -  <?= $data['myuname'] ?>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>

                            <div class="panel-body chat-box-online" id="Student-panel-body" <?= $s_panel ?>>
                                <?php
                                if ($oCurrentUser->ulevel == 3) {
                                    $parent_id = array();
                                    $parent_name = array();
                                    while ($Classes = $getStudentClasses->fetch()) {
                                        
                                        $Class = Master::get_classes($MSID, NULL, NULL, NULL, NULL, $Classes['Class']);
                                        $data = array('class' => $Class['class_no']);
                                        $GetStudent = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);

                                        while ($stdnts = $GetStudent->fetch()) {
                                            $parent_id[] = $stdnts['uid'];
                                            $parent_name[] = $stdnts['f_name'];
                                            ?>
                                            <div class="conversation chat-box-online" id="<?= $stdnts['s_uid'] ?>" style="cursor: pointer">
                                                <span class="hidden" id="1"></span>
                                                <div id="<?= $stdnts['name'] ?>"></div>
                                                <i class="fa fa-user">  </i>  -  <?= $stdnts['name'] ?> <i class="pull-right label label-success"><?= $stdnts['class_name'] ?></i>
                                            </div>
                                            <?php
                                        }
                                    }
                                }
                                ?>
                            </div>
                            <div class="panel-body chat-box-online" id="Parents-panel-body" <?= $p_panel ?>>
                                <?php
                                if ($oCurrentUser->ulevel == 3) {
                                    foreach ($parent_id as $key => $val) {
                                        ?>
                                        <div class="conversation chat-box-online" id="<?= $val ?>" style="cursor: pointer">
                                            <span class="hidden" id="2"></span>
                                            <div id="<?= $parent_name[$key] ?>"></div>
                                            <i class="fa fa-user">  </i>  -  <?= $parent_name[$key] ?>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>

                            <div class="panel-body chat-box-online" id="Employee-panel-body" <?= $e_panel; ?>>
                                <?php while ($employee = $allEmployee->fetch()) {  //pr($employee);   ?>
                                    <?php if ($employee['uid'] != $oCurrentUser->myuid) { ?>
                                        <div class="conversation chat-box-online" id="<?= $employee['uid']; ?>" style="cursor: pointer">
                                            <span class="hidden" id="<?= $employee['ulevel'] ?>"></span>
                                            <div id="<?= $employee['emp_name'] ?>"></div>
                                            <i class="fa fa-user">  </i>  -  <?= $employee['emp_name'] ?>
                                            <i class="pull-right label label-info"><?= $employee['emp_category'] ?></i>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<style>

    body {
        padding-top: 0;
        font-size: 12px;
        color: #777;
        background: #f9f9f9;
        font-family: 'Open Sans',sans-serif;
        /*margin-top:20px;*/
    }

    .bg-white {
        background-color: #fff;
    }

    .friend-list {
        background: #f9f9f9;
        height: 430px;
        list-style: none;
        padding: 0px;
        overflow-y: scroll;
    }

    .friend-list li {
        border-bottom: 1px solid #eee;
    }

    .friend-list li a img {
        float: left;
        width: 45px;
        height: 45px;
        margin-right: 0px;
    }

    .friend-list li a {
        position: relative;
        display: block;
        padding: 10px;
        transition: all .2s ease;
        -webkit-transition: all .2s ease;
        -moz-transition: all .2s ease;
        -ms-transition: all .2s ease;
        -o-transition: all .2s ease;
    }

    .friend-list li.active a {
        background-color: #f1f5fc;
    }

    .friend-list li a .friend-name, 
    .friend-list li a .friend-name:hover {
        color: #777;
    }

    .friend-list li a .last-message {
        width: 65%;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }

    small, .small {
        font-size: 85%;
    }

    .friend-list li a .chat-alert {
        position: absolute;
        right: 8px;
        top: 27px;
        font-size: 10px;
        padding: 3px 5px;
    }

    .chat-message {
        padding: 15px;
        float: left;
        width: 100%;
    }

    .chat {
        list-style: none;
        margin: 0;
        margin-bottom: 10px !important;


    }

    .chat-message{
        background: #f9f9f9;  
        height: 390px;
        overflow-y: scroll;
    }

    .chat li img {
        width: 45px;
        height: 45px;
        border-radius: 50em;
        -moz-border-radius: 50em;
        -webkit-border-radius: 50em;
    }

    img {
        max-width: 100%;
    }

    .chat-body {
        padding-bottom: 20px;
    }

    .chat li.left .chat-body {
        margin-left: 70px;
        background-color: #fff;
    }

    .chat li .chat-body {
        position: relative;
        font-size: 11px;
        padding: 10px;
        border: 1px solid #f1f5fc;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
        -moz-box-shadow: 0 1px 1px rgba(0,0,0,.05);
        -webkit-box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }

    .chat li .chat-body .header {
        padding-bottom: 5px;
        border-bottom: 1px solid #f1f5fc;
    }

    .chat li .chat-body p {
        margin: 0;
    }

    .chat li.left .chat-body:before {
        position: absolute;
        top: 10px;
        left: -8px;
        display: inline-block;
        background: #fff;
        width: 16px;
        height: 16px;
        border-top: 1px solid #f1f5fc;
        border-left: 1px solid #f1f5fc;
        content: '';
        transform: rotate(-45deg);
        -webkit-transform: rotate(-45deg);
        -moz-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        -o-transform: rotate(-45deg);
    }

    .chat li.right .chat-body:before {
        position: absolute;
        top: 10px;
        right: -8px;
        display: inline-block;
        background: #fff;
        width: 16px;
        height: 16px;
        border-top: 1px solid #f1f5fc;
        border-right: 1px solid #f1f5fc;
        content: '';
        transform: rotate(45deg);
        -webkit-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -o-transform: rotate(45deg);
    }

    .chat li {
        margin: 15px 0;
    }

    .chat li.right .chat-body {
        margin-right: 70px;
        background-color: #fff;
    }

    .chat-box {
        /*position: fixed;*/
        bottom: 0;
        left: 444px;
        right: 0;
        padding: 15px;
        border-top: 1px solid #eee;
        transition: all .5s ease;
        -webkit-transition: all .5s ease;
        -moz-transition: all .5s ease;
        -ms-transition: all .5s ease;
        -o-transition: all .5s ease;
    }

    .primary-font {
        color: #3c8dbc;
    }

    a:hover, a:active, a:focus {
        text-decoration: none;
        outline: 0;
    }
    .chat-box-online-head {
        background-color: #03db2f;
        border-bottom: 2px solid #03db2f;
        color: #fff;
        padding: 10px 15px;
        text-align: center;
    }.chat-box-online {
        max-height: 554px;
        overflow: auto;
    }
    .chat-box-online-left {
        color: #049e64;
        margin-left: 10px;
        text-align: left;
    }
    .hr-clas-low {
        border-top: 1px solid #c5c5c5;
    }.chat-box-online-right {
        color: #354ea0;
        margin-right: 10px;
        text-align: right;
    }.img-circle {
        border-radius: 50%;
    }

    .panel-body.chat-box-online{
        height: 430px;
        overflow-y: scroll;
        margin-bottom: 10px;
        margin-top: 10px;
        background: #F9F9F9;
    }
    .active-list {
        background: yellowgreen;
    }
    .chat-list{
        padding: 11px 5px;
        cursor: pointer;
    }
    .chat-list:hover{
        background: #c5c5c5;
        opacity: 0.5;
        color:#fff;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script>
    //for auto show the cuisine item
    $(document).ready(function () {
        "use strict";
        $(document).on('click', '.conversation', function () {
            var name = $(this).children('div').attr('id');
            var sender = '<?= $sender ?>';
            var receiver = this.id;
            var conv = $(this).closest('li').attr('id');
            var read = 1;
            var scrollBottom = $('#chat-message');
            $('#conversation').val(conv);
            $('#chat-message').animate({height: '390px'});
            $('#message').removeClass('hidden');
            $('#chat-head').text(name);
            $('#receiver').val(this.id);
            $('#to_role').val($(this).children('span').attr('id'));
            var to_role = $('#to_role').val();
            var chat_id = $('#conversation').val();
            $.ajax({
                url: "<?= CLIENT_URL ?>/chat_inbox",
                type: 'POST',
                data: {
                    start_chat: "start",
                    chat_id: conv,
                    read: read,
                    name: name,
                    sender: sender,
                    receiver: receiver,
                    to_role: to_role,
                },
                success: function (resp) {
                    scrollBottom.load(location.href + " #chat-message>*");
                    $('#chat-message').animate({scrollTop: $('#chat').prop('scrollHeight')}, 1000);
                }
            });
        });
        $(document).bind('keydown focus', '#message', function () {
            var conversation = $('#conversation').val();
            var read = 1;
            $.ajax({
                url: '<?= CLIENT_URL ?>/chat_inbox',
                type: 'POST',
                data: {conversation: conversation, read: read},
                success: function () {}
            });
        });
        $(document).on('keypress', '#message', function (press) {
            var school_id = <?= $MSID ?>;
            var from_id = '<?= $sender; ?>';
            var to_id = $('#receiver').val();
            var msg = $('#message').val();
            var to_role = $('#to_role').val();
            var from_role = <?= $oCurrentUser->ulevel ?>;
            if (press.which === 13 && msg !== null)
            {
                $('#message').val('');
                $.ajax({
                    url: '<?= CLIENT_URL ?>/chat_inbox',
                    type: 'POST',
                    data: {
                        school_id: school_id,
                        to_id: to_id,
                        to_role: to_role,
                        from_id: from_id,
                        from_role: from_role,
                        msg: msg,
                    },
                    success: function (resp) {
                        $('#chat').load(location.href + " #chat>*");
                        $('#friend-list').load(location.href + " #friend-list>*");
                        $('#chat-message').animate({scrollTop: $('#chat').prop('scrollHeight')}, 1000);
                    }
                });
            }

        });
        $(function () {
            setInterval(function () {
                $('#chat').load(location.href + " #chat>*");
//                $('#chat-message').animate({scrollTop:$('#chat').prop('scrollHeight')}, 100);
            }, 1000);
            setInterval(function () {
                $('#friend-list').load(location.href + " #friend-list>*");
            }, 1000);

            $(document).on('click', '#e_panel', function () {
                $('#Student-panel-body, #Parents-panel-body').hide(500);
                $('#Employee-panel-body').delay(500).show(500);
                $('#e_panel').addClass('active-list');
                $('#s_panel, #p_panel').removeClass('active-list');
            });
            $('#s_panel').on('click', function () {
                $('#Employee-panel-body, #Parents-panel-body').hide(500);
                $('#Student-panel-body').delay(500).show(500);
                $('#s_panel').addClass('active-list');
                $('#e_panel, #p_panel').removeClass('active-list');
            });
            $('#p_panel').on('click', function () {
                $('#Employee-panel-body, #Student-panel-body').hide(500);
                $('#Parents-panel-body').delay(500).show(500);
                $('#p_panel').addClass('active-list');
                $('#e_panel, #s_panel').removeClass('active-list');
            });
        });
    });
</script>