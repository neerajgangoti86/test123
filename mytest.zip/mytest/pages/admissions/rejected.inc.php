<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12"> <?php $message = new Messages(); echo $message->display(); ?>
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">List of rejected students &nbsp;</h3>
            <h3 class="box-title"></h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body table-responsive no-padding">
          <?php if($totalrecords > 0){ ?>
            <table class="table table-hover">
            <thead style="background:#ddd;">
              <tr>
                <th>ID</th>
                <th>Admission No.</th>
                <th>Class</th>
                <th>Name</th>
                <th>Father Name</th>
                <th>Mother Name</th>
                <th>Action</th>
                <!--<th>D.O.B.</th>
                <th>House</th>
                <th>SMS Mobile</th>
                <th>Locality</th>-->
              </tr>
              </thead>
              <?php $i =1; while($rowv = $students->fetch()){ 
//					$local = Master::get_locality($MSID,$rowv['village'],1)->fetch();
					$classarr = classes_list(); ?>
              <tr id="st_<?= $rowv['student_id']; ?>">
                <td><?= $rowv['student_id']; ?></td>
                <td><?= $rowv['admno']? $rowv['admno']: '--'; ?></td>
                <td><?= $classarr[$rowv['adm_classno']]; ?></td>
                <td><?= $rowv['name']; ?></td>
                <td><?= $rowv['f_name']; ?></td>
                <td><?= $rowv['m_name']; ?></td>
                <!--<td><?= date('d M,Y',strtotime($rowv['birth_date'])); ?></td>
                <td><?= $rowv['house']; ?></td>
                <td><?= $rowv['mobile_sms']; ?></td>
                <td><?= $rowv['village']; ?></td>-->
                <td><a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $rowv['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin:0 10px 0 0;">View</a><a data-bb="confirm" class="btn bg-orange btn-flat" href="<?= CLIENT_URL; ?>/rejected/bck/<?= $rowv['student_id']; ?>">Select Back</a></td>
              </tr>
              <?php } ?>
            </table>
            <?php }else{ echo '<div class="text-center margin">No records found.</div>'; } ?>
          </div>
          <div class="box-footer clearfix">
          <?= $pagination ?>
        </div>
          
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>
  <!-- Main content -->
<?php  
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
