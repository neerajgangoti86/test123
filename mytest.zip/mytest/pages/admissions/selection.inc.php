<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12"> <?php $message = new Messages(); echo $message->display(); ?>
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">List of new students for admission &nbsp;</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
           <?php if($totalrecords > 0){
               foreach($students->fetchAll(PDO::FETCH_ASSOC) as $val){ 
		      /*$enrolled = $sAdmission->get_enrolled_std($MSID,'','','',$val['adm_classno'])->fetchAll(PDO::FETCH_ASSOC);
			  foreach($enrolled as $enstd){ 
			  
			  }*/
			  $class = Master::get_classes($MSID, '', '', '',$val['adm_classno'])->fetch(PDO::FETCH_ASSOC);?>
               <input type="radio" name="class_check" class="class_check" value="<?= $class['class_no'];?>">
               <label for="exampleInputPassword1"><?= $class['class_name'];?></label>
               <input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
               &nbsp;&nbsp;
          <?php  }}else{ echo '<p>No new enrollment found.</p>';}?>
            <div class="form-group" id="enrollstudent">
              
            </div>
          </div>
          <!-- /.box-body -->
          <!--<div class="box-footer clearfix">
                  <ul class="pagination pagination-sm no-margin pull-right">
                    <li><a href="#">&laquo;</a></li>
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">&raquo;</a></li>
                  </ul>
                </div>-->
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>
  <!-- Main content -->
  <div class="text-center loading-div"><div class="ld-content"><span class="fa fa-circle-o-notch fa-spin fa-3x text-red"></span><h4>Loading...</h4></div></div>
  <?php
  $sBottomJavascript = <<<EOT
  <script type="text/javascript">
$(document).ready(function(){
	$('body').on('click','[data-ms="modal"]', function(e) {
		var link = $(this);
		var options = {
			url: link.attr("href"),
			title: link.attr("data-title"),
			size : 'lg'
		};
	   eModal.setEModalOptions({
			loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
		});
	   eModal.ajax(options);
	   return false;
	});

    var demos = {};
    $(document).on("click", "a[data-reject]", function(e) {
        e.preventDefault();
        var type = $(this).data("reject");

        if (typeof demos[type] === 'function') {
            demos[type](this);
        }
    });
    demos.confirm = function(e) {
	var options = {
        message: "Are you sure you want to reject this admission?",
        label: "Yes"   // use the positive label as key
    };
   eModal.confirm(options).then(function() { var href = e.href; window.location = href;});
    };
	
	$('.class_check').click(function(){
	   $('#enrollstudent').html('');
	   var classid = $(this).val();
	   var siteurl = $('#site_url').val();	
	   $('#enrollstudent').html('Loading....');
	    $.ajax({
			url: siteurl+"/ajax-page-load/enrollment_std",
			type: "post",
			data: { classid: classid} ,
			success: function (response) {
			  $('#enrollstudent').html(response);
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
        });

	});	
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>