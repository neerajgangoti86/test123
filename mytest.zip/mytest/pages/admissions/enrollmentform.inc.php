<!-- Main content -->

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php
            $message = new Messages();
            echo $message->display();    
//            print_r($step) ;
            ?>

            <?php //print_r($oCurrentUser); ?>
        </div>

        <div class="col-md-12">
            <!-- general form elements --><div class="box box-primary">
                <!--<form id="addmissionfrm" name="addmissionfrm" method="post" action="" enctype="multipart/form-data">-->

                <h2 class="page-header">Student Enrollement </h2>
                <div class="row">
                    <div class="col-md-12">
                        <!-- Custom Tabs -->
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="<?php echo (@$step ) ? "" : "active"; ?>"><a href="javascript:void(0);" data-toggle="tab">Student Detail </a></li>
                                <li class="<?php echo (@$step && $step == "1") ? "active" : ""; ?>"><a href="javascript:void(0);" data-toggle="tab">Parent Detail</a></li>
                                <li class="<?php echo (@$step && $step == "2") ? "active" : ""; ?>"><a href="javascript:void(0);" data-toggle="tab">Student Documents</a></li>
                                <li class="<?php echo (@$step && $step == "3") ? "active" : ""; ?>"><a href="javascript:void(0);" data-toggle="tab">Student Profile</a></li>

                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane <?php echo (@$step ) ? "" : "active"; ?>" id="tab_1">
                                    <form id="addmissionfrm" name="addmissionfrm" method="post" action="" enctype="multipart/form-data">
                                        <div class="box-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div style="" class="formCon">
                                                    <!--<div style="background:url(<?= ASSETS_FOLDER ?>/img/yellow-pattern.png); width:100%; border:0px #fac94a solid; color:#000; " class="formCon">-->
                                                        <div style="padding:5px;" class="formConInner">

                                                        </div>
                                                    </div>
                                                </div>


                                                <!--                                                <div class="col-md-6">
                                                                                                    <div class="form-group">
                                                <?php
                                                $admission = new Admission();
                                                $get_student = $admission->get_enrolled_std($MSID, 1, '', 'all');

                                                $get_student_cnt = $get_student->rowCount();
                                                if ($get_student_cnt > 0) {
                                                    $rowv = $get_student->fetch();
                                                    $student_id = $rowv['student_id'] + 1;
                                                } else {
                                                    //echo substr($oCurrentUser->mysession,2);
                                                    //print_r();
                                                    $student_id = substr($oCurrentUser->mysession, 2) . '001';
                                                    //exit();
                                                }
                                                ?>                                                       
                                                
                                                                                                        <label>Student ID / Reg No: <span class="text-red">*</span></label>
                                                                                                        <input type="text" class="form-control"  value="<?= $student_id ?>" size="30" id="name" name="student[stu_no]" required>
                                                                                                    </div> 
                                                                                                </div>-->



                                                <?php
                                                if ($oCurrentSchool->admno_auto == '0') {
                                                    ?>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Registration No <span class="text-red">*</span></label>
                                                            <input type="text" class="form-control" value="<?= $student_id ?>
                                                                   " size="30" id="" name="student[stu_id]" required>
                                                        </div> </div>
                                                    <?php
                                                } else {
                                                    ?>
                                                    <input type="hidden" value="0" name="student[stu_id]"/>    
                                                    <?php
                                                }
                                                ?>

                                                <div class="col-md-6">
                                                    
                                                    <div class="form-group">
                                                        <label>Admission Date <span class="text-red">*</span></label>
                                                        <input type="text" class="form-control" value="<?php
                                                        //echo $oCurrentUser->mydate;
                                                        $admission_date = $oCurrentUser->mydate;
                                                        echo $admissiondate = date("d-m-Y", strtotime($admission_date));
                                                        ?>" size="30" id="" name="student[adm_date]" required>
                                                   
                                                    </div>
                                                    
                                                    </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Admission Class<span class="text-red">*</span></label>
                                                        <select id="aclass" name="student[aclass]" class="form-control "  required>
                                                            <option id="first_select" value="">Select Class</option>
                                                            <?php
                                                            foreach ($classs as $class) {
                                                                /* if (@$_POST['student']['aclass']== $class['class_no']) {
                                                                  $selected = 'selected="selected"';
                                                                  } else {
                                                                  $selected = '';
                                                                  } */
                                                                ?>
                                                                <option value="<?= $class['class_no']; ?>"><?= $class['class_name']; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>

                                                </div>
                                                <div class="col-md-6">

                                                    <div class="form-group feestartDate">
                                                        <label>Fee Start Date <span class="text-red">*</span></label>
                                                        <?php $feemontharr = array('03' => 'Mar', '04' => 'Apr', '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Aug', '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec'); ?>


                                                        <input class="form-control"  type="text"  value="<?php
                                                        $originalDate = $oCurrentUser->mydate;
                                                        echo $newDate = date("01-m-Y", strtotime($originalDate));
                                                        ?>" size="15" id="feesdate1" name="student[feesdate1]" required>
                                                    </div></div><div id="selection"></div><div class="col-md-6">

                                                    <div class="form-group">
                                                        <label>Name <span class="text-red">*</span></label>
                                                        <input type="text" class="form-control" size="30" id="name" value="<?php
                                                        if (isset($_POST['student']['name'])) {
                                                            echo $_POST['student']['name'];
                                                        }
                                                        ?>" name="student[name]" required>
                                                    </div></div>
                                                <div class="col-md-6">

                                                    <div class="form-group feestartDate">
                                                        <label>Date Of Birth <span class="text-red">*</span></label>
                                                        <input class="form-control adm_date" type="text" autocomplete="off" size="15" value="<?php
                                                        if (isset($_POST['student']['dob'])) {
                                                            echo $_POST['student']['dob'];
                                                        }
                                                        ?>"  id="dob" name="student[dob]" required>
                                                    </div></div>

                                                <?php
                                                if ($oCurrentSchool->school_type == "0") {
                                                    ?><div class="col-md-6">
                                                        <div class="form-group">

                                                            <label>Gender <span class="text-red">*</span></label>
                                                            <select class="form-control" id="Gender" name="student[Gender]" required >
                                                                <option value=""  >Select</option>
                                                                <option value="M" <?php
                                                                if (isset($_POST['student[Gender]'])) {
                                                                    echo "selected";
                                                                }
                                                                ?>>M</option>
                                                                <option value="F" <?php
                                                                if (isset($_POST['student[Gender]'])) {
                                                                    echo "selected";
                                                                }
                                                                ?>>F</option>
                                                            </select>
                                                        </div></div>
                                                    <?php
                                                } elseif ($oCurrentSchool->school_type == "1") {
                                                    ?>
                                                    <input type="hidden" value="M" name="student[Gender]">
                                                    <?php
                                                } else {
                                                    ?>  
                                                    <input type="hidden" value="F" name="student[Gender]">
                                                <?php } ?>  
                                                <div class="col-md-6">



                                                    <?php
                                                    if ($oCurrentSchool->house == '1') {
                                                        ?>
                                                        <div class="form-group">
                                                            <label>House<span class="text-red">*</span></label>  &nbsp;&nbsp;&nbsp;&nbsp;   <a href="<?= CLIENT_URL ?>/students" target="_blank"><b>Check House</b></a>
                                                            <?php $housearr = Master::get_houses($MSID); ?>



                                                            <select class="form-control" id="house" name="student[house]" required>
                                                                <option value="">Select House</option>
                                                                <?php
                                                                while ($rowv = $housearr->fetch()) {
                                                                    ?>
                                                                    <option value="<?php echo $rowv['house_id']; ?>"><?php echo $rowv['house_f_name']; ?></option>
                                                                <?php } ?>
                                                            </select>



                                                        </div>

                                                    <?php } else {
                                                        ?>
                                                        <input type="hidden"  name="student[house]" value="0">
                                                        <?php
                                                    }
                                                    ?>
                                                </div>




                                                <?php
                                                if ($oCurrentSchool->transport == '1') {

                                                    if ($tpt_stations_count > 0) {
                                                        ?> 

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Transportation</label>



                                                                <input type="radio" name="student[transport]" id="option1" onclick="ShowHideDiv()" value="1" <?php
                                                                if (isset($_POST['student[transport]']) && $_POST['student[transport]'] == "1") {
                                                                    echo "checked";
                                                                }
                                                                ?>/>Yes 
                                                                <input type="radio" name="student[transport]" id="option2" onclick="HideDiv()" value="0" <?php
                                                                if (isset($_POST['student[transport]']) && $_POST['student[transport]'] == "0") {
                                                                    echo "checked";
                                                                }
                                                                ?>/>No
                                                                <select class="form-control" id="tpt" name="student[tpt]" style="display:none;">

                                                                    <?php
                                                                    foreach ($tptstations as $station) {
                                                                        echo '<option value="' . $station["station_id"] . '">' . ucfirst($station["station_name"])  . '</option>';
                                                                    }
                                                                    ?>
                                                                </select>

                                                            </div>

                                                        </div>


                                                        <?php
                                                    } else {
                                                        ?>
                                                        <input type="hidden" name="student[tpt]" value="0"/>

                                                        <?php
                                                    }
                                                } else {
                                                    ?>
                                                    <input type="hidden" name="student[tpt]" value="0"/>
                                                    <?php
                                                }
                                                ?>
                                                <?php
                                                if ($oCurrentSchool->discount == '1') {



                                                    if ($discount_count > 0) {
                                                        ?>
                                                        <div class="col-md-6">                                  

                                                            <div class="form-group">
                                                                <label>Discount</label>

                                                                <input type="radio" name="student[discount]" id="option11" onclick="ShowHideDiv1()" value="1" <?php
                                                                if (isset($_POST['student[discount]']) && $_POST['student[discount]'] == "1") {
                                                                    echo "checked";
                                                                }
                                                                ?>/>Yes 
                                                                <input type="radio" name="student[discount]" id="option21" onclick="HideDiv1()" value="0" <?php
                                                                if (isset($_POST['student[discount]']) && $_POST['student[discount]'] == "0") {
                                                                    echo "checked";
                                                                }
                                                                ?>/>No
                                                                <select class="form-control" id="disc" name="student[disc]" style="display:none;">
                                                                    <?php
                                                                    foreach ($discounts as $station) {
                                                                        echo '<option value="' . $station["discount_id"] . '">' . ucfirst($station["name"]). '</option>';
                                                                    }
                                                                    ?>
                                                                </select>

                                                            </div>
                                                        </div>
                                                        <?php
                                                    } else {
                                                        ?>
                                                        <input type="hidden" name="student[disc]" value="0"/> 
                                                        <?php
                                                    }
                                                } else {
                                                    ?>
                                                    <input type="hidden" name="student[disc]" value="0"/>
                                                    <?php
                                                }
                                                ?>







                                                <!-- \col 3 -->

                                                <div class="col-md-6">

                                                    <div class="form-group">
                                                        <label>Email</label>
                                                        <input class="form-control" type="email" value="<?php if (@$_POST['student']['email']) echo $_POST['student']['email']; ?>" size="30" id="email" name="student[email]" >
                                                    </div></div>

                                                <div class="col-md-6" id="subject_group" style="display:none;">
                                                    <div class="form-group">
                                                        <label>Subject Group</label>
                                                        <select class="form-control" id="groupid" name="student[groupid]">
                                                            <option value="">Select</option>
                                                            <?php
                                                            $school_sub = SuperAdmin::get_school_subject($MSID, '', 'all');
                                                            print_r($school_sub);
//print_r($school_sub);
                                                            if ($school_sub->rowCount() > 0) {
                                                                while ($rowv = $school_sub->fetch()) {

                                                                    $subjects = SuperAdmin::get_subject_group($rowv['subject_gp_id'])->fetch(PDO::FETCH_OBJ);
                                                                    ?> <option value="<?= $subjects->group_id ?>"><?= $subjects->Subjects ?></option>
                                                                <?php } ?>
                                                                <?php
                                                            } else {
                                                                ?>
                                                                <input type="hidden" name="student[groupid]" value="0"/>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div> 
                                                <div class="col-md-6">

                                                    <div class="form-group">
                                                        <label>Birth Certificate Received ?</label>
                                                        <select class="form-control" id="birthc" name="student[birthc]">
                                                            <option value="1" selected="selected">Yes</option>
                                                            <option value="0">No</option>
                                                        </select>
                                                    </div></div>

                                                <div class="col-md-6">

                                                    <div class="form-group">
                                                        <label>If Ward of Staff</label>
                                                        <select class="form-control" id="wos" name="student[wos]">
                                                            <option value="0">No </option>
                                                            <option value="1">Yes </option>

                                                            <?php
                                                            if ($oCurrentSchool->ward_of_company == '1') {
                                                                ?>  
                                                                <option value="3">Company</option>
                                                                <?php
                                                            }
                                                            ?>

                                                        </select>
                                                    </div></div>


                                                <?php
                                                if ($oCurrentSchool->hostel == '1') {


                                                    //print_r($hostel);
                                                    //print_r($hostel_stu_data);

                                                    if ($hostel_count > 0) {
                                                        ?>
                                                        <div class="col-md-6">

                                                            <div class="form-group">
                                                                <label>Hostel</label>
                                                                <select class="form-control" id="hostel" name="student[hostel]">
                                                                    <option value="0" selected>None</option>
                                                                    <?php
                                                                    foreach ($hostels as $hostel) {
                                                                        ?>
                                                                        <option value="<?= $hostel['id'] ?>"><?= $hostel['name'] ?></option>

                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div></div>
                                                        <?php
                                                    } else {
                                                        ?>
                                                        <input type="hidden" name="student[hostel]" value="0"/>
                                                        <?php
                                                    }
                                                    ?>
                                                    <?php
                                                } else {
                                                    ?>
                                                    <input type="hidden" name="student[hostel]" value="0"/>

                                                    <?php
                                                }
                                                ?>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Blood Group</label>
                                                        <?php $bloodgrparr = array('A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-'); ?>
                                                        <select class="form-control" id="bgroup" name="student[bgroup]">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($bloodgrparr as $value) {
                                                                echo '<option value="' . $value . '">' . $value . '</option>';
                                                            }
                                                            ?>
                                                        </select>
                                                    </div></div>






                                                <div class="col-md-6">
                                               <div class="form-group">
                                                        <label>Profile Photo </label>
                                                        <input type="file" name="photo">
                                                    </div>
                                                </div>


                                                <div class="col-md-6">

                                                    <div class="form-group">
                                                        <label>Aadhar No</label>
                                                        <input class="form-control" type="text" value="" size="30" id="email" name="student[aadhar]" >
                                                    </div></div>


                                                <!-- \col 3 -->
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <input type="hidden" name="step_1" value="1">

                                                    <input type="hidden" name="session" value="<?= $oCurrentUser->mysession; ?>"/>
                                                    <input type="hidden" name="student_id" value="<?= $student_id ?>"/>
                                                    <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Parent Details &nbsp;&nbsp;&nbsp;&nbsp;>></button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div><!-- /.tab-pane -->
                                <div class="tab-pane <?php echo (@$step && $step == "1") ? "active" : ""; ?>" id="tab_2">
                                    <?php if (@$step == "1") { ?>
                                        <form id="parentfrm" name="parentfrm" method="post" action="" enctype="multipart/form-data">
                                            <div class="box-header">
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <h3 class="box-title"><u>Parents Information</u></h3>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <button style="width:43%; float:left;" class="btn btn-block btn-warning btn-flat parent_reset">Reset Parent</button>
                                                        <a href="<?= CLIENT_URL ?>/ajax-page-load/list" style="width: 43%; display: inline-block; margin: 0px 0px 0px 9px;" data-title="Parents" data-ms="modal" class="btn btn-block btn-warning btn-flat">Select Parents</a> </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">        
                                                <div class="form-group">
                                                    <label>Locality<span class="text-red">*</span> &nbsp;&nbsp;
                                                        <a href="<?= CLIENT_URL ?>/ajax-page-load/locality_select" data-title="Select Locality" data-ms="modal">Add Locality</a></label>
                                                    <?php
                                                    $local_fetch1 = Master::get_locality_list2($MSID, $oCurrentSchool->locality_pincode);
//                                                        print_r($local_fetch1);
                                                    $ids = array();
                                                    while ($local = $local_fetch1->fetch(PDO::FETCH_ASSOC)) {
                                                        $ids[] = $local['id'];
                                                    }
                                                    $ids_all = implode(',', $ids);
//                                                          print_r($ids_all);

                                                    $local_fetch = Master::get_locality_list3($ids_all);

                                                    // print_r($local_fetch);
//                                                  
                                                    ?>

                                                    <select class="form-control" id="locality" name="parent[locality]" required>
                                                        <option value="">Select</option>
                                                        <?php
                                                        while ($local = $local_fetch->fetch(PDO::FETCH_ASSOC)) {
//                                                                print_r($local);
                                                            echo '<option value="' . $local['id'] . '">' . ucfirst($local['name']) . '</option>';
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6">              
                                                        <div class="form-group">
                                                            <label>Religion</label>
                                                            <select class="form-control" id="religion" name="parent[religion]">

                                                                <?php
                                                                foreach (religion() as $key => $value) {
                                                                    echo '<option value="' . $value . '">' . ucfirst($value). '</option>';
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                            
                                            
                                            <div class="box-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Father's Name<span class="text-red">*</span></label>
                                                            <input class="form-control" value="" type="text" size="30" id="name7" name="parent[fname]" required>
                                                        </div>
                                                    </div> 
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Mother's Name <span class="text-red">*</span></label>
                                                            <input class="form-control" type="text" value="" size="30" id="mname" name="parent[mname]" required>
                                                        </div>
                                                    </div> 
                                                    <div class="col-md-6">  
                                                        <div class="form-group">
                                                            <label>Father Qualification</label>
                                                            <select class="form-control" id="f_qualification" name="parent[f_qualification]">
                                                                <option value="">Select Qualification</option>
                                                                <?php
                                                                foreach (qualifications() as $key => $value) {
                                                                    echo '<option value="' . $value . '">' . $value . '</option>';
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>   <div class="col-md-6">           
                                                        <div class="form-group">
                                                            <label>Mother Qualification</label>
                                                            <select class="form-control" id="m_qualification" name="parent[m_qualification]">
                                                                <option value="">Select Qualification</option>
                                                                <?php
                                                                foreach (qualifications() as $key => $value) {
                                                                    echo '<option value="' . $value . '">' . $value . '</option>';
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">   
                                                        <div class="form-group">
                                                            <label>Father Occupation</label>
                                                            <select class="form-control" id="f_occupation" name="parent[f_occupation]">
                                                                <option value="">Select Occupation</option>
                                                                <?php
                                                                foreach (f_occupation() as $value) {
                                                                    echo '<option value="' . $value . '">' . $value . '</option>';
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div> <div class="col-md-6">      
                                                        <div class="form-group">
                                                            <label>Mother Occupation</label>
                                                            <select class="form-control"  id="m_occupation" name="parent[m_occupation]"/>
                                                            <option value="">Select Occupation</option>
                                                            <?php
                                                            foreach (m_occupation() as $value) {
                                                                echo '<option value="' . $value . '">' . $value . '</option>';
                                                            }
                                                            ?>
                                                            </select>
                                                        </div>
                                                    </div> 
                                                    <div class="col-md-6"> 
                                                        <div class="form-group">
                                                            <label>Father Mobile</label>
                                                            <input class="form-control" value=""  type="tel" maxlength="10" size="10" id="fmob" pattern="[0-9]{10,10}" name="parent[fmob]">
                                                        </div>
                                                    </div> 


                                                    <div class="col-md-6">        
                                                        <div class="form-group">
                                                            <label>Mother Mobile</label>
                                                            <input class="form-control" type="tel" value="" maxlength="10" size="10" id="name15" pattern="[0-9]{10,10}"  name="parent[mmob]">
                                                        </div>
                                                    </div> 
                                                    <div class="col-md-6">             
                                                        <div class="form-group">
                                                            <label>Annual Income</label>
                                                            <select class="form-control" id="Annual_Income" name="parent[al_income]">
                                                                <option value="">Select </option>
                                                                <?php
                                                                foreach (annual_income() as $value) {
                                                                    echo '<option value="' . $value . '">' . $value . '</option>';
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <?php
//echo "<pre>";
//print_r($oCurrentSchool);
//echo "</pre>";
                                                    if ($oCurrentSchool->SeprateTPTFBook == '1') {
                                                        //echo "1";
                                                        ?>
                                                        <div class="col-md-6">

                                                            <div class="form-group" id="sep2_fee_book">
                                                                <!--<label>Separate Fee Book</label>-->
                                                                <?php $counts = Student::get_std_count($MSID, $student->parent_id)->fetchAll(PDO::FETCH_OBJ);
                                                                ?>
        <!--                                                            <input type="radio" name="parent_account" value="1" id="parent_account_yes" onclick="show_list();"/>Yes
                                                                <input type="radio" name="parent_account" value="0" id="parent_account_No" onclick="hide_list();"/>No-->

                                                                <?php /* <select class="form-control" id="account_no" name="parent[account_no]" style="display:none;">

                                                                  <?php
                                                                  if (!empty($counts)) {
                                                                  foreach ($counts as $val) {
                                                                  ?>
                                                                  <option value="<?php echo $val->student_id ?>"><?php echo $val->student_id ?></option>
                                                                  <?php
                                                                  }
                                                                  } else {
                                                                  ?>
                                                                  <option value="<<?= $s_id; ?>"><?= $s_id; ?></option>
                                                                  <?php
                                                                  } */
                                                                ?>

                                                                <!--                                                            </select>-->

                                                                <input type="hidden" class="form-control" value="" id="parent[sep_fees_book_box]"/>
                                                            </div></div>

                                                        <?php
                                                    }
                                                    ?>



                                                    <div class="col-md-6">    
                                                        <div class="form-group">
                                                            <label>Category<span class="text-red">*</span></label>
                                                            <?php $category = Master::get_category($MSID, '', 1);
                                                            ?>
                                                            <select class="form-control" id="category" name="parent[category]" required>
                                                                <option value="">Select Category</option>
                                                                <?php
                                                                /* echo "<pre>";
                                                                  print_r($category);
                                                                  echo "</pre>"; */
                                                                while ($cat = $category->fetch()):
                                                                    echo '<option value="' . $cat['id'] . '">' . $cat['name'] . '</option>';
                                                                endwhile;
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div> 
                                                    <div class="col-md-6">       
                                                        <div class="form-group">
                                                            <label>Address Line1</label>
                                                            <input class="form-control" type="text" value="" size="20" id="addline1" name="parent[addline1]">
                                                        </div>
                                                    </div> 
                                                    <!--                                                <div class="col-md-6">          
                                                                                                        <div class="form-group">
                                                                                                            <label>Address Line2</label>
                                                                                                            <input class="form-control" type="text" value="" size="20" id="name16" name="parent[addline2]">
                                                                                                        </div>
                                                                                                    </div> -->

                                                    <div class="col-md-6">          
                                                        <div class="form-group">
                                                            <label>Land Line</label>
                                                            <input class="form-control" type="text" value="" size="12" id="name11" name="parent[landline]">
                                                        </div>
                                                    </div> 
                                                    
                                                      <div class="col-md-6">            
                                                <div class="form-group">
                                                    <label>Mobile No 4 SMS<span class="text-red">*</span></label>
                                                    <input class="form-control" value="" type="tel" maxlength="10" size="10" id="mobsms15" pattern="[0-9]{10,10}" name="parent[mobsms]" required>
                                                </div>
                                            </div>
                                                    <div class="col-md-6">              
                                                        <div class="form-group">
                                                            <label>Permanent Address</label>
                                                            <textarea class="form-control" id="padd" name="parent[padd]"></textarea>
                                                        </div>
                                                    </div> 

                                                    <!-- \col -->
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <input type="hidden" name="step_2" value="2">
                                                        <input type="hidden" name="s_id" value="<?= $s_id; ?>">

                                                        <input type="hidden" name="<?= $student_id ?>" name="parent[student_id]"/>

                                                        <button type="submit" name="rsubmit2" class="btn btn-lg btn-success btn-block">Submit >> </button>
                                                    </div>
                                                    <!-- \col -->
                                                </div>
                                            </div>
                                        </form> 
                                    <?php } ?></div>
                                <div class="tab-pane <?php echo (@$step && $step == "2") ? "active" : ""; ?>" id="tab_3">
                                    <?php
                                    if (@$step == "2") {
                                        $std_dtl = Admission::get_last_student2($MSID, $s_id)->fetch(PDO::FETCH_OBJ);
//                                                            print_r($std_dtl);
                                        ?>

                                        <form id="doxfrm" name="doxfrm" method="post" action="" enctype="multipart/form-data">

                                            <div class="box-body">
                                                <div class="row">

                                                    <div class="col-md-6">

                                                        <div class="form-group">
                                                            <div class="row">
                                                                <?php if ($oCurrentSchool->combine_feebook == "1") {
                                                                    ?>

                                                                    <div class="col-md-6"> 

                                                                        <label>Select Combined Account No  <span class="text-red"></span></label>
                                                                    </div>
                                                                    <div class="col-md-6">  

                                                                        <select name="select_fee" id="select_fee" class="select_feebook">
                                                                            <?php
                                                                            if (http_get('param1') != "sucess") {

                                                                                @$result_student = Admission::get_last_student2($MSID, $s_id);



                                                                                @$parent_get = @$result_student->fetch();

                                                                                //print_r($parent_get);


                                                                                @$result = Parents::get_student_account2($MSID, @$parent_get['parent_id']);

                                                                                //print_r($result);

                                                                                if (@$result->rowCount() > 0) {
                                                                                    while ($v = $result->fetch()) {
                                                                                        ?>
                                                                                        <option value="<?= $v['student_id'] ?>" ><?= $v['student_id']; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    ?>
                                                                                    <option value="<?= $student_id ?>" ><?= $student_id ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>


                                                                            </select>


                                                                        </div>  

                                                                    <?php }
                                                                } else {
                                                                    ?>     
                                                                    <input type="hidden" name="select_fee" value="0"/>
    <?php } ?>
                                                            </div>   
                                                        </div>



                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-6">  <label>Aadhar Certificate <span class="text-red"></span></label>
                                                                </div> <div class="col-md-6">   <input type="file" name="adhaar_cirtificate">
                                                                </div>
                                                            </div>

                                                        </div>


                                                        <div class="form-group">
                                                            <div class="row">  <div class="col-md-6">  <label>Report Card <span class="text-red"></span></label>
                                                                </div> <div class="col-md-6">   <input type="file" name="report_cirtificate">
                                                                </div></div>
                                                        </div>


                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-6">  <label>School Leaving Certificate <span class="text-red"></span></label>
                                                                </div> <div class="col-md-6">   <input type="file" name="schooleaving_cirtificate">
                                                                </div></div>
                                                        </div>


                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-6">  <label>Birth Certificate <span class="text-red"></span></label>
                                                                </div> <div class="col-md-6">   <input type="file" name="birth_cirtificate">
                                                                </div></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row"><div class="col-md-6"><label>Character  Certificate <span class="text-red"></span></label>
                                                                </div> <div class="col-md-6"><input type="file" name="character_cirtificate">
                                                                </div></div></div>
                                                        <div class="form-group">
                                                            <div class="row"> <div class="col-md-6"> <label>Other <span class="text-red"></span></label>
                                                                </div> <div class="col-md-6">  <input type="file" name="other_cirtificate">
                                                                </div>  </div>

                                                        </div>

    <?php $start = substr($oCurrentUser->mysession, 2) . "001"; ?>
                                                        <input type="hidden" name="start" value="<?= $start ?>"><!--
                                                        <input type="hidden" name="email" value="<?= $student->email ?>">-->
    <!--                                                    <input type="hidden" value="<?= $student_id ?>" name="student_id"/>-->
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <input type="hidden" name="step_3" value="3">
                                                        <input type="hidden" name="s_id" value="<?= $s_id; ?>">
                                                        <input type="hidden" name="status" value="<?= $status ?>">
                                                        <input type="hidden" name="parent_id" value="<?= $parent_id ?>"> <input type="hidden" name="msid" value="<?= $MSID ?>">
                                                        <input type="hidden" name="parent_new" value="<?= $std_dtl->p_new ?>">
                                                        <input type="hidden" name="mysession" value="<?= $oCurrentUser->mysession ?>"/>
                                                        <input type="hidden" name="mydate" value="<?= $oCurrentUser->mydate ?>"/>

                                                        <button type="submit" name="rsubmit3" class="btn btn-lg btn-success btn-block">Student Profile &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;>></button>
                                                    </div>
                                                </div>
                                            </div> 
                                        </form>
                                    <?php } ?></div>
                                <div class="tab-pane <?php echo (@$step && $step == "3") ? "active" : ""; ?>" id="tab_4">
<?php if (@$step == "3") { ?>  <div class="box-header">
                                            <h2 class="box-title"><u><a class="btn-flat" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $student->student_id ?>" data-ms="modal" data-title="Student Profile"><?= $student->name . "   Profile" ?></a> 
                                                <a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $student->student_id; ?>" data-ms="modal" data-title="Student Profile">View Profile</a></u></h2>
                                        </div>
                                        <?php
//exit();
                                        $Delete = Fee::get_delete_student_from_fee_billing($MSID, $student->acno, $oCurrentUser->mysession);
                                        $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, $student->acno);
                                        ?>  
                                        <div class="box-body">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <?php
                                                    if ($student->photo != '') {
                                                        ?>

                                                        <img class="img-circle" style="height: 200px; width:200" src="<?= CLIENT_URL ?>/uploads/<?php echo $student->photo; ?>" alt=""><?php
                                                    }
                                                    ?></div>


                                                <div class="col-md-9">

                                                    <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>Email</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?= $student->email ?>  
                                                        </div>

                                                    </div> 

                                                    <?php
                                                    if ($oCurrentSchool->house == 1) {
                                                        ?>

                                                        <div class="col-md-6">


                                                            <div class="col-md-6">
                                                                <label>House</label>
                                                            </div>
                                                            <div class="col-md-6"> 
                                                                <?php
                                                                $house = Master::get_houses($MSID, $student->house)->fetch(PDO::FETCH_OBJ);
                                                                echo $house->house_f_name;
                                                                ?>  
                                                            </div>
                                                        </div>

                                                        <?php
                                                    }
                                                    ?>
                                                    <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>Birth Date</label>
                                                        </div>
                                                        <div class="col-md-6"> 


                                                            <?php
                                                            $originalDate = $student->birth_date;
                                                            echo $newDate = date("d-m-Y", strtotime($originalDate));
                                                            ?>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>Gender</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?php
                                                            if ($student->gender == "M")
                                                                echo "Male";
                                                            else
                                                                echo "Female";
                                                            ?>  
                                                        </div>
                                                    </div> 
                                                    <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>Blood Group</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?= $student->blood_group ?>  
                                                        </div>

                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>ADM NO</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?= $student->admno ?>  
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>ADM Class</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?php
                                                            $class = Master::get_classes($MSID, '', '', '', $student->adm_classno)->fetch(PDO::FETCH_OBJ);
                                                            echo $class->class_name;
                                                            ?>  
                                                        </div>
                                                    </div>  <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>Fee Date</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?= $student->fees_date ?>  
                                                        </div>

                                                    </div><div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label> Father Name</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?php
                                                            if (@$student->parent_id)
                                                                $parent = Student::get_parent($MSID, $student->parent_id)->fetch(PDO::FETCH_OBJ);
                                                            echo @$parent->f_name;
                                                            ?>  

                                                        </div>
                                                    </div> 
                                                    <div class="col-md-6">
                                                        <div class="col-md-6">
                                                            <label>Mother Name</label>
                                                        </div>
                                                        <div class="col-md-6"> 
                                                            <?= @$parent->m_name; ?>  
                                                        </div>

                                                    </div>
                                                </div> 

                                            </div> 
                                            <div class="row">
                                                <div class="col-md-3"></div>
                                                <div class="col-md-9">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="box box-success" style="border-color:rgb(243,156,18) ">
                                                                <div class="box-header with-border " style="background: rgb(243,156,18); color: white">
                                                                    <h3 class="box-title">Student Login Credentials</h3>
                                                                    <div class="box-tools pull-right">
                                                                        <button data-widget="remove" style=" color: white " class="btn btn-box-tool"><i class="fa fa-times"></i></button>
                                                                    </div><!-- /.box-tools -->
                                                                </div><!-- /.box-header -->
                                                                <div class="box-body">
                                                                    <div class="row"><div class="col-md-6"> <label>Usernanme :- </label></div>
                                                                        <div class="col-md-6"> <?= $student->uid; ?></div>


                                                                    </div>
                                                                    <div class="row"><div class="col-md-6"> <label>Password :- </label></div>
                                                                        <div class="col-md-6"> <?= $student->uid; ?></div>


                                                                    </div>


                                                                    <!-- /.box-body -->
                                                                </div></div>

                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="box box-success" style="border-color:rgb(243,156,18) ">
                                                                <div class="box-header with-border " style="background: rgb(243,156,18); color: white">
                                                                    <h3 class="box-title">Parent Login Credentials</h3>
                                                                    <div class="box-tools pull-right">
                                                                        <button data-widget="remove" style=" color: white " class="btn btn-box-tool"><i class="fa fa-times"></i></button>
                                                                    </div><!-- /.box-tools -->
                                                                </div><!-- /.box-header -->

                                                                <div class="box-body">
                                                                    <div class="row"><div class="col-md-6"> <label>Usernanme :- </label></div>
                                                                        <div class="col-md-6"> <?= $parent->uid; ?></div>

                                                                    </div>
                                                                    <div class="row"><div class="col-md-6"> <label>Password :- </label></div>
                                                                        <div class="col-md-6"> <?= $parent->uid; ?></div>

                                                                    </div>
                                                                    <a href="<?= CLIENT_URL; ?>/registration-form/regformS2.php/<?= $student->student_id; ?>" target="_blank">Print Registration Form</a>

                                                                    <!-- /.box-body -->
                                                                </div></div><!-- /.box-body -->
                                                        </div>    
                                                    </div>
                                                </div>   
                                            </div><!-- /.tab-pane -->
                                        </div><!-- /.tab-content -->
                                    <?php } ?>
                                </div><!-- nav-tabs-custom -->
                            </div><!-- /.col -->

                            <!-- /.col -->
                        </div> 

                        <!--</form>-->
                    </div>
                    <!-- /.box -->
                </div>
            </div>
            </section>
            
         
            
            <input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">  <!-- Main content --><?php

     
	        $sBottomJavascript = <<<EOT

 
<script type="text/javascript">
$(document).ready(function(){
    //$("#subject_group").show();                
    $('#aclass').change(function(e){
     var class_id =  $(this).val();
     
     if(class_id >10)
     {
        $("#subject_group").show();                                                        
        
     } 
    else
    {
        $("#subject_group").hide();
    }
   
                                                                
         
                                                                
     //alert(class_id);
	   $('#selection').html('');
	   var classid = $(this).val();
	   var siteurl = $('#site_url').val();	
	   $('#selection').html('Loading....');
	    $.ajax({
			url: siteurl+"/ajax-page-load/selection_std",
			type: "post",
			data: { classid: classid} ,
			success: function (response) {
                       //alert(response);
			  $('#selection').html(response);
                    $('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
        

	});
        
                
                    
                    
                    
    });

                  
                    
$('.adm_date').datepicker({format: 'dd-mm-yyyy',todayHighlight: true }); 
                    
$('.adm_date1').datepicker({format: 'yyyy-mm-dd', todayHighlight: true });
                    
                    
$('.adm_date').on('changeDate', function(ev){
    $(this).datepicker('hide');
}) ;

$('.adm_date1').on('changeDate', function(ev){
    
   var date1 = $(this).val();
   var date_select = date1.split("-");
   //alert(date_select);                
    var date_format = date_select[0]+"-"+date_select[1]+'-'+'01'; 
    
    //alert(date_format);
     $(this).datepicker('hide');               
    $(this).val('');
    $(this).val(date_format);
                    
      
   alert(new_date);
     
   $(this).datepicker('hide');
}) ;
                    
                    
$('body').on('click','[data-ms="modal"]', function(e) {
	var link = $(this);
	var options = {
        url: link.attr("href"),
        title: link.attr("data-title"),
		size : 'lg'
    };
   eModal.setEModalOptions({
        loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
    });
   eModal.ajax(options);
   return false;
});
                    
$('body').on('click','.ajax_locality',function()
{
  var siteurl = $('#site_url').val();	                  
  var id    = $(this).attr('data-id');   
  var locality  = $(this).attr('data-name');
  var pin_code =  $(this).attr('data-pincode');
      
  var pin_id= $(this).attr('data-pin_id');
   
  $.ajax({
                    
          url: siteurl+"/ajax-page-load/locality_add_section",
	  type: "POST",
	  data: { id : id, locality :locality, pin_code : pin_code, pin_id : pin_id} ,
	 success: function (response)
                    {
                     //alert(response);
                    
                    $('#locality').append(response);
                            location.reload();
                            eModal.close();
                    
                    
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
  
                    
                    
                    
});
                    
$('body').on('click','.ajaxselect',function(){
   /*-----*/
        var id    = $(this).attr('data-id');   
        var fname    = $(this).attr('data-fname');
		var mname    = $(this).attr('data-mname');
		var fquali  = $(this).attr('data-fquali');
		var foccu = $(this).attr('data-foccu');
		var fmobile     = $(this).attr('data-fmobile');
		var mquali = $(this).attr('data-mquali');
		var moccu  = $(this).attr('data-moccu');
		var mmobile  = $(this).attr('data-mmobile');
		var category    = $(this).attr('data-category');
		var addline1 = $(this).attr('data-addline1');
		var addline2     = $(this).attr('data-addline2');
		var aincome  = $(this).attr('data-aincome');
		var msms  = $(this).attr('data-msms');
		var local    = $(this).attr('data-local');
		var landline = $(this).attr('data-landline');
		var padd     = $(this).attr('data-padd');
		var religion     = $(this).attr('data-religion');
                var localname = $(this).attr('data-localname');
                    
                var feebook   = $(this).attr('data-feebook');
                    

		$('#name7').val(fname).attr('disabled','disabled');
		$('#mname').val(mname).attr('disabled','disabled');
		$('#f_qualification').val(fquali).attr('disabled','disabled');
		$('#f_occupation').val(foccu).attr('disabled','disabled');
		$('#fmob').val(fmobile).attr('disabled','disabled');
		$('#m_qualification').val(mquali).attr('disabled','disabled');
		$('#m_occupation').val(moccu).attr('disabled','disabled');
		$('#name15').val(mmobile).attr('disabled','disabled');
		$('#category').val(category).attr('disabled','disabled');
		$('#addline1').val(addline1).attr('disabled','disabled');
//		$('#name16').val(addline2).attr('disabled','disabled');
		$('#Annual_Income').val(aincome).attr('disabled','disabled');
		$('#mobsms15').val(msms).attr('disabled','disabled');
		//$('#locality').val(local).attr('disabled','disabled');
                 $('#locality').empty().append('<option selected="selected" value="'+local+'">'+localname+'</option>')
;                $('#locality').attr('disabled','disabled'); 
                 
                 $('#sep_fees_book_box').val('');
                    
                 $('#sep_fees_book_box').val(feebook);
                    
                  
                 
                    
   
		$('#name11').val(landline).attr('disabled','disabled');
		$('#padd').val(padd).attr('disabled','disabled');
		$('#religion').val(religion).attr('disabled','disabled');
               // $('#sep_fee').val(id);
	       $('#parentfrm').append('<input type="hidden" name="parent[parentID]" value="'+id+'" />');
                 //$('#sep_fee_book').show();   
                //$('#sep_fee_book').append('<a id="'+id+'" href="" class="sep_link">Seprate Fee Book</a>');
                
                    
                    
                    
                /* $.ajax({
                    
                    url: siteurl+"/ajax-page-load/get_parentid",
			type: "post",
			data: { classid: id} ,
			success: function (response) {
                      alert(response);
                    eModal.close();
			 // $('#selection').html(response);
                    //$('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });*/
                    
                    
                    
                
        eModal.close();
   /**/
});
$(".parent_reset").on("click", function(e) {
        $('#name7').val('').removeAttr('disabled');
		$('#mname').val('').removeAttr('disabled');
		$('#f_qualification').val('').removeAttr('disabled');
		$('#f_occupation').val('').removeAttr('disabled');
		$('#fmob').val('').removeAttr('disabled');
		$('#m_qualification').val('').removeAttr('disabled');
		$('#m_occupation').val('').removeAttr('disabled');
		$('#name15').val('').removeAttr('disabled');
		$('#category').val('').removeAttr('disabled');
		$('#addline1').val('').removeAttr('disabled');
//		$('#name16').val('').removeAttr('disabled');
		$('#Annual_Income').val('').removeAttr('disabled');
		$('#mobsms15').val('').removeAttr('disabled');
		$('#locality').val('').removeAttr('disabled');
		$('#name11').val('').removeAttr('disabled');
		$('#padd').val('').removeAttr('disabled');
		$('#religion').val('').removeAttr('disabled');
		$('input[name="parent[parentID]"]').remove();
		return false;
});
                    
    $(".sep_link").on("click", function(e) {                
      alert("hi");     
      //var id = $(this).attr('id');
      alert(id);
    /*$.ajax({
                    
                    url: siteurl+"/ajax-page-load/get_parentid",
			type: "post",
			data: { classid: id} ,
			success: function (response) {
                      alert(response);
                   // eModal.close();
			 // $('#selection').html(response);
                    //$('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    }); */             
                    
                    
              });    
                  
                    
                    
    $("#fmob").keyup(function()
    {
      var f_mob = $(this).val();  
      $("#mobsms15").val(f_mob);
          
    });

});
                                                                
                                                                
                                                                
 function ShowHideDiv() {
        var chkYes = document.getElementById("option1");
        var tpt = document.getElementById("tpt");
        tpt.style.display = chkYes.checked ? "block" : "none";
    } 
        
 function HideDiv()
 {
    var chkYes = document.getElementById("option2");
        var tpt = document.getElementById("tpt");
        tpt.style.display = chkYes.checked ? "none" : "block";                 
 }
                                                                                      
 function ShowHideDiv1() {
        var chkYes = document.getElementById("option11");
        var disc = document.getElementById("disc");
        disc.style.display = chkYes.checked ? "block" : "none";
    } 
        
 function HideDiv1()
 {
    var chkYes = document.getElementById("option21");
        var disc = document.getElementById("disc");
        disc.style.display = chkYes.checked ? "none" : "block";                 
 }
                                                                      
                                                                
                                                                
                                                                
                                                                
                                                                
                    
 function show_list()
 {
    var chkYes = document.getElementById("parent_account_yes");
    var account_no = document.getElementById("account_no");
    account_no.style.display = chkYes.checked ? "block" : "none";
 }
  
   
                    
 function hide_list()
 {
    var chkYes = document.getElementById("parent_account_No");
    var account_no = document.getElementById("account_no");
    account_no.style.display = chkYes.checked ? "none" : "block";
 }                   
                    
</script>

EOT;
            $oPageLayout->addJavascriptBottom($sBottomJavascript);
            ?>
