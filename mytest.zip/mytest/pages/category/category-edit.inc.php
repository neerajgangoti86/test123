<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-6"> <?php $message = new Messages(); echo $message->display(); ?>
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Update Category</h3>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form method="post" action="" role="form">
            <div class="box-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Category Name<span class="text-red">*</span></label>
                    <input class="form-control" type="text" value="<?= $category['name']; ?>" size="30" id="name7" name="fname">
                  </div>
                </div>
                <!-- \col -->
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Click here to change Status</label>
                    <select class="form-control" id="status" name="status">
                      <option value="">Select Status</option>
                      <?php  foreach(yes_no_dropdown() as $key => $value){
									 if($key == $category['status']){$selected = 'selected="selected"';}else{$selected = '';}
									 echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
								  } ?>
                    </select>
                  </div>
                </div>
              </div>
              <!-- \row end -->
              <div class="row">
                <div class="col-md-12">
                  <button type="submit" name="updatesubmit" class="btn btn-lg btn-success btn-block">Update</button>
                </div>
                <!-- \col -->
              </div>
              <!-- \row end -->
            </div>
          </form>
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>
  <!-- Main content -->