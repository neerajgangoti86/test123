<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12"> <?php $message = new Messages(); echo $message->display(); ?>
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Enter New Employee</h3>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form method="post" action="" role="form" enctype="multipart/form-data">
            <input type="hidden" name="MSID" value="<?= $MSID ?>" />
            <div class="box-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Employee Id<span class="text-red">*</span></label>
                    <input class="form-control" readonly="readonly" type="text" value="<?= $emp_id; ?>" size="15" id="empid" name="empid">
                  </div>
                  <div class="form-group">
                    <label>Mobile Number <span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="25" id="mobile" name="mobile" required>
                  </div>
                  <div class="form-group">
                    <label>Educational Qualification</label>
                    <input class="form-control" type="text" size="25" id="e_qualification" name="e_qualification">
                  </div>
                  <div class="form-group">
                    <label>Designation <span class="text-red">*</span>&nbsp;&nbsp;<a href="<?= CLIENT_URL ?>/ajax-page-load/designation" data-title="Add New Designation" data-ms="modal">Add new designation</a></label>
                    <select class="form-control" id="designation" name="Designation" required>
                      <option value="">Select</option>
                      <?php while($rowv = $designations->fetch()){ 
										  ?>
                      <option value="<?= $rowv['name']; ?>">
                      <?= $rowv['name']; ?>
                      </option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>EPF No</label>
                    <input class="form-control" type="text" size="20" id="epfno" name="epfno">
                  </div>
                  <div class="form-group">
                    <label>Aadhar Number</label>
                    <input class="form-control" type="text" size="30" id="adno" name="adno">
                  </div>
                </div>
                <!-- \col -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Employee Name<span class="text-red">*</span></label>
                    <select  id="Prefix_Name" name="Prefix_Name" required>
                      <option value="">Select</option>
                      <option>Mr.</option>
                      <option>Mrs.</option>
                      <option>Miss</option>
                      <option>MS</option>
                    </select>
                    <input class="form-control" type="text" size="25" id="empname" name="empname" required>
                  </div>
                  <div class="form-group">
                    <label>Father Name</label>
                    <input class="form-control" type="text" size="25" id="efname" name="efname">
                  </div>
                  <div class="form-group">
                    <label>Professional Qualification</label>
                    <input class="form-control" type="text" size="25" id="p_qualification" name="p_qualification">
                  </div>
                  <div class="form-group">
                    <label>Category <span class="text-red">*</span></label>
                    <select class="form-control" id="empcat" name="empcat" required>
                      <option value="">Select</option>
                      <option>TS</option>
                      <option>NT</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>EPF Join Date</label>
                    <input class="form-control" type="text" size="12" id="epfjdate" name="epfjdate" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Address</label>
                    <textarea class="form-control" rows="2" cols="30" name="Address"></textarea>
                  </div>
                </div>
                <!-- \col -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Date Of Birth<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="25" id="dobid" name="dob" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Spouse Name</label>
                    <input class="form-control" type="text" size="25" id="esname" name="esname">
                  </div>
                  <div class="form-group">
                    <label>Date Of Joining <span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="25" id="hdate" name="hdate" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Department &nbsp;&nbsp;<a href="<?= CLIENT_URL ?>/ajax-page-load/department" data-title="Add New Department" data-ms="modal">Add new department</a></label>
                    <select class="form-control" id="department" name="dept">
                      <option value="">Select</option>
                      <?php while($rowv = $departments->fetch()){ ?>
                      <option value="<?= $rowv['dept_name']; ?>">
                      <?= $rowv['dept_name']; ?>
                      </option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Is Librarian?</label>
                    <select class="form-control" id="Librarian" name="Librarian">
                      <option value="">Select</option>
                      <?php
                                       foreach(yes_no_dropdown() as $key=> $value){
                                         echo '<option value="'.$key.'">'.$value.'</option>';
                                       }
                                       ?>
                    </select>
                  </div>
                </div>
                <!-- \col -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Gender <span class="text-red">*</span></label>
                    <select class="form-control" id="Gender" name="Gender" required>
                      <option value="">Select</option>
                      <option value="M">M</option>
                      <option value="F">F</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Blood Group</label>
                    <?php $bloodgrparr = array('A+','B+','O+','AB+','A-','B-','O-','AB-'); ?>
                    <select class="form-control" id="bgroup" name="bgroup">
                      <option value="">Select</option>
                      <?php  foreach($bloodgrparr as $value){
                                             echo '<option value="'.$value.'">'.$value.'</option>';
                                          } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Bank A/C No</label>
                    <input class="form-control" type="text" size="12" id="bank_acno" name="bank_acno" />
                  </div>
                  <div class="form-group">
                    <label>Locality<span class="text-red">*</span>&nbsp;&nbsp;<a href="<?= CLIENT_URL ?>/ajax-page-load/locality_select" data-title="Select Locality" data-ms="modal">Add Locality</a></label>
                    <select class="form-control" id="locality" name="locality" required>
                      <option value="">Select</option>
                      <?php 
                      $local_fetch1 = Master::get_locality_list2($MSID, $oCurrentSchool->locality_pincode);
                                                        //print_r($local_fetch1);
//                                                        
//                                                        
//                                                        print_r($local_fetch1);
                                                        $ids= array();
                                                          while ($local = $local_fetch1->fetch(PDO::FETCH_ASSOC)) {
                                                              $ids[]=$local['id'];
                                                          } 
                                                          $ids_all= implode(',', $ids);
//                                                          print_r($ids_all);
                                     
                                                              $local_fetch = Master::get_locality_list3($ids_all);
                      
                      ?>
                     
                                                            <?php
                                                            while ($local = $local_fetch->fetch(PDO::FETCH_ASSOC)) {
//                                                                print_r($local);
                                                                
                                                                
                                                                
                                                                echo '<option value="' . $local['id'] . '" '.$selected.'>' . $local['name'] . '</option>';
                                                            }
                                                            ?> 
                      
                      
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Employee Photo</label>
                    <input type="file" id="uploadedfile" name="uploadedfile" />
                  </div>
                </div>
                <!-- \col -->
              </div>
              <!-- \row end -->
              <div class="row">
                <div class="col-md-3">
                  <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                </div>
                <!-- \col -->
              </div>
              <!-- \row end -->
            </div>
          </form>
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>
  <!-- Main content -->
<?php 
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
$('body').on('click','[data-ms="modal"]', function(e) {
	var link = $(this);
	var options = {
        url: link.attr("href"),
        title: link.attr("data-title"),
		size : 'md'
    };
   eModal.setEModalOptions({
        loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
    });
   eModal.ajax(options);
   return false;
});
//calender
$('#dobid, #hdate, #epfjdate').datepicker({
    format: 'yyyy-mm-dd',
	todayHighlight: true
});
});
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>