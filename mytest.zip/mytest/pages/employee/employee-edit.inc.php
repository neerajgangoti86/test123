<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-12"> <?php $message = new Messages(); echo $message->display(); ?>
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Enter New Employee</h3>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form method="post" action="" role="form" enctype="multipart/form-data">
            <input type="hidden" name="MSID" value="<?= $MSID ?>" />
            <div class="box-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Employee Id<span class="text-red">*</span></label>
                    <input class="form-control" readonly="readonly" type="text" value="<?= $employee['employee_id']; ?>" size="15" id="empid" name="empid">
                  </div>
                  <div class="form-group">
                    <label>Mobile Number <span class="text-red">*</span></label>
                    <input class="form-control" type="text" value="<?= $employee['mobile']; ?>" size="25" id="mobile" name="mobile" required>
                  </div>
                  <div class="form-group">
                    <label>Educational Qualification</label>
                    <input class="form-control" type="text" value="<?= $employee['e_qualification']; ?>" size="25" id="e_qualification" name="e_qualification">
                  </div>
                  <div class="form-group">
                    <label>Designation <span class="text-red">*</span>&nbsp;&nbsp;<a href="<?= CLIENT_URL ?>/ajax-page-load/designation" data-title="Add New Designation" data-ms="modal">Add new designation</a></label>
                    <select class="form-control" id="designation" name="Designation" required>
                      <option value="">Select</option>
                      <?php while($rowv = $designations->fetch()){ 
										  if($rowv['name']==$employee['designation']){ $selected = 'selected="selected"';}else{$selected = '';}?>
                      <option value="<?= $rowv['name']; ?>" <?= $selected; ?>>
                      <?= $rowv['name']; ?>
                      </option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>EPF No</label>
                    <input class="form-control" value="<?= $employee['epf_no']; ?>" type="text" size="20" id="epfno" name="epfno">
                  </div>
                  <div class="form-group">
                    <label>Aadhar Number</label>
                    <input class="form-control" value="<?= $employee['aadhar_no']; ?>" type="text" size="30" id="adno" name="adno">
                  </div>
                </div>
                <!-- \col -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Employee Name<span class="text-red">*</span></label>
                    <select  id="Prefix_Name" name="Prefix_Name" required>
                      <option value="">Select</option>
                      <option value="Mr." <?php if($employee['emp_name_prefix']=='Mr.'){ echo 'selected="selected"';} ?>>Mr.</option>
                      <option value="Mrs." <?php if($employee['emp_name_prefix']=='Mrs.'){ echo 'selected="selected"';} ?>>Mrs.</option>
                      <option value="Miss" <?php if($employee['emp_name_prefix']=='Miss'){ echo 'selected="selected"';} ?>>Miss</option>
                      <option value="MS" <?php if($employee['emp_name_prefix']=='MS'){ echo 'selected="selected"';} ?>>MS</option>
                    </select>
                    <input class="form-control" value="<?= $employee['emp_name']; ?>" type="text" size="25" id="empname" name="empname" required>
                  </div>
                  <div class="form-group">
                    <label>Father Name</label>
                    <input class="form-control" value="<?= $employee['father_name']; ?>" type="text" size="25" id="efname" name="efname">
                  </div>
                  <div class="form-group">
                    <label>Professional Qualification</label>
                    <input class="form-control" value="<?= $employee['p_qualification']; ?>" type="text" size="25" id="p_qualification" name="p_qualification">
                  </div>
                  <div class="form-group">
                    <label>Category <span class="text-red">*</span></label>
                    <select class="form-control" id="empcat" name="empcat" required>
                      <option value="">Select</option>
                      <option <?php if($employee['emp_category']=='TS'){ echo 'selected="selected"';} ?>>TS</option>
                      <option <?php if($employee['emp_category']=='NT'){ echo 'selected="selected"';} ?>>NT</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>EPF Join Date</label>
                    <input class="form-control" value="<?= $employee['epf_join_date']; ?>" type="text" size="12" id="epfjdate" name="epfjdate" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Address</label>
                    <textarea class="form-control" rows="2" cols="30" name="Address"><?= $employee['address']; ?>
</textarea>
                  </div>
                </div>
                <!-- \col -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Date Of Birth<span class="text-red">*</span></label>
                    <input class="form-control" value="<?php echo $new_date = date('d-m-Y',strtotime($employee['emp_dob'])); ?>" type="text" size="25" id="dobid" name="dob" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Spouse Name</label>
                    <input class="form-control" value="<?= $employee['spouse_name']; ?>" type="text" size="25" id="esname" name="esname">
                  </div>
                  <div class="form-group">
                    <label>Date Of Joining <span class="text-red">*</span></label>
                    <input class="form-control" value="<?php echo $new_date = date('d-m-Y',strtotime( $employee['hire_date'])); ?>" type="text" size="25" id="hdate" name="hdate" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Department &nbsp;&nbsp;<a href="<?= CLIENT_URL ?>/ajax-page-load/department" data-title="Add New Department" data-ms="modal">Add new department</a></label>
                    <select class="form-control" id="department" name="dept">
                      <option value="">Select</option>
                      <?php while($rowv = $departments->fetch()){ 
                                       if($rowv['dept_name']==$employee['department']){ $selected = 'selected="selected"';}else{$selected = '';} ?>
                      <option value="<?= $rowv['dept_name']; ?>" <?= $selected; ?>>
                      <?= $rowv['dept_name']; ?>
                      </option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Is Librarian?</label>
                    <select class="form-control" id="Librarian" name="Librarian">
                      <option value="">Select</option>
                      <?php
                                       foreach(yes_no_dropdown() as $key=> $value){
									   if($key==$employee['is_librarian']){ $selected = 'selected="selected"';}else{$selected = '';} 
                                         echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
                                       }
                                       ?>
                    </select>
                  </div>
                </div>
                <!-- \col -->
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Gender <span class="text-red">*</span></label>
                    <select class="form-control" id="Gender" name="Gender" required>
                      <option value="">Select</option>
                      <option <?php if($employee['gender']=='M'){ echo 'selected="selected"';} ?> value="M">M</option>
                      <option <?php if($employee['gender']=='F'){ echo 'selected="selected"';} ?> value="F">F</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Blood Group</label>
                    <?php $bloodgrparr = array('A+','B+','O+','AB+','A-','B-','O-','AB-'); ?>
                    <select class="form-control" id="bgroup" name="bgroup">
                      <option value="">Select</option>
                      <?php  foreach($bloodgrparr as $value){
									       if($value==$employee['blood_group']){ $selected = 'selected="selected"';}else{$selected = '';} 
                                             echo '<option value="'.$value.'" '.$selected.'>'.$value.'</option>';
                                          } ?>
                    </select>
                  </div>
                     <div class="form-group">
                    <label>Retire Date <span class="text-red">*</span></label>
                    <input class="form-control" value="<?php echo $new_date = date('d-m-Y',strtotime( $employee['retire_date'])); ?>" type="text" size="25" id="rdate" name="rdate" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Bank A/C No</label>
                    <input class="form-control" value="<?= $employee['bank_ac_no']; ?>" type="text" size="12" id="bank_acno" name="bank_acno" />
                  </div>
                  <div class="form-group">
                    <label>Locality<span class="text-red">*</span>&nbsp;&nbsp;<a href="<?= CLIENT_URL ?>/ajax-page-load/locality_select" data-title="Select Locality" data-ms="modal">Add Locality</a></label>
                    <select class="form-control" id="locality" name="locality" required>
                      <option value="">Select</option>
                      <?php 
                      $local_fetch1 = Master::get_locality_list2($MSID, $oCurrentSchool->locality_pincode);
                                                        //print_r($local_fetch1);
//                                                        
//                                                        
//                                                        print_r($local_fetch1);
                                                        $ids= array();
                                                          while ($local = $local_fetch1->fetch(PDO::FETCH_ASSOC)) {
                                                              $ids[]=$local['id'];
                                                          } 
                                                          $ids_all= implode(',', $ids);
//                                                          print_r($ids_all);
                                     
                                                              $local_fetch = Master::get_locality_list3($ids_all);
                      
                      ?>
                     
                                                            <?php
                                                            while ($local = $local_fetch->fetch(PDO::FETCH_ASSOC)) {
//                                                                print_r($local);
                                                                
                                                                if( $local['id'] == $employee['locality'])
                                                                {
                                                                    $selected = "selected='selected'";
                                                                }
                                                                else
                                                                {
                                                                    $selected ="";
                                                                }
                                                                
                                                                echo '<option value="' . $local['id'] . '" '.$selected.'>' . $local['name'] . '</option>';
                                                            }
                                                            ?> 
                      
                      
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Employee Photo</label>
                    <?php 
                    if($employee['emp_image']!= '')
                    {
                    ?>
                    <img src="<?= CLIENT_URL ?>/uploads/<?php echo $employee['emp_image']; ?>" width="100" style="float:right;"/>
                    <?php
                      }
                   else 
                   {
                   ?>
                    <img src="<?= CLIENT_URL ?>/uploads/no-image.png" width="100" style="float:right;"/>
                    <?php   
                   }
                    ?>
                    <input type="hidden" value="<?php echo $employee['emp_image']; ?>" name="image_org" />
                    <input type="file" id="uploadedfile" name="uploadedfile" />
                  </div>
                </div>
                <!-- \col -->
              </div>
              <!-- \row end -->
              <div class="row">
                <div class="col-md-3">
                  <button type="submit" name="rsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                </div>
                <!-- \col -->
              </div>
              <!-- \row end -->
            </div>
          </form>
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>
  <!-- Main content -->
<?php 
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
        
        
        
        
        
$('body').on('click','[data-ms="modal"]', function(e) {
	var link = $(this);
	var options = {
        url: link.attr("href"),
        title: link.attr("data-title"),
		size : 'md'
    };
   eModal.setEModalOptions({
        loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
    });
   eModal.ajax(options);
   return false;
});
//calender
$('#dobid, #hdate, #epfjdate').datepicker({
    format: 'dd-mm-yyyy',
	todayHighlight: true
});
        
 $('body').on('click','.ajax_locality',function()
{
  var siteurl = $('#site_url').val();	                  
  var id    = $(this).attr('data-id');   
  var locality  = $(this).attr('data-name');
  var pin_code =  $(this).attr('data-pincode');
      
  var pin_id= $(this).attr('data-pin_id');
   
  $.ajax({
                    
          url: siteurl+"/ajax-page-load/locality_add_section",
	  type: "POST",
	  data: { id : id, locality :locality, pin_code : pin_code, pin_id : pin_id} ,
	 success: function (response)
                    {
                     //alert(response);
                    
                    $('#locality').append(response);
                            location.reload();
                            eModal.close();
                    
                    
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
                    
                    
                    });
  
                    
                    
                    
});       
        
        
        
});
        
        
        

</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>