<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box box-primary">
                <div class="box-header">
                    <div class="row">
                        <div class="col-md-2"><h3 class="box-title">Employee List</h3>
                        </div>
                        <div class="col-md-3">
                            <?php if ($out == "false") { ?>
                                <h3 class="box-title">
                                    <?php
                                    $LINK = CLIENT_URL . '/employee/add';
                                    $BTNS = check_privlages($LINK, NULL, NULL, $oCurrentUser->myuid, $MSID);
                                    print_r($BTNS);
                                    ?>
                                </h3>
                            <?php } ?></div>
                        <div class="col-md-5">
                            <h3 class="box-title"><a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL ?>/sms/employee">Send SMS </a></h3>
                        </div>
                        <div class="col-md-2"><form class="form-inline right_ft column_hide_show" method="post">
                                <div class="btn-group">
                                    <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                        Select Columns 
                                        <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu"  aria-labelledby="dropdownMenu1">
                                        <?php
                                        foreach ($employee_array as $key => $val) {
                                            if (in_array($key, @$selected_columns_employees)) {
                                                $checked = "checked ='checked'";
                                            } else {
                                                $checked = "";
                                            };
                                            ?>
                                            <li>
                                                <input type="checkbox" value="<?= $key ?>"  name="column1[]" <?= $checked ?>><?= $val ?>
                                            </li> 
                                        <?php } ?>
                                        <li><button type="submit" name="columnsubmit" class="btn btn-block btn-sm btn-warning btn-flat">Submit</button></li>
                                    </ul>
                                </div>
                            </form></div>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <?php if ($totalrecords > 0) { ?>
                        <table class="tablesorter table table-hover">
                            <thead style="background:#ddd;">
                                <tr>
                                    <th><a href="javascript:void(0);">Sr.No.</a></th>
                                    <?php if (!@$selected_columns_employees) { ?>
                                        <th><a href="javascript:void(0);">Emp Id</a></th>
                                        <th><a href="javascript:void(0);">Employee Name</a></th>
                                        <th><a href="javascript:void(0);">Father Name</a></th>
                                        <th><a href="javascript:void(0);">Spouse Name </a></th>
                                        <th><a href="javascript:void(0);">Department</a></th>
                                        <th><a href="javascript:void(0);">Bank AC No</a></th>
                                        <th><a href="javascript:void(0);">Qualification</a></th>
                                        <th><a href="javascript:void(0);">Mobile</a></th>
                                        <th><a href="javascript:void(0);">DOB</a></th>
                                        <th><a href="javascript:void(0);">Locality</a></th>
                                        <th><a href="javascript:void(0);">Gender</a></th>
                                        <th><a href="javascript:void(0);">EPF Number</a></th>
                                        <th><a href="javascript:void(0);">EPF Joining Date</a></th>
                                        <th><a href="javascript:void(0);">Retire Date</a></th>
                                        <th><a href="javascript:void(0);">Blood Group</a></th>
                                        <th><a href="javascript:void(0);">Hire Date</a></th>
                                        <th><a href="javascript:void(0);">Category</a></th>
                                        <th><a href="javascript:void(0);">Department</a></th>
                                        <th><a href="javascript:void(0);">Address</a></th>
                                        <th><a href="javascript:void(0);">Adhar Number</a></th>
                                        <th><a href="javascript:void(0);">Status</a></th>

                                    <?php } else { ?>
                                        <?php if (in_array('emp_id', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Emp Id</a></th><?php } ?>
                                        <?php if (in_array('name', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Employee Name</a></th><?php } ?>
                                        <?php if (in_array('father_name', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Father Name</a></th><?php } ?>
                                        <?php if (in_array('spouse_name', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Spouse Name</a></th><?php } ?>
                                        <?php if (in_array('designation', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Department</a></th><?php } ?>
                                        <?php if (in_array('bank_ac_no', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Bank AC No</a></th><?php } ?>
                                        <?php if (in_array('qualification', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Qualification</a></th><?php } ?>
                                        <?php if (in_array('mobile', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Mobile</a></th><?php } ?>
                                        <?php if (in_array('dob', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">DOB</a></th><?php } ?>
                                        <?php if (in_array('locality', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Locality</a></th><?php } ?>
                                        <?php if (in_array('gender', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Gender</a></th><?php } ?>
                                        <?php if (in_array('epf_no', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">EPF Number</a></th><?php } ?>
                                        <?php if (in_array('epf_join_date', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">EPF Joining Date</a></th><?php } ?>
                                        <?php if (in_array('retire_date', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Retire Date</a></th><?php } ?>
                                        <?php if (in_array('blood_group', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Blood Group</a></th><?php } ?>
                                        <?php if (in_array('hire_date', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Hire Date</a></th><?php } ?>
                                        <?php if (in_array('emp_category', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Category</a></th><?php } ?>
                                        <?php if (in_array('department', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Department</a></th><?php } ?>
                                        <?php if (in_array('aadhar_no', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Adhar Number</a></th><?php } ?>
                                        <?php if (in_array('address', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Address</a></th><?php } ?>
                                        <?php if (in_array('status', $selected_columns_employees)) { ?><th><a href="javascript:void(0);">Status</a></th><?php } ?>

                                    <?php } ?>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <?php
                            $i = 1;
                            while ($rowv = $employee->fetch()) {
                                $local = Master::get_locality($MSID, $rowv['locality'], 1)->fetch();
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <?php if (!@$selected_columns_employees) { ?>
                                        <td><?= $rowv['employee_id']; ?></td>
                                        <td><?= $rowv['emp_name']; ?></td>
                                        <td><?= $rowv['father_name']; ?></td>
                                        <td><?= $rowv['spouse_name']; ?></td>
                                        <td><?= $rowv['department']; ?></td>
                                        <td><?= $rowv['bank_ac_no']; ?></td>
                                        <td><?= $rowv['e_qualification']; ?></td>
                                        <td><?= $rowv['mobile']; ?></td>
                                        <td><?= date('d-m-Y', strtotime($rowv['emp_dob'])); ?></td>
                                        <td><?= $local['name']; ?></td>
                                        <td><?php echo $rowv['gender'] == 'F' ? "Female" : "Male"; ?></td>
                                        <td><?= $rowv['epf_no']; ?></td>
                                        <td><?= date('d-m-Y', strtotime($rowv['epf_join_date'])); ?></td>
                                        <td><?= date('d-m-Y', strtotime($rowv['retire_date'])); ?></td>
                                        <td><?= $rowv['blood_group']; ?></td>
                                        <td><?= $rowv['hire_date']; ?></td>
                                        <td><?php echo $rowv['emp_category'] == 'TS' ? "Teaching Staff" : "Non Teaching Staff"; ?></td>
                                        <td><?= $rowv['department']; ?></td>
                                        <td><?= $rowv['aadhar_no']; ?></td>
                                        <td><?= $rowv['address']; ?></td>
                                        <td><?php echo $rowv['status'] == '1' ? "Active" : "Disable"; ?></td>
                                    <?php } else { ?>
                                        <?php if (in_array('emp_id', $selected_columns_employees)) { ?><td><?= $rowv['employee_id']; ?></td><?php } ?>
                                        <?php if (in_array('name', $selected_columns_employees)) { ?> <td><?= $rowv['emp_name']; ?></td><?php } ?>
                                        <?php if (in_array('father_name', $selected_columns_employees)) { ?><td><?= $rowv['father_name']; ?></td><?php } ?>
                                        <?php if (in_array('spouse_name', $selected_columns_employees)) { ?> <td><?= $rowv['spouse_name']; ?></td><?php } ?>
                                        <?php if (in_array('designation', $selected_columns_employees)) { ?> <td><?= $rowv['department']; ?></td><?php } ?>
                                        <?php if (in_array('bank_ac_no', $selected_columns_employees)) { ?><td><?= $rowv['bank_ac_no']; ?></td><?php } ?>
                                        <?php if (in_array('qualification', $selected_columns_employees)) { ?><td><?= $rowv['e_qualification']; ?></td><?php } ?>
                                        <?php if (in_array('mobile', $selected_columns_employees)) { ?><td><?= $rowv['mobile']; ?></td><?php } ?>
                                        <?php if (in_array('dob', $selected_columns_employees)) { ?><td><?= date('d-m-Y', strtotime($rowv['emp_dob'])); ?></td><?php } ?>
                                        <?php if (in_array('locality', $selected_columns_employees)) { ?><td><?= $local['name']; ?></td><?php } ?>
                                        <?php if (in_array('gender', $selected_columns_employees)) { ?><td><?php echo $rowv['gender'] == 'F' ? "Female" : "Male"; ?></td><?php } ?>
                                        <?php if (in_array('epf_no', $selected_columns_employees)) { ?><td><?= $rowv['epf_no']; ?></td><?php } ?>
                                        <?php if (in_array('epf_join_date', $selected_columns_employees)) { ?><td><?= date('d-m-Y', strtotime($rowv['epf_join_date'])); ?></td><?php } ?>
                                        <?php if (in_array('retire_date', $selected_columns_employees)) { ?><td><?= date('d-m-Y', strtotime($rowv['retire_date'])); ?></td><?php } ?>
                                        <?php if (in_array('blood_group', $selected_columns_employees)) { ?><td><?= $rowv['blood_group']; ?></td><?php } ?>
                                        <?php if (in_array('hire_date', $selected_columns_employees)) { ?><td><?= $rowv['hire_date']; ?></td><?php } ?>
                                        <?php if (in_array('emp_category', $selected_columns_employees)) { ?><td><?php echo $rowv['emp_category'] == 'TS' ? "Teaching Staff" : "Non Teaching Staff"; ?></td><?php } ?>
                                        <?php if (in_array('department', $selected_columns_employees)) { ?><td><?= $rowv['department']; ?></td><?php } ?>
                                        <?php if (in_array('aadhar_no', $selected_columns_employees)) { ?><td><?= $rowv['aadhar_no']; ?></td><?php } ?>
                                        <?php if (in_array('address', $selected_columns_employees)) { ?><td><?= $rowv['address']; ?></td><?php } ?>
                                        <?php if (in_array('status', $selected_columns_employees)) { ?><td><?php echo $rowv['status'] == '1' ? "Active" : "Disable"; ?></td><?php } ?>
                                    <?php } ?>
                                    <td>
                                        <a  class="btn bg-olive btn-flat" href="<?= CLIENT_URL ?>/ajax-page-load/employee/<?= $rowv['employee_id']; ?>" data-title="View Profile" data-ms="modal" title="View Profile"><i class="fa fa-eye"></i></a>
                                        <?php
                                        $LINK = CLIENT_URL . '/employee/edit/'.$rowv['employee_id'];
                                        $BTNS = check_privlages(NULL, $LINK, NULL, $oCurrentUser->myuid, $MSID);
                                        print_r($BTNS);
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                $i++;
                            }
                            ?>
                        </table>
                        <?php
                    } else {
                        echo '<div class="text-center margin">No records found.</div>';
                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
                    <?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<!-- Main content -->
<?php
$sBottomJavascript = <<<EOT
<script type="text/javascript">
$(document).ready(function(){
$('body').on('click','[data-ms="modal"]', function(e) {
	var link = $(this);
	var options = {
        url: link.attr("href"),
        title: link.attr("data-title"),
		size : 'lg'
    };
   eModal.setEModalOptions({
        loadingHtml: '<div class="text-center"><span class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span><h4>Loading</h4></div>',
    });
   eModal.ajax(options);
   return false;
}); 
$('.column_hide_show li').on('click', function (event) {
	event.stopPropagation();
});   
}); 
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
