<section class="content">
    <div class="row">
      <div class="col-xs-12"> <?php $message = new Messages(); echo $message->display(); ?>
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Classes List</h3>
            <h3 class="box-title"> <a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL; ?>/msclass/add">Add class</a></h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body table-responsive no-padding">
            <?php if($totalrecords > 0){ ?>
            <table class="table table-hover">
              <tr>
                <th>Sr.No.</th>
                <th>Class Name</th>
                <th>Action</th>
              </tr>
              <?php $i =1; while($rowv = $classes->fetch()){ ?>
              <tr>
                <td><?= $i ?></td>
                <td><?= $rowv['class_name']; ?></td>
                <td><a class="text-light-blue" title="Edit" href="<?= CLIENT_URL; ?>/msclass/edit/<?= $rowv['id']; ?>"><i class="fa fa-edit"></i></a></td>
              </tr>
              <?php $i++; } ?>
            </table>
            <?php }else{ echo '<div class="text-center margin">No records found.</div>'; } ?>
          </div>
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>