<?php
$pluginurl = PLUGINS_FOLDER;
$sTopStylesheet = <<<EOT
    <link href="$pluginurl/fullcalendar/fullcalendar.min.css" rel="stylesheet" type="text/css" />
    <link href="$pluginurl/fullcalendar/fullcalendar.print.css" rel="stylesheet" type="text/css" media='print' />
    <link href="$pluginurl/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">
EOT;
$oPageLayout->addJavascriptBottom($sTopStylesheet);
?>
<!-- Main content -->

<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <?php $message = new Messages();
echo $message->display(); ?>
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Event Calender</h3>
          <h3 class="box-title"><button type="button" class="btn bg-olive btn-flat margin" data-toggle="modal" data-target="#myModal">
  Add New
</button></h3>
        </div>
      </div>
      <!-- /.box -->
    </div>
  </div>
  <!-- Event Calender start -->
  <div class="row">
    
    <div class="col-md-8">
      <div class="box box-primary">
        <div class="box-body no-padding">
          <!-- THE CALENDAR -->
          <div id="calendar"></div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /. box -->
    </div>
    <!-- /.col -->
    <div class="col-md-4">
      <div class="box box-solid">
        <div class="box-header with-border">
          <h4 class="box-title">Events List</h4>
        </div>
        <div class="box-body">
          <!-- the events -->
          <?php if ($totalrecords > 0) { ?>
          <ul>
              <?php while ($rowv = $eventsall->fetch()) { ?>
              <li>
              <?= $rowv['title'];?>
              </li>
            <?php } ?>        
            </ul>
          <?php } ?>
          <?= $pagination ?>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /. box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /event calender -->
</section>
<!-- Main content -->
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        <form id="eventnewfrm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="add_event" value="true" />
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Title: </label>
                    <input class="form-control" type="text" size="30" id="title_update" name="title">
                </div>
                <div class="form-group">
                    <label>Description: </label>
                    <textarea name="description" class="form-control"></textarea>
                </div>
                <!--<div class="form-group">
                    <label>Url: </label>
                </div>-->
                <input type="hidden" name="url" class="form-control" />
                <div class="form-group">
                    <label>Color: </label>
                    <input type="text" value="#587ca3" name="color" id="color_picker" class="form-control">
                </div>
                <div class="form-group">
                    <label>Start Date: </label>
                    <input type="text" value="<?= date('Y-m-d'); ?>" name="start_date" id="date_datepicker" class="form-control hascalender">
                </div>
                <div class="form-group">
                    <label>End Date: </label>
                    <input type="text" value="<?= date('Y-m-d'); ?>" name="end_date" id="date_datepicker_second" class="form-control hascalender">
                </div>
            </div>
        </div>
        
    </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary event_action" data-action="savenew">Save changes</button>  
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- /Modal -->
<!-- Modal View Event -->
<div class="modal fade" id="cal_viewModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        qweqwe
      </div>
      <div class="modal-footer">
       <!-- <button type="button" class="btn btn-danger" data-option="remove">Delete</button>
        <button type="button" class="btn btn-info" data-option="edit">Edit</button>-->
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
  <!--<div id="cal_viewModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
    <div class="modal-content">  
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Modal title</h4>
        </div>
        <div class="modal-body"></div>
        <div class="modal-footer">
            <a href="#" class="btn btn-danger" data-option="remove">Delete</a>
            <a href="#" class="btn btn-info" data-option="edit">Edit</a>
        	<a href="#" class="btn" data-dismiss="modal">Close</a>
        </div>
      </div>
     </div>
    </div>-->    
<?php
$clienturl = CLIENT_URL;
$sBottomJavascript = <<<EOT
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.7.0/moment.min.js" type="text/javascript"></script>
<script src="$pluginurl/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
<script src="$pluginurl/colorpicker/bootstrap-colorpicker.js"></script>        
<script type="text/javascript">
$(function () {
    $.ajax({
	    url: "$clienturl/ajax-page-post",
        type: 'POST', // Send post data
        data: { fetch_event: "true", MSID: "$MSID" },
        async: false,
        success: function(s){
        	json_events = s;
        }
	});
	$('.hascalender').datepicker({format: 'yyyy-mm-dd', todayHighlight: true, autoclose: true});
	$('#color_picker').colorpicker();
	/*start model script section*/
	$('.event_action').click(function(e) {
	  var action = $(this).data('action');
          if(action=='savenew'){
           var datastring = $("#eventnewfrm").serialize();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "$clienturl/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                      responseText = $.trim(responseText);
                      if(responseText=='success'){
                       alert('Event successfully saved.');
					   $('#myModal').modal('hide');
					   $('#calendar').fullCalendar('removeEvents');
                       getFreshEvents()
                       }else if(responseText=='empty'){alert('Fill required fields.');}else{
                           alert('Error!!');
                        }
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                    }
                });
                // end ajax
          }
          return false;
        });
//fetch calaneder when add new
	function getFreshEvents(){
		$.ajax({
			url: "$clienturl/ajax-page-post",
	        type: 'POST', // Send post data
	        data: { fetch_event: "true", MSID: "$MSID" },
	        async: false,
	        success: function(s){
	        	freshevents = s;
	        }
		});
		$('#calendar').fullCalendar('addEventSource', JSON.parse(freshevents));
	}		
		/*end script section*/
        //Date for the calendar events (dummy data)
        var date = new Date();
        var d = date.getDate(),
                m = date.getMonth(),
                y = date.getFullYear();
        $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          buttonText: {
            today: 'today',
            month: 'month',
            week: 'week',
            day: 'day'
          },
          //Random default events
          events: JSON.parse(json_events),
		  eventClick: function(event, jsEvent, view) {
				$("#cal_viewModal .modal-body").html('<div class="loadingDiv">loading..</div>');
				$("#cal_viewModal .modal-header").html('<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>'+"<h4>"+event.title+"</h4>");
				$('#cal_viewModal').modal('show');
				$.ajax({
				type:"POST",
				url:"$clienturl/ajax-page-post",
				data:{ fetch_event: "true", MSID: "$MSID", ID: event.id},
				cache:false,
				beforeSend:function(){
				 $("#cal_viewModal .modal-footer").hide()
				},
				error:function(){alert("Failed to load content");},
				success:function(n){
				$("#cal_viewModal .modal-footer").show();
				if(event.url==="undefined"||event.url===''){
				$("#cal_viewModal .modal-body").html(n)
				}else{
				 $("#cal_viewModal .modal-body").html(n+"<br /><br /> Visit Url:<a href='"+event.url+"'>'"+event.url+"</a>")
				}
				 //$(".modal-footer").delegate('[data-option="remove"]',"click",function(e){alert(event.id);e.preventDefault();});
				}
				});
				return false;
			},
          editable: true,
          droppable: true, // this allows things to be dropped onto the calendar !!!
          drop: function (date, allDay) {}
        });

      }); 
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>
