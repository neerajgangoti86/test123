<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-6"> <?php $message = new Messages(); echo $message->display(); ?>
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Edit Department</h3>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form method="post" action="" role="form">
            <div class="box-body">
            <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>Department Name<span class="text-red">*</span></label>
                <input class="form-control" type="text" value="<?= $department['dept_name']; ?>" size="30" id="dept_name" name="dept_name">
              </div>
              <div class="form-group">
                <label> Status</label>
                <select class="form-control" id="status" name="status">
                  <option value="">Select Status</option>
                  <?php foreach(yes_no_dropdown() as $key => $value){
									 if($key == $department['status']){$selected = 'selected="selected"';}else{$selected = '';}
									 echo '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
								  } ?>
                </select>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <button type="submit" name="updatesubmit" class="btn btn-lg btn-success btn-block">Update</button>
                </div>
                <!-- \col -->
              </div>
              <!-- \row end -->
            </div>
          </form>
        </div>
        <!-- /.box -->
      </div>
    </div>
  </section>
  <!-- Main content -->