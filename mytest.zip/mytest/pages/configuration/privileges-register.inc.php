<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">New Privilege</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form method="post" action="" role="form"><!-- form start -->

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Role <sup class="text-red">Important</sup></label>
                                        <select class="form-control" name="role" onchange="this.form.submit()" required="required">
                                            <option value="">Select Role</option>
                                            <?php while ($roles = $role->fetch()) { ?>

                                                <?php
                                                
                                                if (@$_POST['role'] == $roles['id']): $selected = 'selected="selected"';
                                                else:
                                                    $selected = '';
                                                endif;
                                                ?>
                                                <option value="<?= $roles['id'] ?>" <?= $selected ?>><?= $roles['role_name'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>User Level</label>
                                        <label class="form-control"><?= @$ulevel['ulevel'] ?></label>
                                        <input value="<?= @$ulevel['ulevel'] ?>" type="hidden" name="ulevel" readonly="readonly">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Specific User ID &nbsp;<sup class="text-red">Important</sup></label>
                                        <input class="form-control" type="text" size="30" s name="userId" required="">
                                    </div>
                                </div>
                                <?php if (@$_POST['role']) { ?>
                                    <div class="col-md-12">
                                        <div class="form-group" style="margin: 0px;">
                                            <label> Modules : <sup class="text-red">Select Module To Provide Access</sup></label>
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" id="selectall" <?= @$checked ?> value="<?= $model['id'] ?>">
                                            </span>
                                            <label class="label label-info"> SELECT ALL</label>
                                        </div>
                                    </div> 

                                    <?php
                                    $getModules = Role::privilages($MSID, '', 'Default', @$_POST['role'])->fetch(PDO::FETCH_ASSOC);
                                    $DJM = json_decode($getModules['modules']);
                                    foreach ($DJM as $key => $val) {
                                        $modules = Master::get_modules($val, 1)->fetchall();
                                        foreach ($modules as $module) {
                                            ?>
                                            <div class="form-group ">
                                                <div class="col-md-6">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">
                                                            <input class="ModuleCheck" type="checkbox" name="chk_group[]" value="<?= $module['id'] ?>"> 

                                                        </span>
                                                        <label class="form-control"><?= $module['module_name'] ?></label>
                                                    </div>
                                                </div>
                                            </div><!-- \col -->
                                        <?php } ?>

                                        <?php
                                    }
                                }
                                ?>
                                <div class="col-md-12">
                                    <div class="form-group"></div>
                                    <div class="form-group" style="margin: 0px;">
                                        <label> Privilege : <sup class="text-red">Select Privilege</sup></label>
                                    </div>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <input type="checkbox" id="allprivileges">
                                        </span>
                                        <label class="label label-info"> SELECT ALL</label>
                                    </div>
                                    <div class="col-md-4 no-padding">
                                        <div class="form-group ">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input class="priv" type="checkbox" name="privilegeADD" value="1"> 
                                                </span>
                                                <label class="form-control">Add</label>
                                            </div>
                                        </div>
                                    </div><!-- \col -->
                                    <div class="col-md-4 no-padding">
                                        <div class="form-group ">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input class="priv" type="checkbox" name="privilegeEDIT" value="1"> 
                                                </span>
                                                <label class="form-control">Edit</label>
                                            </div>
                                        </div>
                                    </div><!-- \col -->
                                    <div class="col-md-4 no-padding">
                                        <div class="form-group ">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input class="priv" type="checkbox" name="privilegeDEL" value="1"> 
                                                </span>
                                                <label class="form-control">Delete</label>
                                            </div>
                                        </div>
                                    </div><!-- \col -->
                                </div>
                                <input type="hidden" name="status" value="1">
                                <div class="col-md-4 col-md-offset-4">
                                    <input type="submit" name="addprivilege" class="btn btn-lg btn-success btn-block" value="Submit">
                                </div>
                            </form>
                        </div><!-- \row end -->
                    </div>       
                </div><!-- /.box -->
            </div>
        </div>
    </div>
</section>
<!-- Main content -->
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
                                            $(document).ready(function () {
                                                $('#selectall').click(function (event) {
                                                    if (this.checked) {
                                                        $('.ModuleCheck').each(function () {
                                                            this.checked = true;
                                                        });
                                                    } else {
                                                        $('.ModuleCheck').each(function () {
                                                            this.checked = false;
                                                        });
                                                    }
                                                });
                                                $('#allprivileges').click(function (event) {
                                                    if (this.checked) {
                                                        $('.priv').each(function () {
                                                            this.checked = true;
                                                        });
                                                    } else {
                                                        $('.priv').each(function () {
                                                            this.checked = false;
                                                        });
                                                    }
                                                });
                                                
                                            });
</script>