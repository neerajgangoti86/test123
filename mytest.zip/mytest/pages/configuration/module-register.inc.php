<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-6"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Add Module</h3> 
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form method="post" action="" role="form">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Module <span class="text-red">*</span></label>
                                    <input class="form-control" value="" type="text" size="30" s name="module">
                                </div>


                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="hidden" value="<?= $MSID ?>" name='MSID'>
                                    <button type="submit" name="roleadd" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>       
                    </div>
                </form>

                <!-- /.box -->
            </div>
        </div>
    </div>
</section>
<!-- Main content -->