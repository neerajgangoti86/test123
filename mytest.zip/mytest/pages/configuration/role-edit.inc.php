<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-6"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Edit Role</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form method="post" action="" role="form">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Role <span class="text-red">*</span></label>
                                    <?php if ($roles['status'] == 1) { ?>
                                        <label class="form-control"   > <?= $roles['role_name']; ?> </label>
                                        <input type="hidden" name="role_name" value="<?= $roles['role_name']; ?>">

                                    <?php } else { ?>
                                        <input class="form-control" value="<?= $roles['role_name']; ?>" type="text" size="30" s name="role_name">                                     <?php } ?> 
                                </div>
                                <div class="form-group ">
                                    <label  for="exampleInputName2"> Privileges :</label>
                                    <?php
                                    $i = 1;
                                    $models = Master::get_modules('','1')->fetchall();
                                    foreach ($models as
                                            $model) {
                                        if (@$selected_module) {
                                            if (in_array($model['id'],
                                                            @$selected_module)) {

                                                $checked = "checked ='checked'";
                                            } else {
                                                $checked = "";
                                            }
                                        } else {
                                            $checked = "";
                                        }
                                        if ($i == 1) {
                                            ?>
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input type="checkbox" class="checkbox"  id="selectall"> 
                                                </span>
                                                <label class="form-control" for="exampleInputName2">Select All</label>
                                            </div>
    <?php } ?>

                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <input type="checkbox" class="checkbox1"  name="chk_group[]" <?= $checked ?>   value="<?= $model['id'] ?>"> 
                                            </span>
                                            <label class="form-control" for="exampleInputName2"><?= $model['module_name'] ?></label>
                                        </div>
    <?php $i++;
}
?>
                                    <!--                                    <div class="input-group">
                                                                         <input type="checkbox" name="chk_group[]" value="value1" />Value 1<br />
                                                                        </div>-->
                                </div>

                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" name="roleupdate" class="btn btn-lg btn-success btn-block">Update</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>       
                    </div>
                </form>

                <!-- /.box -->
            </div>
        </div>
    </div>
</section>
<!-- Main content -->
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#selectall').click(function (event) {
            if (this.checked) {
                $('.checkbox1').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox1').each(function () {
                    this.checked = false;
                });
            }
        });
    });



</script>
