<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Modules List</h3>
                    <h3 class="box-title"> <a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL; ?>/modules/add">Add Module</a></h3> </div>
                <!-- /.box-header -->
                <div class="box-body">

                    <?php
                    if ($totalrecords > 0)
                        {
                        ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Module Name</th>
                                <th>Action</th>
                            </tr>
                            <?php
                            $i = 1;
                            while ($rowv = $modules->fetch())
                                {
                                ?>
                                <tr>
                                    <td><?= $i ?></td>

                                    <td><?= $rowv['module_name']; ?></td>
                                    <?php
                                    // if ($rowv['status'] != 1)
//                                    { 
                                    ?>    
                                    <td><a class="text-light-blue" data-bb="confirm" title="Delete" href="<?= CLIENT_URL; ?>/modules/delete/<?= $rowv['id']; ?>"><i class="fa fa-trash-o"></i></a>
                                        <a class="text-light-blue" title="Edit" href="<?= CLIENT_URL; ?>/modules/edit/<?= $rowv['id']; ?>"><i class="fa fa-edit"></i></a>
                                       
                                <?php // } ?>
                                </tr>
                                <?php
                                $i++;
                                }
                            ?>
                            </tbody>
                        </table>
                        <?php
                        }
                    else
                        {
                        echo '<div class="text-center margin">No records found.</div>';
                        }
                    ?>
                </div>
                <div class="box-footer clearfix">
<?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php
$sBottomJavascript = <<<EOT
<script type="text/javascript">
    $(function () {
/*        $("#example1").dataTable( {
		 "aProcessing": true,
		 "aServerSide": true,
		 "ajax": "http://localhost/mountshivalik/ajax-page-load/paging",
		});*/
      });
    </script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>    