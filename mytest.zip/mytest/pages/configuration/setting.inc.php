<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php $message = new Messages();
            echo $message->display();
            ?>
        </div>
        
       
        <?php 
          // print_r($oCurrentSchool);
        ?>
        
  <form role="form" action="" method="post" enctype="multipart/form-data">
            <div class="col-md-6">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Edit School Configuration</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <div class="box-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">MSID</label>
                            <input type="text" name="msid" placeholder="Enter MSID" readonly="readonly" value="<?php echo $oCurrentSchool->MSID; ?>" id="exampleInputEmail1" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Name</label>
                            <input type="text" name="name" value="<?php echo $oCurrentSchool->name; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Place</label>
                            <input type="text" name="place" value="<?php echo $oCurrentSchool->place; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Post</label>
                            <input type="text" name="post" value="<?php echo $oCurrentSchool->post; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Distt</label>
                            <input type="text" name="distt" value="<?php echo $oCurrentSchool->distt; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">State</label>
                            <input type="text" name="state" value="<?php echo $oCurrentSchool->state; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Pin</label>
                            <input type="number" name="pin" value="<?php echo $oCurrentSchool->pin; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Board</label>
                            <?php
                               //$school_board_list = $school_board->fetch();
                            //print_r($school_board);
                               
                               ?>
                              <select name="board" class="form-control">
                              <?php
                                 while($school_board_row = $school_board->fetch())
                                 {
                                     
                                    if ($school_board_row['id'] == $oCurrentSchool->board)
                                      {
                                        $selected = 'selected="selected"';
                                      }
                                        else
                                        {
                                        $selected = '';
                                        }
                                    
                                    
                                      //print_r($school_board_row);
                              ?>
                                  <option value="<?=$school_board_row['id'] ?>" <?= $selected?>><?= $school_board_row['name']?></option>
                              <?php 
                                 }
                              ?>
                              </select>
                            
                            
                            
                           <?php /*<input type="text" name="board" value="<?php echo $oCurrentSchool->board; ?>" class="form-control"> */ ?>
                           
                            
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Affiliation No</label>
                            <input type="text" name="affno" value="<?php echo $oCurrentSchool->affNo; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Recognition No</label>
                            <input type="text" name="recno" value="<?php echo $oCurrentSchool->recNo; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">School No</label>
                            <input type="text" name="schoolno" value="<?php echo $oCurrentSchool->schoolNo; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Phone No</label>
                            <input type="number" name="phone" value="<?php echo $oCurrentSchool->phone; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Bank Name</label>
                            <input type="text" name="bank" value="<?php echo $oCurrentSchool->bank; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Branch Name</label>
                            <input type="text" name="branch" value="<?php echo $oCurrentSchool->branch; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Account Number</label>
                            <input type="text" name="acno" value="<?php echo $oCurrentSchool->acno; ?>" class="form-control">
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Ward Of Company</label>
                            <select id="ward_of_company" name="ward_of_company" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->ward_of_company)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                            
                        </div>
                        
                        
                         <div class="form-group">
                            <label for="exampleInputPassword1">No of Term</label>
                            <select id="no_of_term" name="no_of_term" class="form-control">
                               
                                <option value="0" <?php  if($oCurrentSchool->no_of_term == '0'){ echo "selected='selected'";}?>>0</option>
                                <option value="1" <?php  if($oCurrentSchool->no_of_term == '1'){ echo "selected='selected'";}?>>1</option>
                                <option value="2" <?php  if($oCurrentSchool->no_of_term == '2'){ echo "selected='selected'";}?>>2</option>
                                <option value="3" <?php  if($oCurrentSchool->no_of_term == '3'){ echo "selected='selected'";}?>>3</option>
                                
                           </select>
                            
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">CoScholastic Upgardation</label>
                            <select id="conschol_updgrade" name="conschol_updgrade" class="form-control">
                                 
                                
                                <option value="1" <?php  if($oCurrentSchool->CoScholastic == '1'){ echo "selected='selected'";}?>>Marks</option>
                                <option value="2" <?php  if($oCurrentSchool->CoScholastic == '2'){ echo "selected='selected'";}?>>Grade</option>
                                <option value="3" <?php  if($oCurrentSchool->CoScholastic == '3'){ echo "selected='selected'";}?>>Grade With Indicator</option>
                                
                                
                            </select>
                            
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="exampleInputSeparteTPT">Futur Use .....</label>
                            <select id="separte_tpt" name="separte_tpt" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->SeprateTPTFBook)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
 
                            
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputSeparteTPT">Round Amount</label>
                            <select id="round_amount" name="round_amount" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->RoundAmt)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
 
                            
                        </div>
                        
                      
                     <div class="form-group">
                            <label for="exampleInputSeparteTPT">Amount Multiple Of </label>
                            <select id="amount_muliple_of" name="amount_muliple_of" class="form-control">
                                <option value="1"   <?php  if($oCurrentSchool->amount_multiple_of == "1") { echo "selected='selected'"; }?> >Normal</option>
                                <option value="5"   <?php  if($oCurrentSchool->amount_multiple_of == "5") { echo "selected='selected'"; }?>>5</option>
                                <option value="10"   <?php  if($oCurrentSchool->amount_multiple_of == "1") { echo "selected='selected'"; }?>>10</option>
                                
                            </select>
 
                            
                        </div>
 
                        
                        
                       <div class="form-group">
                            <label for="exampleInputSeparteTPT">Bank Receipt </label>
                            <select id="bank_receipt" name="bank_receipt" class="form-control">
                            <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->bank_reciept)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                            
                        </div> 
                       
                        
                        
                        
                        
                        
                        
                        
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <div class="col-md-6">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title"></h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <div class="box-body">
                        <div class="form-group">
                            <label for="exampleInputPassword1">Class From</label>
                            <select id="classfrom" name="classfrom" class="form-control">
                                <option value="">Select </option>
                                <?php
                                foreach ($classes as $rowv)
                                    {
                                    if ($rowv['class_no'] == $oCurrentSchool->class_from)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    ?>
                                    <option value="<?= $rowv['class_no']; ?>" <?= $selected; ?>><?= $rowv['class_name']; ?></option>
<?php } ?>   
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Class To</label>
                            <select id="classto" name="classto" class="form-control">
                                <option value="">Select </option>
                                <?php
                                foreach ($classes as $rowv)
                                    {
                                    if ($rowv['class_no'] == $oCurrentSchool->class_to)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    ?>
                                    <option value="<?= $rowv['class_no']; ?>" <?= $selected; ?>><?= $rowv['class_name']; ?></option>
<?php } ?>    
                            </select>
                        </div>
                        <?php
                        /*<div class="form-group">
                            <label for="exampleInputPassword1">Session Start Date  <?php //print_r($oCurrentSchool);?></label>
                            <input type="text" name="session_start_date" value="<?php echo date('Y-m-d', strtotime($oCurrentSchool->session_start_date)); ?>" class="form-control datepicker">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Session End Date</label>
                            <input type="text" name="session_end_date" value="<?php echo date('Y-m-d', strtotime($oCurrentSchool->session_end_date)); ?>" class="form-control datepicker">
                        </div>*/
                    
                        ?>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Bank/Cash</label>
                            <input type="text" name="bankcash" value="<?php echo $oCurrentSchool->bank_cash; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Fee Last Date </label>
                            <input type="text" name="feelastdate" value="<?php echo date('Y-m-d', strtotime($oCurrentSchool->fee_last_date)); ?>" class="form-control datepicker">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">School Logo</label>
                            <img src="<?= CLIENT_URL.$oCurrentSchool->logo_img ?>" width="100" style="float:right;"/>
                            <input type="hidden" value="<?= $oCurrentSchool->logo_img; ?>" name="logoimage_org" />
                            <input type="file" name="logoimage">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Transport</label>
                            <span id="msg_show" style="color:red;"></span>
                            <select id="transport" name="transport" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->transport)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Activity</label>
                            <select id="activity" name="activity" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->activity)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        
                        
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Hostel</label>
                            <span id="hostel_msg" style="color:red;"></span>
                            <select id="hostel" name="hostel" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->hostel)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Separate TPT FeeBook</label>
                            <select id="feebook" name="feebook" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->SeprateTPTFBook)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        
                        
                        
                      <div class="form-group">
                            <label for="exampleInputPassword1">Head Wise Fee Report</label>
                            <select id="Detailed_Headwise" name="Detailed_Headwise" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->Detailed_Headwise)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div> 
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">House</label>
                            <select id="house" name="house" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->house)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>

                        
                        
                        
                        
                        
                        
                        
                        <div class="form-group">
                            <label for="exampleInputPassword1">Library</label>
                            <select id="library" name="library" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->library)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div> <div class="form-group">
                            <label for="exampleInputPassword1">Admission No. Required</label>
                            <select id="library" name="adm_no" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->adm_no)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div><div class="form-group">
                            <label for="exampleInputPassword1">Student Selection Process</label>
                            <select id="library" name="selection" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->selection)
                                        {
                                       $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Science</label>
                            <select id="science" name="science" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->science)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Arts</label>
                            <select id="arts" name="arts" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->arts)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Commerce</label>
                            <select id="commerce" name="commerce" class="form-control">
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->commerce)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                            </select>
                        </div>
<!--                        <div class="form-group">
                            <label for="exampleInputPassword1">Section</label>
                            <select id="section" name="section" class="form-control">
                                
                                //<?php
//                                for ($i = 0; $i <= 10; $i++)
//                                    {
//                                    if ($i == $oCurrentSchool->section)
//                                        {
//                                        $selected = 'selected="selected"';
//                                        }
//                                    else
//                                        {
//                                        $selected = '';
//                                        }
//                                    echo '<option value="' . $i . '" ' . $selected . '>' . $i . '</option>';
//                                    }
//                                ?>
                            </select>
                        </div>-->
                        <div class="form-group">
                            <label for="exampleInputPassword1">School Type</label>
                            <select id="school_type" name="school_type" class="form-control">
                                <option value="0" <?php echo ($oCurrentSchool->school_type == "0") ? 'selected= "selected"' : ''; ?>> CO-Education School</option>
                                <option value="1" <?php echo ($oCurrentSchool->school_type == "1") ? 'selected= "selected"' : ''; ?>> Boys School </option>
                                <option value="2" <?php echo ($oCurrentSchool->school_type == "2") ? 'selected= "selected"' : ''; ?>> Girls School</option>
                            </select>
                        </div>

                    <div class="form-group">
                            <label for="exampleInputPassword1">Discount</label>
                            <span id="discount_msg" style="color:red;"></span>
                            <select id="discount" name="discount" class="form-control">
                                
                                <?php
                                foreach (yes_no_dropdown() as $key => $value)
                                    {
                                    if ($key == $oCurrentSchool->discount)
                                        {
                                        $selected = 'selected="selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
                                    }
                                ?>
                                
                            </select>
                        </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Water Mark For Reports</label>
                            <select id="watermark" name="watermark" class="form-control">
                                <option value="0" <?php echo ($oCurrentSchool->watermark == "0") ? 'selected= "selected"' : ''; ?>>No</option>
                                <option value="1" <?php echo ($oCurrentSchool->watermark == "1") ? 'selected= "selected"' : ''; ?>>Yes</option>
                                
                            </select>
                        </div>
                         <div class="form-group">
                            <label for="exampleInputPassword1">Locality Pin Code</label>
                            <input type="text" name="locality_pincode" value="<?php echo $oCurrentSchool->locality_pincode; ?>"  class="form-control">
                        </div>
                         <div class="form-group">
                            <label for="exampleInputPassword1">Admission No Auto Increment </label>
                            <select id="admno_auto" name="admno_auto" class="form-control">
                            <option value="0" <?php echo ($oCurrentSchool->admno_auto == "0") ? 'selected= "selected"' : ''; ?>>No</option>
                            <option value="1" <?php echo ($oCurrentSchool->admno_auto == "1") ? 'selected= "selected"' : ''; ?>>Yes</option> 
                                
                            </select>
                        </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Combined Feebook For Siblings </label>
                            <select id="combine_feebook" name="combine_feebook" class="form-control">
                            <option value="0" <?php echo ($oCurrentSchool->combine_feebook == "0") ? 'selected= "selected"' : ''; ?>>No</option>
                            <option value="1" <?php echo ($oCurrentSchool->combine_feebook == "1") ? 'selected= "selected"' : ''; ?>>Yes</option> 
                                
                            </select>
                        </div>
 <div class="form-group">
                            <label for="exampleInputPassword1">Grades In Academic Performance </label>
                            <select id="grades_in_acc_perf" name="grades_in_acc_perf" class="form-control">
                            <option value="0" <?php echo ($oCurrentSchool->grades_in_acc_perf == "0") ? 'selected= "selected"' : ''; ?>>No</option>
                            <option value="1" <?php echo ($oCurrentSchool->grades_in_acc_perf == "1") ? 'selected= "selected"' : ''; ?>>Yes</option> 
                                
                            </select>
                        </div>



                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button class="btn btn-primary" name="updateschool" type="submit">Update</button>
                    </div>
                </div>
                <!-- /.box -->
            </div>
        </form>
    </div>
    <input type="hidden" name="site_url" value="<?= CLIENT_URL; ?>" id="site_url">
</section>
<!-- Main content -->
<?php

$sBottomJavascript = <<<EOT
<script type="text/javascript">
    $(function () {
	  $('.datepicker').datepicker({
		format: 'yyyy-mm-dd',
		todayHighlight: true,
		autoclose: true
		});
 });
 $(document).ready(function()
 {
         
       // alert('hi');
  $('#transport').change(function(e)
  {  
        
      var site_url = $("#site_url").val();  
      var transport = $(this).val();
      $.ajax({
			url: site_url+"/ajax-page-load/transpor_check",
			type: "post",
			data: { transport: transport} ,
			success: function (response) {
                        if(response > 0)
                        {
                           $("#msg_show").html('You can not choose this option');
                           $("#transport :selected").prop('selected', false);
                           var val = "1";
                           $("#transport option[value='" + val + "']").attr("selected","selected");
                           //$("#msg_show").html('');
                            }
                        else
                        {
                           $("#msg_show").html('');
                        }
        
			  //$('#selection').html(response);
                    //$('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
        

	});  
        
        
 });   
        
  $('#discount').change(function(e)
  {  
        
      var site_url = $("#site_url").val();  
      var discount = $(this).val();
      $.ajax({
			url: site_url+"/ajax-page-load/discount_check",
			type: "post",
			data: { discount: discount} ,
			success: function (response) 
                       {
                       if(response > 0)
                        {
                           $("#discount_msg").html('You can not choose this option');
                            $("#discount :selected").prop('selected', false);
                           var val = "1";
                           $("#discount option[value='" + val + "']").attr("selected","selected");
                           //$("#discount_msg").html('');
                            }
                        else
                        {
                           $("#discount_msg").html('');
                        }
                         
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
        

	});  
        
        
        
        
 });   
        
        
$('#hostel').change(function(e)
  {  
        
      var site_url = $("#site_url").val();  
      var hostel = $(this).val();
      $.ajax({
			url: site_url+"/ajax-page-load/hostel_check",
			type: "post",
			data: { hostel: hostel} ,
			success: function (response) 
                       {
                         alert(response);
                       if(response > 0)
                        {
                           $("#hostel_msg").html('You can not choose this option');
                            $("#hostel :selected").prop('selected', false);
                           var val = "1";
                           $("#hostel option[value='" + val + "']").attr("selected","selected");
                           //$("#hostel_msg").html('');
                            }
                        else
                        {
                           $("#discount_msg").html('');
                        }
                         //alert(response);
			  //$('#selection').html(response);
                    //$('#first_select').hide();
			},
			error: function(jqXHR, textStatus, errorThrown) {
			   console.log(textStatus, errorThrown);
			}
        

	});  
         
        }); 
        
        
        
        
        
        
        
        
        
 });
</script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>