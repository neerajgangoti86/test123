<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php $message = new Messages();
echo $message->display();
?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Role List</h3>
                    <h3 class="box-title"> <a class="btn bg-olive btn-flat margin" href="<?= CLIENT_URL; ?>/role/add">Add Role</a></h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">

<?php if ($totalrecords > 0) { ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Role </th>
                                <!--<th>Description</th>-->
                                <th>Action</th>
                            </tr>
                            <?php
                            $i = 1;
                            while ($rowv = $roles->fetch()) {
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= $rowv['role_name']; ?></td>
                                    <!--<td><?= $rowv['description']; ?></td>-->
                                    <td><a class="text-light-blue" title="Edit" href="<?= CLIENT_URL; ?>/role/edit/<?= $rowv['id']; ?>"><i class="fa fa-edit"></i></a>
                                     <?php if ($rowv['status'] != 1) { ?>     <a class="text-light-blue" data-bb="confirm" title="Edit" href="<?= CLIENT_URL; ?>/role/delete/<?= $rowv['id']; ?>"><i class="fa fa-trash-o"></i></a>
                                     <?php } ?></td>
                                </tr>
                                <?php
                                $i++;
                            }
                            ?>
                            </tbody>
                        </table>
                    <?php
                    } else {
                        echo '<div class="text-center margin">No records found.</div>';
                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
<?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php
$sBottomJavascript = <<<EOT
<script type="text/javascript">
    $(function () {
/*        $("#example1").dataTable( {
		 "aProcessing": true,
		 "aServerSide": true,
		 "ajax": "http://localhost/mountshivalik/ajax-page-load/paging",
		});*/
      });
    </script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>    