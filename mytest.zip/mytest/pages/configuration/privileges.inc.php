<section class="content">
    <div class="row">
        <div class="col-xs-12"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Privilege List</h3>
                    <h3 class="box-title"> : 
                        <?php
                        $data = check_privlages(CLIENT_URL . '/privileges/new', NULL, NULL, $oCurrentUser->myuid, $MSID);
                        print_r($data);
                        ?>
                    </h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">

                    <?php if ($totalrecords > 0) {
                        ?>
                        <table class="table table-hover">
                            <tr>
                                <th>Sr.No.</th>
                                <th>User ID</th>
                                <th>Role </th>
                                <th colspan="3" class="text-center">Privilege</th>
                                <th>Action</th>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>Add</td>
                                <td>Edit</td>
                                <td>Delete</td>
                                <td></td>
                            </tr>
                            <?php
                            $i = 1;
                            while ($privilege = $roles->fetch()) {
                                $name = Role::get_role($privilege['role'])->fetch(PDO::FETCH_ASSOC);
                                if ($privilege['status'] == 0) {
                                    $class = 'danger';
                                    $btns = '';
                                } else {
                                    $class = "success";
                                    $LINK_EDIT = CLIENT_URL . '/privileges/edit/' . $privilege['id'];
                                    $LINK_DEL = CLIENT_URL . '/privileges/delete/' . $privilege['id'];
                                    $btns = check_privlages(NULL, $LINK_EDIT, $LINK_DEL, $oCurrentUser->myuid, $MSID);
                                }
                                ?>
                                <tr class="<?= $class ?>" >
                                    <td style="border-color: #fff "><?= $i ?></td>
                                    <td style="border-color: #fff "><?php if (@$privilege['userId']): print $privilege['userId'];
                        else: print 'N/A';
                        endif; ?></td>
                                    <td style="border-color: #fff "><?= $name['role_name']; ?></td>
                                    <?php if ($privilege['p_add'] != 0): ?>
                                        <td class="text-green"  style="border-color: #fff "><?= '<i class="fa fa-check"></i>' ?></td>
                                    <?php else: ?>
                                        <td class="text-red"  style="border-color: #fff "><?= '<i class="fa fa-remove"></i>' ?></td>
                                    <?php endif; ?>

                                    <?php if ($privilege['p_edit'] != 0): ?>
                                        <td class="text-green"  style="border-color: #fff "><?= '<i class="fa fa-check"></i>' ?></td>
                                    <?php else: ?>
                                        <td class="text-red"  style="border-color: #fff "><?= '<i class="fa fa-remove"></i>' ?></td>
                                    <?php endif; ?>

                                    <?php if ($privilege['p_delete'] != 0): ?>
                                        <td class="text-green"  style="border-color: #fff "><?= '<i class="fa fa-check"></i>' ?></td>
                                    <?php else: ?>
                                        <td class="text-red"  style="border-color: #fff "><?= '<i class="fa fa-remove"></i>' ?></td>
                                    <?php endif; ?>

                                    <td style="border-color: #fff "><?php print_r($btns) ?></td>
                                </tr>
                                <?php
                                $i++;
                            }
                            ?>
                            </tbody>
                        </table>
                        <?php
                    }
                    else {
                        echo '<div class="text-center margin">No records found.</div>';
                    }
                    ?>
                </div>
                <div class="box-footer clearfix">
                    <?= $pagination ?>
                </div>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php
$sBottomJavascript = <<<EOT
<script type="text/javascript">
    $(function () {
/*        $("#example1").dataTable( {
		 "aProcessing": true,
		 "aServerSide": true,
		 "ajax": "http://localhost/mountshivalik/ajax-page-load/paging",
		});*/
      });
    </script>
EOT;
$oPageLayout->addJavascriptBottom($sBottomJavascript);
?>    