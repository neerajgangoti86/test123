<!-- Main content -->
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Edit Privilege</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form method="post" action="" role="form"><!-- form start -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Specific User ID &nbsp;<sup class="text-red">Important</sup></label>
                                        <input class="form-control" type="text" size="30" value="<?= @$data['userId'] ?>" name="userId" required="required">
                                    </div>

                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Role</label>
                                        <?php $Role = Role::get_role($data['role'])->fetch(PDO::FETCH_ASSOC); ?>
                                        <label class="form-control"><?= $Role['role_name'] ?></label>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group" style="margin: 0px;">
                                        <label> Modules : <sup class="text-red">Select Module To Provide Access</sup></label>
                                    </div>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <input type="checkbox" id="selectall">
                                        </span>
                                        <label class="label label-info"> SELECT ALL</label>
                                    </div>
                                </div>
                                
                                <div class="form-group ">
                                    <input class="hidden" type="checkbox" name="chk_group[]" checked="checked" value="">
                                    <?php
                                    $models = Master::get_modules(NULL, 1)->fetchall();
                                    foreach ($models as $model) {
//                                        pr($model['id']);
//                                        pr($selected_module);
                                        if (!empty($selected_module)) {
                                            if (!in_array($model['id'], $selected_module)) {
                                                $checked = 'checked="checked"';
                                            } else {
                                                $checked = '';
                                            }
                                        }
                                        else
                                        {
                                            $checked = 'checked="checked"';
                                        }
                                        ?>
                                        <div class="col-md-6">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input class="ModuleCheck" type="checkbox" name="chk_group[]" <?= @$checked ?> value="<?= $model['id'] ?>"> 
                                                </span>
                                                <label class="form-control"><?= $model['module_name'] ?></label>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div><!-- \col -->
                                <div class="col-md-12">
                                    <div class="form-group"></div>
                                    <div class="form-group">
                                        <label> Privileges :</label>
                                    </div>
                                    <?php
                                    if ($data['p_add'] == 1) {
                                        $checkadd = 'checked="checked"';
                                    } else {
                                        $checkadd = "";
                                    }
                                    if ($data['p_edit'] == 1) {
                                        $checkedit = 'checked="checked"';
                                    } else {
                                        $checkedit = "";
                                    }
                                    if ($data['p_delete'] == 1) {
                                        $checkdel = 'checked="checked"';
                                    } else {
                                        $checkdel = "";
                                    }
                                    ?>
                                    <div class="col-md-4 no-padding">
                                        <div class="form-group ">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input type="checkbox" name="privilegeADD" <?= $checkadd ?> value="1"> 
                                                </span>
                                                <label class="form-control">Add</label>
                                            </div>
                                        </div>
                                    </div><!-- \col -->
                                    <div class="col-md-4 no-padding">
                                        <div class="form-group ">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input type="checkbox" name="privilegeEDIT" <?= $checkedit ?> value="1"> 
                                                </span>
                                                <label class="form-control">Edit</label>
                                            </div>
                                        </div>
                                    </div><!-- \col -->
                                    <div class="col-md-4 no-padding">
                                        <div class="form-group ">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <input type="checkbox" name="privilegeDEL" <?= $checkdel ?> value="1"> 
                                                </span>
                                                <label class="form-control">Delete</label>
                                            </div>
                                        </div>
                                    </div><!-- \col -->
                                </div>
                                <div class="col-md-4 col-md-offset-4">
                                    <input type="submit" name="updatePrivilege" class="btn btn-lg btn-success btn-block" value="Update">
                                </div>
                            </form>
                        </div><!-- \row end -->
                    </div>       
                </div><!-- /.box -->
            </div>
        </div>
    </div>
</section>
<!-- Main content -->
<!-- Main content -->
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#selectall').click(function (event) {
            if (this.checked) {
                $('.ModuleCheck').each(function () {
                    this.checked = true;
                });
            } else {
                $('.ModuleCheck').each(function () {
                    this.checked = false;
                });
            }
        });
    });



</script>
