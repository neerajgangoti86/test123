<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-6"> <?php $message = new Messages();
echo $message->display();
?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Add Role</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form method="post" action="" role="form">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Role <span class="text-red">*</span></label>
                                    <input class="form-control" value="" type="text" size="30" s name="role_name">
                                </div>
                                <div class="form-group">
                                    <label>User Level <span class="text-red">*</span></label>
                                    <input class="form-control" value="" type="text" size="30" s name="ulevel">
                                </div> 
                                <div class="form-group ">
                                    <label  for="exampleInputName2"> Privileges :</label>
<?php $models= Master::get_modules()->fetchall();
foreach($models as $model) {
    ?>
     
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <input type="checkbox" name="chk_group[]" value="<?= $model['id']?>"> 
                                        </span>
                                        <label class="form-control" for="exampleInputName2"><?= $model['module_name']?></label>
                                    </div>
                                       <?php
}?>
                                </div>
                             
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="hidden" value="<?= $MSID ?>" name='MSID'>
                                    <button type="submit" name="roleadd" class="btn btn-lg btn-success btn-block">Submit</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>       
</div>
                </form>
            
            <!-- /.box -->
        </div>
    </div>
    </div>
</section>
<!-- Main content -->