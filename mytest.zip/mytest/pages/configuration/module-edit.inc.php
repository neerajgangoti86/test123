<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-6"> <?php
            $message = new Messages();
            echo $message->display();
            ?>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Edit Modules</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form method="post" action="" role="form">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Role <span class="text-red">*</span></label>
                                    <?php // if ($roles['status'] == 1) { ?>
<!--                                        <label class="form-control"   > <?= $roles['module_name']; ?> </label>
                                        <input type="hidden" name="module_name" value="<?= $roles['module_name']; ?>">-->

                                    <?php // } else { ?>
                                        <input class="form-control" value="<?= $roles['module_name']; ?>" type="text" size="30" s name="module">                                     <?php // } ?> 
                                </div>
                              

                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" name="roleupdate" class="btn btn-lg btn-success btn-block">Update</button>
                                </div>
                                <!-- \col -->
                            </div>
                            <!-- \row end -->
                        </div>       
                    </div>
                </form>

                <!-- /.box -->
            </div>
        </div>
    </div>
</section>
<!-- Main content -->
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#selectall').click(function (event) {
            if (this.checked) {
                $('.checkbox1').each(function () {
                    this.checked = true;
                });
            } else {
                $('.checkbox1').each(function () {
                    this.checked = false;
                });
            }
        });
    });



</script>
