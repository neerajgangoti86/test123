<?php
class General {

 public static function gererate_db_nextid($MSID = NULL, $tablename = NULL, $dataselect = 'employee_id'){
   try {
		 $sql="SELECT ".$dataselect." FROM ".DB_PREFIX.$tablename;
		 $sql .= " where MSID=".$MSID;
		 $sql .= " order by ".$dataselect." DESC LIMIT 1";
//                 print_r($sql);
//                 exit();
		 $oDb = DBConnection::get();
		 $sql = $oDb->query($sql);
		 return $sql;
     }
	catch(PDOException $e) {
	  $message = new Messages();
	  $message->add('e', $e->getMessage());
	}
  }
/**
 * activate / deactivate recoreds
 * @parm id , tablename, redirect, status 
 **/
 public function activate_deactivate($data = array()){
 $message = new Messages();
 $oDb = DBConnection::get();
	  try{
	      if(!empty($data["where"])){ $where_column = $data["where"]; }else{ $where_column = 'id'; }
		  $upsql = $oDb->prepare('UPDATE '.DB_PREFIX.$data["tablename"].' SET status = :status  WHERE '.$where_column.' = :id');
				$upsql->execute(array(
				    ':status' => $data["status"],
					':id' => $data["id"]
				));
			if(!empty($data["redirect"])){	
			$message->add('s', 'Status changed successfully!',$data["redirect"]);
			exit();
			}else{
			$message->add('s', 'Status changed successfully!');
			}
	  }
	  catch(PDOException $e) {
	    $message->add('e', $e->getMessage());
	  }
 
 }  
 /**
 * delete record function
 * @parm id , tablename, redirect, where 
 **/
 public static function delete($data = array()){
 $message = new Messages();
 
	  try{
	      $oDb = DBConnection::get();
		  $upsql = $oDb->prepare('DELETE FROM '.DB_PREFIX.$data["tablename"].' WHERE '.$data["where"].' = :id') ;
				$upsql->execute(array(
					':id' => $data["id"]
				));
			if(!empty($data["redirect"])){	
			$message->add('s', 'Record deleted successfully!',$data["redirect"]);
			exit();
			}else{
			$message->add('s', 'Record deleted successfully!');
			}
	  }
	  catch(PDOException $e) {
	    $message->add('e', $e->getMessage());
	  }
 
 }
 public function add_hide_show_columns($id = NULL, $msid = NULL, $user_id = NULL, $table_name = NULL, $fields = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            $sql = " SELECT * ";
            $sql .=" from " . DB_PREFIX . "hide_show_columns ";
            $sql .= " WHERE MSID = ".$msid." AND user_id = '" . $user_id . "' AND table_name = '".$table_name."'";
            $oDb = DBConnection::get();
            $count_data = $oDb->query($sql)->rowCount();
            if ($count_data > 0) {
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'hide_show_columns SET fields = :fields WHERE MSID = :MSID AND user_id = :user_id AND table_name = :table_name ');
                $upsql->execute(array(
				    ':MSID' => $msid,
                    ':user_id' => $user_id,
                    ':table_name' => $table_name,
                    ':fields' => $fields,
                ));
                 $last_id = $oDb->lastInsertId();
                return $last_id;
                exit();
            } else {
                $sqladd = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'hide_show_columns (MSID, user_id, table_name, fields) VALUES  (:MSID, :user_id, :table_name, :fields)');
                $sqladd->execute(array(
                    ':MSID' => $msid,
                    ':user_id' => $user_id,
                    ':table_name' => $table_name,
                    ':fields' => $fields,
                ));
                $last_id = $oDb->lastInsertId();
                return $last_id;
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function get_hide_show_columns($msid = NULL, $user_id = NULL, $table_name = NULL) {
        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "hide_show_columns  ";
            $sql .= " WHERE MSID=" . $msid . " AND status ='1'";
            if (!empty($user_id)) {
                $sql .=" AND user_id= '" . $user_id."'";
            }
            if (!empty($table_name)) {
                $sql .=" AND table_name='". trim($table_name)."'";
            }

            $sql .= " order by id DESC";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
 //	create image thumbnil
 public function cwUpload($file = '',$field_name = '', $target_folder = '', $file_name = '', $thumb = FALSE, $thumb_folder = '', $thumb_width = '', $thumb_height = ''){
	//folder path setup
	$target_path = $target_folder;
	$thumb_path = $thumb_folder;
	
	//file name setup
	$filename_err = explode(".",$file[$field_name]['name']);
	$filename_err_count = count($filename_err);
	$file_ext = $filename_err[$filename_err_count-1];
	if($file_name != '')
	{
		$fileName = $file_name.'.'.$file_ext;
	}
	else
	{
		$fileName = $file[$field_name]['name'];
	}
	
	//upload image path
	$upload_image = $target_path.basename($fileName);
	
	//upload image
	if(move_uploaded_file($file[$field_name]['tmp_name'],$upload_image))
	{
		//thumbnail creation
		if($thumb == TRUE)
		{
			$thumbnail = $thumb_path.$fileName;
			list($width,$height) = getimagesize($upload_image);
			$thumb_create = imagecreatetruecolor($thumb_width,$thumb_height);
			switch($file_ext){
				case 'jpg':
					$source = imagecreatefromjpeg($upload_image);
					break;
				case 'jpeg':
					$source = imagecreatefromjpeg($upload_image);
					break;
				case 'png':
					$source = imagecreatefrompng($upload_image);
					break;
				case 'gif':
					$source = imagecreatefromgif($upload_image);
					break;
				default:
					$source = imagecreatefromjpeg($upload_image);
			}
			imagecopyresized($thumb_create,$source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);
			switch($file_ext){
				case 'jpg' || 'jpeg':
					imagejpeg($thumb_create,$thumbnail,100);
					break;
				case 'png':
					imagepng($thumb_create,$thumbnail,100);
					break;
				case 'gif':
					imagegif($thumb_create,$thumbnail,100);
					break;
				default:
					imagejpeg($thumb_create,$thumbnail,100);
			}
		}

		return $fileName;
	}
	else
	{
		return false;
	}
}  
public function create_url_slug($string){
	$string = strtolower($string);
	$slug=preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
	return $slug;
}  
public function excerpt($text, $limit)
{
	$content = $text;
	if (strlen($content)>=$limit) {
	$content = substr(strip_tags($text), 0, $limit).'..';
	} else {
	$content = strip_tags($text);
	}
	
	return $content;
}

}

?>
