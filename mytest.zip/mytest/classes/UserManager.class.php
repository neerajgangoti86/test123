<?php

class UserManager {

    public static function get_users($id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "users";

            if ($id != NULL) {
                $sql .= " where user_id=" . $id;
            } else {
                $sql .=" where MSID!=0";
            }
            $sql .= " order by user_id DESC";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_slusers($id = NULL, $msid = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "slusers";

            $sql .= " where user_id='" . $id . "'";

            if ($msid != NULL) {
                $sql .= " and MSID=" . $msid;
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function update_user($id = NULL, $data = array(), $redirect = NULL) {
        $message = new Messages();
        try {
            $oDb = DBConnection::get();
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'users SET first_name = :first_name, last_name = :last_name, email = :email, MSID = :MSID WHERE user_id = :id');
            $upsql->execute(array(
                ':first_name' => $data['first_name'],
                ':last_name' => $data['last_name'],
                ':email' => $data['email'],
                ':MSID' => $data['MSID'],
                ':id' => $id
            ));
            $message->add('s', 'Updated successfully!', $redirect);
            exit();
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function create_user($postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            if (strlen(trim(@$postdata['first_name'])) == 0)
                $message->add('e', 'First name is required!');
            if (strlen(trim(@$postdata['last_name'])) == 0)
                $message->add('e', 'Last name is required!');
            if (strlen(trim(@$postdata['email'])) == 0)
                $message->add('e', 'Email is required!');
            if (strlen(trim(@$postdata['username'])) == 0)
                $message->add('e', 'Username is required!');
            if (strlen(trim(@$postdata['password'])) == 0)
                $message->add('e', 'Password is required!');
            if (!$message->hasMessages()) {
                $password = hashpassword($postdata['password']);
                //insert into database
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'users (username,password,first_name,last_name, email, MSID, user_level, created_date, status) VALUES  (:username, :password, :first_name, :last_name, :email, :MSID, :user_level, :created_date, :status)');

                $sql->execute(array(
                    ':username' => $postdata['username'],
                    ':password' => $password,
                    ':first_name' => $postdata['first_name'],
                    ':last_name' => $postdata['last_name'],
                    ':email' => $postdata['email'],
                    ':MSID' => $postdata['MSID'],
                    ':user_level' => $postdata['user_level'],
                    ':created_date' => date('Y-m-d H:i:s'),
                    ':status' => '1'
                ));
                $message->add('s', 'User successfully created!', CLIENT_URL . '/users');
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function change_password($userid = NULL, $postdata = array(), $redirect = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            if (strlen(trim($postdata['currpassword'])) == 0)
                $message->add('e', 'Current password is required!');
            if (strlen(trim($postdata['newpassword'])) == 0)
                $message->add('e', 'New password is required!');
            if (strlen(trim($postdata['confpassword'])) == 0)
                $message->add('e', 'Confirm password is required!');
            if ($postdata['confpassword'] != $postdata['newpassword'])
                $message->add('e', 'Password not match!');

            if (!$message->hasMessages()) {
                $currentpass = hashpassword($postdata['currpassword']);
                $newpassword = hashpassword($postdata['newpassword']);
                $sql = "SELECT user_id, email  FROM " . DB_PREFIX . "users WHERE user_id = '" . $userid . "' and password = '" . $currentpass . "'";
                $stmt = $oDb->query($sql);
                $no_row = $stmt->fetchColumn();

                if ($no_row > 0) {
                    //insert into database
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'users SET password = :password WHERE user_id = :id');
                    $stmt->execute(array(
                        ':password' => $newpassword,
                        ':id' => $userid
                    ));
                    //redirect to index page
                    $message->add('s', 'Pasword changed successfully!', $redirect);
                    exit();
                } else {
                    $message->add('e', 'Current password is not valid!');
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    /**
     * get user by email and pass and set in session
     * @param string $sUsername
     * @param string $sPassword
     * @return mixed User/false
     */
    public static function login($username, $password, $remember) {

        try {
            $cookpass = $password;
            $password = hashpassword($password);
            $oDb = DBConnection::get();
            $sql = "SELECT * FROM " . DB_PREFIX . "slusers WHERE myuid = '" . $username . "' and mypsw = '" . $password . "'";
            $stmt = $oDb->query($sql);
            $oUser = $stmt->fetch(PDO::FETCH_OBJ);
            //$db->query($sql);// or die(mysql_error());
            if ($remember != NULL) {
                setcookie("user_login", $username, time() + (60 * 60 * 24 * 30));
                setcookie("user_pass", $cookpass, time() + (60 * 60 * 24 * 30));
                setcookie("user_rem", $remember, time() + (60 * 60 * 24 * 30));
            } else {
                setcookie("user_login", '', time() - (60 * 60 * 24 * 30));
                setcookie("user_pass", '', time() - (60 * 60 * 24 * 30));
                setcookie("user_rem", '', time() - (60 * 60 * 24 * 30));
            }
            if ($oUser) {
                self::loginUser($oUser);
                //self::updateLastLogin($oUser->userId); //update last login date and time'
                ActivityFeed::add_feeds($_SESSION['oCurrentUser']->MSID, $_SESSION['oCurrentUser']->user_id, $_SESSION['oCurrentUser']->myuname, $_SESSION['oCurrentUser']->ulevel, 'Logged In', '', '', '', '', '');
                return true;
            }

            /* no user found return false */
            return false;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /**
     * get user by email and pass and set in session
     * @param string $sUsername
     * @param string $sPassword
     * @return mixed User/false
     */
    public static function get_status($username, $password) {

        try {
            $cookpass = $password;
            $password = hashpassword($password);
            $oDb = DBConnection::get();
            $sql = "SELECT * FROM " . DB_PREFIX . "slusers WHERE myuid = '" . $username . "' and mypsw = '" . $password . "'";
            $stmt = $oDb->query($sql);
            return $stmt;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /**
     * do actually login user in session and mask password
     * @param User $oUser
     */
    private static function loginUser($oUser) {

        $_SESSION['oCurrentUser'] = $oUser; // set user in session
        $_SESSION['user_date'] = $oUser->mydate;
        $_SESSION['year'] = $oUser->mysession;
        $_SESSION['user_school'] = $oUser->myschool;
    }

    /**
     * Logout user
     * @param string $sRedirect (redirect location)
     */
    public static function logout($sRedirectLocation) {
        //print_r($oCurrentUser);
        //die("<>>>");



        $post = array('date_from' => $_SESSION['user_date'], 'date_to' => $_SESSION['user_date']);




        $dates_between = Employee::update_user_dates($_SESSION['oCurrentUser']->MSID, $_SESSION['oCurrentUser']->user_id, $post);

        //die("<>>");

        ActivityFeed::add_feeds($_SESSION['oCurrentUser']->MSID, $_SESSION['oCurrentUser']->user_id, $_SESSION['oCurrentUser']->myuname, $_SESSION['oCurrentUser']->ulevel, 'Logged Out', '', '', '', '', '');
        unset($_SESSION['oCurrentUser']);
        unset($_SESSION['year']);
        unset($_SESSION['user_date']);
        unset($_SESSION);
        http_redirect($sRedirectLocation); //go to redirect location
    }

    public static function updateUserSession($postyear = NULL) {
        try {
            $oDb = DBConnection::get();
            if ($postyear != NULL) {
                $ulevel = $_SESSION['oCurrentUser']->ulevel;
                $uid = $_SESSION['oCurrentUser']->myuid;
                if ($ulevel == 3 || $ulevel == 9 || $ulevel == 11) {//update user session for employee
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'employee SET my_session = :my_session WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_session' => $postyear,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                    $vmstmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'vmusers SET my_session = :my_session WHERE name = :name and ulevel = :ulevel');
                    $vmstmt->execute(array(
                        ':my_session' => $postyear,
                        ':name' => $_SESSION['oCurrentUser']->myuname,
                        ':ulevel' => $ulevel
                    ));
                }
                if ($ulevel == 1) {//update user session for student
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET my_session = :my_session WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_session' => $postyear,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                }
                if ($ulevel == 2) {//update user session for parents
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'parents SET my_session = :my_session WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_session' => $postyear,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                }
                $_SESSION['year'] = $_SESSION['oCurrentUser']->mysession = $postyear;
            }
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function updateUserDate($postdate = NULL) {
        try {
            $oDb = DBConnection::get();
            if ($postdate != NULL) {
                $ulevel = $_SESSION['oCurrentUser']->ulevel;
                $uid = $_SESSION['oCurrentUser']->myuid;
                if ($ulevel == 3 || $ulevel == 9 || $ulevel == 11) {//update user session for employee
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'employee SET my_date = :my_date WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_date' => $postdate,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                    $vmstmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'vmusers SET my_date = :my_date WHERE name = :name and ulevel = :ulevel');
                    $vmstmt->execute(array(
                        ':my_date' => $postdate,
                        ':name' => $_SESSION['oCurrentUser']->myuname,
                        ':ulevel' => $ulevel
                    ));
                }
                if ($ulevel == 1) {//update user session for student
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET my_date = :my_date WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_date' => $postdate,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                }
                if ($ulevel == 2) {//update user session for parents
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'parents SET my_date = :my_date WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_date' => $postdate,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                }
                $_SESSION['user_date'] = $_SESSION['oCurrentUser']->mydate = $postdate;
            }
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function updateSessionSchool($postschool = NULL) {
        try {
            $oDb = DBConnection::get();
            if ($postschool != NULL) {
                $ulevel = $_SESSION['oCurrentUser']->ulevel;
                $uid = $_SESSION['oCurrentUser']->myuid;
                if ($ulevel == 3 || $ulevel == 9 || $ulevel == 11) {//update user session for employee
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'employee SET my_school = :my_school WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_school' => $postschool,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                    $vmstmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'vmusers SET my_school = :my_school WHERE name = :name and ulevel = :ulevel');
                    $vmstmt->execute(array(
                        ':my_school' => $postschool,
                        ':name' => $_SESSION['oCurrentUser']->myuname,
                        ':ulevel' => $ulevel
                    ));
                }
                if ($ulevel == 1) {//update user session for student
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET my_school = :my_school WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_school' => $postschool,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                }
                if ($ulevel == 2) {//update user session for parents
                    $stmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'parents SET my_school = :my_school WHERE uid = :uid and ulevel = :ulevel');
                    $stmt->execute(array(
                        ':my_school' => $postschool,
                        ':uid' => $uid,
                        ':ulevel' => $ulevel
                    ));
                }
                $_SESSION['user_school'] = $_SESSION['oCurrentUser']->myschool = $postschool;
            }
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function onSessionUpdateDate($postyear = NULL) {
        if ($postyear != NULL) {
            $umsid = $_SESSION['oCurrentUser']->MSID;
            $sessinDate = Master::get_session($umsid, $postyear)->fetch(PDO::FETCH_OBJ);
            self::updateUserDate($sessinDate->begins);
            $_SESSION['oCurrentUser']->begins = $sessinDate->begins;
            $_SESSION['oCurrentUser']->ends = $sessinDate->ends;
        }
    }

    public static function onDateUpdateSession($postdate = NULL) {
        if ($postdate != NULL) {
            $umsid = $_SESSION['oCurrentUser']->MSID;
            $sessionYear = Master::getSchoolSession($umsid, $postdate)->fetch(PDO::FETCH_OBJ);
            self::updateUserSession($sessionYear->session_id);
            $_SESSION['oCurrentUser']->begins = $sessionYear->begins;
            $_SESSION['oCurrentUser']->ends = $sessionYear->ends;
        }
    }

}

?>
