<?php

class Transport {

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_tptstations($msid = NULL, $id = NULL, $status = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_stations";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND station_id=" . $id;
            }
            if ($status != NULL) {
                $sql .= " AND status=" . $status;
            }
            $sql .= " order by station_id ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//                 print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_stu_traninfo($msid = NULL, $id = NULL, $student_id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_stations";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND station_id=" . $id;
            }
            if ($student_id != NULL) {
                $sql .= " AND S_id=" . $student_id;
            }
            $sql .= " order by station_id ASC";


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_stu_tpt($msid = NULL, $dm = NULL, $cno = NULL, $session = Null, $tpt = NULL) {
        try {
            $sql = "SELECT (`A`.student_id) as sid,`A`.name,`A`.birth_date,`A`.sl_date,`A`.house,`A`.sssm_id,`A`.section,P.id,P.f_name,P.m_name,P.village,P.MSID,`A`.adm_classno+'$session'-Year(`A`.fees_date)+COALESCE(B.SumResult,0) AS CClass,T.tpt_stn_id FROM (SELECT * FROM `" . DB_PREFIX . "students` WHERE `MSID`='$msid' AND '$dm' BETWEEN `fees_date` AND `sl_date`) AS A INNER JOIN " . DB_PREFIX . "parents P ON A.parent_id=P.id LEFT JOIN (SELECT MSID,`s_id`,SUM(`result`) AS SumResult FROM `" . DB_PREFIX . "exams` ";
            $sql .= " where MSID=" . $msid;
            $sql .="  AND `date_result` <'" . $dm . "' GROUP BY s_id) AS B ON A.student_id=B.s_id Left JOIN " . DB_PREFIX . "tpt_std T ON A.MSID=T.MSID AND A.student_id=T.S_id AND '$dm' BETWEEN T.date_from AND T.date_to Having P.MSID='$msid'  ";


            if ($cno != NULL) {
                $sql .= "AND CClass='$cno'";
            }
            if ($tpt != "1") {
                $sql .= " AND  T.tpt_stn_id Is Not Null ";
            } else {
                $sql .= " AND  T.tpt_stn_id Is Null ";
            }



            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_trans_edit($msid = NULL, $id = NULL, $student_id = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_std";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            if ($student_id != NULL) {
                $sql .= " AND S_id=" . $student_id;
            }
            $sql .= " order by id ASC";


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_details_tran_stu($msid = NULL, $mydate = NUll) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_std";
            $sql .= " where MSID=" . $msid;

            if ($mydate != NULL) {
                $sql .= " AND date_to >= " . $mydate;
            }



            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_discount_names($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "discount_names";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND discount_id=" . $id;
            }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_transport_list($msid = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_stations";
            $sql .= " where MSID=" . $msid;

            /* if($id != NULL){
              $sql .= " AND discount_id=".$id;
              } */

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /* ========  Get student Transporation data ================= */

    public static function get_transport_stu($msid = NULL, $id = NULL, $mydate = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_std";
            $sql .= " where MSID=" . $msid;

            $sql .= " AND S_id=" . $id;
            if (@$mydate != NULL) {
                $sql .= " AND '" . $mydate . "' BETWEEN date_from AND date_to";
            
            $sql .= " ORDER BY id";}
       //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_stu_trans($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_std";
            $sql .= " where MSID=" . $msid;

            $sql .= " AND S_id=" . $id;

            $sql .= " ORDER BY id";
//       print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function stu_del_discounted_student($msid = NULL, $id = NUll, $date_from = NULL) {
        try {

            $oDb = DBConnection::get();
            $sql = "Delete From `ms_discounted_student` where `id`='$id' AND `MSID`='$msid' ";
            if (@$date_from) {
                $sql .= " AND date_from ='$date_from'";
            }
            $upsql = $oDb->prepare($sql);
//            print_r($upsql);
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function stu_del_trans($msid = NULL, $id = NUll, $date_from = NULL) {
        try {

            $oDb = DBConnection::get();
            $upsql = $oDb->prepare("Delete From `ms_tpt_std` where `id`='$id' AND `MSID`='$msid' AND date_from ='$date_from'");
//            print_r($upsql);
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function stutran_del($msid = null, $id = null) {
        try {

            $oDb = DBConnection::get();
            $upsql = $oDb->prepare("Delete From `ms_tpt_std` where `id`='$id' AND `MSID`='$msid'");
//            print_r($upsql);
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /* ========  Get student Discounted Student data ================= */

    public static function get_discounted_stu($msid = NULL, $id = NULL, $mydate = NULL, $all = "one") {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "discounted_student";
            $sql .= " where MSID=" . $msid;

            $sql .= " AND S_id=" . $id;
            if ($all == "one") {
                $sql .= " AND '" . $mydate . "' BETWEEN date_from AND date_to";
            }
//       $sql .= " ORDER BY id DESC LIMIT 0,1";
//       print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_single_discounted_stu($msid = NULL, $id = NULL, $discount_id = NULL, $mydate = NULL, $all = "one") {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "discounted_student";
            $sql .= " where MSID=" . $msid;

            $sql .= " AND S_id=" . $id;


            $sql .= " AND id =" . $discount_id;


            if ($all == "one") {
                $sql .= " AND '" . $mydate . "' BETWEEN date_from AND date_to";
            }

//       $sql .= " ORDER BY id DESC LIMIT 0,1";
//       print_r($sql); 
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_tptroutes($msid = NULL, $id = NULL, $status = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_routes";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND route_id=" . $id;
            }

            $sql .= " order by route_id ASC";
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_tptfees($msid = NULL, $id = NULL, $status = NULL, $mydate = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_fee";
            $sql .= " where MSID=" . $msid . " And '" . $mydate . "' Between date_from and date_to";


            if ($id != NULL) {
                $sql .= " AND station_id=" . $id;
            }
//            if ($status != NULL) {
//                $sql .= " AND status=" . $status;
//            }
            $sql .= " order by id ASC";
//            print_r($sql);
//            exit();
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function get_std_routes($uid = NULL, $routeId = NULL, $limit = NULL) {
        try {

            if (@$routeId) {
                $sql = " SELECT * ";
            } else {
                $sql = "SELECT Q1.route_id,Q1.route_name,Count(*) as ttlstd ";
            }
            $sql .= " FROM (SELECT SAT.`S_id`,S.`name`,TS.`station_name`,TS.`route_id`,R.`route_name` FROM (SELECT * FROM `ms_slusers`";
            $sql .= " WHERE `myuid`='" . $uid . "')";


            $sql .= " CU INNER JOIN ms_tpt_std SAT ON CU.msid=SAT.msid AND CU.MyDate Between SAT.`date_from` AND SAT.`date_to`INNER JOIN ms_tpt_stations TS ON TS.msid=CU.msid and SAT.tpt_stn_id=TS.station_id INNER JOIN ms_tpt_routes R On R.msid=CU.msid And TS.route_id=R.route_id INNER JOIN ms_students S ON S.msid=CU.msid AND CU.mydate BETWEEN S.Fees_date AND S.sl_date AND S.student_Id=SAT.S_Id)Q1  ";

            if (@$routeId) {
                $sql .= " where Q1.route_id=" . $routeId;
            } else {

                $sql .=" Group By route_name";
            }
            //$sql .= " GROUP BY station.route_id";
            //$sql .= " order by station.id DESC";



            if (!empty($limit)) {
                $sql .= " limit " . $limit;
            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function add_tpt_stations($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['stations'])) == 0)
                $message->add('e', 'TPT Stations Name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_stations SET route_id = :route_id, station_name = :station_name, distance = :distance WHERE station_id = :station_id');
                    $upsql->execute(array(
                        ':route_id' => $postdata['route_id'],
                        ':station_name' => $postdata['stations'],
                        ':distance' => $postdata['distance'],
                        ':station_id' => $id
                    ));
                    $message->add('s', 'TPT Station Field updated successfully!', CLIENT_URL . '/tptstations');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_stations (MSID, route_id, station_name, distance, created_date, status) VALUES  (:MSID, :route_id, :station_name, :distance, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':route_id' => $postdata['route_id'],
                        ':station_name' => $postdata['stations'],
                        ':distance' => $postdata['distance'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'TPT Station added successfully!', CLIENT_URL . '/tptstations');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_tpt_route($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['route_name'])) == 0)
                $message->add('e', 'TPT Route Name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_routes SET route_name = :route_name WHERE route_id = :route_id');
                    $upsql->execute(array(
                        ':route_name' => $postdata['route_name'],
                        ':route_id' => $id
                    ));
                    $message->add('s', 'TPT Route updated successfully!', CLIENT_URL . '/tptroutes');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_routes (MSID, route_name, created_date, status) VALUES  (:MSID, :route_name, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':route_name' => $postdata['route_name'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'TPT Route added successfully!', CLIENT_URL . '/tptroutes');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_tpt_fees($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            // Insert into database //
            if (strlen(trim(@$postdata['fee'])) == 0)
                $message->add('e', 'TPT Fee is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_fee SET station_id = :station_id, date_from = :date_from, date_to = :date_to , fee = :fee WHERE id = :id');
                    $upsql->execute(array(
                        ':station_id' => $postdata['station_id'],
                        ':date_from' => $postdata['date_from'],
                        ':date_to' => $postdata['date_to'],
                        ':fee' => $postdata['fee'],
                        ':id' => $id
                    ));
                    $message->add('s', 'TPT Fee Fields updated successfully!', CLIENT_URL . '/tptfee');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_fee (MSID, station_id, date_from, date_to, fee, created_date, status) VALUES  (:MSID, :station_id, :date_from, :date_to, :fee, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':station_id' => $postdata['station_id'],
                        ':date_from' => $postdata['date_from'],
                        ':date_to' => $postdata['date_to'],
                        ':fee' => $postdata['fee'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'TPT Fee added successfully!', CLIENT_URL . '/tptfee');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function update_student_tpt($msid, $student_id, $station, $from_date, $to_date) {
        try {
            $message = new Messages();
            $oDb = DBConnection::get();

            $tpt_result = self::get_transport_stu($msid, $student_id );
//            print_r($tpt_result); die();
            $result= $tpt_result->rowCount();
            if($result == 0)
            {
                $sql = "INSERT INTO ms_tpt_std (MSID, date_from, date_to, S_id, tpt_stn_id) VALUES('".$msid."', '".$from_date."', '".$to_date."', '".$student_id."', '".$station."')";
                $query = $oDb->query($sql);
                 
            }else{ 
               
                 $sql = "UPDATE ms_tpt_std SET date_from = '".$from_date."', date_to = '".$to_date."',  tpt_stn_id = '".$station."' WHERE MSID = '".$msid."' AND S_id = '".$student_id."'";
                
//                print_r($sql);echo "<br>";
                $query = $oDb->query($sql);
                
            }
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

}

?>
