<?php

class Attendance
    {

    public static function get_exam_attendance($msid = NULL, $id = NULL, $term = NULL, $tw_days = NULL, $s_id = NULL, $session = NULL, $class = NULL, $section = NULL, $distinct = "False", $data = array('selectAll' => 'true'))
        {
        try
            {
            if ($distinct == "True")
                {
                $sql = "SELECT distinct class, section   FROM " . DB_PREFIX . "attendance_term";
                }
            else
                {
                $sql = "SELECT *  FROM " . DB_PREFIX . "attendance_term";
                }
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }
            if ($s_id != NULL)
                {
                $sql .= " AND s_id=" . $s_id;
                }
            if ($term != NULL)
                {
                $sql .= " AND term=" . $term;
                }
            if ($session != NULL)
                {
                $sql .= " AND session=" . $session;
                } if ($class != NULL)
                {
                $sql .= " AND class=" . $class;
                }
            if ($section != NULL)
                {
                $sql .= " AND section='" . $section . "'";
                }
            if ($tw_days != NULL)
                {
                $sql .= " AND tw_days=" . $tw_days;
                }

            $sql .= " order by id ASC";
//            pr($sql);
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
//            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function count_emp_attendacnce($uid = NULL, $section = NULL, $attendance = NULL)
        {
        try
            {
            $sql = " SELECT A.`SId`,E.*, A.`Att`,A.`Reason` FROM (SELECT * FROM `ms_slusers` WHERE MyUId='$uid') CU Inner JOIN ms_attendances A ON A.msid=CU.msid And A.`AttDate` = CU.MyDate Inner JOIN ms_employee E ON E.msid=CU.msid And CU.MyDate Between E.hire_date And  E.retire_date  And E.`employee_id` = A.SID WHERE 1 ";
            if ($section != NULL)
                {
                $sql .= " AND A.`section`='$section'";
                }
            if ($attendance != NUll)
                {
                $sql .= " AND Att='$attendance'";
                }
//            // print_r($sql); 
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (Exception $ex)
            {
            echo $ex->getMessage();
            }
        }

    public static function get_emp_attendance_details($msid = NULL, $session = NULL, $my_date = NULL, $section = Null, $ids = NULL)
        {
        try
            {

            $sql = "select A.* from ( SELECT E.* FROM ms_employee E  WHERE E.MSID='$msid' And '$my_date' Between E.hire_date And  E.retire_date  ";
            if ($section != NULL)
                {
                $sql .= " And E.emp_category='$section' ";
                } $sql .= ") A ";

            if ($ids != NULL)
                {
                $sql .= " Where  A.`employee_id` NOT IN ($ids)";
                }
            $sql .=" ORDER BY `A`.`employee_id` ASC ";
//            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (Exception $ex)
            {
            echo $ex->getMessage();
            }
        }

    public static function get_attendance_emp($msid = NULL, $attendance_date = NULL, $section = NULL)
        {
        try
            {

            $sql = "SELECT section,Count(IF(Att = 'P', 1, NULL)) AS Present, Count(IF(Att = 'A', 1, NULL)) AS Absent, Count(IF(Att = 'L', 1, NULL)) AS L from `ms_attendances` where  AttDate='$attendance_date' and  MSID='$msid'";

            if ($section != '')
                {
                $sql .= " AND section= '$section'";
                }

            //print_r($sql); 

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (Exception $ex)
            {
            echo $ex->getMessage();
            }
        }

    public static function get_employee_attend($msid = NULL, $session = NULL, $my_date = NULL)
        {
        try
            { 
            $sql = "SELECT S.student_id,count(S.student_id) as total,S.*,P.*,L.id, S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0)
AS CClass FROM ms_students S INNER JOIN ms_parents P ON S.parent_id=P.id  And S.MSID=P.MSID INNER Join 
ms_locality L ON P.village=L.id  And P.MSID=L.MSID LEFT JOIN (SELECT E.s_id, Sum(E.result) 
AS SumResult FROM ms_exams E WHERE (((E.MSID)='$msid') AND ((E.date_result) < '$my_date' )) GROUP BY E.s_id )
AS Q1 ON S.student_id = Q1.s_id WHERE S.MSID='$msid' And
 S.fees_date <='$my_date' AND S.sl_date >'$my_date' And 
 P.MSID='$msid' GROUP BY S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0)";

//		 // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (Exception $ex)
            {
            echo $ex->getMessage();
            }
        }

    public static function add_exam_attendance($id = NULL, $postdata = array())
        {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {


//            echo '<pre>';
//            print_r($postdata);
//            exit();
            //********* Insert into database *********//
            if (!$message->hasMessages())
                {
                $i = 0;
                foreach ($postdata['id'] as $data => $val)
                    {
                    $students_existing_attendance = Attendance::get_exam_attendance($_POST['MSID'], '', $_POST['term'], '', $data, $_POST['session'], $_POST['class_id'], $_POST['section']);
                    $totalrecords_students = $students_existing_attendance->rowCount();

                    if ($totalrecords_students > 0)
                        {
                        $existing_attendance = $students_existing_attendance->fetch(PDO::FETCH_ASSOC);
                        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_acedemic_performance SET marks_obtained= :marks_obtained WHERE id = :id');
                        $upsql->execute(array(
                            ':marks_obtained' => $_POST['attended_days'][$i],
                            ':id' => $existing_attendance['id'],
                        ));
                        }
                    else
                        {
//                    print_r($_POST);
//                    exit();
                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'attendance_term (MSID,session,s_id,term,tw_days,ta_days,class,section) VALUES  (:MSID,:session,:s_id,:term,:tw_days,:ta_days,:class,:section)');
                        $sql->execute(array(
                            ':MSID' => $_POST['MSID'],
                            ':session' => $_POST['session'],
                            ':s_id' => $data,
                            ':term' => $_POST['term'],
                            ':tw_days' => $_POST['tw_days'],
                            ':class' => $_POST['class_id'],
                            ':section' => $_POST['section'],
                            ':ta_days' => $_POST['attended_days'][$i]
                        ));
                        } $i++;
                    }
                } $message->add('s', 'Term Attendance added successfully!', CLIENT_URL . '/term-attendances');
            exit();
//            }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_attendance($msid = NULL, $id = NULL, $data = array())
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND SId=" . $id;
                }
            if (!empty($data))
                {
                foreach ($data as $key => $val)
                    {
                    $sql .= " AND " . $key . "=" . $val;
                    }
                }
            $sql .= " order by id ASC";
//            pr($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_attendances($msid = NULL, $id = NULL, $data = array(), $att = NULL)
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND SId=" . $id;
                }
            if (!empty($data))
                {
                foreach ($data as $key => $val)
                    {
                    $sql .= " AND " . $key . "=" . $val;
                    }
                }
            if (!empty($att))
                {
                $sql .= " OR Att IN($att)";
                }
            $sql .= " order by AttDate ASC";
//            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_holidays($msid = NULL, $id = NULL)
        {
        try
            {

            $sql = "SELECT * FROM " . DB_PREFIX . "holidays";
            $sql .= " where MSID=" . $msid;

            if (@$id != '')
                {

                $sql .= " AND holiday_id=" . $id;
                }


            $sql .= " order by ID ASC";
//            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_holidays_max($msid = NULL)
        {
        try
            {

            $sql = "SELECT MAX(ID) as h_id FROM " . DB_PREFIX . "holidays";
            $sql .= " where MSID=" . $msid;



            $sql .= " order by ID ASC";

            // print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function count_holidays($mydate = NULL)
        {

        try
            {

            $sql = "SELECT if(`weak_day`='Sun','Sunday',if(`weak_day`='Sat' And Day(date_id) Between 8 And 14,'2nd Saturday','')) AS SS from ms_dates where date_id='$mydate'";

            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        public static function count_SS_holidays($msid = NULL, $SS=NULL )
        {

        try
            {

            $sql = "SELECT if(`weak_day`='Sun','Sunday',if(`weak_day`='Sat' And Day(date_id) Between 8 And 14,'2nd Saturday','')) AS SS from ms_dates where date_id='$mydate'";

            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function special_holidays($msid = NULL, $mydate = NULL)
        {
        try
            {

            $sql = "SELECT * from ms_holidays where '$mydate' between `DateFrom` And  `DateTo` And MSID='$msid'";

            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        
        public static function get_months_working_days($uid = NULL, $mydate = NULL)
        {
        try
            {

            $sql = "Select Count(date_id) NOWDays,`holiday_id`,`Particular` From ms_dates D Inner Join (SELECT MSID,`mydate`,`mysession`,`begins`,`ends` FROM `ms_slusers` WHERE `myuid`='".$uid."') CU On D.date_id Between CU.begins And CU.mydate Left Join ms_fixed_holidays FH On (FH.MSID=CU.MSID Or FH.MSID=0) And WeekDay(date_id) Between WDFrom And WDTO And Day(date_id) Between DayFrom And DayTo Left Join ms_holidays H On H.MSID=CU.MSID And date_id Between H.DateFrom And H.DateTo Where HName IS NULL And Particular IS NULL  And Month(date_id)=Month(CU.mydate)";

            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        
        public static function get_total_working_days($uid = NULL, $mydate = NULL)
        {
        try
            {

            $sql = "Select Count(date_id) NOWDays,`holiday_id`,`Particular` From ms_dates D Inner Join (SELECT MSID,`mydate`,`mysession`,`begins`,`ends` FROM `ms_slusers` WHERE `myuid`='".$uid."') CU On D.date_id Between CU.begins And CU.mydate Left Join ms_fixed_holidays FH On (FH.MSID=CU.MSID Or FH.MSID=0) And WeekDay(date_id) Between WDFrom And WDTO And Day(date_id) Between DayFrom And DayTo Left Join ms_holidays H On H.MSID=CU.MSID And date_id Between H.DateFrom And H.DateTo Where HName IS NULL And Particular IS NULL  And Month(date_id)<Month(CU.mydate)";

            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        public static function count_student_att_month($msid = NULL, $sid = NULL, $mydate= NULL )
        {
        try
            {

            $sql = "SELECT count(SId) total FROM `ms_attendances` WHERE `MSID`='".$msid."' And `SId`='".$sid."' and Month(`AttDate`)=Month('".$mydate."')";

            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        public static function student_total_att_month($msid = NULL, $sid = NULL, $mydate= NULL )
        {
        try
            {

            $sql = "SELECT count(SId) total FROM `ms_attendances` WHERE `MSID`='".$msid."' And `SId`='".$sid."' and Month(`AttDate`) < Month('".$mydate."')";

            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }


    }

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

