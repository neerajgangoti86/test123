<?php
class Paginator {
 
        private $_conn;
        private $_limit;
        private $_page;
        private $_query;
        private $_total;
		private $_url;
		
 public function __construct( $totalrecords ,$limit, $page, $url) {
    $this->_limit   = $limit;
    $this->_page    = $page;
    $this->_total = $totalrecords;
	$this->_url   = CLIENT_URL.'/'.$url;
     
  }
  
public function createLinks( $links, $list_class ) {
    if ( $this->_limit == 'all' ) {
        return '';
    }
 
    $last       = ceil( $this->_total / $this->_limit );
 
    $start      = ( ( $this->_page - $links ) > 0 ) ? $this->_page - $links : 1;
    $end        = ( ( $this->_page + $links ) < $last ) ? $this->_page + $links : $last;
    
	$html       = '<div class="row">
            <div class="col-xs-6">
              <div class="dataTables_info" id="example2_info">';
	
	$recordArray = array('5','10','25','50','100','500');
	
	$html       .='<div class="pull-left">Show rows:&nbsp;</div>';
	
	$html       .= '<form name="paging_per_page" method="post" action="'.$this->_url.'" class="pull-left" style="padding-right:24px;">
                 <select name="r_per_page" onchange="this.form.submit()">';
				 foreach($recordArray as $val){
				 $html .= '<option value="'.$val.'" '.($this->_limit==$val?'selected="selected"': '').'>'.$val.'</option>';
				 }
	$html       .='</select></form>';
			  
    $html    .= ' '.(($this->_page-1) * $this->_limit+1).'&nbsp;-&nbsp;'.($this->_total - $this->_page * $this->_limit > 0 ? $this->_page * $this->_limit : $this->_total).'&nbsp;of&nbsp;'.$this->_total.' entries</div>
            </div>
            <div class="col-xs-6">
              <div class="dataTables_paginate paging_bootstrap">';
	if($end > 1){
    $html       .= '<ul class="' . $list_class . '">';
	
    $class      = ( $this->_page == 1 ) ? "disabled" : "";
    $html       .= '<li class="' . $class . '"><a href="'.(( $this->_page == 1 ) ?"javascript:;": $this->_url .'/page/' . ( $this->_page - 1 )) . '">&laquo;</a></li>';
 
    if ( $start > 1 ) {
        $html   .= '<li><a href="'.$this->_url .'/page/1">1</a></li>';
        $html   .= '<li class="disabled"><span>...</span></li>';
    }
 
    for ( $i = $start ; $i <= $end; $i++ ) {
        $class  = ( $this->_page == $i ) ? "active" : "";
        $html   .= '<li class="' . $class . '"><a href="'. $this->_url .'/page/' . $i . '">' . $i . '</a></li>';
    }
 
    if ( $end < $last ) {
        $html   .= '<li class="disabled"><span>...</span></li>';
        $html   .= '<li><a href="'. $this->_url .'/page/' . $last . '">' . $last . '</a></li>';
    }
 
    $class      = ( $this->_page == $last ) ? "disabled" : "";
    $html       .= '<li class="' . $class . '"><a href="'.(( $this->_page == $last ) ?"javascript:;": $this->_url .'/page/' . ( $this->_page + 1 )) . '">&raquo;</a></li>';
 
    $html       .= '</ul>';
	}
	$html       .= '</div>
            </div>
          </div>';
    
    return $html;
}
 
}
?>