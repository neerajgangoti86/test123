<?php
class ActivityFeed {

    /**
     * get enrolled student list for admission tab(module)
     * @param string $msid
     * @param string $limit
     * @param string rejected
     */

    public static function add_feeds($msid = NULL, $initiator_id = NULL, $initiator_name = NULL, $initiator_type = NULL, $activity_type = NULL, $goal_id = NULL, $goal_name = NULL, $field_name = NULL, $initial_field_value = NULL, $new_field_value = NULL) {
       
//        print_r($msid ." ". $initiator_id ." ".$initiator_name ." ".$initiator_type ." ".$activity_type." ".$goal_id ." ".$goal_name." ".$field_name." ".$initial_field_value ." ".$new_field_value ." ".$ip_address);
//        exit();
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
//********* Insert into database *********//
            if (strlen(trim($initiator_name)) == 0)
                $message->add('e', 'User Name is required..!!');

            if (!$message->hasMessages()) {
//insert into database
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'activity_feed (MSID, initiator_id, initiator_name,initiator_type, activity_type, goal_id ,goal_name ,field_name,initial_field_value,new_field_value,ip_address,activity_time, status) VALUES  (:MSID, :initiator_id, :initiator_name, :initiator_type, :activity_type,  :goal_id , :goal_name , :field_name, :initial_field_value, :new_field_value, :ip_address, :activity_time, :status)');

                $sql->execute(array(
                    ':MSID' => $msid,
                    ':initiator_id' =>$initiator_id,
                    ':initiator_name' => $initiator_name,
                    ':initiator_type' => $initiator_type,
                    ':activity_type' => $activity_type,
                    ':goal_id' => $goal_id,
                    ':goal_name' =>$goal_name,
                    ':field_name' => $field_name,
                    ':initial_field_value' => $initial_field_value,
                    ':new_field_value' => $new_field_value,
                    ':ip_address' => $_SERVER['REMOTE_ADDR'],
                    ':activity_time' => date('Y-m-d H:i:s'),
                    ':status' => '1'
                ));
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }
public static function get_activity_feeds($msid = NULL, $limit = NULL, $whr = array()){
	 $sql="SELECT * FROM ".DB_PREFIX."activity_feed";
	 $sql .= " where MSID=".$msid;
     if(!empty($whr)){
	  foreach($whr as $key=>$value){
	   $sql .= " AND ".$key."=".$value;
	  }
	 }
	 $sql .= " order by id DESC";
     
	 if($limit !=NULL){
	  $sql .= " LIMIT ".$limit;
	 }
	 $oDb = DBConnection::get();
	 $sql = $oDb->query($sql);
//         print_r($sql);
	 return $sql;
}

}

?>
