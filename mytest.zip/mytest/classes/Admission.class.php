<?php

class Admission {

    /**
     * get enrolled student list for admission tab(module)
     * @param string $msid
     * @param string $limit
     * @param string rejected
     */
    public function get_last_std($msid = NULL) {
        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "students as student ";

            $sql .= " WHERE student.MSID= '" . $msid . "'";
            $sql .= " order by student.student_id DESC";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /* public function get_last_std2($msid = NULL) {
      try {

      $sql = "SELECT * FROM " . DB_PREFIX . "students_enrole";

      $sql .= " WHERE MSID= '" . $msid . "'";
      $sql .= " order by student_id DESC";

      //            print_r($sql);
      $oDb = DBConnection::get();
      $sql = $oDb->query($sql);
      return $sql;
      } catch (PDOException $e) {
      $message = new Messages();
      $message->add('e', $e->getMessage());
      }
      } */

    //public static function get_class
    // Get Last ID GET 



    public function get_lastid_stu_transport($msid = NULL) {

        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "tpt_std ";

            $sql .= " WHERE MSID= '" . $msid . "'";
            //$sql .= " order by student.student_id DESC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function get_last_student($msid = null) {
        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "students as student ";

            $sql .= " WHERE student.MSID= '" . $msid . "'";
            $sql .= " order by student.id DESC";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_last_student2($msid = null, $id = NULL) {
        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "students_enrole WHERE 1 ";

            $sql .= " AND MSID=" . $msid;

            if (@$id) {
                $sql .= " AND id= " . $id;
            }

            $sql .= " order by id DESC";
            
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function get_enrolled_std($msid = NULL, $limit = 'all', $rejected = NULL, $type = NULL, $group = NULL, $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            if (!empty($group)) {
                if ($group == 'class') {
                    $sql = "SELECT student.adm_classno FROM " . DB_PREFIX . "students as student";
                } else {
                    $sql = "SELECT * FROM " . DB_PREFIX . "students as student";
                }
            } else {
                $sql = "SELECT * FROM " . DB_PREFIX . "students as student";
            }
            $sql .= " LEFT JOIN " . DB_PREFIX . "parents as parent ON parent.id = student.parent_id";
            if (!empty($rejected)) {
                $sql .= " WHERE student.MSID=" . $msid ;
            } else {
                if (!empty($type)) {
                    $sql .= " WHERE student.MSID=" . $msid;
                } else {
                    //$sql .= " WHERE student.MSID=".$msid." AND (student.admno = '' OR student.admno IS NULL) AND (student.status ='0' OR student.status IS NULL)";
//                    $sql .= " WHERE student.MSID=" . $msid . " AND (student.status ='0' OR student.status IS NULL)";
                }
            }
//            if (@$_SESSION['year']) {
//                $sql .= " AND " . $_SESSION['year'] . "= YEAR(student.adm_date)";
//            }
            if (!empty($group)) {
                if ($group == 'class') {
                    $sql .= " GROUP BY student.adm_classno";
                } else {
                    $sql .= " AND student.adm_classno = " . $group;
                }
            }
            $sql .= " order by student.id DESC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function get_enrolled_std2($msid = NULL, $limit = 'all', $rejected = NULL, $type = NULL, $group = NULL, $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            if (!empty($group)) {
                if ($group == 'class') {
                    $sql = "SELECT student.adm_classno FROM " . DB_PREFIX . "students_enrole as student";
                } else {
                    $sql = "SELECT * FROM " . DB_PREFIX . "students_enrole as student";
                }
            } else {
                $sql = "SELECT * FROM " . DB_PREFIX . "students_enrole as student";
            }
            $sql .= " LEFT JOIN " . DB_PREFIX . "parents as parent ON parent.id = student.parent_id";
            if (!empty($rejected)) {
                $sql .= " WHERE student.MSID=" . $msid ;
            } else {
                if (!empty($type)) {
                    $sql .= " WHERE student.MSID=" . $msid;
                } else {
                    //$sql .= " WHERE student.MSID=".$msid." AND (student.admno = '' OR student.admno IS NULL) AND (student.status ='0' OR student.status IS NULL)";
                    $sql .= " WHERE student.MSID=" . $msid ;
                }
            }
//            if (@$_SESSION['year']) {
//                $sql .= " AND " . $_SESSION['year'] . "= YEAR(student.adm_date)";
//            }
            if (!empty($group)) {
                if ($group == 'class') {
                    $sql .= " GROUP BY student.adm_classno";
                } else {
                    $sql .= " AND student.adm_classno = " . $group;
                }
            }
            $sql .= " order by student.id DESC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /**
     * this function used for rejecting enrolled student in admission tab(module)
     * @param string $msid
     * @param string $studentID
     */
    public function reject_enroll_std($msid = NULL, $studentID = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {

            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET status = :status WHERE student_id = :student_id AND MSID = :MSID');
            $status = $sql->execute(array(
                ':status' => '2',
                ':MSID' => $msid,
                ':student_id' => $studentID
            ));
            if ($status) {
                $message->add('s', 'Enrollment form rejected successfully!', CLIENT_URL . '/admissions');
                exit();
            } else {
                $message->add('e', 'Error! internal error.Please try again.', CLIENT_URL . '/admissions');
                exit();
            }
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function get_student_data($msid = NULL, $id = NULL) {

        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "students_enrole";

            $sql .= " WHERE MSID= " . $msid;
            $sql .= " AND id= " . $id;

// print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /**
     * New admission 
     * */
    public function enrollment($msid = NULL, $parentdata = NULL, $studentdata = NULL, $data = NULL, $file = NULL) {


//          echo "<pre>";
//          print_r($_POST['student']);
//          echo "</pre>";
//          die("<>>>p");

        /* print_r($_POST);
          die("<><<<<"); */



        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            if (@$data['step_1'] && $data['step_1'] == "1") {

                $get_student = $this->get_last_std($msid);
                $get_student_cnt = $get_student->rowCount();


//echo $student_id = $rowv['student_id'];
                //die("<>><");
                /* if ($get_student_cnt > 0) {
                  $rowv = $get_student->fetch();

                  $student_id = $rowv['student_id'] + 1;
                  } else {
                  $student_id = '15001';
                  } */

                /* if (@$data['adm_no1']) {
                  $adm_no = $student_id;
                  } else {
                  $adm_no = $studentdata['adm_no'];
                  } */
                if (!empty($file['photo']['name'])) {

                    @$photo_name = "/".$msid."/".time() . "_" . $file['photo']['name'];
                    $upload_image = "uploads/".$msid."/". basename(@$photo_name);
                    $upload_img = move_uploaded_file($file['photo']['tmp_name'], $upload_image);
                } else {
                    $upload_img = '';
                }

                if (!isset($studentdata['email'])) {
                    $studentdata['email'] = '';
                }
                if (empty($file['photo']['name'])) {
                    @$photo_name = '';
                }


                //print_r($studentdata['stu_no']);

                $birth_date = date("Y-m-d H:i:s", strtotime($studentdata['dob']));

                $fee_date = date("Y-m-d H:i:s", strtotime($studentdata['feesdate1']));

                $adm_date = date("Y-m-d H:i:s", strtotime($studentdata['adm_date']));

                //$student_id =  $data['student_id'];
                // die("<><");

                $section = (@$studentdata['section'] > 0) ? $studentdata['section'] : '';
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'students_enrole (MSID, adm_classno,section, house, admno, roll_no, birth_certificate, name,email, fees_date, transportation,discount, wardofstaff, gender, adm_date, group_id, birth_date, blood_group,photo,  created_date , aadhar, my_session , my_date , ulevel ,step,hostel,status) VALUES (:MSID, :adm_classno,:section, :house, :admno, :roll_no,  :birth_certificate,  :name, :email, :fees_date, :transportation, :discount, :wardofstaff,  :gender,  :adm_date,  :group_id, :birth_date,  :blood_group, :photo, :created_date, :aadhar, :my_session , :my_date , :ulevel , :step, :hostel, :status)');

                
                
               if(@$studentdata['transport'] == '1')
               {
                 @$transport = @$studentdata['tpt'];
               }
               else
               {
                 @$transport = '0';
               }
               
               if(@$studentdata['discount'] == '1')
               {
                  @$discount = @$studentdata['disc'];
               }
               else
               {
                  @$discount = '0';
               }
               
              
               if(isset($studentdata['stu_id']))
               {
                  
                   $_SESSION['STUDENT_ID'] = $studentdata['stu_id'];
                  
                   
               }
               else
               {
                  $_SESSION['STUDENT_ID'] = '0';
               }

                $sql->execute(array(
                    ':MSID' => $msid,
//                    ':student_id' => $stu_no,
                    ':adm_classno' => $studentdata['aclass'],
                    ':section' => $section,
                    ':house' => $studentdata['house'],
                    ':admno' => '0',
                    ':roll_no' => '0',
                    ':birth_certificate' => $studentdata['birthc'],
                    ':name' => $studentdata['name'],
                    ':email' => $studentdata['email'],
                    ':fees_date' => $fee_date,
                    ':transportation' => @$transport,
                    ':discount' => @$discount,
                    ':wardofstaff' => $studentdata['wos'],
                    ':gender' => $studentdata['Gender'],
                    ':adm_date' => $adm_date,
                    ':group_id' => $studentdata['groupid'],
                    ':birth_date' => $birth_date,
                    ':blood_group' => $studentdata['bgroup'],
                    ':photo' => @$photo_name,
                    ':created_date' => date('Y-m-d H:i:s'),
                    ':aadhar' => $studentdata['aadhar'],
                    ':my_session' => $data['session'],
                    ':my_date' => date('Y-m-d H:i:s'),
                    ':ulevel' => '1',
                    ':step' => $data['step_1'],
                    ':hostel' => $studentdata['hostel'],
                    ':status' => '-1'
                ));
                $stu_id = $oDb->lastInsertId();

                $_SESSION['S_ID'] = $stu_id;

                $s_id = $_SESSION['S_ID'];







                header("Location:  " . CLIENT_URL . '/enrollment/' . $s_id);
            } elseif (@$data['step_2'] && $data['step_2'] == "2") {
                if (@$parentdata['parentID']) {
                    $parent_id = $parentdata['parentID'];
                    //$parentdata['sep_fees_book_box'];
//                    if (@$parentdata['sep_fees_book_box'] != '') {
//                        @$accno = @$parentdata['sep_fees_book_box'];
//                        
//                    }
//
                    $parent_new = 0;
                    //die("<><<");
                } else {

                    //echo $parent_id = $parentdata['parentID'];
                    //die("<><<");
//                    print_r($parentdata);

                    if (!@$parentdata['al_income']) {
                        $parentdata['al_income'] = '0';
                    }
//                    //die("<>>");

                    $parent_new = 1;



                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'parents (MSID,f_name, f_occupation, f_qualification, f_mobile, m_name,m_occupation,m_qualification,m_mobile, phone_home, mobile_sms, category, address_line1, address, village, annual_income, religion, created_date,status) VALUES  (:MSID, :f_name, :f_occupation, :f_qualification, :f_mobile, :m_name, :m_occupation, :m_qualification, :m_mobile, :phone_home, :mobile_sms, :category, :address_line1, :address, :village, :annual_income, :religion, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $msid,
                        ':f_name' => $parentdata['fname'],
                        ':f_occupation' => $parentdata['f_occupation'],
                        ':f_qualification' => $parentdata['f_qualification'],
                        ':f_mobile' => $parentdata['fmob'],
                        ':m_name' => $parentdata['mname'],
                        ':m_occupation' => $parentdata['m_occupation'],
                        ':m_qualification' => $parentdata['m_qualification'],
                        ':m_mobile' => $parentdata['mmob'],
                        ':phone_home' => $parentdata['landline'],
                        ':mobile_sms' => $parentdata['mobsms'],
                        ':category' => $parentdata['category'],
                        ':address_line1' => $parentdata['addline1'],
//                        ':address_line2' => $parentdata['addline2'],
                        ':address' => $parentdata['padd'],
                        ':village' => $parentdata['locality'],
                        ':annual_income' => $parentdata['al_income'],
                        ':religion' => $parentdata['religion'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '0'
                    ));
                    $parent_id = $oDb->lastInsertId();
//                  
                }
                $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students_enrole SET step = :step,parent_id = :parent_id,p_new=:p_new WHERE id = :id ');
                $status = $sql->execute(array(
                    ':step' => $data['step_2'],
                    ':parent_id' => $parent_id,
                    ':p_new' => $parent_new,
                    ':id' => $data['s_id']
                ));
                header("Location:  " . CLIENT_URL . '/enrollment/' . $data['s_id']);
            } elseif (@$data['step_3'] && $data['step_3'] == "3") {

                if (!empty($file['birth_cirtificate']['name'])) {


                    @$file_name_birth = time() . "_" . $file['birth_cirtificate']['name'];

                    $upload_image_1 = "uploads/student_docx/" . basename(@$file_name_birth);
                    $upload_img_1 = move_uploaded_file($file['birth_cirtificate']['tmp_name'], $upload_image_1);
                } else {
                    $upload_img_1 = '';
                }

                if (!empty($file['character_cirtificate']['name'])) {

                    @$file_name_character = time() . "_" . $file['character_cirtificate']['name'];
                    $upload_image_2 = "uploads/student_docx/" . basename(@$file_name_character);
                    $upload_img_2 = move_uploaded_file($file['character_cirtificate']['tmp_name'], $upload_image_2);
                } else {
                    $upload_img_2 = '';
                } if (!empty($file['other_cirtificate']['name'])) {

                    @$file_name_other = time() . "_" . $file['other_cirtificate']['name'];
                    $upload_image_3 = "uploads/student_docx/" . basename(@$file_name_other);
                    $upload_img_3 = move_uploaded_file($file['other_cirtificate']['tmp_name'], $upload_image_3);
                } else {
                    $upload_img_3 = '';
                }

                if (!empty($file['adhaar_cirtificate']['name'])) {

                    @$file_name_aadar = time() . "_" . $file['adhaar_cirtificate']['name'];
                    $upload_image_4 = "uploads/student_docx/" . basename(@$file_name_aadar);
                    $upload_img_4 = move_uploaded_file($file['adhaar_cirtificate']['tmp_name'], $upload_image_4);
                } else {
                    $upload_img_4 = '';
                }

                if (!empty($file['report_cirtificate']['name'])) {

                    @$file_name_report_certificate = time() . "_" . $file['adhaar_cirtificate']['name'];

                    $upload_image_5 = "uploads/student_docx/" . basename(@$file_name_report_certificate);
                    $upload_img_5 = move_uploaded_file($file['report_cirtificate']['tmp_name'], $upload_image_5);
                } else {
                    $upload_img_5 = '';
                }



                if (!empty($file['schooleaving_cirtificate']['name'])) {

                    @$file_name_schoo_leave = time() . "_" . $file['schooleaving_cirtificate']['name'];
                    $upload_image_6 = "uploads/student_docx/" . basename(@$file_name_schoo_leave);
                    $upload_img_6 = move_uploaded_file($file['schooleaving_cirtificate']['tmp_name'], $upload_image_6);
                } else {
                    $upload_img_6 = '';
                }

                if (empty($file['birth_cirtificate']['name'])) {
                    @$file_name_birth = '';
                }
                if (empty($file['character_cirtificate']['name'])) {
                    $file_name_character = '';
                }

                if (empty($file['other_cirtificate']['name'])) {
                    @$file_name_other = '';
                }


                if (empty($file['adhaar_cirtificate']['name'])) {
                    @$file_name_aadar = '';
                }


                if (empty($file['report_cirtificate']['name'])) {
                    @$file_name_report_certificate = '';
                }

                if (empty($file['schooleaving_cirtificate']['name'])) {
                    @$file_name_schoo_leave = '';
                }




//
//                print_r($_POST);
//                exit();

                if ($_SESSION['STUDENT_ID'] == '0') 
                {
                    
                    $get_student =  self::get_enrolled_std($data['msid']);
                    $get_student_cnt = $get_student->rowCount();
                    if ($get_student_cnt > 0) {
                        $rowv = $get_student->fetch();
//                        print_r($rowv);
//                        exit();
                        $student_id = $rowv['student_id'] + 1;
                    } else {
                        $student_id = $data['start'];
                    }
                } else {
                    $student_id = $_SESSION['STUDENT_ID'];
                }
                
                if(@$data['select_fee'] && @$data['select_fee'] != '0')
                {
                    $account_no = @$data['select_fee'];
                }
                
                else
                {
                  $account_no = $student_id;
                
                }

//                print_r($account_no);
//                print_r($account_no);
//                die("<>><<");
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'students_docx (MSID,s_id,birth,ch,other,aadhar,report_cirtificate,school_leaving) VALUES  (:MSID,:s_id,:birth,:ch,:other,:aadhar,:report_cirtificate,:school_leaving)');

                $sql->execute(array(
                    ':MSID' => $msid,
                    ':s_id' => $student_id,
                    ':birth' => @$file_name_birth,
                    ':ch' => @$file_name_character,
                    ':other' => @$file_name_other,
                    ':aadhar' => @$file_name_aadar,
                    ':report_cirtificate' => @$file_name_report_certificate,
                    ':school_leaving' => @$file_name_schoo_leave
                ));
                $docx_id = $oDb->lastInsertId();

                $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students_enrole SET acno = :acno,step = :step,docx_id = :docx_id,status=:status WHERE id = :id ');
                $status = $sql->execute(array(
                    ':step' => $data['step_3'],
                    ':docx_id' => $docx_id,
                    ':acno' => $account_no,
                    ':status' => '1',
                    ':id' => $data['s_id'],
                ));
                if (@$data['parent_new']) {

                    $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'parents SET status = :status ,my_session = :my_session, my_date = :my_date, uid= :uid,ulevel = :ulevel, password= :password  WHERE id = :id ');
                    $status = $sql->execute(array(
                        ':status' => $data['status'],
                        ':my_session' => $data['mysession'],
                        ':my_date' => $data['mydate'],
                        ':uid' => $msid . "P" . $student_id,
                        ':ulevel' => '3',
                        ':password' => $msid . "P" . $student_id,
                        ':id' => $data['parent_id'],
                    ));




//                  
                }
                //echo $student_id;
                $stu_data_get1 = $this->get_student_data($msid, $_SESSION['S_ID']);

                $stu_data_get = $stu_data_get1->fetch();

                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'students (MSID, acno, student_id, parent_id, adm_classno,section, house, admno, roll_no, birth_certificate, name,email, fees_date, wardofstaff, gender, adm_date, group_id, birth_date, blood_group,photo,  created_date , aadhar, my_session , my_date , uid , ulevel , password,step,docx_id) VALUES (:MSID, :acno, :student_id, :parent_id, :adm_classno,:section, :house, :admno, :roll_no,  :birth_certificate,  :name, :email, :fees_date , :wardofstaff,  :gender,  :adm_date,  :group_id, :birth_date,  :blood_group, :photo, :created_date, :aadhar, :my_session , :my_date , :uid , :ulevel , :password, :step, :docx_id)');
                $sql->execute(array(
                    ':MSID' => $stu_data_get['MSID'],
                    ':acno' => $stu_data_get['acno'],
                    ':student_id' => $student_id,
                    ':parent_id' => $stu_data_get['parent_id'],
                    ':adm_classno' => $stu_data_get['adm_classno'],
                    ':section' => $stu_data_get['section'],
                    ':house' => $stu_data_get['house'],
                    ':admno' => $student_id,
                    ':roll_no' => $stu_data_get['roll_no'],
                    ':birth_certificate' => $stu_data_get['birth_certificate'],
                    ':name' => $stu_data_get['name'],
                    ':email' => $stu_data_get['email'],
                    ':fees_date' => $stu_data_get['fees_date'],
                    ':wardofstaff' => $stu_data_get['wardofstaff'],
                    ':gender' => $stu_data_get['gender'],
                    ':adm_date' => $stu_data_get['adm_date'],
                    ':group_id' => $stu_data_get['group_id'],
                    ':birth_date' => $stu_data_get['birth_date'],
                    ':blood_group' => $stu_data_get['blood_group'],
                    ':photo' => $stu_data_get['photo'],
                    ':created_date' => $stu_data_get['created_date'],
                    ':aadhar' => $stu_data_get['aadhar'],
                    ':my_session' => $stu_data_get['my_session'],
                    ':my_date' => $stu_data_get['my_date'],
                    ':uid' => $stu_data_get['MSID']."S".$student_id,
                    ':ulevel' => $stu_data_get['ulevel'],
                    'password' =>$stu_data_get['MSID']."S".$student_id,
                    ':step' => $stu_data_get['step'],
                    ':docx_id' => $stu_data_get['docx_id'],
//                    ':status' => $stu_data_get['status']
                ));
                if (@$stu_data_get['transportation'] != "0") {
                    $sql_transport = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_std (MSID, S_id, tpt_stn_id,date_from, date_to, up, down) VALUES (:MSID, :S_id, :tpt_stn_id,:date_from,:date_to, :up, :down)');

                    $sql_transport->execute(array(
                        ':MSID' => $msid,
                        ':S_id' => $student_id,
                        ':tpt_stn_id' => $stu_data_get['transportation'],
                        ':date_from' => '2016-04-01',
                        ':date_to' => '3000-12-31',
                        ':up' => '0',
                        ':down' => '0',
                    ));
                }
                if (@$stu_data_get['discount'] != "0") {
                    $sql_transport = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'discounted_student (MSID, S_id, discount_id,date_from, date_to) VALUES (:MSID, :S_id, :discount_id,:date_from,:date_to)');

                    $sql_transport->execute(array(
                        ':MSID' => $msid,
                        ':S_id' => $student_id,
                        ':discount_id' => $stu_data_get['discount'],
                        ':date_from' => '2016-04-01',
                        ':date_to' => '3000-12-31',
                    ));
                }

                if (@$stu_data_get['hostel'] != "0") {
                    $sql_transport = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'hosteler (MSID, hostel_id, s_id, from_date, to_date) VALUES (:MSID, :hostel_id, :s_id, :from_date, :to_date)');

                    $sql_transport->execute(array(
                        ':MSID' => $msid,
                        ':hostel_id' => $stu_data_get['hostel'],
                        ':s_id' => $student_id,
                        ':from_date' => $stu_data_get['adm_date'],
                        ':to_date' => '3000-12-31',
                    ));
                }







                $message->add('s', 'Student registered successfully!', CLIENT_URL . '/enrollment/sucess/' . $student_id);
            }

           // exit();
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

}

?>
