<?php

class Homework {

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_homeworks($msid = NULL, $id = NULL,$class_id = NULL, $section_id = NULL, $subject_id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "homework";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            if ($class_id != NULL) {
                $sql .= " AND class_id=" . $class_id;
            }
            if ($section_id != NULL) {
                $sql .= " AND section=" . $section_id;
            }
             if ($subject_id != NULL) {
                 $sql .= " AND subject_id='" . $subject_id."'";
            }
//			$sql .= " AND YEAR(created_date) =" . $_SESSION['year'] ;
            $sql .= " order by id ASC";

//            if ($data['selectAll'] == 'false') {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//            }
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function add_homework($id = NULL, $postdata = array(), $file = NULL) {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['class_id'])) == 0)
                $message->add('e', 'Class Name is required..!!');
            if (strlen(trim(@$postdata['subject_id'])) == 0)
                $message->add('e', 'Subject Name is required..!!');

            if (strlen(trim(@$postdata['homework'])) == 0)
                $message->add('e', 'homework is required..!!');

            if (!$message->hasMessages()) {
                if (!empty($file['file']['name'])) {
                    $upload_image = "uploads/homework/" .basename( $file["file"]["name"]);
                    $upload_img = move_uploaded_file($file['file']['tmp_name'], $upload_image);

                } else {
                    $upload_img = '';
                }
               
                if (!empty($id)) {//update designation
                    if (empty($upload_img)) {
                        $update_img = $postdata['file_data'];
                    } else {
                        $update_img = $file['file']['name'];
                    }
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'homework SET class_id = :class_id,section_id = :section_id, subject_id = :subject_id, homework = :homework , file = :file , created_date =:created_date WHERE id = :id');
                    $upsql->execute(array(
                        ':class_id' => $postdata['class_id'],
                        ':section_id' => $postdata['section_id'],
                        ':subject_id' => $postdata['subject_id'],
                        ':homework' => $postdata['homework'],
                        ':file' => $update_img,
                        ':created_date'=>$postdata['created_date'],
                        ':id' => $id
                    ));print_r($sql);
                    $message->add('s', 'Homework Field updated successfully!', CLIENT_URL . '/homework');
                    exit();
                } else {//insert into database
//                    print_r($update_img);
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'homework (MSID, class_id,section, subject_id, homework,file, created_date) VALUES  (:MSID, :class_id,:section_id, :subject_id, :homework, :file,  :created_date)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':class_id' => $postdata['class_id'],
                        ':section_id' => $postdata['section_id'],
                        ':subject_id' => $postdata['subject_id'],
                        ':homework' => $postdata['homework'],
                        ':file' => $file['file']['name'],
                        ':created_date' => $postdata['created_date'],
                    ));
                    
                    $message->add('s', 'Homework  added successfully!', CLIENT_URL . '/homework');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

}

?>
