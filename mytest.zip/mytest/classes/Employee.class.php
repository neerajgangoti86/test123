<?php

class Employee {

    /**
     * get employee for school
     * @param string $msid
     * @param string $id
     * this function used in following pages : ajax-page-load.cont.php, 
     */
    public static function change_pasword($msid = NULL, $uid = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "employee";
            $sql .= " where MSID=" . $msid . " AND uid = '" . $uid . "'";

            // print_r($sql);
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function emp_timetable($msid = NULL, $class = NULL, $period = NULL, $section = NULL) {

        try {
            $sql = "SELECT  distinct T.`empid`,E.employee_id,E.emp_name  FROM   `" . DB_PREFIX . "time_tb`  T INNER JOIN  `" . DB_PREFIX . "employee`   E ON T.empid=E.employee_id And  T.MSID=E.MSID And T.MSID='" . $msid . "'  ";

            if ($class != NULL) {
                $sql .= " and T.Class='" . $class . "' ";
            }
            if ($section != NULL) {
                $sql .= " and T.Section='" . $section . "'";
            }
            if ($period != NULL) {
                $sql .= " and T.Period='" . $period . "'";
            }

            $sql .= " And E.emp_category='TS'";

//            print_r($sql);
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function update_pasword($msid = NULL, $uid = NULL, $post) {
        $message = new Messages();
        $oDb = DBConnection::get();

        try {
            $usr_type = strpos($uid, 'E');
            if ($usr_type != NULL) {
                $uid = explode('E', $uid);
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'employee SET password = :password  WHERE MSID = :MSID AND uid = :uid');
                $upsql->execute(array(
                    ':password' => $post,
                    ':MSID' => $msid,
                    ':uid' => $uid[1],
                ));
            } else {
                $uid = explode('vm', $uid);
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'vmusers SET password = :password  WHERE  uid = :uid');
                $upsql->execute(array(
                    ':password' => $post,
                    ':uid' => $uid[1],
                ));
            }

            ActivityFeed::add_feeds($_SESSION['oCurrentUser']->MSID, $_SESSION['oCurrentUser']->user_id, $_SESSION['oCurrentUser']->myuname, $_SESSION['oCurrentUser']->ulevel, 'Changed Password', '', '', '', '', '');

            $message->add('s', 'Password updated successfully! <a id="true" href="'.CLIENT_URL.'" >Click Here</a> to Open Dashboard', CLIENT_URL . '/password');
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function update_user_dates($msid = NULL, $uid = NULL, $post) {
//        print_r($_POST);
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            $date_period_from = date('Y-m-d', strtotime($post['date_from']));
            $date_period_to = date('Y-m-d', strtotime($post['date_to']));

            unset($_SESSION['date_period_from']);
            unset($_SESSION['date_period_to']);
            $_SESSION['date_period_from'] = $date_period_from;
            $_SESSION['date_period_to'] = $date_period_to;

            //die("<>><<");

            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'employee SET my_period_from = :my_period_from, my_period_to = :my_period_to  WHERE MSID = :MSID AND uid = :uid');
            $status = $upsql->execute(array(':my_period_from' => $date_period_from, ':my_period_to' => $date_period_to,
                ':MSID' => $msid,
                ':uid' => $uid
            ));

            $vmstmt = $oDb->prepare('UPDATE ' . DB_PREFIX . 'vmusers SET my_period_from = :my_period_from, my_period_to = :my_period_to WHERE name = :name and ulevel = :ulevel');
            $status2 = $vmstmt->execute(array(
                ':my_period_from' => $date_period_from, ':my_period_to' => $date_period_to,
                ':name' => $_SESSION['oCurrentUser']->myuname,
                ':ulevel' => $_SESSION['oCurrentUser']->ulevel
            ));


            return $status2;




            //return $status;
            //header('Location: ' . CLIENT_URL . '/fee-report');
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_employee($msid = NULL, $id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10), $curren_date = Null, $out = "false") {
//        print_r($out);
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "employee";
            $sql .= " where MSID=" . $msid . " AND employee_id > 0 ";

            if ($id != NULL) {
                $sql .= " AND employee_id=" . $id;
            }
            if (!empty($data['emp_category'])) {
                $sql .= " AND emp_category='" . $data['emp_category'] . "'";
            }
            if ($out == "false") {
                $sql .= " AND retire_date > '" . $curren_date . "' ";
            } else {
                $sql .= " AND retire_date <= '" . $curren_date . "' ";
            }
            $sql .= " order by id ASC";
            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
//            exit();

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_employee_by_cat($msid = NULL, $curren_date = Null, $out = "false") {
        try {
            $sql = "SELECT count(*) as ttl_grp , emp_category FROM " . DB_PREFIX . "employee";
            $sql .= " where MSID=" . $msid;
            if ($out == "false") {
                $sql .= " AND retire_date > '" . $curren_date . "' ";
            } else {
                $sql .= " AND retire_date <= '" . $curren_date . "' ";
            }
            $sql .= " and emp_category !=''";
            $sql .= " group by emp_category ";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function create_employee($id = NULL, $postdata = array(), $file = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        $sGeneral = new General();
        try {
            //insert into database
            //image upload
            if (!empty($file['uploadedfile']['name'])) {
                //call thumbnail creation function and store thumbnail name
                $newfilename = 'photo_' . round(microtime(true));
                $upload_img = $sGeneral->cwUpload($file, 'uploadedfile', 'uploads/', $newfilename, TRUE, 'uploads/', '200', '160');
            } else {
                $upload_img = '';
            }
            if (!empty($id)) {//update parent
                if (empty($upload_img)) {
                    $update_img = $postdata['image_org'];
                } else {
                    $update_img = $upload_img;
                }

                $dob = date('Y-m-d', strtotime($postdata['dob']));
                $date_of_joing = date('Y-m-d', strtotime($postdata['hdate']));
                $retire_date = date('Y-m-d', strtotime($postdata['rdate']));

                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'employee SET emp_name_prefix = :emp_name_prefix, emp_name = :emp_name, spouse_name = :spouse_name, father_name = :father_name, epf_no = :epf_no, epf_join_date = :epf_join_date, emp_dob = :emp_dob, gender = :gender, blood_group = :blood_group, p_qualification = :p_qualification, e_qualification = :e_qualification, bank_ac_no = :bank_ac_no, hire_date = :hire_date, retire_date = :retire_date, emp_category = :emp_category, department = :department, designation = :designation, emp_image = :emp_image, is_librarian = :is_librarian, mobile = :mobile, aadhar_no = :aadhar_no, locality = :locality, address = :address WHERE employee_id = :employee_id And MSID = :MSID');
                $upsql->execute(array(
                    ':emp_name_prefix' => $postdata['Prefix_Name'],
                    ':emp_name' => $postdata['empname'],
                    ':spouse_name' => $postdata['esname'],
                    ':father_name' => $postdata['efname'],
                    ':epf_no' => $postdata['epfno'],
                    ':epf_join_date' => $postdata['epfjdate'],
                    ':emp_dob' => $dob,
                    ':gender' => $postdata['Gender'],
                    ':blood_group' => $postdata['bgroup'],
                    ':p_qualification' => $postdata['p_qualification'],
                    ':e_qualification' => $postdata['e_qualification'],
                    ':bank_ac_no' => $postdata['bank_acno'],
                    ':hire_date' => $date_of_joing,
                    ':retire_date' => $retire_date,
                    ':emp_category' => $postdata['empcat'],
                    ':department' => $postdata['dept'],
                    ':designation' => $postdata['Designation'],
                    ':emp_image' => $update_img,
                    ':is_librarian' => $postdata['Librarian'],
                    ':mobile' => $postdata['mobile'],
                    ':aadhar_no' => $postdata['adno'],
                    ':locality' => $postdata['locality'],
                    ':address' => $postdata['Address'],
                    ':employee_id' => $id,
                    ':MSID' => $postdata['MSID']
                ));

//                print_r($upsql);
                $message->add('s', 'Employee updated successfully!', CLIENT_URL . '/employee/edit/' . $id);
                exit();
            } else {//insert into database
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'employee (MSID, employee_id ,emp_name_prefix, emp_name, spouse_name, father_name, epf_no, epf_join_date, emp_dob,gender, blood_group,p_qualification,e_qualification, bank_ac_no, hire_date, retire_date, emp_category, department, designation, emp_image, is_librarian, mobile, aadhar_no, locality, address, created_date,status) VALUES  (:MSID, :employee_id, :emp_name_prefix, :emp_name, :spouse_name, :father_name, :epf_no, :epf_join_date, :emp_dob, :gender, :blood_group, :p_qualification, :e_qualification, :bank_ac_no, :hire_date, :retire_date, :emp_category, :department, :designation, :emp_image, :is_librarian, :mobile, :aadhar_no, :locality, :address, :created_date, :status)');

                $sql->execute(array(
                    ':MSID' => $postdata['MSID'],
                    ':employee_id' => $postdata['empid'],
                    ':emp_name_prefix' => $postdata['Prefix_Name'],
                    ':emp_name' => $postdata['empname'],
                    ':spouse_name' => $postdata['esname'],
                    ':father_name' => $postdata['efname'],
                    ':epf_no' => $postdata['epfno'],
                    ':epf_join_date' => $postdata['epfjdate'],
                    ':emp_dob' => $postdata['dob'],
                    ':gender' => $postdata['Gender'],
                    ':blood_group' => $postdata['bgroup'],
                    ':p_qualification' => $postdata['p_qualification'],
                    ':e_qualification' => $postdata['e_qualification'],
                    ':bank_ac_no' => $postdata['bank_acno'],
                    ':hire_date' => $postdata['hdate'],
                    ':retire_date' => '3000-12-31',
                    ':emp_category' => $postdata['empcat'],
                    ':department' => $postdata['dept'],
                    ':designation' => $postdata['Designation'],
                    ':emp_image' => $upload_img,
                    ':is_librarian' => $postdata['Librarian'],
                    ':mobile' => $postdata['mobile'],
                    ':aadhar_no' => $postdata['adno'],
                    ':locality' => $postdata['locality'],
                    ':address' => $postdata['Address'],
                    ':created_date' => date('Y-m-d H:i:s'),
                    ':status' => '1'
                ));

                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'employee SET my_session = :my_session, my_date = :my_date, uid= :uid,ulevel = :ulevel, password= :password WHERE MSID= :MSID And employee_id = :id');
                $upsql->execute(array(
                    ':my_session' => date('Y'),
                    ':my_date' => date('Y-m-d H:i:s'),
                    ':uid' => $postdata['MSID'] . "E" . $postdata['empid'],
                    ':ulevel' => '2',
                    ':password' => md5($postdata['MSID'] . "E" . $postdata['empid']),
                    ':id' => $postdata['empid'],
                    ':MSID' => $postdata['MSID'],
                ));
//                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'users (username,password,first_name,last_name,email,MSID,user_level,created_date,status) VALUES  (:username,:password,:first_name,:last_name,:email,:MSID,:user_level,:created_date,:status)');
//
//                $sql->execute(array(
//                    ':username' => $postdata['MSID'] . "E" . $employee_id,
//                    ':password' => md5($postdata['MSID'] . "E" . $employee_id),
//                    ':first_name' => $postdata['fname'],
//                    ':last_name' => '',
//                    ':email' => '',
//                    ':MSID' => $postdata['MSID'],
//                    ':user_level' => 'Employee',
//                    ':created_date' => date('Y-m-d H:i:s'),
//                    ':status' => '1'
//                ));
                $message->add('s', 'Employee registered successfully!', CLIENT_URL . '/employee');
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

}

?>
