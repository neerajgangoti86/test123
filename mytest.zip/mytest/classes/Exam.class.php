<?php

class Exam
    {

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_exam_grades($msid = NULL, $percent = NULL)
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_grades";
            $sql .= " where MSID=" . $msid;

            if ($percent != NULL)
                {
                $sql .= " AND '" . $percent . "' between percent_from And percent_to";
                }
            $sql .= " order by id ASC";


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_teacher_classes($msid = NULL, $uid = NULL)
        {
        try
            {
            $sql = " SELECT A.MSID,E.uid,A.empid,E.emp_name,A.Class,A.Section,A.Subject from (SELECT * FROM `" . DB_PREFIX . "time_tb` where MSID='" . $msid . "'  ) A left join  " . DB_PREFIX . "employee E on E.employee_id=A.empid and A.MSID=E.MSID where E.uid='" . $uid . "' group by A.empid,A.Class,A.Section,A.Subject ";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_student_exams($msid = NULL, $id = NULL)
        {

        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "exams";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND s_id=" . $id;
                }
            $sql .= " order by id ASC";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_student_academic_activity($msid = NULL, $activity_id = NULL)
        {

        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "activites";
            $sql .= " where MSID=" . $msid;

            if ($activity_id != NULL)
                {
                $sql .= " AND id =" . $activity_id;
                }
            $sql .= " order by id ASC";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_indicator_names($msid = NULL, $id = NULL)
        {
        try
            {
            $sql = "  SELECT * FROM " . DB_PREFIX . "exam_co_scholastic_indicators";
            $sql .= " where MSID = " . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id = " . $id;
                }



            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
            }
        }

    public static function get_failed_students($msid = NULL, $id = NULL, $results = NULL, $data = array('selectAll' => 'true'), $begin = Null, $end = Null)
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "exams";
            $sql .= " where MSID=" . $msid;
            if ($results != NULL)
                {
                $sql .=" AND result =" . $results;
                }
            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }

            $sql .= " AND date_result between '" . $begin . "' And '" . $end . "' order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

//    public static function get_accademinc_performance($msid = NULL, $id = NULL, $
//    ent_id = NULL, $activity_id = NULL, $subject_id = NULL, $class_id = NULL, $s_id = NULL, $session = NULL, $data = array('selectAll' => 'true'), $distinct = 'NO', $section_id = Null)
//        {
//        try
//            {
//            if ($distinct == 'YES')
//                {
//                $sql = "SELECT distinct subject_id FROM " . DB_PREFIX . "exam_acedemic_performance";
//                }
//            else
//                {
//                $sql = "SELECT * FROM " . DB_PREFIX . "exam_acedemic_performance";
//                }
//            $sql .= " where MSID=" . $msid;
//
//            if ($id != NULL)
//                {
//                $sql .= " AND id=" . $id;
//                }
//            if ($s_id != NULL)
//                {
//                $sql .= " AND student_id=" . $s_id;
//                }
//            if ($assesment_id != NULL)
//                {
//                $sql .= " AND assesment_id=" . $assesment_id;
//                }
//            if ($activity_id != NULL)
//                {
//                $sql .= " AND activity_id=" . $activity_id;
//                }
//            if ($subject_id != NULL)
//                {
//                $sql .= " AND subject_id=" . $subject_id;
//                }
//            if ($class_id != NULL)
//                {
//                $sql .= " AND class=" . $class_id;
//                }
//            if ($section_id != NULL)
//                {
//                $sql .= " AND section=" . $section_id;
//                }
//            if ($session != NULL)
//                {
//                $sql .= " AND session=" . $session;
//                }
//
//            $sql .= " order by id ASC";
//            if ($data['selectAll'] == 'false')
//                {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//                }
////            print_r($sql); 
////            exit();
//            $oDb = DBConnection::get();
//            $sql = $oDb->query($sql);
//            return $sql;
//            }
//        catch (PDOException $e)
//            {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
//            }
//        }
    public static function get_performance($uid = NULL, $class = NULL, $section = NULL, $assid = NULL, $activity_id = NULL, $subject = NULL)
        {
        try
            {

            $sql = "select FIIN.student_Id,FIIN.MO,FIIN.max_marks,FIIN.percent,(select COUNT(*) from (SELECT CS.student_id ,CS.`name`,CS.`Section`,DS.`assessment`,COALESCE(Sum(AP.marks_obtained),0) MO,Sum(DS.`max_marks`)max_marks,COALESCE(Sum(AP.marks_obtained)/Sum(DS.`max_marks`)*100,0) percent FROM (SELECT CU.msid,CU.Mysession Session, S.`student_id`,S.`name`,S.`Section`,S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) 

CClass,K.`class_from`,K.`class_to` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='" . $uid . "') CU ON S.msid=CU.msid And S.`fees_date` <= CU.`ends` 

AND S.`sl_date` >= CU.`Begins` INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < 

CU.`mydate` GROUP BY S.`student_id` HAVING CClass Between K.`class_from` AND K.`class_to`) CS LEFT JOIN ms_exam_datesheet DS ON DS.`msid`=CS.`msid` AND 

DS.`session`=CS.`session` AND DS.`class`=CS.`Cclass` Left Join ms_exam_acedemic_performance AP ON AP.msid=CS.MSID And  AP.`datesheet_id`=DS.id And 

CS.`student_id`=AP.`student_id`  Where  DS.Class='" . $class . "' And CS.Section='" . $section . "' AND DS.`assessment`='" . $assid . "' group by CS.student_id) FIN where FIN.percent>FIIN.percent) + 1 as rank from (SELECT CS.student_id ,DS.`assessment`,COALESCE(Sum(AP.marks_obtained),0) MO,Sum(DS.`max_marks`)max_marks,COALESCE(Sum(AP.marks_obtained)/Sum(DS.`max_marks`)*100,0) percent FROM (SELECT CU.msid,CU.Mysession Session, S.`student_id`, S.`name`, S.`section`, S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) 

CClass,K.`class_from`,K.`class_to` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='1001vm1') CU ON S.msid=CU.msid And S.`fees_date` <= CU.`ends` 

AND S.`sl_date` >= CU.`Begins` INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < 

CU.`mydate` GROUP BY S.`student_id` HAVING CClass Between K.`class_from` AND K.`class_to`) CS LEFT JOIN ms_exam_datesheet DS ON DS.`msid`=CS.`msid` AND 

DS.`session`=CS.`session` AND DS.`class`=CS.`Cclass` Left Join ms_exam_acedemic_performance AP ON AP.msid=CS.MSID And  AP.`datesheet_id`=DS.id And 

CS.`student_id`=AP.`student_id`  Where  DS.Class='" . $class;
            if (@$section)
                {
                $sql .= "' And CS.Section='" . $section;
                }
            if (@$assid)
                {
                $sql .= "' AND DS.`assessment`='" . $assid;
                }
            if (@$activity_id)
                {
                $sql .= "' AND DS.`activity`='" . $activity_id;
                }
            if (@$subject)
                {
                $sql .= "' AND DS.`subject`='" . $subject;
                }
            $sql .= "' group by CS.student_id) FIIN order by rank
";
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_accademinc_performance($msid = NULL, $id = NULL, $class_id = NULL, $s_id = NULL, $section_id = Null, $data = array('selectAll' => 'true'), $distinct = 'NO')
        {
        try
            {
            if ($distinct == 'YES')
                {
                $sql = "SELECT distinct datesheet_id FROM " . DB_PREFIX . "exam_acedemic_performance";
                }
            else
                {
                $sql = "SELECT * FROM " . DB_PREFIX . "exam_acedemic_performance";
                }
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND datesheet_id=" . $id;
                }
            if ($s_id != NULL)
                {
                $sql .= " AND student_id=" . $s_id;
                }

            if ($class_id != NULL)
                {
                $sql .= " AND class=" . $class_id;
                }
            if ($section_id != NULL)
                {
                $sql .= " AND section=" . $section_id;
                }


            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_reportcard_detail($msid = NULL, $id = NULL, $class_id = NULL, $s_id = NULL, $distinct = NULL)
        {
        try
            {
            "SELECT CS.student_id ,DS.`subject`,DS.`assessment`, AP.`marks_obtained`,AP.`grade`, WT.`output_field`, sum(AP.marks_obtained/DS.`max_marks`*WT.weightage) Percent,sum(WT.weightage) Outoff, DS.`max_marks` FROM (SELECT CU.msid,CU.Mysession Session, S.`student_id`,S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) CClass,K.`class_from`,K.`class_to` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='1001vm1') CU ON S.msid=CU.msid And S.`fees_date` <= CU.`ends` AND S.`sl_date` >= CU.`Begins` INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < CU.`mydate` GROUP BY S.`student_id` HAVING CClass Between K.`class_from` AND K.`class_to`) CS LEFT JOIN ms_exam_datesheet DS ON DS.`msid`=CS.`msid` AND DS.`session`=CS.`session` AND DS.`class`=CS.`Cclass` Left Join ms_exam_acedemic_performance AP ON AP.msid=CS.MSID And  AP.`datesheet_id`=DS.id And CS.`student_id`=AP.`student_id` Inner Join ms_exam_weightage WT  ON  WT.`Assesment_id`=DS.assessment And CS.CClass between  WT.`class_from` And WT.`class_to` Where WT.`report_name`='HYAP1' And CS.student_id='12004' And WT.`output_field`='Term1'  group by CS.student_id,DS.subject,WT.`output_field`
";

//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function add_exam_daily_marks($id = NULL, $postdata = array())
        {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {
//            echo "<pre>";
//            print_r($postdata);
//            exit();
            //********* Insert into database *********//
//            if (!$message->hasMessages())
//                {
            $i = 0;
//                foreach ($postdata['id'] as $data => $val)
////                    {
//                    $students_marks_existing = Exam::get_accademinc_performance($_POST['MSID'], '', $_POST['assesment'], $activity_id, $_POST['sub_id'], $_POST['class_id'], $data);
//                    $totalrecords_students = $students_marks_existing->rowCount();
//                    if ($totalrecords_students > 0)
//                        {
//                        $attend = (@$_POST['cid'][$data]) ? '1' : '0';
//                        $existing_marks = $students_marks_existing->fetch(PDO::FETCH_ASSOC);
//                        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_acedemic_performance SET marks_obtained = :marks_obtained, attendance = :attendance, grade = :grade WHERE id = :id');
//                        $upsql->execute(array(
//                            ':marks_obtained' => $_POST['marks'][$i],
//                            ':grade' => $_POST['grade'][$i],
//                            ':attendance' => $attend,
//                            ':id' => $existing_marks['id'],
//                        ));
//                        }
//                    else
//                        {
//                    print_r($_POST);
//                    exit();
//                         $date = date("Y-m-d", strtotime($_POST['date']));
//                         print_r($date);
//                         exit();
//                         
//                        $attend = (@$_POST['cid'][$data]) ? '1' : '0';
            foreach ($_POST['q_no'] as $key => $val)
                {
//echo "ASda";
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_question_bank (MSID, q_no, class, subject, chapter, question, marks, sub_group, session, no_of_question, d_level, section, qheading) VALUES (:MSID, :q_no, :class, :subject, :chapter, :question, :marks, :sub_group, :session, :no_of_question, :d_level, :section, :qheading)');
                $sql->execute(array(
                    ':MSID' => $_POST['MSID'],
//                    ':q_id' => $_POST['year'],
                    ':q_no' => $val,
//                    ':assesment' => $_POST['assesment'],
                    ':class' => $_POST['class_id'],
                    ':subject' => $_POST['subject'],
                    ':chapter' => $_POST['chapter'],
                    ':question' => $_POST['question'][$key],
                    ':marks' => $_POST['max_marks'],
                    ':sub_group' => $_POST['section_title'],
                    ':session' => $_POST['session'],
                    ':no_of_question' => $_POST['noq'],
                    ':d_level' => $_POST['dlevel'],
                    ':section' => $_POST['section'],
                    ':qheading' => $_POST['question_title']
                ));
//                        } $i++;
                }
//                }
            $message->add('s', 'Question added successfully!', CLIENT_URL . '/question-bank/add');
            exit();
//            }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }

    public static function add_exam_datesheet($id = NULL, $postdata = array())
        {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {
            if (@$_POST['activity'])
                {
                $activity_id = $_POST['activity'];
                }
            else
                {
                $activity_id = 0;
                }
//            echo '<pre>';
//          print_r($postdata);
//            exit();
            //********* Insert into database *********//
            if (!$message->hasMessages())
                {
                $i = 0;
//                foreach ($postdata['id'] as $data => $val)
////                    {
//                    $students_marks_existing = Exam::get_accademinc_performance($_POST['MSID'], '', $_POST['assesment'], $activity_id, $_POST['sub_id'], $_POST['class_id'], $data);
//                    $totalrecords_students = $students_marks_existing->rowCount();
//                    if ($totalrecords_students > 0)
//                        {
//                        $attend = (@$_POST['cid'][$data]) ? '1' : '0';
//                        $existing_marks = $students_marks_existing->fetch(PDO::FETCH_ASSOC);
//                        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_acedemic_performance SET marks_obtained = :marks_obtained, attendance = :attendance, grade = :grade WHERE id = :id');
//                        $upsql->execute(array(
//                            ':marks_obtained' => $_POST['marks'][$i],
//                            ':grade' => $_POST['grade'][$i],
//                            ':attendance' => $attend,
//                            ':id' => $existing_marks['id'],
//                        ));
//                        }
//                    else
//                        {
//                    print_r($_POST);
//                    exit();
//                         $date = date("Y-m-d", strtotime($_POST['date']));
//                         print_r($date);
//                         exit();
//                        $attend = (@$_POST['cid'][$data]) ? '1' : '0';
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_datesheet (MSID, session, subject, assessment, activity, max_marks, class, pass_marks, exam_date, exam_time_from, exam_time_to, section) VALUES (:MSID, :session, :subject, :assessment, :activity, :max_marks, :class, :pass_marks, :exam_date, :exam_time_from, :exam_time_to, :section)');
                $sql->execute(array(
                    ':MSID' => $_POST['MSID'],
                    ':session' => $_POST['year'],
                    ':subject' => $_POST['sub_id'],
                    ':assessment' => $_POST['assesment'],
                    ':activity' => $activity_id,
                    ':max_marks' => $_POST['max_marks'],
                    ':class' => $_POST['class_id'],
                    ':pass_marks' => $_POST['pasing_marks'],
                    ':exam_date' => $_POST['exam_date'],
                    ':exam_time_from' => $_POST['start_time'],
                    ':exam_time_to' => $_POST['end_time'],
                    ':section' => $_POST['section_id']
                ));
//                        } $i++;
//                    }
                
                } $message->add('s', 'DateSheet added successfully!', CLIENT_URL . '/exam-schedule');
            exit();
//            }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }

    public static function add_exam_acedemic_performance($id = NULL, $postdata = array(), $type = NULL)
        {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {

            //********* Insert into database *********//
            if (!$message->hasMessages())
                {
                $i = 0;
                foreach ($postdata['id'] as $data => $val)
                    {
                    $students_marks_existing = Exam::get_accademinc_performance($_POST['MSID'], $_POST['datesheet_id'], $_POST['class_id'], $data, $_POST['section'], $data);
                    $totalrecords_students = $students_marks_existing->rowCount();

                    if ($totalrecords_students > 0)
                        {
                        $attend = (@$_POST['cid'][$data]) ? '1' : '0';
                        $existing_marks = $students_marks_existing->fetch(PDO::FETCH_ASSOC);
                        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_acedemic_performance SET marks_obtained = :marks_obtained, attendance = :attendance, grade = :grade WHERE id = :id');
                        $upsql->execute(array(
                            ':marks_obtained' => $_POST['marks'][$i],
                            ':grade' => $_POST['grade'][$i],
                            ':attendance' => $attend,
                            ':id' => $existing_marks['id'],
                        ));
                        }
                    else
                        {
//                    print_r($_POST);
//                    exit();
//                         $date = date("Y-m-d", strtotime($_POST['date']));
//                         print_r($date);
//                         exit();
                        $attend = (@$_POST['cid'][$data]) ? '1' : '0';
                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_acedemic_performance (MSID, datesheet_id, student_id, marks_obtained, grade, attendance, class, section, type) VALUES (:MSID, :datesheet_id, :student_id, :marks_obtained, :grade, :attendance, :class, :section, :type)');
                        $sql->execute(array(
                            ':MSID' => $_POST['MSID'],
                            ':datesheet_id' => $_POST['datesheet_id'],
                            ':student_id' => $data,
                            ':marks_obtained' => $_POST['marks'][$i],
                            ':grade' => $_POST['grade'][$i],
                            ':attendance' => $attend,
                            ':class' => $_POST['class_id'],
                            ':section' => $_POST['section'],
                            ':type' => $_POST['type']
                        ));
                        } $i++;
                    }
                } $message->add('s', 'Acedemic Performance added successfully!', CLIENT_URL . '/datesheet');
            exit();
//            }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_datesheets($msid = NULL, $id = NULL, $assesment_id = NULL, $activity_id = NULL, $subject_id = NULL, $class_id = NULL, $section = NULL, $session = NULL, $data = array('selectAll' => 'true'))
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_datesheet";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }
            if ($activity_id != NULL)
                {
                $sql .= " AND activity=" . $activity_id;
                }
            if ($assesment_id != NULL)
                {
                $sql .= " AND assessment=" . $assesment_id;
                }
            if ($subject_id != NULL)
                {
                $sql .= " AND subject=" . $subject_id;
                }
            if ($class_id != NULL)
                {
                $sql .= " AND class=" . $class_id;
                }
            if ($section != NULL)
                {
                $sql .= " AND section=" . $section;
                }
            if ($session != NULL)
                {
                $sql .= " AND session=" . $session;
                }

            $sql .= " order by class, section, subject ,activity, id ASC";
//            print_r($sql);
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_distinct_assesments($msid = NULL, $id = NULL, $class_id = NULL, $section = NULL, $s_id = NULL, $data = array('selectAll' => 'true'))
        {
        try
            {
            $sql = "SELECT distinct  `class`,`section` FROM " . DB_PREFIX . "exam_acedemic_performance";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }
            if ($s_id != NULL)
                {
                $sql .= " AND student_id=" . $s_id;
                }

            if ($class_id != NULL)
                {
                $sql .= " AND class=" . $class_id;
                }
            if ($section != NULL)
                {
                $sql .= " AND section=" . $section;
                }


            $sql .= " order by id ASC";
            print_r($sql);
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

//    public static function get_distinct_assesments($msid = NULL, $id = NULL, $assesment_id = NULL, $activity_id = NULL, $subject_id = NULL, $class_id = NULL, $s_id = NULL, $session = NULL, $data = array('selectAll' => 'true'), $section = NULL)
//        {
//        try
//            {
//            $sql = "SELECT distinct `subject_id`, `assesment_id`,`activity_id`, `max_marks`, `passing_marks`, `start_time`, `class`,`section`, `end_time`, `date` FROM " . DB_PREFIX . "exam_acedemic_performance";
//            $sql .= " where MSID=" . $msid;
//
//            if ($id != NULL)
//                {
//                $sql .= " AND id=" . $id;
//                }
//            if ($s_id != NULL)
//                {
//                $sql .= " AND student_id=" . $s_id;
//                }
//            if ($activity_id != NULL)
//                {
//                $sql .= " AND activity_id=" . $activity_id;
//                }
//            if ($assesment_id != NULL)
//                {
//                $sql .= " AND assesment_id=" . $assesment_id;
//                }
//            if ($subject_id != NULL)
//                {
//                $sql .= " AND subject_id=" . $subject_id;
//                }
//            if ($class_id != NULL)
//                {
//                $sql .= " AND class=" . $class_id;
//                }
//            if ($section != NULL)
//                {
//                $sql .= " AND section=" . $section;
//                }
//            if ($session != NULL)
//                {
//                $sql .= " AND session=" . $session;
//                }
//
//            $sql .= " order by id ASC";
//            //print_r($sql);
//            if ($data['selectAll'] == 'false')
//                {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//                }
//
//            $oDb = DBConnection::get();
//            $sql = $oDb->query($sql);
//            return $sql;
//            }
//        catch (PDOException $e)
//            {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
//            }
//        }

    public static function get_exam_co_scholastic_areas($msid = NULL, $id = NULL, $data = array('selectAll' => 'true'), $class_id = NULL)
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_co_scholastic_areas";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }
            if ($class_id != NULL)
                {
                $sql .= " AND FIND_IN_SET('" . $class_id . "',class)";
                }
            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_exam_assesments($msid = NULL, $id = NULL, $data = array('selectAll' => 'true'), $class_id = NULL, $assesment_id = NULL, $term = 'NO', $term_id = NULL, $distinct = NULL)
        {
        try
            {
            if ($distinct == "YES")
                {
                $sql = "SELECT distinct  title ,assesment_id FROM " . DB_PREFIX . "exam_assesments  ";
                }
            else
                {
                $sql = "SELECT * FROM " . DB_PREFIX . "exam_assesments  ";
                }
            if (@$msid)
                {
                $sql .= " where MSID=" . $msid;
                }
            if (@$term_id)
                {
                $sql .= " AND term='" . $term_id . "'";
                }

            if (@$id)
                {
                $sql .= " AND id=" . $id;
                } if (@$assesment_id && $assesment_id != '')
                {
                $sql .= " AND assesment_id=" . $assesment_id;
                }
            if (@$class_id || $class_id == "0")
                {
                $sql .= "  AND FIND_IN_SET('" . $class_id . "',class) ";
                }
            if (@$assesment_id && $assesment_id != '')
                {
                $sql.=" group by assesment_id ";
                }
            if ($term == "YES")
                {
                $sql .= " ORDER BY `term` ASC ";
                }
            else
                {
                $sql .= " order by assesment_id ASC";
                }
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_new_exam_assesments($msid = NULL, $class_id = NULL, $assesment_id = NULL, $term_id = NULL, $distinct = NULL)
        {
        try
            {
            if ($distinct == "YES")
                {
                $sql = "SELECT distinct  title ,assesment_id FROM " . DB_PREFIX . "exam_assesments  ";
                }
            else
                {
                $sql = "SELECT * FROM " . DB_PREFIX . "exam_assesments  ";
                }
            if (@$msid)
                {
                $sql .= " where MSID=" . $msid;
                }
            if (@$term_id)
                {
                $sql .= " AND term='" . $term_id . "'";
                }

            if (@$assesment_id && $assesment_id != '')
                {
                $sql .= " AND assesment_id=" . $assesment_id;
                }
            if (@$class_id || $class_id == "0")
                {
                $sql .= "  AND FIND_IN_SET('" . $class_id . "',class) ";
                }
            if (@$assesment_id && $assesment_id != '')
                {
                $sql.=" group by assesment_id ";
                }
            if ($term == "YES")
                {
                $sql .= " ORDER BY `term` ASC ";
                }
            else
                {
                $sql .= " order by id ASC";
                }
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function exam_grade_calculater($msid = NULL, $student_id = NULL, $assesment_id = NULL, $subject_id = NULL, $order_by = "NO")
        {
        try
            {
            $sql = "SELECT AP.MSID,AP.`student_id`,AP.`assesment_id`,AP.`marks_obtained`,AP.`max_marks`,
                AP.`subject_id`,ROUND(AP.`marks_obtained`/AP.`max_marks`*100,2)
                Percent,G.`Grade` FROM `ms_exam_acedemic_performance` AP INNER Join ms_exam_grades G 
                ON (AP.`marks_obtained`/AP.`max_marks`*100) Between G.`percent_from` AND 
                G.`percent_to` AND AP.MSID=G.MSID WHERE AP.MSID='$msid' AND 
                 AP.`session`='" . $_SESSION['year'] . "' AND AP.student_id='" . $student_id .
                    "'  AND AP.`assesment_id`='" . $assesment_id . "' 
                AND AP.`subject_id`='$subject_id'";
            if (@$order_by == "YES")
                {
                $sql .="ORDER BY `student_id`,`assesment_id`,`subject_id";
                }
            else
                {
                $sql .="AND FIND_IN_SET(AP.`class`,class) ";
                }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function exam_term_grade_calculater($msid = NULL, $student_id = NULL, $term_id = NULL, $subject_id = NULL)
        {
        try
            {
            $sql = "SELECT Q1.student_id,Q1.subject_id,Q1.Term,Q1.Point,G.grade FROM 
                    (SELECT RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,
                    W.term,SUM(ROUND(RD.`marks_obtained`/RD.`max_marks`*term_wtg,2))
                     Point FROM `ms_exam_acedemic_performance` RD 
                    INNER JOIN ms_exam_weightage W ON W.MSID=RD.MSID AND W.assesment_id=RD.assesment_id 
                    WHERE
                    RD.MSID='$msid' AND
                    RD.`session`='" . $_SESSION['year'] . "' AND 
                    student_id='" . $student_id . "'  AND 
                    RD.`subject_id`='" . $subject_id;
            if ($term_id)
                {
                $sql .= "'  And
            W.term ='" . $term_id;
                }
            $sql .= "'
                     GROUP BY RD.student_id,RD.subject_id,W.term) Q1 
                    INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.Point 
                    BETWEEN G.`percent_from` AND G.`percent_to`";


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function exam_Subjectwise_overallgrade_calculater($msid = NULL, $student_id = NULL, $subject_id = NULL)
        {
        try
            {
            $sql = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade FROM 
                    (Select RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`
                    ,W.term,round(Sum(RD.`marks_obtained`)/SUM(W.overall_wtg)*100,2)
                     point from ms_exam_weightage W inner JOIN `ms_exam_acedemic_performance` RD ON W.assesment_id=RD.assesment_id AND W.overall_wtg=RD.max_marks
                     WHERE  RD.MSID='$msid' AND  W.MSID='$msid' AND `session`='" . $_SESSION['year']
                    . "' AND student_id='" . $student_id . "'  AND  `subject_id`='" .
                    $subject_id . "'   GROUP BY RD.student_id,RD.subject_id )
                     Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point
                     BETWEEN G.`percent_from` AND G.`percent_to`";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function exam_grade_point($msid = NULL, $student_id = NULL, $subject_id = NULL)
        {
        try
            {

            $sql = "SELECT Q1.student_id,Q1.subject_id,Q1.term,Q1.point,G.grade ,G.grade_point FROM
                     (Select RD.MSID,RD.`student_id`,RD.`assesment_id`,RD.`subject_id`,
                     W.term,round(Sum(RD.`marks_obtained`)/SUM(W.overall_wtg)*100,2) point
                     from ms_exam_weightage W inner JOIN `ms_exam_acedemic_performance` 
                     RD ON W.assesment_id=RD.assesment_id AND W.overall_wtg=RD.max_marks
                     WHERE  RD.MSID='$msid' AND  W.MSID='$msid' AND `session`='" . $_SESSION['year'] .
                    "' AND student_id='" . $student_id . "'  AND  `subject_id`='" .
                    $subject_id . "'   GROUP BY RD.student_id,RD.subject_id ) Q1 
                    INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.point BETWEEN 
                    G.`percent_from` AND G.`percent_to`";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function exam_overall_grade_calculater($msid = NULL, $student_id = NULL)
        {
        try
            {
            $sql = "SELECT Q1.student_id, Q1.Point,G.grade FROM 
                    (Select student_id, MSID, round(Sum( `marks_obtained`)/SUM(`max_marks`)*100,2)
                     Point from `ms_exam_acedemic_performance` 
                     WHERE   MSID='$msid' AND `session`='" . $_SESSION['year'] . "' AND 
                      student_id='" . $student_id .
                    "') Q1 INNER JOIN ms_exam_grades G ON Q1.MSID=G.MSID AND Q1.Point BETWEEN "
                    . "G.`percent_from` AND G.`percent_to`";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_exam_remarks($msid = NULL, $id = NULL, $data = array('selectAll' => 'true'), $s_id = NULL, $session = NULL, $term = NULL, $class = NULL)
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_remarks";
            $sql .= " where MSID = " . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id = " . $id;
                } if ($s_id != NULL)
                {
                $sql .= " AND s_id = " . $s_id;
                }if ($session != NULL)
                {
                $sql .= " AND session = " . $session;
                }

            if ($term != NULL)
                {
                $sql .= " AND term = " . $term;
                }
            if ($term != NULL)
                {
                $sql .= " AND class = " . $class;
                }

            $sql .= " order by id ASC";
//            if ($data['selectAll'] == 'false') {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//            }
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
            }
        }

    public static function add_remarks($id = NULL, $postdata = array())
        {
//        print_r($postdata);
//        exit();
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {
            //********* Insert into database *********//
            if (!$message->hasMessages())
                {
                $i = 0;
                foreach ($postdata['s_id'] as $data => $val)
                    {
                    $remark = Exam::get_exam_remarks($postdata['MSID'], '', '', $data, $postdata['year'], $postdata['term_id'], $postdata['class']);

                    $totalrecords_students = $remark->rowCount();
                    $existing_remark = $remark->fetch(PDO::FETCH_ASSOC);
                    if ($totalrecords_students > 0)
                        {
                        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_remarks SET remark = :remark WHERE id = :id');
                        $upsql->execute(array(
                            ':remark' => $postdata['remarks'][$i],
                            ':id' => $existing_remark['id'],
                        ));
                        }
                    else
                        {
                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_remarks (MSID, s_id, class, section, session, remark, term) VALUES (:MSID, :s_id, :class, :section, :session, :remark, :term)');
                        $sql->execute(array(
                            ':MSID' => $postdata['MSID'],
                            ':remark' => $postdata['remarks'][$i],
                            ':class' => $postdata['class'],
                            ':section' => $postdata['section'],
                            ':session' => $postdata['year'],
                            ':term' => $postdata['term_id'],
                            ':s_id' => $data
                        ));
                        }

                    $i++;
                    } $message->add('s', 'Remarks added successfully!', CLIENT_URL . '/remarks');
                unset($_SESSION['term']);
                unset($_SESSION['class_id']);
                exit();
                }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage
                    ());
            }
        }

    public static function get_exam_co_scholastic_marks($msid = NULL, $id = NULL, $data = array('selectAll' => 'true'), $s_id = NULL, $session = NULL, $co_scholastic_id = NULL, $term = NULL)
        {
        try
            {
            $sql = "  SELECT * FROM " . DB_PREFIX . "exam_co_scholastic_marks";
            $sql .= " where MSID = " . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id = " . $id;
                }
            if ($s_id != NULL)
                {
                $sql .= " AND s_id = " . $s_id;
                }
            if ($session != NULL)
                {
                $sql .= " AND session = " . $session;
                }
            if ($co_scholastic_id != NULL)
                {
                $sql .= " AND co_scholastic_id = " . $co_scholastic_id;
                }

            if ($term != NULL)
                {
                $sql .= " AND term = " . $term;
                }

            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
            }
        }

    public static function get_exam_health_data($msid = NULL, $id = NULL, $data = array('selectAll' => 'true'), $s_id = NULL, $session = NULL, $term = NULL)
        {
        try
            {
            $sql = "  SELECT * FROM " . DB_PREFIX . "exam_health_data";
            $sql .= " where MSID = " . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id = " . $id;
                }
            if ($s_id != NULL)
                {
                $sql .= " AND s_id = " . $s_id;
                }
            if ($session != NULL)
                {
                $sql .= " AND session = " . $session;
                }
            if ($term != NULL)
                {
                $sql .= " AND term = " . $term;
                }
            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
            }
        }

    public static function add_exam_health_data($id = NULL, $postdata = array())
        {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {
//            echo '<pre>';
//            print_r($postdata);
//            exit();
            //********* Insert into database *********//
            if (!$message->hasMessages())
                {
                $i = 0;
                foreach ($postdata['id'] as $data => $val)
                    {
                    $existing = Exam::get_exam_health_data($postdata['MSID'], '', array('selectAll' => 'true'), $data, $postdata['year'], $postdata['term']);

                    $totalrecords_students = $existing->rowCount();

                    if ($totalrecords_students > 0)
                        {
                        $existing_remark = $existing->fetch(PDO::FETCH_ASSOC);
                        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_health_data SET height = :height, weight = :weight WHERE id = :id');
                        $upsql->execute(array(
                            ':height' => $postdata['height'][$i],
                            ':weight' => $postdata['weight'][$i],
                            ':id' => $existing_remark['id'],
                        ));
                        }
                    else
                        {
                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_health_data (MSID, session, s_id, height, weight, term, class, section) VALUES (:MSID, :session, :s_id, :height, :weight, :term, :class, :section)');
                        $sql->execute(array(
                            ':MSID' => $_POST['MSID'],
                            ':session' => $postdata['year'],
                            ':s_id' => $data,
                            ':height' => $_POST['height'][$i],
                            ':weight' => $_POST['weight'][$i],
                            ':term' => $postdata['term'],
                            ':class' => $postdata['class'],
                            ':section' => $postdata['section']
                        ));
                        }

                    $i++;
                    } $message->add('s', 'Health Data added successfully!', CLIENT_URL . '/health-data');
                exit();
                }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage
                    ());
            }
        }

    public static function get_exam_co_scholastic_indicators($msid = NULL, $id = NULL, $co_scholastic_id = NULL, $data = array('selectAll' => 'true'), $grade = NUll)
        {
        try
            {
            $sql = "   SELECT * FROM " . DB_PREFIX . "exam_co_scholastic_indicators";
            $sql .= " where MSID = " . $msid;

            if ($id != NULL)
                {
                $sql .= " AND id = " . $id;
                } if ($co_scholastic_id != NULL)
                {
                $sql .= " AND co_scholastic_id = " . $co_scholastic_id;
                }
            if ($grade != NULL)
                {
                $sql .= " AND grade = '" . $grade . "'";
                }
            $sql .= " order by id ASC";
//            print_r($sql);
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_exam_co_scholastic_indicators_grade($msid = NULL, $data = array('selectAll' => 'true'), $grade = NULL, $id = Null)
        {
        try
            {
            $sql = "   SELECT * FROM " . DB_PREFIX . "exam_co_scholastic_indicators";
            $sql .= " where MSID = " . $msid;

            if ($grade != NULL)
                {
                $sql .= " AND grade = '" . $grade . "'";
                }
            if ($id != NULL)
                {
                $sql .= " AND co_scholastic_id = '" . $id . "'";
                }




            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
//         print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_exam_grades_by_marks($msid = NULL, $class_id = NULL, $marks = NULL)
        {
        try
            {
            $sql = "   SELECT * FROM " . DB_PREFIX . "exam_grades";
            $sql .= " where MSID = " . $msid;


            if ($class_id != NULL)
                {
                $sql .= " AND FIND_IN_SET('" . $class_id . "',for_class)";
                }
            if ($marks != NULL)
                {
                $sql .= " AND " . $marks . " between percent_from And percent_to";
                }
            $sql .= " order by id ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function genrate_question_paper($msid = NULL, $class_id = NULL, $subject = NULL, $chapter = NULL, $d_level = NULL, $sub_subject = NULL, $importance = NULL, $typeid = NULL, $typesubsubject = NULL)
        {
        try
            {
            $sql = "SELECT @RN:=CASE WHEN FIN.OPTIONS=0 && FIN.SUB_QUESTION=1 THEN @RN+1 WHEN (FIN.OPTIONS*2)%(LEFT(FIN.row_number,1)%2=0)=0 and FIN.row_number<=(FIN.OPTIONS*2) THEN @RN  WHEN FIN.SUB_QUESTION!=1 THEN FIN.QUESTION_FROM else @RN+1 END AS row_num ,FIN.* from
(SELECT @rn:=CASE WHEN F.OPTIONS=0 and @type=F.TYPE_ID THEN @rn+1 WHEN F.OPTIONS>0 and (F.OPTIONS*2)%(LEFT(F.row_number,1)%2=0)=0  and F.row_number<=(F.OPTIONS*2)  THEN @rn WHEN  F.OPTIONS>0  and F.row_number>=(F.OPTIONS*2) THEN @rn+1  ELSE 1 END AS row_numbers,@type:=F.TYPE_ID AS TID,F.* from (SELECT 

Z.row_number,Z.SUBSUBJECT, Z.SUBJECT, Z.CLASS, Z.STATEMENT,Z.MARKS,S.SECTION_NAME,S.OPTIONS,S.QUESTION_FROM,S.QUESTION_TO,S.TYPE_ID,Z.m,Z.STATUS,S.SUB_QUESTION from (SELECT @row_number:=CASE WHEN @mark=TYPE_ID THEN @row_number+1 

ELSE 1 END AS row_number,@mark:=TYPE_ID AS 

m,Q.*
FROM(  SELECT * FROM ms_questionbank where  MSID='" . $msid . "'";

            if ($chapter != NULL)
                {
                $sql.= " And CHAPTER IN('" . $chapter . "')";
                }
            if ($d_level != NULL)
                {
                $sql.= "and LEVEL_ID in('" . $d_level . "')";
                }
            $sql .=" and CLASS='" . $class_id . "' and SUBJECT='" . $subject . "'";
            if ($importance != NULL)
                {
                $sql.=" and IMPORTANCE_LEVEL IN ('" . $importance . "')";
                }
            $sql .=" and STATUS IN('2')";
            if ($sub_subject != NULL)
                {
                $sql.=" and SUBSUBJECT IN ('" . $sub_subject . "')";
                }
            $sql .=" Order by RAND()) Q, (SELECT 

@row_number:=0,@mark:='') AS t
ORDER BY Q.MARKS,Q.TYPE_ID,Q.STATUS) as Z inner join ms_format S on S.MSID=Z.MSID and S.CLASS=Z.CLASS and S.SUBJECT=Z.SUBJECT  and S.TYPE_ID=Z.m and S.SUBSUBJECT=Z.SUBSUBJECT and S.CATEGORY=Z.CATEGORY where 

Z.row_number<=(S.QUESTION_TO-S.QUESTION_FROM+S.OPTIONS+S.SUB_QUESTION) order by S.SECTION_NAME,Z.TYPE_ID,Z.row_number) F,(SELECT @rn:=0,@type:='') FF) FIN,(SELECT @RN:=0,@option:='') AS FX";
            if ($typeid != NULL)
                {
                $sql .=" Where FIN.TID='" . $typeid . "'";
                }
            if ($typesubsubject != NULL)
                {
                $sql.=" And FIN.SUBSUBJECT ='" . $typesubsubject . "'";
                }
            if ($class_id != NULL)
                {
                $sql.=" And FIN.CLASS ='" . $class_id . "'";
                }
            if ($subject != NULL)
                {
                $sql.=" And FIN.SUBJECT ='" . $subject . "'";
                }
            $sql .=" order by FIN.Question_from ,FIN.row_number ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_streamsubject($msid = NULL, $subject = NULL)
        {
        try
            {
            $sql = "SELECT distinct SG.`group_id`, MS.`stream`, SA.`subject_id` subid, SA.`subject_f_name`, SS.`subject_id` FROM `ms_schoolwise_subjects` SS inner join `ms_subjects_all` SA On SA.`subject_f_name` Like SS.`name` Inner join `ms_subjects_group` SG ON SA.`subject_id`=SG.`subject_id` Inner join `ms_subjects` MS On SG.`group_id`=MS.`subject_gp_id`  And MS.`MSID`=SS.`MSID` WHERE SS.`MSID`='" . $msid . "' And SS.`subject_id`='" . $subject . "' Limit 1";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    }

?>
