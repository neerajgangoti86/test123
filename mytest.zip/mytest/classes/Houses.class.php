<?php

class Houses {

    /**
     * get houses name  
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_houses($msid = NULL, $id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "houses";

            if ($id != NULL) {
                $sql .= " where id=" . $id;
            }else{
			    $sql .= " where MSID=" . $msid;
			}
            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
//  $sql = "Select count(T.id) NORt ,T.`TrDate`,T.`tr_id_no`,T.`username`,T.`cost_center` AcNo,Sum(T.`Amt`) FeeAmt,Sum(T.`late_fee`) Late_Fee,Sum(T.`EOD`) EOD,Sum(T.`Amt`+T.`late_fee`+T.`EOD`) TotalAmt From Vu_39Transactions T INNER JOIN (SELECT * FROM ms_slusers_new WHERE MyUId = '" . $uid . "') CU ON T.msid=CU.msid and T.Session=CU.MySession And T.TrDate BETWEEN CU.my_Period_from And CU.my_Period_to Group By T.`cost_center";
     public static function get_daily_fee_recive2($uid = NULL) {
        try {
            $sql = "Select count(T.id) NORt , T.`TrDate`, T.`sr_no`, T.`type`,T.`time_stamp`,T.`username`,T.`cost_center` AcNo,Sum(T.`Amt`) FeeAmt,Sum(T.`late_fee`) Late_Fee,Sum(T.`EOD`) EOD,Sum(T.`Amt`+T.`late_fee`+T.`EOD`) TotalAmt From Vu_39Transactions T INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId = '".$uid."') CU ON T.msid=CU.msid and T.Session=CU.MySession And T.TrDate BETWEEN CU.my_Period_from And CU.my_Period_to Group By T.`cost_center` ORDER BY T.id ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) 
        {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function print_fee_receipt($uid = NULL) {
        try {
            $sql = "Select count(T.id) NORt ,T.id, T.`TrDate`, T.`sr_no`, T.`type`, T.`time_stamp`,T.`party_refference`,T.`username`,T.`cost_center` AcNo,Sum(T.`Amt`) FeeAmt,Sum(T.`late_fee`) Late_Fee,Sum(T.`EOD`) EOD,Sum(T.`Amt`+T.`late_fee`+T.`EOD`) TotalAmt From Vu_39Transactions T INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId = '".$uid."') CU ON T.msid=CU.msid and T.Session=CU.MySession And T.TrDate BETWEEN CU.my_Period_from And CU.my_Period_to Group By T.`party_refference` ORDER BY T.id ASC";
           // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) 
        {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
   public static function get_daily_fee_recive_month($uid = NULL) {
        try {
            $sql = "SELECT MONTH(T.TrDate)as sr_no,CONCAT(MonthName(T.TrDate),',',YEAR(T.TrDate)) AS Month,SUM(T.`Amt`+T.`late_fee`+T.`EOD`) as AMOUNT FROM (SELECT * FROM ms_slusers WHERE MyUId = '".$uid."') CU INNER JOIN Vu_39Transactions T ON T.msid=CU.msid AND T.Session=CU.MySession AND T.V_Id='2' GROUP BY MONTH(T.TrDate) ORDER BY T.TrDate";
          // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) 
        {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    } 
    
     public static function get_daily_fee_recive_month_day($uid = NULL,$month = NULL) {
        try {
            $sql = "SELECT T.TrDate AS Date, SUM(T.`Amt`+T.`late_fee`+T.`EOD`) AMOUNT FROM (SELECT * FROM `ms_slusers` WHERE MyUId= '".$uid."') CU INNER JOIN Vu_39Transactions T ON T.msid=CU.msid AND T.Session=CU.MySession AND T.V_Id='2' WHERE Month(T.TrDate)='$month' GROUP BY T.TrDate ORDER BY T.TrDate";
          // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) 
        {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    } 
    
    public static function get_daily_fee_recive_day($uid = NULL,$date= NULL) {
        try {
            $sql = "SELECT T.Id AS TrId, T.`Amt` FeeAmt,`late_fee`,`EOD`,(`Amt`+`late_fee`+`EOD`) NetRd FROM (SELECT * FROM `ms_slusers` WHERE MyUId='".$uid."') CU INNER JOIN Vu_39Transactions T ON T.msid=CU.msid AND T.Session=CU.MySession AND T.V_Id='2' WHERE T.TrDate='$date'  ORDER BY T.Id";
          // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) 
        {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    } 
    
    
    
    
    
    
    public static function get_daily_fee_recive($uid = NULL, $mydate = NULL) {
        try {
            $sql = "Select count(T.id) NORt ,T.`TrDate`,T.`username`,T.`cost_center` AcNo,Sum(T.`Amt`) FeeAmt,Sum(T.`late_fee`) Late_Fee,Sum(T.`EOD`) EOD,Sum(T.`Amt`+T.`late_fee`+T.`EOD`) TotalAmt From Vu_39Transactions T INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId = '".$uid."') CU ON T.msid=CU.msid and T.Session=CU.MySession And T.TrDate='".$mydate."' Group By T.`cost_center";
                
//Select T.`TrDate`,T.`tr_id_no`,T.`username`,T.`cost_center` AcNo,B.FatherName,B.Village,T.`Amt` FeeAmt,T.`late_fee` as Late_Fee,T.`EOD`,T.`Amt`+T.`late_fee`+T.`EOD` TotalAmt From Vu_39Transactions T 
//Inner Join (SELECT Distinct `MSID`, `AcNo`, `Session`,  `FatherName`, `Village`, `MobileSMS` FROM `ms_fee_billing` WHERE 1) B ON B.AcNo=T.Cost_Center 
//where T.username='".$uid."' And T.TrDate='".$mydate."' order by T.id";
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) 
        {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    public static function get_daily_fee_recive_dr($uid = NULL, $dr=NULL) {
        try {
            $sql = "Select count(T.id) NORt ,T.`TrDate`,T.`dr`,T.`time_stamp`,T.`username`,T.`cost_center` AcNo,Sum(T.`Amt`) FeeAmt,Sum(T.`late_fee`) Late_Fee,Sum(T.`EOD`) EOD,Sum(T.`Amt`+T.`late_fee`+T.`EOD`) TotalAmt From Vu_39Transactions T INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId = '". $uid."') CU ON T.msid=CU.msid and T.Session=CU.MySession And T.TrDate<=CU.Mydate Where T.dr='".$dr."' Group By T.`cost_center` ORDER BY T.id ASC";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) 
        {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    
    /*public static function get_daily_fee_recive_total($uid = NULL, $mydate = NULL) {
        try {
            $sql = "Select T.`TrDate`,T.`tr_id_no`,T.`cost_center` AcNo,B.FatherName,B.Village,T.`Amt` FeeAmt,T.`late_fee`,T.`EOD`,T.`Amt`+T.`late_fee`+T.`EOD` TotalAmt,SUM(T.`Amt`+T.`late_fee`+T.`EOD`) as total_amount From Vu_39Transactions T 
Inner Join (SELECT Distinct `MSID`, `AcNo`, `Session`,  `FatherName`, `Village`, `MobileSMS` FROM `ms_fee_billing` WHERE 1) B ON B.AcNo=T.Cost_Center 
where T.username='".$uid."' And T.TrDate='".$mydate."'";
            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }*/

  public static function get_discount_name($msid = NULL, $id = NULL)
  {
      try
      {
          $sql = "SELECT * FROM " . DB_PREFIX . "discount_names";
         
          $sql .= " where MSID=" . $msid;
          
          $sql .= " AND discount_id=" . $id;
          
          
          
           $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;  
            
          
      } 
      catch (Exception $ex) 
      {
          $message = new Messages();
          $message->add('e', $ex->getMessage());
      }
      
      
  }
    
  
  
public static function del_stu_discount($msid = NULL ,$id = NULL ,$date_from = NULL)
{
    
    try {

            $oDb = DBConnection::get();
            $upsql = $oDb->prepare("Delete From `discounted_student` where `id`='$id' AND `MSID`='$msid' AND date_from ='$date_from'");
//            print_r($upsql);
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
     

    
    
}
    
    
  public static function getDiscountRules($msid = NULL, $id = NULL, $limit = 'all',$data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT DS.*,FN.fee_name,DN.name as discount_name FROM " . DB_PREFIX . "discount_rule as DS";
			$sql .= " INNER JOIN " . DB_PREFIX . "fee_names as FN on DS.fee_id=FN.fee_id AND DS.MSID=FN.MSID";
			$sql .= " INNER JOIN " . DB_PREFIX . "discount_names as DN on DS.discount_id=DN.discount_id AND DS.MSID=DN.MSID";

            if ($id != NULL) {
                $sql .= " where DS.id=" . $id;
            }else{
			    $sql .= " where DS.MSID=" . $msid;
			}
			$sql .= " AND '".$_SESSION['user_date']."' BETWEEN DS.date_from AND DS.date_to";
            $sql .= " order by id ASC";
            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    public function add_house($id = NULL, $postdata = array())
    {
        
         $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['houses_sname'])) == 0)
                $message->add('e', 'House short name is required..!!');
          
            if (strlen(trim(@$postdata['houses_fname'])) == 0)
                $message->add('e', 'House full name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'houses SET house_s_name = :house_s_name, house_f_name = :house_f_name WHERE id = :id');
                    $upsql->execute(array(
                        
                        ':house_s_name' => $postdata['houses_sname'],
                        ':house_f_name'=> $postdata['houses_fname'],
                        ':id'=>$id
                    ));
                    $message->add('s', 'House Name Field updated successfully!', CLIENT_URL . '/houses');
                    exit();
                } else {//insert into database
				   $sqldsid = "SELECT * FROM ".DB_PREFIX."houses where MSID=".$postdata['MSID']." order by house_id DESC limit 1";
				   
				   $sqldsid = $oDb->query($sqldsid);
				   $sqldsrslt = $sqldsid->fetch(PDO::FETCH_OBJ);
				   if($sqldsid->rowCount() > 0){ $houseID = $sqldsrslt->house_id+1;}else{$houseID =1;}
                   $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'houses (MSID, house_id, house_s_name, house_f_name) VALUES  (:MSID, :house_id, :house_s_name, :house_f_name)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
		        ':house_id' => $houseID,
                        ':house_s_name' => $postdata['houses_sname'],
                        ':house_f_name'=> $postdata['houses_fname']
                    ));
                    $message->add('s', 'House is added successfully!', CLIENT_URL . '/houses');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }

        
        
    }
    
    
    
    
    
    
    public function add_discount($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['name'])) == 0)
                $message->add('e', 'Discount Name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'discount_names SET name = :name WHERE id = :id');
                    $upsql->execute(array(
                        ':name' => $postdata['name'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Discount Name Field updated successfully!', CLIENT_URL . '/discount');
                    exit();
                } else {//insert into database
				   $sqldsid = "SELECT * FROM ".DB_PREFIX."discount_names where MSID=".$postdata['MSID']." order by discount_id DESC limit 1";
				   
				   $sqldsid = $oDb->query($sqldsid);
				   $sqldsrslt = $sqldsid->fetch(PDO::FETCH_OBJ);
				   if($sqldsid->rowCount() > 0){ $disconutID = $sqldsrslt->discount_id+1;}else{$disconutID =1;}
                   $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'discount_names (MSID, discount_id, name) VALUES  (:MSID, :discount_id, :name)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
						':discount_id' => $disconutID,
                        ':name' => $postdata['name']
                    ));
                    $message->add('s', 'Discount is added successfully!', CLIENT_URL . '/discount');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

}

?>
