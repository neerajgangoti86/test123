<?php

class Student {
    
    /**
     * Update Student Password
     */
    public static function update_pasword($msid = NULL, $uid = NULL, $post)
        {
        $message = new Messages();
        $oDb = DBConnection::get();

        try
            {

            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET password = :password  WHERE MSID = :MSID AND uid = :uid');
            $upsql->execute(array(
                ':password' => $post,
                ':MSID' => $msid,
                ':uid' => $uid
            ));
            ActivityFeed::add_feeds($_SESSION['oCurrentUser']->MSID, $_SESSION['oCurrentUser']->user_id, $_SESSION['oCurrentUser']->myuname, $_SESSION['oCurrentUser']->ulevel, 'Changed Password', '', '', '', '', '');
            if($upsql){
            $message->add('s', 'Password updated successfully! <a href="'.CLIENT_URL.'" >Click Here</a> to Open Dashboard', CLIENT_URL . '/password');
            
            }
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    /**
     * get student for school
     */
    public static function get_std_count($msid = NULL, $parentid = NULL) {
        $sql = " SELECT `student_id` FROM `ms_students` WHERE `parent_id`='" . $parentid . "' AND MSID='" . $msid . "'";
//        print_r($sql);
        //print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_stdnt_enroll($msid = NULL, $id = NULL) {
        $sql = " SELECT * from ms_students_enrole as student";
        $sql .= " WHERE student.MSID=" . $msid . " AND student.id= " . $id;
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_stdnt($msid = NULL, $id = NULL) {
        $sql = " SELECT * from ms_students ";
        $sql .= " WHERE MSID=" . $msid . " AND student_id= " . $id;
//        print_r($sql);
//        exit();
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_stdnt_for_fee($uid = NULL, $sid = NULL) {
        $sql = " SELECT S.acno,S.opening_bal,S.student_id,S.name,S.gender,P.f_name FROM ms_students S INNER JOIN  (SELECT * FROM `ms_slusers` WHERE MyUid='" . $uid . "') CU ON S.msid = CU.msid  left join ms_parents P on P.MSID= S.MSID and P.id = S.parent_id left join ms_locality L on L.MSID= S.MSID and P.village =L.id LEFT JOIN ms_locality_b LB ON L.post_id =LB.Id  Where S.`student_id` ='" . $sid . "' ";
//        print_r($sql);
//        exit();
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_stdnt_history($msid = NULL, $id = NULL, $s_id = NULL) {
        $sql = " SELECT * from ms_history ";
        $sql .= " WHERE MSID=" . $msid;
        if (@$id) {
            $sql .= " AND id= " . $id;
        }
        if (@$s_id) {
            $sql .= " AND s_id= " . $s_id;
        }
//        print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_history_worning($id = NULL) {
        $sql = " SELECT * from ms_history_wornings ";
        if (@$id) {
            $sql .= " Where id= " . $id;
        }
//        print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_parent_id($msid = NULL, $stu_id = NULL) {
        $sql = " SELECT * from ms_students_enrole";
        $sql .= " WHERE MSID=" . $msid . " AND student_id= " . $stu_id;
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_parent($msid = NULL, $id = NULL) {
        $sql = " SELECT * from ms_parents as parent";
        $sql .= " WHERE parent.MSID=" . $msid . " AND parent.id= " . $id;
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_stu_info($msid = NULL, $id = NULL, $acno = NULL) {
        try {
            $sql = " SELECT * from ms_students";
            $sql .= " WHERE MSID=" . $msid;
            if (@$id) {
                $sql .= " AND student_id= " . $id;
            }
            if (@$acno) {
                $sql .= " AND acno= " . $acno;
            }

            //print_r($sql);


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /* Get Parent Info */

    public static function get_parent_info($msid = NULL, $id = NULL) {

        try {
            $sql = " SELECT * from ms_parents ";
            $sql .= " WHERE MSID=" . $msid . " AND id= " . $id;
            // print_r($sql);



            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function get_stu_traninfo($msid = null, $id = null) {

        try {
            $sql = " SELECT * from ms_tpt_std ";
            $sql .= " WHERE MSID=" . $msid . " AND S_id= " . $id;
            // print_r($sql);
            $sql .= " order by id desc";
            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    //public function get_transport_
    

    public static function get_ms_students($msid = NULL, $student_id = NULL) {
//    SELECT * FROM `ms_schools_section` WHERE MSID = '1001' AND `class_id` = '0'
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "students WHERE `MSID` = '" . $msid . "'";
            if (@$student_id != NULL) {
                $sql .= "AND `student_id` = '" . $student_id . "'";
            }
            //   print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_student_test_subject($msid = NULL, $class = NULL, $startDate = NULL, $endDate = NULL, $session = NULL) {

        try {
            //SELECT DISTINCT `SubjectId` FROM `ms_exam_weeklytest` WHERE `MSID` = '1001'
            $sql = "SELECT DISTINCT `SubjectId`, `Date` FROM " . DB_PREFIX . "exam_weeklytest WHERE `MSID` = '" . $msid . "' ";

            if (@$class != NULL) {
                $sql .= "AND `Class` = '" . $class . "' ";
            }

            if (@$startDate != NULL && @$endDate != NULL) {
                $sql .= "AND `Date` BETWEEN '" . $startDate . "' AND '" . $endDate . "'";
            }

            if ($session != NULL) {
                $sql .= " AND `Session` = '" . $session . "'";
            }
            //   print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_students($uid = NULL, $limit = 'all', $id = NULL, $parentid = NULL, $where = array('page' => 1, 'record_per_page' => 10), $search = NULL) {
        try {

//            print_r($where); 
            //exit();
//        $sql="select A.section,A.adm_classno,A.adm_class_name,A.opening_bal,A.annual_income,A.sec_name,A.class,CL.class_name,A.s_uid,A.s_pwd,A.uid,A.password,A.parent_id,A.Category_short,A.student_id,A.stream,A.main_group,A.sub_group,A.group_id,A.name,A.birth_date,A.f_name,A.m_name,A.roll_no,A.photo,A.aadhar,A.blood_group,A.admno,A.adm_date,A.gender,A.mobile_sms,A.acno,A.village,A.postoffice,A.Tehsil,A.District,A.State,A.pincode,A.house,A.f_name,A.m_name,A.mobile_sms,A.vilage_id,A.f_mobile,A.m_mobile,A.f_occupation,A.phone_home,A.address_line1,A.address_line2,A.address,A.f_qualification,A.m_qualification,A.m_occupation from ( SELECT S.MSID,S.student_id as s_id,(S.adm_classno + CU.MySession-year (S.fees_date)+COALESCE(sum(E.result),0)) as class,S.roll_no,S.aadhar,S.gender,S.admno,CLA.class_name adm_class_name,S.photo,S.adm_date,S.blood_group,S.name,S.acno,S.stream,S.main_group,S.sub_group,S.group_id,S.student_id,S.birth_date,P.f_name,P.m_name,P.village as vilage_id,P.mobile_sms,P.category,P.f_mobile,P.m_mobile,P.annual_income,P.f_occupation,P.m_occupation,P.phone_home,P.address_line1,P.address_line2,P.address,P.f_qualification,P.m_qualification,L.name as village,If(L.post_id='',L.postoffice,LB.postoffice)postoffice,If(L.post_id='',L.tehsil,LB.tehsil)Tehsil,If(L.post_id='',L.district,LB.district)district,If(L.post_id='',L.state,LB.state)state,If(L.post_id='',L.pincode,LB.pincode)pincode,H.house_f_name as house,S.adm_classno,S.opening_bal,S.parent_id,S.uid as s_uid,S.password as s_pwd,P.uid,P.password,S.section,Sec.sec_name,C.Name category_Name,C.Short_Name category_short FROM `ms_students` S INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='1001vm1')CU ON CU.msid=S.msid AND CU.MyDate Between S.Fees_Date AND S.sl_Date left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id left join ms_parents P on P.MSID= S.MSID and P.id = S.parent_id left join ms_locality L on L.MSID= S.MSID and P.village =L.id LEFT JOIN ms_locality_b LB ON L.post_id =LB.Id left join ms_houses H on H.MSID= S.MSID and H.house_id= S.house left join ms_category C on C.MSID= S.MSID and C.cat_id= P.category INNER JOIN ms_classes CLA ON CLA.MSID=S.MSID AND CLA.class_no=S.adm_classno group by S.student_id ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And CC.class_to AND A.class= '1' INNER JOIN ms_classes CL ON CL.msid=A.msid AND CL.class_no=A.Class limit 0,10
//
//";
            $sql = " select A.section,A.adm_classno,A.adm_class_name,A.opening_bal,A.annual_income,A.sec_name,A.class,CL.class_name,A.s_uid,A.s_pwd,A.uid,A.password,A.parent_id,A.Category_short,A.student_id,A.stream,A.main_group,A.sub_group,A.group_id,A.name,A.sl_date,A.feepaidupto,A.TcIssueDate,A.extra_activities,A.birth_date,A.f_name,A.m_name,A.roll_no,A.photo,A.aadhar,A.blood_group,A.admno,A.adm_date,A.gender,A.mobile_sms,A.acno,A.village,A.postoffice,A.tehsil,A.district,A.state,A.pincode,A.house,A.f_name,A.m_name,A.mobile_sms,A.category,A.vilage_id,A.f_mobile,A.m_mobile,A.f_occupation,A.feepaymentmode,A.phone_home,A.address_line1,A.address_line2,A.address,A.f_qualification,A.m_qualification,A.religion,A.m_occupation from ( SELECT S.MSID,S.student_id as s_id,(S.adm_classno + CU.MySession-year (S.fees_date)+COALESCE(sum(E.result),0)) as class,S.roll_no,S.aadhar,S.gender,S.admno,CLA.class_name adm_class_name,S.photo,S.adm_date,S.blood_group,S.name,S.acno,S.stream,S.main_group,S.sub_group,S.group_id,S.student_id,S.sl_date,S.feepaidupto,S.TcIssueDate,S.extra_activities,S.birth_date,P.f_name,P.m_name,P.village as vilage_id,P.mobile_sms,P.category,P.f_mobile,P.m_mobile,P.annual_income,P.f_occupation,P.m_occupation,P.phone_home,P.address_line1,P.address_line2,P.feepaymentmode,P.address,P.f_qualification,P.m_qualification,P.religion,L.name as village,If(L.post_id='',L.postoffice,LB.postoffice)postoffice,If(L.post_id='',L.tehsil,LB.tehsil)tehsil,If(L.post_id='',L.district,LB.district)district,If(L.post_id='',L.state,LB.state)state,If(L.post_id='',L.pincode,LB.pincode)pincode,H.house_f_name as house,S.adm_classno,S.opening_bal,S.parent_id,S.uid as s_uid,S.password as s_pwd,P.uid,P.password,S.section,Sec.sec_name,C.Name category_Name,C.Short_Name category_short FROM `ms_students` S ";
            $sql .="INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='" . $uid . "')CU ON CU.msid=S.msid AND CU.MyDate Between S.Fees_Date AND S.sl_Date left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id left join ms_parents P on P.MSID= S.MSID and P.id = S.parent_id left join ms_locality L on L.MSID= S.MSID and P.village =L.id LEFT JOIN ms_locality_b LB ON L.post_id =LB.Id left join ms_houses H on H.MSID= S.MSID and H.house_id= S.house left join ms_category C on C.MSID= S.MSID and C.cat_id= P.category INNER JOIN ms_classes CLA ON CLA.MSID=S.MSID AND CLA.class_no=S.adm_classno  ";
//            print_r($where);

            if (@$where) {
//                echo "sds";
                $sql .= "Where 1 ";
                if (@$where['newadmission'] || @$where['outgoing'] || @$where['alumini']) {
                    if (@$where['newadmission']) {
                        $sql .= " AND S.fees_date BETWEEN '" . $where['start'] . " 00-00-00' AND '" . $where['ends'] . " 00-00-00' ";
                    }
                    if (@$where['outgoing']) {
                        $sql .= " AND S.sl_date BETWEEN DATE_SUB( '" . $where['start'] . " 00-00-00',INTERVAL 1 DAY)  AND  DATE_SUB('" . $where['ends'] . " 00-00-00' ,INTERVAL 1 DAY)  ";
                    }
                    if (@$where['alumini']) {
                        $sql .= " AND S.sl_date BETWEEN DATE_SUB( '" . $where['start'] . " 00-00-00',INTERVAL 1 DAY)  AND  DATE_SUB('" . $where['ends'] . " 00-00-00' ,INTERVAL 1 DAY)  ";
                    }
                } else {
//                    $sql .="AND '" . $_SESSION['user_date'] . "' between S.fees_date and S.sl_date";
                    if (@$where['field_name']) {
                        if ($where['field_name'] == "transportation" && $where['field_value'] == "0") {
                            $sql .= " AND (S." . $where['field_name'] . "='' OR S." . $where['field_name'] . " IS NULL )";
                        } else if ($where['field_name'] == "transportation" && $where['field_value'] == "1") {
                            $sql .= " AND (S." . $where['field_name'] . "!='' OR S." . $where['field_name'] . " IS NOT NULL )";
                        } else if ($where['field_name'] == "section") {
                            $sql .= " AND S." . $where['field_name'] . "='" . $where['field_value'] . "'";
                        } else if ($where['field_name'] == "category") {
                            $sql .= " AND P." . $where['field_name'] . "='" . $where['field_value'] . "'";
                        } else {
                            if ($where['field_name'] != 'page')
                                $sql .= " AND S." . $where['field_name'] . "='" . $where['field_value'] . "'";
                        }
                    }
                }
            }

            if ($search != '') {
                $local = Master::get_locality_name($msid, $search)->fetch();

                $sql .= " AND S.student_id  LIKE  '$search%' OR S.name LIKE '$search%' OR P.f_name LIKE '$search%' OR  P.m_name LIKE '$search%' OR P.mobile_sms LIKE '%$search%' OR  P.village LIKE '$local[id]' ";
            }

            if (@$id) {
                $sql .=" AND S.student_id= '" . $id . "'";
            }
            $sql .=" group by S.student_id 
                ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And CC.class_to ";
            if (@$where['class'] || @$where['class'] == '0') {
                $sql.=" AND A.class= '" . $where['class'] . "'";
            }

            $sql .="  INNER JOIN ms_classes CL ON CL.msid=A.msid AND CL.class_no=A.class order by A.student_id";

            if ($limit != 'all') {
                $records_per_page = $where['record_per_page'];
                $starting_position = ($where['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }


//            print_r($where); 
//            print_r($sql);
//             exit();
            //exit(); 


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_students3($uid = NULL, $limit = 'all', $id = NULL, $parentid = NULL, $where = array('page' => 1, 'record_per_page' => 10), $search = NULL, $section_id = NULL) {
        try {
            //print_r($where); 
            //exit();
//        $sql="select A.section,A.adm_classno,A.adm_class_name,A.opening_bal,A.annual_income,A.sec_name,A.class,CL.class_name,A.s_uid,A.s_pwd,A.uid,A.password,A.parent_id,A.Category_short,A.student_id,A.stream,A.main_group,A.sub_group,A.group_id,A.name,A.birth_date,A.f_name,A.m_name,A.roll_no,A.photo,A.aadhar,A.blood_group,A.admno,A.adm_date,A.gender,A.mobile_sms,A.acno,A.village,A.postoffice,A.Tehsil,A.District,A.State,A.pincode,A.house,A.f_name,A.m_name,A.mobile_sms,A.vilage_id,A.f_mobile,A.m_mobile,A.f_occupation,A.phone_home,A.address_line1,A.address_line2,A.address,A.f_qualification,A.m_qualification,A.m_occupation from ( SELECT S.MSID,S.student_id as s_id,(S.adm_classno + CU.MySession-year (S.fees_date)+COALESCE(sum(E.result),0)) as class,S.roll_no,S.aadhar,S.gender,S.admno,CLA.class_name adm_class_name,S.photo,S.adm_date,S.blood_group,S.name,S.acno,S.stream,S.main_group,S.sub_group,S.group_id,S.student_id,S.birth_date,P.f_name,P.m_name,P.village as vilage_id,P.mobile_sms,P.category,P.f_mobile,P.m_mobile,P.annual_income,P.f_occupation,P.m_occupation,P.phone_home,P.address_line1,P.address_line2,P.address,P.f_qualification,P.m_qualification,L.name as village,If(L.post_id='',L.postoffice,LB.postoffice)postoffice,If(L.post_id='',L.tehsil,LB.tehsil)Tehsil,If(L.post_id='',L.district,LB.district)district,If(L.post_id='',L.state,LB.state)state,If(L.post_id='',L.pincode,LB.pincode)pincode,H.house_f_name as house,S.adm_classno,S.opening_bal,S.parent_id,S.uid as s_uid,S.password as s_pwd,P.uid,P.password,S.section,Sec.sec_name,C.Name category_Name,C.Short_Name category_short FROM `ms_students` S INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='1001vm1')CU ON CU.msid=S.msid AND CU.MyDate Between S.Fees_Date AND S.sl_Date left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id left join ms_parents P on P.MSID= S.MSID and P.id = S.parent_id left join ms_locality L on L.MSID= S.MSID and P.village =L.id LEFT JOIN ms_locality_b LB ON L.post_id =LB.Id left join ms_houses H on H.MSID= S.MSID and H.house_id= S.house left join ms_category C on C.MSID= S.MSID and C.cat_id= P.category INNER JOIN ms_classes CLA ON CLA.MSID=S.MSID AND CLA.class_no=S.adm_classno group by S.student_id ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And CC.class_to AND A.class= '1' INNER JOIN ms_classes CL ON CL.msid=A.msid AND CL.class_no=A.Class limit 0,10
//
//";
            $sql = " select A.section,A.adm_classno,A.adm_class_name,A.opening_bal,A.annual_income,A.sec_name,A.class,CL.class_name,A.s_uid,A.s_pwd,A.uid,A.password,A.parent_id,A.Category_short,A.student_id,A.stream,A.main_group,A.sub_group,A.group_id,A.name,A.birth_date,A.f_name,A.m_name,A.roll_no,A.photo,A.aadhar,A.blood_group,A.admno,A.adm_date,A.gender,A.mobile_sms,A.acno,A.village,A.postoffice,A.tehsil,A.district,A.state,A.pincode,A.house,A.f_name,A.m_name,A.mobile_sms,A.category,A.vilage_id,A.f_mobile,A.m_mobile,A.f_occupation,A.feepaymentmode,A.phone_home,A.address_line1,A.address_line2,A.address,A.f_qualification,A.m_qualification,A.m_occupation from ( SELECT S.MSID,S.student_id as s_id,(S.adm_classno + CU.MySession-year (S.fees_date)+COALESCE(sum(E.result),0)) as class,S.roll_no,S.aadhar,S.gender,S.admno,CLA.class_name adm_class_name,S.photo,S.adm_date,S.blood_group,S.name,S.acno,S.stream,S.main_group,S.sub_group,S.group_id,S.student_id,S.birth_date,P.f_name,P.m_name,P.village as vilage_id,P.mobile_sms,P.category,P.f_mobile,P.m_mobile,P.annual_income,P.f_occupation,P.m_occupation,P.phone_home,P.address_line1,P.address_line2,P.feepaymentmode,P.address,P.f_qualification,P.m_qualification,L.name as village,If(L.post_id='',L.postoffice,LB.postoffice)postoffice,If(L.post_id='',L.tehsil,LB.tehsil)tehsil,If(L.post_id='',L.district,LB.district)district,If(L.post_id='',L.state,LB.state)state,If(L.post_id='',L.pincode,LB.pincode)pincode,H.house_f_name as house,S.adm_classno,S.opening_bal,S.parent_id,S.uid as s_uid,S.password as s_pwd,P.uid,P.password,S.section,Sec.sec_name,C.Name category_Name,C.Short_Name category_short FROM `ms_students` S ";
            $sql .="INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='" . $uid . "')CU ON CU.msid=S.msid AND CU.MyDate Between S.Fees_Date AND S.sl_Date left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id left join ms_parents P on P.MSID= S.MSID and P.id = S.parent_id left join ms_locality L on L.MSID= S.MSID and P.village =L.id LEFT JOIN ms_locality_b LB ON L.post_id =LB.Id left join ms_houses H on H.MSID= S.MSID and H.house_id= S.house left join ms_category C on C.MSID= S.MSID and C.cat_id= P.category INNER JOIN ms_classes CLA ON CLA.MSID=S.MSID AND CLA.class_no=S.adm_classno  ";
//            print_r($where);

            if (@$where) {
//                echo "sds";
                $sql .= "Where 1 ";
                if (@$where['newadmission'] || @$where['outgoing'] || @$where['alumini']) {
                    if (@$where['newadmission']) {
                        $sql .= " AND S.fees_date BETWEEN '" . $where['start'] . " 00-00-00' AND '" . $where['ends'] . " 00-00-00' ";
                    }
                    if (@$where['outgoing']) {
                        $sql .= " AND S.sl_date BETWEEN DATE_SUB( '" . $where['start'] . " 00-00-00',INTERVAL 1 DAY)  AND  DATE_SUB('" . $where['ends'] . " 00-00-00' ,INTERVAL 1 DAY)  ";
                    }
                    if (@$where['alumini']) {
                        $sql .= " AND S.sl_date BETWEEN DATE_SUB( '" . $where['start'] . " 00-00-00',INTERVAL 1 DAY)  AND  DATE_SUB('" . $where['ends'] . " 00-00-00' ,INTERVAL 1 DAY)  ";
                    }
                } else {
//                    $sql .="AND '" . $_SESSION['user_date'] . "' between S.fees_date and S.sl_date";
                    if (@$where['field_name']) {
                        if ($where['field_name'] == "transportation" && $where['field_value'] == "0") {
                            $sql .= " AND (S." . $where['field_name'] . "='' OR S." . $where['field_name'] . " IS NULL )";
                        } else if ($where['field_name'] == "transportation" && $where['field_value'] == "1") {
                            $sql .= " AND (S." . $where['field_name'] . "!='' OR S." . $where['field_name'] . " IS NOT NULL )";
                        } else if ($where['field_name'] == "section") {
                            $sql .= " AND S." . $where['field_name'] . "='" . $where['field_value'] . "'";
                        } else if ($where['field_name'] == "category") {
                            $sql .= " AND P." . $where['field_name'] . "='" . $where['field_value'] . "'";
                        } else {
                            if ($where['field_name'] != 'page')
                                $sql .= " AND S." . $where['field_name'] . "='" . $where['field_value'] . "'";
                        }
                    }
                }
            }

            if ($search != '') {
                $local = Master::get_locality_name($msid, $search)->fetch();

                $sql .= " AND S.student_id  LIKE  '$search%' OR S.name LIKE '$search%' OR P.f_name LIKE '$search%' OR  P.m_name LIKE '$search%' OR P.mobile_sms LIKE '%$search%' OR  P.village LIKE '$local[id]' ";
            }

            if (@$id) {
                $sql .=" AND S.student_id= '" . $id . "'";
            }

            /* if(@$section_id)
              {
              $sql.=" AND S.section= '" . $section_id . "'";
              } */

            $sql .=" group by S.student_id 
                ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And CC.class_to ";
            if (@$where['class'] || @$where['class'] == '0') {
                $sql.=" AND A.class= '" . $where['class'] . "'";
            }




            $sql .="  INNER JOIN ms_classes CL ON CL.msid=A.msid AND CL.class_no=A.class";

            if (@$where['section']) {
                $sql.=" AND A.section= '" . $where['section'] . "'";
            }

            //$sql .= " INNER JOIN ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id";

            if ($limit != 'all') {
                $records_per_page = $where['record_per_page'];
                $starting_position = ($where['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }


//            print_r($where['page']);
//            print_r($sql);
//             exit();
            //exit();


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_quick_search($msid = NULL, $separtator = NULL, $limit = 'all', $myuid = NULL, $parentid = NULL, $search = NULL, $where = array('page' => 1, 'record_per_page' => 10)) {
        try {
//            print_r($where);
//            exit();
//            Select L.`name` as village,S.`section`, S.`acno`,(S.adm_classno + CU.MySession-year (S.fees_date)+COALESCE(sum(E.result),0)) as class, S.`house`,S.`gender`,S.`blood_group`,S.`admno`,S.`adm_date`,S.`roll_no`,S.`student_id`,S.`name`,S.`birth_date`,Concat(Day(S.birth_date),"-",Month(S.birth_date)) BirthDay,S.`aadhar`,P.`f_name`,P.`f_mobile`,P.`m_name`,P.`m_mobile`,P.`mobile_sms`,L.`name` Locality From (SELECT * FROM `ms_slusers` WHERE `myuid` = "1001vm7" ) CU Inner Join ms_students S On S.msid=CU.msid And CU.mydate between S.Fees_Date And S.Sl_Date Inner Join ms_parents P ON P.MSID=CU.MSID And P.Id=S.Parent_Id Inner Join ms_locality L On L.Id=P.Village  left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id AND E.`date_result` < CU.`MyDate`  WHERE S.msid=1001 AND S.`student_id`="16044" OR S.`name` Like "16044%" OR S.`name` Like "%16044" OR P.`f_name` Like "16044%" OR P.`m_name` Like "%16044" OR `f_mobile`= "16044" OR P.`m_mobile`= "16044" OR P.`mobile_sms`= "16044" OR L.`name` Like "16044%" OR Concat(Day(S.birth_date), "-",Month(S.birth_date)) = "16044"

            $sql = "select * from (SELECT S.student_id,S.name, S.admno, S.house, P.`f_name`,P.`f_mobile`,P.`m_mobile`,P.`m_name`,S.`birth_date`,S.`acno`,H.`house_f_name` housec,S.`gender`,S.`blood_group`,S.`aadhar`,P.`mobile_sms`,L.`name` village,TPTS.`station_name`,DN.`name` Discount FROM(SELECT CU.*,S.`student_id`,S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) CClass,K.`class_from`,K.`class_to` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='" . $myuid . "') CU ON S.msid=CU.msid And S.`fees_date` <= CU.`ends` AND S.`sl_date` >= CU.`Begins` INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < CU.`mydate` GROUP BY S.`student_id` HAVING CClass Between K.`class_from` AND K.`class_to`) CS INNER JOIN ms_students S ON S.msid=CS.msid AND S.student_id=CS.student_id Left Join ms_parents P ON P.id=S.Parent_id Left Join ms_locality L ON P.`village`=L.`id` Left Join ms_houses H on H.msid=CS.msid And S.house=H.house_id Left Join ms_tpt_std TP On TP.msid=CS.msid AND TP.`S_id`=S.student_id AND CS.myDate Between TP.`date_from` AND TP.`date_to` Left Join ms_tpt_stations TPTS ON TPTS.`station_id`=TP.`tpt_stn_id` Left Join ms_discounted_student DS ON DS.msid=CS.msid AND DS.`s_id`=CS.`student_id` AND CS.MyDate Between DS.`date_from` AND DS.`date_to` Left Join ms_discount_names DN ON DN.msid=CS.msid AND DN.discount_id=DS.`discount_id`";

            $sql .= " WHERE ";

            if ($search != '') {

                $sql .= ' S.`student_id`="' . $search . '"';
                $sql .= ' OR S.`admno` Like "' . $search . '"';
                $sql .= '  OR S.`name` Like "' . $search . '%"  OR S.`name` Like "%' . $search . '"';
                $sql .= ' OR P.`f_name` Like "' . $search . '%" OR P.`f_name` Like "%' . $search . '"';
                $sql .= ' OR P.`m_name` Like "' . $search . '%"';
                $sql .= ' OR P.`mobile_sms` = "' . $search . '"';
                $sql .=' OR P.`f_mobile`= "' . $search . '"';
                $sql .=' OR P.`m_mobile`= "' . $search . '"';
                $sql .=' OR L.name Like "' . $search . '%"';
                $sql .=' OR Concat(Day(S.birth_date), "' . $separtator . '",Month(S.birth_date)) = "' . $search . '"';

                //               $sql .=' OR S.`blood_group` ="' . $search . '" OR S.`aadhar` = "' . $search . '"';
//               $sql .=' OR DN.name = "' . $search . '"';
            }

            if ($limit != 'all') {
                $records_per_page = $where['record_per_page'];
                $starting_position = ($where['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }

            $sql .= " ) sql1 where sql1.student_id > 0 ";
//            print_r($sql);          


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fail_student($msid = NULL, $limit = 'all', $id = NULL, $parentid = NULL, $where = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "students as student";
            $sql .= " LEFT JOIN " . DB_PREFIX . "parents as parent ON parent.id = student.parent_id";
            $sql .= " LEFT JOIN " . DB_PREFIX . "exams as exam ON exam.s_id = student.id";
            $sql .= " where student.MSID=" . $msid . " AND (student.admno != '' OR student.admno IS NOT NULL) ";

            if (!empty($where)) { // For New Admission ,Outgoing And Current
//                    if (@$where['fail'])
//                        $sql .= " AND student.fees_date BETWEEN '" . $where['start'] . " 00-00-00' AND '" . $where['ends'] . " 00-00-00' ";
                $sql .= "  LEFT JOIN (SELECT exam.s_id, Sum(exam.result) AS SumResult FROM ms_exam E WHERE (((E.MSID)='$msid') AND ((E.date_result)<'" . $where['start'] . " 00-00-00')) GROUP BY E.s_id ) AS Q1 ON student.id = Q1.s_id WHERE student.MSID='$msid' And student.fees_date<='" . $where['ends'] . " 00-00-00' AND student.sl_date>'" . $where['ends'] . " 00-00-00' And parent.MSID='$msid'   And exam.MSID='$msid'    And exam.result='-1'   GROUP BY S.id, COALESCE(SumResult,0)";
            }
//                for the session wise 
            if ($id != NULL) {
                $sql .= " AND student.id=" . $id . " OR student.student_id=" . $id;
            }
            if ($parentid != NULL) {
                $sql .= " AND student.parent_id=" . $parentid;
            }
            $sql .= " order by student.id ASC";
            if ($limit != 'all') {
                $records_per_page = $where['record_per_page'];
                $starting_position = ($where['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            //   print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_alumini_students($msid = NULL, $limit = 'all', $id = NULL, $parentid = NULL, $where = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "students as student";
            $sql .= " LEFT JOIN " . DB_PREFIX . "parents as parent ON parent.id = student.parent_id";
            $sql .= " where student.MSID=" . $msid . " AND (student.admno != '' OR student.admno IS NOT NULL) ";


            if (@$_SESSION['user_date']) {
                $sql .= " AND  student.sl_date<'" . $_SESSION['user_date'] . "'";
            }
            if ($id != NULL) {
                $sql .= " AND student.id=" . $id . " OR student.student_id=" . $id;
            }
            if ($parentid != NULL) {
                $sql .= " AND student.parent_id=" . $parentid;
            }
            $sql .= " order by student.id ASC";
            if ($limit != 'all') {
                $records_per_page = $where['record_per_page'];
                $starting_position = ($where['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//                         print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_outgoing_students($msid = NULL, $limit = 'all', $id = NULL, $parentid = NULL, $where = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "students as student";
            $sql .= " LEFT JOIN " . DB_PREFIX . "parents as parent ON parent.id = student.parent_id";
            $sql .= " where student.MSID=" . $msid . " AND (student.admno != '' OR student.admno IS NOT NULL) ";


            if (@$_SESSION['user_date']) {
                $sql .= " AND  student.sl_date<'" . $_SESSION['user_date'] . "'";
            }
            if ($id != NULL) {
                $sql .= " AND student.id=" . $id . " OR student.student_id=" . $id;
            }
            if ($parentid != NULL) {
                $sql .= " AND student.parent_id=" . $parentid;
            }
            $sql .= " order by student.id ASC";
            if ($limit != 'all') {
                $records_per_page = $where['record_per_page'];
                $starting_position = ($where['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//                         print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function check_account($id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "students";

            $sql .= " where student_id =" . $id;

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message = new Messages();
            $message->add('e', $ex->getMessage());
        }
    }

    public static function update_student($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //insert into database
            if (strlen(trim(@$postdata['name'])) == 0)
                $message->add('e', 'Name is required!');
            if (!$message->hasMessages()) {
                $birth_date = date("Y-m-d H:i:s", strtotime($postdata['dob']));

                $fee_date = date("Y-m-d H:i:s", strtotime($postdata['feesdate1']));

                $adm_date = date("Y-m-d H:i:s", strtotime($postdata['adm_date']));

                $check_status = self::check_account($id);


                $sl_date = date("Y-m-d", strtotime($postdata['sl_date']));



                $check_status_data = $check_status->fetch();


                   if (strtotime($postdata['sl_date']) < strtotime(date("d-m-Y"))) {
                   
                    $Delete = Fee::get_delete_student_from_fee_billing($postdata['msid'], '', $postdata['session'],$id);
                }
                else {
//                   
                    $Delete = Fee::get_delete_student_from_fee_billing($postdata['msid'], '', $postdata['session'],$id);
                    $data_insert = Fee::insert_student_into_fee_billing2($postdata['myuid'],'',$id);
                }

                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET admno = :admno, acno = :acno, adm_date = :adm_date, fees_date =  :fees_date, section = :section, adm_classno = :adm_classno, name = :name, house = :house, birth_date = :birth_date, blood_group = :blood_group, group_id = :group_id, gender = :gender, birth_certificate = :birth_certificate, aadhar = :aadhar, wardofstaff = :wardofstaff, sl_date = :sl_date, opening_bal = :opening_bal WHERE MSID=:msid And student_id = :student_id');
                $upsql->execute(array(
                    ':admno' => @$postdata['adm_no'],
                    ':acno' => @$postdata['acno'],
                    ':adm_date' => $adm_date,
                    ':fees_date' => $fee_date,
                    ':section' => @$postdata['section'],
                    ':adm_classno' => @$postdata['aclass'],
                    ':name' => $postdata['name'],
                    ':house' => @$postdata['house'],
                    ':birth_date' => @$birth_date,
                    ':blood_group' => @$postdata['bgroup'],
                    ':group_id' => @$postdata['groupid'],
                    ':gender' => @$postdata['gender'],
                    ':birth_certificate' => @$postdata['birth_certificate'],
                    ':aadhar' => @$postdata['aadhar'],
                    ':wardofstaff' => @$postdata['wardofstaff'],
                    ':sl_date' => @$sl_date,
                    ':opening_bal' => @$postdata['opening_balance'],
                    ':student_id' => $id,
                    ':msid' => $postdata['msid']
                ));
                $message->add('s', 'Student updated successfully!', CLIENT_URL . '/students/editprofile/' . $id);
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    /* Update Student Info with photo  */

    public static function update_stuinfo_photo($id = NULL, $postdata = array(), $file) {


        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //insert into database
            if (strlen(trim(@$postdata['name'])) == 0)
                $message->add('e', 'Name is required!');
            if (!$message->hasMessages()) {

                if (!empty($file['photo']['name'])) {
                    @$photo_name = "/" . $postdata['msid'] . "/" . time() . "_" . $file['photo']['name'];
                    $upload_image = "uploads/" . $postdata['msid'] . "/" . basename($photo_name);
                    $upload_img = move_uploaded_file($file['photo']['tmp_name'], $upload_image);
                    //die("<>>");
                } else {
                    $upload_img = '';
                }
                //die("<>>");

                $fee_date = date("Y-m-d H:i:s", strtotime($postdata['feesdate1']));

                $adm_date = date("Y-m-d H:i:s", strtotime($postdata['adm_date']));

                $check_status = self::check_account($id);


                $sl_date = date("Y-m-d", strtotime($postdata['sl_date']));



                $check_status_data = $check_status->fetch();


                if (strtotime($postdata['sl_date']) < strtotime(date("d-m-Y"))) {

                    $Delete = Fee::get_delete_student_from_fee_billing($postdata['msid'], '', $postdata['session'], $id);
                } else {
//                   
                    $Delete = Fee::get_delete_student_from_fee_billing($postdata['msid'], '', $postdata['session'], $id);
                    $data_insert = Fee::insert_student_into_fee_billing2($postdata['myuid'], '', $id);
                }
                //update student
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET admno = :admno, acno = :acno, adm_date = :adm_date, fees_date =  :fees_date, section = :section, adm_classno = :adm_classno, name = :name, house = :house, birth_date = :birth_date, blood_group = :blood_group, group_id = :group_id, gender = :gender, birth_certificate = :birth_certificate, aadhar = :aadhar, wardofstaff = :wardofstaff, photo = :photo, sl_date = :sl_date, opening_bal = :opening_bal WHERE MSID=:msid And student_id = :student_id');
                $upsql->execute(array(
                    ':admno' => @$postdata['adm_no'],
                    ':acno' => @$postdata['acno'],
                    ':adm_date' => $adm_date,
                    ':fees_date' => $fee_date,
                    ':section' => @$postdata['section'],
                    ':adm_classno' => @$postdata['aclass'],
                    ':name' => $postdata['name'],
                    ':house' => @$postdata['house'],
                    ':birth_date' => @$birth_date,
                    ':blood_group' => @$postdata['bgroup'],
                    ':group_id' => @$postdata['groupid'],
                    ':gender' => @$postdata['gender'],
                    ':birth_certificate' => @$postdata['birth_certificate'],
                    ':aadhar' => @$postdata['aadhar'],
                    ':wardofstaff' => @$postdata['wardofstaff'],
                    ':photo' => @$photo_name,
                    ':sl_date' => @$sl_date,
                    ':opening_bal' => @$postdata['opening_balance'],
                    ':student_id' => $id,
                    ':msid' => $postdata['msid']
                ));

                $message->add('s', 'Student updated successfully!', CLIENT_URL . '/students/editprofile/' . $id);
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function update_student_doc($msid = NULL, $id = NULL) {


        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "students_docx WHERE ";

            $sql .= " MSID='" . $msid . "'";

            $sql .= " AND s_id='" . $id . "'";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message->add('e', $e->getMessage());
        }
    }

    public function update_stu_doc($msid = NULL, $file = array(), $post = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();





        if (!empty($file['birth_cirtificate']['name'])) {


            @$file_name_birth = time() . "_" . $file['birth_cirtificate']['name'];

            $upload_image_1 = "uploads/student_docx/" . basename(@$file_name_birth);
            $upload_img_1 = move_uploaded_file($file['birth_cirtificate']['tmp_name'], $upload_image_1);
        } else {
            $upload_img_1 = '';
        }
        if (!empty($file['character_cirtificate']['name'])) {

            @$file_name_character = time() . "_" . $file['character_cirtificate']['name'];
            $upload_image_2 = "uploads/student_docx/" . basename(@$file_name_character);
            $upload_img_2 = move_uploaded_file($file['character_cirtificate']['tmp_name'], $upload_image_2);
        } else {
            $upload_img_2 = '';
        } if (!empty($file['other_cirtificate']['name'])) {

            @$file_name_other = time() . "_" . $file['other_cirtificate']['name'];
            $upload_image_3 = "uploads/student_docx/" . basename(@$file_name_other);
            $upload_img_3 = move_uploaded_file($file['other_cirtificate']['tmp_name'], $upload_image_3);
        } else {
            $upload_img_3 = '';
        }

        if (!empty($file['adhaar_cirtificate']['name'])) {

            @$file_name_aadar = time() . "_" . $file['adhaar_cirtificate']['name'];
            $upload_image_4 = "uploads/student_docx/" . basename(@$file_name_aadar);
            $upload_img_4 = move_uploaded_file($file['adhaar_cirtificate']['tmp_name'], $upload_image_4);
        } else {
            $upload_img_4 = '';
        }

        if (!empty($file['report_cirtificate']['name'])) {

            @$file_name_report_certificate = time() . "_" . $file['adhaar_cirtificate']['name'];

            $upload_image_5 = "uploads/student_docx/" . basename(@$file_name_report_certificate);
            $upload_img_5 = move_uploaded_file($file['report_cirtificate']['tmp_name'], $upload_image_5);
        } else {
            $upload_img_5 = '';
        }



        if (!empty($file['schooleaving_cirtificate']['name'])) {

            @$file_name_schoo_leave = time() . "_" . $file['schooleaving_cirtificate']['name'];
            $upload_image_6 = "uploads/student_docx/" . basename(@$file_name_schoo_leave);
            $upload_img_6 = move_uploaded_file($file['schooleaving_cirtificate']['tmp_name'], $upload_image_6);
        } else {
            $upload_img_6 = '';
        }

        $stu_id = $post['student_id'];

        @$check_document = self::get_student_get($stu_id);

        @$check_data_fech = $check_document->fetch();

        @$birth = @$check_data_fetch['birth'];

        @$ch = @$check_data_fech['ch'];

        @$other = @$check_data_fech['other'];

        @$aadhar = @$check_data_fech['aadhar'];

        @$report_cirtificate = @$check_data_fech['report_cirtificate'];

        @$school_leaving = @$check_data_fech['school_leaving'];

        if (!empty($file_name_birth)) {
            @$birth = @$file_name_birth;
        } else {
            @$birth = @$birth;
        }



        if (!empty($file_name_character)) {
            @$ch = @$file_name_character;
        } else {
            @$ch = $ch;
        }

        if (!empty($file_name_other)) {
            @$other = @$file_name_other;
        } else {
            @$other = @$other;
        }

        if (!empty($file_name_aadar)) {
            @$aadhar = @$file_name_aadar;
        } else {
            @$aadhar = @$aadhar;
        }



        if (!empty($file_name_report_certificate)) {
            @$report_cirtificate = @$file_name_report_certificate;
        } else {
            @$report_cirtificate = @$report_cirtificate;
        }

        if (!empty($file_name_schoo_leave)) {
            @$school_leaving = @$file_name_schoo_leave;
        } else {
            @$school_leaving = @$school_leaving;
        }






        $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students_docx SET birth = :birth, ch = :ch, other = :other, aadhar = :aadhar, report_cirtificate = :report_cirtificate ,school_leaving = :school_leaving WHERE s_id = :s_id');

        $sql->execute(array(
            ':birth' => @$birth,
            ':ch' => @$ch,
            ':other' => @$other,
            ':aadhar' => @$aadhar,
            ':report_cirtificate' => @$report_cirtificate,
            ':school_leaving' => @$school_leaving,
            ':s_id' => $post['student_id']
        ));





        $message->add('s', 'Student  document updated successfully!', CLIENT_URL . '/students/editprofile/' . $post['student_id']);
        exit();
    }

    public static function get_student_get($id = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "students_docx WHERE ";

            //$sql .= " MSID='" . $msid . "'";

            $sql .= " s_id='" . $id . "'";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function student_listing($msid = NULL, $classID = NULL) {
        $housearr = Master::get_houses($msid);
        $totalrecords = $housearr->rowCount();
        $sql = "SELECT count(*) as total , sum( case when E.result = '-1' then 1 else 0 end ) as f,sum( case when E.result = '1' then 1 else 0 end ) as p, sum( case when student.gender = 'M' then 1 else 0 end ) as male , sum( case when student.gender = 'F' then 1 else 0 end ) as female , sum( case when parent.category = 1 then 1 else 0 end ) as Tgeneral , sum( case when parent.category = 2 then 1 else 0 end ) as Tsc , sum( case when parent.category = 3 then 1 else 0 end ) as Tst , sum( case when parent.category = 4 then 1 else 0 end ) as Tobc ,";
        if (@$_SESSION['user_date']) {
            $sql .= "(student.adm_classno+" . $_SESSION['year'] . "-year (student.fees_date)+COALESCE(sum(E.result),0)) as class ,";
        }
        while ($rowv = $housearr->fetch()) {
            $totalrecords--;
            $sql .=" sum( case when student.house = " . $rowv['house_id'] . " then 1 else 0 end ) as " . $totalrecords . "a ";
            if ($totalrecords > 0) {
                $sql .=" ,";
            }
        }
        $sql .=" from " . DB_PREFIX . "students as student LEFT JOIN ms_parents as parent ON parent.id = student.parent_id";
        $sql .= " LEFT JOIN " . DB_PREFIX . "exams as E ON E.MSID = student.MSID AND E.s_id = student.student_id ";

        $sql .= " WHERE student.MSID=" . $msid . " AND (student.admno != '' OR student.admno IS NOT NULL)";

        if (@$_SESSION['user_date']) {
//           $month= date('m',  strtotime($school_session_end['ends']));

            $sql .= " AND '" . $_SESSION['user_date'] . ".00-00-00'>= student.fees_date";
            $sql .= " AND '" . $_SESSION['user_date'] . ".00-00-00'<= student.sl_date";
//            $sql .= " AND " . $_SESSION['year'] . ">= YEAR(student.fees_date)";
            $sql .= " AND (" . $_SESSION['year'] . "- YEAR(student.fees_date)+student.adm_classno  =" . $classID . " )";
        } else {
            $sql .= " AND student.adm_classno =" . $classID;
        }
        // print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function student_listing2($msid = NULL, $date = NULL, $year = Null) {
        $sql = " select NA.MSID,
CN.class_no as class_no,
CN.class_name as class_name,
count(NA.s_id) as total,
sum(if(NA.transport='NULL',1,0)) as non_tpt,
sum(if(transport<>'NULL',1,0)) as tpt,
sum(if(NA.gender='M',1,0)) as boys,
sum(if(NA.gender='F',1,0)) as girls,
sum(if(NA.house='1',1,0)) as 'h1' ,
sum(if(NA.house='2',1,0)) as 'h2',
sum(if(NA.house='3',1,0)) as 'h3',
sum(if(NA.house='4',1,0)) as 'h4',
sum(if(NA.category='1',1,0)) as gen,
sum(if(NA.category='2',1,0)) as sc ,
sum(if(NA.category='3',1,0)) as st,
sum(if(NA.category='4',1,0)) as obc ,
sum(if(NA.category='5',1,0)) as bc 
from (
select distinct CS.s_id,CS.name,CS.house_name,CS.category,
      if(CS.s_id=TPT.s_id,TPT.tpt_stn_id,'NULL') as transport,

CS.gender,CS.MSID,CS.house,CS.class from 
(
    select A.s_id,A.name,A.category,A.gender,A.MSID,A.house,A.house_name,A.class from (
    SELECT S.MSID,S.student_id as s_id,S.name,H.house_f_name as house_name,P.category ,(S.adm_classno +'" . $year . "' -year (S.fees_date)+COALESCE(sum(E.result),0)) as class , S.gender,S.house FROM `ms_students` S   left join ms_parents P on P.MSID=S.MSID and  S.parent_id=P.id left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id left join ms_houses H on H.MSID=S.MSID and S.house=H.house_id  Where S.MSID='" . $msid . "'AND '" . $date . "'
between S.fees_date and S.sl_date   group by S.student_id 
) as A  inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And CC.class_to) as CS 
 
 left join ms_tpt_std TPT on TPT.MSID=CS.MSID and CS.s_id=TPT.s_id and '" . $date . "' between TPT.date_from and TPT.date_to group by CS.s_id) as NA left join ms_classes CN on CN.MSID=NA.MSID and CN.class_no=NA.class   group by NA.class";
//       print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function student_listingbck($msid = NULL, $date = NULL) {
        $sql = " select NA.MSID,
CN.class_no as class_no,
CN.class_name as class_name,
count(NA.s_id) as total,
sum(if(NA.transport='NULL',1,0)) as non_tpt,
sum(if(transport<>'NULL',1,0)) as tpt,
sum(if(NA.hostel='NULL',1,0)) as non_hosteler,
sum(if(hostel<>'NULL',1,0)) as hosteler,
sum(if(NA.gender='M',1,0)) as boys,
sum(if(NA.gender='F',1,0)) as girls,
sum(if(NA.house='1',1,0)) as 'h1' ,
sum(if(NA.house='2',1,0)) as 'h2',
sum(if(NA.house='3',1,0)) as 'h3',
sum(if(NA.house='4',1,0)) as 'h4',
sum(if(NA.category='1',1,0)) as gen,
sum(if(NA.category='2',1,0)) as sc ,
sum(if(NA.category='3',1,0)) as st,
sum(if(NA.category='4',1,0)) as obc ,
sum(if(NA.category='5',1,0)) as bc ,
sum(if(NA.`section`='1',1,0)) as 'S1',
sum(IF(NA.`section`='2',1,0)) as 'S2',
sum(IF(NA.`section`='3',1,0)) as 'S3',
sum(IF(NA.`section`='4',1,0)) as 'S4',
sum(IF(NA.`section`='5',1,0)) as 'S5'
from (
select distinct CS.s_id,CS.name,CS.house_name,CS.section ,CS.category,
      if(CS.s_id=TPT.s_id,TPT.tpt_stn_id,'NULL') as transport,
if(CS.s_id=HOS.s_id,HOS.hostel_id,'NULL') as hostel,
CS.gender,CS.MSID,CS.house,CS.class from 
(
    select A.s_id,A.name,A.category,A.gender,A.MSID,A.house,A.section,A.house_name,A.class from (
    SELECT S.MSID,S.student_id as s_id,S.name,H.house_f_name as house_name,P.category ,(S.adm_classno + 2015-year (S.fees_date)+COALESCE(sum(E.result),0)) as class , S.gender,S.house,S.section FROM `ms_students` S   left join ms_parents P on P.MSID=S.MSID and  S.parent_id=P.id left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id left join ms_houses H on H.MSID=S.MSID and S.house=H.house_id  left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id  Where S.MSID='" . $msid . "'AND '" . $date . "'
between S.fees_date and S.sl_date   group by S.student_id 
) as A  inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And CC.class_to) as CS 
 left join ms_hosteler HOS on HOS.MSID=CS.MSID and CS.s_id=HOS.s_id and '" . $date . "' between HOS.from_date and HOS.to_date 
 left join ms_tpt_std TPT on TPT.MSID=CS.MSID and CS.s_id=TPT.s_id and '" . $date . "' between TPT.date_from and TPT.date_to group by CS.s_id) as NA left join ms_classes CN on CN.MSID=NA.MSID and CN.class_no=NA.class   group by NA.class";


//        print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function student_section_count($msid = NULL, $date = NULL, $class_id = NULL, $sec_name = NULL, $all = NULL) {

        $sql = "select count(*) as total ,A.section,A.sec_name,A.sec_id,A.class from ( SELECT S.MSID,S.student_id as s_id,
                (S.adm_classno + " . $_SESSION['year'] . "-year (S.fees_date)+COALESCE(sum(E.result),0)) as class ,
                S.section,Sec.sec_name,Sec.id as sec_id FROM `ms_students` S 
                left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id 
                left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id 
                Where S.MSID='" . $msid . "'AND '" . $_SESSION['user_date'] . "' between S.fees_date and S.sl_date group by S.student_id 
                ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And
                CC.class_to ";
        if (@$all) {
            
        } else {
            $sql.=" AND A.class= '" . $class_id . " '";
        }
        if (@$sec_name) {
            $sql .= " AND A.sec_name= '" . $sec_name . " ' ";
        }
        if (@$all) {
            
        } else {
            $sql .= " group by class,sec_name";
        }

//print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function student_designs($design = NULL) {

        $sql = "select * from  " . DB_PREFIX . "designs";
        if (@$design) {
            $sql.=" where design = '" . $design . " '";
        }
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function student_fee_designs($design = NULL) {

        $sql = "select * from  " . DB_PREFIX . "design_reportcard";
        if (@$design) {
            $sql.=" where sample = '" . $design . " '";
        }
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function student_house_count($msid = NULL, $date = NULL, $class_id = NULL, $house_id = NULL, $all = NULL) {

        $sql = "select count(*) as total ,A.house,A.house_s_name,A.class from ( SELECT S.MSID,S.student_id as s_id,
                (S.adm_classno + " . $_SESSION['year'] . "-year (S.fees_date)+COALESCE(sum(E.result),0)) as class ,
                S.house,H.house_s_name FROM `ms_students` S 
                left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id 
                left join ms_houses H on H.MSID=S.MSID and S.house=H.house_id 
                Where S.MSID='" . $msid . "'AND '" . $_SESSION['user_date'] . "' between S.fees_date and S.sl_date group by S.student_id 
                ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And
                CC.class_to ";
        if (@$all) {
            
        } else {
            $sql.=" AND A.class= '" . $class_id . " '";
        }
        if (@$house_id) {
            $sql .= " AND A.house= '" . $house_id . " ' ";
        }
        if (@$all) {
            
        } else {
            $sql .= " group by class,house_s_name";
        }

//        print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_std_available($msid = NULL, $class_id = NULL, $sec_name = NULL) {

        $sql = "select count(*) as total ,A.section,A.sec_name,A.sec_id,A.class from ( SELECT S.MSID,S.student_id as s_id,
                (S.adm_classno + " . $_SESSION['year'] . "-year (S.fees_date)+COALESCE(sum(E.result),0)) as class ,
                S.section,Sec.sec_name,Sec.id as sec_id FROM `ms_students` S 
                left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id 
                left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id 
                Where S.MSID='" . $msid . "'AND '" . $_SESSION['user_date'] . "' between S.fees_date and S.sl_date group by S.student_id 
                ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And
                CC.class_to ";
//        if (@$all) {
//            
//        } else {
        $sql.=" AND A.class= '" . $class_id . " '";
        $sql .= " AND A.sec_name= '" . $sec_name . "' ";
//        }
//        $sql = "SELECT id, student_id FROM " . DB_PREFIX . "students";
//        $sql .= " where MSID=" . $whr['MSID'] . " AND (admno != '' OR admno IS NOT NULL) AND status ='1'";
//
//        $sql .= " AND " . $whr['field'] . "=" . $whr['value'];
//
//        $sql .= " order by id DESC";
//        print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function getYears($msid = NULL, $start_date = NULL) {
        $time = strtotime($start_date);
        for ($i = date('Y', $time); $i <= date('Y'); $i++) {
            $years["{$i}"] = "{$i}";
        }
        return $years;
    }

    public static function get_session($msid = NULL) {
        $sql = "SELECT * FROM ms_sessions";

        $sql .= " WHERE MSID=" . $msid;

        //print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function sessionwise_student($msid = NULL, $session = NULL) {
        $sql = "SELECT count(*) as total ";
        $sql .=", sum( case when YEAR(student.fees_date) = " . $session . " then 1 else 0 end ) as thisyear ";
        $sql .=" from ms_students as student";
        $sql .= " WHERE student.MSID=" . $msid . " AND (student.admno != '' OR student.admno IS NOT NULL) ";
        $sql .= " AND " . $session . " >= YEAR(student.fees_date)";
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function sessionwise_out($msid = NULL) {
        $sql = "SELECT COUNT(S.Id) as count FROM `ms_sessions` Sn, ms_students S WHERE Sn.MSID='" . $msid . "' AND S.MSID='" . $msid . "' AND S.sl_date BETWEEN DATE_SUB(Sn.begins,INTERVAL 1 DAY)  AND  DATE_SUB(Sn.ends,INTERVAL 1 DAY)  GROUP BY Sn.id ";

//        $sql = "SELECT count(*) as totalout ";
//        $sql .=" from ms_students as student";
//        $sql .= " WHERE student.MSID=" . $msid . " AND (student.admno != '' OR student.admno IS NOT NULL) AND student.status ='2'";
//        $sql .= " AND " . $session . " >= YEAR(student.fees_date)";
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function old_student_tc_register($msid = NULL, $post) {
        $oDb = DBConnection::get();


        try {

            $old_stu_data = self::get_old_stu_check($msid, $post['student_id']);


            $count_result = $old_stu_data->rowCount();




            if ($count_result > 0) {

                $old_stu_data_fetch = $old_stu_data->fetch();

                $id = $old_stu_data_fetch['id'];


                $udpate = $oDb->prepare('UPDATE ' . DB_PREFIX . 'old_students SET MSID = :MSID, Ref = :Ref, SID = :SID, Name = :Name, SubjectSTD = :SubjectSTD, TotalWdays = :TotalWdays, Attendance = :Attendance ,LastResult = :LastResult, RollNo = :RollNo, Mraks_obtained = :Mraks_obtained, Promotion = :Promotion, Feeconcession = :Feeconcession, Reason = :Reason, class= :class WHERE id = :id');
                $status2 = $udpate->execute(array(
                    ':MSID' => $msid,
                    ':Ref' => $post['ref_no'],
                    ':SID' => $post['student_id'],
                    ':Name' => $post['stu_name'],
                    ':SubjectSTD' => $post['subject_studied'],
                    ':TotalWdays' => $post['total_working_days'],
                    ':Attendance' => $post['total_attendance'],
                    ':LastResult' => $post['result'],
                    ':RollNo' => $post['roll_no'],
                    ':Mraks_obtained' => $post['marks_obtained'],
                    ':Promotion' => $post['qualifiy_next'],
                    ':Feeconcession' => $post['fees_concession_avail'],
                    ':Reason' => $post['reason_leaving'],
                    ':class' => $post['stu_class'],
                    ':id' => $id
                ));
            } else {

                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'old_students (MSID, Ref, SID , Name, SubjectSTD , TotalWdays, Attendance ,LastResult, RollNo, Mraks_obtained, Promotion, Feeconcession, Reason, class) VALUES  (:MSID, :Ref, :SID , :Name, :SubjectSTD , :TotalWdays, :Attendance , :LastResult, :RollNo, :Mraks_obtained, :Promotion, :Feeconcession, :Reason, :class)');
                $status = $sql->execute(array(
                    ':MSID' => $msid,
                    ':Ref' => $post['ref_no'],
                    ':SID' => $post['student_id'],
                    ':Name' => $post['stu_name'],
                    ':SubjectSTD' => $post['subject_studied'],
                    ':TotalWdays' => $post['total_working_days'],
                    ':Attendance' => $post['total_attendance'],
                    ':LastResult' => $post['result'],
                    ':RollNo' => $post['roll_no'],
                    ':Mraks_obtained' => $post['marks_obtained'],
                    ':Promotion' => $post['qualifiy_next'],
                    ':Feeconcession' => $post['fees_concession_avail'],
                    ':Reason' => $post['reason_leaving'],
                    ':class' => $post['stu_class']
                ));

                $id = $oDb->lastInsertId();
            }

            if (@$post['last_attend']) {
                $tcl_date = date('Y-m-d', strtotime($post['tc_issue_date']));
                $sl_date = date('Y-m-d', strtotime($post['last_attend']));
                $feepaidupto = date('Y-m-d', strtotime($post['fee_paid_date']));
                print_r($post);
                print_r($sl_date);

//                 TcIssueDate = :TcIssueDate, feepaidupto = :feepaidupto, 
                $udpate3 = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET  sl_date = :sl_date, TcIssueDate = :TcIssueDate, feepaidupto = :feepaidupto,  extra_activities = :extra_activities WHERE student_id = :student_id AND MSID = :MSID');
                $status3 = $udpate3->execute(array(
                    ':sl_date' => $sl_date,
                    ':TcIssueDate' => $tcl_date,
                    ':feepaidupto' => $feepaidupto,
                    ':extra_activities' => $post['extra_activity'],
                    ':student_id' => $post['student_id'],
                    ':MSID' => $msid
                ));
//                    print_r($udpate3);
//                   exit();

                $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $post['session'], $post['student_id']);
                $data_insert = Fee::insert_student_into_fee_billing2($msid, '', $post['student_id']);
            } else {
                $tcl_date = date('Y-m-d', strtotime($post['tc_issue_date']));
                $feepaidupto = date('Y-m-d', strtotime($post['fee_paid_date']));
                $udpate4 = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET  TcIssueDate = :TcIssueDate, feepaidupto = :feepaidupto, extra_activities = :extra_activities WHERE student_id = :student_id AND MSID = :MSID');
                $status4 = $udpate4->execute(array(
                    ':TcIssueDate' => $tcl_date,
                    ':feepaidupto' => $feepaidupto,
                    ':extra_activities' => $post['extra_activity'],
                    ':student_id' => $post['student_id'],
                    ':MSID' => $msid
                ));
//                    print_r($udpate4);  
            }

            return $id;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_old_stu_check($msid = NULL, $stu_id = NULL, $id = NULL) {

        $sql = "select * from  " . DB_PREFIX . "old_students";
        $sql .= " WHERE MSID=" . $msid;
        if (@$stu_id) {
            $sql.=" AND SID= " . $stu_id;
        }
        if (@$id) {
            $sql.=" AND id= " . $id;
        }

//        print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function get_stu_details($msid = NULL, $myuid = NULL, $my_date = NULL) {
        try {
            $sql = "Select Q1.CClass, count(Q1.`student_id`) total From (SELECT S.`student_id`,S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) CClass,K.`class_from`,K.`class_to` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='" . $myuid . "') CU ON S.msid=CU.msid /*And S.`fees_date` <= CU.`ends` AND S.`sl_date` >= CU.`Begins`*/ AND CU.MyDate Between S.fees_date AND S.sl_date INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < CU.`mydate` GROUP BY S.`student_id` HAVING CClass Between K.`class_from` AND K.`class_to`) Q1 group by CClass";

//		 print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_attendance($msid = NULL, $attendance_date = NULL, $class_name = NULL, $section = NULL) {
        try {

            $sql = "SELECT section,Count(IF(Att = 'P', 1, NULL)) AS Present, Count(IF(Att = 'A', 1, NULL)) AS Absent, Count(IF(Att = 'L', 1, NULL)) AS L, Count(IF(Att = 'H', 1, NULL)) AS H from `ms_attendances` where ClassName='$class_name' And AttDate='$attendance_date' and  MSID='$msid'";

            if ($section != '') {
                $sql .= " AND section= '$section'";
            }

            //print_r($sql); 

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function check_holiday($msid = NULL, $mydate = NULL) {
        try {

            //$sql = "SELECT Count(IF(Att = 'P', 1, NULL)) AS Present, Count(IF(Att = 'A', 1, NULL)) AS Absent, Count(IF(Att = 'L', 1, NULL)) AS L from `ms_attendances` where ClassName='$class_name' And AttDate='$attendance_date' and  MSID='$msid'";

            $sql = "SELECT * FROM `ms_dates` WHERE date_id NOT IN (SELECT date_id FROM `ms_dates`,ms_fixed_holidays 
FH WHERE WeekDay(date_id) BETWEEN FH.WDFrom AND FH.WDTo AND Day(date_id) BETWEEN FH.DayFrom AND FH.DayTo AND MONTH(date_id) 
BETWEEN FH.MonthFrom AND FH.MonthTo AND FH.MSID='$msid') AND date_id NOT IN (SELECT date_id FROM `ms_dates` D, ms_holidays 
H WHERE 
date_id BETWEEN 
H.DateFrom AND H.DateTo AND H.MSID='$msid') AND date_id='" . $mydate . "'";

//         print_r($sql);




            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_stu_ac($msid = NULL, $stu_id = NULL) {
        try {

            $sql = "SELECT * FROM ms_students WHERE ";

            if ($msid != '') {

                $sql .= " MSID=" . $msid;
            }

            if ($stu_id != '') {

                $sql .= " AND student_id =" . $stu_id;
            }




            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function count_section_students($msid = NULL, $session = NULL, $my_date = NULL, $class = NULL, $section = Null) {
        try {
//           print_r($section);
            $sql = "select  count(A.CClass), A.CClass from ( SELECT S.*, S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0) AS CClass FROM ms_students S LEFT JOIN (SELECT E.s_id, Sum(E.result) AS SumResult FROM ms_exams E WHERE (((E.MSID)='$msid') AND ((E.date_result) < '$my_date' )) GROUP BY E.s_id ) AS Q1 ON S.student_id = Q1.s_id WHERE S.MSID='$msid' And S.fees_date <='$my_date' AND S.sl_date >'$my_date' ";
            $sql.=" And S.section='$section' ) A where A.CClass='$class' ";
//       
//          print_r($sql);
//       exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function count_sections_students($msid = NULL, $section_id = NULL, $class_id = NULL) {
        try {
            $sql = "SELECT count(student_id) as Section  FROM ms_students WHERE ";

            $sql .= " MSID =" . $msid;

            $sql .= " AND adm_classno=" . $class_id;

            $sql .= " AND section=" . $section_id;


            $sql .= " GROUP BY section ASC";




            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function count_students_attendacnce($uid = NULL, $class_name = NULL, $section = NULL, $attendance = NULL) {
        try {
            /* $sql = "SELECT  * FROM ms_students WHERE ";

              $sql .= " MSID =". $msid;

              $sql .= " AND adm_classno=". $class_id;

              $sql .= " AND section=". $section_id;

             */
            $sql = " SELECT A.`SId`,S.*, A.`Att`,A.`Reason` FROM (SELECT * FROM `ms_slusers` WHERE MyUId='$uid') CU INNER JOIN ms_attendances A ON A.msid=CU.msid And A.`AttDate` = CU.MyDate INNER JOIN ms_students S ON S.msid=CU.msid And S.`student_id` = A.SID WHERE 1 ";

            if ($class_name != NULL) {
                $sql .= " AND A.`ClassName` ='$class_name'";
            }

            if (@$section != '') {
                $sql .= " AND A.`section`='$section'";
            }

            if ($attendance != NUll) {

                $sql .= " AND Att='$attendance'";
            }


//      print_r($sql);
            //exit();


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_stu_attendance_details($msid = NULL, $session = NULL, $my_date = NULL, $class = NULL, $section = Null, $ids = NULL) {
        try {

            $sql = "select A.*,A.CClass from ( SELECT S.*, S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0) AS CClass FROM ms_students S LEFT JOIN (SELECT E.s_id, Sum(E.result) AS SumResult FROM ms_exams E WHERE (((E.MSID)='$msid') AND ((E.date_result) < '$my_date' )) GROUP BY E.s_id ) AS Q1 ON S.student_id = Q1.s_id WHERE S.MSID='$msid' And S.fees_date <='$my_date' AND S.sl_date >'$my_date' And S.section='$section' ) A where A.CClass='$class'";

            if ($ids != '') {
                $sql .= "and A.`student_id` NOT IN ($ids)";
            }
            $sql .=" ORDER BY A.roll_no, `A`.`student_id` ASC ";
//    print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function count_section_wise_student($msid = NULL, $session = NULL, $class = NULL) {
        try {
            $sql = "SELECT distinct `section` FROM `ms_students` WHERE `MSID`='$msid' and `adm_classno`+'$session'-Year(`fees_date`)=$class";

            $sql .= " ORDER BY section ASC ";

            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_student_class_wise($msid = NULL, $session = NULL, $mydate = NULL, $class = NULL) {
        try {
            $sql = "SELECT  (S.`student_id`) as sid, S.name as sname, S.*,P.*,L.name as village, S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0) AS CClass FROM ms_students S INNER JOIN ms_parents P ON S.`parent_id`=P.id INNER Join ms_locality L ON P.village=L.id LEFT JOIN (SELECT E.s_id, Sum(E.result) AS SumResult FROM ms_exams E WHERE (((E.MSID)='$msid') AND ((E.date_result)<'$mydate')) GROUP BY E.s_id ) AS Q1 ON S.`student_id` = Q1.s_id WHERE S.MSID='$msid' And P.MSID='$msid'  And S.`fees_date`<='$mydate' AND S.`sl_date`>'$mydate' and  S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0)='$class' GROUP BY S.`student_id`, COALESCE(SumResult,0) Order By `student_id`";
            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_outgoing_student_dtl($myuid = NULL) {
        try {
            $sql = "SELECT S.name, S.* ,P.*, L.name as village FROM `ms_students` S INNER JOIN (Select * from ms_slusers where myuid='" . $myuid . "') as CU ON S.MSID=CU.MSID
  Left JOIN ms_parents P on P.msid= CU.msid  and P.id=S.parent_id Inner Join ms_locality L On L.msid=CU.Msid and P.village=L.id
  INNER JOIN ms_sessions K on K.msid= CU.msid And K.session_id=CU.mysession  And S.sl_date between DATE_SUB(K.begins, INTERVAL 1 DAY) And DATE_SUB(K.ends, INTERVAL 1 DAY)";
            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_student_streamlist($myuid = NULL) {
        try {
            $sql = "Select Q1.CClass, Count(Q1.student_id)Total, Sum(IF(Q1.`Stream`='Commerce',1,0))Comm, Sum(IF(Q1.`Stream`='Arts',1,0))Arts, Sum(IF(Q1.`Stream`='science',1,0)) Science, Sum(IF(Q1.`group`='NM',1,0))NM , Sum(IF(Q1.`group`='Med',1,0))Med,SUM(IF(Q1.`stream`='',1,0))'NA'  FROM(SELECT CU.msid,CU.Mysession Session, S.`student_id`,S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) CClass,SG.`group`,SG.`stream` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='" . $myuid . "') CU ON S.msid=CU.msid And S.`fees_date` <= CU.`ends` AND S.`sl_date` >= CU.`Begins` INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_subjects SG ON SG.`msid`=CU.`msid` AND SG.`subject_gp_id`=S.`group_id` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < CU.`mydate` GROUP BY S.`student_id` HAVING CClass Between 11 AND 12)Q1 GROUP BY Q1.CClass";
            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

    public static function get_student_stream($myuid = NULL, $class = NULL, $stream = NULL, $group = NULL) {
        try {
            $sql = "SELECT FIN.CClass,FIN.msid,FIN.Session, FIN.`student_id`,FIN.`stream`, FIN.`group` from (SELECT CU.msid,CU.Mysession Session, S.`student_id`,S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) CClass,SG.`group`,SG.`stream` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='" . $myuid . "') CU ON S.msid=CU.msid And S.`fees_date` <= CU.`ends` AND S.`sl_date` >= CU.`Begins` INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_subjects SG ON SG.`msid`=CU.`msid` AND SG.`subject_gp_id`=S.`group_id` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < CU.`mydate` GROUP BY S.`student_id`) FIN ";

            if ($class == 'all') {
                $sql .= " Where CClass Between 11 And 12";
            }
            if ($class != 'all') {
                $sql .= " Where CClass =" . $class;
            }
            if ($stream != NULL) {
                $sql .= " And `stream` ='" . $stream . "'";
            }
            if ($group != NULL) {
                $sql .= " And `group` ='" . $group . "' ";
            }


//            print_r($sql);
//            exit();

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

//    public static function update_all_student_image($msid, $student_id, $target_dir) {
//        print_r($target_dir);
//        try {
//            $sql = "UPDATE ms_students SET photo= '".$target_dir."' WHERE MSID = '".$msid."' AND student_id= '".$student_id."' ";
//            $oDb = DBConnection::get();
//            $sql = $oDb->query($sql);
//            $message = new Messages();
//            $message->add('s', 'Students Images Uploaded Successfully!', CLIENT_URL . '/edit-all-student');
//        } catch (Exception $ex) {
//            echo $ex->getMessage();
//        }
//    }
    
    
    public static function update_all_student($msid, $student_id, $postdata= array()) {
        try {
            $sql = "UPDATE ms_students SET name= '".$postdata['name']."', birth_date= '".$postdata['birth_date']."', gender = '".$postdata['gender']."', ";
            $sql .= "adm_date= '".$postdata['adm_date']."', fees_date= '".$postdata['fees_date']."', aadhar = '".$postdata['aadhar']."', ";
            $sql .= "house= '".$postdata['house']."', blood_group= '".$postdata['blood_group']."', photo= '".$postdata['photo']."', opening_bal = '".$postdata['opening_bal']."', ";
            $sql .= "amrit_dhari= '".$postdata['amrit_dhari']."', boarding_id= '".$postdata['boarding_id']."', section = '".$postdata['section']."' WHERE MSID = '".$postdata['MSID']."' AND student_id= '".$student_id."' ";

//            pr($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            $message = new Messages();
            //$message->add('s', 'Students updated successfully!', CLIENT_URL . '/edit-all-student');
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }
    public static function get_students_streamwise($myuid, $class, $subject=NULL, $stream=NULL, $group= NULL ) {
        try {
            $sql = "SELECT S.`student_id`,S.`name`, SG.Subject_id,SJ.`stream`,SJ.`group`,S.`adm_classno`+CU.MySession-Year(S.`fees_date`)+COALESCE(SUM(`result`),0) CClass,K.`class_from`,K.`class_to` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='".$myuid."') CU ON S.msid=CU.msid /*And S.`fees_date` <= CU.`ends` AND S.`sl_date` >= CU.`Begins`*/ AND CU.MyDate Between S.fees_date AND S.sl_date INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < CU.`mydate` Left Join ms_subjects_group SG ON SG.group_id=S.`group_id` Left Join ms_subjects SJ ON SJ.`subject_gp_id` = S.group_id  GROUP BY S.`student_id` HAVING CClass ='".$class."' And SG.subject_id= '".$subject."' And SJ.`stream`='".$stream."' ";

//            pr($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            $message = new Messages();
              return $sql;
            //$message->add('s', 'Students updated successfully!', CLIENT_URL . '/edit-all-student');
        } catch (Exception $ex) {
            echo $ex->getMessage();
        }
    }

}

?>
