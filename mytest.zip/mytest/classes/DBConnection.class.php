<?php

/**
 * class to store DBconnections and retreive a connections
 */
class DBConnection {

   private static   $host = DB_HOST;
   private static   $user = DB_USER; 
   private static   $password = DB_PASS;
   private static   $database = DB_DATABASE;
    /**
     * get a stored connection
     * @param string $sName name of the connection
     * @return DBConnection object
     */
    public static function get() {

        try {

        $db = new PDO("mysql:host=".self::$host.";dbname=".self::$database, self::$user, self::$password);
		$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		return $db;
		
		} catch (PDOException $e) {
		  echo '<title>Connection Error</title><h1>Connection failed: ' . $e->getMessage(). '</h1>';
		  exit;
		}
		return true;
    }

}

?>
