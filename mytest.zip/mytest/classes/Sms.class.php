<?php

class SMS
    {

    public function __construct()
        {
        
        }

    public static function get_sms_detail($msid = Null)
        {
        try
            {
            $sql = "select  *  From  `ms_sms_detail` where  `MSID`='$msid'";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function add_sms_template($msid, $data)
        {
        $message = new Messages();
        try
            {

            $oDb = DBConnection::get();
            $sql = $oDb->prepare('INSERT INTO  `ms_sms_templates`(`msid` ,  `temp_name` ,  `temp_body`) VALUES(:msid , :temp_name,  :temp_body)');
            $exe = $sql->execute(array(
                ":msid" => $msid,
                ":temp_name" => $data['template_name'],
                ":temp_body" => $data['template_body'],
            ));
            if ($exe)
                {
                $message->add('s', '"' . $data['template_name'] . '" Added Successfully!', CLIENT_URL . '/sms-template/add');
                }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }
    public static function update_sms_template($msid, $data, $id)
        {
        $message = new Messages();
        try
            {

            $oDb = DBConnection::get();
            $sql = $oDb->prepare('UPDATE ms_sms_templates SET msid=:msid ,  temp_name=:temp_name , temp_body=:temp_body WHERE id = :id');
            $exe = $sql->execute(array(
                ":msid" => $msid,
                ":temp_name" => $data['template_name'],
                ":temp_body" => $data['template_body'],
                ":id"=>$id,
            ));
            if ($exe)
                {
                $message->add('s', '"' . $data['template_name'] . '" Updated Successfully!', CLIENT_URL . '/sms-template');
                }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_sms_keywords($msid, $id=null, $data = array('selectAll' => 'true'))
        {

        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "keywords  WHERE msid=" . $msid;
            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }

            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
    public static function get_sms_templates($msid, $id=null, $data = array('selectAll' => 'true'))
        {

        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "sms_templates  WHERE msid=" . $msid;
            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }

            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    }

?>
