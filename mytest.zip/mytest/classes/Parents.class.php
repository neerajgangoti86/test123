<?php

class Parents
    {

    /**
     * get locality by school
     * @param string $msid
     * @param string $id
     * @param string $status
     * @return mixed User/false
     */
    public static function update_password($uid = null, $password = null)
        {
        $message = new Messages();
        $oDb = DBConnection::get();
        $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'parents SET password = :password WHERE uid = :uid');
        $sucess = $sql->execute(array(
            ':password' => $password,
            ':uid' => $uid
        ));
//        print_r($sucess);
//        exit();
        if (@$sucess)
            {
            $message->add('s', 'Password updated successfully!', CLIENT_URL . '/changepassword');
            } exit();
        }

    public static function get_parents_count($myuid = NULL)
        {
        try
            {
            $sql = "SELECT COUNT(*) parents FROM(SELECT COUNT( S.student_id ) AS Children
FROM (

SELECT * 
FROM ms_slusers
WHERE MyUId =  '" . $myuid . "'
)CU
INNER JOIN ms_students S ON S.msid = CU.msid
AND CU.MyDate
BETWEEN S.fees_date
AND S.sl_date
INNER JOIN ms_parents P ON S.parent_id = P.id
AND S.MSID = P.MSID
INNER JOIN ms_locality L ON P.village = L.id
AND P.MSID = L.MSID
LEFT JOIN (

SELECT E.s_id, SUM( E.result ) AS SumResult
FROM ms_exams E
INNER JOIN (

SELECT * 
FROM ms_slusers
WHERE MyUId =  '" . $myuid . "'
)CU1 ON E.MSID = CU1.msid
AND E.date_result < CU1.MyDate
GROUP BY E.s_id
) AS Q1 ON S.student_id = Q1.s_id
WHERE S.MSID = CU.msid
AND CU.MyDate
BETWEEN S.fees_date
AND S.sl_date
AND P.MSID = CU.msid
GROUP BY S.parent_id)Q1";
//                    . ""
//                    . "SELECT P.`f_name`,`f_mobile`,P.`m_name`,P.`m_mobile`,L.`name` Lacality,Count(S.`student_id`) NOC FROM (SELECT * FROM `ms_slusers` WHERE `myuid` = '".$myuid."') CU INNER JOIN ms_students S ON S.`msid`=CU.`msid` AND CU.`mydate` BETWEEN S.`fees_date` AND S.`sl_date` INNER JOIN ms_parents P ON P.Id =S.`parent_id` INNER JOIN ms_locality L On L.msid=CU.msid And P.village=L.id Group By P.`id`";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_parents_detl($msid = NULL, $mydate = NULL, $session = NULL, $for = "one", $search = NULL, $limit = 'all', $data = array())
        {
        try
            {
            $sql = " SELECT  Count(S.student_id) AS Children,S.*,P.*,L.id, L.name as locality, S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0) AS"
                    . " CClass FROM ms_students S INNER JOIN ms_parents P ON S.parent_id=P.id  and S.MSID=P.MSID INNER Join ms_locality L ON P.village=L.id and P.MSID=L.MSID"
                    . "  LEFT JOIN (SELECT E.s_id, Sum(E.result) AS SumResult "
                    . "FROM ms_exams E WHERE (((E.MSID)='$msid') AND ((E.date_result)<'$mydate')) GROUP BY E.s_id ) "
                    . "AS Q1 ON S.student_id = Q1.s_id WHERE S.MSID='$msid' And '$mydate'";



            if ($for == "all")
                {
                $sql .=" > ";
                }
            else
                {
                $sql .=" < ";
                }
            $sql .="S.sl_date  And P.MSID='$msid' ";
            if ($search != '')
                {
                $local = Master::get_locality_name($msid, $search)->fetch();

                $sql .= " AND P.f_name LIKE '$search%' OR P.f_name LIKE '%$search' And P.MSID='$msid' OR P.f_mobile LIKE '$search' And P.MSID='$msid' OR  P.m_name LIKE '$search%' And P.MSID='$msid' OR P.m_name LIKE '%$search' And P.MSID='$msid' OR P.mobile_sms LIKE '$search' And P.MSID='$msid' OR  P.village LIKE '$local[id]' And P.MSID='$msid' ";

                // $sql .= " OR village = '" . $local['id'] . "' ) ";
                }

            $sql .="GROUP BY S.parent_id";
            if ($limit != 'all')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
//                print_r($sql);
                }

//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_parent_search_details($msid = NULL, $mydate = NULL, $session = NULL, $for = "one", $limit = 'all', $data = array(), $search = NULL)
        {
        try
            {
            $sql = " SELECT  Count(S.student_id) AS Children,S.*,P.*,L.id, L.name as locality, S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0) AS"
                    . " CClass FROM ms_students S INNER JOIN ms_parents P ON S.parent_id=P.id  and S.MSID=P.MSID INNER Join ms_locality L ON P.village=L.id and P.MSID=L.MSID"
                    . "  LEFT JOIN (SELECT E.s_id, Sum(E.result) AS SumResult "
                    . "FROM ms_exams E WHERE (((E.MSID)='$msid') AND ((E.date_result)<'$mydate')) GROUP BY E.s_id ) "
                    . "AS Q1 ON S.student_id = Q1.s_id WHERE S.MSID='$msid' And '$mydate' AND (f_name like '$search%' OR f_mobile like '$search%')";
            if ($for == "all")
                {
                $sql .=" > ";
                }
            else
                {
                $sql .=" < ";
                }
            $sql .="S.sl_date  And P.MSID='$msid' GROUP BY S.parent_id";
            if ($limit != 'all')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
//                print_r($sql);
                }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_parents($msid = NULL, $id = NULL, $limit = 'all', $data = array())
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "parents";
            $sql .= " where MSID=" . $msid;

//           print_r($data);
//           exit();

            if (!empty($data['f_name']))
                {
                $f_name = $data['f_name'];
                $sql .= "  AND  (f_name like '$f_name%'";
                $sql .= " OR m_name like '$f_name%'";
                $sql .= " OR mobile_sms like '$f_name'";
                //$locality = $data['locality'];

                $local = Master::get_locality_name($msid, $f_name)->fetch();

                //print_r($local);



                $sql .= " OR village = '" . $local['post_id'] . "' ) ";
                }
//            if (!empty($data['f_name']))
//                {
//                $m_name = $data['f_name'];
//                $sql .= " OR m_name like '$f_name%'";
//                }
//            if (!empty($data['mobile_sms']))
//                {
//                $mobile_sms = $data['mobile_sms'];
//                $sql .= " OR mobile_sms like '$f_name%'";
//                }
//                
//            if (!empty($data['locality']))
//                {
//                $locality = $data['locality'];
//                
//                $local = Master::get_locality_name($msid,$locality)->fetch();
//                
//               //print_r($local);
//                
//               
//                
//                $sql .= " AND village = '".$local['id']."'";
//                }

            if ($id != NULL)
                {
                $sql .= " AND id=" . $id;
                }
            $sql .= " order by id DESC";

            if ($limit != 'all')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
            // print_r($sql);
//           exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_childrens($id = NULL, $mydate = NULL, $for = "one")
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "students WHERE parent_id = '" . $id . "'  AND '" . $mydate;
            if ($for == "all")
                {
                $sql .="' > ";
                }
            else
                {
                $sql .="' < ";
                }
            $sql.= " sl_date ";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_children($id = NULL)
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "students WHERE parent_id = " . $id;
//print_r($sql);
            $oDb = DBConnection::get();
            $result = $oDb->prepare($sql);
            $result->execute(array(
                ':id' => $id
            ));
            $number_of_rows = $result->fetchColumn();
            return $number_of_rows;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_same_parent($id = NULL)
        {

        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "students WHERE parent_id = " . $id;
//print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_student_account($msid = null, $id = null, $stu_id = null)
        {
        try
            {
            $sql = "SELECT student_id FROM " . DB_PREFIX . "students";

            $sql .= " where MSID=" . $msid;

            $sql .=" and  parent_id=" . $id;

            //$sql .=" and  student_id=" .$stu_id;
            //$sql .=" and  status=" . $status;


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_student_account2($msid = null, $id = null, $stu_id = null)
        {
        try
            {
            $sql = "SELECT student_id FROM " . DB_PREFIX . "students";

            $sql .= " where MSID=" . $msid;

            $sql .=" and  parent_id=" . $id;

//            $sql .=" and  student_id=" . $stu_id;
            //$sql .=" and  status=" . $status;


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            //print_r($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function parent_get($msid = null, $id = null)
        {
        try
            {
            $sql = "SELECT *  FROM " . DB_PREFIX . "students";

            $sql .= " where MSID=" . $msid;

            $sql .=" and  student_id = " . $id;

            //$sql .=" and  status=" . $status;


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function parent_get2($msid = null, $id = null)
        {
        try
            {
            $sql = "SELECT *  FROM " . DB_PREFIX . "students_enrole";

            $sql .= " where MSID=" . $msid;

            $sql .=" and  student_id = " . $id;

            //$sql .=" and  status=" . $status;


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function update_parent($parentdata = null, $data = null, $id = null)
        {        //print_r($expression)
        $message = new Messages();
        $oDb = DBConnection::get();
        $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'parents SET f_name = :f_name, f_occupation =  :f_occupation, f_qualification = :f_qualification, f_mobile = :f_mobile, m_name = :m_name, m_occupation = :m_occupation, m_qualification = :m_qualification, m_mobile = :m_mobile, phone_home = :phone_home, mobile_sms = :mobile_sms, category = :category, address_line1 = :address_line1, address_line2 = :address_line2, address = :address,village = :village, annual_income = :annual_income, religion = :religion  WHERE id = :id');

        $sql->execute(array(
            ':f_name' => $parentdata['fname'],
            ':f_occupation' => $parentdata['f_occupation'],
            ':f_qualification' => $parentdata['f_qualification'],
            ':f_mobile' => $parentdata['fmob'],
            ':m_name' => $parentdata['mname'],
            ':m_occupation' => $parentdata['m_occupation'],
            ':m_qualification' => $parentdata['m_qualification'],
            ':m_mobile' => $parentdata['mmob'],
            ':phone_home' => $parentdata['landline'],
            ':mobile_sms' => $parentdata['mobsms'],
            ':category' => $parentdata['category'],
            ':address_line1' => $parentdata['addline1'],
            ':address_line2' => $parentdata['addline2'],
            ':address' => $parentdata['padd'],
            ':village' => $parentdata['locality'],
            ':annual_income' => $parentdata['al_income'],
            ':religion' => $parentdata['religion'],
            ':id' => @$data['parent_id']
        ));

        $message->add('s', 'Parent Details updated successfully!', CLIENT_URL . '/students/editprofile/' . $id);
        exit();
        }

    /**
     * Register new parents
     * */
    public function create_parent($id = NULL, $postdata = array())
        {
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {
            //insert into database
            if (strlen(trim(@$postdata['fname'])) == 0) $message->add('e', 'father name is required!');
            if (strlen(trim(@$postdata['mname'])) == 0) $message->add('e', 'Mother name is required!');

            if (!$message->hasMessages())
                {

                if (!empty($id))
                    {//update parent
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'parents SET f_name = :f_name, f_occupation = :f_occupation, f_qualification = :f_qualification, f_mobile = :f_mobile, m_name = :m_name, m_occupation = :m_occupation, m_qualification = :m_qualification, m_mobile = :m_mobile,  phone_home  = :phone_home, mobile_sms = :mobile_sms, category = :category, address_line1 = :address_line1, address_line2 = :address_line2, address = :address, village = :village, annual_income = :annual_income,  religion = :religion WHERE id = :id');
                    $upsql->execute(array(
                        ':f_name' => $postdata['fname'],
                        ':f_occupation' => $postdata['f_occupation'],
                        ':f_qualification' => $postdata['f_qualification'],
                        ':f_mobile' => $postdata['fmob'],
                        ':m_name' => $postdata['mname'],
                        ':m_occupation' => $postdata['m_occupation'],
                        ':m_qualification' => $postdata['m_qualification'],
                        ':m_mobile' => $postdata['mmob'],
                        ':phone_home' => $postdata['landline'],
                        ':mobile_sms' => $postdata['mobsms'],
                        ':category' => $postdata['category'],
                        ':address_line1' => $postdata['addline1'],
                        ':address_line2' => $postdata['addline2'],
                        ':address' => $postdata['padd'],
                        ':village' => $postdata['locality'],
                        ':annual_income' => $postdata['al_income'],
                        ':religion' => $postdata['religion'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Parent updated successfully!', CLIENT_URL . '/parents/edit/' . $id);
                    exit();
                    }
                else
                    {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'parents (MSID,f_name, f_occupation, f_qualification, f_mobile, m_name,m_occupation,m_qualification,m_mobile, phone_home, mobile_sms, category, address_line1, address_line2, address, village, annual_income, religion, created_date,status) VALUES  (:MSID, :f_name, :f_occupation, :f_qualification, :f_mobile, :m_name, :m_occupation, :m_qualification, :m_mobile, :phone_home, :mobile_sms, :category, :address_line1, :address_line2, :address, :village, :annual_income, :religion, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':f_name' => $postdata['fname'],
                        ':f_occupation' => $postdata['f_occupation'],
                        ':f_qualification' => $postdata['f_qualification'],
                        ':f_mobile' => $postdata['fmob'],
                        ':m_name' => $postdata['mname'],
                        ':m_occupation' => $postdata['m_occupation'],
                        ':m_qualification' => $postdata['m_qualification'],
                        ':m_mobile' => $postdata['mmob'],
                        ':phone_home' => $postdata['landline'],
                        ':mobile_sms' => $postdata['mobsms'],
                        ':category' => $postdata['category'], ':address_line1' => $postdata['addline1'], ':address_line2' => $postdata['addline2'], ':address' => $postdata['padd'], ':village' => $postdata['locality'], ':annual_income' => $postdata['al_income'], ':religion' => $postdata['religion'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $parent_id = $oDb->lastInsertId();
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'users (username,password,first_name,last_name,email,MSID,created_date,status) VALUES  (:username,:password,:first_name,:last_name,:email,:MSID,:created_date,:status)');

                    $sql->execute(array(
                        ':username' => $postdata['MSID'] . "P" . $parent_id,
                        ':password' => $postdata['MSID'] . "P" . $parent_id,
                        ':first_name' => $postdata['fname'],
                        ':last_name' => '',
                        ':email' => '',
                        ':MSID' => $postdata['MSID'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'Parent registered successfully!', CLIENT_URL . '/parents');
                    exit();
                    }
                }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }
        
        
            public static function update_all_parent($msid, $parent_id, $postdata = array()) {   
//                pr($postdata);
                
        $message = new Messages();
        $oDb = DBConnection::get();
        $sql = 'UPDATE ' . DB_PREFIX . 'parents SET f_name = "'.$postdata['f_name'].'", m_name = "'.$postdata['m_name'].'", m_mobile = "'.$postdata['m_mobile'].'",  mobile_sms = "'.$postdata['mobile_sms'].'",  address = "'.$postdata['address'].'"  WHERE MSID="'.$msid.'" AND id = "'.$parent_id.'"';
        $exc = $oDb->query($sql);
    }

    }

?>
