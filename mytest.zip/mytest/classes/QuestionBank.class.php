<?php

class QuestionBank {

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_questionpaper_import($msid = NULL, $file = NULL) {

        $fo = fopen($file, "r");
// CSV fiile
        $i = 0;
//        print_r($fo);
        while (($emapData = fgetcsv($fo, "", ",")) !== FALSE) {
            if ($i != 0) {
                $sql = "INSERT into  `ms_exam_question_bank`
(`MSID`, `q_no`, `class`, `subject`, `chapter`, `question`, `marks`, `sub_group`, `session`, `no_of_question`,`d_level`, `section`, `qheading`) VALUES 
('" . $msid . "','" . $emapData[0] . "','" . $emapData[1] . "','" . $emapData[2] . "','" . $emapData[3] . "','" . $emapData[4] . "','" . $emapData[5] . "','" . $emapData[6] . "','" . $emapData[7] . "','" . $emapData[8] . "','" . $emapData[9] . "','" . $emapData[10] . "','" . $emapData[11] . "')";
                $oDb = DBConnection::get();
                $sql = $oDb->query($sql);
            }
            $i++;
        } $message = new Messages();
        $message->add('s', 'Question Bank is added successfully!', CLIENT_URL . '/question-bank-import');
        $message->add('s', $e->getMessage());
    }

    public static function get_exam_question_for_genrater($msid = NULL, $class_id = NULL, $subject = NULL, $id = NULL, $qheadding = NULL) {
        try {
            $sql = "   SELECT * FROM " . DB_PREFIX . "exam_question_bank";
            $sql .= " where MSID = " . $msid;


            if ($class_id != NULL) {
                $sql .= " AND class =" . $class_id;
            }
            if ($id != NULL) {
                $sql .= "  AND  q_id IN (" . $id . ") ";
            }
            if ($subject != NULL) {
                $sql .= " AND subject ='" . $subject . "'";
            }
            if ($qheadding != NULL) {
                $sql .= " AND qheading ='" . $qheadding . "'";
            }
            $sql .= " order by q_id ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_exam_distinct_questions($msid = NULL, $class_id = NULL, $subject = NULL, $id = NULL) {
        try {
            $sql = "   SELECT * FROM " . DB_PREFIX . "exam_question_bank";
            $sql .= " where  MSID= " . $msid;


            if ($class_id != NULL) {
                $sql .= " AND class =" . $class_id;
            }
            if ($id != NULL) {
                $sql .= "  AND  q_id IN (" . $id . ") ";
//                $sql .= " AND q_no  in =" . $id;
            }
            if ($subject != NULL) {
                $sql .= " AND subject ='" . $subject . "'";
            }
            $sql .= " group by qheading ";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_exam_questions_subject($msid = NULL, $class_id = NULL, $subject = NULL) {
        try {
            $sql = "   SELECT distinct SUBJECT FROM " . DB_PREFIX . "questionbank";
            $sql .= " where  MSID= " . $msid;


            if ($class_id != NULL) {
                $sql .= " AND CLASS =" . $class_id;
            }

            "Order by SUBJECT Asc ";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_exam_questions_class($msid = NULL, $session = NULL) {
        try {
            $sql = "   SELECT distinct `CLASS` FROM " . DB_PREFIX . "questionbank";
            $sql .= " where  MSID= " . $msid . " Order by `CLASS` Asc";



//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_questions_subsubject($msid = NULL, $class_id = NULL, $where = NULL, $subject = NULL) {
        try {
            if ($where != NULL) {
                $sql = "SELECT distinct " . $where . " From ms_questionbank";
            } else {
                $sql = "SELECT distinct SUBSUBJECT FROM " . DB_PREFIX . "questionbank";
            }
            $sql .= " where  MSID= " . $msid;


            if ($class_id != NULL) {
                $sql .= " AND CLASS ='" . $class_id. "'";
            }
            if ($subject != NULL) {
                $sql .= " AND SUBJECT ='" . $subject . "'";
            }
            $sql .="  Order by CHAPTER Asc";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_questions($msid = NULL, $class_id = NULL, $subject = NULL,  $chapter = NULL) {
        try {
           
            $sql = "SELECT * FROM " . DB_PREFIX . "questionbank where  MSID= " . $msid;
            if ($class_id != NULL) {
                $sql .= " AND CLASS =" . $class_id;
            }
            if ($subject != NULL) {
                $sql .= " AND SUBJECT ='" . $subject . "'";
            }
            if ($chapter != NULL) {
                $sql .= " AND CHAPTER ='" . $chapter . "' Order by CLASS, SUBJECT Asc";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    

    public static function Insert_questions($msid = NULL, $class_id = NULL, $subject = NULL, $post = NULL) {
      $oDb = DBConnection::get();
      try { 
            $sql = $oDb->prepare('INSERT INTO `ms_questionbank`(`MSID`, `CLASS`, `SUBJECT`, `SUBSUBJECT`, `CHAPTER`, `STATEMENT`, `MARKS`, `TYPE_ID`, `CATEGORY`, `LEVEL_ID`, `STATUS`, `IMPORTANCE_LEVEL`) VALUES (:MSID, :CLASS, :SUBJECT, :SUBSUBJECT, :CHAPTER, :STATEMENT, :MARKS, :TYPE_ID, :CATEGORY, :LEVEL_ID, :STATUS, :IMPORTANCE_LEVEL)');
            $sql->execute(array(
                ':MSID' => $msid,
                ':CLASS' => $class_id,
                ':SUBJECT' => $subject,
                ':SUBSUBJECT' => $subject,
                ':CHAPTER' => $_POST['chapter'],
                ':STATEMENT' => $_POST['editor1'],
                ':MARKS' => $_POST['marks'],
                ':TYPE_ID' => $_POST['type'],
                ':CATEGORY' => $_POST['type'],
                ':LEVEL_ID' => $_POST['level'],
                ':STATUS' => 2,
                ':IMPORTANCE_LEVEL' => $_POST['imp'],
            ));
           print_r($sql);
             } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_questions_options($table = NULL, $msid= NULL, $class= NULL, $subject= NULL, $typeid=NULL, $SUBSUBJECT= NULL) {
        try {
           
            $sql = "SELECT * FROM ".$table;
            if($msid !=NULL) {
              $sql .= " Where MSID=".$msid; 
            }
             if($class !=NULL) {
               $sql .= " And CLASS=".$class;   
             }
             if($subject !=NULL) {
               $sql .= " And SUBJECT='".$subject."'";   
             }
             if($typeid !=NULL) {
               $sql .= " And ID='".$typeid."'";   
             }
             if($SUBSUBJECT !=NULL) {
               $sql .= " And SUBSUBJECT='".$SUBSUBJECT."'";   
             }
            
           
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
     public static function get_paper_format($msid= NULL, $class= NULL, $subject= NULL, $typeid=NULL) {
        try {
           
            $sql = "SELECT TT.CAPTION, TT.ID, TT.SUBSUBJECT FROM `ms_format` FF inner join ms_q_type TT on FF.MSID=TT.MSID and FF.TYPE_ID=TT.ID and FF.SUBSUBJECT=TT.SUBSUBJECT and FF.CLASS=TT.CLASS And FF.SUBJECT=TT.SUBJECT";
            if($msid !=NULL) {
              $sql .= " where TT.MSID='".$msid."'"; 
            }
             if($class !=NULL) {
               $sql .= " and TT.CLASS='".$class."'";   
             }
             if($subject !=NULL) {
               $sql .= " and TT.SUBJECT='".$subject."'";   
             }
             if($typeid !=NULL) {
               $sql .= " And TT.ID='".$typeid."' Order By FF.QUESTION_FROM ASC";   
             }
            
           
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

}

?>
