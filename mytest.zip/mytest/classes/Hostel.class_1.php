<?php

class Hostel {
s] => 3 [section] => 1 ) select A.section,A.adm_classno,A.adm_class_name,A.opening_bal,A.annual_income,A.sec_name,A.class,CL.class_name,A.s_uid,A.s_pwd,A.uid,A.password,A.parent_id,A.Category_short,A.student_id,A.stream,A.main_group,A.sub_group,A.group_id,A.name,A.sl_date,A.feepaidupto,A.TcIssueDate,A.extra_activities,A.birth_date,A.f_name,A.m_name,A.roll_no,A.photo,A.aadhar,A.blood_group,A.admno,A.adm_date,A.gender,A.mobile_sms,A.acno,A.village,A.postoffice,A.tehsil,A.district,A.state,A.pincode,A.house,A.f_name,A.m_name,A.mobile_sms,A.category,A.vilage_id,A.f_mobile,A.m_mobile,A.f_occupation,A.feepaymentmode,A.phone_home,A.address_line1,A.address_line2,A.address,A.f_qualification,A.m_qualification,A.religion,A.m_occupation from ( SELECT S.MSID,S.student_id as s_id,(S.adm_classno + CU.MySession-year (S.fees_date)+COALESCE(sum(E.result),0)) as class,S.roll_no,S.aadhar,S.gender,S.admno,CLA.class_name adm_class_name,S.photo,S.adm_date,S.blood_group,S.name,S.acno,S.stream,S.main_group,S.sub_group,S.group_id,S.student_id,S.sl_date,S.feepaidupto,S.TcIssueDate,S.extra_activities,S.birth_date,P.f_name,P.m_name,P.village as vilage_id,P.mobile_sms,P.category,P.f_mobile,P.m_mobile,P.annual_income,P.f_occupation,P.m_occupation,P.phone_home,P.address_line1,P.address_line2,P.feepaymentmode,P.address,P.f_qualification,P.m_qualification,P.religion,L.name as village,If(L.post_id='',L.postoffice,LB.postoffice)postoffice,If(L.post_id='',L.tehsil,LB.tehsil)tehsil,If(L.post_id='',L.district,LB.district)district,If(L.post_id='',L.state,LB.state)state,If(L.post_id='',L.pincode,LB.pincode)pincode,H.house_f_name as house,S.adm_classno,S.opening_bal,S.parent_id,S.uid as s_uid,S.password as s_pwd,P.uid,P.password,S.section,Sec.sec_name,C.Name category_Name,C.Short_Name category_short FROM `ms_students` S INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='10046vm3')CU ON CU.msid=S.msid AND CU.MyDate Between S.Fees_Date AND S.sl_Date left join ms_exams E on E.MSID=S.MSID and E.s_id=S.student_id left join ms_schools_section Sec on Sec.MSID=S.MSID and S.section=Sec.section_id left join ms_parents P on P.MSID= S.MSID and P.id = S.parent_id left join ms_locality L on L.MSID= S.MSID and P.village =L.id LEFT JOIN ms_locality_b LB ON L.post_id =LB.Id left join ms_houses H on H.MSID= S.MSID and H.house_id= S.house left join ms_category C on C.MSID= S.MSID and C.cat_id= P.category INNER JOIN ms_classes CLA ON CLA.MSID=S.MSID AND CLA.class_no=S.adm_classno Where 1 group by S.student_id ) as A inner join ms_schools CC on CC.MSID=A.MSID and A.class between CC.class_from And CC.class_to AND A.class= '3' INNER JOIN ms_classes CL ON CL.msid=A.msid AND CL.class_no=A.class order by A.student_id 
    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_hostels($msid = NULL, $id = NULL,
            $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "hostels";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }

            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_hostelers($msid = NULL, $id = NULL, $s_id = NULL,
            $hostel_id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "hosteler";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            if ($s_id != NULL) {
                $sql .= " AND s_id=" . $s_id;
            }
            
            if ($s_id != NULL) {
                $sql .= " AND s_id=" . $s_id;
            }
            

            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    
    public static function hostel_stu_data($msid= NULL)
    {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "hostels";
            $sql .= " where MSID=" . $msid;

            $sql .= " order by id ASC";
            

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
        
        
    }
    
    
    public static function get_hostelers_stu($msid = NULL, $mydate = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "hosteler";
            $sql .= " where MSID=" . $msid;

            
            if ($mydate!= NULL) {
                $sql .= " AND to_date >=" . $mydate;
            }

            $sql .= " order by id ASC";
            

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    
    
    public static function get_stu_hostel_data($msid = NULL,$id = NULL,$mydate = NULL)
    {
        try
     {
       $sql="SELECT * FROM ".DB_PREFIX."hosteler";
       $sql .= " where MSID=".$msid;
 
       $sql .= " AND s_id=".$id;
       $sql .= " AND '".$mydate."' BETWEEN from_date AND to_date";
       $sql .= " ORDER BY id DESC LIMIT 0,1";
//       print_r($sql);
       $oDb = DBConnection::get();
       $sql = $oDb->query($sql);
         return $sql;
             
         
         
    } 
     catch (Exception $e) 
     {
        $message = new Messages();
        $message->add('e', $e->getMessage());
     }
        
        
        
    }
    
     public static function get_allstu_hostel_data($msid = NULL,$id = NULL)
    {
        try
     {
       $sql="SELECT * FROM ".DB_PREFIX."hosteler";
       $sql .= " where MSID=".$msid;
 
       $sql .= " AND s_id=".$id;
       //$sql .= " AND '".$mydate."' BETWEEN from_date AND to_date";
       $sql .= " ORDER BY id DESC";
//       print_r($sql);
       $oDb = DBConnection::get();
       $sql = $oDb->query($sql);
         return $sql;
             
         
         
    } 
     catch (Exception $e) 
     {
        $message = new Messages();
        $message->add('e', $e->getMessage());
     }
        
        
        
    }
    
    
    
    public static function get_stulast_hostel_data($msid = NULL,$stu_id = NULL,$id=NULL)
    {
        try
     {
       $sql="SELECT * FROM ".DB_PREFIX."hosteler";
       $sql .= " where MSID=".$msid;
 
       $sql .= " AND s_id=".$stu_id;
       
       $sql .= " AND id=".$id;
       
       //$sql .= " AND '".$mydate."' BETWEEN from_date AND to_date";
       $sql .= " ORDER BY id DESC";
//       print_r($sql);
       $oDb = DBConnection::get();
       $sql = $oDb->query($sql);
         return $sql;
             
         
         
    } 
     catch (Exception $e) 
     {
        $message = new Messages();
        $message->add('e', $e->getMessage());
     }
        
        
        
    }


public static function stu_del_hostel($msid = NULL,$id = NUll,$date_from = NULL)
 {
     try {

            $oDb = DBConnection::get();
            $upsql = $oDb->prepare("Delete From `ms_hosteler` where `id`='$id' AND `MSID`='$msid' AND from_date ='$date_from'");
//            print_r($upsql);
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
     
     
 }
    
 
 public static function stuhostel_del($msid = null, $id = null)
 {
    try {

            $oDb = DBConnection::get();
            $upsql = $oDb->prepare("Delete From `ms_hosteler` where `id`='$id' AND `MSID`='$msid'");
//            print_r($upsql);
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
     
     
     
     
 }
 
 
 

}




   




?>
