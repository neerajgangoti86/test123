<?php

class TimeTable {

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
   public static function get_classes($msid = NULL) {
        try {
            $sql = "select * from `" . DB_PREFIX . "classes` ";
                 
            $sql .= " where MSID=" . $msid;

            $sql .= " order by class_no ASC";
      

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_used_days($msid = NULL,$class = NULL,$period = NULL,$section = NULL ) {
        try {
            $sql = "select GROUP_CONCAT(DISTINCT days  ORDER BY days ASC SEPARATOR ',')  used_days from  `" . DB_PREFIX . "time_tb` where MSID='". $msid."'  and Class='". $class."'  and Section='". $section."'  and Period='". $period."' ";
      

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
  public static function get_timetb($msid = NULL,$class = NULL,$period = NULL,$section = NULL ) {
        try {
            $sql = "SELECT M.`MSID`,  M.`id`, M.`Period`, M.`Days`, M.`Class`, M.`Section`, M.`Subject` ,E.emp_name,E.Id ,E.MSID,S.subject_f_name,(S.subject_id) as sub,S.MSID FROM `" . DB_PREFIX . "time_tb` M INNER JOIN " . DB_PREFIX . "employee  E on M.`Empid` =E.id  And M.MSID=E.MSID INNER JOIN " . DB_PREFIX . "subjects_all S on S.subject_id=M.Subject  And M.MSID=S.MSID  where `Class`='". $class."' And `Period`='". $period."' And E.MSID=' ". $msid."' And M.MSID='". $msid."' And S.MSID='". $msid."'    And M.`Section`='".$section."'";
//            print_r($sql) ;
         

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_time_table_dtl($msid = NULL,$id = NULL) {
        try {
            $sql = "SELECT * FROM `" . DB_PREFIX . "time_tb`  where `id`='". $id."' And `MSID`='". $msid ."'";
      
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
     public static function delete_timetb($id = NULL) {
        try {
            $sql = "DELETE FROM `ms_time_tb` WHERE `id` = ".$id;
      

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            print_r($sql);
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

}

?>
