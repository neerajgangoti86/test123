<?php

class SuperAdmin {

    public function __construct() {
        
    }

    public static function get_subject($id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "subjects_all";

            if ($id != NULL) {
                $sql .= " WHERE subject_id=" . $id;
            }
            $sql .= " order by subject_id ASC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_school_boards($id = NULL) {
        $sql = "SELECT * FROM " . DB_PREFIX . "school_boards";
        if ($id != NULL) {
            $sql .= " WHERE id=" . $id;
        }
        $sql .= " order by id ASC";
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }
    
    public static function get_act_subject2($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "schoolwise_subjects WHERE 1";
            if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }
            if (@$id) {
                $sql .= " AND subject_id IN (".$id.")";
            } 
            $sql .= " order by MSID ASC";
              
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    public static function get_act_assesment2($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_assesments WHERE 1";
            if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }
            if (@$id) {
                $sql .= " AND assesment_id IN (".$id.")";
            } 
            $sql .= " order by MSID ASC";
              
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    public static function get_act_class2($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "classes WHERE 1";
            if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }
            if (@$id) {
                $sql .= " AND class_no IN (".$id.")";
            } 
            $sql .= " order by MSID ASC";
              
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_subject_group($id = NULL, $limit = NULL, $data = array()) {
        try {
            $sql = "select SLG.group_id AS group_id,group_concat(S.subject_s_name order by SLG.orders ASC separator ' ') AS Subjects from " . DB_PREFIX . "subjects_group SLG join " . DB_PREFIX . "subjects_all S on(S.subject_id = SLG.subject_id)";

            if ($id != NULL) {
                $sql .= " WHERE SLG.group_id=" . $id;
            }
            $sql .= " group by SLG.group_id";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_stream($msid = NULL, $stream = NULL) {
        try {
            $sql = "SELECT distinct `stream` FROM `ms_subjects` WHERE `MSID`='".$msid."'";

            if ($stream != NULL) {
                $sql .= " And `stream` like '".$stream."'";
            }
            $sql .= " And `stream`!='' Order By stream Asc";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_stream_subjects($msid = NULL, $stream = NULL) {
        try {
            $sql = "SELECT Distinct MS.`subject_id`,MS.`name`, SB.`subject_f_name`  FROM `ms_subjects` S Inner join `ms_subjects_group` SG ON S.`subject_gp_id`= SG.`group_id` Inner Join `ms_subjects_all` SB ON SG.`subject_id`=SB.`subject_id` Inner join `ms_schoolwise_subjects` MS ON SB.`subject_f_name` LIKE MS.`name` And S.`MSID`=MS.`MSID`  WHERE S.`MSID`='".$msid."' And S.`stream`='".$stream."'";

           
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_subjects_from_group($id = NULL, $limit = NULL, $data = array()) {
        try {
            $sql = "select group_concat(S.subject_f_name order by SLG.orders ASC ) AS subjects , group_concat(S.subject_id order by SLG.orders ASC ) AS subject_id from " . DB_PREFIX . "subjects_group SLG join " . DB_PREFIX . "subjects_all S on(S.subject_id = SLG.subject_id)";

            if ($id != NULL) {
                $sql .= " WHERE SLG.group_id=" . $id;
            }
            $sql .= " group by SLG.group_id";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
 public static function get_subjects_from_datesheet($msid = NULL,$section = NULL,$session = NULL,$assessment = NULL,$class = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_datesheet dt inner join " . DB_PREFIX . "schoolwise_subjects  ss ON dt.msid=ss.msid and dt.subject=ss.subject_id WHERE 1";
            if ($msid != NULL) {
                $sql .= " AND dt.msid=" . $msid;
            }
            if ($section != NULL) {
                $sql .= " AND dt.section=" . $section;
            } 
               if ($msid != NULL) {
                $sql .= " AND dt.session=" . $session;
            }
            if ($section != NULL) {
                $sql .= " AND dt.assessment=" . $assessment;
            } 
             if ($section != NULL) {
                $sql .= " AND dt.class=" . $class;
            }
           
            $sql .= " order by ss.subject_id";
//print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_assessment_from_datesheet($msid = NULL,$section = NULL,$session = NULL,$assessment = NULL,$class = NULL) {
        try {
            $sql = "SELECT *,dt.max_marks as mxmks ,dt.id as dtid  FROM " . DB_PREFIX . "exam_datesheet dt left join " . DB_PREFIX . "exam_assesments  es ON dt.msid=es.msid and dt.assessment=es.assesment_id WHERE 1";
            if ($msid != NULL) {
                $sql .= " AND dt.msid=" . $msid;
            }
            if ($section != NULL) {
                $sql .= " AND dt.section=" . $section;
            } 
               if ($msid != NULL) {
                $sql .= " AND dt.session=" . $session;
            }
            if ($section != NULL) {
                $sql .= " AND dt.assessment=" . $assessment;
            } 
             if ($section != NULL) {
                $sql .= " AND dt.class=" . $class; 
            }
//print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
     public static function get_assessment_from_date($msid = NULL,$section = NULL,$session = NULL,$assessment = NULL,$class = NULL) {
        try {
            $sql = "SELECT *,dt.max_marks as mxmks ,dt.id as dtid  FROM " . DB_PREFIX . "exam_datesheet dt left join " . DB_PREFIX . "exam_assesments  es ON dt.msid=es.msid and dt.assessment=es.assesment_id WHERE 1";
            if ($msid != NULL) {
                $sql .= " AND dt.msid=" . $msid;
            }
            if ($section != NULL) {
                $sql .= " AND dt.section=" . $section;
            } 
               if ($msid != NULL) {
                $sql .= " AND dt.session=" . $session;
            }
            if ($section != NULL) {
                $sql .= " AND dt.assessment=" . $assessment;
            } 
             if ($section != NULL) {
                $sql .= " AND dt.class=" . $class; 
            }
//print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    public static function get_marks_from_academicperformence($msid = NULL,$section = NULL,$dtid = NULL,$sid = NULL,$class = NULL) {
        try { 
            $sql = "SELECT *  FROM " . DB_PREFIX . "exam_acedemic_performance  dt WHERE 1";

            if ($msid != NULL) {
                $sql .= " AND dt.msid=" . $msid;
            }
            
            if ($section != NULL) {
                $sql .= " AND dt.section=" . $section;
            } 
               if ($msid != NULL) {
                $sql .= " AND dt.datesheet_id=" . $dtid;
            }
            if ($section != NULL) {
                $sql .= " AND dt.student_id=" . $sid;
            } 
             if ($section != NULL) {
                 
                $sql .= " AND dt.class=" . $class; 
            }
            

//            if ($limit != 'all') {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//            }
//            print_r($sql); 
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_school_subject($msid = NULL, $id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "subjects ";

            if ($id != NULL) {
                $sql .= " WHERE id=" . $id;
            }
            if ($msid != NULL) {
                $sql .= " WHERE MSID=" . $msid;
            }
            $sql .= " order by id ASC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
  public static function schoolSubjFeeGroup($msid = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "subjects";

			if ($msid != NULL) {
                $sql .= " WHERE MSID=" . $msid;
            }
            $sql .= " group by fee_group_id order by fee_group_id ASC";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
  } 	
  public static function get_schoolwise_subject($msid = NULL, $id = NULL, $data = array('page' => 1, 'record_per_page' => 10), $class_id = NULL,$lib="NO",$rec="NO",$overall="NO",$subject_id=Null) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "schoolwise_subjects WHERE 1";

            if (@$id) {
                $sql .= " AND subject_id=" . $id;
            }
            if (@$subject_id) {
                $sql .= " AND subject_id=" . $subject_id;
            }if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }

            if ($class_id != NULL) {
                $sql .= " AND FIND_IN_SET('" . $class_id . "',class)";
            }
            if ($rec == "YES") {
                $sql .= " AND record = 1 ";
            } if ($lib == "YES") {
                $sql .= " AND lib = 1 ";
            } if ($overall == "YES") {
                $sql .= " AND overall_grade = 1 ";
            }
            $sql .= " order by MSID ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    public static function get_schoolwise_subject2($msid = NULL, $id = NULL, $data = array('page' => 1, 'record_per_page' => 10), $class_id = NULL,$lib="NO",$rec="NO",$overall="NO") {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "schoolwise_subjects WHERE 1";

            if (@$id) {
                $sql .= " AND subject_id=" . $id;
            } if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }

           /* if ($class_id != NULL) {
                $sql .= " AND FIND_IN_SET('" . $class_id . "',class)";
            }*/
            
            if ($class_id != NULL) {
                $sql .= " AND ". $class_id ." BETWEEN class AND class_to ";
            }
            
            if ($rec == "YES") {
                $sql .= " AND record = 1 ";
            } if ($lib == "YES") {
                $sql .= " AND lib = 1 ";
            } if ($overall == "YES") {
                $sql .= " AND overall_grade = 1 ";
            }
            $sql .= " order by MSID ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    
    
    
    
    
    
//
//    public static function get_stream($id = NULL) {
//        $sql = "SELECT * FROM " . DB_PREFIX . "stream";
//        if ($id != NULL) {
//            $sql .= " WHERE id=" . $id;
//        }
//        $sql .= " order by id ASC";
//        $oDb = DBConnection::get();
//        $sql = $oDb->query($sql);
//        return $sql;
//    }

    public function add_subject_group($gid = NULL, $newgid = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            if (empty($postdata['subjectid']))
                $message->add('e', 'Subject is required..!!');
            if (!$message->hasMessages()) {

                if (!empty($gid)) {//update classes
                    foreach ($postdata['subjectid'] as $sbid) {
                        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'subjects_group SET orders = :orders WHERE subject_id = :subject_id AND group_id = :group_id');

                        $upsql->execute(array(
                            ':orders' => $postdata['suborder_' . $sbid],
                            ':subject_id' => $sbid,
                            ':group_id' => $gid
                        ));
                    }
                    $message->add('s', 'Subject group updated successfully!', CLIENT_URL . '/subjectgroup');
                    exit();
                }
                else {//insert into database
                    foreach ($postdata['subjectid'] as $sbid) {
                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'subjects_group (subject_id, group_id) VALUES  (:subject_id, :group_id)');

                        $sql->execute(array(
                            ':subject_id' => $sbid,
                            ':group_id' => $newgid
                        ));
                    }

                    $message->add('s', 'Subject group added successfully!', CLIENT_URL . '/subjectgroup');
                    exit();
                }
            }
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function add_school_subject($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            // Insert into database //
            if (strlen(trim(@$postdata['currschool'])) == 0)
                $message->add('e', 'School is required..!!');
            if (strlen(trim(@$postdata['subgrpid'])) == 0)
                $message->add('e', 'Subject is required..!!');
			if (strlen(trim(@$postdata['subfeegroup'])) == 0)
                $message->add('e', 'Subject Fee Group is required..!!');		
            if (!$message->hasMessages()) {

                if (!empty($id)) {//update classes
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'subjects SET subject_gp_id = :subject_gp_id, fee_group_id = :fee_group_id WHERE id = :id');
                    $upsql->execute(array(
                        ':subject_gp_id' => $postdata['subgrpid'],
                        ':fee_group_id' => $postdata['subfeegroup'],
						':id' => $id
						));
                    $message->add('s', 'Subject updated successfully!', CLIENT_URL . '/school-subject-group');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'subjects (MSID, subject_gp_id, fee_group_id, created_date) VALUES  (:MSID, :subject_gp_id, :fee_group_id, :created_date)');

                    $sql->execute(array(
                        ':MSID' => $postdata['currschool'],
                        ':subject_gp_id' => $postdata['subgrpid'],
						':fee_group_id' => $postdata['subfeegroup'],
                        ':created_date' => date('Y-m-d H:i:s')
                    ));
                    $message->add('s', 'Subject added successfully!', CLIENT_URL . '/school-subject-group');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_subject($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            // Insert into database //
            if (strlen(trim(@$postdata['subsname'])) == 0)
                $message->add('e', 'Subject shortname is required..!!');
            if (strlen(trim(@$postdata['subfname'])) == 0)
                $message->add('e', 'Subject fullname is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update classes
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'subjects_all SET subject_s_name = :subject_s_name, subject_f_name = :subject_f_name WHERE subject_id = :subject_id');
                    $upsql->execute(array(
                        ':subject_s_name' => $postdata['subsname'],
                        ':subject_f_name' => $postdata['subfname'],
                        ':subject_id' => $id
                    ));
                    $message->add('s', 'Subject updated successfully!', CLIENT_URL . '/subjectall');
                    exit();
                }
                else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'subjects_all (subject_s_name, subject_f_name, created_date, status) VALUES  (:subject_s_name, :subject_f_name, :created_date, :status)');

                    $sql->execute(array(
                        ':subject_s_name' => $postdata['subsname'],
                        ':subject_f_name' => $postdata['subfname'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => 1
                    ));
                    $message->add('s', 'Subject added successfully!', CLIENT_URL . '/subjectall');
                    exit();
                }
            }
        }
        catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }



 public static function get_datesheet_subject($msid = NULL, $id = NULL, $class_id = NULL,$lib="NO",$rec="NO",$overall="NO",$subject_id=Null) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_datesheet WHERE 1";

            if (@$id) {
                $sql .= " AND id=" . $id;
            }
            if (@$subject_id) {
                $sql .= " AND subject_id=" . $subject_id;
            }if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }

            if ($class_id != NULL) {
                $sql .= " AND FIND_IN_SET('" . $class_id . "',class)";
            }
            if ($rec == "YES") {
                $sql .= " AND record = 1 ";
            } if ($lib == "YES") {
                $sql .= " AND lib = 1 ";
            } if ($overall == "YES") {
                $sql .= " AND overall_grade = 1 ";
            }
            $sql .= " order by MSID ASC";

//            if ($data['selectAll'] == 'false') {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        }
        catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
}
?>
