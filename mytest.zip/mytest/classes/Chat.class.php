<?php

class Chat {

    /**
     * get enrolled student list for admission tab(module)
     * @param string $msid
     * @param string $limit
     * @param string rejected
     */
    public static function get_inbox($msid = NULL, $conversation_id = NULL, $u_role = NULL, $from_id = NULL, $to_id = NULL, $distinct = "False", $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10), $order = NULL) {
        if ($distinct == "true") {
            $sql = "SELECT distinct (`to_id`) FROM " . DB_PREFIX . "messages";
        } else {
            $sql = "SELECT * FROM " . DB_PREFIX . "messages";
        }
        $sql .= " where MSID=" . $msid;
        if ($conversation_id != NULL) {
            $sql .= " And conversation = '" . $conversation_id . "'";
        }
        if ($u_role != NULL) {
            $sql .= " And from_role = '" . $u_role . "'";
        }
        if ($distinct == "both") {
            $sql .= " And (( from_id = '" . $from_id . "' AND to_id = '" . $to_id . "') or ( to_id = '" . $from_id . "' AND from_id = '" . $to_id . "')  ) ";
        } else {
            if ($from_id != NULL) {
                $sql .= " And from_id = '" . $from_id . "'";
            }
            if ($to_id != NULL) {
                $sql .= " And to_id = '" . $to_id . "'";
            }
        }
        if ($order != NULL) {
            $sql .= " order by id  " . $order;
        }

        if ($limit != 'all') {
            $records_per_page = $data['record_per_page'];
            $starting_position = ($data['page'] - 1) * $records_per_page;
            $sql .= " limit $starting_position, $records_per_page";
        }
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
//        print_r($sql);
        return $sql;
    }

    public static function new_conversation($msid, $data = array()) {
        $sql = "INSERT INTO " . DB_PREFIX . "conversations (MSID, user_one, user_two, role_one, role_two) VALUES('" . $msid . "', '" . $data['user_one'] . "', '" . $data['user_two'] . "', '" . $data['role_one'] . "', '" . $data['role_two'] . "')";
//        print_r($sql);die();
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
    }

    public static function all_conversations($msid, $id = NULL, $data = array()) {
        $sql = "SELECT * FROM " . DB_PREFIX . "conversations WHERE MSID = " . $msid;
        if ($id != NULL) {
            $sql .= " AND id = " . $id;
        }
        if (@$data['field_one'] && !@$data['field_two']) {
            $sql .= " AND user_one = '" . $data['field_one'] . "' OR user_two = '" . $data['field_one'] . "'";
        }
        if (@$data['field_one'] && @$data['field_two']) {
            $sql .= " AND user_one = '" . $data['field_one'] . "' AND user_two = '" . $data['field_two'] . "' OR user_one = '" . $data['field_two'] . "' AND user_two = '" . $data['field_one'] . "'";
        }

//        print_r($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function unread_messages($msid, $data = array()) {
        $sql = "SELECT * FROM " . DB_PREFIX . "messages WHERE MSID = " . $msid;
        if (ISSET($data['status']) != NULL) {
            $sql .= " AND `read` = " . $data['status'];
        }
        if (@$data['conversation'] != NULL) {
            $sql .= " AND conversation = '" . $data['conversation'] . "'";
        }
        if (@$data['to_id'] != NULL) {
            $sql .= " AND to_id = '" . $data['to_id'] . "'";
        }
        if (@$data['from_id'] != NULL) {
            $sql .= " AND from_id = '" . $data['from_id'] . "'";
        }
//        printf($sql);
        $oDb = DBConnection::get();
        $sql = $oDb->query($sql);
        return $sql;
    }

    public static function new_message($msid, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
//            pr($postdata);
            $check = self::all_conversations($msid, NULL, array('field_one' => $postdata['from_id'], 'field_two' => $postdata['to_id']))->rowCount();
//            pr($check); //die();
            if ($check == 0) {
                $data = array(
                    'user_one' => $postdata['from_id'] ,
                    'user_two' => $postdata['to_id'],
                    'role_one' => $postdata['from_role'],
                    'role_two' => $postdata['to_role']
                );
                self::new_conversation($msid, $data);
            }

            $conversation = self::all_conversations($msid, NULL, array('field_one' => $postdata['from_id'], 'field_two' => $postdata['to_id']))->fetch();
//            pr($postdata);
            $to_role = (@$postdata['to_role']) ? $postdata['to_role'] : 0;

            //insert into database
            $upsql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'messages (MSID, message, from_role, to_role, from_id, to_id, ip, date_time, conversation)'
                    . ' VALUES(:MSID, :message, :from_role, :to_role, :from_id, :to_id, :ip, :date_time, :conversation)');

            $upsql->execute(array(
                ':MSID' => $msid,
                ':message' => $postdata['message'],
                ':from_role' => $postdata['from_role'],
                ':to_role' =>$to_role,
                ':from_id' => $postdata['from_id'],
                ':to_id' => $postdata['to_id'],
                ':ip' => $postdata['ip'],
                ':date_time' => $postdata['date_time'],
                ':conversation' => $conversation['id'],
            ));
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function update_message($msid, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //insert into database   UPDATE `ms_messages` SET `read`= 1 WHERE `MSID` = 1001 AND `conversation` = 17
            $sql = "UPDATE " . DB_PREFIX . "messages SET ";
            if (@$postdata['message'] != NULL) {
                $sql .= "`message` = '" . $postdata['message'] . "', ";
            }
            if (@$postdata['read'] != NULL) {
                $sql .= "`read` = " . $postdata['read'];
            }
            $sql .= " WHERE `MSID` = " . $msid . " AND `conversation` = " . $postdata['chat_id'];


            $oDb->query($sql);
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

}

?>
