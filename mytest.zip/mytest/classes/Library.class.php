<?php

class Library {

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_category($msid = NULL, $id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "book_category";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function add_category($id = NULL, $postdata = array()) {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['name'])) == 0)
                $message->add('e', 'Category Name is required..!!');
            if (!$message->hasMessages()) {
                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'book_category SET name = :name  WHERE id = :id');
//                    print_r($upsql);
//                    exit();
                    $upsql->execute(array(
                        ':name' => $postdata['name'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Books Category updated successfully!', CLIENT_URL . '/library/cat');
                    exit();
                } else {//insert into database
//                    print_r($update_img);
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'book_category (MSID, name) VALUES  (:MSID, :name)');
                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':name' => $postdata['name']
                    ));
                    $message->add('s', 'Books Category  added successfully!', CLIENT_URL . '/library/cat');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_book($id = NULL, $postdata = array()) {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['isbn'])) == 0)
                $message->add('e', 'ISBN Number is required..!!');
            if (strlen(trim(@$postdata['title'])) == 0)
                $message->add('e', 'Title is required..!!');
            if (strlen(trim(@$postdata['category_id'])) == 0)
                $message->add('e', 'Category is required..!!');
            if (strlen(trim(@$postdata['author'])) == 0)
                $message->add('e', 'Author Name is required..!!');
            if (strlen(trim(@$postdata['edition'])) == 0)
                $message->add('e', 'Editions are required..!!');
            if (strlen(trim(@$postdata['publisher'])) == 0)
                $message->add('e', 'Publisher Name is required..!!');
            if (strlen(trim(@$postdata['copy_taken'])) == 0)
                $message->add('e', 'No Of Copy Taken is required..!!');
            if (strlen(trim(@$postdata['book_position'])) == 0)
                $message->add('e', 'Book Position is required..!!');
            if (strlen(trim(@$postdata['shelf_no'])) == 0)
                $message->add('e', 'Shelf No is required..!!');
            if (!$message->hasMessages()) {
                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'book SET isbn = :isbn , title = :title,category_id = :category_id,author = :author,edition = :edition,publisher = :publisher,copy_taken = :copy_taken,book_position = :book_position,shelf_no = :shelf_no  WHERE id = :id');
                    $upsql->execute(array(
                        ':isbn' => $postdata['isbn'],
                        ':title' => $postdata['title'],
                        ':category_id' => $postdata['category_id'],
                        ':author' => $postdata['author'],
                        ':edition' => $postdata['edition'],
                        ':publisher' => $postdata['publisher'],
                        ':copy_taken' => $postdata['copy_taken'],
                        ':book_position' => $postdata['book_position'],
                        ':shelf_no' => $postdata['shelf_no'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Books Category updated successfully!', CLIENT_URL . '/library/book');
                    exit();
                } else {//insert into database
//                    print_r($update_img);
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'book (MSID,isbn,title,category_id,author,edition,publisher,copy_taken,book_position,shelf_no) VALUES(:MSID,:isbn,:title,:category_id,:author,:edition,:publisher,:copy_taken,:book_position,:shelf_no)');
                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':isbn' => $postdata['isbn'],
                        ':title' => $postdata['title'],
                        ':category_id' => $postdata['category_id'],
                        ':author' => $postdata['author'],
                        ':edition' => $postdata['edition'],
                        ':publisher' => $postdata['publisher'],
                        ':copy_taken' => $postdata['copy_taken'],
                        ':book_position' => $postdata['book_position'],
                        ':shelf_no' => $postdata['shelf_no'],
                    ));
                    $message->add('s', 'Books Category  added successfully!', CLIENT_URL . '/library/book');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_books($msid = NULL, $id = NULL, $isbn = NULL, $category_id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "book";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            if ($isbn != NULL) {
                $sql .= " AND isbn=" . $isbn;
            }
            if ($category_id != NULL) {
                $sql .= " AND category_id=" . $category_id;
            }
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage()); 
        }
    } 
public static function get_total_books($msid = NULL, $cat_id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT Sum(If(category_id='$cat_id',1,0)) AS tbooks FROM " . DB_PREFIX . "book";
            $sql .= " where MSID=" . $msid;

            
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//           print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
  public static function get_skl_subjects($msid = NULL, $uslib = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT  * FROM " . DB_PREFIX . "schoolwise_subjects";
            if ($msid != NULL) {  
               $sql .= " where MSID=" . $msid;
            } if ($uslib != NULL) {
                $sql .= " AND lib=" . $uslib;
            }

           
            $sql .= " order by subject_id ASC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page"; print_r($records_per_page);
            }
           
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function get_lb_books($msid = NULL,$subject_id = NULL, $cat_id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT Sum(If(subject='$subject_id',1,0)) AS sbbooks FROM " . DB_PREFIX . "book";
            $sql .= " where MSID=" . $msid;
                    if ($cat_id != NULL) {
                       $sql .= " AND category_id=" . $cat_id;
                           }
                           
                          
            
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//           print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
  

    public function add_issue_book($id = NULL, $postdata = array()) {
        $sGeneral = new General();
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
//            print_r($_POST);
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['student_id'])) == 0)
                $message->add('e', 'Student Id is required..!!');
            if (strlen(trim(@$postdata['book_id'])) == 0)
                $message->add('e', 'Book Id is required..!!');
            if (strlen(trim(@$postdata['book_name'])) == 0)
                $message->add('e', 'Book Name is required..!!');
            if (strlen(trim(@$postdata['due_date'])) == 0)
                $message->add('e', 'Due Date  is required..!!');
            if (!$message->hasMessages()) {
//                if (!empty($id)) {//update designation
//                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'book_borrow SET isbn = :isbn , student_id = :student_id,book_name = :book_name,book_id = :book_id,issue_date = :issue_date,due_date = :due_date WHERE id = :id');
//                    $upsql->execute(array(
//                        ':isbn' => $postdata['isbn'],
//                        ':student_id' => $postdata['student_id'],
//                        ':book_name' => $postdata['book_name'],
//                        ':book_id' => $postdata['book_id'],
//                        ':issue_date' => date('Y-m-d'),
//                        ':due_date' => $postdata['due_date'],
//                        ':id' => $id
//                    ));
//                    $message->add('s', 'Books Is Issued updated successfully!',
//                            CLIENT_URL . '/library/due');
//                    exit();
//                } 
//                else {//insert into database
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'book_borrow (MSID,student_id,book_name,book_id,issue_date,due_date) VALUES(:MSID,:student_id,:book_name,:book_id,:issue_date,:due_date)');

                $sql->execute(array(
                    ':MSID' => $postdata['MSID'],
                    ':student_id' => $postdata['student_id'],
                    ':book_name' => $postdata['book_name'],
                    ':book_id' => $postdata['book_id'],
                    ':issue_date' => date('Y-m-d'),
                    ':due_date' => $postdata['due_date']
                ));

                $message->add('s', 'Books is Issued successfully!', CLIENT_URL . '/library/due');
                exit();
            }
//            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_return_book($id = NULL, $fine = Null) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
//            print_r($_POST);
            //********* Insert into database *********//
            if (!empty($id)) {//update designation
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'book_borrow SET fine_amount = :fine_amount,status= :status,return_date= :return_date WHERE id = :id');
                $upsql->execute(array(
                    ':fine_amount' => $fine,
                    ':return_date' => date('Y-m-d'),
                    ':status' => '0',
                    ':id' => $id
                ));
                $message->add('s', 'Books Returned successfully!', CLIENT_URL . '/library/return');
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_due_book($msid = NULL, $id = NULL, $student_id = NULL, $status = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "book_borrow";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            if ($student_id != NULL) {
                $sql .= " AND student_id=" . $student_id;
            }
            if ($status != NULL) {
                $sql .= " AND status= '" . $status . "'";
            }
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

}

?>
