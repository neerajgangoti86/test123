<?php

class Role
    {

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    
    
    
    
    public static function get_role($id = NULL, $data = array('selectAll' => 'true'))
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "user_roles ";

//            if ($msid != NULL) {
//            $sql .= " where MSID=" . $msid;
//            }
            if ($id != NULL)
                {
                $sql .= "WHERE id=" . $id;
                }
            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public static function add_privilages($msid = NULL, $post = array())
        {
        try
            {
            $models = Master::get_modules()->fetchall();
            //pr($models);
            $ar= array();
            foreach ($models as $key =>$val){
                $ar[]= $val['id'];
            }
            $CheckGroups = array();
            $CheckGroups = array_diff($ar, $post['chk_group']);
            //pr($CheckGroups);

            $arAS= array();
            foreach ($CheckGroups as $key =>$val){
                $arAS[]= $val;
            }
            //pr($arAS);//die();
                $CheckGroup = json_encode($arAS);
            
            if(empty($post['privilegeADD'])){ $add = 0; }else{ $add = $post['privilegeADD']; }
            if(empty($post['privilegeEDIT'])){ $edit = 0; }else{ $edit = $post['privilegeEDIT']; }
            if(empty($post['privilegeDEL'])){ $delete = 0; }else{ $delete = $post['privilegeDEL']; }
            
            $oDb = DBConnection::get();
            $SQL = "INSERT INTO " . DB_PREFIX . "privileges_users "
                    . "(MSID, userId, role, ulevel, modules, p_add, p_edit, p_delete, status) VALUES"
                    . "(:msid, :userid, :role, :ulevel, :modules, :padd, :pedit, :pdelete, :status)";
            //print_r($SQL);
            $QUERY = $oDb->prepare($SQL);
            $EXT = $QUERY->execute(array(
                ':msid' => $msid,
                ':userid' => @$post['userId'],
                ':role' => @$post['role'],
                ':ulevel' => @$post['ulevel'],
                ':modules' => $CheckGroup,
                ':padd' => $add,
                ':pedit' => $edit,
                ':pdelete' => $delete,
                ':status' => @$_POST['status'],
            ));
            $message = new Messages();
            $message->add('s', 'New Privilege added successfully!', CLIENT_URL . '/privileges');
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        
        
    public static function update_privilages($msid = NULL, $id = NULL, $post = array())
        {
        try
            {
            
            $models = Master::get_modules()->fetchall();
            //pr($models);
            $ar= array();
            foreach ($models as $key =>$val){
                $ar[]= $val['id'];
            }
            $CheckGroups = array();
            $CheckGroups = array_diff($ar, $post['chk_group']);
            //pr($CheckGroups);

            $arAS= array();
            foreach ($CheckGroups as $key =>$val){
                $arAS[]= $val;
            }
            //pr($arAS);//die();
                $CheckGroup = json_encode($arAS);
            if(empty($post['privilegeADD'])){ $add = 0; }else{ $add = $post['privilegeADD']; }
            if(empty($post['privilegeEDIT'])){ $edit = 0; }else{ $edit = $post['privilegeEDIT']; }
            if(empty($post['privilegeDEL'])){ $delete = 0; }else{ $delete = $post['privilegeDEL']; }
            
            $oDb = DBConnection::get();
            $SQL = "UPDATE " . DB_PREFIX . "privileges_users SET"
                    . " userId=:userid, modules=:modules, p_add=:padd, p_edit=:pedit, p_delete=:pdelete"
                    . " WHERE MSID=:msid AND id=:id";
            print_r($SQL);
            $QUERY = $oDb->prepare($SQL);
            $EXT = $QUERY->execute(array(
                
                
                ':userid' => @$post['userId'],
                ':modules' => $CheckGroup,
                ':padd' => $add,
                ':pedit' => $edit,
                ':pdelete' => $delete,
                ':msid' => $msid,
                ':id' => $id,
            ));
            $message = new Messages();
            $message->add('s', 'Privilege Updated successfully!', CLIENT_URL . '/privileges/edit/'.  http_get('param2'));
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        
    public static function privilages($msid, $id = NULL, $userID= NULL, $role=NULL)
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "privileges_users  where MSID=" . $msid;
            if ($id != NULL)
                {
                $sql .= " And id=" . $id;
                }
            if ($userID != NULL)
                {
                $sql .= " And userId='" . $userID."'";
                }
            if ($role != NULL)
                {
                $sql .= " And role='" . $role."'";
                }
                //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public function add_role($id = NULL, $postdata = array())
        {
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {
            if (@$postdata['chk_group'])
                {
                $check_group = json_encode($postdata['chk_group']);
                }
            //********* Insert into database *********//
            if (strlen(trim(@$check_group)) == 0) $message->add('e', 'Role Selection  is required..!!');
//            print_r($_POST);
//            exit();
            if (!$message->hasMessages())
                {

                if (!empty($id))
                    {//update designation
                    $upsql_user = $oDb->prepare('UPDATE ' . DB_PREFIX . 'user_roles SET role_name = :role_name ,  ulevel = :ulevel WHERE id = :id');
                    $upsql_user->execute(array(
                        ':role_name' => $_POST['role_name'],
                        ':ulevel' => $_POST['ulevel'],
                        ':id' => $id
                    ));
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'privileges_users SET privilege_id = :privilege_id WHERE user_id = :user_id');
                    $upsql->execute(array(
                        ':privilege_id' => $check_group,
                        ':user_id' => $id
                    ));
                    $message->add('s', 'TPT User Privlages updated successfully!', CLIENT_URL . '/role');
                    exit();
                    }
                else
                    {
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'user_roles (role_name,ulevel, status) VALUES  (:role_name,:ulevel, :status)');

                    $sql->execute(array(
                        ':role_name' => $postdata['role_name'],
                        ':ulevel' => $postdata['ulevel'],
                        ':status' => '2'
                    ));
                    $parent_id = $oDb->lastInsertId();
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'privileges_users (MSID, user_id, role, u_level, privilege_id, p_add, p_edit, p_delete) VALUES  (:MSID,:user_id, :role, :u_level, :privilege_id, :add, :edit, :delete)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':user_id' => $parent_id,
                        ':role' => $postdata['role_name'],
                        ':u_level' => $postdata['ulevel'],
                        ':privilege_id' => $check_group,
                        ':add' => $parent_id,
                        ':edit' => $parent_id,
                        ':delete' => $parent_id,
                    ));
                    $message->add('s', 'Role added successfully!', CLIENT_URL . '/role');
                    exit();
                    }
                }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }

    public static function get_modules($id = NULL, $data = array('selectAll' => 'true'))
        {
        try
            {
            $sql = "SELECT * FROM " . DB_PREFIX . "modules where 1  ";

//            if ($msid != NULL) {
//            $sql .= " where MSID=" . $msid;
//            }
            if ($id != NULL)
                {
                $sql .= " And id=" . $id;
                }
            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false')
                {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
                }
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }

    public function add_module($id = NULL, $postdata = array())
        {
        $message = new Messages();
        $oDb = DBConnection::get();
        try
            {

            //********* Insert into database *********//



            if (!empty($id))
                {//update designation
                $upsql_user = $oDb->prepare('UPDATE ' . DB_PREFIX . 'modules SET module_name = :module_name WHERE id = :id');
                $upsql_user->execute(array(
                    ':module_name' => $_POST['module'],
                    ':id' => $id
                ));

                $message->add('s', 'Module  updated successfully!', CLIENT_URL . '/modules');
                exit();
                }
            else
                {
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'modules (module_name) VALUES  (:module_name)');

                $sql->execute(array(
                    ':module_name' => $postdata['module'],
                ));
                $parent_id = $oDb->lastInsertId();

                $message->add('s', 'Module added successfully!', CLIENT_URL . '/modules');
                exit();
                }
            }
        catch (PDOException $e)
            {
            $message->add('e', $e->getMessage());
            }
        }

    }

?>
