<?php

class Discount {

    /**
     * get discount name  
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_discounted_students($msid = NULL, $session = NULL, $Ends = NULL, $uid = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT (S.student_id) as sid,S.*,P.*,D.*,L.name, S.`adm_classno`+'$session'-Year(S.`fees_date`)+ COALESCE(SumResult,0) AS CClass FROM (SELECT * 
FROM `ms_slusers` WHERE MyUid = '$uid' ) CU 
                    Inner Join ms_students S On S.MSID=CU.MSID 
                   INNER JOIN ms_parents P ON S.parent_id=P.id And P.MSID=CU.MSID 
                   INNER Join ms_locality L ON P.village=L.id 
                   INNER Join ms_discounted_student D ON S.student_id=D.s_id and S.MSID=D.MSID 
                   LEFT JOIN (SELECT E.s_id, Sum(E.result) AS SumResult FROM ms_exams E WHERE 
                    (((E.MSID)='$msid') AND ((E.date_result)<'$Ends')) GROUP BY E.s_id ) AS Q1 ON S.student_id = Q1.S_Id 
                    WHERE CU.MyDate between D.date_from and D.date_to And CU.Mydate between S.fees_date and S.sl_date ORDER BY `sid` ASC";
            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_discount($msid = NULL, $id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "discount_names";
            if ($msid != NULL) {
                $sql .= " where MSID=" . $msid;
            }
            if ($id != NULL) {
                $sql .= " where discount_id=" . $id;
            }
            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_discount_name($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "discount_names";

            $sql .= " where MSID=" . $msid;

            $sql .= " AND discount_id=" . $id;


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message = new Messages();
            $message->add('e', $ex->getMessage());
        }
    }

    public static function del_stu_discount($msid = NULL, $id = NULL, $date_from = NULL) {

        try {

            $oDb = DBConnection::get();
            $upsql = $oDb->prepare("Delete From `discounted_student` where `id`='$id' AND `MSID`='$msid' AND date_from ='$date_from'");
//            print_r($upsql);
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_stu_discount($msid = NULL, $date_to = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "discounted_student";

            $sql .= " where MSID=" . $msid;

            $sql .= " AND date_to >=" . $date_to;



            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message = new Messages();
            $message->add('e', $ex->getMessage());
        }
    }

    public static function getDiscountRules($msid = NULL, $id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT DS.*,FN.fee_name,DN.name as discount_name FROM " . DB_PREFIX . "discount_rule as DS";
            $sql .= " INNER JOIN " . DB_PREFIX . "fee_names as FN on DS.fee_id=FN.fee_id AND DS.MSID=FN.MSID";
            $sql .= " INNER JOIN " . DB_PREFIX . "discount_names as DN on DS.discount_id=DN.discount_id AND DS.MSID=DN.MSID";

            if ($id != NULL) {
                $sql .= " where DS.id=" . $id;
            } else {
                $sql .= " where DS.MSID=" . $msid;
            }
            $sql .= " AND '" . $_SESSION['user_date'] . "' BETWEEN DS.date_from AND DS.date_to";
            $sql .= " order by id ASC";
            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public function add_discount($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$postdata['name'])) == 0)
                $message->add('e', 'Discount Name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'discount_names SET name = :name WHERE id = :id');
                    $upsql->execute(array(
                        ':name' => $postdata['name'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Discount Name Field updated successfully!', CLIENT_URL . '/discount');
                    exit();
                } else {//insert into database
                    $sqldsid = "SELECT * FROM " . DB_PREFIX . "discount_names where MSID=" . $postdata['MSID'] . " order by discount_id DESC limit 1";

                    $sqldsid = $oDb->query($sqldsid);
                    $sqldsrslt = $sqldsid->fetch(PDO::FETCH_OBJ);
                    if ($sqldsid->rowCount() > 0) {
                        $disconutID = $sqldsrslt->discount_id + 1;
                    } else {
                        $disconutID = 1;
                    }
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'discount_names (MSID, discount_id, name) VALUES  (:MSID, :discount_id, :name)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':discount_id' => $disconutID,
                        ':name' => $postdata['name']
                    ));
                    $message->add('s', 'Discount is added successfully!', CLIENT_URL . '/discount');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_discount_stdnt($msid = NULL, $student_id = NULL) {
        try {
            //SELECT * FROM `ms_discounted_student` WHERE `MSID`=1001 AND `s_id` = '15003'
            $sql = "SELECT * FROM " . DB_PREFIX . "discounted_student ";

            $sql .= " where MSID='" . $msid . "' ";

            $sql .= " AND s_id='" . $student_id . "'";


            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message = new Messages();
            $message->add('e', $ex->getMessage());
        }
    }

    public static function update_stdnt_discount($msid = NULL, $student_id = NULL, $postdata = array()) {
        try {
            $message = new Messages();
            $oDb = DBConnection::get();
            
            $result = self::get_discount_stdnt($msid, $student_id)->rowCount();
            if ($result == 0) {
                $sql = "INSERT INTO ms_discounted_student (MSID, s_id, date_from, date_to, discount_id) VALUES('" . $msid . "', '" . $student_id . "', '" . $postdata['date_from'] . "', '" . $postdata['date_to'] . "', '" . $postdata['discount_id'] . "')";
                $execute = $oDb->query($sql);
            } elseif ($result > 0) {
                $sql = "UPDATE ms_discounted_student SET date_from = '" . $postdata['date_from'] . "', date_to = '" . $postdata['date_to'] . "', discount_id = '" . $postdata['discount_id'] . "' WHERE MSID = '" . $msid . "' AND s_id = '" . $student_id . "' ";
                $execute = $oDb->query($sql);
            }
        } catch (Exception $ex) {
            $message = new Messages();
            $message->add('e', $ex->getMessage());
        }
    }

}

?>
