<?php

class Reportcard
    { 

    /**
     * get transport stations 
     * @param string $msid
     * @param string $id
     * @param string $status
     */
    public static function get_reportcard_subjects($msid = NULL,$sid = NULL,$cl = NULL)
        {
        try
            {
            $sql = "SELECT distinct DS.subject ,SS.subject_id,SS.name
 FROM   " . DB_PREFIX . "exam_acedemic_performance  EX inner join " . DB_PREFIX . "exam_datesheet DS on  EX.datesheet_id= DS.id and EX.MSID= DS.MSID INNER JOIN " . DB_PREFIX . "schoolwise_subjects SS ON DS.subject= SS.subject_id and DS.MSID= SS.MSID ";
            $sql .= " where EX.`MSID`=" . $msid;
             $sql .= " AND  EX.`student_id`=" . $sid;
             $sql .= " AND  EX.`class`=" . $cl;
//print_r($sql);
           $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
         public static function get_act_subject($msid = NULL,$sid = NULL,$cl = NULL,$subid = NULL)
        {
        try
            {
            $sql = "SELECT distinct `datesheet_id`,DS.subject ,SS.subject_id,SS.name,AC.name,AC.id
 FROM " . DB_PREFIX . "exam_acedemic_performance EX inner join " . DB_PREFIX . "exam_datesheet DS on  EX.datesheet_id= DS.id and EX.MSID= DS.MSID INNER JOIN " . DB_PREFIX . "schoolwise_subjects SS ON DS.subject= SS.subject_id and DS.MSID= SS.MSID   INNER JOIN " . DB_PREFIX . "activites AC ON DS.activity= AC.id and DS.MSID= AC.MSID   ";
            $sql .= " where EX.`MSID`=" . $msid;
              $sql .= " AND  EX.`student_id`=" . $sid;
              $sql .= " AND  EX.`class`=" . $cl;
                $sql .= " AND  DS.subject=" . $subid;
//              print_r($sql);
           $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
    
    public static function get_act_grades($msid = NULL,$act=NULL,$sub=NULL,$sid = NULL)
        {
        try
            {
           $sql = " SELECT   EX.`student_id`, EX. marks_obtained,DS.max_marks , (EX. marks_obtained/DS.max_marks*100)per ,DS.activity,EX.`datesheet_id` ,DS.subject,gr.grade  FROM " . DB_PREFIX . "exam_acedemic_performance  EX inner join " . DB_PREFIX . "exam_datesheet DS on  EX.datesheet_id= DS.id and EX.MSID= DS.MSID   inner join " . DB_PREFIX . "exam_grades gr on   DS.MSID= gr.MSID  And (EX. marks_obtained/DS.max_marks*100)  between `percent_from` and `percent_to`
 ";
            $sql .= " where EX.`MSID`=" . $msid;
            $sql .= " AND DS.activity=" . $act;
            $sql .= " AND DS.subject=" . $sub; 
            $sql .= " AND  EX.`student_id`=" . $sid;
//            print_r($sql);
             $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        
        
        
        public static function get_sub_grades($msid = NULL,$sub=NULL,$sid = NULL)
        {
        try
            {
           $sql = "SELECT   EX.`student_id`, SUM(EX. marks_obtained)/SUM(DS.max_marks)*100 as percentage   ,DS.activity,EX.`datesheet_id` ,DS.subject  FROM " . DB_PREFIX . "exam_acedemic_performance EX inner join " . DB_PREFIX . "exam_datesheet DS on  EX.datesheet_id= DS.id and EX.MSID= DS.MSID  ";
            $sql .= " where EX.`MSID`=" . $msid;
//            $sql .= " AND DS.activity=" . $act;
            $sql .= " AND DS.subject=" . $sub; 
            $sql .= " AND  EX.`student_id`=" . $sid;
            $sql .= " group by DS.subject ASC";
//            print_r($sql);
             $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages(); 
            $message->add('e', $e->getMessage());
            }
        }
         public static function get_subfinal_grades($msid = NULL,$per=NULL,$cl=NULL)
        {
        try
            {
           $sql = " SELECT * FROM `ms_exam_grades` WHERE `MSID`='$msid'  and '$per' between `percent_from` and `percent_to` And '$cl' between  `for_class` and  `class_to`";
             
//            print_r($sql);
             $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
            }
        catch (PDOException $e)
            {
            $message = new Messages();
            $message->add('e', $e->getMessage());
            }
        }
        
    }
?>
