<?php

class Fee {

    public function __construct() {
        
    }

    public static function get_monthly_fee($uid = NULL) {
        try {
            $sql = "SELECT `RSrNo` SrNo, MonthName(dueDate) Month ,Sum(`FeeAmt`)Amount FROM `ms_fee_billing` B INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='" . $uid . "')CU ON CU.`msid`=B.`msid` AND CU.`MySession`=B.`Session` AND B.`type` = 0 Group By RSrNo ";

            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_yearly_tpt_fee($uid = NULL) {
        try {
            $sql = "SELECT FeeGroup, Sum( `FeeAmt` ) Amount FROM `ms_fee_billing` B INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId = '" . $uid . "')CU ON CU.`msid` = B.`msid`
AND CU.`MySession` = B.`Session` AND B.`type` =0 WHERE FeeId = '0' GROUP BY FeeId";


            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_yearly_fee($uid = NULL) {
        try {
            $sql = "SELECT  FeeGroup, Sum(`FeeAmt`)Amount FROM `ms_fee_billing` B INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='" . $uid . "')CU ON CU.`msid`=B.`msid` AND CU.`MySession`=B.`Session` AND B.`type` = 0  where FeeId!='0' Group By FeeGroup";

            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_monthly_fee_detail($uid = NULL, $rsr_no = NULL) {
        try {
            $sql = "SELECT `fee_name` FeeName, Sum(`FeeAmt`)Amount FROM `ms_fee_billing` B INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='" . $uid . "')CU ON CU.`msid`=B.`msid` AND CU.`MySession`=B.`Session` AND B.`type` = 0 And RSrNo = '" . $rsr_no . "' INNER JOIN ms_fee_names FN ON FN.msid=CU.msid And FN.fee_id=B.FeeId Group By `FeeId` ";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_opening_bal($msid = Null, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {

            $sql = "SELECT `SID`,`FatherName`,`Class`, Sum(`FeeAmt`)Amt,COALESCE(Sum(TD.`Rate`),0)Rd,Sum(`FeeAmt`)-COALESCE(Sum(TD.`Rate`),0)Bal FROM `ms_fee_billing` B LEFT JOIN ms_fee_transactions T  ON T.msid=B.msid And T.`cost_center` = B.SID Left JOIN ms_fee_transaction_dtl TD ON TD.Tr_Id=T.Id AND TD.`item_id` = B.FeeId WHERE `FeeId`=-5681702 AND B.`MSID`=" . $msid . " And B.`FeeAmt`!=0  Group By SID  ";
            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
        }
    }

    public static function get_Std_fee_tpt($msid = NULL, $session = NULL, $acno = NULL, $srno = NULL, $groupby = "TRUE", $group_2 = "False", $tpt = Null) {
        try {
            if ($group_2 == "True") {
                $sql = "  SELECT MSID,id, type,AcNo, SID,FeeName, SrNo, RSrNo, DueDate, FeeId,sum(FeeAmt) as FeeAmt  FROM " . DB_PREFIX . "fee_billing Where 1 ";
            } else {
                if ($groupby == "FALSE") {
                    $sql = "  SELECT MSID,id,type, AcNo, SID,FeeName, SrNo, RSrNo, DueDate, FeeId,FeeAmt FROM " . DB_PREFIX . "fee_billing Where 1 ";
                } else {
                    $sql = "  SELECT MSID,id, AcNo,type, SID,FeeName, SrNo, RSrNo, DueDate, FeeId,FeeAmt, sum(FeeAmt) as fee FROM " . DB_PREFIX . "fee_billing Where 1 ";
                }
            }

            if (@$msid) {
                $sql .= " AND MSID = " . $msid;
            }
            if (@$session) {
                $sql .= " AND Session = " . $session;
            }
            if (@$acno) {
                $sql .= " AND AcNo = " . $acno;
            }
            if (@$srno) {
                $sql .= " AND RSrNo = " . $srno;
            }
            if ($tpt == "0") {
                $sql .= " AND  FeeId != 0 ";
            } else if ($tpt == "2") {
                $sql .= " AND  FeeId = 0 ";
            }
            if ($group_2 == "True") {
                $sql .= " group by FeeId ,AcNo ";
            } else {
                if ($groupby == "FALSE") {
                    
                } else {
                    $sql .= " group by RSrNo , AcNo";
                }
            }
//            $sql .= " ORDER by ID DESC";
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_defaulters($msid = Null, $type = NULL, $class = Null, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10), $sum = "False") {
        try {
//            print_r($data);
            $sql = "";
            if (@$sum == "True") {
                $sql .="select  Sum(MN3.bal) as balance From ( ";
            } $sql .= "Select FE.MSID,FE.MyDate,FE.DueAmt as Amt,COALESCE(TE.LFI,0) as LateFee,S.section,S.name as StudentName, S.`adm_classno`+(FE.MySession)-Year(S.`fees_date`)
CClass, FE.FatherName, FE.SID,FE.Class,FE.Village,FE.MobileSMS ,FE.AcNo,FE.DueAmt+COALESCE(TE.LFI,0)-COALESCE(TE.TEOD,0) TotalDue,COALESCE(TE.AmtPaid+TE.LFRd-TE.TEOD,0) RdAmt ,(FE.DueAmt+COALESCE(TE.LFI,0)-COALESCE(TE.TEOD,0)) - (COALESCE(TE.AmtPaid+TE.LFRd-TE.TEOD,0)) Bal From (Select CU.MyDate, CU.MySession, FF.MSID,FF.DueDate,FF.FatherName, FF.SID,FF.Class,FF.Village,FF.MobileSMS,FF.AcNo, Sum(FF.FeeAmt) DueAmt From (Select * From ms_slusers Where MyUId ='" . $msid . "') CU Inner Join ms_fee_billing FF On FF.MSID = CU.MSID And FF.Session =CU.MySession And RSrNo <= If(Month(CU.Begins)<=Month(CU.MyDate) ,Month(CU.MyDate) -Month(CU.Begins)+1,Month(CU.MyDate)-Month(CU.Begins)+13) Group By FF.AcNo)FE left join ms_students S on S.msid=FE.msid AND S.student_id=FE.SID Left Join (Select cost_center,Sum(Amt)AmtPaid,Sum(`cal_late_fee`) LFI,Sum(`late_fee`) LFRd,Sum(`EOD`) TEOD From Vu_39Transactions T Inner Join (Select * From ms_slusers Where MyUId ='" . $msid . "') CU ON T.MSID=CU.MSID And T.Session=CU.MySession And T.TrDate <= CU.MyDate Group By T.cost_center) TE On TE.cost_center=FE.AcNo  ";
            if ($class != "all") {
                $sql.=" Where Class = '" . $class . "'";
            }
            if ($type != "all") {
                if ($type == "defaulters") {
                    $sql.=" Having Bal > 0 order by CClass,S.section ,FE.AcNo";
                } elseif ($type == "advancepayer") {
                    $sql.=" Having Bal < 0 order by CClass,S.section ,FE.AcNo";
                } elseif ($type == "perfact_payer") {
                    $sql.=" Having Bal = 0 order by CClass,S.section ,FE.AcNo";
                }
            } else {
                $sql.=" Having Bal > 0 order by CClass,S.section ,FE.AcNo";
            }


            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            if (@$sum == "True") {
                $sql .=" ) as MN3  ";
            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_delete_student_from_fee_billing($msid = Null, $acno = Null, $session = NULL, $student_id = NULL) {
        try {

            $oDb = DBConnection::get();
            $sql = "Delete From `ms_fee_billing` where `MSID`='$msid' And `FeeId`>='0' ";
            if (@$student_id) {
                $sql .= "And `SID` ='$student_id'";
            } else if (@$acno) {
                $sql .= "And `AcNo` ='$acno'";
            }
            $sql .=" and Session= '" . $session . "'";
            $upsql = $oDb->prepare($sql);
//            exit();
            $upsql->execute();

//            print_r($upsql);
//            exit();
//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
        }
    }

//    Delete From `ms_fee_billing` where `MSID`='10046' And `FeeId`>='0' And `AcNo` ='1856' and Session= '2016'
    public static function get_ledger_dtl($msid = Null, $acno = Null, $session = NULL, $student_id = NULL) {
        try {

            $oDb = DBConnection::get();
            $sql = "Delete From `ms_fee_billing` where `MSID`='$msid' And `FeeId`>='0' ";
            if (@$student_id) {
                $sql .= "And `SID` ='$student_id'";
            } else if (@$acno) {
                $sql .= "And `AcNo` ='$acno'";
            }
            $sql .=" and Session= '" . $session . "'";
            $upsql = $oDb->prepare($sql);
//            print_r($upsql);
//            exit();
//            exit();
            $upsql->execute();

//            $sql = $oDb->query($sql);
            return $upsql;
        } catch (PDOException $e) {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
        }
    }

    public static function insert_student_into_fee_billing($myuid = Null, $acno = Null, $sid = NULL, $symbole = "<") {
        try {
            $sql = "
INSERT INTO `ms_fee_billing` (`MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`, `FeeAmt` ,`FeeGroup`,`Session`,`Class`, `FatherName`, `Village`, `MobileSMS`, `FeeName`, `House`) Select CSD.MSID MSID,CSD.AcNo AcNo,CSD.SID SID,CSD.SrNo SrNo,FS.r_sr_no RSrNo,MIN(CSD.DueDate) DueDate,CSD.FeeId FeeId,round(Sum(If(FEE.fee_id=0,COALESCE(TR.fee,0),

FEE.fee_rate))*(1-COALESCE (DR.percent,0))-(COALESCE(DR.fixed_amount,0))) FeeAmt,CSD.FeeGroup,CSD.mysession,CC.class_name ClassName,CSD.FatherName FatherName,CSD.name Village,CSD.MobileSMS,CSD.FeeName FeeName,HH.house_f_name House
From (
Select Q1.*,If(Month(Q1.DueDate)-Month(Q1.begins)+1 >0,Month(Q1.DueDate)-Month(Q1.begins)+1,Month(Q1.DueDate)-Month (Q1.begins)+13) SrNo

,Q1.AdmClassNo+Year(Q1.begins)-Year(Q1.FSDate)+COALESCE(Sum(E.Result),0)

CClass,SFG.feegroupid FGroupId,SAT.tpt_stn_id TptStation,DS.discount_id discount,P.f_name FatherName,P.mobile_sms MobileSMS,P.feepaymentmode FeePaymentMode,L.name
FROM (
Select S.student_id SID,S.parent_id PID,S.acno Acno,S.Name StudentName,S.Adm_classno AdmClassNo,S.fees_date FSDate,S.sl_date SLDate,S.group_id GroupId,S.opening_bal OpeningBal,DD.date_id DueDate,FN.fee_id

FeeId,FN.fee_name FeeName,FN.fee_group_name FeeGroup,COY.Name SchoolName,COY.SeprateTPTFBook,CU.MSID,CU.mydate,CU.mysession,CU.begins,CU.ends,CU.myuid,S.House From (SELECT *

FROM `ms_slusers` WHERE Myuid = '" . $myuid . "vm3' ) CU    Inner Join ms_schools COY On COY.MSID = CU.MSID Inner Join ms_dates DD On DD.date_id Between

CU.begins And CU.ends And Day(date_id) = '1' Inner Join ms_students S On S.MSID =CU.MSID And DD.date_id Between S.fees_date And S.sl_date Inner

Join ms_fee_names FN On FN.MSID=CU.MSID


) Q1
     
Left Join
ms_exams E On E.MSID = Q1.MSID AND E.s_id=Q1.SID And E.date_result<Q1.DueDate
Inner Join
ms_fee_slsubgrp SFG On SFG.MSID=Q1.MSID AND SFG.subgroupid=Q1.GroupId
Left Join
ms_tpt_std SAT ON SAT.MSID=Q1.MSID And Q1.DueDate Between SAT.date_from And SAT.date_to And SAT.S_Id=Q1.SID
Left Join
ms_discounted_student DS ON DS.MSID=Q1.MSID And DS.S_Id=Q1.SID And Q1.DueDate Between DS.date_from And DS.date_to
Inner Join
ms_parents P On P.id=Q1.PID
Inner Join
ms_locality L On L.MSID=Q1.MSID And L.id=P.village
Where 1 ";
            if (@$sid) {
                $sql .= " And Q1.SID= " . $sid . "  ";
            } else if (@$acno) {
                $sql .= " And Q1.acno= " . $acno . "  ";
            }
            $sql .= " 
Group By Q1.SID, Q1.DueDate,Q1.FeeId

) CSD
inner join ms_classes CC on CC.msid=CSD.msid and CC.class_no=CSD.CClass Left join ms_houses HH on HH.MSID=CSD.MSID and HH.house_id=CSD.house
 
Inner Join
ms_fee_schedule FS On FS.MSID=CSD.MSID And FS.pay_mode=CSD.FeePaymentMode  And CSD.SrNo Between FS.sr_no_from And FS.sr_no_to And CSD.DueDate Between FS.Date_From And FS.date_to
Inner Join
ms_fee FEE On FEE.MSID=CSD.MSID And CSD.DueDate Between FEE.date_from And FEE.date_to And FEE.fee_id=CSD.FeeId And CSD.CClass Between

FEE.class_from And

FEE.class_to And
(CSD.FGroupId=FEE.group_id Or FEE.group_id = '0') And If(FEE.ff='1' And CSD.DueDate=CSD.FSDate,CSD.SrNo Between FEE.ff_from And

FEE.ff_to,CSD.SrNo Between

FEE.sr_no_from And FEE.sr_no_to)
Left Join
ms_tpt_fee TR On TR.MSID=CSD.MSID And CSD.DueDate Between TR.date_from And TR.date_to And CSD.TptStation=TR.station_id
Left Join
ms_discount_rule DR On DR.MSID=CSD.MSID And CSD.DueDate Between DR.date_from And DR.date_to And DR.discount_id=CSD.Discount And

DR.fee_id=FEE.fee_id And CSD.CClass

Between DR.class_from And DR.class_to And CSD.SrNo Between DR.sr_no_from And DR.sr_no_to
Group By AcNo,RSrNo,SID,FeeId

";
//            if (@$symbole == "4") {
//                $sql .= " And CSD.CClass < 5";
//            } else if (@$symbole == "8") {
//                $sql .= " And CSD.CClass Between 4 And 9";
//            } else if (@$symbole == "10") {
//                $sql .= " And CSD.CClass Between 8 And 11";
//            } else if (@$symbole == "12") {
//                $sql .= " And CSD.CClass  > 10";
//            }
//            $sql .=" Group By AcNo,SrNo,SID,FeeId
//";
//            $sql ="Select CSD.MSID MSID,CSD.AcNo AcNo,CSD.SID SID,CSD.SrNo SrNo,FS.r_sr_no RSrNo,CSD.DueDate DueDate,CSD.FeeId FeeId,round(Sum(If(FEE.fee_id=0,COALESCE(TR.fee,0),
//
//FEE.fee_rate))*(1-COALESCE (DR.percent,0))-(COALESCE(DR.fixed_amount,0))) FeeAmt,CSD.mysession,CC.class_name ClassName,CSD.FatherName FatherName,CSD.name Village,CSD.MobileSMS,CSD.FeeName FeeName,HH.house_f_name House
//From (
//Select Q1.*,If(Month(Q1.DueDate)-Month(Q1.begins)+1 >0,Month(Q1.DueDate)-Month(Q1.begins)+1,Month(Q1.DueDate)-Month (Q1.begins)+13) SrNo
//
//,Q1.AdmClassNo+Year(Q1.begins)-Year(Q1.FSDate)+COALESCE(Sum(E.Result),0)
//
//CClass,SFG.feegroupid FGroupId,SAT.tpt_stn_id TptStation,DS.discount_id discount,P.f_name FatherName,P.mobile_sms MobileSMS,P.feepaymentmode FeePaymentMode,L.name
//FROM (
//Select S.student_id SID,S.parent_id PID,S.acno Acno,S.Name StudentName,S.Adm_classno AdmClassNo,S.fees_date FSDate,S.sl_date SLDate,S.group_id GroupId,S.opening_bal OpeningBal,DD.date_id DueDate,FN.fee_id
//
//FeeId,FN.fee_name FeeName,FN.fee_group_name FeeGroup,COY.Name SchoolName,COY.SeprateTPTFBook,CU.MSID,CU.mydate,CU.mysession,CU.begins,CU.ends,CU.myuid,S.House From (SELECT *
//
//FROM `ms_slusers` WHERE Myuid = '1001vm1' ) CU    Inner Join ms_schools COY On COY.MSID = CU.MSID Inner Join ms_dates DD On DD.date_id Between
//
//CU.begins And CU.ends And Day(date_id) = '1' Inner Join ms_students S On S.MSID =CU.MSID And DD.date_id Between S.fees_date And S.sl_date Inner
//
//Join ms_fee_names FN On FN.MSID=CU.MSID
//
//
//) Q1
//     
//Left Join
//ms_exams E On E.MSID = Q1.MSID AND E.s_id=Q1.SID And E.date_result<Q1.DueDate
//Inner Join
//ms_fee_slsubgrp SFG On SFG.MSID=Q1.MSID AND SFG.subgroupid=Q1.GroupId
//Left Join
//ms_tpt_std SAT ON SAT.MSID=Q1.MSID And Q1.DueDate Between SAT.date_from And SAT.date_to And SAT.S_Id=Q1.SID
//Left Join
//ms_discounted_student DS ON DS.MSID=Q1.MSID And DS.S_Id=Q1.SID And Q1.DueDate Between DS.date_from And DS.date_to
//Inner Join
//ms_parents P On P.id=Q1.PID
//Inner Join
//ms_locality L On L.MSID=Q1.MSID And L.id=P.village
//Where sid='13056'
//Group By Q1.SID, Q1.DueDate,Q1.FeeId
//
//) CSD
//inner join ms_classes CC on CC.msid=CSD.msid and CC.class_no=CSD.CClass inner join ms_houses HH on HH.MSID=CSD.MSID and HH.house_id=CSD.house
// 
//Inner Join
//ms_fee_schedule FS On FS.MSID=CSD.MSID And FS.pay_mode=CSD.FeePaymentMode  And CSD.SrNo Between FS.sr_no_from And FS.sr_no_to And CSD.DueDate Between FS.Date_From And FS.date_to
//Inner Join
//ms_fee FEE On FEE.MSID=CSD.MSID And CSD.DueDate Between FEE.date_from And FEE.date_to And FEE.fee_id=CSD.FeeId And CSD.CClass Between
//
//FEE.class_from And
//
//FEE.class_to And
//(CSD.FGroupId=FEE.group_id Or FEE.group_id = '0') And If(FEE.ff='1' And CSD.DueDate=CSD.FSDate,CSD.SrNo Between FEE.ff_from And
//
//FEE.ff_to,CSD.SrNo Between
//
//FEE.sr_no_from And FEE.sr_no_to)
//Left Join
//ms_tpt_fee TR On TR.MSID=CSD.MSID And CSD.DueDate Between TR.date_from And TR.date_to And CSD.TptStation=TR.station_id
//Left Join
//ms_discount_rule DR On DR.MSID=CSD.MSID And CSD.DueDate Between DR.date_from And DR.date_to And DR.discount_id=CSD.Discount And
//
//DR.fee_id=FEE.fee_id And CSD.CClass
//
//Between DR.class_from And DR.class_to And CSD.SrNo Between DR.sr_no_from And DR.sr_no_to
//Group By AcNo,SrNo,SID,FeeId"
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
        }
    }

    public static function insert_student_into_fee_billing2($myuid = Null, $acno = Null, $sid = NULL, $symbole = "<") {
        try {
            $sql = "
INSERT INTO `ms_fee_billing` (`MSID`, `AcNo`, `SID`, `SrNo`, `RSrNo`, `DueDate`, `FeeId`, `FeeAmt` ,`FeeGroup`,`Session`,`Class`, `FatherName`, `Village`, `MobileSMS`, `FeeName`, `House`) Select CSD.MSID MSID,CSD.AcNo AcNo,CSD.SID SID,CSD.SrNo SrNo,FS.r_sr_no RSrNo,CSD.DueDate DueDate,CSD.FeeId FeeId,round(Sum(If(FEE.fee_id=0,COALESCE(TR.fee,0),

FEE.fee_rate))*(1-COALESCE (DR.percent,0))-(COALESCE(DR.fixed_amount,0))) FeeAmt,CSD.FeeGroup,CSD.mysession,CC.class_name ClassName,CSD.FatherName FatherName,CSD.name Village,CSD.MobileSMS,CSD.FeeName FeeName,HH.house_f_name House
From (
Select Q1.*,If(Month(Q1.DueDate)-Month(Q1.begins)+1 >0,Month(Q1.DueDate)-Month(Q1.begins)+1,Month(Q1.DueDate)-Month (Q1.begins)+13) SrNo

,Q1.AdmClassNo+Year(Q1.begins)-Year(Q1.FSDate)+COALESCE(Sum(E.Result),0)

CClass,SFG.feegroupid FGroupId,SAT.tpt_stn_id TptStation,DS.discount_id discount,P.f_name FatherName,P.mobile_sms MobileSMS,P.feepaymentmode FeePaymentMode,L.name
FROM (
Select S.student_id SID,S.parent_id PID,S.acno Acno,S.Name StudentName,S.Adm_classno AdmClassNo,S.fees_date FSDate,S.sl_date SLDate,S.group_id GroupId,S.opening_bal OpeningBal,DD.date_id DueDate,FN.fee_id

FeeId,FN.fee_name FeeName,FN.fee_group_name FeeGroup,COY.Name SchoolName,COY.SeprateTPTFBook,CU.MSID,CU.mydate,CU.mysession,CU.begins,CU.ends,CU.myuid,S.House From (SELECT *

FROM `ms_slusers` WHERE Myuid = '" . $myuid . "' ) CU    Inner Join ms_schools COY On COY.MSID = CU.MSID Inner Join ms_dates DD On DD.date_id Between

CU.begins And CU.ends And Day(date_id) = '1' Inner Join ms_students S On S.MSID =CU.MSID And DD.date_id Between S.fees_date And S.sl_date Inner

Join ms_fee_names FN On FN.MSID=CU.MSID


) Q1
     
Left Join
ms_exams E On E.MSID = Q1.MSID AND E.s_id=Q1.SID And E.date_result<Q1.DueDate
Inner Join
ms_fee_slsubgrp SFG On SFG.MSID=Q1.MSID AND SFG.subgroupid=Q1.GroupId
Left Join
ms_tpt_std SAT ON SAT.MSID=Q1.MSID And Q1.DueDate Between SAT.date_from And SAT.date_to And SAT.S_Id=Q1.SID
Left Join
ms_discounted_student DS ON DS.MSID=Q1.MSID And DS.S_Id=Q1.SID And Q1.DueDate Between DS.date_from And DS.date_to
Inner Join
ms_parents P On P.id=Q1.PID
Inner Join
ms_locality L On L.MSID=Q1.MSID And L.id=P.village
Where 1 ";
            if (@$sid) {
                $sql .= " And Q1.SID= " . $sid . "  ";
            } else if (@$acno) {
                $sql .= " And Q1.acno= " . $acno . "  ";
            }
            $sql .= " 
Group By Q1.SID, Q1.DueDate,Q1.FeeId

) CSD
inner join ms_classes CC on CC.msid=CSD.msid and CC.class_no=CSD.CClass Left join ms_houses HH on HH.MSID=CSD.MSID and HH.house_id=CSD.house
 
Inner Join
ms_fee_schedule FS On FS.MSID=CSD.MSID And FS.pay_mode=CSD.FeePaymentMode  And CSD.SrNo Between FS.sr_no_from And FS.sr_no_to And CSD.DueDate Between FS.Date_From And FS.date_to
Inner Join
ms_fee FEE On FEE.MSID=CSD.MSID And CSD.DueDate Between FEE.date_from And FEE.date_to And FEE.fee_id=CSD.FeeId And CSD.CClass Between

FEE.class_from And

FEE.class_to And
(CSD.FGroupId=FEE.group_id Or FEE.group_id = '0') And If(FEE.ff='1' And CSD.DueDate=CSD.FSDate,CSD.SrNo Between FEE.ff_from And

FEE.ff_to,CSD.SrNo Between

FEE.sr_no_from And FEE.sr_no_to)
Left Join
ms_tpt_fee TR On TR.MSID=CSD.MSID And CSD.DueDate Between TR.date_from And TR.date_to And CSD.TptStation=TR.station_id
Left Join
ms_discount_rule DR On DR.MSID=CSD.MSID And CSD.DueDate Between DR.date_from And DR.date_to And DR.discount_id=CSD.Discount And

DR.fee_id=FEE.fee_id And CSD.CClass

Between DR.class_from And DR.class_to And CSD.SrNo Between DR.sr_no_from And DR.sr_no_to
Group By AcNo,SrNo,SID,FeeId

";
//            if (@$symbole == "4") {
//                $sql .= " And CSD.CClass < 5";
//            } else if (@$symbole == "8") {
//                $sql .= " And CSD.CClass Between 4 And 9";
//            } else if (@$symbole == "10") {
//                $sql .= " And CSD.CClass Between 8 And 11";
//            } else if (@$symbole == "12") {
//                $sql .= " And CSD.CClass  > 10";
//            }
//            $sql .=" Group By AcNo,SrNo,SID,FeeId
//";
//            $sql ="Select CSD.MSID MSID,CSD.AcNo AcNo,CSD.SID SID,CSD.SrNo SrNo,FS.r_sr_no RSrNo,CSD.DueDate DueDate,CSD.FeeId FeeId,round(Sum(If(FEE.fee_id=0,COALESCE(TR.fee,0),
//
//FEE.fee_rate))*(1-COALESCE (DR.percent,0))-(COALESCE(DR.fixed_amount,0))) FeeAmt,CSD.mysession,CC.class_name ClassName,CSD.FatherName FatherName,CSD.name Village,CSD.MobileSMS,CSD.FeeName FeeName,HH.house_f_name House
//From (
//Select Q1.*,If(Month(Q1.DueDate)-Month(Q1.begins)+1 >0,Month(Q1.DueDate)-Month(Q1.begins)+1,Month(Q1.DueDate)-Month (Q1.begins)+13) SrNo
//
//,Q1.AdmClassNo+Year(Q1.begins)-Year(Q1.FSDate)+COALESCE(Sum(E.Result),0)
//
//CClass,SFG.feegroupid FGroupId,SAT.tpt_stn_id TptStation,DS.discount_id discount,P.f_name FatherName,P.mobile_sms MobileSMS,P.feepaymentmode FeePaymentMode,L.name
//FROM (
//Select S.student_id SID,S.parent_id PID,S.acno Acno,S.Name StudentName,S.Adm_classno AdmClassNo,S.fees_date FSDate,S.sl_date SLDate,S.group_id GroupId,S.opening_bal OpeningBal,DD.date_id DueDate,FN.fee_id
//
//FeeId,FN.fee_name FeeName,FN.fee_group_name FeeGroup,COY.Name SchoolName,COY.SeprateTPTFBook,CU.MSID,CU.mydate,CU.mysession,CU.begins,CU.ends,CU.myuid,S.House From (SELECT *
//
//FROM `ms_slusers` WHERE Myuid = '1001vm1' ) CU    Inner Join ms_schools COY On COY.MSID = CU.MSID Inner Join ms_dates DD On DD.date_id Between
//
//CU.begins And CU.ends And Day(date_id) = '1' Inner Join ms_students S On S.MSID =CU.MSID And DD.date_id Between S.fees_date And S.sl_date Inner
//
//Join ms_fee_names FN On FN.MSID=CU.MSID
//
//
//) Q1
//     
//Left Join
//ms_exams E On E.MSID = Q1.MSID AND E.s_id=Q1.SID And E.date_result<Q1.DueDate
//Inner Join
//ms_fee_slsubgrp SFG On SFG.MSID=Q1.MSID AND SFG.subgroupid=Q1.GroupId
//Left Join
//ms_tpt_std SAT ON SAT.MSID=Q1.MSID And Q1.DueDate Between SAT.date_from And SAT.date_to And SAT.S_Id=Q1.SID
//Left Join
//ms_discounted_student DS ON DS.MSID=Q1.MSID And DS.S_Id=Q1.SID And Q1.DueDate Between DS.date_from And DS.date_to
//Inner Join
//ms_parents P On P.id=Q1.PID
//Inner Join
//ms_locality L On L.MSID=Q1.MSID And L.id=P.village
//Where sid='13056'
//Group By Q1.SID, Q1.DueDate,Q1.FeeId
//
//) CSD
//inner join ms_classes CC on CC.msid=CSD.msid and CC.class_no=CSD.CClass inner join ms_houses HH on HH.MSID=CSD.MSID and HH.house_id=CSD.house
// 
//Inner Join
//ms_fee_schedule FS On FS.MSID=CSD.MSID And FS.pay_mode=CSD.FeePaymentMode  And CSD.SrNo Between FS.sr_no_from And FS.sr_no_to And CSD.DueDate Between FS.Date_From And FS.date_to
//Inner Join
//ms_fee FEE On FEE.MSID=CSD.MSID And CSD.DueDate Between FEE.date_from And FEE.date_to And FEE.fee_id=CSD.FeeId And CSD.CClass Between
//
//FEE.class_from And
//
//FEE.class_to And
//(CSD.FGroupId=FEE.group_id Or FEE.group_id = '0') And If(FEE.ff='1' And CSD.DueDate=CSD.FSDate,CSD.SrNo Between FEE.ff_from And
//
//FEE.ff_to,CSD.SrNo Between
//
//FEE.sr_no_from And FEE.sr_no_to)
//Left Join
//ms_tpt_fee TR On TR.MSID=CSD.MSID And CSD.DueDate Between TR.date_from And TR.date_to And CSD.TptStation=TR.station_id
//Left Join
//ms_discount_rule DR On DR.MSID=CSD.MSID And CSD.DueDate Between DR.date_from And DR.date_to And DR.discount_id=CSD.Discount And
//
//DR.fee_id=FEE.fee_id And CSD.CClass
//
//Between DR.class_from And DR.class_to And CSD.SrNo Between DR.sr_no_from And DR.sr_no_to
//Group By AcNo,SrNo,SID,FeeId"
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_book_querry1($uid = Null, $acno = Null, $RSrNo = NULL, $student_id = NULL, $group_name = '', $tpt = "1") {
        try {
//            print_r($group_name);
            $sql = " SELECT FF.MSID, FF.SrNo, FF.RSrNo,FF.SID,FF.AcNo, monthName(FF.DueDate) as Month,year(FF.DueDate) as Year,
                FF.Class,FF.House,sum( FF.FeeAmt ) AS FeeAmt ,FF.FeeGroup,S.name  FROM ms_fee_billing FF inner join (Select * From ms_slusers Where MyUId='" . $uid . "') CU on CU.MSID=FF.MSID and FF.DueDate between CU.Begins And CU.Ends  inner join ms_students S on S.MSID=CU.MSID and S.student_id=FF.SID where FF.AcNo='" . $acno . "'  ";
            if ($tpt == "0") {
                $sql .= " AND  FF.FeeId != 0 ";
            } else if ($tpt == "2") {
                $sql .= " AND  FF.FeeId = 0 ";
            }
            if (@$RSrNo) {
                $sql .=" AND FF.RSrNo='" . $RSrNo . "' ";
            }
//            if (@$fee_id || @$fee_id == "0") {
//                $sql .=" AND FF.FeeId='" . $fee_id . "' ";
//            }
            if (@$student_id) {
                $sql .=" AND FF.SID='" . $student_id . "' ";
            }
            if (@$group_name) {
                $sql .=" AND FF.FeeGroup='" . $group_name . "' ";
            }
            $sql .=" GROUP BY FF.SID Order By SID,FeeGroup ";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_distinct_students($uid = Null, $acno = Null, $RSrNo = NULL) {
        try {
//            print_r($group_name);
            $sql = " SELECT distinct FF.SID  FROM ms_fee_billing FF inner join (Select * From ms_slusers Where MyUId='" . $uid . "') CU on CU.MSID=FF.MSID and FF.DueDate between CU.Begins And CU.Ends  inner join ms_students S on S.MSID=CU.MSID and S.student_id=FF.SID where FF.AcNo='" . $acno . "'  ";

            if (@$RSrNo) {
                $sql .=" AND FF.RSrNo='" . $RSrNo . "' ";
            }

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_book_querry2_subtotal($uid = Null, $acno = Null, $RSrNo = NULL, $student_id = NULL, $tpt = "1") {
        try {
//            print_r($tpt);

            $sql = "    SELECT FF.MSID, FF.SrNo, FF.RSrNo,FF.SID,FF.AcNo, monthName(FF.DueDate) as Month,year(FF.DueDate) as Year
                ,FF.Class,FF.House,sum(FF.FeeAmt) as Sub_Total,FF.FeeId,FF.FeeGroup,S.name  FROM ms_fee_billing FF inner join (Select * From ms_slusers U Where MyUId= '" . $uid . "' ) CU on CU.MSID=FF.MSID and FF.DueDate between CU.Begins And CU.Ends  inner join ms_students S on S.MSID=CU.MSID and S.student_id=FF.SID  where FF.AcNo='" . $acno . "' ";
            if ($tpt == "0") {
                $sql .= " AND  FF.FeeId != 0 ";
            } else if ($tpt == "2") {
                $sql .= " AND  FF.FeeId = 0 ";
            }

            if (@$RSrNo) {
                $sql .=" AND FF.RSrNo='" . $RSrNo . "' ";
            } if (@$student_id) {
                $sql .=" AND FF.SID='" . $student_id . "' ";
            }

            $sql .= "group by SID Order By DueDate
                 ";
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_summary($msid = Null, $muid = NULL) {
        try {
            $sql = "SELECT B.`FeeId`,B.`FeeName`,SUM(B.`FeeAmt`) total FROM `ms_fee_billing` B INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='" . $muid . "') CU ON CU.`msid` =B.`msid` AND B.`Session` = CU.`MySession` AND B.`RsrNo` <= If(Month(CU.MyDate)-Month(CU.begins)+1 >0,Month(CU.MyDate)-Month(CU.begins)+1,Month(CU.MyDate)-Month (CU.begins)+13)GROUP BY B.`FeeId`";


//
//SELECT MN1.FeeName,MN1.FeeId,Sum(MN1.NetAmt) as FeeAmt,MN1.MyDate From (
//SELECT MN.MyDate, MN.FeeName, MN.DueDate, MN.AcNo, MN.SId, MN.Class, MN.House, MN.FatherName, 
//MN.Village, ROUND(SUM(MN.FeeAmt),0) NetAmt,MN.FeeId
//FROM (select FF.*,U.MyDate from ms_fee_billing FF inner join ms_slusers U on U.MSID=FF.MSID and U.myuid='" . $msid . "e1' and FF.DueDate between U.begins and U.ends) MN Where 1 GROUP BY AcNo,RSrNo,FeeId Having Netamt>0 )MN1 Where MN1.DueDate<=MN1.MyDate Group By MN1.FeeName
//";

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_credit_deatils($uid = NULL) {
        try {
            $sql = " Select dr,Coalesce(L.name,'Total') name,Round(Sum(Amt)) FeeAmtRd,Sum(late_fee) LateFeeRd,Round(Sum(amt)+Sum(late_fee)) Total From Vu_39Transactions T Inner Join (Select * From ms_slusers Where myuid='" . $uid . "') CU On CU.MSID=T.MSID And CU.mysession=T.Session And T.TrDate<= CU.mydate Inner Join ms_fee_ledgers L On L.MSID=CU.MSID And L.ledgers_id=T.Dr Where T.v_id='2' Group By name ";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_opening_balance($msid = Null) {
        try {
            $sql = " SELECT  sum(`opening_bal`) as total FROM `ms_students` where MSID='" . $msid . "'";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_late_fee_for_headwise($msid = Null, $date = Null) {
        try {
            $sql = "   SELECT sum(late_fee) `late_fees` FROM `ms_fee_transactions` WHERE `tr_date` ='" . $date . "' And `v_id`='2' AND `MSID`='" . $msid . "'";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_onaccount_for_headwise($msid = Null, $date = Null) {
        try {
            $sql = "  SELECT Sum(D.qty*D.rate ) onrate FROM `ms_fee_transactions` T INNER JOIN `ms_fee_transaction_dtl` D ON T.tr_id_no = D.tr_id WHERE T.tr_date = '" . $date . "' AND T.MSID = '" . $msid . "'";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_max_tr_date($uid = Null, $acno = Null) {
        try {
            $sql = " SELECT `id`, Max(tr_date) tdate FROM (SELECT * FROM ms_slusers WHERE myuid = '" . $uid . "') CU INNER JOIN ms_fee_transactions T ON T.msid=CU.msid AND T.Tr_Date <= CU.`mydate`  AND T.`type` = 'Adjustment' And T.cost_center='" . $acno . "' ";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_daily_fee($uid = Null) {
        try {
            $sql = "SELECT `item_id`,FN.`fee_name`,SUM(`rate`) as amt FROM (SELECT CU.*,T.`time_stamp`,T.`id` FROM (SELECT * FROM ms_slusers WHERE myuid = '" . $uid . "') CU INNER JOIN ms_fee_transactions T ON T.msid=CU.msid AND T.Tr_Date Between CU.`my_period_from` AND CU.`my_period_to`) Q1 INNER JOIN ms_fee_transaction_dtl TD ON TD.`tr_id`=Q1.`id` LEFT JOIN ms_fee_names FN ON Q1.`MSID` = FN.`MSID` AND TD.`item_id` = FN.`fee_id` GROUP BY TD.`item_id`";
//            $sql = "   Select count(T.id) NORt ,T.`TrDate`,T.`tr_id_no`,T.`username`,T.`cost_center` AcNo,Sum(T.`Amt`) FeeAmt,Sum(T.`late_fee`) Late_Fee,Sum(T.`EOD`) EOD,Sum(T.`Amt`+T.`late_fee`+T.`EOD`) TotalAmt From Vu_39Transactions T INNER JOIN (SELECT * FROM ms_slusers_new WHERE MyUId = '" . $uid . "') CU ON T.msid=CU.msid and T.Session=CU.MySession And T.TrDate BETWEEN CU.my_Period_from And CU.my_Period_to Group By T.`cost_center";
//                    . ""
//                    . " Select MN1.FeeId, MN1.FeeName,Sum(MN1.FeeAmt) as amt From (Select MN.MSID, MN.FeeName,MN.AcNo,MN.DueDate,MN.RSrNo,MN.FeeId,Sum(MN.FeeAmt) FeeAmt FROM (select FF.* from ms_fee_billing FF where FF.MSID='" . $msid . "') MN Group By MN.AcNo,MN.RSrNo,FeeId)MN1
//Where Concat(MN1.MSID,'-',MN1.AcNo,'-',MN1.DueDate) In (Select fee_receipt_id From ms_fee_transactions T where  T.tr_date ='" . $date . "')
//Group By FeeId";
//Select distinct D.*, round(Sum(D.qty*D.rate)) RD ,T.* from ms_fee_transactions T Inner Join ms_fee_transaction_dtl D ON D.tr_id=T.tr_id_no WHERE T.tr_date ='" . $date . "' And T.MSID='" . $msid . "' group by item_id 
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_due_amt($myuid = Null, $mydate = Null, $acno = NULL, $begin = NULL, $end = NULL, $tpt = "FALSE", $all_fee_structure = "FALSE") {
        try {
            if ($all_fee_structure == "FALSE") {
                $sql = "    SELECT Sum(FF.FeeAmt) as DueAmt  ";
            } else {
                $sql = " SELECT Sum(FF.FeeAmt)  as fee , MonthName(DueDate) as month_name ,DueDate ,RSrNo,SrNo   ";
            }
            $sql .= " From ms_fee_billing FF Inner Join (SELECT *,If(Month(MyDate)>=Month(Begins),Month(MyDate)-Month(Begins)+1,"
                    . "Month(MyDate)-Month(Begins)+13) As a FROM`ms_slusers` WHERE MyUid='" . $myuid . "') CU On FF.MSID=CU.MSID And FF.Session=CU.MySession ";
            if ($all_fee_structure == "FALSE") {
                $sql .="    And FF.RSrNo <= CU.a  ";
            }
            $sql .="And FF.ACNo='" . $acno . "'";
            if ($all_fee_structure == "FALSE") {
                $sql .="    And FF.RSrNo <= CU.a  ";
                if ($tpt == "True") {
                    $sql .="   GROUP BY  FF.ACNo";
                } else {
                    $sql .=" And  `FF.FeeId`!='0'    GROUP BY  FF.ACNo";
                }
            } else {
                $sql .="   GROUP BY  FF.RSrNo ";
            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_due_date($msid = Null, $student_id = Null, $RSrNo = NULL, $begin = NULL, $end = NULL) {
        try {
            $sql = " SELECT distinct DATE_ADD(`DueDate`,INTERVAL -'-9' Day) as paydate FROM `ms_fee_billing` WHERE SID='" . $student_id . "' and  DueDate between '" . $begin . "' And '" . $end . "' And MSID='" . $msid . "' And SrNo='" . $RSrNo . "'";

//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_book_querry3_total($msid = Null, $acno = Null, $RSrNo = NULL, $tpt = "1") {
        try {
            $sql = "SELECT FF.MSID, FF.SrNo, FF.RSrNo,FF.AcNo, monthName(FF.DueDate) as Month,year(FF.DueDate) as Year,
                sum(FF.FeeAmt) as Total FROM ms_fee_billing FF inner join ms_slusers U on 
                U.MSID=FF.MSID and FF.DueDate between U.Begins And U.Ends  and U.myuid='" . $msid . "e1' inner join ms_students 
                S on S.MSID=U.MSID and S.student_id=FF.SID where FF.AcNo='" . $acno . "'";
            if ($tpt == "0") {
                $sql .= " AND  FF.FeeId != 0 ";
            } else if ($tpt == "2") {
                $sql .= " AND  FF.FeeId = 0 ";
            } if (@$RSrNo) {
                $sql .=" AND FF.RSrNo='" . $RSrNo . "' ";
            }
            $sql .=" group by FF.AcNo,FF.RSrNo Order By DueDate
                              ";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_report($msid = Null, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "select T.MSID,T.tr_id_no,X.AcNo,X.FatherName,X.Village,L.name as Received_by,ROUND(T.Amt,2) as FeeAmt,
                    T.late_fee,ROUND((T.Amt+T.late_fee),2) as Total from (SELECT * from ms_slusers where MyUid='" . $msid . "e1') U inner 
                   join Vu_39Transactions T on T.MSID=U.MSID and T.TrDate=U.MyDate left join ms_fee_ledgers L on L.MSID=T.MSID and 
                    T.dr=L.id left join (SELECT DISTINCT(Acno),MSID,FatherName,Village FROM `ms_fee_billing`) X on X.MSID=T.MSID 
                    and X.AcNo=T.cost_center";

//            print_r($sql);
//            exit();

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function update_fee_paid_b($TrDate = NULL, $DR = NULL, $AcNo = NULL, $foo = NULL, $TridNo = NULL, $amt = NULL, $fee_dtl = NULL, $fee_ids = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {

//            print_r($fee_dtl) ;
//            exit();
            $keys = array();
            foreach ($fee_ids as $fee => $val) {
                $keys[] = $val;
            }

            if (!$message->hasMessages()) {

//update designation
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_transactions SET tr_date = :tr_date, dr=:dr,cost_center=:cost_center,ttl_paid=:ttl_paid,username=:username WHERE tr_id_no = :tr_id_no');
                $upsql->execute(array(
                    ':tr_date' => $TrDate,
                    ':dr' => $DR,
                    ':cost_center' => $AcNo,
                    ':ttl_paid' => $amt,
                    ':username' => $foo,
                    ':tr_id_no' => $TridNo
                ));

                $i = 0;
                foreach ($fee_dtl as $fee) {
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_transaction_dtl SET rate = :rate WHERE tr_id = :tr_id AND item_id = :item_id');
                    $upsql->execute(array(
                        ':rate' => $fee,
                        ':item_id' => $keys[$i],
                        ':tr_id' => $TridNo,
                    ));
                    $i++;
                }
//                $message->add('s', 'Paid Fee is updated successfully!', CLIENT_URL . '/feevoucher');
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function delete_transections($r_id = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            $txns = Fee::get_txn('', $r_id, '')->fetch(PDO::FETCH_OBJ);
//            print_r($txns);
//            exit(); 
            $upsql = $oDb->prepare("DELETE  FROM  `" . DB_PREFIX . "fee_transaction_dtl`  WHERE `tr_id` LIKE '" . $r_id . "'");
            $upsql->execute();
            $upsql = $oDb->prepare("DELETE  FROM `" . DB_PREFIX . "fee_transactions` WHERE `id` LIKE '" . $r_id . "'");
            $upsql->execute();
            echo "sucess";
//                $message->add('s', 'Paid Fee is updated successfully!', CLIENT_URL . '/feevoucher');
            exit();
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function update_fee_paid_headwise($TrDate = NULL, $DR = NULL, $AcNo = NULL, $foo = NULL, $TridNo = NULL, $amt = NULL, $fee_dtl = NULL, $fee_ids = NULL, $late_fee = 0, $discount = 0, $cal_late_fee = 0, $msid = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {

//            print_r($fee_dtl) ;
//            exit();
            $keys = array();
            foreach ($fee_ids as $fee => $val) {
                $keys[] = $val;
            }

            if (!$message->hasMessages()) {

//update designation
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_transactions SET tr_date = :tr_date, dr=:dr,cost_center=:cost_center,ttl_paid=:ttl_paid,late_fee=:late_fee,cal_late_fee=:cal_late_fee,discount=:discount,username=:username WHERE id = :tr_id_no');
                $upsql->execute(array(
                    ':tr_date' => $TrDate,
                    ':dr' => $DR,
                    ':cost_center' => $AcNo,
                    ':ttl_paid' => $amt,
                    ':late_fee' => $late_fee,
                    ':cal_late_fee' => $cal_late_fee,
                    ':discount' => $discount,
                    ':username' => $foo,
                    ':tr_id_no' => $TridNo
                ));

                $i = 0;
                foreach ($fee_dtl as $fee) {
                    if ($keys[$i] < 0) {
                        $fee_details = Fee::get_feename_2($msid, $keys[$i])->fetch(PDO::FETCH_OBJ);
                        if ($fee_details->type == 2) {
                            $fee = -$fee;
                        }
                    }
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_transaction_dtl SET rate = :rate WHERE tr_id = :tr_id AND item_id = :item_id');
                    $upsql->execute(array(
                        ':rate' => $fee,
                        ':item_id' => $keys[$i],
                        ':tr_id' => $TridNo,
                    ));
                    $i++;
                }
                echo "sucess";
//                $message->add('s', 'Paid Fee is updated successfully!', CLIENT_URL . '/feevoucher');
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function update_fee_paid($TrDate = NULL, $DR = NULL, $AcNo = NULL, $foo = NULL, $TridNo = NULL, $amt = NULL, $fee_dtl = NULL, $fee_ids = NULL, $late_fee = 0, $discount = 0, $cal_late_fee = 0) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {

//            print_r($fee_dtl) ;
//            exit();
//            $keys = array();
//            foreach ($fee_ids as $fee => $val) { 
//                $keys[] = $val;
//            }

            if (!$message->hasMessages()) {

//update designation
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_transactions SET tr_date = :tr_date, dr=:dr,cost_center=:cost_center,ttl_paid=:ttl_paid,late_fee=:late_fee,discount=:discount,cal_late_fee=:cal_late_fee,username=:username WHERE tr_id_no = :tr_id_no');
                $upsql->execute(array(
                    ':tr_date' => $TrDate,
                    ':dr' => $DR,
                    ':cost_center' => $AcNo,
                    ':ttl_paid' => $amt,
                    ':late_fee' => $late_fee,
                    ':discount' => $discount,
                    ':cal_late_fee' => $cal_late_fee,
                    ':username' => $foo,
                    ':tr_id_no' => $TridNo
                ));

                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_transaction_dtl SET rate = :rate WHERE tr_id = :tr_id ');
                $upsql->execute(array(
                    ':rate' => $amt,
                    ':tr_id' => $TridNo,
                ));
                echo "sucess";
//                $message->add('s', 'Paid Fee is updated successfully!', CLIENT_URL . '/feevoucher');
                exit();
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function save_trancection($msid = NULL, $session = NULL, $TrDate = NULL, $DR = NULL, $AcNo = NULL, $foo = NULL, $Ref = NULL, $ID_DUEDATE_UNIQ = NULL, $TridNo = NULL, $amt = NULL, $fee_dtl = NULL, $extra = NULL, $fee_ids = NULL, $sr_no = NULL, $late_fee = NULL, $discount = NULL, $pass = "False") {
//        echo $amt, $discount;
//        exit();
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
//            print_r($fee_ids);
//            exit();
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transactions (MSID,session,tr_date,v_id,dr,cr,cost_center,cc_type,late_fee,cal_late_fee,discount,ttl_paid,username,party_refference,fee_receipt_id,status,tr_id_no,sr_no,EOD,type) VALUES  (:MSID,:session,:tr_date,:v_id,:dr,:cr,:cost_center,:cc_type,:late_fee,:cal_late_fee,:discount,:ttl_paid,:username,:party_refference,:fee_receipt_id,:status,:tr_id_no,:sr_no,:EOD,:type)');
            $sql->execute(array(
                ':MSID' => $msid,
                ':session' => $session,
                ':tr_date' => $TrDate,
                ':v_id' => '2',
                ':dr' => $DR,
                ':cr' => '3',
                ':cost_center' => $AcNo,
                ':cc_type' => '1',
                ':late_fee' => $late_fee,
                ':cal_late_fee' => $late_fee,
                ':discount' => $discount,
                ':ttl_paid' => $amt,
                ':username' => $foo,
                ':party_refference' => $Ref,
                ':fee_receipt_id' => $ID_DUEDATE_UNIQ,
                ':status' => '1',
                ':tr_id_no' => $TridNo,
                ':sr_no' => $sr_no,
                ':EOD' => '',
                ':type' => 'BillbyBill',
            ));

            $t_id = $oDb->lastInsertId();
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transaction_dtl (tr_id_no,tr_id,item_id,qty, rate, status) VALUES  (:tr_id_no,:tr_id,:item_id,:qty, :rate, :status)');
            $sql->execute(array(
                ':tr_id' => $TridNo,
                ':tr_id_no' => $t_id,
                ':item_id' => 999,
                ':qty' => '1',
                ':rate' => $amt,
                ':status' => '1'
            ));

            // For Backup

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transactions_bkup (MSID,session,tr_date,v_id,dr,cr,cost_center,cc_type,late_fee,cal_late_fee,discount,ttl_paid,username,party_refference,fee_receipt_id,status,tr_id_no,sr_no,EOD,type) VALUES  (:MSID,:session,:tr_date,:v_id,:dr,:cr,:cost_center,:cc_type,:late_fee,:cal_late_fee,:discount,:ttl_paid,:username,:party_refference,:fee_receipt_id,:status,:tr_id_no,:sr_no,:EOD,:type)');
            $sql->execute(array(
                ':MSID' => $msid,
                ':session' => $session,
                ':tr_date' => $TrDate,
                ':v_id' => '2',
                ':dr' => $DR,
                ':cr' => '3',
                ':cost_center' => $AcNo,
                ':cc_type' => '1',
                ':late_fee' => $late_fee,
                ':cal_late_fee' => $late_fee,
                ':discount' => $discount,
                ':ttl_paid' => $amt,
                ':username' => $foo,
                ':party_refference' => $Ref,
                ':fee_receipt_id' => $ID_DUEDATE_UNIQ,
                ':status' => '1',
                ':tr_id_no' => $TridNo,
                ':sr_no' => $sr_no,
                ':EOD' => '',
                ':type' => 'BillbyBill',
            ));

            $t_id = $oDb->lastInsertId();
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transaction_dtl_bkup (tr_id_no,tr_id,item_id,qty, rate, status) VALUES  (:tr_id_no,:tr_id,:item_id,:qty, :rate, :status)');
            $sql->execute(array(
                ':tr_id' => $TridNo,
                ':tr_id_no' => $t_id,
                ':item_id' => 999,
                ':qty' => '1',
                ':rate' => $amt,
                ':status' => '1'
            ));

            if ($pass == "True") {
                $message->add('s', 'Fee Submited successfully!', CLIENT_URL . '/feevoucher');
            } else {
                echo 'sucess';
            }
            exit();
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function save_trancection_headwise($msid = NULL, $session = NULL, $TrDate = NULL, $DR = NULL, $AcNo = NULL, $foo = NULL, $Ref = NULL, $ID_DUEDATE_UNIQ = NULL, $TridNo = NULL, $amt = NULL, $fee_dtl = NULL, $extra = NULL, $fee_ids = NULL, $sr_no = NULL, $late_fee = 0, $discount = 0, $pass = "False") {

        $message = new Messages();
        $oDb = DBConnection::get();
        try {
//            echo '<pre>';
//            print_r($fee_dtl);
//            exit();
//            print_r($pass);
//            exit(); 
            if (@$sr_no) {
                $type = "BillbyBill";
            } else {
                $type = "Adjustment";
            }
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transactions (MSID,session,tr_date,v_id,dr,cr,cost_center,cc_type,late_fee,cal_late_fee,discount,ttl_paid,username,party_refference,fee_receipt_id,status,sr_no,EOD,type) VALUES  (:MSID,:session,:tr_date,:v_id,:dr,:cr,:cost_center,:cc_type,:late_fee,:cal_late_fee,:discount,:ttl_paid,:username,:party_refference,:fee_receipt_id,:status,:sr_no,:EOD,:type)');
            $sql->execute(array(
                ':MSID' => $msid,
                ':session' => $session,
                ':tr_date' => $TrDate,
                ':v_id' => '2',
                ':dr' => $DR,
                ':cr' => '3',
                ':cost_center' => $AcNo,
                ':cc_type' => '1',
                ':late_fee' => $late_fee,
                ':cal_late_fee' => $late_fee,
                ':discount' => $discount,
                ':ttl_paid' => $amt,
                ':username' => $foo,
                ':party_refference' => $Ref,
                ':fee_receipt_id' => $ID_DUEDATE_UNIQ,
                ':status' => '1',
                ':sr_no' => $sr_no,
                ':EOD' => '',
                ':type' => $type,
            ));

            $t_id = $oDb->lastInsertId();
            if (@$fee_dtl) {
//                print_r($fee_dtl);
//                exit();
                foreach ($fee_dtl as $fee) {

                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transaction_dtl (tr_id,item_id,qty, rate, status) VALUES  (:tr_id,:item_id,:qty, :rate, :status)');
                    $sql->execute(array(
                        ':tr_id' => $t_id,
                        ':item_id' => $fee['FeeId'],
                        ':qty' => '1',
                        ':rate' => $fee['FeeAmt'],
                        ':status' => '1'
                    ));
                }
            }
            if ($extra != NULL) {
                $keys = array();
                foreach ($fee_ids as $fee => $val) {
                    $keys[] = $val;
                }
                $i = 0;
                foreach ($extra as $fee => $val) {
                    $fee_details = Fee::get_feename_2($msid, $keys[$i])->fetch(PDO::FETCH_OBJ);
                    if ($fee_details->type == 2) {
                        $val = -$val;
                    }
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transaction_dtl (tr_id,item_id,qty, rate, status) VALUES  (:tr_id,:item_id,:qty, :rate, :status)');
                    $sql->execute(array(
                        ':tr_id' => $t_id,
                        ':item_id' => $keys[$i],
                        ':qty' => '1',
                        ':rate' => $val,
                        ':status' => '1'
                    ));
                    $i++;
                }
            }
            //for Backup

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transactions_bkup (MSID,session,tr_date,v_id,dr,cr,cost_center,cc_type,late_fee,cal_late_fee,discount,ttl_paid,username,party_refference,fee_receipt_id,status,sr_no,EOD,type) VALUES  (:MSID,:session,:tr_date,:v_id,:dr,:cr,:cost_center,:cc_type,:late_fee,:cal_late_fee,:discount,:ttl_paid,:username,:party_refference,:fee_receipt_id,:status,:sr_no,:EOD,:type)');
            $sql->execute(array(
                ':MSID' => $msid,
                ':session' => $session,
                ':tr_date' => $TrDate,
                ':v_id' => '2',
                ':dr' => $DR,
                ':cr' => '3',
                ':cost_center' => $AcNo,
                ':cc_type' => '1',
                ':late_fee' => $late_fee,
                ':cal_late_fee' => $late_fee,
                ':discount' => $discount,
                ':ttl_paid' => $amt,
                ':username' => $foo,
                ':party_refference' => $Ref,
                ':fee_receipt_id' => $ID_DUEDATE_UNIQ,
                ':status' => '1',
                ':sr_no' => $sr_no,
                ':EOD' => '',
                ':type' => $type,
            ));

            $t_id = $oDb->lastInsertId();
            if (@$fee_dtl) {
//                print_r($fee_dtl);
//                exit();
                foreach ($fee_dtl as $fee) {

                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transaction_dtl_bkup (tr_id,item_id,qty, rate, status) VALUES  (:tr_id,:item_id,:qty, :rate, :status)');
                    $sql->execute(array(
                        ':tr_id' => $t_id,
                        ':item_id' => $fee['FeeId'],
                        ':qty' => '1',
                        ':rate' => $fee['FeeAmt'],
                        ':status' => '1'
                    ));
                }
            }
            if ($extra != NULL) {
                $keys = array();
                foreach ($fee_ids as $fee => $val) {
                    $keys[] = $val;
                }
                $i = 0;
                foreach ($extra as $fee => $val) {
                    $fee_details = Fee::get_feename_2($msid, $keys[$i])->fetch(PDO::FETCH_OBJ);
                    if ($fee_details->type == 2) {
                        $val = -$val;
                    }
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transaction_dtl_bkup (tr_id,item_id,qty, rate, status) VALUES  (:tr_id,:item_id,:qty, :rate, :status)');
                    $sql->execute(array(
                        ':tr_id' => $t_id,
                        ':item_id' => $keys[$i],
                        ':qty' => '1',
                        ':rate' => $val,
                        ':status' => '1'
                    ));
                    $i++;
                }
            }

            if ($pass == "True") {
               

            $message->add('s', 'Fee Submited successfully!', CLIENT_URL . '/feevoucher');
            } else {
                echo 'sucess';
            }
            exit();
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_ledgers($msid = NULL, $id = NULL) {
        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_ledgers Where 1 ";
            if ($msid != NULL) {
                $sql .= " and MSID = " . $msid;
            }
            if ($id != NULL) {
                $sql .= " and ledgers_id = " . $id;
            }

            $sql .= " order by id ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

//DELETE e1 FROM  `ms_locality` e1, `ms_locality` e2 WHERE e1.name = e2.name AND e1.post_id = e2.post_id AND e1.id > e2.id
    public static function get_fee_billing_loops($uid = NULL, $acno = NULL) {
        try {
            $sql = " SELECT * FROM `" . DB_PREFIX . "fee_billing` B INNER JOIN (SELECT * FROM ms_slusers WHERE MyUId='" . $uid . "') CU ON B.MSID=CU.MSID AND B.Session = CU.MySession WHERE `AcNo`='" . $acno . "' GROUP BY RSrNo ORDER BY RSrNo";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_txn($msid = NULL, $id = NULL, $recipt_id = NULL) {
        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_transactions Where 1 ";
            if ($msid != NULL) {
                $sql .= " and MSID = " . $msid;
            }
            if ($id != NULL) {
                $sql .= " and id = '" . $id . " ' ";
            }if ($recipt_id != NULL) {
                $sql .= " and fee_receipt_id = '" . $recipt_id . "' ";
            }
            $sql .= " order by id ASC";
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_txn_detail($id = NULL) {
        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_transaction_dtl Where 1 ";
//            if ($msid != NULL)
//                {
//                $sql .= " and MSID = " . $msid;
//                }
            if ($id != NULL) {
                $sql .= " and tr_id = '" . $id;
            }
            $sql .= "' order by id ASC";
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_genrated_distinct_fee($msid = NULL, $session = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT distinct  MSID,Session FROM " . DB_PREFIX . "fee_billing WHERE 1 ";
            if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }
            if (@$session) {
                $sql .= " AND  Session=" . $session;
            }

            $sql .= " order by id ASC";


            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_distinct_fee($msid = NULL, $id = NULL, $fee_id = NULL, $date = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10), $distinct = "False") {
        try {
            if ($distinct == "True") {
                $sql = "SELECT distinct  fee_id,class_from, class_to,fee_rate FROM " . DB_PREFIX . "fee WHERE 1 ";
            } else {
                $sql = "SELECT * FROM " . DB_PREFIX . "fee WHERE 1 ";
            }
            if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }
            if (@$fee_id) {
                $sql .= " AND  fee_id=" . $fee_id;
            } if (@$date) {
                $sql .= " AND  '" . $date . "'  Between `date_from` And`date_to` ";
            }
            if ($id != NULL) {
                $sql .= " AND  id = " . $id;
            }

            $sql .= " order by id ASC";


            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_fee_tsn($msid = NULL, $session = NULL, $AcNo = NULL, $date = NULL) {
        try {

            $sql = "

SELECT T.tr_date,T.id,T.type,T.cal_late_fee,T.discount,(Q1.amt) as amt,T.late_fee,T.fee_receipt_id,T.sr_no,T.type from " . DB_PREFIX . "fee_transactions T INNER JOIN (SELECT `tr_id`,sum(`rate`) amt FROM `ms_fee_transaction_dtl` where status!='0' GROUP By `tr_id`) AS Q1 ON  T.id=Q1.tr_id WHERE 1 ";
            if (@$msid) {
                $sql .= " AND T.MSID = " . $msid;
            }
            if (@$session) {
                $sql .= " AND T.session = " . $session . " AND T.v_id='2' ";
            }
            if (@$AcNo) {
                $sql .= " AND T.cost_center = '" . $AcNo . "' AND   status!='0' ";
            }
            if (@$date) {
                $sql .= "  And  T.tr_date<= '" . $date . "' ";
            }
            $sql .= " ORDER BY  T.tr_date,T.sr_no";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_fee_tsn_tpt($msid = NULL, $session = NULL, $AcNo = NULL, $date = NULL, $tpt = NULL) {
        try {

            $sql = " SELECT T.tr_date, T.id tr_id ,T.id,T.cal_late_fee,T.discount,(Q1.amt) as amt,T.late_fee,T.fee_receipt_id,T.sr_no,T.type FROM " . DB_PREFIX . "fee_transactions T INNER JOIN (SELECT `tr_id`,sum(`rate`) amt FROM `ms_fee_transaction_dtl` where status!='0' GROUP By `tr_id`) AS Q1 ON T.id=Q1.tr_id WHERE 1 ";
            if (@$msid) {
                $sql .= " AND T.MSID = " . $msid;
            }
            if (@$session) {
                $sql .= " AND T.session = " . $session . " AND T.v_id='2' ";
            }
            if (@$AcNo) {
                $sql .= " AND T.cost_center = '" . $AcNo . "' AND   status!='0' ";
            }
            if (@$date) {
                $sql .= "  And  T.tr_date<= '" . $date . "' ";
            }
//              if ($tpt == "0") {
//                $sql .= " AND  FF.FeeId != 0 ";
//            } else if ($tpt == "2") {
//                $sql .= " AND  FF.FeeId = 0 ";
//            }
            $sql .= " ORDER BY  T.tr_date,T.sr_no";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_Std_fee($msid = NULL, $session = NULL, $acno = NULL, $srno = NULL, $groupby = "TRUE", $group_2 = "False") {
        try {
            if ($group_2 == "True") {
                $sql = "  SELECT MSID,id, type,AcNo, SID,FeeName, SrNo, RSrNo, DueDate, FeeId,sum(FeeAmt) as FeeAmt  FROM " . DB_PREFIX . "fee_billing Where 1 ";
            } else {
                if ($groupby == "FALSE") {
                    $sql = "  SELECT MSID,id,type, AcNo, SID,FeeName, SrNo, RSrNo, DueDate, FeeId,FeeAmt FROM " . DB_PREFIX . "fee_billing Where 1 ";
                } else {
                    $sql = "  SELECT MSID,id, AcNo,type, SID,FeeName, SrNo, RSrNo, DueDate, FeeId,FeeAmt, sum(FeeAmt) as fee FROM " . DB_PREFIX . "fee_billing Where 1 ";
                }
            }

            if (@$msid) {
                $sql .= " AND MSID = " . $msid;
            }
            if (@$session) {
                $sql .= " AND Session = " . $session;
            }
            if (@$acno) {
                $sql .= " AND AcNo = " . $acno;
            }
            if (@$srno) {
                $sql .= " AND RSrNo = " . $srno;
            }

            if ($group_2 == "True") {
                $sql .= " group by FeeId ,AcNo ";
            } else {
                if ($groupby == "FALSE") {
                    
                } else {
                    $sql .= " group by RSrNo , AcNo";
                }
            }
//            $sql .= " ORDER by ID DESC";
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_Std_fee2($myuid = NULL, $acno = NULL) {
        try {


            $sql = "  SELECT BE.FeeName,BE.type,BE.FeeId,(BE.FeeAmt-COALESCE(TE.AmtRd,0)) ToPay FROM(SELECT B.AcNo,B.FeeId,B.type,B.FeeName,SUM(B.FeeAmt)FeeAmt FROM(SELECT * FROM ms_slusers WHERE MyUid='" . $myuid . "') CU INNER JOIN ms_fee_billing B ON B.msid=CU.msid AND B.session =CU.MySession AND B.DueDate <= CU.MyDate Where AcNo='" . $acno . "' GROUP BY FeeId) BE Left Join (SELECT T.`cost_center`,`late_fee`,`discount`,`EOD`,`cal_late_fee`,TD.`item_id`,SUM(TD.`rate`)AmtRd FROM(SELECT * FROM ms_slusers WHERE MyUid='" . $myuid . "') CU INNER JOIN ms_fee_transactions T ON T.msid=CU.msid AND T.session=CU.MySession AND T.tr_date<= CU.MyDate INNER JOIN ms_fee_transaction_dtl TD ON TD.tr_id=T.id Where T.Cost_center='" . $acno . "' GROUP BY TD.item_id)TE ON BE.AcNo=TE.Cost_Center AND BE.FeeId=TE.Item_id Having ToPay > 0";

//            $sql .= " ORDER by ID DESC";
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_feename_2($msid = NULL, $id = NULL) {

        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_billing WHERE 1 ";
            if ($msid != NULL) {
                $sql .= " AND MSID = " . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND FeeId = " . $id;
            }

            $sql .= " order by id ";


//            print_r($sql);
//die("<>><");
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_feename($msid = NULL, $id = NULL) {

        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_billing WHERE 1 ";
            if ($msid != NULL) {
                $sql .= " AND MSID = " . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND id = " . $id;
            }

            $sql .= " order by id ";


//            print_r($sql);
//die("<>><");
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_distinct_fee_names_from_billing($msid = NULL, $session = NULL, $type = Null, $id = NULL, $rsrno = NULL, $student_id = NULL, $fee_id = NULL) {

        try {
            $sql = "    SELECT distinct FeeName ,FeeId ,id FROM " . DB_PREFIX . "fee_billing WHERE 1 ";
            if ($msid != NULL) {
                $sql .= " And MSID = " . $msid;
            }
            if ($session != NULL) {
                $sql .= " And Session = " . $session;
            }
            if ($type != NULL) {
                $sql .= " AND type = " . $type;
            }
            if ($id != NULL) {
                $sql .= " AND id = " . $id;
            } if ($rsrno != NULL) {
                $sql .= " AND RSrNo = " . $rsrno;
            }
            if ($student_id != NULL) {
                $sql .= " AND SID = " . $student_id;
            }
            if ($fee_id != NULL) {
                $sql .= " AND FeeId = " . $fee_id;
            }
            $sql .= " order by id ";
//            print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_fee_names($msid = NULL, $id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10), $fee_id = NULL, $groupby = "False", $tpt = "1") {
        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_names WHERE 1 ";
            if ($msid != NULL) {
                $sql .= " AND MSID = " . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND id = " . $id;
            }
            if ($tpt == "0") {
                $sql .= " AND  fee_id != 0 ";
            } else if ($tpt == "2") {
                $sql .= " AND  fee_id = 0 ";
            }
            if ($fee_id != NULL) {

                $sql .= " AND fee_id = " . $fee_id;
            }


            if ($groupby == "True") {
                $sql .=" Group by fee_group_id ";
            }
            $sql .= " order by id ";


            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql); 
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_fee_discount($msid = NULL) {
        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_discount WHERE ";
            if ($msid != NULL) {
                $sql .= " MSID = " . $msid;
            }
            $sql .= " order by id ";



//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function day_end($msid = NULL, $date_from = NULL, $date_to = NULL) {
        try {
            $message = new Messages();

//            $oDb = DBConnection::get();
//            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_transactions FT  inner join (select * from ms_slusers where MyUid="'.$myuid.'" ) CU on FT.`tr_date` between CU.my_period_from and CU.my_period_to  SET FT.`status`=2  WHERE FT.MSID=CU.MSID');
            $sql = 'UPDATE ' . DB_PREFIX . 'fee_transactions  SET `status`=2  WHERE MSID=' . $msid . ' AND  `tr_date` between "' . $date_from . '" and "' . $date_to . '"';
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            $message->add('s', 'Day Ended Sucessfully You Can Not Be able to Alter Data Now!', CLIENT_URL . '/fee-headwise');

//            print_r($sql);
            return $sql;
            exit();


//            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_school_fee($msid = NULL, $id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "    SELECT F.*, FN.fee_name FROM " . DB_PREFIX . "fee F";
            $sql .= " INNER JOIN " . DB_PREFIX . "fee_names FN ON F.fee_id = FN.fee_id AND F.MSID = FN.MSID";

            if ($id != NULL) {
                $sql .= " WHERE F.id = " . $id;
            } else {
                if ($msid != NULL) {
                    $sql .= " WHERE F.MSID = " . $msid;
                }
            }
            $sql .= " AND '" . $_SESSION['user_date'] . "' between F.date_from and F.date_to";

            $sql .= " order by id ASC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($_POST);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_fee_type($id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10, 'type' => 'feename')) {
        try {
            $sql = "   SELECT * FROM " . DB_PREFIX . "fee_type";

            if ($id != NULL) {
                $sql .= " WHERE id = " . $id;
            } else {
                $sql .= " WHERE type = '{$data['type']}'";
            }

            $sql .= " order by id ASC";
            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function get_fee_schedule($msid = NULL, $id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10), $RSrNo = Null, $feepaymode = Null, $mydate = '') {
//        print_r($feepaymode);
//        exit();
        try {
            $sql = "    SELECT * FROM " . DB_PREFIX . "fee_schedule where 1 ";
            if ($msid != NULL) {
                $sql .= " And MSID = " . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND id = " . $id;
            } if ($RSrNo != NULL) {
                $sql .= " AND r_sr_no = " . $RSrNo;
            }
            if (@$feepaymode || $feepaymode == "0") {
                $sql .= " AND pay_mode = " . $feepaymode;
            }
            if (@$mydate) {
                $sql .= " AND '" . $mydate . "' Between date_from and date_to ";
            }
            $sql .= " order by id ASC";
//            print_r($sql);
            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public function add_fee_schedule($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_schedule SET pay_mode = :pay_mode, r_sr_no=:r_sr_no,sr_no_from=:sr_no_from,sr_no_to=:sr_no_to WHERE id = :id');
                    $upsql->execute(array(
                        ':pay_mode' => $postdata['pay_mode'],
                        ':r_sr_no' => $postdata['r_sr_no'],
                        ':sr_no_from' => $postdata['sr_no_from'],
                        ':sr_no_to' => $postdata['sr_no_to'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Fee Schedule is updated successfully!', CLIENT_URL . '/fee-schedule');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_schedule (MSID, pay_mode,r_sr_no ,sr_no_from,sr_no_to, created_date) VALUES  (:MSID, :pay_mode, :r_sr_no, :sr_no_from, :sr_no_to, :created_date)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':pay_mode' => $postdata['pay_mode'],
                        ':r_sr_no' => $postdata['r_sr_no'],
                        ':sr_no_from' => $postdata['sr_no_from'],
                        ':sr_no_to' => $postdata['sr_no_to'],
                        ':created_date' => date('Y-m-d H:i:s')
                    ));
                    $message->add('s', 'Fee Schedule added successfully!', CLIENT_URL . '/fee-schedule');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage
                    ());
        }
    }

    public static function feeCollection($msid = NULL, $class = NULL, $sid = NULL) {
        try {
            $sql = "   Select CSD.MSID MSID, CSD.AcNo AcNo, CSD.SID SID, CSD.SrNo SrNo, FS.month RSrNo, CSD.DueDate DueDate, CSD.FeeId FeeId, round(Sum(If(FEE.fee_id = 0, COALESCE(TR.fee, 0),
                    FEE.fee_rate))*(1-COALESCE (DR.percent, 0))-(COALESCE(DR.fixed_amount, 0))) FeeAmt
                    From (/* --------------------------------------CSD Starts ------------------------------------ */
                    Select Q1.*, If(Month(Q1.DueDate)-Month(Q1.Begins)+1 >0, Month(Q1.DueDate)-Month(Q1.Begins)+1, Month(Q1.DueDate)-Month (Q1.Begins)+13) SrNo
                    , Q1.adm_classno+Year(Q1.Begins)-Year(Q1.fees_date)+COALESCE(Sum(E.result), 0)

                    CClass, SFG.subgroupid FGroupId , SAT.tpt_stn_id TptStation, DS.discount_id Discount, P.f_name, P.mobile_sms MobileSMS, P.feepaymentmode FeePaymentMode
                    FROM (/* +++++++++++++++++++++++++++++++++++++++++++++++++Q1 Starts+++++++++++++++++++++++++++++++++++++++++++++++ */
                    Select S.student_id SID, S.parent_id, S.acno AcNo, S.name StudentName, S.adm_classno, S.fees_date, S.sl_date, S.group_id, S.opening_bal, DD.date_id DueDate, FN.fee_id FeeId, FN.fee_name FeeName, FN.fee_group_name FeeGroup, COY.name SchoolName, COY.SeprateTPTFBook, CU.MSID, CU.mydate Mydate, CU.mysession MySession, CU.begins Begins, CU.ends Ends From (SELECT * FROM `ms_slusers` WHERE myuid = '1001e1' ) CU
                    Inner Join ms_schools COY On COY.MSID = CU.MSID
                    Inner Join ms_dates DD On DD.date_id Between CU.begins And CU.ends And Day(date_id) = '1'
                    Inner Join ms_students S On S.MSID = CU.MSID And DD.date_id Between S.fees_date And S.sl_date
                    Inner Join ms_fee_names FN On FN.MSID = CU.MSID";
            $sql .=" where CU.MSID = " . $msid;
            if ($sid != NULL) {
                $sql .=" AND S.student_id = " . $sid;
            }
            $sql .=" order by S.student_id, DD.date_id
                    /* Where S.AcNo='6' */
                    /* ++++++++++++++++++++++++++++++++++++++++++++++++++++ Q1 Ends ++++++++++++++++++++++++++++++++++++++++++++++++++ */
                    ) Q1

                    Left Join
                    ms_exams E On E.MSID = Q1.MSID AND E.s_id = Q1.SID And E.date_result < Q1.DueDate
                    Inner Join
                    ms_subjects SFG On SFG.MSID = Q1.MSID AND SFG.subject_gp_id = Q1.group_id
                    Left Join
                    ms_tpt_std SAT ON SAT.MSID = Q1.MSID And Q1.DueDate Between SAT.date_from And SAT.date_to And SAT.S_id = Q1.SID
                    Left Join
                    ms_discounted_student DS ON DS.MSID = Q1.MSID And DS.s_id = Q1.SID And Q1.DueDate Between DS.date_from And DS.date_to
                    Inner Join
                    ms_parents P On P.id = Q1.parent_id
                    Inner Join
                    ms_locality L On L.MSID = Q1.MSID And L.id = P.village

                    Where 1
                    Group By Q1.SID, Q1.DueDate, Q1.FeeId
                    /* -----------------------------------------------------------CSD Ends------------------------------------ */
                    ) CSD

                    Inner Join
                    ms_fee_schedule FS On FS.MSID = CSD.MSID And FS.pay_mode = CSD.FeePaymentMode And FIND_IN_SET(CSD.SrNo, FS.fee_of_months)
                    Inner Join
                    ms_fee FEE On FEE.MSID = CSD.MSID And CSD.DueDate Between FEE.date_from And FEE.date_to And FEE.fee_id = CSD.FeeId And FIND_IN_SET(CSD.CClass, FEE.classes) And
                    (CSD.FgroupId = FEE.fee_group_id Or FEE.fee_group_id = '0') And If(FEE.ff = '1' And CSD.DueDate = CSD.fees_date, CSD.SrNo Between FEE.ff_from And FEE.ff_to, CSD.SrNo Between FEE.sr_no_from And FEE.sr_no_to)
                    Left Join
                    ms_tpt_fee TR On TR.MSID = CSD.MSID And CSD.DueDate Between TR.date_from And TR.date_to And CSD.TptStation = TR.station_id
                    Left Join
                    ms_discount_rule DR On DR.MSID = CSD.MSID And CSD.DueDate Between DR.date_from And DR.date_to And DR.discount_id = CSD.Discount And DR.fee_id = FEE.fee_id And FIND_IN_SET(CSD.CClass, DR.classes) And FIND_IN_SET(CSD.SrNo, DR.months)";
            if ($class != NULL) {
                $sql .=" where CSD.CClass = " . $class;
            }
            $sql .=" Group By AcNo, SrNo, SID, FeeId";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_defaulters2($msid = Null, $type = NULL, $class = Null, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10), $sum = "False") {
        try {
//            print_r($data);
            $sql = "";
            if (@$sum == "True") {
                $sql .="select  Sum(MN3.bal) as balance From (";
            } $sql .= "Select MN2.MSID,MN2.AcNo,MN2.FeeAmt,MN2.OpeningBal, Coalesce(T.Amt,0) Amt, Coalesce(T.CalLateFee,0) CalLateFee,Coalesce(T.LateFee,0) LateFee,Round(MN2.OpeningBal+MN2.FeeAmt

+Coalesce(T.CalLateFee,0)-Coalesce(T.Amt,0)-Coalesce(T.LateFee,0)) Bal,MN2.StudentName,MN2.FatherName,MN2.SID,MN2.Class,MN2.section,MN2.Village,MN2.MobileSMS

From (
/*((((((((((((((((((((((((((((( MN2 Begins))))))))))))))))))))))))))))))))))*/
Select MN1.MSID,MN1.MyDate,MN1.AcNo,MN1.OpeningBal,Sum(MN1.FeeAmt) FeeAmt,MN1.StudentName,MN1.FatherName,MN1.SID,MN1.Class,MN1.section,MN1.Village,MN1.MobileSMS From(
/*_________________________________________MN1 Begins________________________________*/   
Select MN.MSID,MN.MyDate,MN.DueDate, MN.AcNo,Sum(MN.FeeAmt) FeeAmt,MN.OpeningBal,MN.StudentName,MN.FatherName,MN.SID,MN.Class,MN.section,MN.Village,MN.MobileSMS

FROM (
select FE.*,S.Name StudentName,S.AdmNo,S.Section,S.opening_bal OpeningBal,U.mydate MyDate from  (select * from ms_fee_billing ) FE left join ms_students S

on S.msid=FE.msid and S.student_id=FE.SID left join ms_parents P on

P.msid=FE.msid and P.id=S.parent_id left join ms_locality L on L.msid=P.msid and L.id=P.Village inner join  (select * from ms_slusers where myuid='" . $msid . "' ) U on 

FE.msid=U.msid

) MN
Group By AcNo,RSrNo
/*___________________________________________MN1 Ends _________________________________*/                                
)MN1
Where MN1.DueDate <= MN1.MyDate
Group By MN1.AcNo
/*((((((((((((((((((((((((((((((MN2 Ends))))))))))))))))))))))))))))))))))*/
) MN2
Left Join (Select cost_center,Sum(Amt) Amt,Sum(cal_late_fee) CalLateFee,Sum(late_fee) LateFee From

Vu_39Transactions VU  Inner Join (SELECT

*
FROM `ms_slusers` WHERE MyUid = '" . $msid . "' ) CU On VU.MSID=CU.MSID And VU.Session = CU.mysession And VU.TrDate <= CU.mydate Group By

cost_center) T On T.Cost_center = MN2.AcNo ";
            if ($type == "defaulters") {
                $sql.=" Having Bal > 0";
            } elseif ($type == "advancepayer") {
                $sql.=" Having Bal < 0";
            } elseif ($type == "perfact_payer") {
                $sql.=" Having Bal = 0";
            }
//            elseif ($type == "today") {
//                $sql.=" ";
//            }
            elseif ($type == "classwise_today") {
                $sql.=" Having MN2.Class= '" . $class . "'";
            } elseif ($type == "classwise_defaulters") {
                $sql.=" Having Bal > 0 And MN2.Class= '" . $class . "'";
            }



            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            if (@$sum == "True") {
                $sql .=" ) as MN3  ";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

// public static function get_fee_due_amt($msid = Null, $mydate = Null, $acno = NULL, $begin = NULL, $end = NULL, $tpt = "FALSE") {
//        try {
//            $sql = " Select AcNo,round(Sum(FeeAmt)) DueAmt,Month(DueDate) as mn From `ms_fee_billing` Where `MSID`='" .
//                    $msid . "' and `ACNo`='" . $acno . "'  And RSrNo <= Month('" . $mydate . "')   and DueDate between '" . $begin .
//                    "' And '" . $end . "'";
//            if ($tpt == "True") {
//                $sql .="   GROUP BY  ACNo";
//            } else {
//                $sql .=" And  `FeeId`!='0'    GROUP BY  ACNo";
//            }
//
////            print_r($sql);
////            exit();
//            $oDb = DBConnection::get();
//            $sql = $oDb->query($sql);
//            return $sql;
//        } catch (PDOException $e) {
//            $message = new Messages();
//            $message->add('e', $e->getMessage());
//        }
//    }


    public static function fee_transaction_upload($file = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {


            //Upload File
            //Import uploaded file to Database
            //readfile($file['csv_file']['tmp_name']);
            $handle = fopen($file['csv_file']['tmp_name'], "r");

            //print_r($handle);


            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_transactions_b (MSID,session,tr_date,v_id,dr,cr,cost_center,cc_type,m_reading,late_fee,discount,ttl_paid,sr_no,narration,username,time_stamp,party_refference,fee_receipt_id,status,tr_id_no,EOD,type,cal_late_fee,due_month) VALUES  (:MSID, :session, :tr_date, :v_id, :dr, :cr, :cost_center, :cc_type, :m_reading, :late_fee, :discount, :ttl_paid, :sr_no, :narration, :username, :time_stamp, :party_refference, :fee_receipt_id, :status, :tr_id_no, :EOD, :type, :cal_late_fee, :due_month)');
                $sql->execute(array(
                    ':MSID' => $data[0],
                    ':session' => $data[1],
                    ':tr_date' => $data[2],
                    ':v_id' => $data[3],
                    ':dr' => $data[4],
                    ':cr' => $data[5],
                    ':cost_center' => $data[6],
                    ':cc_type' => $data[7],
                    ':m_reading' => $data[8],
                    ':late_fee' => $data[9],
                    ':discount' => $data[10],
                    ':ttl_paid' => $data[11],
                    ':sr_no' => $data[12],
                    ':narration' => $data[13],
                    ':username' => $data[14],
                    ':time_stamp' => $data[15],
                    ':party_refference' => $data[16],
                    ':fee_receipt_id' => $data[17],
                    ':status' => $data[18],
                    ':tr_id_no' => $data[19],
                    ':EOD' => $data[20],
                    ':type' => $data[21],
                    ':cal_late_fee' => $data[22],
                    ':due_month' => $data[23]
                ));
            }



            fclose($handle);

            $message->add('s', 'Fee transaction uploaded  successfully!', CLIENT_URL . '/fee-transaction');
            exit();
        } catch (Exception $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_reciept_bulk_print($myuid = NULL, $datefrm = NULL, $dateto = NULL) {
        try {

            $sql = "SELECT S.`student_id`,S.`name`,P.`f_name`,T.tr_date,T.party_refference, T.type, P.`mobile_sms`, `cost_center`, FN.`fee_name`,TD.`item_id`, SUM(TD.`rate`) rate FROM `ms_fee_transactions` T Inner join (Select * from ms_slusers where myuid='$myuid') CU ON CU.MSID=T.MSID And CU.mysession=T.session And T.tr_date=CU.mydate inner join ms_fee_transaction_dtl TD ON T.`id`= TD.`tr_id` Inner Join ms_fee_names FN On FN.`fee_id`=TD.`item_id` And FN.MSID=CU.MSID Inner Join ms_students S ON S.`MSID`=CU.MSID And S.`acno`=T.cost_center inner join ms_parents P on P.MSID=CU.MSID And P.id=S.`parent_id` Group by T.party_refference Order by T.party_refference";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
//            print_r($sql);
            return $sql;
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }

}

?>
