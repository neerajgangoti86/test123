<?php

ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 'on');
# get micro time to check what time it takes to load the PHP
$iSMT = microtime(true);

//"SELECT `feegroupid` ,group_concat(sa.subject_s_name) FROM `ms_fee_slsubgrp` fsg 
//Inner join ms_subjects_all sa on sa.subject_id=fsg.subgroupid WHERE 1 group by `feegroupid`"
// To see what the document root is you can use next line (not working with cron jobs)
//echo $_SERVER['DOCUMENT_ROOT'];
# set document root
//define('DOCUMENT_ROOT', '/home/rootsmann/domains/rootsmann.nl/public_html/');
define('DOCUMENT_ROOT', $_SERVER['DOCUMENT_ROOT'] . '/');
//print_r(DOCUMENT_ROOT);
# for checking access in controllers
define("ACCESS", 'xXx');

include_once DOCUMENT_ROOT . '/inc/config.inc.php';

include_once INC_FOLDER . '/loginControl.inc.php';


# get the controller from the $_GET
$sControllerRequest = strtolower(http_get('controller', null));



# controller request is empty? simulate home
if (empty($sControllerRequest))
    {
    $sControllerRequest = 'home';
    $_GET['controller'] = 'home';
    }
# Key = 'controller name', Value = 'path to file' ()
//Superadmin
if (@$oCurrentUser->ulevel == '11')
    {
    $aControllers = array(
        'home' => '/controllers/superadmin/home.cont.php',
        'schools' => '/controllers/superadmin/schools.cont.php',
        'users' => '/controllers/superadmin/users.cont.php',
        'profile' => '/controllers/superadmin/profile.cont.php',
        'subjectall' => '/controllers/superadmin/subjectall.cont.php',
        'subjectgroup' => '/controllers/superadmin/subjectgroup.cont.php',
        'school-subject-group' => '/controllers/superadmin/schoolsubjects.cont.php',
        'ajax-load' => '/controllers/superadmin/ajax-load.cont.php',
        'ajax-post' => '/controllers/superadmin/ajax-post.cont.php',
        'fee-name' => '/controllers/superadmin/feenames.cont.php',
        'fee-type' => '/controllers/superadmin/feetype.cont.php',
        'fee-group' => '/controllers/superadmin/feegroup.cont.php',
        'fee-schedule' => '/controllers/superadmin/feeschedule.cont.php',
        'fee-billing-genrater' => '/controllers/superadmin/feebilling_genrater.cont.php',
        'board' => '/controllers/superadmin/board.cont.php',
        'fee' => '/controllers/superadmin/fee.cont.php',
        'fee-genrator' => '/controllers/superadmin/fee_copy.cont.php',
        'settings' => '/controllers/superadmin/setting.cont.php',
        'discount' => '/controllers/superadmin/discount.cont.php',
        'discount-rules' => '/controllers/superadmin/discountRule.cont.php',
        'discounted-students' => '/controllers/superadmin/discountedStudents.cont.php',
        'houses' => '/controllers/superadmin/houses.cont.php'
    );
    }

//school admin
else if (@$oCurrentUser->ulevel == '9')
    {

    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        "main-dash" => "/controllers/home_dashboard.cont.php",
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admin/admission/admissions.cont.php',
        'enrollment' => '/controllers/admin/admission/enrollmentform.cont.php',
        'selection' => '/controllers/admin/admission/selection.cont.php',
        'rejected' => '/controllers/admin/admission/rejected.cont.php',
        'parents' => '/controllers/admin/parent/parents.cont.php',
        'parents-old' => '/controllers/admin/parent/old_parents.cont.php',
        'employee' => '/controllers/admin/employee/employee.cont.php',
        'employee-old' => '/controllers/admin/employee/employee_old.cont.php',
        'icard_print' => '/controllers/admin/student/icard_print.cont.php',
        'students' => '/controllers/admin/student/student.cont.php',
        'quick-search' => '/controllers/admin/student/quicksearch.cont.php',
        'academic-add' => '/controllers/admin/exam/academic_add.cont.php',
        'exam-grades' => '/controllers/admin/exam/grade.cont.php',
        'question-bank' => '/controllers/admin/exam/question_bank.cont.php',
        'question-bank-import' => '/controllers/admin/exam/question_bank_import.cont.php',
        'assesments' => '/controllers/admin/exam/assesment.cont.php',
        'remarks' => '/controllers/admin/exam/remarks.cont.php',
        'activities' => '/controllers/admin/exam/activities.cont.php',
        'activities-assign' => '/controllers/admin/exam/activities_assign.cont.php',
        'co-scholastic-areas' => '/controllers/admin/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/admin/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/admin/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => '/controllers/admin/exam/academic_performance.cont.php',
        'enter-marks' => '/controllers/admin/exam/enter_marks.cont.php',
        'result' => '/controllers/admin/exam/result.cont.php',
        'subjectwise-result' => '/controllers/admin/exam/subjectwise_result.cont.php',
        'consolidated-report' => '/controllers/admin/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/admin/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/admin/exam/promoted_students.cont.php',
        'report-cards' => '/controllers/admin/exam/report_card.cont.php',
        'final-report' => '/controllers/admin/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/admin/exam/gradewise_list.cont.php',
        'health-data' => 'controllers/admin/exam/health_data.cont.php',
        'tptroutewise' => '/controllers/admin/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/admin/tpt/routes.cont.php',
        'tptstations' => '/controllers/admin/tpt/stations.cont.php',
        'tptfee' => '/controllers/admin/tpt/fee.cont.php',
        'attendances' => '/controllers/admin/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/admin/attendance/empattendance.cont.php',
        'term-attendances' => '/controllers/admin/attendance/term.cont.php',
        'month_attendances' => '/controllers/admin/attendance/month_attendance.cont.php',
        'users' => '/controllers/admin/users/users.cont.php',
        'sms' => '/controllers/admin/sms/sms.cont.php',
        'feevoucher' => '/controllers/admin/fee/voucher.cont.php',
        'm_receivable' => '/controllers/admin/fee/m_receivable.cont.php',
        'y_receivable' => '/controllers/admin/fee/y_receivable.cont.php',
        'detail_receivable' => '/controllers/admin/fee/detail_receivable.cont.php',
        'feevoucher-tpt' => '/controllers/admin/fee/voucher_tpt.cont.php',
        'feevoucher-without-tpt' => '/controllers/admin/fee/voucher_without_tpt.cont.php',
        'fee-structure' => '/controllers/admin/fee/structure.cont.php',
        'fee-detail' => '/controllers/admin/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/admin/fee/defaulters.cont.php',
        'fee-report' => '/controllers/admin/fee/fee_report.cont.php',
        'fee-report-monthly' => '/controllers/admin/fee/fee_report_monthly.cont.php',
        'fee-report-month-day' => '/controllers/admin/fee/fee_report_month_day.cont.php',
        'fee-summary' => '/controllers/admin/fee/summary.cont.php',
        'fee-report-export' => '/controllers/admin/fee/fee_report_export.cont.php',
        'fee-headwise' => '/controllers/admin/fee/headwise.cont.php',
        'fee-transaction' => '/controllers/admin/fee/fee_transaction.cont.php',
        'timetable-classwise' => '/controllers/admin/timetable/classwise.cont.php',
        'master-class' => '/controllers/admin/timetable/master_class.cont.php',
        'timetable-teachers' => '/controllers/admin/timetable/teacherswise.cont.php',
        'master-timetable' => '/controllers/admin/timetable/master.cont.php',
        'library' => '/controllers/admin/library/library.cont.php',
        'homework' => '/controllers/admin/homework/homework.cont.php',
        'hostels' => '/controllers/admin/hostel/hostel.cont.php',
        'hostelers' => '/controllers/admin/hostel/hostelers.cont.php',
        //fdgdf
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax' => '/controllers/ajax/fee.cont.php',
        'exam-load' => '/controllers/ajax/exam.cont.php',
        'exam-post' => '/controllers/ajax/post_exam.cont.php',
        'tpt-load' => '/controllers/ajax/tpt.cont.php',
        'tpt-post' => '/controllers/ajax/post_tpt.cont.php',
        'ajax-post' => '/controllers/ajax/post_fee.cont.php',
        'sms-post' => '/controllers/ajax/post_sms.cont.php',
        'sms-load' => '/controllers/ajax/sms.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'ajax-library-load' => '/controllers/library-load.cont.php',
        'ajax-library-post' => '/controllers/library-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'privileges' => '/controllers/privileges.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'school-reports' => '/controllers/admin/reports/school_reports.cont.php',
        'reports' => '/controllers/admin/reports/consolidate_report.cont.php',
        'headwise-feereports' => '/controllers/admin/reports/headwise_feereport.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'security' => '/controllers/admin/camara/security_cam.cont.php',
        'changepassword' => '/controllers/changepass.cont.php',
        'discounted-students' => '/controllers/admin/reports/discounted_student.cont.php',
        'opening-bal' => '/controllers/admin/reports/opening_bal.cont.php',
        'datesheet' => '/controllers/admin/exam/datesheet.cont.php',
        'datesheet-add' => '/controllers/admin/exam/datesheet_add.cont.php',
        'fee-report-dr' => '/controllers/admin/fee/fee_report_day.cont.php',
        'print-reciept' => '/controllers/admin/fee/print_reciept.cont.php',
        'student-stream' => '/controllers/admin/student/student_stream.cont.php',
        'sms-template' => '/controllers/admin/sms/sms_template.cont.php',
        'sms-keyword' => '/controllers/admin/sms/sms_keyword.cont.php',
        'test-report' => '/controllers/admin/exam/test_report.cont.php',
        'assign-transport' => '/controllers/admin/tpt/assign_transport.cont.php',
        'assign-discount' => '/controllers/admin/fee/assign_discount.cont.php',
        'edit-all-student' => '/controllers/admin/student/edit_students.cont.php',
        'all-student' => '/controllers/admin/student/classwise_student.cont.php',
        'chat_inbox' => '/controllers/chat/inbox.cont.php',
        'view-questions' => '/controllers/admin/exam/view_questions.cont.php',
        'password' => '/controllers/setpass.cont.php',
        'quick-receive' => '/controllers/admin/fee/fee_submit_all.cont.php',
    );
//        }
    }

// accountant  
else if (@$oCurrentUser->ulevel == '8')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'attendances' => '/controllers/admin/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/attendance/empattendance.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'term-attendances' => '/controllers/admin/attendance/term.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => '/controllers/admin/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/admin/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => '/controllers/admin/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/admin/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
        'password' => '/controllers/setpass.cont.php',
    );
    }

// clerck 
else if (@$oCurrentUser->ulevel == '7')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'attendances' => '/controllers/admin/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/attendance/empattendance.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => '/controllers/admin/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/admin/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => '/controllers/admin/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/admin/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'term-attendances' => '/controllers/admin/attendance/term.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
        'password' => '/controllers/setpass.cont.php',
    );
    }

//librarian
else if (@$oCurrentUser->ulevel == '5')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'term-attendances' => '/controllers/admin/attendance/term.cont.php',
        'attendances' => '/controllers/admin/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/attendance/empattendance.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => '/controllers/admin/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/admin/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => '/controllers/admin/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/admin/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
        'password' => '/controllers/setpass.cont.php',
    );
    }

//teacher 
else if (@$oCurrentUser->ulevel == '3')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'profile' => '/controllers/teacher/profile.cont.php',
        'class-timetable' => '/controllers/teacher/class_timetable.cont.php',
        //'timetable-teachers' => '/controllers/teacher/timetable_teachers.cont.php',
        'attendances' => '/controllers/admin/attendance/attendance.cont.php',
        'student_attendence' => '/attendances/today.inc.php',
        'academic-add' => '/controllers/admin/exam/academic_add.cont.php',
        'homework-assign' => '/controllers/teacher/assign_homework.cont.php',
        'homework-list' => '/controllers/teacher/homework_list.cont.php',
        'academic-performance' => '/controllers/teacher/academic_performance.cont.php',
//        'datesheet' => '/controllers/admin/exam/datesheet.cont.php',
        'datesheet-add' => '/controllers/admin/exam/datesheet_add.cont.php',
        'co-scholastic' => '/controllers/admin/exam/co_scholastic_marks.cont.php',
        'consolidated-report' => '/controllers/admin/exam/consolidated_report.cont.php',
        'health-data' => 'controllers/admin/exam/health_data.cont.php',
        'remarks' => '/controllers/admin/exam/remarks.cont.php',
        'exam-results' => '/controllers/teacher/exam_results.cont.php',
        'exam-schedule' => '/controllers/admin/exam/datesheet.cont.php',
        'term-attendance' => '/controllers/admin/attendance/term.cont.php',
//        'term-attendence' => '/controllers/teacher/term_attendence.cont.php',
        'salary-slips' => '/controllers/teacher/salary_slips.cont.php',
        'paid-salary' => '/controllers/teacher/paid_salary.cont.php',
        'apply-leave' => '/controllers/teacher/leave_application.cont.php',
        'leave-history' => '/controllers/teacher/leave_history.cont.php',
        'chat_inbox' => '/controllers/chat/inbox.cont.php',
        'password' => '/controllers/setpass.cont.php',
    );
    }

//parent
else if (@$oCurrentUser->ulevel == '2')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'myprofile' => '/controllers/student/profile.cont.php',
        'timetable' => '/controllers/student/timetable.cont.php',
        'myclassmates' => '/controllers/student/myclassmates.cont.php',
        'myteachers' => '/controllers/student/myteachers.cont.php',
        'attendance' => '/controllers/student/attendance.cont.php',
        'homework' => '/controllers/student/homework.cont.php',
        //'homework/add'=>'controllers/student/addhomework.cont.php',
        'feeaccount' => '/controllers/student/feeac.cont.php',
        'reportcard' => '/controllers/student/reportcard.cont.php',
        'hyap' => '/controllers/student/hyap.cont.php',
        'changepassword' => '/controllers/changepass.cont.php',
        'chat_inbox' => '/controllers/chat/inbox.cont.php',
        'password' => '/controllers/setpass.cont.php',
    );
    }

//student
else if (@$oCurrentUser->ulevel == '1')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'profile' => '/controllers/student/profile.cont.php',
        'timetable' => '/controllers/student/timetable.cont.php',
        'classmates' => '/controllers/student/classmates.cont.php',
        'teachers' => '/controllers/student/teachers.cont.php',
        'notification' => '/controllers/student/notification.cont.php',
        'attendance' => '/controllers/student/attendance.cont.php',
        'calendar' => '/controllers/student/calendar.cont.php',
        'library' => '/controllers/student/library.cont.php',
        'examination' => '/controllers/student/examination.cont.php',
        'assignment' => '/controllers/student/assignment.cont.php',
        'questionbank' => '/controllers/student/questionbank.cont.php',
        'noticeboard' => '/controllers/student/noticeboard.cont.php',
        'homework' => '/controllers/student/homework.cont.php',
        'exam-tips' => 'controllers/student/exam_tips.cont.php',
        'class-test-report' => 'controllers/student/class_test_report.cont.php',
        'term-assesment' => 'controllers/student/term_assesment.cont.php',
        'feeaccount' => '/controllers/student/feeac.cont.php',
        'reportcard' => '/controllers/student/reportcard.cont.php',
        'hyap' => '/controllers/student/hyap.cont.php',
        'changepassword' => '/controllers/changepass.cont.php',
        'chat_inbox' => '/controllers/chat/inbox.cont.php',
        'password' => '/controllers/setpass.cont.php',
    );
    }

// before login
else
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => 'controllers/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/admin/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => 'controllers/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
        'password' => '/controllers/setpass.cont.php',
    );
    }

# get the controller 'path to file' from the controller array
if ($sControllerRequest != "chat_test")
    {
    if (array_key_exists($sControllerRequest, $aControllers))
        {
        $sControllerPath = $aControllers[$sControllerRequest];
        }
    else
        {
        # Path found? GO
        if (empty($sControllerPath) && !empty($sControllerRequest))
            {
            # non existing controller request and page
            //showHttpError(404);
            $iErrorNr = 404;
            include_once DOCUMENT_ROOT . "/controllers/errors.cont.php";
            }
        }

    if (file_exists(DOCUMENT_ROOT . $sControllerPath))
        {
        include_once DOCUMENT_ROOT . $sControllerPath;
        }
    else
        {
        //showHttpError(404);
        $iErrorNr = 404;
        include_once DOCUMENT_ROOT . "/controllers/errors.cont.php";
        }
    }
if (DEBUG)
    {
    //echo "Time to load PHP: " . ($iEMT - $iSMT) . " sec";
    }
# save referrer for redirecting after login
if (http_get('controller') != 'account' && !(http_get('controller') == 'winkelwagen' && empty($_GET['param1'])))
    {
    $_SESSION['frontendLoginReferrer'] = getCurrentUrlPath(true, true);
    }
ob_flush();
if ($_GET['controller'] == "main-dash")
    {
    ?>                                                                                                                   <style>

        .content-wrapper, .right-side, .main-footer {
            -webkit-transition: -webkit-transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -moz-transition: -moz-transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -o-transition: -o-transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            transition: transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -webkit-transition: margin-left .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -o-transition: margin-left .3s cubic-bezier(.32, 1.25, .375, 1.15);
            transition: margin-left .3s cubic-bezier(.32, 1.25, .375, 1.15);
            margin-left: 230px;
            z-index: 820
        }
    </style>                             <?php

    }
else
    {
    ?> 
    <style>

        .content-wrapper, .right-side, .main-footer {
            -webkit-transition: -webkit-transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -moz-transition: -moz-transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -o-transition: -o-transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            transition: transform .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -webkit-transition: margin-left .3s cubic-bezier(.32, 1.25, .375, 1.15);
            -o-transition: margin-left .3s cubic-bezier(.32, 1.25, .375, 1.15);
            transition: margin-left .3s cubic-bezier(.32, 1.25, .375, 1.15);
            /*margin-left: 230px;*/
            z-index: 820
        }
    </style>  <?php }
?>                                   