<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Event Calendar | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Calendar'; 
$admission = new Admission();
$sParents = new Parents();
$type = http_get('param1');

if($type=='page'){
 $page = http_get('param2');
}else{
 $page = 1;
}
if(isset($_SESSION['r_per_page'])){
$records_per_page=$_SESSION['r_per_page'];
}else{
$records_per_page=RECORDS_PER_PAGE;
}

$eventsall = Master::get_events($MSID,'','',array('page'=>$page,'record_per_page'=>$records_per_page));
$totalrecords = $eventsall->rowCount();
$total_no_recrd = Master::get_events($MSID,'','all')->rowCount();

$links      = 3;

$Paginator  = new Paginator( $total_no_recrd, $records_per_page ,$page,'event-calender');

$pagination = $Paginator->createLinks( $links, 'pagination' );
$oPageLayout->sPagePath = PAGES_FOLDER . '/event_calender/event_calender.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>