
<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller for handeling the ajax pages post values
 * This is a very special controller that is included on other places beside the index
 */
//print_r($_POST);
//exit();
$id = http_get("param1");
$oDb = DBConnection::get();
$MSID = @$_POST['MSID'];
//print_r($_POST);
//pr($id);
if ($id == "del")
    {

    $r_id = http_get("param3");
//    print_r($r_id);
//    exit();
    $delete = Fee::delete_transections($r_id);

    exit();
    }
//else if ($id == "timetable_delete")
//    {
//    $del_time_tb = TimeTable::delete_timetb(http_get("param2"));
////    print_r($del_time_tb);
//    header("Refresh:0; url=".CLIENT_URL."/master-timetable");
////    header(CLIENT_URL);
//    }
else if (@$_POST['add_new_discount'] == 'true')
    {


    $MSID = $_POST['MSID'];
    $fee_details = Fee::get_feename($MSID, $_POST['id_to_pass'])->fetch(PDO::FETCH_OBJ);

//    print_r($fee_details);
//    exit();
    $id = -$_POST['id_to_pass'];
    $amt = -$_POST['fee_amt'];
//    try {
    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_billing (MSID, DueDate, SID, FeeName, FeeAmt, AcNo, SrNo, RSrNo,   FeeId, Class, FatherName ,Village, MobileSMS, House,type) VALUES  (:MSID, :DueDate, :SID, :FeeName, :FeeAmt , :AcNo, :SrNo, :RSrNo, :FeeId, :Class, :FatherName ,:Village, :MobileSMS, :House ,:type)');
    $status = $sql->execute(array(
        ':MSID' => $MSID,
        ':DueDate' => $fee_details->DueDate,
        ':SID' => $fee_details->SID,
        ':FeeName' => $_POST['fee_name'],
        ':FeeAmt' => $amt,
        ':AcNo' => $fee_details->AcNo,
        ':SrNo' => $fee_details->SrNo,
        ':RSrNo' => $fee_details->RSrNo,
        ':FeeId' => $id,
        ':Class' => $fee_details->Class,
        ':FatherName' => $fee_details->FatherName,
        ':Village' => $fee_details->Village,
        ':MobileSMS' => $fee_details->MobileSMS,
        ':House' => $fee_details->House,
        ':type' => $_POST['type']
    ));

//    print_r($sql);
//    exit();
//        if ($status) {
    echo 'success';
//            header(CLIENT_URL . '/ajax/fee_detail_headwise/');
    $message = new Messages();
    $message->add('s', 'Fine  added successfully!');
//        } else {
//            echo 'error';
//        }
//    } catch (PDOException $e) {
//        echo 'errorsss';
//    }
    }
else if (@$_POST['add_timetable'] == 'true')
    {

//    print_r($_POST);
//    exit();
    try
        {
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'time_tb (MSID, empid, Period, colour, days, Class, Section, Subject) VALUES  (:MSID, :empid, :Period, :colour, :days, :Class, :Section, :Subject)');

        $status = $sql->execute(array(
            ':MSID' => $MSID,
            ':empid' => $_POST['e_id'],
            ':Period' => $_POST['period'],
            ':colour' => $_POST['colour'],
            ':days' => implode(',', $_POST['days']),
            ':Class' => $_POST['class'],
            ':Section' => $_POST['section'],
            ':Subject' => $_POST['subject']
        ));
        if ($status)
            {
            echo 'success';
            $message = new Messages();
            $message->add('s', 'added successfully!');
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['add_locality'] == 'true')
    {

    $localName = $_POST['localName'];
//    print_r($_POST);


    try
        {
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'locality (MSID, name, postoffice, tehsil, district, state, pincode, created_date, status) VALUES  (:MSID, :name, :postoffice, :tehsil, :district, :state, :pincode, :created_date, :status)');

        $sql->execute(array(
            ':MSID' => $MSID,
            ':name' => $_POST['localName'],
            ':postoffice' => $_POST['postoffice'],
            ':state' => $_POST['state'],
            ':tehsil' => $_POST['tehsil'],
            ':district' => $_POST['district'],
            ':pincode' => $_POST['pincode'],
            ':created_date' => date('Y-m-d H:i:s'),
            ':status' => '1'
        ));
        $local_id = $oDb->lastInsertId();
        if ($local_id > 0)
            {
            echo '<option value="' . $local_id . '">' . $localName . '</option>';
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        //echo 'error';

        echo $e->getMessage();
        }
    }
else if (@$_POST['add_hostel'] == 'true')
    {
    if (empty($_POST['name']))
        {

        echo 'error';
        }
    else
        {
        try
            {

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'hostels (MSID, name) VALUES  (:MSID, :name )');

            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':name' => $_POST['name']
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Hostel added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_history'] == 'true')
    {
    try
        {
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'history (MSID, s_id, session, history, reward, warning, date, fine) VALUES  (:MSID, :s_id, :session, :history, :reward, :warning, :date, :fine)');

        $sql->execute(array(
            ':MSID' => $MSID,
            ':s_id' => $_POST['s_id'],
            ':session' => $_POST['session'],
            ':history' => $_POST['history'],
            ':reward' => $_POST['reward'],
            ':warning' => $_POST['warning'],
            ':date' => date('Y-m-d H:i:s'),
            ':fine' => $_POST['fine']
        ));
        if ($status)
            {
            echo 'success';
            $message = new Messages();
            $message->add('s', 'added successfully!');
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
//else if (@$_POST['timetable_delete'] == 'true')
//    {
////    print_r($_POST);
////    die()
//    $dataarr = array(
//        'id' => $_POST['id'],
//        'tablename' => 'time_tb',
//        'redirect' => CLIENT_URL . '/master-timetable',
//        'where' => 'id'
//    );
//    $deleterecored = General::delete($dataarr);
////    $del_time_tb = TimeTable::delete_timetb($_POST['id']);
//    if ($deleterecored)
//        {
//        $message = new Messages();
//        $message->add('s', 'Deleted successfully!');
//        echo 'success';
//        }
//    else
//        {
//        echo 'error';
//        }
//    }
else if (@$_POST['update_timetable'] == 'true')
    {


    if (@$_POST['days'])
        {


//    print_r($_POST);
//    exit();
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'time_tb SET empid = :empid,days = :days, colour = :colour, Subject = :Subject WHERE id = :id');
            $status = $sql->execute(array(
                ':empid' => $_POST['e_id'],
                ':days' => implode(',', $_POST['days']),
                ':Subject' => $_POST['subject'],
                ':id' => $_POST['id'],
                ':colour' => $_POST['colour']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'erroaaar';
                }
            }
        catch (PDOException $e)
            {
            echo 'errorz';
            }
        }
    else
        {
        echo 'error';
        }
//    if ($_POST['timetb_del'])
//        {
//        $del_time_tb = TimeTable::delete_timetb($_POST['id']);
//        }
    }
else if (@$_POST['update_remarks'] == 'true')
    {
//    print_r($_POST);
//    exit();

    try
        {
        $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'history SET history = :history,reward = :reward,warning = :warning,fine = :fine WHERE id = :id');
        $status = $sql->execute(array(
            ':history' => $_POST['history'],
            ':reward' => $_POST['reward'],
            ':warning' => $_POST['warning'],
            ':fine' => $_POST['fine'],
            ':id' => $_POST['id']
        ));
        if ($status)
            {
            $message = new Messages();
            $message->add('s', 'Updated successfully!');
            echo 'success';
            }
        else
            {
            echo 'erroaaar';
            }
        }
    catch (PDOException $e)
        {
        echo 'errorz';
        }
    }
else if (@$_POST['update_hostel'] == 'true')
    {
    if (empty($_POST['name']))
        {

        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'hostels SET name = :name WHERE id = :id');
            $status = $sql->execute(array(
                ':name' => $_POST['name'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_hostelers'] == 'true')
    {
    if (empty($_POST['s_id']) || empty($_POST['hostel_id']) || empty($_POST['from_date']))
        {
        echo 'error';
        }
    else
        {
        try
            {

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'hosteler (MSID, s_id, hostel_id,from_date) VALUES  (:MSID, :s_id,:hostel_id, :from_date )');

            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':s_id' => $_POST['s_id'],
                ':hostel_id' => $_POST['hostel_id'],
                ':from_date' => $_POST['from_date']
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Hosteler added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_hosteler'] == 'true')
    {
    if (empty($_POST['s_id']) || empty($_POST['hostel_id']) || empty($_POST['from_date']))
        {

        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'hosteler SET s_id = :s_id,hostel_id = :hostel_id, from_date=:from_date WHERE id = :id');
            $status = $sql->execute(array(
                ':s_id' => $_POST['s_id'],
                ':hostel_id' => $_POST['hostel_id'],
                ':from_date' => $_POST['from_date'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_failed_student'] == 'true')
    {

    if (empty($_POST['s_id']) || empty($_POST['date_result']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exams (MSID, s_id, date_result,result) VALUES  (:MSID,:s_id,:date_result,:result)');
            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':s_id' => $_POST['s_id'],
                ':date_result' => $_POST['date_result'],
                ':result' => $_POST['result'],
            ));
            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_failed_students'] == 'true')
    {
    if (empty($_POST['s_id']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exams SET s_id = :s_id  WHERE id = :id');
            $status = $sql->execute(array(
                ':s_id' => $_POST['s_id'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_assesments'] == 'true')
    {
    if (empty($_POST['title']) || empty($_POST['term']) || empty($_POST['max_marks']) || empty($_POST['for_class']))
        {
        echo 'error';
        }
    try
        {
        if ($_POST['title'] == "1")
            {
            $title = "FA1";
            $assesment_id = 1;
            }
        else if ($_POST['title'] == "2")
            {
            $title = "FA2";
            $assesment_id = 2;
            }
        else if ($_POST['title'] == "3")
            {
            $title = "FA3";
            $assesment_id = 3;
            }
        else if ($_POST['title'] == "4")
            {
            $title = "FA4";
            $assesment_id = 4;
            }
        else if ($_POST['title'] == "5")
            {
            $title = "SA1";
            $assesment_id = 5;
            }
        else if ($_POST['title'] == "6")
            {
            $title = "SA2";
            $assesment_id = 6;
            }
        $data = implode(",", $_POST['for_class']);
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_assesments (MSID, title, term, max_marks, class,assesment_id) VALUES  (:MSID,:title,:term, :max_marks , :class, :assesment_id )');
        $status = $sql->execute(array(
            ':MSID' => $MSID,
            ':title' => $title,
            ':term' => $_POST['term'],
            ':max_marks' => $_POST['max_marks'],
            ':class' => $data,
            ':assesment_id' => $assesment_id,
        ));
        if ($status)
            {
            echo 'success';
            $message = new Messages();
            $message->add('s', 'Assesment added successfully!');
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['add_co_scholastic_areas'] == 'true')
    {
    if (empty($_POST['title']) || empty($_POST['max_marks']) || empty($_POST['for_class']))
        {

        echo 'error';
        }
    elseif (is_numeric($_POST['max_marks']) && ($_POST['max_marks'] > 0 ))
        {
        try
            {
            $data = implode(",", $_POST['for_class']);

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_co_scholastic_areas (MSID, title, max_marks, class) VALUES  (:MSID, :title, :max_marks , :class )');

            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':title' => $_POST['title'],
                ':max_marks' => $_POST['max_marks'],
                ':class' => $data,
//                ':created_date' => date('Y-m-d H:i:s')
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Co - Scholastic - Area added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    else
        {
        echo 'error';
        }
    }
else if (@$_POST['add_exam_co_scholastic_marks'] == 'true')
    {
    if (empty($_POST['MSID']) || empty($_POST['id']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $i = 0;
            foreach ($_POST['co_scholastic'] as $data => $val)
                {
                $marks = Exam::get_exam_co_scholastic_marks($_POST['MSID'], '', array('selectAll' => 'true'), $_POST['id'], $_SESSION['year'], $data);
                $totalrecords_marks = $marks->rowCount();
                if ($totalrecords_marks > 0)
                    {

                    $existing_marks = $marks->fetch(PDO::FETCH_ASSOC);
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_co_scholastic_marks SET title = :title ,marks =:marks WHERE id = :id');
                    $upsql->execute(array(
                        ':title' => $_POST['title'][$i],
                        ':marks' => $_POST['marks'][$i],
                        ':id' => $existing_marks['id'],
                    ));
                    }
                else
                    {
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_co_scholastic_marks (MSID,co_scholastic_id,s_id,session, title,marks) VALUES  (:MSID,:co_scholastic_id,:s_id,:session, :title , :marks)');
                    $status = $sql->execute(array(
                        ':MSID' => $_POST['MSID'],
                        ':co_scholastic_id' => $data,
                        ':s_id' => $_POST['id'],
                        ':session' => $_SESSION['year'],
                        ':title' => $_POST['title'][$i],
                        ':marks' => $_POST['marks'][$i]
                    ));
                    }

                $i++;
                }
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Added successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_co_scholastic_indicators'] == 'true')
    {
    if (empty($_POST['grade']) || empty($_POST['description']) || empty($_POST['co_scholastic_id']))
        {
        echo 'error';
        }
    else
        {
        try
            {
//            $existing_Indictor = Exam::get_exam_co_scholastic_indicators($_POST['MSID'], '', $_POST['co_scholastic_id'], array('selectAll' => 'true'), $_POST['grade']);
//            $totalrecords_Indictor = $existing_Indictor->rowCount();
//            if ($totalrecords_Indictor > 0)
//                {
//
//                $existing_Indictor = $existing_Indictor->fetch(PDO::FETCH_ASSOC);
//                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_co_scholastic_indicators SET description = :description WHERE id = :id');
//                $status_update = $upsql->execute(array(
//                    ':description' => $_POST['description'],
//                    ':id' => $existing_Indictor['id']
//                ));
//                }
//            else
//                {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_co_scholastic_indicators (MSID,co_scholastic_id, grade,description) VALUES  (:MSID, :co_scholastic_id , :grade , :description)');
            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':co_scholastic_id' => $_POST['co_scholastic_id'],
                ':grade' => $_POST['grade'],
                ':description' => $_POST['description']
            ));
//                }
            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Co- scholastic- Indicator added successfully!');
                }
            elseif ($status_update)
                {
                $message = new Messages();
                $message->add('s', 'Co- scholastic- Indicator Updated successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_grade'] == 'true')
    {
//    die();

    if (empty($_POST['grade']) || empty($_POST['percent_from']) || empty($_POST['percent_to']) || empty($_POST['5_point_grade']) || empty($_POST['grade_point']) || empty($_POST['for_class']))
        {

        echo 'error';
        }
    else if ($_POST['percent_from'] > $_POST['percent_to'])
        {
        echo 'error';
        }
    else
        {
        try
            {
            $data = implode(",", $_POST['for_class']);

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_grades (MSID, grade, percent_from, percent_to,5_point_grade,grade_point,for_class,created_date) VALUES  (:MSID, :grade, :percent_from , :percent_to , :5_point_grade , :grade_point , :for_class, :created_date)');

            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':grade' => $_POST['grade'],
                ':percent_from' => $_POST['percent_from'],
                ':percent_to' => $_POST['percent_to'],
                ':5_point_grade' => $_POST['5_point_grade'],
                ':grade_point' => $_POST['grade_point'],
                ':for_class' => $data,
                ':created_date' => date('Y-m-d H:i:s')
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Grade added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_exam_health_data'] == 'true')
    {
//    print_r($_POST);
//    exit();
    if (empty($_POST['MSID']) || empty($_POST['id']))
        {
        echo 'error';
        }
    else
        {

        try
            {
            $bcg = (@$_POST['bcg_v']) ? $_POST['bcg_v'] : "off";
            $hepatitis_b = (@$_POST['hepatitis_b']) ? $_POST['hepatitis_b'] : "off";
            $dpt = (@$_POST['dpt']) ? $_POST['dpt'] : "off";
            $hb = (@$_POST['hb']) ? $_POST['hb'] : "off";
            $oral_polio = (@$_POST['oral_polio']) ? $_POST['oral_polio'] : "off";
            $hepatitis_a = (@$_POST['hepatitis_a']) ? $_POST['hepatitis_a'] : "off";
            $chickenpox = (@$_POST['chickenpox']) ? $_POST['chickenpox'] : "off";
            $dt_opa = (@$_POST['dt_opa']) ? $_POST['dt_opa'] : "off";
            $mmr = (@$_POST['mmr']) ? $_POST['mmr'] : "off";
            $measles = (@$_POST['measles']) ? $_POST['measles'] : "off";
            $dpt_opt_hb = (@$_POST['dpt_opt_hb']) ? $_POST['dpt_opt_hb'] : "off";
            $typhoid = (@$_POST['typhoid']) ? $_POST['typhoid'] : "off";

            $existing_data = Exam::get_exam_health_data($_POST['MSID'], '', array('selectAll' => 'true'), $_POST['id'], $_POST['year'], $_POST['term']);
            $totalrcd = $existing_data->rowCount();
            if ($totalrcd > 0)
                {

                $existing_health_datas = $existing_data->fetch(PDO::FETCH_ASSOC);
                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_health_data SET height= :height,weight= :weight,vision_l=:vision_l,vision_r= :vision_r,dental_hygiene=:dental_hygiene,ear_l=:ear_l,ear_r=:ear_r,nose=:nose,throat=:throat,pulse=:pulse,heart=:heart,alergy=:alergy,chronic_diease=:chronic_diease,physical_activity_problem=:physical_activity_problem,bcg_v=:bcg_v,hepatitis_b=:hepatitis_b,dpt=:dpt,hb=:hb,oral_polio=:oral_polio,measles=:measles,hepatitis_a=:hepatitis_a,chickenpox=:chickenpox, dt_opa=:dt_opa,mmr=:mmr,dpt_opt_hb=:dpt_opt_hb,typhoid=:typhoid,any_other=:any_other WHERE id = :id');
                $status_update = $upsql->execute(array(
                    ':height' => $_POST['height'],
                    ':weight' => $_POST['weight'],
                    ':vision_l' => $_POST['vision_l'],
                    ':vision_r' => $_POST['vision_r'],
                    ':dental_hygiene' => $_POST['dental_hygiene'],
                    ':ear_l' => $_POST['ear_l'],
                    ':ear_r' => $_POST['ear_r'],
                    ':nose' => $_POST['nose'],
                    ':throat' => $_POST['throat'],
                    ':pulse' => $_POST['pulse'],
                    ':heart' => $_POST['heart'],
                    ':alergy' => $_POST['alergy'],
                    ':chronic_diease' => $_POST['chronic_diease'],
                    ':physical_activity_problem' => $_POST['physical_activity_problem'],
                    ':bcg_v' => $bcg,
                    ':hepatitis_b' => $hepatitis_b,
                    ':dpt' => $dpt,
                    ':hb' => $hb,
                    ':oral_polio' => $oral_polio,
                    ':measles' => $measles,
                    ':hepatitis_a' => $hepatitis_a,
                    ':chickenpox' => $chickenpox,
                    ':dt_opa' => $dt_opa,
                    ':mmr' => $mmr,
                    ':dpt_opt_hb' => $mmr,
                    ':typhoid' => $typhoid,
                    ':any_other' => $_POST['any_other'],
                    ':id' => $existing_health_datas['id'],
                ));
                }
            else
                {
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_health_data (MSID,session,s_id,height,weight,vision_l,vision_r,dental_hygiene,ear_l,ear_r,nose,throat,pulse,heart,alergy,chronic_diease,physical_activity_problem,bcg_v,hepatitis_b,dpt,hb,oral_polio,measles,hepatitis_a,chickenpox,dt_opa,mmr,dpt_opt_hb,typhoid,any_other,term,class,section) VALUES (:MSID,:session,:s_id,:height,:weight,:vision_l,:vision_r,:dental_hygiene,:ear_l,:ear_r,:nose,:throat,:pulse,:heart,:alergy,:chronic_diease,:physical_activity_problem,:bcg_v, :hepatitis_b , :dpt ,:hb, :oral_polio , :measles , :hepatitis_a , :chickenpox , :dt_opa , :mmr , :dpt_opt_hb , :typhoid , :any_other , :term,:class,:section)');
//        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_health_data (MSID,session,s_id,height,weight,vision_l,vision_r,dental_hygiene,ear_l,ear_r,nose,throat,pulse,heart,alergy,chronic_diease,physical_activity_problem,bcg_v,hepatitis_b,dpt,hb,oral_polio,measles,hepatitis_a,chickenpox,dt_opa,mmr,dpt_opt_hb,typhoid,any_other,term) VALUES (:MSID,:session,:s_id,:height,:weight,:vision_l,:vision_r,:dental_hygiene,:ear_l,:ear_r,:nose,:throat,:pulse,:heart,:alergy,:chronic_diease,:physical_activity_problem,:bcg_v, :hepatitis_b , :dpt , :oral_polio , :measles , :hepatitis_a , :chickenpox , :dt_opa , :mmr , :dpt_opt_hb , :typhoid , :any_other , :term)');
                $status = $sql->execute(array(
                    ':MSID' => $_POST['MSID'],
                    ':session' => $_POST['year'],
                    ':s_id' => $_POST['id'],
                    ':height' => $_POST['height'],
                    ':weight' => $_POST['weight'],
                    ':vision_l' => $_POST['vision_l'],
                    ':vision_r' => $_POST['vision_r'],
                    ':dental_hygiene' => $_POST['dental_hygiene'],
                    ':ear_l' => $_POST['ear_l'],
                    ':ear_r' => $_POST['ear_r'],
                    ':nose' => $_POST['nose'],
                    ':throat' => $_POST['throat'],
                    ':pulse' => $_POST['pulse'],
                    ':heart' => $_POST['heart'],
                    ':alergy' => $_POST['alergy'],
                    ':chronic_diease' => $_POST['chronic_diease'],
                    ':physical_activity_problem' => $_POST['physical_activity_problem'],
                    ':bcg_v' => $bcg,
                    ':hepatitis_b' => $hepatitis_b,
                    ':dpt' => $dpt,
                    ':hb' => $hb,
                    ':oral_polio' => $oral_polio,
                    ':measles' => $measles,
                    ':hepatitis_a' => $hepatitis_a,
                    ':chickenpox' => $chickenpox,
                    ':dt_opa' => $dt_opa,
                    ':mmr' => $mmr,
                    ':dpt_opt_hb' => $mmr,
                    ':typhoid' => $typhoid,
                    ':any_other' => $_POST['any_other'],
                    ':term' => $_POST['term'],
                    ':class' => $_POST['class'],
                    ':section' => $_POST['section']
                ));
                }


            if (@$status_update)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                exit();
                }if (@$status)
                {
                $message = new Messages();
                $message->add('s', 'Added successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_exam_assesments'] == 'true')
    {
    if (empty($_POST['title']) || empty($_POST['term']) || empty($_POST['max_marks']) || empty($_POST['for_class']))
        {
        echo 'error';
        }
    try
        {


        if ($_POST['title'] == "1")
            {
            $title = "FA1";
            $assesment_id = 1;
            }
        else if ($_POST['title'] == "2")
            {
            $title = "FA2";
            $assesment_id = 2;
            }
        else if ($_POST['title'] == "3")
            {
            $title = "FA3";
            $assesment_id = 3;
            }
        else if ($_POST['title'] == "4")
            {
            $title = "FA4";
            $assesment_id = 4;
            }
        else if ($_POST['title'] == "5")
            {
            $title = "SA1";
            $assesment_id = 5;
            }
        else if ($_POST['title'] == "6")
            {
            $title = "SA2";
            $assesment_id = 6;
            }

        $data = implode(",", $_POST['for_class']);
        $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_assesments SET assesment_id = :assesment_id  ,title = :title,term = :term,max_marks = :max_marks,class = :class WHERE id = :id');
        $status = $sql->execute(array(
            ':title' => $title,
            ':assesment_id' => $assesment_id,
            ':term' => $_POST['term'],
            ':max_marks' => $_POST['max_marks'],
            ':class' => $data,
            ':id' => $_POST['id']
        ));
        if ($status)
            {
            $message = new Messages();
            $message->add('s', 'Updated successfully!');
            echo 'success';
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['update_exam_co_scholastic_areas'] == 'true')
    {
    if (empty($_POST['title']) || empty($_POST['max_marks']) || empty($_POST['for_class']))
        {

        echo 'error';
        }
    elseif (is_numeric($_POST['max_marks']) && ($_POST['max_marks'] > 0 ))
        {

        try
            {
            $data = implode(",", $_POST['for_class']);
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_co_scholastic_areas SET title = :title,max_marks = :max_marks,class = :class WHERE id = :id');
            $status = $sql->execute(array(
                ':title' => $_POST['title'],
                ':max_marks' => $_POST['max_marks'],
                ':class' => $data,
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    else
        {
        echo 'error';
        }
    }
else if (@$_POST['update_exam_co_scholastic_indicators'] == 'true')
    {
    if (empty($_POST['grade']) || empty($_POST['description']) || empty($_POST['co_scholastic_id']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_co_scholastic_indicators SET co_scholastic_id = :co_scholastic_id,grade = :grade,description = :description WHERE id = :id');
            $status = $sql->execute(array(
                ':co_scholastic_id' => $_POST['co_scholastic_id'],
                ':grade' => $_POST['grade'],
                ':description' => $_POST['description'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_exam_grade'] == 'true')
    {
    if (empty($_POST['grade']) || empty($_POST['percent_from']) || empty($_POST['percent_to']) || empty($_POST['5_point_grade']) || empty($_POST['grade_point']) || empty($_POST['for_class']))
        {

        echo 'error';
        }
    else if ($_POST['percent_from'] > $_POST['percent_to'])
        {
        echo 'error';
        }
    else
        {
        try
            {
            $data = implode(",", $_POST['for_class']);
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_grades SET grade = :grade,percent_from = :percent_from,percent_to = :percent_to,5_point_grade = :5_point_grade,grade_point = :grade_point,for_class = :for_class WHERE id = :id');
            $status = $sql->execute(array(
                ':grade' => $_POST['grade'],
                ':percent_from' => $_POST['percent_from'],
                ':percent_to' => $_POST['percent_to'],
                ':5_point_grade' => $_POST['5_point_grade'],
                ':grade_point' => $_POST['grade_point'],
                ':for_class' => $data,
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_fee_names'] == 'true')
    {//used in edit school fee group name
    if (empty($_POST['grade']) || empty($_POST['MSID']) || empty($_POST['percent_from']) || empty($_POST['percent_to']) || empty($_POST['5_point_grade']) || empty($_POST['grade_point']) || empty($_POST['for_class']))
        {
        echo 'error';
        $data = implode(",", $_POST['for_class']);
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_names SET MSID = :MSID, grade = :grade, percent_from = :percent_from, percent_to = :percent_to, 5_point_grade = :5_point_grade, grade_point = :grade_point, for_class = :for_class WHERE id = :id');
            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':grade' => $_POST['grade'],
                ':percent_from' => $_POST['percent_from'],
                ':percent_to' => $_POST['percent_to'],
                ':5_point_grade' => $_POST['5_point_grade'],
                ':grade_point' => $_POST['grade_point'],
                ':for_class' => $data,
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_department'] == 'true')
    {
    $depName = $_POST['dept_name'];
    try
        {
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'department (dept_name) VALUES (:dept_name)');
        $status = $sql->execute(array(
            ':dept_name' => $depName
        ));

        //echo $status;
        $dept_id = $oDb->lastInsertId();
        if ($dept_id > 0)
            {
            echo '<option value="' . $depName . '">' . $depName . '</option>';
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        //echo 'error';
        echo $e->getMessage();
        }
    }
else if (@$_POST['add_designation'] == 'true')
    {
    $designationName = $_POST['designame'];
    try
        {
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'designation (name) VALUES (:name)');

        $sql->execute(array(
            ':name' => $designationName
        ));
        $des_id = $oDb->lastInsertId();
        if ($des_id > 0)
            {
            echo '<option value="' . $designationName . '">' . $designationName . '</option>';
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['add_admission'] == 'true')
    {
    $adm_no = $_POST['adm_no'];
    $st_id = $_POST['st_id'];
    try
        {
        $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET admno = :admno, status = :status WHERE student_id = :student_id');
        $status = $sql->execute(array(
            ':admno' => $adm_no,
            ':status' => '1',
            ':student_id' => $st_id
        ));
        if ($status)
            {
            echo 'success';
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['enrollmnt_selection'] == 'true')
    {
    if (isset($_POST['submitfrm']))
        {
        foreach ($_POST['student_ids'] as $val)
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET admno = :admno, section = :section, status = :status WHERE student_id = :student_id');
            $status = $sql->execute(array(
                ':admno' => $_POST['adm_no_' . $val],
                ':section' => $_POST['student_sec_' . $val],
                ':status' => '1',
                ':student_id' => $val
            ));
            }
        }
    else
        {
        foreach ($_POST['student_ids'] as $val)
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET status = :status WHERE student_id = :student_id');
            $status = $sql->execute(array(
                ':status' => '2',
                ':student_id' => $val
            ));
            }
        }
    }
else if (@isset($_POST['activity_flag']))
    {
    $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'activity_feed SET notify_flag = :notify_flag WHERE notify_flag = :flag');
    $changeflag = $sql->execute(array(
        ':notify_flag' => '1',
        ':flag' => '0'
    ));
    if ($changeflag)
        {
        echo 'success';
        }
    else
        {
        echo 'error';
        }
    }
else if (@$_POST['add_attendance'] == 'true')
    {
    try
        {
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'attendances (MSID, user_id, class_id, attendance_date, attendance, role, reason) VALUES  (:MSID, :user_id, :class_id, :attendance_date, :attendance, :role, :reason )');

        $sql->execute(array(
            ':MSID' => $MSID,
            ':user_id' => $_POST['user_id'],
            ':class_id' => $_POST['class_id'],
            ':attendance_date' => $_POST['date'],
            ':attendance' => $_POST['attendance'],
            ':role' => $_POST['role'],
            ':reason' => $_POST['reason'],
        ));
        $attendance_id = $oDb->lastInsertId();
        if ($attendance_id > 0)
            {
            echo 'success';
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['add_attendance_emp'] == 'true')
    {
    try
        {
        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'attendances (MSID, user_id, class_id, role, attendance_date, attendance, reason) VALUES  (:MSID, :user_id, :class_id, :role, :attendance_date, :attendance, :reason )');

        $sql->execute(array(
            ':MSID' => $MSID,
            ':user_id' => $_POST['user_id'],
            ':class_id' => '',
            ':role' => $_POST['role'],
            ':attendance_date' => $_POST['date'],
            ':attendance' => $_POST['attendance'],
            ':reason' => $_POST['reason'],
        ));
        $attendance_id = $oDb->lastInsertId();
        if ($attendance_id > 0)
            {
            echo 'success';
            }
        else
            {
            echo 'error';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['add_event'] == 'true')
    {
    try
        {
        if ($_POST['title'] != '' && $_POST['description'] != '' && $_POST['start_date'] != '')
            {
            $start_date = strtotime($_POST['start_date']);
            $end_date = strtotime($_POST['end_date']);
            if ($end_date < $start_date)
                {
                $end_date = $_POST['start_date'];
                }
            else
                {
                $end_date = $_POST['end_date'];
                }
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'events (MSID, title, description, url, color, startdate, enddate, created_date, status) VALUES  (:MSID, :title, :description, :url, :color, :startdate, :enddate, :created_date, :status )');

            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':title' => $_POST['title'],
                ':description' => $_POST['description'],
                ':url' => $_POST['url'],
                ':color' => $_POST['color'],
                ':startdate' => $_POST['start_date'],
                ':enddate' => $end_date,
                ':created_date' => date('Y-m-d H:i:s'),
                ':status' => '1'
            ));
            if ($status)
                {
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        else
            {
            echo 'empty';
            }
        }
    catch (PDOException $e)
        {
        echo 'error';
        }
    }
else if (@$_POST['fetch_event'] == 'true')
    {

    $events = array();
    $sql = "SELECT * FROM " . DB_PREFIX . "events";
    $sql .= " where MSID=" . $MSID;
    if (!empty($_POST['ID']))
        {
        $sql .= " AND id=" . $_POST['ID'];
        }
    $sql = $oDb->query($sql);
    if (!empty($_POST['ID']))
        {
        $fetch = $sql->fetch(PDO::FETCH_ASSOC);
        echo $fetch['description'];
        }
    else
        {

        while ($fetch = $sql->fetch())
            {
            $e = array();
            $e['id'] = $fetch['id'];
            $e['title'] = $fetch['title'];
            $e['start'] = $fetch['startdate'];
            if (strtotime($fetch['enddate']) != strtotime($fetch['startdate']))
                {
                $e['end'] = date('Y-m-d', strtotime($fetch['enddate']) + (3600 * 24));
                }
            $e['url'] = $fetch['url'];
            $e['allDay'] = true;
            $e['backgroundColor'] = $fetch['color'];
            $e['borderColor'] = $fetch['color'];

            array_push($events, $e);
            }
        echo json_encode($events);
        }
    }
else if (@$_POST['update_book'] == 'true')
    {
    if (empty($_POST['isbn']) || empty($_POST['title']) || empty($_POST['category_id']) || empty($_POST['author']) || empty($_POST['edition']) || empty($_POST['publisher']) || empty($_POST['copy_taken']) || empty($_POST['book_position']) || empty($_POST['shelf_no']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'book SET isbn = :isbn , title = :title,category_id = :category_id,author = :author,edition = :edition,publisher = :publisher,copy_taken = :copy_taken,book_position = :book_position,shelf_no = :shelf_no  WHERE id = :id');
            $status = $upsql->execute(array(
                ':isbn' => $_POST['isbn'],
                ':title' => $_POST['title'],
                ':category_id' => $_POST['category_id'],
                ':author' => $_POST['author'],
                ':edition' => $_POST['edition'],
                ':publisher' => $_POST['publisher'],
                ':copy_taken' => $_POST['copy_taken'],
                ':book_position' => $_POST['book_position'],
                ':shelf_no' => $_POST['shelf_no'],
                ':id' => $_POST['id']
            ));

            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_books_category'] == 'true')
    {
    if (empty($_POST['name']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'book_category SET name = :name  WHERE id = :id');
            $status = $upsql->execute(array(
                ':name' => $_POST['name'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_book'] == 'true')
    {
    if (empty($_POST['isbn']) || empty($_POST['title']) || empty($_POST['category_id']) || empty($_POST['author']) || empty($_POST['edition']) || empty($_POST['publisher']) || empty($_POST['copy_taken']) || empty($_POST['book_position']) || empty($_POST['shelf_no']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'book (MSID,isbn,title,category_id,author,edition,publisher,copy_taken,book_position,shelf_no) VALUES(:MSID,:isbn,:title,:category_id,:author,:edition,:publisher,:copy_taken,:book_position,:shelf_no)');
            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':isbn' => $_POST['isbn'],
                ':title' => $_POST['title'],
                ':category_id' => $_POST['category_id'],
                ':author' => $_POST['author'],
                ':edition' => $_POST['edition'],
                ':publisher' => $_POST['publisher'],
                ':copy_taken' => $_POST['copy_taken'],
                ':book_position' => $_POST['book_position'],
                ':shelf_no' => $_POST['shelf_no'],
            ));
            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Book  added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_books_category'] == 'true')
    {
    if (empty($_POST['MSID']) || empty($_POST['name']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'book_category (MSID, name) VALUES  (:MSID, :name)');
            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':name' => $_POST['name']
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Books Category  added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }

/* Transportation Update Record here */
else if (@$_POST['transport'] == 'true')
    {


    $student_tran = new Student();
    $student_id = $_POST['student_id'];

    $msid = $_POST['msid'];

    $stu_trans_info = $student_tran->get_stu_traninfo($msid, $student_id);

    $stu_trans_get = $stu_trans_info->fetch();

    //$stu_trans_date = $stu_trans_get['date_to'];

    $stu_tran_get_from_date = $stu_trans_get['date_from'];

    $current_date = $oCurrentUser->mydate;

    $stu_date_from = date('Y-m-d', strtotime($current_date . ' -1 day'));

    $stu_trans_id = $stu_trans_get['id'];

    /* echo "<pre>";
      print_r($_POST);
      echo "</pre>"; */

    //die("<>><<<");

    if ($stu_tran_get_from_date == $current_date)
        {

        // echo "Hi";
        //die("<>>");

        $del_tran = Transport:: stu_del_trans($msid, $stu_trans_id, $stu_tran_get_from_date);
        }
    // die("<>><<");
    //die("<>>")
    // echo $stu_trans_get['tpt_stn_id'];
    //echo $_POST['tpt'];
    if ($stu_trans_get['tpt_stn_id'] == $_POST['tpt'])
        {
        //echo "nHi";
        }
    else
        {
        //echo "Hi";

        try
            {




            $oDb = DBConnection::get();

            $sql_transport = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_std (MSID, S_id, tpt_stn_id,date_from, date_to, up, down) VALUES (:MSID, :S_id, :tpt_stn_id,:date_from,:date_to, :up, :down)');
            $current_date = $oCurrentUser->mydate;
            $cur_date = date('Y-m-01', strtotime($current_date));

            $sql_transport->execute(array(
                ':MSID' => $msid,
                ':S_id' => $student_id,
                ':tpt_stn_id' => $_POST['tpt'],
                ':date_from' => $cur_date,
                ':date_to' => '3000-12-31',
                ':up' => '0',
                ':down' => '0',
            ));
            }
        catch (PDOException $e)
            {
            echo $e->getMessage();
            }

        try
            {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_std SET date_to = :date_to  WHERE id = :id');
            $status = $upsql->execute(array(
                ':date_to' => $stu_date_from,
                ':id' => $stu_trans_id
            ));

//            $upsql1 = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET transportation = :transportation  WHERE student_id = :student_id');
//            $status1 = $upsql1->execute(array(
//                ':transportation' => $_POST['tpt'],
//                ':student_id' => $student_id
//            ));

            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $student_id);
            $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $student_id);
            }
        catch (PDOException $e)
            {
            // echo 'error';

            echo $e->getMessage();
            }
        }

    /* echo "<pre>";
      print_r($_POST);
      echo "<pre>"; */
    }
else if (@$_POST['del_transport'] == 'true')
    {



    $id = $_POST['id'];
    $s_id = $_POST['s_id'];
    $msid = $_POST['msid'];
    /* echo "<pre>";

      print_r($_POST);
      echo "</pre>"; */




    $del = Transport::stutran_del($msid, $id);

    $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $s_id);
    $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $s_id);


    if ($del)
        {
        echo "Success";
        }
    else
        {
        echo "Error!";
        }
    }
else if (@$_POST['del_discount'] == 'true')
    {



    $id = $_POST['id'];
    $s_id = $_POST['s_id'];
    $msid = $_POST['msid'];
    /* echo "<pre>";

      print_r($_POST);
      echo "</pre>"; */
    $del = Transport::stu_del_discounted_student($msid, $id);

    $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $s_id);
    $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $s_id);



    if ($del)
        {
        echo "Success";
        }
    else
        {
        echo "Error!";
        }
    }
else if (@$_POST['discount_update'] == 'true')
    {

//    print_r($_POST);
    $student_id = $_POST['student_id'];

    $msid = $_POST['msid'];

    $stu_trans_info = Transport::get_discounted_stu($msid, $student_id, $oCurrentUser->mydate);

    $stu_trans_get = $stu_trans_info->fetch();

    //$stu_trans_date = $stu_trans_get['date_to'];

    $stu_tran_get_from_date = $stu_trans_get['date_from'];

    $current_date = $oCurrentUser->mydate;

    $stu_date_from = date('Y-m-d', strtotime($current_date . ' -1 day'));

    $stu_trans_id = $stu_trans_get['id'];


    if ($stu_tran_get_from_date == $current_date)
        {

        // echo "Hi";
        //die("<>>");

        $del_tran = Transport:: stu_del_discounted_student($msid, $stu_trans_id, $stu_tran_get_from_date);
        }
    // die("<>><<");
    //die("<>>")
    // echo $stu_trans_get['tpt_stn_id'];
    //echo $_POST['tpt'];
    if ($stu_trans_get['discount_id'] == $_POST['discount_select'])
        {
        //echo "nHi";
        }
    else
        {
        //echo "Hi";

        try
            {

            $oDb = DBConnection::get();

            $sql_transport = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'discounted_student (MSID, S_id, discount_id, date_from, date_to) VALUES (:MSID, :S_id, :discount_id, :date_from, :date_to)');
            $current_date = $oCurrentUser->mydate;
            $cur_date = date('Y-m-01', strtotime($current_date));

            $sql_transport->execute(array(
                ':MSID' => $msid,
                ':S_id' => $student_id,
                ':discount_id' => $_POST['discount_select'],
                ':date_from' => $cur_date,
                ':date_to' => '3000-12-31'
            ));
            }
        catch (PDOException $e)
            {
            echo $e->getMessage();
            }

        try
            {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'discounted_student SET date_to = :date_to  WHERE id = :id');
            $status = $upsql->execute(array(
                ':date_to' => $stu_date_from,
                ':id' => $stu_trans_id
            ));

            /* $upsql1 = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET discount = :discount  WHERE student_id = :student_id');
              $status1 = $upsql1->execute(array(
              ':discount' => $_POST['discount_select'],
              ':student_id' => $student_id
              )); */

            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $student_id);
            $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $student_id);
            }
        catch (PDOException $e)
            {
            echo 'error';

            echo $e->getMessage();
            }
        }
    }
else if (@$_POST['add_exams'] == 'true')
    {

    $student_id = $_POST['student_id'];
    $exam_result = $_POST['exam_result'];
    $msid = $_POST['msid'];



    try
        {




        $oDb = DBConnection::get();

        $sql_transport = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exams (MSID, s_id, date_result,result) VALUES (:MSID, :s_id, :date_result, :result)');

        $sql_transport->execute(array(
            ':MSID' => $msid,
            ':s_id' => $student_id,
            ':date_result' => $_POST['date_result'],
            ':result' => $exam_result
        ));

        $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $student_id);
        $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $student_id);

        echo "Success";
        }
    catch (PDOException $e)
        {
        echo $e->getMessage();
        }
    }
else if (@$_POST['del_exam'] == 'true')
    {

    $id = $_POST['id'];
    $msid = $_POST['msid'];

    try
        {

        $oDb = DBConnection::get();
        $upsql = $oDb->prepare("Delete FROM `ms_exams` where `id`='$id' AND `MSID`='$msid'");
//            print_r($upsql);
        $upsql->execute();

//            $sql = $oDb->query($sql);
        return $upsql;
        }
    catch (PDOException $e)
        {
        $message = new Messages();
        $message->add('e', $e->getMessage());
        }
    }



/* * ***********   =================  Student Transport Edit Section =================  */
else if (@$_POST['trans_edit'] == 'true')
    {
    //$student_tran = new Student();



    $student_id = $_POST['student_id'];

    $msid = $_POST['msid'];





    //$stu_trans_info = $student_tran->get_stu_traninfo($msid, $student_id);
    //$stu_trans_get = $stu_trans_info->fetch();
    //$stu_trans_date = $stu_trans_get['date_to'];

    $stu_tran_get_from_date = $_POST['date_from'];

    $current_date = $oCurrentUser->mydate;

    //$stu_date_from = date('Y-m-d', strtotime($current_date . ' -1 day'));


    $stu_date_to = $_POST['date_to'];

    $stu_trans_id = $_POST['trans_id'];



    /* echo "<pre>";
      print_r($_POST);
      echo "</pre>"; */

    //die("<>><<<");

    /* if ($stu_tran_get_from_date <= $current_date ) 
      {



      //echo "hi";   // echo "Hi";
      //die("<>>");

      //$del_tran = Transport:: stu_del_trans($msid, $stu_trans_id, $stu_tran_get_from_date);
      } */


    // die("<>><<");
    //die("<>>")
    // echo $stu_trans_get['tpt_stn_id'];
    //echo $_POST['tpt'];
    /* else { */

    //echo "Hi";


    try
        {
        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_std SET tpt_stn_id = :tpt_stn_id, date_from = :date_from, date_to = :date_to  WHERE id = :id');
        $status = $upsql->execute(array(
            ':tpt_stn_id' => $_POST['tpt'],
            ':date_from' => $stu_tran_get_from_date,
            ':date_to' => $stu_date_to,
            ':id' => $stu_trans_id
        ));



        if ($status)
            {
            $message = new Messages();
            $message->add('s', 'Updated successfully!');
            echo 'success';
            }
        else
            {
            echo 'error';
            }
        $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $student_id);
        $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $student_id);
        }
    catch (PDOException $e)
        {
        // echo 'error';

        echo $e->getMessage();
        }
    /* } */
    }


/* * *********    ==================  End Here  ==================================  */
else if (@$_POST['discount_edit'] == 'true')
    {


    $student_id = $_POST['student_id'];

    $msid = $_POST['msid'];





    //$stu_trans_info = $student_tran->get_stu_traninfo($msid, $student_id);
    //$stu_trans_get = $stu_trans_info->fetch();
    //$stu_trans_date = $stu_trans_get['date_to'];

    $stu_discount_get_from_date = $_POST['date_from'];

    $current_date = $oCurrentUser->mydate;

    //$stu_date_from = date('Y-m-d', strtotime($current_date . ' -1 day'));


    $stu_date_to = $_POST['date_to'];

    $discount_id = $_POST['discount_id'];



    /* echo "<pre>";
      print_r($_POST);
      echo "</pre>"; */

    //die("<>><<<");

    /* if ($stu_tran_get_from_date <= $current_date ) 
      {



      //echo "hi";   // echo "Hi";
      //die("<>>");

      //$del_tran = Transport:: stu_del_trans($msid, $stu_trans_id, $stu_tran_get_from_date);
      } */


    // die("<>><<");
    //die("<>>")
    // echo $stu_trans_get['tpt_stn_id'];
    //echo $_POST['tpt'];
    /* else { */

    //echo "Hi";


    try
        {
        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'discounted_student SET discount_id = :discount_id, date_from = :date_from, date_to = :date_to  WHERE id = :id');
        $status = $upsql->execute(array(
            ':discount_id' => $_POST['dis_count'],
            ':date_from' => $stu_discount_get_from_date,
            ':date_to' => $stu_date_to,
            ':id' => $discount_id
        ));



        if ($status)
            {
            $message = new Messages();
            $message->add('s', 'Updated successfully!');
            echo 'success';
            }
        else
            {
            echo 'error';
            }

        $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $student_id);
        $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $student_id);
        }
    catch (PDOException $e)
        {
        // echo 'error';

        echo $e->getMessage();
        }
    }
else if (@$_POST['hostel_data'] == 'true')
    {
    // $student_tran = new Student();
    $student_id = $_POST['student_id'];

    $msid = $_POST['msid'];

    $my_date = $oCurrentUser->mydate;

    $hostel_stu_data = Hostel::get_stu_hostel_data($msid, $student_id, $my_date)->fetch();

    //$stu_trans_date = $stu_trans_get['date_to'];

    $stu_tran_get_from_date = $hostel_stu_data['from_date'];

    $current_date = $oCurrentUser->mydate;

    $stu_date_from = date('Y-m-d', strtotime($current_date . ' -1 day'));

    $stu_trans_id = $hostel_stu_data['id'];

    /* echo "<pre>";
      print_r($_POST);
      echo "</pre>"; */

    //die("<>><<<");

    if ($stu_tran_get_from_date == $current_date)
        {

        // echo "Hi";
        //die("<>>");

        $del_tran = Hostel:: stu_del_hostel($msid, $stu_trans_id, $stu_tran_get_from_date);
        }
    // die("<>><<");
    //die("<>>")
    // echo $stu_trans_get['tpt_stn_id'];
    //echo $_POST['tpt'];
    if ($hostel_stu_data['hostel_id'] == $_POST['hostel'])
        {
        //echo "nHi";
        }
    else
        {
        //echo "Hi";

        try
            {




            $oDb = DBConnection::get();

            $sql_transport = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'hosteler (MSID,s_id,hostel_id,from_date,to_date) VALUES (:MSID, :s_id, :hostel_id, :from_date, :to_date)');
            $current_date = $oCurrentUser->mydate;
            $cur_date = date('Y-m-01', strtotime($current_date));

            $sql_transport->execute(array(
                ':MSID' => $msid,
                ':s_id' => $student_id,
                ':hostel_id' => $_POST['hostel'],
                ':from_date' => $cur_date,
                ':to_date' => '3000-12-31',
            ));
            }
        catch (PDOException $e)
            {
            echo $e->getMessage();
            }

        try
            {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'hosteler SET to_date = :to_date  WHERE id = :id');
            $status = $upsql->execute(array(
                ':to_date' => $stu_date_from,
                ':id' => $stu_trans_id
            ));

            /* $upsql1 = $oDb->prepare('UPDATE ' . DB_PREFIX . 'students SET transportation = :transportation  WHERE student_id = :student_id');
              $status1 = $upsql1->execute(array(
              ':transportation' => $_POST['tpt'],
              ':student_id' => $student_id
              )); */

            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }

            $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $student_id);
            $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $student_id);
            }
        catch (PDOException $e)
            {
            // echo 'error';

            echo $e->getMessage();
            }
        }
    }
else if (@$_POST['del_hostel'] == 'true')
    {



    $id = $_POST['id'];
    $s_id = $_POST['s_id'];
    $msid = $_POST['msid'];
    /* echo "<pre>";

      print_r($_POST);
      echo "</pre>"; */




    $del = Hostel::stuhostel_del($msid, $id);
    $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $s_id);
    $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $s_id);
//    $Delete = Fee::get_delete_student_from_fee_billing($msid, $_POST['acno'], $_POST['session']);
//    $data_insert = Fee::insert_student_into_fee_billing($msid, $_POST['acno']);

    if ($del)
        {
        echo "Success";
        }
    else
        {
        echo "Error!";
        }
    }
else if (@$_POST['hostel_edit'])
    {

    $student_id = $_POST['student_id'];

    $msid = $_POST['msid'];





    //$stu_trans_info = $student_tran->get_stu_traninfo($msid, $student_id);
    //$stu_trans_get = $stu_trans_info->fetch();
    //$stu_trans_date = $stu_trans_get['date_to'];

    $stu_tran_get_from_date = date("Y-m-d", strtotime($_POST['date_from']));

    $current_date = $oCurrentUser->mydate;

    //$stu_date_from = date('Y-m-d', strtotime($current_date . ' -1 day'));


    $stu_date_to = date("Y-m-d", strtotime($_POST['date_to']));

    $stu_trans_id = $_POST['hostel_id'];



    /* echo "<pre>";
      print_r($_POST);
      echo "</pre>"; */

    //die("<>><<<");

    /* if ($stu_tran_get_from_date <= $current_date ) 
      {



      //echo "hi";   // echo "Hi";
      //die("<>>");

      //$del_tran = Transport:: stu_del_trans($msid, $stu_trans_id, $stu_tran_get_from_date);
      } */


    // die("<>><<");
    //die("<>>")
    // echo $stu_trans_get['tpt_stn_id'];
    //echo $_POST['tpt'];
    /* else { */

    //echo "Hi";


    try
        {
        $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'hosteler SET hostel_id = :hostel_id, from_date = :from_date, to_date = :to_date  WHERE id = :id');
        $status = $upsql->execute(array(
            ':hostel_id' => $_POST['hostel'],
            ':from_date' => $stu_tran_get_from_date,
            ':to_date' => $stu_date_to,
            ':id' => $stu_trans_id
        ));



        if ($status)
            {
            $message = new Messages();
            $message->add('s', 'Updated successfully!');
            echo 'success';
            }
        else
            {
            echo 'error';
            }
//        $Delete = Fee::get_delete_student_from_fee_billing($msid, $_POST['acno'], $_POST['session']);
//        $data_insert = Fee::insert_student_into_fee_billing($msid, $_POST['acno']);
        }
    catch (PDOException $e)
        {
        // echo 'error';

        echo $e->getMessage();
        }
    }
else if (@$_POST['edit_holday'] == 'true')
    {
    if (strtotime($_POST['date_from']) > strtotime($_POST['date_to']) || $_POST['holiday_name'] == "")
        {
        echo 'error';
        }
    else
        {


        $date_from = date('Y-m-d', strtotime($_POST['date_from']));
        $date_to = date('Y-m-d', strtotime($_POST['date_to']));

        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'holidays  SET MSID = :MSID, ID = :ID, DateFrom = :DateFrom, DateTo = :DateTo, Particular = :Particular,colour =:colour WHERE holiday_id = :holiday_id');


            $sql->execute(array(
                ':MSID' => $_POST['msid'],
                ':ID' => $_POST['ID'],
                ':DateFrom' => $date_from,
                ':DateTo' => $date_to,
                ':Particular' => $_POST['holiday_name'],
                ':colour' => $_POST['colour'],
                ':holiday_id' => $_POST['holiday_id']
            ));
            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            //echo 'error';

            echo $e->getMessage();
            }
        }
    }
else if (@$_POST['del_holiday'] == true)
    {

    echo "<pre>";

    print_r($_POST);

    echo "</pre>";
    }
?>