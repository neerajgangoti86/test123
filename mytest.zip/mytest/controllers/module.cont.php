<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */
# make pageLayout Object
$oPageLayout = new PageLayout();

$sRole = new Role();
$oPageLayout->sWindowTitle = 'Modules | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Configuration';
$sMaster = new Master();
$type = http_get('param1');
if ($type == 'add')
    {
    $oPageLayout->sWindowTitle = 'Add New Role | ' . CLIENT_NAME;

    if (isset($_POST['roleadd']))
        {
//      print_r($_FILES); 
//      exit();
        $sRole->add_module('', $_POST);
        }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/module-register.inc.php';
    }
else if ($type == 'edit')
    {

    $oPageLayout->sWindowTitle = 'Edit Modules | ' . CLIENT_NAME;
    $id = http_get('param2');
    $role = Role::get_modules($id);
    $roles = Role::get_modules($id)->fetch();


//    $count_data = $role->rowCount();
//    if ($count_data > 0)
//        {
//        $get_columns = $roles->fetch();
//        $fields = json_decode($get_columns['privilege_id'], true);
//        $selected_modules = array();
//        if (@$fields)
//            {
//            foreach ($fields as $k => $val)
//                {
//                $selected_module[] = $val;
//                }
//            }
//        }
//    print_r($selected_module);
    if (isset($_POST['roleupdate']))
        {
        $sRole->add_module($id, $_POST);
        }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/module-edit.inc.php'; // special home page
//    $sGeneral = new General();
//    $id = http_get('param2');
//    $state = http_get('param3');
//    $new_state = ($state == '1') ? 0 : 1;
//    $dataarr = array(
//        'id' => $id,
//        'tablename' => 'modules ',
//        'redirect' => CLIENT_URL . '/modules',
//        'where' => 'id',
//        'status' => $new_state
//    );
//    $changeback = $sGeneral->activate_deactivate($dataarr);
    }
else
    {
    if ($type == 'delete')
        {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id))
            {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'modules',
                'redirect' => CLIENT_URL . '/modules',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
            }
        }

    if ($type == 'page')
        {
        $page = http_get('param2');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }
//print_r($records_per_page);
//print_r($page);
    $modules = Master::get_modules('', '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $modules->rowCount();
    $total_no_recrd = Master::get_modules('', '')->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'modules');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/module.inc.php'; // special home page
# include the main template
    }
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>