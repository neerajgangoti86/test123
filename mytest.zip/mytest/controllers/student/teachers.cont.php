<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}  
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'My Teachers | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
 
$currentPage = 'My Classmates'; 

if($oCurrentUser->ulevel == '2'){
$ids = explode("P", $oCurrentUser->myuid);
$parentid = $ids[1];
$getstudent = Parents::get_childrens($parentid, $oCurrentUser->mydate);
$student = $getstudent->fetch();
$employee = array();
$getChildren = Student::get_students($student['uid'], '1', $student['student_id']); 
$children = $getChildren->fetch();

}
else 
{ 
    $ids = explode("S", $oCurrentUser->myuid);
    $id =$ids[1];
    $getChildren = Student::get_students($oCurrentUser->myuid, '1', $id);
    $children = $getChildren->fetch();
    //pr($children);
    if(empty($childern)): $emptyResult = "No Record Exists."; endif;
}

$oPageLayout->sPagePath = PAGES_FOLDER . '/student_level/teachers.inc.php'; // special home page

 
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>