<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Question Bank | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';

/*
 * Get Student
 */
$studentids = explode('S', $oCurrentUser->myuid);
$studentId = $studentids[1];
$student = Student::get_students($oCurrentUser->myuid, '1', $studentId)->fetch(PDO::FETCH_ASSOC);
$selectedClass = $student['class'];
/*
 * Get Week Start - End Date
 */
$CurrentDate = $oCurrentUser->mydate;
$year = date('Y', strtotime($CurrentDate));
$date = new DateTime($CurrentDate);
$WeekNumber = $date->format("W");



$monthYear = date('F', strtotime($CurrentDate)) . ' ' . date('Y', strtotime($CurrentDate));
$YearMonth = strtotime($monthYear);
$StartDate = date('Y-m-01', $YearMonth);
$EndDate = date('Y-m-t', $YearMonth);
$rTypeM = 'selected ="selected"';
$data = array('class' => $selectedClass);
$Student = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);

$getSubject = Student::get_student_test_subject($MSID, '', $StartDate, $EndDate, $oCurrentUser->mysession, $studentId);
$getDate = Student::get_student_test_subject($MSID, '', $StartDate, $EndDate, $oCurrentUser->mysession, $studentId);


$oPageLayout->sPagePath = PAGES_FOLDER . '/student_level/class_test_report.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>