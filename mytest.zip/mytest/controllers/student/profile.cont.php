<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}  
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'My Profile | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
 
$currentPage = 'Admin'; 
$sActivityFeed = new ActivityFeed(); 
$type = http_get('param1');

$activityfeed = ActivityFeed::get_activity_feeds($MSID);

$oPageLayout->sPagePath = PAGES_FOLDER . '/student_level/profile.inc.php'; // special home page


# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>