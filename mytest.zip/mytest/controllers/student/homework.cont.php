<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}  
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Home Work | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
 



//$data = array('class' => $student['class']);



$currentPage = 'My Classmates'; 

$oPageLayout->sPagePath = PAGES_FOLDER . '/student_level/homework.inc.php'; // special home page


# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>

<!--Main PHP code for student homework -->

