<?php
# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");
$oDb = DBConnection::get();
/*
 * this part used for enrolled form page to list/select existing parents
 */
if ($content == 'list')
    {

    if (isset($_POST["page"]))
        {
        $page = $_POST["page"];
        }
    else
        {
        $page = 1;
        }

    if (isset($_POST['r_per_page']))
        {
        $records_per_page = $_POST['r_per_page'];
        }
    else
        {
        $records_per_page = 10;
        }
//    print_r($_POST);
//    exit();
//    
    $parents = Parents::get_parents($MSID, '', '', array('page' => $page, 'record_per_page' => $records_per_page, 'f_name' => @$_POST['f_name']));

    //print_r($parents);

    $totalrecords = $parents->rowCount();
    $total_no_recrd = Parents::get_parents($MSID, '', 'all', array('f_name' => @$_POST['f_name']))->rowCount();
    $total_pages = ceil($total_no_recrd / $records_per_page);
    ?>
    <div id="results"><!-- content will be loaded here -->

        <form id="parent_form" name="parent_form">
            <table class="table table-hover">
                <thead style="background:#ddd;">

                    <tr>
                        <th><input type="text" class="form-control" id="fnamefilter" name="fnamefilter" value="<?= @$_POST['f_name']; ?>" autofocus="autofocus"></th>

                        <th>
                            <input type="submit" name="form_submit" id="submit_form" class="x btn btn-primary" value="Search"/>

                        </th>

                    </tr>
                    <tr>
                        <th>Father Name</th>
                        <th>Mother Name</th>
                        <th>Mobile 4 SMS</th>
                        <th>Locality</th>

                        <th>Action</th>
                    </tr>
                </thead>

                <?php
                if ($totalrecords > 0)
                    {
                    while ($rowv = $parents->fetch())
                        {

                        // print_r()
                        // $local_get =  Master::get_locality($MSID, $rowv['village']);
                        // print_r($local_get);
                        $local = Master::get_locality_new2($MSID, $rowv['village'])->fetch();

                        //print_r($local);
                        // print_r($local);
                        //$counts = Student::get_std_count($MSID, $rowv['id'])->fetch();

                        $display = Parents::get_children($rowv['id']);
                        ?>
                        <tr>
                            <td><?= $rowv['f_name']; ?></td>
                            <td><?= $rowv['m_name']; ?></td>
                            <td><?= $rowv['mobile_sms']; ?></td>
                            <td><?= $local['name']; ?>

                            <td><a class="text-light-blue ajaxselect" title="select" data-feebook="<?= $account_no ?>" data-id="<?= $rowv['id']; ?>" href="javascript:;" data-fname="<?= $rowv['f_name']; ?>" data-mname="<?= $rowv['m_name']; ?>" data-fquali="<?= $rowv['f_qualification']; ?>" data-foccu="<?= $rowv['f_occupation']; ?>" data-fmobile="<?= $rowv['f_mobile']; ?>" data-mquali="<?= $rowv['m_qualification']; ?>" data-moccu="<?= $rowv['m_occupation']; ?>" data-mmobile="<?= $rowv['m_mobile']; ?>" data-category="<?= $rowv['category']; ?>" data-addline1="<?= $rowv['address_line1']; ?>" data-addline2="<?= $rowv['address_line2']; ?>" data-aincome="<?= $rowv['annual_income']; ?>" data-msms="<?= $rowv['mobile_sms']; ?>" data-local="<?= $rowv['village']; ?>" data-localname="<?= $local['name'] ?>" data-landline="<?= $rowv['phone_home']; ?>" data-padd="<?= $rowv['address']; ?>" data-religion="<?= $rowv['religion']; ?>">Select</a></td>
                        </tr>
                        <?php
                        }
                    }
                else
                    {
                    echo '<tr class="text-center"><td colspan="5">No records found.</td></tr>';
                    }
                ?>
            </table>
            <?= paginate_function($records_per_page, $page, $total_no_recrd, $total_pages);
            ?>
    </div>
    <script>
        $(function () {
            //executes code below when user click on pagination links
            $("#results").on("click", ".pagination a", function (e) {
                e.preventDefault();
                //$(".loading-div").show();
                var page = $(this).attr("data-page"); //get page number from link
                var perpage = $('#results .perpage').val(); //get page number from link\
                var f_name = $("#results #fnamefilter").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                var locality = $("#results #localityfilter").val();


                $("#results").load("<?= CLIENT_URL ?>/ajax-page-load/list", {"page": page, "r_per_page": perpage, "f_name": f_name}, function () { //get content from PHP page
                    //$(".loading-div").hide(); //once done, hide loading element
                });
                return false;
            });
            $("#results").on("change", ".perpage", function (e) {
                e.preventDefault();
                //$(".loading-div").show();
                var page = $('#results .pagination a').attr("data-page"); //get page number from link
                var perpage = $(this).val(); //get page number from link
                var f_name = $("#results #fnamefilter").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                var locality = $("#results #localityfilter").val();
                $("#results").load("<?= CLIENT_URL ?>/ajax-page-load/list", {"page": page, "r_per_page": perpage, "f_name": f_name}, function () { //get content from PHP page
                    //$(".loading-div").hide(); //once done, hide loading element
                });
                return false;
            });
            $("#results").on("click", "#submit_form", function (e) {


                var f_name = $("#results #fnamefilter").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                var locality = $("#results #localityfilter").val();

                e.preventDefault();
                var page = $('#results .pagination a').attr("data-page"); //get page number from link
                var perpage = $('#results .perpage').val(); //get page number from link
                var f_name = $("#results #fnamefilter").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                var locality = $("#results #localityfilter").val();
                //alert(locality);

                //f_name.focus();
                $("#results").load("<?= CLIENT_URL ?>/ajax-page-load/list", {"page": page, "r_per_page": perpage, "f_name": f_name}, function () { //get content from PHP page
                });
                return false;
            });
            $("#results").on("change", ".select_feebook", function (e) {
                e.preventDefault();
                //$(".loading-div").show();
                var id = $(this).attr('id');
                var vals = $("#" + id).val();
                $("input#sep_fees_book_box").val('');
                //var p = $('a.ajaxselect').attr('data-select',val);
                $("input#sep_fees_book_box").val(vals);
            });
            return false;
        });</script>
    <?php
    }
else if ($content == 'locality_select')
    {

    if (isset($_POST["page"]))
        {
        $page = $_POST["page"];
        }
    else
        {
        $page = 1;
        }

    if (isset($_POST['r_per_page']))
        {
        $records_per_page = $_POST['r_per_page'];
        }
    else
        {
        $records_per_page = 10;
        }
    //print_r($_POST);
//    exit();
//    
//    $parents = Parents::get_parents($MSID, '', '', array('page' => $page, 'record_per_page' => $records_per_page, 'f_name' => @$_POST['f_name']));
//    $totalrecords = $parents->rowCount();
//    $total_no_recrd = Parents::get_parents($MSID, '', 'all', array('f_name' => @$_POST['f_name']))->rowCount();
//    $total_pages = ceil($total_no_recrd / $records_per_page);

    $locality = Master::get_locality2($MSID, @$_POST['f_name'], '', array('page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $locality->rowCount();
    $total_no_recrd = Master::get_locality2($MSID, @$_POST['f_name'], 'all')->rowCount();
    $total_pages = ceil($total_no_recrd / $records_per_page);

    //print_r(@$_POST);
    ?>
    <div id="results"><!-- content will be loaded here -->
        <form id="localiy_form" name="localiy_form" method="POST">

            <table class="table table-hover">
                <thead style="background:#ddd;">

                    <tr>

                        <th><input type="text" class="form-control" id="add_locality2" placeholder="Please enter your locality" name="add_locality2" value="<?= @$_POST['locality']; ?>" required="required" autofocus="autofocus"/></th>

                        <th  id="search_pin"><input type="text" class="form-control" id="fnamefilter" placeholder="Please enter pincode to search" name="fnamefilter" required="required" value="<?= @$_POST['f_name']; ?>"/></th>

                        <th  id="search_btn">
                            <input type="submit" class="x btn btn-primary" name="form_submit" id="submit_form" value="Search"/>

                        </th>

                    </tr>
                    <tr>
                        <th>Postoffice</th>
                        <th>Pincode</th>
                        <th>Tehsil</th>
                        <th>District</th>
                        <th>State</th>

                        <th>Action</th>
                    </tr>
                </thead>

                <?php
                if ($totalrecords > 0)
                    {
                    while ($rowv = $locality->fetch())
                        {
                        ?>
                        <tr>
                            <td><?= $rowv['postoffice']; ?></td>
                            <td><?= $rowv['pincode']; ?></td>
                            <td><?= $rowv['tehsil']; ?></td>
                            <td><?= $rowv['district']; ?></td><td><?= $rowv['state']; ?></td>
                            <td><a class="text-light-blue ajax_locality" title="select" data-id="<?= $rowv['id']; ?>" data-pincode="<?= $rowv['id'] ?>" data-name="<?= @$_POST['locality']; ?>" data-pin_id="<?= $rowv['pincode']; ?>" href="javascript:;">Select</a></td>
                        </tr>
                        <?php
                        }
                    }
                else
                    {
                    echo '<tr class="text-center"><td colspan="5">No records found.</td></tr>';
                    }
                ?>
            </table>
        </form>
        <?= paginate_function($records_per_page, $page, $total_no_recrd, $total_pages);
        ?>
    </div>
    <script>
        $(function () {



            //executes code below when user click on pagination links
            $("#results").on("click", ".pagination a", function (e) {
                e.preventDefault();
                //$(".loading-div").show();
                var page = $(this).attr("data-page"); //get page number from link
                var perpage = $('#results .perpage').val(); //get page number from link\
                var f_name = $("#results #fnamefilter").val();
                var locality = $("#results #add_locality2").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                var locality = $("#results #localityfilter").val();


                $("#results").load("<?= CLIENT_URL ?>/ajax-page-load/locality_select", {"page": page, "r_per_page": perpage, "f_name": f_name, "locality": locality}, function () { //get content from PHP page
                    //$(".loading-div").hide(); //once done, hide loading element
                });
                return false;
            });
            $("#results").on("change", ".perpage", function (e) {
                e.preventDefault();
                //$(".loading-div").show();
                var page = $('#results .pagination a').attr("data-page"); //get page number from link
                var perpage = $(this).val(); //get page number from link
                var f_name = $("#results #fnamefilter").val();
                var locality = $("#results #add_locality2").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                var locality = $("#results #localityfilter").val();
                $("#results").load("<?= CLIENT_URL ?>/ajax-page-load/locality_select", {"page": page, "r_per_page": perpage, "f_name": f_name, "locality": locality}, function () { //get content from PHP page
                    //$(".loading-div").hide(); //once done, hide loading element
                });
                return false;
            });
            $("#results").on("click", "#submit_form", function (e) {


                var f_name = $("#results #fnamefilter").val();
                var locality = $("#results #add_locality2").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                

                e.preventDefault();
                var page = $('#results .pagination a').attr("data-page"); //get page number from link
                var perpage = $('#results .perpage').val(); //get page number from link
                var f_name = $("#results #fnamefilter").val();
                var locality = $("#results #add_locality2").val();
                //                var m_name = $("#results #mnamefilter").val();
                //                var mobsms_name = $("#results #mobsmsfilter").val();
                //                var locality = $("#results #localityfilter").val();
                //alert(locality);

                //f_name.focus();
                $("#results").load("<?= CLIENT_URL ?>/ajax-page-load/locality_select", {"page": page, "r_per_page": perpage, "f_name": f_name, "locality": locality}, function () { //get content from PHP page
                });
                return false;
            });
            $("#results").on("change", ".select_feebook", function (e) {
                e.preventDefault();
                //$(".loading-div").show();
                var id = $(this).attr('id');
                var vals = $("#" + id).val();
                $("input#sep_fees_book_box").val('');
                //var p = $('a.ajaxselect').attr('data-select',val);
                $("input#sep_fees_book_box").val(vals);
            });
            return false;
        });</script>
    <?php
    }
else if ($content == 'edit_hostel')
    { //used in fee type and fee group page
    $hostel = Hostel::get_hostels($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_hostel" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Name</label>
                        <input class="form-control" value="<?= $hostel['name'] ?>" type="text" name="name" id="title" placeholder="Hostel A"/>
                    </div>
                </div>
                <!-- \col --> 
            </div>
    </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error')
                        {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'failed_students')
    { //used in fee type and fee group page
    $exam_std = Exam::get_failed_students($MSID, $id, '-1')->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_failed_students" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Student Id</label>
                        <input class="form-control" value="<?= $exam_std['s_id'] ?>" type="text" name="s_id" placeholder="Self Awareness"/>
                    </div>
                </div>
                <!-- \col --> 
            </div>
            <!--            <div class="form-group ">
                            <label  for="exampleInputName2">Result Date:</label>
                            <div class="input-group ">
                                <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
            
                                <input type="text" name="date_result" placeholder="<?= $exam_std['date_result'] ?>" id="date_result" value="" class="form-control failed_date_update"/>
                            </div>
                             /.input group 
                        </div>-->




    </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {
            //            $('.failed_date_update').datepicker({
            //                format: 'yyyy-mm-dd',
            //                todayHighlight: true,
            //                clearBtn: true
            //            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'child')
    {
    $parentid = $id;
    $students = Parents::get_childrens($parentid, $oCurrentUser->mydate);
    $totalrecords = $students->rowCount();

    if ($totalrecords > 0)
        {
        ?>
        <table class="table table-hover">
            <tr>
                <th>Sr.No.</th>
                <th>ID</th>
                <th>Name</th>
                <th>D.O.B.</th>
                <th>Class</th>
                <th>Transport</th>
                <th>Discount</th>
                <th>Action</th>
            </tr>
            <?php
            $i = 1;
            while ($rowv = $students->fetch(PDO::FETCH_ASSOC))
                {
                ?>
                <tr>
                    <td><?= $i ?></td>
                    <td><?= $rowv['student_id']; ?></td>
                    <td><?= $rowv['name']; ?></td>
                    <td><?= date('d M,Y', strtotime($rowv['birth_date'])); ?>
                    </td> 
                    <td><?php
                        $std_detail = Student::get_students($oCurrentUser->myuid, '', $rowv['student_id'])->fetch(PDO::FETCH_OBJ);
                        $cls = Master::get_classes($MSID, '', '', '', $std_detail->class)->fetch(PDO::FETCH_OBJ);
                        echo @$cls->class_name;
                        ?></td>
                    <td><?php
                        $tpt_stu_data = Transport::get_transport_stu($MSID, $rowv['student_id'], $oCurrentUser->mydate)->fetch(PDO::FETCH_OBJ);
                        if (@$tpt_stu_data->tpt_stn_id)
                            {
                            $tpt_stn = Transport::get_tptstations($MSID, $tpt_stu_data->tpt_stn_id)->fetch(PDO::FETCH_OBJ);
                            echo $tpt_stn->station_name;
                            }
                        else
                            {
                            echo "No";
                            }
                        ?></td>
                    <td><?php
                        $disc_stu_data = Transport::get_discounted_stu($MSID, $id, $oCurrentUser->mydate)->fetch(PDO::FETCH_OBJ);

                        if (@$disc_stu_data->discount_id)
                            {
                            $dis_stn = Transport::get_discount_names($MSID, $disc_stu_data->discount_id)->fetch(PDO::FETCH_OBJ);
                            echo $dis_stn->name;
                            }
                        else
                            {
                            echo "No";
                            }
                        ?></td>

                    <td><a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $rowv['student_id']; ?>" data-ms="modal" data-title="Student Profile">View</a></td>
                </tr>
                <?php
                ++$i;
                }
            ?>
        </table>
        <?php
        }
    else
        {
        echo '<p class="text-center">No records found.</p>';
        }
    ?>
    <?php
    }
else if ($content == 'add_timetable')
    {
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="add_timetable" value="true" />
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Teacher   <?php
                        $employees_used = Employee::emp_timetable($MSID, http_get("param2"), http_get("param3"), http_get("param4"))->fetchAll(PDO::FETCH_ASSOC);
//                        pr($employees_used)   ;    $used_employees_array = array();
                        foreach ($employees_used as $emps)
                            {
                            $used_employees_array[] = $emps['employee_id'];
                            }
//                        pr($used_employees_array);
                        $employees = Employee::get_employee($MSID, '', 'all', array('emp_category' => 'TS'))->fetchAll(PDO::FETCH_ASSOC);
//                        pr($employees);
//                        exit();
                        $total_employees_array = array();
                        foreach ($employees as $emp)
                            {
                            $total_employees_array[] = $emp['employee_id'];
                            }
                        //                        print_r($total_employees_array);
                        if (@$used_employees_array)
                            {
                            $remaining = array();
                            $remaining = array_diff($total_employees_array, $used_employees_array);
                            }
                        else
                            {
                            $remaining = $total_employees_array;
                            }
//                        pr($remaining);
                        ?></label>
                    <select id="e_id" name="e_id" class="form-control "  >


                        <?php
                        foreach ($remaining as $employee)
                            {

                            $employees = Employee::get_employee($MSID, $employee)->fetch(PDO::FETCH_ASSOC);
//                      
                            ?>
                            <option value="<?= $employees['employee_id']; ?>"  >
                                <?php echo format($employees['emp_name']), " ", $employees['employee_id']; ?>
                            </option>
                        <?php } ?>
                    </select></div>
            </div>
            <!-- \col --> 
        </div><div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Subject</label>
                    <select id="subject" name="subject" class="form-control "  >
                        <?php
                        $subjects = SuperAdmin::get_schoolwise_subject($MSID)->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                        ?>

                        <?php
                        foreach ($subjects as $subject)
                            {
                            ?>
                            <option value="<?= $subject['subject_id']; ?>"  >
                                <?= $subject['name']; ?>
                            </option>
                        <?php } ?>
                    </select></div>
            </div>
            <!-- \col --> 
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <lable> Select Color</lable> <input type="color" name="colour"  value="#ffffff">
                </div>
            </div>
        </div>

        <input type="hidden" name="section" value="<?= http_get("param4") ?>">
        <input type="hidden" name="period" value="<?= http_get("param3") ?>">
        <input type="hidden" name="class" value="<?= http_get("param2") ?>">
        <div class="input-group">
            <span class="input-group-addon">
                <input type="checkbox" class="checkbox"  id="selecta"> 
            </span>
            <label class="form-control" for="exampleInputName2">Days</label>
        </div>
        <?php
        $time_table = TimeTable::get_used_days($MSID, http_get("param2"), http_get("param3"), http_get("param4"))->fetch(PDO::FETCH_OBJ);
        $used_days = $time_table->used_days;
        $ttl_days = $oCurrentSchool->working_days;
        $used_days_array = array();
        $total_days_array = array();
        $remaining = array();
        $used_days_array = explode(",", $used_days);
        $total_days_array = explode(",", $ttl_days);
        $remaining = array_diff($total_days_array, $used_days_array);
//                                                   $days = array();

        foreach ($remaining as $day)
            {
            $day_name = days_name($day);
            ?><div class="col-md-4"><input id="" type="checkbox"  class="checkbox1 day_all" value="<?= $day; ?>" name="days[]" <?php ?>> <?= $day_name ?></div>

            <?php
            }
        ?><br>

        <div class="row">
            <div class="col-md-3">
                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
            </div>
            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
        </div>
    </form>
    <script>
        $(function () {
            $('#selecta').click(function (event) {
                //                 alert("asd");
                if (this.checked) {
                    $('.day_all').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.day_all').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var e_id = $("#e_id");
                var subject = $("#subject");
                var days = $("#days");
                var errors = '';
                if (e_id.val() == '') {
                    e_id.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    e_id.parent('.form-group').removeClass('has-error');
                }
                if (subject.val() == '') {
                    subject.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    subject.parent('.form-group').removeClass('has-error');
                }
                if (days.val() == '') {
                    days.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    days.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                //                alert(datastring);
                //                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data


                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            //                            location.reload();
                            //                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'edit_timetable')
    {
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="update_timetable" value="true" />
        <div class="row">
            <?php
            $timttable_dtl = TimeTable::get_time_table_dtl($MSID, http_get("param5"))->fetch(PDO::FETCH_OBJ);
//            print_r($timttable_dtl);
            ?>
            <div class="col-md-12">
                <div class="form-group">
                    <label>Teacher</label>
                    <select id="e_id" name="e_id" class="form-control "  >
                        <?php
                        $employees_used = Employee::emp_timetable($MSID, '', '', http_get("param4"))->fetchAll(PDO::FETCH_ASSOC);
//                        print_r($employees_used)   ;    $used_employees_array = array();
                        foreach ($employees_used as $emps)
                            {
                            $used_employees_array[] = $emps['employee_id'];
                            }
//                        print_r($used_employees_array);
                        $employees = Employee::get_employee($MSID, '', 'all', array('emp_category' => 'TS'))->fetchAll(PDO::FETCH_ASSOC);
//                        print_r($employees);
                        $total_employees_array = array();
                        foreach ($employees as $emp)
                            {
                            $total_employees_array[] = $emp['employee_id'];
                            }

//                        print_r($total_employees_array);
                        $remaining = array();
                        $remaining = array_diff($total_employees_array, $used_employees_array);
//                          $remaining = array_diff($total_employees_array, $used_employees_array);
//                                                   
//                        print_r($remaining);
                        ?>

                        <?php
                        foreach ($remaining as $employee)
                            {

                            $employees = Employee::get_employee($MSID, $employee)->fetch(PDO::FETCH_ASSOC);
//                      
                            ?>
                            <option value="<?= $employees['employee_id']; ?>"  >
                                <?php echo format($employees['emp_name']), " ", $employees['employee_id']; ?>
                            </option>
                            <?php
                            }
                        $employees = Employee::get_employee($MSID, $timttable_dtl->empid)->fetch(PDO::FETCH_ASSOC);
//                      
                        ?>
                        <option value="<?= $employees['employee_id']; ?>" selected="selected" >
                            <?php echo format($employees['emp_name']), " ", $employees['employee_id']; ?>
                        </option> ?>

                    </select></div>
            </div>
            <!-- \col --> 
        </div><div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Subject</label>
                    <select id="subject" name="subject" class="form-control "  >
                        <?php
                        $subjects = SuperAdmin::get_schoolwise_subject($MSID, '', array('selectAll' => 'true'))->fetchAll(PDO::FETCH_ASSOC);
//                                            print_r($subjects) ;    
                        ?>

                        <?php
                        foreach ($subjects as $subject)
                            {
                            ?>
                            <option value="<?= $subject['subject_id']; ?>"  >
                                <?= $subject['name']; ?>
                            </option>
                            <?php
                            }
                        $subjects = SuperAdmin::get_schoolwise_subject($MSID, '', array('selectAll' => 'true'), '', '', '', '', $timttable_dtl->Subject)->fetch(PDO::FETCH_ASSOC);
//                    //                      
                        ?>
                        <option value="<?= $subjects['subject_id']; ?>" selected="selected" >
                            <?php echo format($subjects['name']) ?>
                        </option> ?>
                    </select></div>
            </div>
            <!-- \col --> 
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <lable> Select Color</lable> <input type="color" name="colour"  value="#ffffff">
                </div>
            </div>
        </div>

        <input type="hidden" name="section" value="<?= http_get("param4") ?>">
        <input type="hidden" name="id" value="<?= $timttable_dtl->id ?>">
        <input type="hidden" name="period" value="<?= http_get("param3") ?>">
        <input type="hidden" name="class" value="<?= http_get("param2") ?>">
        <div class="input-group">
            <span class="input-group-addon">
                <input type="checkbox" class="checkbox"  id="selectal"> 
            </span>
            <label class="form-control" for="exampleInputName2">Days</label>
        </div>
        <?php
        $time_table = TimeTable::get_used_days($MSID, http_get("param2"), http_get("param3"), http_get("param4"))->fetch(PDO::FETCH_OBJ);
        $used_days = $time_table->used_days;
        $ttl_days = $oCurrentSchool->working_days;
        $used_days_array = array();
        $total_days_array = array();
        $remaining = array();
        $used_days_array = explode(",", $used_days);
        $total_days_array = explode(",", $ttl_days);
        $remaining = array_diff($total_days_array, $used_days_array);
//                                                   $days = array();

        foreach ($remaining as $day)
            {
            $day_name = days_name($day);
            ?><div class="col-md-4"><input id="days" type="checkbox"  class="day_alls checkbox1" value="<?= $day; ?>" name="days[]" <?php ?>> <?= $day_name ?></div>

            <?php
            }

        $used_day_array = explode(",", $timttable_dtl->days);
        foreach ($used_day_array as $day)
            {
            $day_name = days_name($day);
            ?><div class="col-md-4"><input checked="checked" id="days" type="checkbox"  class="day_alls checkbox1" value="<?= $day; ?>" name="days[]" <?php ?>> <?= $day_name ?></div>

            <?php
            }
        ?><br>
        <div class="row">
            <div class="col-md-3">
                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button> 
                <div class="col-md-12"><a class="btn btn-lg btn-success" href="<?= CLIENT_URL; ?>/master-timetable/delete/<?= http_get("param5"); ?>"  style="margin: 0 0 0 3px;">Delete</a>

                </div>
                <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
            </div>
    </form>
    <script>
        $(function () {
            $('#selectal').click(function (event) {
                //                 alert("asd");
                if (this.checked) {
                    $('.day_alls').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.day_alls').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var e_id = $("#e_id");
                var subject = $("#subject");
                var days = $("#days");
                var errors = '';
                if (e_id.val() == '') {
                    e_id.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    e_id.parent('.form-group').removeClass('has-error');
                }
                if (subject.val() == '') {
                    subject.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    subject.parent('.form-group').removeClass('has-error');
                }
                if (days.val() == '') {
                    days.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    days.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            //                            alert(responseText);
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! Select Days.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'locality')
    {
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="add_locality" value="true" />
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Locality Name<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="30" id="localName" name="localName" required>
                </div>
                <div class="form-group">
                    <label>Post-Office<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="30" id="postoffice" name="postoffice" required>
                </div>
                <div class="form-group">
                    <label>Tehsil<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="30" id="tehsil" name="tehsil" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>District<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="30" id="district" name="district" required>
                </div>
                <div class="form-group">
                    <label>State<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="30" id="state" name="state" required>
                </div>
                <div class="form-group">
                    <label>Pin-Code<span class="text-red">*</span></label>
                    <input class="form-control" type="number" id="pincode" name="pincode" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
            </div>
            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
        </div>
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var name = $("#localName");
                var postoffice = $("#postoffice");
                var tehsil = $("#tehsil");
                var district = $("#district");
                var state = $("#state");
                var pincode = $("#pincode");
                var errors = '';
                if (name.val() == '') {
                    name.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    name.parent('.form-group').removeClass('has-error');
                }
                if (postoffice.val() == '') {
                    postoffice.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    postoffice.parent('.form-group').removeClass('has-error');
                }
                if (tehsil.val() == '') {
                    tehsil.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    tehsil.parent('.form-group').removeClass('has-error');
                }
                if (district.val() == '') {
                    district.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    district.parent('.form-group').removeClass('has-error');
                }
                if (state.val() == '') {
                    state.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    state.parent('.form-group').removeClass('has-error');
                }
                if (pincode.val() == '') {
                    pincode.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    pincode.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            $('#locality').append(responseText);
                            eModal.close();
                            name.val('');
                            postoffice.val('');
                            tehsil.val('');
                            district.val('');
                            state.val('');
                            pincode.val('');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'update_hostelers')
    { //used in fee type and fee group page
    $hosteler = Hostel::get_hostelers($MSID, $id)->fetch(PDO::FETCH_OBJ);
//        print_r($exam_grade);
    ?><?php
    $ses_str_dt = $oCurrentUser['mysession'] . '-' . date('m-d', strtotime($oCurrentSchool->session_start_date));
    $ses_end_dt = ($oCurrentUser['mysession'] + 1) . '-' . date('m-d', strtotime($oCurrentSchool->session_end_date));
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_hosteler" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Student Id</label>
                    <input class="form-control" type="text" name="s_id" id="s_id" value="<?= $hosteler->s_id ?>"placeholder="15001"/>
                </div>
            </div>
            <!-- \col --> 
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Hostel</label>
                    <select id="s_id" name="hostel_id" class="form-control "  >
                        <?php
                        $hostels = Hostel::get_hostels($MSID)->fetchAll(PDO::FETCH_ASSOC);
                        ?>

                        <?php
                        foreach ($hostels as $hostel)
                            {
                            if ($hostel['id'] == $hosteler->hostel_id)
                                {
                                $selected = 'selected= "selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $hostel['id'] . '"' . $selected . '>' . $hostel['name'] . '</option>';
                            }
                        ?>
                    </select></div>
            </div>
            <!-- \col --> 
        </div>   
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>From Date</label>

                    <input type="text" name="from_date" id="due_date_id" class="form-control issue_datea"/>
                </div>
            </div>
            <!-- \col --> 
        </div>  



        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {
            $('.issue_datea').datepicker({
                format: 'yyyy-mm-dd',
                todayHighlight: true,
                startDate: "$ses_str_dt",
                endDate: "$ses_end_dt",
                clearBtn: true
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'exam_assesments')
    { //used in fee type and fee group page
    $exam_co = Exam::get_exam_assesments($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_exam_assesments" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Title</label>
                        <select class="form-control " name="title" id="title">
                            <option value="1" <?php echo (@$exam_co['title'] == "FA1") ? 'Selected="Selected"' : ''; ?>> FA 1 </option>
                            <option value="2" <?php echo (@$exam_co['title'] == "FA2") ? 'Selected="Selected"' : ''; ?>> FA 2 </option>
                            <option value="3" <?php echo (@$exam_co['title'] == "FA3") ? 'Selected="Selected"' : ''; ?>> FA 3 </option>
                            <option value="4" <?php echo (@$exam_co['title'] == "FA4") ? 'Selected="Selected"' : ''; ?>> FA 4 </option>
                            <option value="5" <?php echo (@$exam_co['title'] == "SA1") ? 'Selected="Selected"' : ''; ?>> SA 1 </option>
                            <option value="6" <?php echo (@$exam_co['title'] == "SA2") ? 'Selected="Selected"' : ''; ?>> SA 2 </option>
                        </select>
                    </div>
                </div>
                <!-- \col --> 
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Term</label>
                        <select class="form-control " name="term" id="term">
                            <option value="Term 1" <?php echo (@$exam_co['term'] == "Term 1") ? 'Selected="Selected"' : ''; ?>>Term 1 </option>
                            <option value="Term 2" <?php echo (@$exam_co['term'] == "Term 2") ? 'Selected="Selected"' : ''; ?>>Term 2 </option>
                        </select>  </div>
                </div>
                <!-- \col --> 
            </div><div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Maximum Marks</label>
                        <input class="form-control" type="text" value="<?= $exam_co['max_marks'] ?>"  name="max_marks" id="max_marks" placeholder="100" />
                    </div>
                </div>
                <!-- \col --> 
            </div>


            <div class="row">
                <div class="input-group">
                    <span class="input-group-addon">
                        <input type="checkbox" class="checkbox"  id="selectalll"> 
                    </span>
                    <label class="form-control" for="exampleInputName2">Classes</label>
                </div>
                <?php
                $selected_classes = explode(',', $exam_co['class']);
                ?>
                <?php
                $get_classes = Master::get_classes($MSID);
//print_r($get_classes);
                $test = Master::get_classes($MSID)->fetch(PDO::FETCH_ASSOC);
                $i = -1;
                while ($rowv = $get_classes->fetch(PDO::FETCH_ASSOC))
                    {
                    ?><div class="col-md-4"><input type="checkbox"  class="checkbox1" value="<?= $rowv['class_no']; ?>" name="for_class[]" <?php
                    echo (in_array($i, $selected_classes)) ? 'checked="checked"' : '';
                    ?>> <?= $rowv['class_name']; ?></div>

                    <?php
                    $i++;
                    }
                ?>
            </div>
    </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {
            $('#selectalll').click(function (event) {
                //            alert();
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'exam_co_scholastic_marks')
    { //used in fee type and fee group page
    $exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '', array('selectAll' => 'true'), $_SESSION['class_id_for_marks']);
    $totalrecords = $exam_co_scholastic_areas->rowCount();
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="add_exam_co_scholastic_marks" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>

        <div class="box-body">
            <?php
            if ($totalrecords > 0)
                {
                ?>  <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-6"> 
                                    <lable><b>Co Scholastic Area</b></lable>
                                </div>
                                <div class="col-md-4">

                                    <lable><b>Marks</b></div>  
                                <div class="col-md-2">
                                    <lable><b>Out OF <span class="text-red ">*</span></b></lable></div>  
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                while ($rowv = $exam_co_scholastic_areas->fetch())
                    {
                    $marks = Exam::get_exam_co_scholastic_marks($MSID, '', $data = array('selectAll' => 'true'), $id, $oCurrentUser['mysession'], $rowv['id']);
                    $totalrecords_marks = $marks->rowCount();
                    if ($totalrecords_marks > 0)
                        {
                        $previous_marks = $marks->fetch(PDO::FETCH_ASSOC);
                        }
                    ?> 

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6"> 
                                        <input class="form-control" type="text" name="title[]"  value="<?php
                                        echo ($totalrecords_marks > 0) ? $previous_marks['title'] : $rowv['title'];
                                        ?>" id="title" />
                                        <input class="form-control" type="hidden" name="co_scholastic[<?= $rowv['id'] ?>]" value="<?= $rowv['id'] ?>" />
                                    </div>
                                    <div class="col-md-4">
                                        <input class="form-control" type="text" name="marks[]" value="<?php
                                        echo ($totalrecords_marks > 0) ? $previous_marks['marks'] : "";
                                        ?>" id="marks" />
                                    </div>  
                                    <div class="col-md-2">
                                        <span class="text-red ">*</span> / <?= $rowv['max_marks'] ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    }
                }
            else
                {
                echo '<div class="text-center margin">Please Add Co Scholastic Areas for ' . $_SESSION['class_id_for_marks'] . ' Class</div>';
                }
            ?>

        </div>
        <?php
        if ($totalrecords > 0)
            {
            ?> <div class="form-group">
                <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Add</button>
            </div>
        <?php } ?>
        <div class="col-md-3 text-center"> 
            <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </form>

    <script>
        $(function () {
            $('#selectalll').click(function (event) {
                //            alert();
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'exam_co_scholastic_indicators')
    { //used in fee type and fee group page
    $exam_indicators = Exam::get_exam_co_scholastic_indicators($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_exam_co_scholastic_indicators" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Co- Scholastic Area</label>
                        <select id="co_scholastic_id" name="co_scholastic_id" class="form-control "  >
                            <?php
                            $areas = Exam::get_exam_co_scholastic_areas($MSID)->fetchAll(PDO::FETCH_ASSOC);
                            ?>

                            <?php
                            foreach ($areas as $area)
                                {
                                if ($area['id'] == $exam_indicators['co_scholastic_id'])
                                    {
                                    $selected = 'selected="selected"';
                                    }
                                else
                                    {
                                    $selected = '';
                                    }
                                ?>
                                <option value="<?= $area['id']; ?>" <?= $selected ?> >
                                    <?= $area['title']; ?>
                                </option>
                            <?php } ?>
                        </select></div>
                </div>
                <!-- \col --> 
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Grade</label>

                        <select class="form-control" type="text" name="grade" id="grade">


                            <option value="A" <?php
                            if ($exam_indicators['grade'] == 'A')
                                {
                                echo 'selected="selected"';
                                }
                            ?>>A</option>
                            <option value="B" <?php
                            if ($exam_indicators['grade'] == 'B')
                                {
                                echo 'selected="selected"';
                                }
                            ?>>B</option>
                            <option value="C" <?php
                            if ($exam_indicators['grade'] == 'C')
                                {
                                echo 'selected="selected"';
                                }
                            ?>>C</option>
                            <option value="D" <?php
                            if ($exam_indicators['grade'] == 'D')
                                {
                                echo 'selected="selected"';
                                }
                            ?>>D</option>
                            <option value="E" <?php
                            if ($exam_indicators['grade'] == 'E')
                                {
                                echo 'selected="selected"';
                                }
                            ?>>E</option>


                        </select>  
                    </div>
                </div>
                <!-- \col --> 
            </div><div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Description </label>
                        <textarea class="form-control" rows="2" cols="50" name="description"   id="description" placeholder="Description" ><?= $exam_indicators['description'] ?></textarea>

                    </div>
                </div>
                <!-- \col --> 
            </div>

        </div></form>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {
            $('#selectalll').click(function (event) {
                //            alert();
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'exam_co_scholastic_areas')
    { //used in fee type and fee group page
    $exam_co = Exam::get_exam_co_scholastic_areas($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_exam_co_scholastic_areas" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Title</label>
                        <input class="form-control" value="<?= $exam_co['title'] ?>" type="text" name="title" id="title" placeholder="Self Awareness"/>
                    </div>
                </div>
                <!-- \col --> 
            </div><div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Maximum Marks</label>
                        <input class="form-control" type="text" value="<?= $exam_co['max_marks'] ?>"  name="max_marks" id="max_marks" placeholder="1" />
                    </div>
                </div>
                <!-- \col --> 
            </div>


            <div class="row">
                <div class="input-group">
                    <span class="input-group-addon">
                        <input type="checkbox" class="checkbox"  id="selectalll"> 
                    </span>
                    <label class="form-control" for="exampleInputName2">Classes</label>
                </div>
                <?php
                $selected_classes = explode(',', $exam_co['class']);
                ?>
                <?php
                $get_classes = Master::get_classes($MSID);
//print_r($get_classes);
                $test = Master::get_classes($MSID)->fetch(PDO::FETCH_ASSOC);
                $i = -1;
                while ($rowv = $get_classes->fetch(PDO::FETCH_ASSOC))
                    {
                    ?><div class="col-md-4"><input type="checkbox"  class="checkbox1" value="<?= $rowv['class_no']; ?>" name="for_class[]" <?php
                    echo (in_array($i, $selected_classes)) ? 'checked="checked"' : '';
                    ?>> <?= $rowv['class_name']; ?></div>

                    <?php
                    $i++;
                    }
                ?>
            </div>
    </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {
            $('#selectalll').click(function (event) {
                //            alert();
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'exam_grade')
    { //used in fee type and fee group page
    $exam_grade = Exam::get_exam_grades($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_exam_grade" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Grade</label>
                        <input class="form-control" value="<?= $exam_grade['grade'] ?>" type="text" name="grade" id="grade" />
                    </div>
                </div>
                <!-- \col --> 
            </div><div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Percent From</label>
                        <input class="form-control" type="text" value="<?= $exam_grade['percent_from'] ?>"  name="percent_from" id="percent_from" />
                    </div>
                </div>
                <!-- \col --> 
            </div><div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Percent To</label>
                        <input class="form-control" type="text" value="<?= $exam_grade['percent_to'] ?>" name="percent_to" id="percent_to" />
                    </div>
                </div>
                <!-- \col --> 
            </div><div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>5 Point Grade </label>
                        <input class="form-control" type="text" value="<?= $exam_grade['5_point_grade'] ?>"  name="5_point_grade" id="5_point_grade" />
                    </div>
                </div>
                <!-- \col --> 
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Grade Point</label>
                        <input class="form-control" type="text"  value="<?= $exam_grade['grade_point'] ?>" name="grade_point" id="grade_point" />
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="input-group">
                    <span class="input-group-addon">
                        <input type="checkbox" class="checkbox"  id="selectalll"> 
                    </span>
                    <label class="form-control" for="exampleInputName2">Classes</label>
                </div>
                <?php
                $selected_classes = explode(',', $exam_grade['for_class']);
                ?>
                <?php
                $get_classes = Master::get_classes($MSID);
//print_r($get_classes);
                $test = Master::get_classes($MSID)->fetch(PDO::FETCH_ASSOC);
                $i = -1;
                while ($rowv = $get_classes->fetch(PDO::FETCH_ASSOC))
                    {
                    ?><div class="col-md-4"><input type="checkbox"  class="checkbox1" value="<?= $rowv['class_no']; ?>" name="for_class[]" <?php
                    echo (in_array($i, $selected_classes)) ? 'checked="checked"' : '';
                    ?>> <?= $rowv['class_name']; ?></div>

                    <?php
                    $i++;
                    }
                ?>
            </div> 
    </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {
            $('#selectalll').click(function (event) {
                //            alert();
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'exam_health_data')
    { //used in fee type and fee group page
    $existing_health = Exam::get_exam_health_data($MSID, '', array('selectAll' => 'true'), $id, $oCurrentUser->mysession, http_get("param3"));
    $totalrecords = $existing_health->rowCount();
    if ($totalrecords > 0)
        {
        $existing_health_data = $existing_health->fetch(PDO::FETCH_ASSOC);
        }
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="add_exam_health_data" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" /> 
        <input type="hidden" name="term" value="<?= http_get("param3") ?>" />
        <input type="hidden" name="class" value="<?= http_get("param4") ?>" />
        <input type="hidden" name="section" value="<?= http_get("param5") ?>" />
        <input type="hidden" name="year" value="<?= $oCurrentUser->mysession ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>

        <div class="box-body">

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Select ID</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <lable><b><?= $id ?></b></lable>
                                    </div></div> 
                            </div>
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Term</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <lable><b><?= http_get("param3") ?></b></lable>
                                    </div></div> 
                            </div>
                        </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Height(cm)</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="height" value="<?= @$existing_health_data['height'] ?>"> 
                                    </div></div> 
                            </div>
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Weight(kg)</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="weight" value="<?= @$existing_health_data['weight'] ?>"> 
                                    </div></div> 
                            </div>  </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>VisionL</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="vision_l" value="<?= (@$existing_health_data['vision_l']) ? $existing_health_data['vision_l'] : "6/6"
        ?>"> 
                                    </div></div> 
                            </div>
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>VisionR</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="vision_r" value="<?= (@$existing_health_data['vision_r']) ? $existing_health_data['vision_r'] : "6/6"
        ?>" > 
                                    </div></div> 
                            </div>  </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Ear Left</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="ear_l" value="<?= @$existing_health_data['ear_l'] ?>"> 
                                    </div></div> 
                            </div>
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Ear Right</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="ear_r" value="<?= @$existing_health_data['ear_r'] ?>"> 
                                    </div></div> 
                            </div>   </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Nose</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="nose" value="<?= @$existing_health_data['nose'] ?>"> 
                                    </div></div> 
                            </div>
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Throat</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="throat" value="<?= @$existing_health_data['throat'] ?>"> 
                                    </div></div> 
                            </div>  </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Dental Hygiene</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="dental_hygiene" value="<?= @$existing_health_data['dental_hygiene'] ?>"> 
                                    </div></div> 
                            </div>
                            <div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Pulse</b></lable>
                                    </div> 
                                    <div class="col-md-6"><input type="text" name="pulse" value="<?= @$existing_health_data['pulse'] ?>"> 
                                    </div></div> 
                            </div> </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6"> 
                            </div><div class="col-md-6"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Heart</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <input type="text" name="heart" value="<?= @$existing_health_data['heart'] ?>"> 
                                    </div></div> 
                            </div> </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">


                            <div class="col-md-12"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Any Kind Of Alergy?</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <textarea name="alergy" cols="50" rows="1"> <?= @$existing_health_data['alergy'] ?></textarea>
                                    </div></div> 
                            </div>   </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-12"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Any other Chronic Disease Child has:</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <textarea name="chronic_diease" cols="50" rows="1"><?= @$existing_health_data['chronic_diease'] ?></textarea>
                                    </div></div> 
                            </div> </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-12"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Does the child has any problem during physical activity .
                                                (if any kind mention here:</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <textarea name="physical_activity_problem" cols="50" rows="1"><?= @$existing_health_data['physical_activity_problem'] ?></textarea>
                                    </div></div> 
                            </div>  </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Details of vaccination taken please tick below:</b></lable>
                                    </div> 
                                    <div class="col-md-6">   <p class="form-group">
                                            <input type="checkbox"   id="select_all">&nbsp;  <b>Select All</b> 
                                        </p>
                                    </div></div> 
                            </div>
                        </div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-12"> 
                                <div class="row">
                                    <div class="col-md-3"> 
                                        <input type="checkbox" class="checkboxs"name="bcg_v" <?php echo (@$existing_health_data['bcg_v'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp; BCG </div>
                                    <div class="col-md-3"><input type="checkbox" class="checkboxs"name="hb" <?php echo (@$existing_health_data['hb'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;HB</div>
                                    <div class="col-md-3">   <input type="checkbox" class="checkboxs"name="hepatitis_b" <?php echo (@$existing_health_data['hepatitis_b'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;Hepatitis B</div>
                                    <div class="col-md-3">    <input type="checkbox" class="checkboxs"name="oral_polio" <?php echo (@$existing_health_data['oral_polio'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;Oral Polio</div>
                                    <div class="col-md-3">    <input type="checkbox" class="checkboxs"name="dpt" <?php echo (@$existing_health_data['dpt'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;DPT</div>
                                    <div class="col-md-3">    <input type="checkbox" class="checkboxs"name="measles" <?php echo (@$existing_health_data['measles'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;Measles</div>
                                    <div class="col-md-3">   <input type="checkbox" class="checkboxs"name="hepatitis_a" <?php echo (@$existing_health_data['hepatitis_a'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;Hepatitis A</div>
                                    <div class="col-md-3"> <input type="checkbox" class="checkboxs"name="mmr" <?php echo (@$existing_health_data['mmr'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;MMR</div>
                                    <div class="col-md-3">  <input type="checkbox" class="checkboxs"name="chickenpox" <?php echo (@$existing_health_data['chickenpox'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;Chickenpox</div>
                                    <div class="col-md-3">    <input type="checkbox" class="checkboxs"name="dpt_opt_hb" <?php echo (@$existing_health_data['dpt_opt_hb'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;DPT+OPV+HB</div>
                                    <div class="col-md-3">    <input type="checkbox" class="checkboxs"name="dt_opa" <?php echo (@$existing_health_data['dt_opa'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;DT.OPA</div>
                                    <div class="col-md-3">     <input type="checkbox" class="checkboxs"name="typhoid" <?php echo (@$existing_health_data['typhoid'] == 'on') ? "checked" : '';
        ?>>&nbsp;&nbsp;Typhoid</div>  
                                </div>
                            </div></div>
                    </div></div><div class="col-md-12">
                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-12"> 
                                <div class="row">
                                </div>
                            </div></div>
                    </div></div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="row">

                            <div class="col-md-12"> 
                                <div class="row">
                                    <div class="col-md-6"> <lable><b>Any Other Problem?</b></lable>
                                    </div> 
                                    <div class="col-md-6"> <textarea name="any_other" cols="50" rows="1"><?= @$existing_health_data['any_other'] ?></textarea>
                                    </div></div> 
                            </div>

                        </div>
                    </div>
                </div>
            </div>





        </div>
        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Add</button>
        </div>
        <div class="col-md-3 text-center"> 
            <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </form>

    <script>
        $(document).ready(function () {
            //        alert('');
            $('#select_all').click(function (event) {
                if (this.checked) {
                    $('.checkboxs').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkboxs').each(function () {
                        this.checked = false;
                    });
                }
            });
        });
        $(function () {

            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                                                                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'add_books')
    {
    ?>
    <form method="post" action="" role="form" id="onajaxForm">
        <input type="hidden" name="add_book" value="true" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <div class="row">
            <div class="col-md-12">


                <div class="form-group">
                    <label>ISBN<span class="text-red">*</span></label>
                    <input type="number"  min="1"  name="isbn" size="30" placeholder="12345" class="form-control">
                </div>

                <div class="form-group">
                    <label>Title<span class="text-red">*</span></label>
                    <input type="text" name="title" size="30" class="form-control">
                </div>
                <div class="form-group">
                    <label>category<span class="text-red">*</span></label>
                    <select name="category_id" class="class_check form-control">
                        <option value="">Select</option>
                        <?php
                        $categorys = Library::get_category($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        <?php
                        foreach ($categorys as $category)
                            {

                            echo '<option value="' . $category['id'] . '">' . $category['name'] . '</option>';
                            }
                        ?>
                    </select>
                </div>  
                <div class="form-group">
                    <label>Author<span class="text-red">*</span></label>
                    <input type="text" name="author" size="30" class="form-control">
                </div>

                <div class="form-group">
                    <label>Edition<span class="text-red">*</span></label>
                    <input type="number" min="1" name="edition" size="30" class="form-control">
                </div>
                <div class="form-group">
                    <label>Publisher<span class="text-red">*</span></label>
                    <input type="text" name="publisher" size="30" class="form-control">
                </div>
                <div class="form-group">
                    <label>No Of Copy<span class="text-red">*</span></label>
                    <input type="number"  min="1"  name="copy_taken" size="30" class="form-control">
                </div>
                <div class="form-group">
                    <label>Shelf No<span class="text-red">*</span></label>
                    <input type="text" name="shelf_no" size="30" class="form-control">
                </div>
                <div class="form-group">
                    <label>book_position<span class="text-red">*</span></label>
                    <input type="text" name="book_position" size="30" class="form-control">
                </div>


            </div>
            <!-- \col -->
        </div>
    </form>

    <div class="modal-footer">

        <button type="button" class="btn btn-primary" id="submit">Save changes</button>
    </div>



    <?php
    }
else if ($content == 'department')
    {
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="add_department" value="true" />
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Department Name<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="30" id="dept_name" name="dept_name">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
            </div>
            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
        </div>
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var dept_name = $("#dept_name");
                var errors = '';
                if (dept_name.val() == '') {
                    dept_name.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    dept_name.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        alert(responseText);
                        /*if (responseText != 'error') {
                         $('#department').append(responseText);
                         eModal.close();
                         dept_name.val('');
                         } else {
                         $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                         }*/
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'designation')
    {
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="add_designation" value="true" />
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Designation Name<span class="text-red">*</span></label>
                    <input class="form-control" type="text" size="30" id="designame" name="designame">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
            </div>
            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
        </div>
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var designame = $("#designame");
                var errors = '';
                if (designame.val() == '') {
                    designame.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    designame.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            $('#designation').append(responseText);
                            eModal.close();
                            designame.val('');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'employee')
    {
    $emp = Employee::get_employee($MSID, $id, 'all', '', $oCurrentUser->mydate)->fetch(PDO::FETCH_ASSOC);
    //print_r($emp);
//get locality
    $local = Master::get_locality($MSID, $emp['locality'], 1)->fetch();
    ?>
    <style>
        td, th {
            border: medium none !important;
        }
        .trnormal{
            font-weight: normal;
            color:#3c8dbc;
        }
    </style>
    <div class="row">
        <div class="col-md-4"> <img width="100%" height="100%" class="profile" src="uploads/no-image.png"> </div>
        <div class="col-md-8">
            <table	 class="table">
                <tbody>
                    <tr>
                        <td colspan="5"><h3 style="margin:0px;">
                                <?= $emp['emp_name_prefix'] . '&nbsp;' . $emp['emp_name']; ?>
                            </h3></td>
                    </tr>
                    <tr>
                        <td class="pst" colspan="5"><?= $emp['p_qualification']; ?>
                            (
                            <?php
                            if ($emp['emp_category'] == 'TS')
                                {
                                echo 'Teaching Staff';
                                }
                            else
                                {
                                echo 'Non Teaching Staff';
                                }
                            ?>
                            )</td>
                    </tr>
                    <tr>
                        <th>Father's Name</th>
                        <th>Spouse  Name</th>
                        <th>Date of Birth</th>
                        <th>Mobile</th>
                    </tr>
                    <tr>
                        <td class="trnormal"><?= $emp['father_name']; ?></td>
                        <td class="trnormal"><?= $emp['spouse_name']; ?></td>
                        <td class="trnormal"><?= $emp['emp_dob']; ?></td>
                        <td class="trnormal"><?= $emp['mobile']; ?></td>
                    </tr>
                    <tr>
                        <th>Department</th>
                        <th>Educational Qualification</th>
                        <th>Address</th>
                        <th>&nbsp;</th>
                        <th>&nbsp;</th>
                    </tr>
                    <tr>
                        <td class="trnormal"><?= $emp['department']; ?></td>
                        <td class="trnormal"><?= $emp['e_qualification']; ?></td>
                        <td class="trnormal"><?= $local['name']; ?></td>
                        <td class="trnormal">&nbsp;</td>
                        <td class="trnormal">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php
    }
else if ($content == 'asignadm_no')
    {

    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);

    $classarr = classes_list();
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="st_id" value="<?= $id ?>" />
        <input type="hidden" name="add_admission" value="true" />
        <table class="table">
            <tbody>
                <tr>
                    <td colspan="5"><h3 style="margin:0px;">
                            <?= $student['name']; ?>
                        </h3></td>
                </tr>
                <tr>
                    <th>Father's Name</th>
                    <th>Mother's Name</th>
                    <th>Date of Birth</th>
                    <th>Class</th>
                </tr>
                <tr>
                    <td class="trnormal"><?= $student['f_name']; ?></td>
                    <td class="trnormal"><?= $student['m_name']; ?></td>
                    <td class="trnormal"><?= date('d M,Y', strtotime($student['birth_date']));
                            ?></td>
                    <td class="trnormal"><?= $classarr[$student['adm_classno']]; ?></td>
                </tr>
                <tr>
                    <th>Admission Number</th>
                    <td><input type="text" class="form-control" size="15" id="adm_no" name="adm_no" required></td>
                    <td><button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button></td>
                    <td><div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div></td>
                </tr>
            </tbody>
        </table>
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var adm_no = $("#adm_no");
                var errordv = $("#process");
                var errors = '';
                if (adm_no.val() == '') {
                    $("#ajaxForm").append('<div class="errorDiv text-red">Admission no. is required.</div>');
                    errors = 'true';
                } else {
                    errordv.html('');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                errordv.show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            $('#st_<?= $id; ?>').slideUp('slow');
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        errordv.hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        errordv.hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'std_profile')
    {
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);

    //print_r($student);
    // print_r($student);

    $_SESSION['s_id'] = $student['student_id'];

    $tpt_stu_data = Transport::get_transport_stu($MSID, $id, $oCurrentUser->mydate)->fetch(PDO::FETCH_OBJ);


    $disc_stu_data = Transport::get_discounted_stu($MSID, $id, $oCurrentUser->mydate)->fetch(PDO::FETCH_OBJ);




    /* echo "<pre>";
      print_r($tpt_stu_data_fetch);
      echo "</pre>"; */

    $classes = Master::get_class_names2($MSID, $student['class'])->fetch();


    // $classarr = classes_list();
    // print_r($classarr);
//get locality
//    $local = Master::get_locality($MSID, $student['village'], 1)->fetch();
    $placeholderimg = '';
    $student['gender'] == 'M' ? $placeholderimg = ASSETS_FOLDER . '/img/avatar5.png' : $placeholderimg = ASSETS_FOLDER . '/img/avatar3.png';
    $student['photo'] ? $placeholderimg = $student['photo'] : '';
    ?>
    <style>
        td, th {
            border: medium none !important;
        }
        .trnormal{
            font-weight: normal;
            color:#3c8dbc;
        }
    </style>

    <div class="row">
        <div class="col-md-10"> </div>
        <div class="col-md-2"><a class="btn btn-block bg-olive" href="<?= CLIENT_URL ?>/students/editprofile/<?= $student['student_id'] ?>">Edit Profile</a></div>
    </div>
    <div class="row">

        <div class="col-md-4"> <img  class="img-circle" src="<?= $placeholderimg; ?>" style="height: 150px; width:150px"> </div>
        <div class="col-md-8">
            <table	 class="table">
                <tbody>
                    <tr>
                        <td colspan="5"><h3 style="margin:0px;">
                                <?= $student['name']; ?>
                            </h3></td>
                    </tr>
                    <tr>
                        <th>Student Id</th>
                        <th>Class</th>
                        <th>Locality</th>
                        <th>DOB</th>
                        <th>SMS Mobile</th>
                    </tr>
                    <tr>
                        <td class="trnormal"><?= $student['student_id']; ?></td>
                        <td class="trnormal"><?= $classes['class_name']; ?></td>
                        <td class="trnormal"><?= $student['village']; ?></td>
                        <td class="trnormal"><?= date('d M,Y', strtotime($student['birth_date']));
                                ?></td>
                        <td class="trnormal"><?= $student['mobile_sms']; ?></td>
                    </tr>
                    <tr>
                        <th>Father's Name</th>
                        <th>&nbsp;</th>
                        <th>Mobile</th>
                        <th>Occupation</th>
                        <th>Discount</th>
                    </tr>
                    <tr>
                        <td class="trnormal"><?= $student['f_name']; ?></td>
                        <td class="trnormal">&nbsp;</td>
                        <td class="trnormal"><?= $student['f_mobile']; ?></td>
                        <td class="trnormal"><?= $student['f_occupation']; ?></td>
                        <td class="trnormal">
                            <?php
                            if (@$disc_stu_data->discount_id)
                                {
                                $dis_stn = Transport::get_discount_names($MSID, $disc_stu_data->discount_id)->fetch(PDO::FETCH_OBJ);
                                echo $dis_stn->name;
                                }
                            else
                                {
                                echo "No";
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Mother's Name</th>
                        <th>&nbsp;</th>
                        <th>Mobile</th>
                        <th>Occupation</th>
                        <th>Transportation</th>
                    </tr>
                    <tr>
                        <td class="trnormal"><?= $student['m_name']; ?></td>
                        <td class="trnormal">&nbsp;</td>
                        <td class="trnormal"><?= $student['m_mobile']; ?></td>
                        <td class="trnormal"><?= $student['m_occupation']; ?></td>
                        <td class="trnormal"><?php
                            //echo $tpt_stu_data_fetch['tpt_stn_id'];
                            if (@$tpt_stu_data->tpt_stn_id)
                                {
                                $tpt_stn = Transport::get_tptstations($MSID, $tpt_stu_data->tpt_stn_id)->fetch(PDO::FETCH_OBJ);
                                echo "Upto ", $tpt_stn->station_name;
                                }
                            else
                                {
                                echo "No";
                                }



                            //$student['transportation'] == "1" ? "Yes" : "No";
                            ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col-md-12"><?php
                $design_RFormDesigns = Student::student_designs($oCurrentSchool->RFormDesigns)->fetch(PDO::FETCH_OBJ);
                $design_FBKDesigns = Student::student_designs($oCurrentSchool->FBKDesigns)->fetch(PDO::FETCH_OBJ);

                $reportcard_hyp = Student::student_fee_designs($oCurrentSchool->ReportcrdDesign)->fetch(PDO::FETCH_OBJ);
                $reportcard = Student::student_fee_designs($oCurrentSchool->ReportcrdDesign)->fetch(PDO::FETCH_OBJ);
//                print_r($reportcard_hyp);
                ?>
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/registration-form/<?= $design_RFormDesigns->reg ?>/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 3px;">Registration Form</a>
                <?php
                $get_childern = Parents::get_same_parent($student['parent_id']);

                @$row_count = $get_childern->rowCount();

                if (@$row_count > 1)
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/child/<?= $student['parent_id']; ?>" data-ms="modal" data-title="Siblings" style="margin: 0 0 0 3px;">Sibling(s)</a>
                    <?php
                    }
                ?> 


                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/fee-book/<?= $design_FBKDesigns->fee_book ?>/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 3px;">FeeBook</a>
                <?php
                if ($oCurrentSchool->SeprateTPTFBook == "1" && @$tpt_stu_data->tpt_stn_id)
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/fee-book/<?= $design_FBKDesigns->fee_book ?>/<?= $student['student_id']; ?>/tpt" target="_blank"  style="margin: 0 0 0 3px;">Tpt FeeBook</a>
                <?php } ?><a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/feevoucher" target="_blank"  data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
    <!--                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/half-yearly/<?= $student['student_id']; ?>"  target="_blank" style="margin: 0 0 0 10px;">Half Yearly</a>
    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/final-report/<?= $student['student_id']; ?>"  target="_blank" style="margin: 0 0 0 10px;">Report Card</a>-->
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/report-card/<?= $reportcard_hyp->hyap ?>/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 3px;">Half Yearly</a>
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/report-card/reportcardS1.php/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 3px;">Report Card</a>
            </div>
        </div>
        <div class='row'><div class="col-md-12">&nbsp;</div></div>
        <div class="row">
            <div class="col-md-12"><a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/birth-certificate/<?php echo @$design_RFormDesigns->birth_certificate ? $design_RFormDesigns->birth_certificate : "birth_certificate.php" ?>/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 10px;">Birth Certificate</a>
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/confidential-letter/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 3px;">Confidential Letter</a>

                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/character-certificate/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 3px;">Character Certificate</a>
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/tc/<?php echo @$design_RFormDesigns->tc ? $design_RFormDesigns->tc : "tc_info_pr.php" ?>/<?= $student['student_id']; ?>" target="_blank"  style="margin: 0 0 0 3px;">TC</a>
            </div>  </div>
        <?php // print_r($design_RFormDesigns);           ?>
    </div>
    <?php
    }
else if ($content == 'enrollment_std')
    {
    $sAdmission = new Admission();
    $students = $sAdmission->get_enrolled_std($MSID, '', '', '', $_POST['classid']);
    $classsections = Master::get_schools_section($MSID, '', $_POST['classid']);
    $clsectiondrp = Master::get_schools_section($MSID, '', $_POST['classid']);
    /* foreach($students as $key=>$value){

      } */
    ?>
    <div class="row">
        <div class="col-xs-4">
            <div class="form-group" style="text-align:right;">
                <input type="radio" name="rejectselect" value="select" checked="checked"/>Select &nbsp;<input type="radio" name="rejectselect" value="reject" />Reject
            </div>
            <?php
            if ($clsectiondrp->rowCount() > 0)
                {
                ?>
                <div class="form-group">
                    <select name="sectionss" id="slt_sct" class="form-control">
                        <option value="">Select section</option>
                        <?php
                        while ($rowv = $clsectiondrp->fetch())
                            {
//                            $secname = Master::get_sections($rowv['sec_id'])->fetch(PDO::FETCH_ASSOC);
                            ?>
                            <option value="<?= $rowv['id']; ?>"><?= $rowv['display_name']; ?></option>
                        <?php } ?>
                    </select>

                </div>
            <?php } ?>
        </div>
        <?php
        if ($classsections->rowCount() > 0)
            {
            ?>
            <div class="col-xs-8"><table class="table table-hover">
                    <tr>
                        <th>Section</th>
                        <th>Seats</th>
                        <th>Availability</th>
                    </tr>
                    <?php
                    while ($rowv = $classsections->fetch())
                        {
//                        print_r($rowv);
//                        $secname = Master::get_sections($rowv['id'])->fetch(PDO::FETCH_ASSOC);
                        $secname = $rowv['display_name'];

                        $total = Student::get_std_available($MSID, $rowv['class_id'], $rowv['sec_name'])->rowCount();
                        if (@$total > 0)
                            {
                            $total_s = Student::get_std_available($MSID, $rowv['class_id'], $rowv['sec_name'])->fetch(PDO::FETCH_ASSOC);
                            $totalstd = $total_s['total'];
                            }
                        else
                            {
                            $totalstd = 0;
                            }
                        $available = $rowv['sec_seats'] - $totalstd;
                        ?>
                        <tr>
                            <td><?= $rowv['display_name']; ?></td>
                            <td><?= $rowv['sec_seats']; ?></td>
                            <td><?= $available >= 0 ? $available : '0'; ?></td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        <?php } ?>     
    </div>
    <div class="row">
        <div class="col-xs-12">
            <form name="assign_adm_no" id="ajaxForm" method="post" action="">
                <input type="hidden" name="enrollmnt_selection" value="true" />
                <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <table class="table table-hover">
                    <tr>
                        <th>Sr.No.</th>
                        <th><input type="checkbox" name="selectall" id="selectall" /></th>
                        <th>ID</th>
                        <th>Admission No.</th>
                        <?php
                        if ($classsections->rowCount() > 0)
                            {
                            ?>
                            <th>Section</th>
                        <?php } ?>
                        <th>Name</th>
                        <th>Father Name</th>
                        <th>Mother Name</th>
                        <th></th>
                    </tr>
                    <?php
                    $i = 1;
                    while ($rowv = $students->fetch())
                        {
                        $local = Master::get_locality($MSID, $rowv['village'], 1)->fetch();
                        ?>
                        <tr id="st_<?= $rowv['student_id']; ?>">
                            <td><?= $i ?></td>
                            <td><input type="checkbox" class="std_chked" name="student_ids[]" value="<?= $rowv['student_id']; ?>" /><input type="hidden" class="student_sec" name="student_sec_<?= $rowv['student_id']; ?>" value="" /></td>
                            <td><?= $rowv['student_id']; ?></td>
                            <td><input type="text" name="adm_no_<?= $rowv['student_id']; ?>" value="<?= $rowv['admno']; ?>" /></td>
                            <?php
                            if ($classsections->rowCount() > 0)
                                {
                                ?>
                                <td class="sec_display_<?= $rowv['student_id']; ?>">--</td>
                            <?php } ?>
                            <td><?= $rowv['name']; ?></td>
                            <td><?= $rowv['f_name']; ?></td>
                            <td><?= $rowv['m_name']; ?></td>
                            <td><a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $rowv['student_id']; ?>" data-ms="modal" data-title="Student Profile">View</a></td>
                        </tr>
                        <?php
                        $i++;
                        }
                    ?>
                    <tr><td colspan="9" align="center" id="selection"><input type="hidden" name="submitfrm" value="true" /><button type="submit" id="ajaxSubmit" class="btn bg-orange btn-flat">Submit</button>&nbsp;<a class="btn bg-olive btn-flat"  href="<?= CLIENT_URL ?>/selection" >Refresh</a></td></tr>
                </table>
            </form> 
            <?php /* ?><td><a href="<?= CLIENT_URL ?>/ajax-page-load/asignadm_no/<?= $rowv['student_id']; ?>" data-ms="modal" data-title="Assign admission number" class="btn bg-orange btn-flat">Adm No.</a><a class="btn bg-olive btn-flat" style="margin:0 10px;" href="<?= CLIENT_URL ?>/ajax-page-load/std_profile/<?= $rowv['student_id']; ?>" data-ms="modal" data-title="Student Profile">View</a><a data-reject="confirm" class="btn btn-danger btn-flat" href="<?= CLIENT_URL ?>/admissions/<?= $rowv['student_id']; ?>">Reject</a></td><?php */ ?>
        </div>
    </div>    
    <script>
        $(function () {
            //select / reject radio buttons
            $('input[name="rejectselect"]').click(function (event) {
                var values = $(this).val();
                var selkt = $('#selection');
                selkt.html('');
                if ($(this).is(':checked')) {
                    if (values == 'select') {
                        selkt.html('<input type="hidden" name="submitfrm" value="true" /><button type="submit" id="ajaxSubmit" class="btn bg-orange btn-flat">Submit</button>&nbsp;<a class="btn bg-olive btn-flat"  href="<?= CLIENT_URL ?>/selection" >Refresh</a>');
                    } else {
                        selkt.html('<input type="hidden" name="rejectfrm" value="true" /><button type="submit" id="ajaxReject" class="btn btn-danger btn-flat">Reject</button>&nbsp;<a class="btn bg-olive btn-flat"  href="<?= CLIENT_URL ?>/selection" >Refresh</a>');
                    }
                } else {

                }
            });
            ///select all checkbox
            $('#selectall').click(function (event) {
                var sec_id = $('#slt_sct').val();
                var sec_text = sec_id != '' ? $('#slt_sct').find("option:selected").text() : '--';
                if (this.checked) {
                    $('.std_chked').each(function () {
                        this.checked = true;
                        var std_id = $(this).val();
                        $('input[name="student_sec_' + std_id + '"]').val(sec_id);
                        $('.sec_display_' + std_id).text(sec_text);
                    });
                } else {
                    $('.std_chked').each(function () {
                        this.checked = false;
                        var std_id = $(this).val();
                        $('input[name="student_sec_' + std_id + '"]').val('');
                        $('.sec_display_' + std_id).text('--');
                    });
                }
            });
            //select sections from dropdown
            $('#slt_sct').on('change', function () {
                var sec_id = $(this).val();
                var sec_text = sec_id != '' ? $(this).find("option:selected").text() : '--';
                if ($('.std_chked').is(':checked')) {
                    $('.std_chked').each(function () {
                        var std_id = (this.checked ? $(this).val() : "");
                        if (std_id != '') {
                            $('input[name="student_sec_' + std_id + '"]').val(sec_id);
                            $('.sec_display_' + std_id).text(sec_text);
                        } else {
                            $('input[name="student_sec_' + std_id + '"]').val('');
                            $('.sec_display_' + std_id).text('--');
                        }
                    });
                } else {
                    alert('Please select student from list.');
                }
            });
            $('.std_chked').click(function () {
                var sec_id = $('#slt_sct').val();
                var sec_text = sec_id != '' ? $('#slt_sct').find("option:selected").text() : '--';
                var std_id = $(this).val();
                if ($(this).is(':checked')) {
                    $('input[name="student_sec_' + std_id + '"]').val(sec_id);
                    $('.sec_display_' + std_id).text(sec_text);
                } else {
                    $('input[name="student_sec_' + std_id + '"]').val('');
                    $('.sec_display_' + std_id).text('--');
                }
            });
            //submit form 
            $('#ajaxForm').on('click', '#ajaxSubmit', function () {
                if ($('.std_chked').is(':checked')) {
                    var errormsg = '';
                    $('.std_chked').each(function () {
                        var std_id = $(this).val();
                        var std_sec_id = $('input[name="student_sec_' + std_id + '"]').val();
                        var std_adm_no = $('input[name="adm_no_' + std_id + '"]').val();
    <?php
    if ($classsections->rowCount() > 0)
        {
        ?>
                            if (std_adm_no == '' || std_sec_id == '') {
                                errormsg = 'error true';
                                return false;
                            }
        <?php
        }
    else
        {
        ?>
                            if (std_adm_no == '') {
                                errormsg = 'error true';
                                return false;
                            }
    <?php } ?>
                    });
                    if (errormsg != '') {
                        alert('Admission no and section is required for selected student.');
                        return false;
                    }
                    var datastring = $("#ajaxForm").serialize();
                    ///ajax code
                    $('.loading-div').show();
                    $.ajax({
                        type: "POST", // type
                        url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                        data: datastring, // post data
                        success: function (responseText) { // get the response
                            responseText = $.trim(responseText);
                            if (responseText != 'error') {
                                location.reload(true);
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                            }
                            $('.loading-div').hide();
                        }, // end success
                        error: function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                            }
                            $('.loading-div').hide();
                        }
                    });
                    // end 
                } else {
                    alert('Please select student from list.');
                }
                return false;
            });
            //reject students
            $('#ajaxForm').on('click', '#ajaxReject', function () {
                if ($('.std_chked').is(':checked')) {
                    var datastring = $("#ajaxForm").serialize();
                    ///ajax code
                    $('.loading-div').show();
                    $.ajax({
                        type: "POST", // type
                        url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                        data: datastring, // post data
                        success: function (responseText) { // get the response
                            responseText = $.trim(responseText);
                            if (responseText != 'error') {
                                location.reload(true);
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                            }
                            $('.loading-div').hide();
                        }, // end success
                        error: function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                            }
                            $('.loading-div').hide();
                        }
                    });
                    // end 
                } else {
                    alert('Please select student from list.');
                }
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'selection_std')
    {
    $sAdmission = new Admission();
    $students = $sAdmission->get_enrolled_std($MSID, '', '', '', $_POST['classid']);
    $classsections = Master::get_schools_section($MSID, '', $_POST['classid']);
    //$classsections->rowCount()
    ?>

    <?php
    if ($classsections->rowCount() > 1 && $oCurrentSchool->section != '0')
        {
        ?><div class="col-md-6">
            <div class="form-group">
                <label>Select section<span class="text-red">*</span></label>
                <select id="aclass" name="student[section]" class="form-control "   required>

                    <?php
                    while ($rowv = $classsections->fetch())
                        {
                        $total = Student::get_std_available($MSID, $rowv['class_id'], $rowv['sec_name'])->rowCount();
                        if (@$total > 0)
                            {
                            $total_s = Student::get_std_available($MSID, $rowv['class_id'], $rowv['sec_name'])->fetch(PDO::FETCH_ASSOC);
                            $totalstd = $total_s['total'];
                            }
                        else
                            {
                            $totalstd = 0;
                            }
                        $available = $rowv['sec_seats'] - $totalstd;
                        ?>
                        <option value="<?= $rowv['section_id'] ?>"><?= $rowv['sec_name']; ?></option>

                    <?php } ?>  
                </select>
                <a href="<?= CLIENT_URL ?>/students" target="_blank"><b>Check Section</b></a>
            </div>



            <?php
            }
        else if ($classsections->rowCount() == 1)
            {
            while ($rowv = $classsections->fetch())
                {
                ?>
                <input type="hidden" value="<?= $rowv['id']; ?>"  name="student[section]">
                <?php
                }
            }
        ?>




        <?php
        }
    else if ($content == 'paging')
        {
        ?>

        <?php
// DB table to use
        $table = 'ms_tpt_stations';

// Table's primary key
        $primaryKey = 'station_id';
        ?>
        <?php
        }
    else if ($content == 'registration_form')
        {
        ?>
        <?php
        $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
        $classarr = classes_list();
        $category = Master::get_category($MSID, $student['category'], 1)->fetch(PDO::FETCH_ASSOC);


        $placeholderimg = '';
        $student['gender'] == 'M' ? $placeholderimg = ASSETS_FOLDER . '/img/avatar5.png' : $placeholderimg = ASSETS_FOLDER . '/img/avatar3.png';
        $student['photo'] ? $placeholderimg = UPLOADS_FOLDER . '/10046/' . $student['photo'] : '';
        ?>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
            <title></title>
            <script language="javascript">
                function printpage()
                {
                    window.print();
                }
            </script>
        </head>

        <body>

            <form id="contactform" name="contactform" method="post" action="admin.php">
                <table width="674" background="" style="background-size:45%; background-position:center; background-repeat:no-repeat" border="1" align="center" cellpadding="2" cellspacing="2">
                    <tr>
                        <td width="100%"><table width="647" height="794" align="center" bordercolor="#2A3F00">
                                <tr align="left" valign="top">
                                    <td width="652" height="133">
                                        <table width="100%" align="center" cellpadding="2" cellspacing="2">
                                            <tr>
                                                <td height="22" colspan="3" align="center"><span class="m1"><?= $oCurrentSchool->name ?></span></td>
                                            </tr>
                                            <tr>
                                                <td width="30%" height="101" align="center" valign="middle"><img src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" width="90"/></td>
                                                <td width="30%" valign="top"><table width="98%" height="74" border="0" align="center">
                                                        <tr>
                                                            <td width="402" height="25" align="center" ><span class="b1"><?= $oCurrentSchool->place ?></span></td>
                                                        </tr>
                                                        <tr>
                                                            <td height="20" align="center" class="b1"><span class="t1"><?= $oCurrentSchool->board ?></span></td>
                                                        </tr>
                                                        <tr>
                                                            <td height="21" align="center" class="t1"><!--Registration Form--></td>
                                                        </tr>
                                                    </table></td>
                                                <td width="40%" align="right" valign="top"><table width="100%" align="right">
                                                        <tr>
                                                            <td align="center">Phone No:</td>
                                                            <td align="right" class="r"><strong><?= $oCurrentSchool->phone ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="80" class="r">Affiliation No.:</td>
                                                            <td width="82" align="right" class="r"><strong><?= $oCurrentSchool->affNo ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="r"> School Code :</td>
                                                            <td align="right"><span class="r"><strong><?= $oCurrentSchool->schoolNo ?></strong></span></td>
                                                        </tr>
                                                        <tr>
                                                            <td><span class="r">Recognition No.:</span></td>
                                                            <td align="right"><strong class="r"><?= $oCurrentSchool->recNo ?></strong></td>
                                                        </tr>
                                                    </table></td>
                                            </tr>


                                        </table>







                                    </td>
                                </tr>
                                <tr align="left" valign="top">
                                    <td height="4" align="left"><hr/></td>
                                </tr>          <tr align="left" valign="top">
                                    <td height="220"><table width="100%" height="46" border="0" align="left">
                                            <tr valign="top" class="st4">
                                              <td width="34" align="left" valign="top"><img    src="<?= $placeholderimg; ?>" width="105" height="117"><!--<img    src=""  width="99" height="126">-->          


                                                </td>
                                                <td width="623" height="42"><table width="100%" height="212" border="0" align="center">
                                                        <tr valign="top" class="st4">
                                                            <td height="49" colspan="3" style="margin: 0;">&nbsp&nbsp&nbsp<?= $student['name']; ?> <br />                      <br /></td>
                                                        </tr>
                                                        <tr valign="top" class="st4">
                                                            <td width="30%" height="36">&nbsp&nbsp&nbspStudent&nbsp;Id:&nbsp;&nbsp;<strong><?= $student['student_id'] ?></strong> &nbsp;</td>
                                                            <td width="33%">Parent's ID:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $student['parent_id'] ?>&nbsp;</strong></td>
                                                            <td width="37%">Date of Birth: &nbsp; <strong><?= date('d M,Y', strtotime($student['birth_date']));
        ?>                    </strong></td>
                                                        </tr>
                                                        <tr valign="top" class="st4">
                                                            <td height="36">&nbsp&nbsp&nbspAdmission No: <strong><?= $student['admno'] ?></strong></td>
                                                            <td height="36">Admission class: <strong><?= $classarr[$student['adm_classno']] ?></strong></td>
                                                            <td height="36">Admission Date: <strong><?= date('d M,Y', strtotime($student['adm_date']));
        ?></strong></td>
                                                        </tr>
                                                        <tr valign="top" class="st4">
                                                            <td height="36">&nbsp&nbsp&nbspCategory:&nbsp;&nbsp;&nbsp;&nbsp;<strong><?= $category['name'] ?></strong></strong></td>
                                                            <td height="36">House:<strong>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    <?= $student['house'] ?>                    
                                                                </strong></td>                                          </tr>
                                                    </table></td>
                                            </tr>
                                        </table></td>
                                </tr>

                                <tr align="left" valign="top">
                                    <td height="211"><table width="95%" height="221" border="0" align="center">
                                            <tr valign="top" class="b1">
                                                <td height="49" colspan="2" align="center" valign="middle"><u>Father's Info:</u>
                                                </td>
                                                <td colspan="2" align="center" valign="middle"><u>Mother's Info:</u></td>
                                            </tr>

                                            <tr valign="top">
                                                <td width="97" height="27"><span class="st4">Name </span></td>
                                                <td width="283"><span class="st4"><strong>Mr. <?= $student['f_name'] ?></strong></span></td>
                                                <td width="111"><span class="st4">Name </span></td>
                                                <td width="270"><span class="st4"><strong>Mrs. <?= $student['m_name'] ?></strong></span></td>
                                            </tr>
                                            <tr valign="top">
                                                <td height="31"><span class="st4">Occupation</span></td>
                                                <td><span class="st4"><strong><?= $student['f_occupation'] ?></strong></span></td>
                                                <td width="111"><span class="st4">Occupation</span></td>
                                                <td width="270"><span class="st4"><strong><?= $student['m_occupation'] ?></strong></span></td>
                                            </tr>
                                            <tr valign="top">
                                                <td height="30"><span class="st4">Qualification</span></td>
                                                <td><span class="st4"><strong><?= $student['f_qualification'] ?></strong></span></td>
                                                <td width="111"><span class="st4">Qualification</span></td>
                                                <td width="270"><span class="st4"><strong><?= $student['m_qualification'] ?></strong></span></td>
                                            </tr>
                                            <tr valign="top">
                                                <td height="33"><span class="st4">Mobile No:</span></td>
                                                <td><span class="st4"><strong><?= $student['f_mobile'] ?></strong></span></td>
                                                <td><span class="st4">Mobile No:</span></td>
                                                <td><span class="st4"><strong><?= $student['m_mobile'] ?></strong></span></td>
                                            </tr>
                                            <tr valign="top">
                                                <td height="31"><span class="st4">Ph.Office</span></td>
                                                <td><span class="st4"><strong><?= $student['phone_home'] ?></strong></span></td>
                                                <td width="111"><span class="st4">Ph.Office</span></td>
                                                <td width="270"><span class="st4"><?= $student['phone_home'] ?><strong></strong></span></td>
                                            </tr>
                                        </table></td>
                                </tr>
                                <tr align="left" valign="top">
                                    <td height="118"><strong class="st4"></strong><span class="b1"><u>Local Address: </u></span><br />
                                        <br />
                                        <?php
//                                        print_r($student);
                                        $locality = Master::get_locality($MSID, $student['vilage_id'], $status);
                                        ?>
                                        <table width="667" height="28" border="0" align="center">
                                            <tr valign="top" class="st4">
                                                <td width="367" height="24">Address/Village/city<strong><span class="st4"><?= $student['village'] ?> <?= $student['address_line2'] ?>   <?= $student['address'] ?> </span></strong></td>
                                                <td width="272">:<strong><span class="st4"></span></strong></td>
                                            </tr>
                                        </table> 
                                    </td> 
                                </tr>
                                <tr align="left" valign="top">
                                    <td height="64"><table width="667" border="0" align="center">
                                            <tr>
                                                <td width="209" height="21">.....................................................</td>
                                                <td width="208">.....................................................</td>
                                                <td width="218">.....................................................</td>
                                            </tr>
                                            <tr valign="top" class="st4">
                                                <td height="35"><div align="center">Father/Guardian</div></td>
                                                <td width="208"><div align="center">Mother</div></td>
                                                <td width="218"><div align="center">Principal</div></td>
                                            </tr>
                                        </table></td>
                                </tr>
                            </table></td>
                    </tr>
                </table>
                <br>

                <input type="button" value="Print" onClick="printpage();">
                <br>
                <br> <br>

                <div class="row">
                    <div class="col-md-12">
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                        <?php
                        if ($content != "registration_form")
                            {
                            ?>
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 10px;">Registration Form</a>
                            <?php
                            } if ($content != "feebook")
                            {
                            ?>        
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                            <?php
                            } if ($content != "fee_ac")
                            {
                            ?>
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                            <?php
                            } if ($content != "birth_certificate")
                            {
                            ?>
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                            <?php
                            } if ($content != "tc")
                            {
                            ?>
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                            <?php
                            } if ($content != "history")
                            {
                            ?>
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                            <?php
                            } if ($content != "confidential_letter")
                            {
                            ?>
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                            <?php
                            } if ($content != "character_certificate")
                            {
                            ?>
                            <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                        <?php } ?></div>
                </div>

            </form>

        </body>
    </html>




    <?php
    }
else if ($content == 'feebook')
    {
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    ?><html>
        <body>
            <h3>Comming Soon...</h3>
            <br>
            <br>
            <div class="row">
                <div class="col-md-12">
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                    <?php
                    if ($content != "registration_form")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 10px;">Registration Form</a>
                        <?php
                        } if ($content != "feebook")
                        {
                        ?>        
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                        <?php
                        } if ($content != "fee_ac")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                        <?php
                        } if ($content != "birth_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                        <?php
                        } if ($content != "tc")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                        <?php
                        } if ($content != "history")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                        <?php
                        } if ($content != "confidential_letter")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                        <?php
                        } if ($content != "character_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                    <?php } ?></div>
            </div>
        </body>
    </html>

    <?php
    }
else if ($content == 'fee_ac')
    {

    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    ?><html>
        <body>
            <h3>Comming Soon...</h3>
            <br>
            <br>
            <div class="row">
                <div class="col-md-12">
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                    <?php
                    if ($content != "registration_form")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 3px;">Registration Form</a>
                        <?php
                        } if ($content != "feebook")
                        {
                        ?>        
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                        <?php
                        } if ($content != "fee_ac")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                        <?php
                        } if ($content != "birth_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                        <?php
                        } if ($content != "tc")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                        <?php
                        } if ($content != "history")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                        <?php
                        } if ($content != "confidential_letter")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                        <?php
                        } if ($content != "character_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                    <?php } ?></div>
            </div>
        </body>
    </html>




    <?php
    }
else if ($content == 'birth_certificate')
    {
    ?>
    <?php
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    $classarr = classes_list();
    ?>


    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <style type="text/css">
            .style2 {	 font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 19px;
            }
            .style19 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; 
            }
            .st4 { 
                font-family: Verdana, Arial, Helvetica, sans-serif;
                font-size: 13px;
            }
            .style15 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 17px; }
        </style>
        <script language="javascript">
            function printpage()
            {
                window.print();
            }
        </script>
    </head>
    <body><table width="674"  border="1" align="center">
            <tr>
                <td width="642" height="516"><table width="674">
                        <tr align="left" valign="top">
                            <td width="652" height="133">
                                <table width="100%" align="center" cellpadding="2" cellspacing="2">
                                    <tr>
                                        <td height="22" colspan="3" align="center"><span class="m1"><?= $oCurrentSchool->name ?></span></td>
                                    </tr>
                                    <tr>
                                        <td width="30%" height="101" align="center" valign="middle"><img src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" width="90"/></td>
                                        <td width="30%" valign="top"><table width="98%" height="74" border="0" align="center">
                                                <tr>
                                                    <td width="402" height="25" align="center" ><span class="b1"><?= $oCurrentSchool->place ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td height="20" align="center" class="b1"><span class="t1"><?= $oCurrentSchool->board ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td height="21" align="center" class="t1"><!--Registration Form--></td>
                                                </tr>
                                            </table></td>
                                        <td width="40%" align="right" valign="top"><table width="100%" align="right">
                                                <tr>
                                                    <td align="center">Phone No:</td>
                                                    <td align="right" class="r"><strong><?= $oCurrentSchool->phone ?></strong></td>
                                                </tr>
                                                <tr>
                                                    <td width="80" class="r">Affiliation No.:</td>
                                                    <td width="82" align="right" class="r"><strong><?= $oCurrentSchool->affNo ?></strong></td>
                                                </tr>
                                                <tr>
                                                    <td class="r"> School Code :</td>
                                                    <td align="right"><span class="r"><strong><?= $oCurrentSchool->schoolNo ?></strong></span></td>
                                                </tr>
                                                <tr>
                                                    <td><span class="r">Recognition No.:</span></td>
                                                    <td align="right"><strong class="r"><?= $oCurrentSchool->recNo ?></strong></td>
                                                </tr>
                                            </table></td>
                                    </tr>


                                </table>







                            </td>
                        </tr>
                        <tr>
                            <td colspan="4"  ><hr />
                                <table width="100%" height="319" border="0" align="center">
                                    <tr valign="top" class="st4">
                                        <td height="42" colspan="3" align="center" class="style15"><table width="406" border="0">
                                                <tr>
                                                    <td width="302" align="center"><strong>TO WHOM IT MAY CONCERN</strong></td>
                                                </tr>
                                                <tr>
                                                    <td width="302" align="center"><hr /></td>
                                                </tr>
                                            </table>
                                            <br />
                                            <br /></td>
                                    </tr>
                                    <tr valign="top" class="st4">
                                        <td height="139" colspan="3">&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <p>This is to certify that <strong>
                                                    Master                        <?= $student['name'] ?></strong>
                                                S/O
                                                <strong>Mr. <?= $student['f_name']; ?></strong> and <strong>Mrs. <?= $student['m_name']; ?></strong> Of  &nbsp;is bonafide student of this school of class 
                                                <strong>
                                                    <?= $classarr[$student['adm_classno']] ?>                   </strong>. <br />
                                                &nbsp;&nbsp;<br />

                                                His
                                                Admission No as per school record is  <strong>
                                                    <?= $student['admno'] ?></strong> and date of birth is <strong>

                                                    <?= date('d M,Y', strtotime($student['birth_date'])) ?></strong></p></td>
                                    </tr>
                                    <tr valign="top" class="st4">
                                        <td width="227" rowspan="2" valign="middle"><strong>Dated:
                                                <?= date('d/y/m') ?>                      </strong></td>
                                        <td width="227" valign="bottom" align="center">.....................</td>
                                        <td width="200" height="50" align="center" valign="bottom">.....................</td>
                                    </tr>
                                    <tr valign="top" class="st4">
                                        <td width="227" valign="top" align="center"><strong>Checked by</strong></td>
                                        <td align="center"><strong>Principal</strong></td>
                                    </tr>
                                </table></td></tr>
                    </table></td>
            </tr>
        </table>
        <br>
        <br>
        <div class="row">
            <div class="col-md-12">
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                <?php
                if ($content != "registration_form")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 10px;">Registration Form</a>
                    <?php
                    } if ($content != "feebook")
                    {
                    ?>        
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                    <?php
                    } if ($content != "fee_ac")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                    <?php
                    } if ($content != "birth_certificate")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                    <?php
                    } if ($content != "tc")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                    <?php
                    } if ($content != "history")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                    <?php
                    } if ($content != "confidential_letter")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                    <?php
                    } if ($content != "character_certificate")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                <?php } ?></div>
        </div>
    </body>
    </html>




    <?php
    }
else if ($content == 'tc')
    {
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    ?>
    <html>
        <body>
            <h3>Comming Soon...</h3>
            <br>
            <br>
            <div class="row">
                <div class="col-md-12">
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                    <?php
                    if ($content != "registration_form")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 10px;">Registration Form</a>
                        <?php
                        } if ($content != "feebook")
                        {
                        ?>        
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                        <?php
                        } if ($content != "fee_ac")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                        <?php
                        } if ($content != "birth_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                        <?php
                        } if ($content != "tc")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                        <?php
                        } if ($content != "history")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                        <?php
                        } if ($content != "confidential_letter")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                        <?php
                        } if ($content != "character_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                    <?php } ?></div>
            </div>
        </body>
    </html>





    <?php
    }
else if ($content == 'history')
    {
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    $student_history = Student::get_stdnt_history($MSID, '', $student['student_id']);
    $totalrecords = $student_history->rowCount();
    ?> 
    <html>
        <body>

            <div class="box-body table-responsive no-padding">
                <!--<div class="row">-->
                <a class="btn btn-info btn-flat pull-right " data-title="Add history" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax-page-load/add_history/<?php echo $student['student_id']; ?>">Add history</a>
                <!--</div>-->
                <?php
                if ($totalrecords > 0)
                    {
                    ?>
                    <table class="table table-hover">
                        <tr>
                            <th>Sr No</th>
                            <th>Description</th>
                            <th>Rewards</th>
                            <th>Warning</th>
                            <th>Fine</th>
                            <th>Action</th>
                        </tr>
                        <tbody>
                            <?php
                            $i = 1;
                            while ($rowv = $student_history->fetch())
                                {
                                ?>
                                <tr>

                                    <td><?= $i ?></td>
                                    <td><?= $rowv['history']; ?></td>
                                    <td><?= $rowv['reward']; ?></td>
                                    <td><?php
                                        $worning = Student::get_history_worning($rowv['warning'])->fetch();
//                                   print_r($worning);
                                        echo $worning['description']
                                        ?></td>
                                    <td><?= $rowv['fine']; ?></td>
                                    <td><a class="btn btn-info btn-flat" data-title="Edit Remarks" data-ms="modal" href="<?= CLIENT_URL; ?>/ajax-page-load/update_remarks/<?php echo $rowv['id']; ?>">Edit</a>&nbsp;
                                        &nbsp; <a data-bb="confirm" class="btn btn-danger btn-flat" href="<?= CLIENT_URL; ?>/activities/delete/<?php echo $rowv['id']; ?>">Delete</a></td>

                                </tr>
                                <?php
                                $i++;
                                }
                            ?>
                        </tbody>

                    </table>
                    <?php
                    }
                else
                    {
                    echo '<div class="text-center margin">No records found.</div>';
                    }
                ?>
            </div>
            <br>
            <br>
            <div class="row">
                <div class="col-md-12">
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                    <?php
                    if ($content != "registration_form")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 10px;">Registration Form</a>
                        <?php
                        } if ($content != "feebook")
                        {
                        ?>        
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                        <?php
                        } if ($content != "fee_ac")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                        <?php
                        } if ($content != "birth_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                        <?php
                        } if ($content != "tc")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                        <?php
                        } if ($content != "history")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                        <?php
                        } if ($content != "confidential_letter")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                        <?php
                        } if ($content != "character_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                    <?php } ?></div>
            </div>
        </body>
    </html>





    <?php
    }
else if ($content == 'add_history')
    {
//    $student = Student::get_students($oCurrentUser->myuid, '1', )->fetch(PDO::FETCH_ASSOC);
//    print_r($student );
    $student_history = Student::get_stdnt_history($MSID, $id)->fetch(PDO::FETCH_OBJ);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="add_history" value="true" />
        <input type="hidden" name="id" value="<?= $student_history->id ?>" />
        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Description<span class="text-red">*</span></label>
                        <input type="text" name="history" size="30" class="form-control">
                    </div><div class="form-group">
                        <label>Rewords<span class="text-red">*</span></label>
                        <input type="text" name="reward" size="30" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Wornings<span class="text-red">*</span></label>
                        <select name="warning" id="warning" class="form-control">
                            <?php
//                            echo $student_history->warning;
                            while ($rowv = $history_worning->fetch())
                                {
                                ?>
                                <option value="<?= $rowv['id']; ?>" ><?= $rowv['description']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Fine<span class="text-red">*</span></label>
                        <input type="text" name="fine" size="30" class="form-control">
                    </div>
                </div>
                <!-- \col -->
            </div>
        </div>


        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            //                            location.reload();
                            //                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'update_remarks')
    {
//    $student = Student::get_students($oCurrentUser->myuid, '1', )->fetch(PDO::FETCH_ASSOC);
//    print_r($student );
    $student_history = Student::get_stdnt_history($MSID, $id)->fetch(PDO::FETCH_OBJ);
//    print_r($student_history);
    $history_worning = Student::get_history_worning();
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_remarks" value="true" />
        <input type="hidden" name="id" value="<?= $student_history->id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Description<span class="text-red">*</span></label>
                        <input type="text" name="history" value="<?= $student_history->history ?>"size="30" class="form-control">
                    </div><div class="form-group">
                        <label>Rewords<span class="text-red">*</span></label>
                        <input type="text" name="reward" value="<?= $student_history->reward ?>"size="30" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Wornings<span class="text-red">*</span></label>
                        <select name="warning" id="warning" class="form-control">
                            <?php
                            echo $student_history->warning;
                            while ($rowv = $history_worning->fetch())
                                {
                                if ($rowv['id'] == $student_history->warning)
                                    {
                                    $selected = 'selected="selected"';
                                    }
                                else
                                    {
                                    $selected = '';
                                    }
                                ?>
                                <option value="<?= $rowv['id']; ?>" <?= $selected; ?>><?= $rowv['description']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Fine<span class="text-red">*</span></label>
                        <input type="text" name="fine" value="<?= $student_history->fine ?>"size="30" class="form-control">
                    </div>
                </div>
                <!-- \col -->
            </div>
        </div>


        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            //                            location.reload();
                            //                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'confidential_letter')
    {
    ?>
    <?php
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    $classarr = classes_list();
    ?>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title></title>
        <script language="javascript">
            function printpage()
            {
                window.print();
            }
        </script>
        <style type="text/css">
            <!--
            .style190 {	color: #FFFFFF;

            }
            .style15 {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 24px; font-weight:900; }

            .st3 {

                font-family: Verdana, Arial, Helvetica, sans-serif;
                font-size: 13px;

            }.st2 {

                font-family: Verdana, Arial, Helvetica, sans-serif;
                font-size: 11px;

            }
            .b1 {
                font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 22px; font-weight:bold;
            }
            .c1 {
                font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 17px; font-weight:bold;
            }
            .st4 {
                font-family:Verdana, Geneva, sans-serif,arial;
                font-size: 13px;

            }/*.phead{color:#000; font-family:Verdana, Geneva, sans-serif,arial; font-size:12px;  text-transform:capitalize;}
            .pfont{color:#1070b3; font-family:Verdana, Geneva, sans-serif,arial; font-size:13px; font-weight:500; text-transform:capitalize;}*/
        </style>
    </head>

    <body>

        <table width="706" border="1" align="center" cellpadding="2" cellspacing="2">
            <tr>
                <td width="694"><table width="709" height="819" align="center" bordercolor="#2A3F00">
                        <tr align="left" valign="top">
                            <td width="1" height="101" rowspan="3">
                            </td>
                            <td width="90" height="101" rowspan="3"><img style="margin:10px;" src="<?= CLIENT_URL ?>/uploads/thumbs/<?= $oCurrentSchool->logo_img ?>" width="90" height="90" class="logo"></td>
                            <td width="602" height="43" align="center" valign="middle" class="style15"><?= $oCurrentSchool->name ?> </td>
                        </tr>
                        <tr align="left" valign="top">
                            <td height="31" align="center" valign="middle" class="c1"  ><?= $oCurrentSchool->place ?></td>
                        </tr>
                        <tr align="left" valign="top">
                            <td height="28" align="center" valign="middle" class="c1" >Affiliated To :(<?= $oCurrentSchool->board ?> ) </td>
                        </tr>
                        <tr align="left" valign="top">
                            <td height="696" class="st4">&nbsp;</td>
                            <td height="696" colspan="2" class="st4"><table width="100%" cellpadding="5">
                                    <tr>
                                        <td height="48" colspan="4" align="center" class="b1"><hr/>Confidential Letter<hr/></td>
                                    </tr>
                                    <tr>
                                        <td width="30%" class="st4"><strong>Student's Name</strong></td>
                                        <td width="42%" class="st4"><strong>:&nbsp;&nbsp;&nbsp;<?= $student['name'] ?></strong></td>
                                        <td width="10%" class="st4"><strong>Class</strong></td>
                                        <td width="18%"class="st4"><strong>:&nbsp;&nbsp;&nbsp;<?= $classarr[$student['adm_classno']]; ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td class="st4"><strong>Father's/Guardian's Name</strong></td>
                                        <td colspan="3" class="st4"><strong>:&nbsp;&nbsp;&nbsp;<?= $student['f_name'] ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td colspan="4"><p>Dear Parents, <br />
                                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Greetings from <?= $oCurrentSchool->name ?> ,<br />
                                                Congratulations! Now you can enjoy uninterrupted communication with teachers and can see your ward's details and activities online.</p></td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">To Login to '<?= $oCurrentSchool->name ?>' Panel follow the steps</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">1) Visit official website of school </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">2) You will find a Link for Login.</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">3) There will be a space in that block to insert username and password.</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">4) Enter The username and password given below and enjoy browsing.</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4"><table width="100%" cellpadding="5">
                                                <tr>
                                                    <td width="25%">Student's Username</td>
                                                    <td width="75%"><strong>:&nbsp;&nbsp;&nbsp;--</strong></td>
                                                </tr>
                                                <tr>
                                                    <td>Student's Password</td>
                                                    <td><strong>:&nbsp;&nbsp;&nbsp;--</strong></td>
                                                </tr>
                                                <tr>
                                                    <td>Parents Username:</td>
                                                    <td><strong>:&nbsp;&nbsp;&nbsp;--</strong></td>
                                                </tr>
                                                <tr>
                                                    <td>Parents Password:</td>
                                                    <td><strong>:&nbsp;&nbsp;&nbsp;</strong></td>
                                                </tr>
                                            </table></td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">FEATURES:</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4"><p>1) View your ward's teacher and communicate directly.<br />
                                                2) See and download Time Table, Syllabus, Attendance records, Assignments, Date Sheets, Activity &nbsp;&nbsp;&nbsp;&nbsp;Calendar, Homework etc.<br />
                                                3) Ask your academic questions through online 'Questionnaire'.<br />
                                            </p></td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">Important Note:</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4"><p>1) You can login and change your password for your privacy.<br />
                                                2) Parents will be able to update and make any changes in personal details through their login.<br />
                                                3) In case of any enquiry or problem you can mail us at ""</p></td>
                                    </tr>
                                   <!-- <tr>
                                      <td colspan="4"><p>Thanks,<br />
                                        AM Visual Media Team</p></td>
                                    </tr>-->
                                    <tr>
                                        <td>Parent's/Guardian's Signature</td>
                                        <td colspan="3" align="right">Date:___________________</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>

                    </table></td>
            </tr>
        </table>
        <br>
        <div class="row">
            <div class="col-md-12">
                <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                <?php
                if ($content != "registration_form")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 10px;">Registration Form</a>
                    <?php
                    } if ($content != "feebook")
                    {
                    ?>        
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                    <?php
                    } if ($content != "fee_ac")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                    <?php
                    } if ($content != "birth_certificate")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                    <?php
                    } if ($content != "tc")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                    <?php
                    } if ($content != "history")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                    <?php
                    } if ($content != "confidential_letter")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                    <?php
                    } if ($content != "character_certificate")
                    {
                    ?>
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                <?php } ?></div>
        </div>
    </body>
    </html>



    <?php
    }
else if ($content == 'character_certificate')
    {
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    ?>
    <html>
        <body>
            <h3>Comming Soon...</h3>
            <br>
            <br>
            <div class="row">
                <div class="col-md-12">
                    <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/std_profile/<?= $student['student_id']; ?>" data-ms="modal" data-title="Student Profile " style="margin: 0 0 0 10px;"> Profile</a>
                    <?php
                    if ($content != "registration_form")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/registration_form/<?= $student['student_id']; ?>" data-ms="modal" data-title="Registration Form " style="margin: 0 0 0 10px;">Registration Form</a>
                        <?php
                        } if ($content != "feebook")
                        {
                        ?>        
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/feebook/<?= $student['student_id']; ?>" data-ms="modal" data-title="FeeBook " style="margin: 0 0 0 3px;">FeeBook</a>
                        <?php
                        } if ($content != "fee_ac")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/fee_ac/<?= $student['student_id']; ?>" data-ms="modal" data-title="FEE AC" style="margin: 0 0 0 3px;">FEE AC</a>
                        <?php
                        } if ($content != "birth_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/birth_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Birth Certificate" style="margin: 0 0 0 3px;">Birth Certificate</a>
                        <?php
                        } if ($content != "tc")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/tc/<?= $student['student_id']; ?>" data-ms="modal" data-title="T C " style="margin: 0 0 0 3px;">TC</a>
                        <?php
                        } if ($content != "history")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/history/<?= $student['student_id']; ?>" data-ms="modal" data-title="History " style="margin: 0 0 0 3px;">History</a>
                        <?php
                        } if ($content != "confidential_letter")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/confidential_letter/<?= $student['student_id']; ?>" data-ms="modal" data-title="Confidential Letter" style="margin: 0 0 0 3px;">Confidential Letter</a>
                        <?php
                        } if ($content != "character_certificate")
                        {
                        ?>
                        <a class="btn bg-olive btn-flat" href="<?= CLIENT_URL; ?>/ajax-page-load/character_certificate/<?= $student['student_id']; ?>" data-ms="modal" data-title="Character Certificate" style="margin: 0 0 0 3px;">Character Certificate</a>
                    <?php } ?></div>
            </div>
        </body>
    </html>
    <?php
    }
else if ($content == 'attendance')
    {
    $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
    $classarr = classes_list();
//get locality

    $placeholderimg = '';
    $student['gender'] == 'M' ? $placeholderimg = ASSETS_FOLDER . '/img/avatar5.png' : $placeholderimg = ASSETS_FOLDER . '/img/avatar3.png';
    $student['photo'] ? $placeholderimg = UPLOADS_FOLDER . $student['photo'] : '';
    ?>
    <style>
        td, th {
            border: medium none !important;
        }
        .trnormal{
            font-weight: normal;
            color:#3c8dbc;
        }
    </style>

    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="add_attendance" value="true" />
        <input type="hidden" name="role" value="student" />
        <?php $date = http_get("param3"); ?>
        <input type="hidden" name="date" value=<?= $date ?>/><?php $class = http_get("param4"); ?>
        <input type="hidden" name="class_id" value=<?= $class ?>/>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Name</label>

                </div>
                <div class="form-group">
                    <label>Student Id</label>

                </div><div class="form-group">
                    <label>Date</label>

                </div><div class="form-group">
                    <label>Leave Type</label>

                </div>
                <div class="form-group">
                    <label>Reason <span class="text-red">*</span></label>

                </div>

            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo ucfirst($student['name']); ?>
                </div>
                <div class="form-group"> <?= $student['student_id']; ?>
                    <input type="hidden"  name="user_id" value="<?= $student['student_id']; ?>" class="form-control pull-right "/>
                </div>
                <div class="form-group"><?= $date; ?>
                </div>
                <div class="form-group"><input  type="radio" name="attendance" value="Leave" checked> Leave
                    &nbsp;&nbsp;&nbsp;

                    <input type="radio" name="attendance" value="Absent"> Absent   </div>
                <div class=""><input type="text"  name="reason" id="reason" class="form-control pull-right " required="required"/>
                </div>


            </div>
        </div> 
        <div class="row"><div class="col-md-6"></div>
            <div class="col-md-3">
                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
            </div>
            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
        </div>
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var reason = $("#reason");
                var attendance_type = $("input:radio[name=attendance]:checked").val();
                //               alert(attendance_type);
                var errors = '';
                if (reason.val() == '') {
                    reason.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    reason.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) {
                        //                        alert(responseText);
                        // get the response
                        if (attendance_type == "Absent") {
                            $(".abc").text("A");
                            $(".abc").parents('td').css('background-color', 'red');
                        } else
                        {
                            $(".abc").text("L");
                            $(".abc").parents('td').css('background-color', 'blue');
                        }
                        $(".Present").removeClass("abc");
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            $('#attendance').append(responseText);
                            eModal.close();
                            reason.val('');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>
    <?php
    }
else if ($content == 'attendance_emp')
    {
    $employee = Employee::get_employee($MSID, $id, 'all', '', $oCurrentUser->mydate)->fetch(PDO::FETCH_ASSOC);
    ?>
    <style>
        td, th {
            border: medium none !important;
        }
        .trnormal{
            font-weight: normal;
            color:#3c8dbc;
        }
    </style>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="role" value="employee" />
        <input type="hidden" name="add_attendance_emp" value="true" />
        <?php $date = http_get("param3"); ?>
        <input type="hidden" name="date" value="<?= $date ?>"/>


        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Name</label>

                </div>
                <div class="form-group">
                    <label>Student Id</label>

                </div><div class="form-group">
                    <label>Date</label>

                </div><div class="form-group">
                    <label>Leave Type</label>

                </div>
                <div class="form-group">
                    <label>Reason <span class="text-red">*</span></label>

                </div>

            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <?php echo ucfirst($employee['emp_name']); ?>
                </div>
                <div class="form-group"> <?= $employee['id']; ?>
                    <input type="hidden"  name="user_id" value="<?= $employee['id']; ?>" class="form-control pull-right "/>
                </div>
                <div class="form-group"><?= $date; ?>
                </div>
                <div class="form-group"><input  type="radio" name="attendance" value="Leave" checked> Leave
                    &nbsp;&nbsp;&nbsp;

                    <input type="radio" name="attendance" value="Absent"> Absent   </div>
                <div class=""><input type="text"  name="reason" id="reason" class="form-control pull-right " required/>
                </div>


            </div>
        </div> 
        <div class="row"><div class="col-md-6"></div>
            <div class="col-md-3">
                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
            </div>
            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
        </div>
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var reason = $("#reason");
                var attendance_type = $("input:radio[name=attendance]:checked").val();
                //               alert(attendance_type);
                var errors = '';
                if (reason.val() == '') {
                    reason.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    reason.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                    data: datastring, // post data
                    success: function (responseText) {
                        //                        alert(responseText);
                        // get the response
                        if (attendance_type == "Absent") {
                            $(".abc").text("A");
                            $(".abc").parents('td').css('background-color', 'red');
                        } else
                        {
                            $(".abc").text("L");
                            $(".abc").parents('td').css('background-color', 'blue');
                        }
                        $(".Present").removeClass("abc");
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            $('#attendance').append(responseText);
                            eModal.close();
                            reason.val('');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });</script>  
    <?php
    }
else if ($content == 'homework_add')
    {
    if (@$_POST['selected_subject_id'])
        {
        $selected_subject_id = $_POST['selected_subject_id'];
        }
    $class_id = $_POST['classid'];
//    $subject = Master::get_subject($MSID, '', $class_id);
    $subject = SuperAdmin::get_schoolwise_subject2($MSID, '', array('selectAll' => 'true'), $class_id, '', 'YES');

    $totalrecords = $subject->rowCount();
    if ($totalrecords > 0)
        {

        $all_subjects = $subject->fetchAll(PDO::FETCH_ASSOC);
        ?>

        <label>Subject<span class="text-red">*</span></label>
        <select name="subject_id" class="class_check form-control">
            <option value="">Select</option>

            <?php
            foreach ($all_subjects as $subjects)
                {
                if (@$selected_subject_id)
                    {
                    if ($selected_subject_id == $subjects['subject_id'])
                        {
                        $selected = 'selected :"selected"';
                        }
                    else
                        {
                        $selected = '';
                        }
                    }
                else
                    {
                    $selected = '';
                    }
                echo '<option value="' . $subjects['subject_id'] . '"' . $selected . '>' . $subjects['name'] . '</option>';
                }
            ?>
        </select>



        <?php
// print_r($all_subjects);
        }
    else
        {
        ?>
        No Subject Available 
        <?php
        }
    exit();
    }
else if ($content == 'issue_book')
    {
    if (@$_POST['student_id'])
        {
        $student_id = $_POST['student_id'];
        $student = Student::get_students($oCurrentUser->myuid, '', $student_id);
        $totalrecords = $student->rowCount();
        if ($totalrecords > 0)
            {
            $Student_detail = $student->fetch(PDO::FETCH_ASSOC);
            ?> 
            <div class="form-group"><label>Student Name</label>
                <label><?= $Student_detail['name']; ?></label>
            </div><?php
            }
        else
            {
            ?>
            <div class="form-group"> 
                <span class="text-red">Student Id doesn't exist<span><br>
                        </div>
                        <?php
                        }
                    } if (@$_POST['book_id'])
                    {
                    $book_id = $_POST['book_id'];
                    $book = Library::get_books($MSID, '', $book_id);
                    $totalrecords = $book->rowCount();
                    if ($totalrecords > 0)
                        {
                        $book_detail = $book->fetch(PDO::FETCH_ASSOC);
                        ?> 
                        <div class="form-group"> <label>Book Name</label>
                            <input type="text" value="<?= $book_detail['title']; ?>" name="book_name"></label>
                        </div>
                        <?php
                        }
                    else
                        {
                        ?>
                        <div class="form-group">   
                            <input type="hidden" value="" name="book_name">
                            <span class="text-red">Book Id doesn't exist<span><br>
                                    </div>  
                                    <?php
                                    }
                                }


                            exit();
                            }
                        else if ($content == 'update_book')
                            { //used in fee type and fee group page
                            $book = Library::get_books($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
                            ?>
                            <form id="ajaxForm" method="post" action="" role="form">
                                <input type="hidden" name="update_book" value="true" />
                                <input type="hidden" name="id" value="<?= $id ?>" />
                                <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                                <?php ?>
                                <div class="col-md-12">


                                    <div class="form-group">
                                        <label>ISBN<span class="text-red">*</span></label>
                                        <input type="number" name="isbn" size="30" value="<?= $book['isbn'] ?>" placeholder="12345" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label>Title<span class="text-red">*</span></label>
                                        <input type="text" name="title" size="30" value="<?= $book['title'] ?>"class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>category<span class="text-red">*</span></label>
                                        <select name="category_id" class="class_check form-control">
                                            <option value="">Select</option>
                                            <?php
                                            $categorys = Library::get_category($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
                                            ?>
                                            <?php
                                            foreach ($categorys as $category)
                                                {
                                                if ($category['id'] == $book['category_id'])
                                                    {
                                                    $selected = 'selected= "selected"';
                                                    }
                                                else
                                                    {
                                                    $selected = '';
                                                    }
                                                echo '<option value="' . $category['id'] . '"' . $selected . '>' . $category['name'] . '</option>';
                                                }
                                            ?>
                                        </select>
                                    </div>  
                                    <div class="form-group">
                                        <label>Author<span class="text-red">*</span></label>
                                        <input type="text" name="author" value="<?= $book['author'] ?>" size="30" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label>Edition<span class="text-red">*</span></label>
                                        <input type="number" name="edition" value="<?= $book['edition'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Publisher<span class="text-red">*</span></label>
                                        <input type="text" name="publisher" value="<?= $book['publisher'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>No Of Copy<span class="text-red">*</span></label>
                                        <input type="number" name="copy_taken" value="<?= $book['copy_taken'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Shelf No<span class="text-red">*</span></label>
                                        <input type="text" name="shelf_no" value="<?= $book['shelf_no'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>book_position<span class="text-red">*</span></label>
                                        <input type="text" name="book_position" value="<?= $book['book_position'] ?>" size="30" class="form-control">
                                    </div>


                                </div>


                                <div class="form-group">
                                    <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
                                </div>
                                <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

                            </form>

                            <script>
                                $(function () {
                                    $('#ajaxSubmit').click(function () {
                                        $('#ajaxForm .errorDiv').remove();
                                        var datastring = $("#ajaxForm").serialize();
                                        $("#process").show();
                                        ///ajax code
                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                responseText = $.trim(responseText);
                                                if (responseText != 'error') {
                                                    location.reload();
                                                    eModal.close();
                                                } else {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                                                }
                                                $("#process").hide();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {
                                                if (jqXHR.status == 500) {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                        // end
                                        return false;
                                    });
                                });
                            </script>
                            <?php
                            }
                        else if ($content == 'update_category')
                            { //used in fee type and fee group page
                            $category = Library::get_category($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
                            ?>
                            <form id="ajaxForm" method="post" action="" role="form">
                                <input type="hidden" name="update_books_category" value="true" />
                                <input type="hidden" name="id" value="<?= $id ?>" />
                                <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                                <?php ?>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Name<span class="text-red">*</span></label>
                                                <input type="text" name="name" value="<?= $category['name'] ?>"size="30" class="form-control">
                                            </div>
                                        </div>
                                        <!-- \col -->
                                    </div>
                                </div>


                                <div class="form-group">
                                    <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
                                </div>
                                <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

                            </form>

                            <script>
                                $(function () {
                                    $('#ajaxSubmit').click(function () {
                                        $('#ajaxForm .errorDiv').remove();
                                        var datastring = $("#ajaxForm").serialize();
                                        $("#process").show();
                                        ///ajax code
                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                responseText = $.trim(responseText);
                                                if (responseText != 'error') {
                                                    location.reload();
                                                    eModal.close();
                                                } else {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                                                }
                                                $("#process").hide();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {
                                                if (jqXHR.status == 500) {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                        // end
                                        return false;
                                    });
                                });
                            </script>
                            <?php
                            }
                        else if ($content == 'view-document')
                            {
                            $id = http_get('param2');

                            $stu_doc = Student::get_student_get($id);

                            // print_r($stu_doc);


                            $stu_docs = $stu_doc->fetch();

                            //print_r($stu_docs);
                            //print_r($stu_docs);
                            ?>
                            <div class="row">
                                <div class="col-md-3">
                                    <h3 class="box-title"><u>Document List</u></h3>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6">  <label>Aadhar Certificate <span class="text-red"></span></label>
                                    </div> <div class="col-md-6">
                                        <?php
                                        if ($stu_docs['aadhar'] != '')
                                            {
                                            ?>
                                            <img src="<?= CLIENT_URL ?>/uploads/student_docx/<?= $stu_docs['aadhar'] ?>" width="150" height="100"/>

                                            <?php
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">&nbsp;</div>

                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"><label>Report Card <span class="text-red"></span></label>
                                    </div> <div class="col-md-6">   
                                        <?php
                                        if ($stu_docs['report_cirtificate'] != '')
                                            {
                                            ?>
                                            <img src="<?= CLIENT_URL ?>/uploads/student_docx/<?= $stu_docs['report_cirtificate'] ?>" width="150" height="100"/>

                                            <?php
                                            }
                                        ?>




                                    </div></div>
                            </div>

                            <div class="row">&nbsp;</div>
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6">  <label>School Leaving Certificate <span class="text-red"></span></label>
                                    </div> <div class="col-md-6"> 
                                        <?php
                                        if ($stu_docs['school_leaving'] != '')
                                            {
                                            ?>
                                            <img src="<?= CLIENT_URL ?>/uploads/student_docx/<?= $stu_docs['school_leaving'] ?>" width="150" height="100"/>

                                            <?php
                                            }
                                        ?>


                                    </div></div></div>

                            <div class="row">&nbsp;</div>

                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6">  <label>Birth Certificate <span class="text-red"></span></label>
                                    </div> <div class="col-md-6">
                                        <?php
                                        if ($stu_docs['birth'] != '')
                                            {
                                            ?>
                                            <img src="<?= CLIENT_URL ?>/uploads/student_docx/<?= $stu_docs['birth'] ?>" width="150" height="100"/>

                                            <?php
                                            }
                                        ?>



                                    </div></div></div>
                            <div class="row">&nbsp;</div>
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"><label>Character  Certificate <span class="text-red"></span></label>
                                    </div> <div class="col-md-6">
                                        <?php
                                        if ($stu_docs['ch'] != '')
                                            {
                                            ?>
                                            <img src="<?= CLIENT_URL ?>/uploads/student_docx/<?= $stu_docs['ch'] ?>" width="150" height="100"/>

                                            <?php
                                            }
                                        ?>


                                    </div></div></div>

                            <div class="row">&nbsp;</div>
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"> <label>Other <span class="text-red"></span></label>
                                    </div> <div class="col-md-6">  

                                        <?php
                                        if ($stu_docs['other'] != '')
                                            {
                                            ?>
                                            <img src="<?= CLIENT_URL ?>/uploads/student_docx/<?= $stu_docs['other'] ?>" width="150" height="100"/>

                                            <?php
                                            }
                                        ?>

                                    </div></div></div>




                            <?php
                            }
                        else if ($content == 'discount')
                            {
                            $id = http_get('param2');
                            $student_tran = new Student();


                            $stu_discount_info = Transport::get_discounted_stu($MSID, $id, '', 'all');




                            $stu_discount_infos = Transport::get_discounted_stu($MSID, $id, $oCurrentUser->mydate);
                            $stu_record = Student::get_stu_info($MSID, $id)->fetch();

                            $stu_discount_data = $stu_discount_infos->fetch(PDO::FETCH_ASSOC);


                            $discount_list = Transport::get_discount_names($MSID);
                            //print_r($discount_list);
                            ?>
                            <form method="post" id="discount_form">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h3 class="box-title"><b>Discount</b></h3>
                                    </div> 
                                    <div class="col-md-6">
                                        <h4>Student Discount information</h4>

                                        <table class="table">
                                            <tr>
                                                <th>Student ID</th> <th>Discount Name</th> <th>Start From</th> <th>To</th><th></th>
                                            </tr>
                                            <?php
                                            if ($stu_discount_info->rowCount() > 0)
                                                {
                                                while ($row_rec = $stu_discount_info->fetch())
                                                    {

                                                    $tpt_station = Discount::get_discount_name($MSID, $row_rec['discount_id']);

                                                    //print_r($tpt_station);
                                                    $tpt_station_fetch = $tpt_station->fetch();
                                                    // print_r($tpt_station_fetch);
                                                    ?>

                                                    <tr>
                                                        <td><?= $row_rec['s_id'] ?></td><td><?= $tpt_station_fetch['name'] ?></td><td><?= $row_rec['date_from'] ?></td><td><?= $row_rec['date_to'] ?></td>
                                                        <td><a class="" id="edit_discount" data-title="Edit Discount" data-ms="modal" href="<?= CLIENT_URL ?>/ajax-page-load/discount_edit/<?= $id ?>/<?= $row_rec['id'] ?>"><b>Edit</b></a> <a href="javascript:void(0);" onCLick="return confirm('Are you SURE you want to delete this record?')" class="del_discount" id="<?= $row_rec['id'] ?>"><b>Delete</b></a>
                                                        </td>
                                                    </tr>





                                                    <?php
                                                    }
                                                }
                                            ?>
                                        </table>

                                    </div>
                                    <div class="col-md-4" id="transport_sec">


                                        <select class="form-control" id="discount_select" name="discount_select">
                                            <option value="">Select</option>
                                            <?php
                                            while ($discount = $discount_list->fetch())
                                                {
//                                                print_r($discount);
//                                                exit();
                                                if ($stu_discount_data['discount_id'] == $discount["discount_id"])
                                                    {
                                                    $selected = "selected='selected'";
                                                    }
                                                else
                                                    {
                                                    $selected = '';
                                                    }

                                                echo '<option value="' . $discount["discount_id"] . '" ' . @$selected . '>' . $discount["name"] . '</option>';
                                                }
                                            ?>
                                        </select> 

                                    </div>    
                                </div>         
                                <br>
                                <div class="row">   
                                    <div class="col-md-4">
                                        <input type="hidden" name="student_id" id="student_id" value="<?= http_get('param2') ?>"/>
                                        <input type="hidden" name="msid" value="<?= $MSID ?>" id="msid"/>


                                        <input type="hidden" name ="discount_update" id="" value="true" />

                                        <input type="hidden" name="acno" id= "acno" value="<?= $stu_record['acno'] ?>"/> <input type="hidden" name="s_id" id= "s_id" value="<?= $id ?>"/>

                                        <input type="hidden" name="session" id="session" value="<?= $oCurrentUser->mysession ?>"/>

                                        <input type="hidden" name="myuid" id="myuid" value="<?= $oCurrentUser->myuid ?>"/>


                                        <button type="button" name="update_discount" id="update_discount" class="btn btn-success pull-right">Update</button>            


                                    </div> 


                                </div> 
                            </form>
                            <script>
                                $(document).ready(function ()
                                {

                                    $("#update_discount").click(function ()
                                    {

                                        var datastring = $("#discount_form").serialize();
                                        //                                        alert(datastring);




                                        //  var student_id = $("#student_id").val();

                                        //  var  msid = $("#msid").val();




                                        //var datastring = 'tpt='+tpt+'&student_id='+student_id+'&msid='+msid+'&transport='+'true';

                                        //alert(datastring);
                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText)
                                            { // get the response
                                                //                                                alert(responseText);
                                                //                                                alert(responseText);

                                                location.reload();
                                                eModal.close();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {

                                                alert(errorThrown);
                                                if (jqXHR.status == 500) {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                    });
                                    $(".del_discount").click(function ()
                                    {
                                        var id = $(this).attr('id');
                                        var msid = $("#msid").val();
                                        var acno = $("#acno").val();
                                        var s_id = $("#s_id").val();
                                        var session = $("#session").val();
                                        var myuid = $("#myuid").val();
                                        var datastring = 'id=' + id + '&msid=' + msid + '&del_discount=' + 'true' + '&acno=' + acno + '&s_id=' + s_id + '&session=' + session + '&myuid=' + myuid;
                                        // alert(datastring);

                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                //                                                alert(responseText);
                                                //alert(responseText);
                                                location.reload();
                                                eModal.close();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {

                                                alert(errorThrown);
                                                if (jqXHR.status == 500) {
                                                    // $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    //$("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                    });
                                });
                            </script>       
                            <?php
                            }
                        else if ($content == 'transport')
                            {
                            $id = http_get('param2');
                            $student_tran = new Transport();


                            $stu_trans_info = Transport::get_transport_stu($MSID, $id, $oCurrentUser->mydate);

                            $tpt_std = $stu_trans_info->fetch(PDO::FETCH_OBJ);
//                             print_r($tpt_std);

                            $stu_trans_info_count = $stu_trans_info->rowCount();


                            $tpt_stu_data = Transport::get_stu_trans($MSID, $id);
                            @$selected_stn = Transport::get_stu_traninfo($MSID, $tpt_std->tpt_stn_id)->fetch(PDO::FETCH_OBJ);

                            // print_r($selected_stn);
                            //echo  $selected_stn->station_id;
//                            $selected_stn->station_name ;
                            //$tpt_stu_data_fetch = $tpt_stu_data->fetchAll();
                            //print_r($tpt_stu_data_fetch);
                            // print_r($stu_trans_get);

                            $tptstations = Transport::get_tptstations($MSID, '');



                            $tpt_stations_count = $tptstations->rowCount();

                            $student = Student::get_stu_info($MSID, $id)->fetch(PDO::FETCH_OBJ);

                            $stu_record = Student::get_stu_info($MSID, $id)->fetch();

                            // print_r($stu_trans_info);
                            ?>
                            <form method="post" id="tpt_form">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h3 class="box-title"><b>Transportation</b></h3>
                                    </div> 
                                    <div class="col-md-6">
                                        <h4>Student Transport information</h4>

                                        <table class="table">
                                            <tr>
                                                <th>Student ID</th> <th>Station Name</th> <th>Start From</th> <th>To</th>
                                                <th>Action</th>

                                            </tr>
                                            <?php
                                            if ($tpt_stu_data->rowCount() > 0)
                                                {
                                                while ($row_rec = $tpt_stu_data->fetch())
                                                    {
                                                    $tpt_station = Transport::get_tptstations($MSID, $id = $row_rec['tpt_stn_id'], '', $data = array('selectAll' => 'true'));
                                                    $tpt_station_fetch = $tpt_station->fetch();
                                                    ?>

                                                    <tr>
                                                        <td><?= $row_rec['S_id'] ?></td><td><?= $tpt_station_fetch['station_name'] ?></td><td><?= $row_rec['date_from'] ?></td><td><?= $row_rec['date_to'] ?></td>
                                                        <td><a class="" id="edit_transport" data-title="Transport" data-ms="modal" href="<?= CLIENT_URL ?>/ajax-page-load/transport_edit/<?= $student->student_id ?>/<?= $row_rec['id'] ?>"><b>Edit</b></a>|<a href="javascript:void(0);" onCLick="return confirm('Are you SURE you want to delete this record?')" class="del_trans" id="<?= $row_rec['id'] ?>"><b>Delete</b></a></td>
                                                    </tr>





                                                    <?php
                                                    }
                                                }
                                            ?>
                                        </table>

                                    </div>

                                    <div class="col-md-4" id="transport_sec">


                                        <select  id="tpt" class="form-control" name="tpt" style="width:100%">
                                            <option value="">Select</option>
                                            <?php
                                            foreach ($tptstations as $station)
                                                {

                                                if ($selected_stn->station_id == $station["station_id"])
                                                    {
//                                                    exit();
                                                    $selected = "selected='selected'";
                                                    }
                                                else
                                                    {
                                                    $selected = '';
                                                    }

                                                echo '<option value="' . $station["station_id"] . '" ' . $selected . '>' . $station["station_name"] . '</option>';
                                                }
                                            ?>
                                        </select> 
                                        <?php
                                        //print_r($oCurrentUser);
                                        ?>
                                    </div>    
                                </div>         

                                <div class="row">   
                                    <div class="col-md-4">
                                        <input type="hidden" name="student_id" id="student_id" value="<?= http_get('param2') ?>"/>
                                        <input type="hidden" name="msid" value="<?= $MSID ?>" id="msid"/>
                                        <input type="hidden" name ="tpt_val" id="tpt_val" value="" />

                                        <input type="hidden" name ="transport" id="tpt_val" value="true" />

                                        <input type="hidden" name="acno" value="<?= $stu_record['acno'] ?>"/>


                                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>"/>

                                        <input type="hidden" name="myuid" value="<?= $oCurrentUser->myuid ?>"/>
                                        <br/>

                                        <button type="button" name="update_transporation" id="update_transporation" class="btn btn-success pull-right">Update</button>            


                                    </div> 


                                </div> 
                            </form>
                            <script>
                                $(document).ready(function ()
                                {

                                    $("#update_transporation").click(function ()
                                    {

                                        var datastring = $("#tpt_form").serialize();
                                        //alert(datastring);




                                        //  var student_id = $("#student_id").val();

                                        //  var  msid = $("#msid").val();




                                        //var datastring = 'tpt='+tpt+'&student_id='+student_id+'&msid='+msid+'&transport='+'true';

                                        //alert(datastring);
                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                //                                                alert(responseText);
                                                //                                                alert(responseText);
                                                location.reload();
                                                eModal.close();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {

                                                alert(errorThrown);
                                                if (jqXHR.status == 500) {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                    });
                                    $(".del_trans").click(function ()
                                    {
                                        var id = $(this).attr('id');
                                        var msid = $("#msid").val();
                                        var acno = $("#acno").val();
                                        var s_id = $("#student_id").val();
                                        var session = $("#session").val();
                                        var myuid = $("#myuid").val();
                                        var datastring = 'id=' + id + '&msid=' + msid + '&del_transport=' + 'true' + '&acno=' + acno + '&s_id=' + s_id + '&session=' + session + '&myuid=' + myuid;
                                        //                                         alert(datastring);

                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                //                                                 alert(responseText);

                                                location.reload();
                                                eModal.close();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {

                                                alert(errorThrown);
                                                if (jqXHR.status == 500) {
                                                    // $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    //$("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                    });
                                });
                            </script>       
                            <?php
                            }
                        else if ($content == 'select_no_transport')
                            {

                            $student_id = $_POST['student_id'];
                            //echo $MSID ;
                            $tpt_stu_data = Transport::get_transport_stu($MSID, $student_id);

                            $tp_stu_fetch = $tpt_stu_data->fetch();

                            $tp_stu_id = $tp_stu_fetch['id'];

                            $tp_stu_tr = $tp_stu_fetch['tpt_stn_id'];


                            //print_r($oCurrentUser);

                            $date_get_sess_date = $oCurrentUser->mydate;

                            $date_get = date('Y-m-d', strtotime($date_get_sess_date . ' -1 day'));


                            try
                                {
                                $oDb = DBConnection::get();

                                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_std SET tpt_stn_id = :tpt_stn_id, date_to = :date_to  WHERE id = :id');
                                $status = $upsql->execute(array(
                                    ':tpt_stn_id' => '0',
                                    ':date_to' => $date_get,
                                    ':id' => $tp_stu_id
                                ));

                                if ($status)
                                    {

                                    echo "success";
                                    }
                                }
                            catch (Exception $ex)
                                {
                                
                                }
                            ?>



                            <?php
                            }
                        else if ($content == 'select_no_discount')
                            {
                            $student_id = $_POST['student_id'];
                            //print_r($oCurrentUser);
                            $tpt_stu_data = Transport::get_discounted_stu($MSID, $student_id);
                            $tp_stu_fetch = $tpt_stu_data->fetch();
                            $tp_stu_id = $tp_stu_fetch['id'];
                            $tp_stu_tr = $tp_stu_fetch['tpt_stn_id'];
                            $date_get_sess_date = $oCurrentUser->mydate;

                            $date_get = date('Y-m-d', strtotime($date_get_sess_date . ' -1 day'));


                            try
                                {
                                $oDb = DBConnection::get();

                                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'discounted_student SET discount_id = :discount_id, date_to = :date_to  WHERE id = :id');
                                $status = $upsql->execute(array(
                                    ':discount' => '0',
                                    ':date_to' => $date_get,
                                    ':id' => $tp_stu_id
                                ));

                                if ($status)
                                    {

                                    echo "success";
                                    }
                                }
                            catch (Exception $ex)
                                {
                                
                                }
                            ?>



                            <?php
                            }
                        else if ($content == "term_attendance")
                            {


                            $sAdmission = new Admission();
                            $students = $sAdmission->get_enrolled_std($MSID, '', '', '', $_POST['class_id']);
                            $classsections = Master::get_schools_section($MSID, '', $_POST['class_id']);
                            //$classsections->rowCount()

                            if ($classsections->rowCount() > 0 && $oCurrentSchool->section != '0')
                                {
                                ?>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select section<span class="text-red">*</span></label>
                                        <select id="section_id" name="section_id" class="form-control" >        

                                            <?php
                                            while ($rowv = $classsections->fetch())
                                                {
                                                $total = Student::get_std_available($MSID, $rowv['class_id'], $rowv['sec_name'])->rowCount();
                                                if (@$total > 0)
                                                    {
                                                    $total_s = Student::get_std_available($MSID, $rowv['class_id'], $rowv['sec_name'])->fetch(PDO::FETCH_ASSOC);
                                                    $totalstd = $total_s['total'];
                                                    }
                                                else
                                                    {
                                                    $totalstd = 0;
                                                    }
                                                $available = $rowv['sec_seats'] - $totalstd;
                                                ?>
                                                <option value="<?= $rowv['id']; ?>"><?= $rowv['display_name'] . " " . "&nbsp;&nbsp;"; ?></option>

                                            <?php } ?>

                                        </select>



                                        <?php
                                        }
                                    }
                                else if ($content == 'transport_edit')
                                    {
                                    $student_id = http_get('param2');

                                    $id = http_get('param3');

                                    $stu_record = Student::get_stu_info($MSID, $student_id)->fetch();

                                    $trans_info = Transport:: get_trans_edit($MSID, $id, $student_id)->fetch();

                                    $tpt_station = Transport::get_tptstations($MSID, $trans_info['tpt_stn_id'], '', $data = array('selectAll' => 'true'));
                                    $tpt_station_fetch = $tpt_station->fetch();
                                    $tptstations = Transport::get_tptstations($MSID, '');



                                    //$tpt_stations_count = $tptstations->rowCount();
                                    ?>
                                    <form method="post" id="tptedit_form">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Student ID <span class="text-red">*</span></label>
                                                    <input class="form-control" type="text" size="30" id="student_id" name="student_id" value="<?= $trans_info['S_id'] ?>" readonly="readonly" required/>
                                                </div>
                                                <div class="form-group">
                                                    <label>Station Name<span class="text-red">*</span></label>
                                                    <div class="form-group">
                                                        <select class="form-control" id="tpt" name="tpt">
                                                            <option value="">Select</option>
                                                            <?php
                                                            foreach ($tptstations as $station)
                                                                {

                                                                if ($trans_info['tpt_stn_id'] == $station["station_id"])
                                                                    {
                                                                    $selected = "selected='selected'";
                                                                    }
                                                                else
                                                                    {
                                                                    $selected = '';
                                                                    }

                                                                echo '<option value="' . $station["station_id"] . '" ' . $selected . '>' . $station["station_name"] . '</option>';
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <label>Date From <span class="text-red">*</span></label>
                                                    <input class="form-control" type="text" size="30" id="date_from"  value="<?= $trans_info['date_from'] ?>" name="date_from" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Date To <span class="text-red">*</span></label>
                                                    <input class="form-control" type="text" size="30" id="date_to" value="<?= $trans_info['date_to'] ?>" name="date_to" required>
                                                    <input type="hidden" name="msid" value="<?= $trans_info['MSID'] ?>"/>
                                                    <input type="hidden" name="student_id" value="<?= $trans_info['S_id'] ?>"/>

                                                    <input type="hidden" name="trans_id" value="<?= $trans_info['id'] ?>"/>
                                                    <input type="hidden" name="trans_edit" value="true"/>
                                                    <input type="hidden" name="acno" value="<?= $stu_record['acno'] ?>"/>

                                                    <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>"/>

                                                    <input type="hidden" name="myuid" value="<?= $oCurrentUser->myuid ?>"/>



                                                </div>

                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <button type="button" id="tran_btn" name="tran_btn" class="btn btn-lg btn-success btn-block">Submit</button>
                                            </div>
                                            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                                        </div>





                                </div>







                                </form> 

                                <script>

                                    $("#tran_btn").click(function ()
                                    {

                                        var datastring = $("#tptedit_form").serialize();
                                        //alert(datastring)


                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                //alert(responseText);


                                                location.reload();
                                                eModal.close();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {

                                                alert(errorThrown);
                                                if (jqXHR.status == 500) {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                    });
                                </script>





                                <?php
                                }
                            else if ($content == 'stu_exams')
                                {
                                $id = http_get('param2');

                                $student_exams = Exam::get_student_exams($MSID, $id);
                                //print_r($student_exams);       
                                $stu_record = Student::get_stu_info($MSID, $id)->fetch();
                                ?>

                                <table class="table">
                                    <tr>
                                        <th>Student ID</th> <th>Date Result</th> <th>Result</th><th>Action</th>


                                    </tr>

                                    <?php
                                    if ($student_exams->rowCount() > 0)
                                        {
                                        while ($student_row = $student_exams->fetch())
                                            {
                                            if ($student_row['result'] == '-1')
                                                {
                                                $result = "Fail";
                                                }
                                            if ($student_row['result'] == '1')
                                                {
                                                $result = "Promoted";
                                                }
                                            ?>
                                            <tr>
                                                <td><?= $student_row['s_id'] ?></td><td><?= $student_row['date_result'] ?></td><td><?= $result ?></td><td><a href="javascript:void" id="<?= $student_row['id'] ?>" class="del_exam" >Delete</a></td>
                                            </tr>
                                            <?php
                                            }
                                        }
                                    ?>

                                </table>
                                <form method="post" id="add_exam_form" name="add_exam_form">
                                    <table class="table">



                                        <tr>


                                            <td><?= $id ?></td><td><input class="form-control" type="text" size="5" id="date_result" name="date_result" value="<?= $oCurrentUser->mydate ?>" required="required"/></td><td><select name="exam_result" id="exam_result" class="form-control"><option value="1">Promoted</option><option value="-1" selected="selected">Fail</option></select></td><td><input type="button" class="btn-lg btn-success" value="Submit" id="add_exam" name="add_exam"/>
                                                <input type="hidden" name="student_id" id="student_id" value="<?= $id ?>"/>
                                                <input type="hidden" name="add_exams" value="true"/>


                                                <input type="hidden" name="msid" value="<?= $MSID ?>" id="msid"/>


                                                <input type="hidden" name="acno" value="<?= $stu_record['acno'] ?>"/>

                                                <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>"/>

                                                <input type="hidden" name="myuid" value="<?= $oCurrentUser->myuid ?>"/>

                                            </td> 



                                        </tr>   


                                    </table>   
                                </form>
                                <script>
                                    $(document).ready(function ()
                                    {
                                        $("#add_exam").click(function ()
                                        {

                                            var datastring = $("#add_exam_form").serialize();
                                            $.ajax({
                                                type: "POST", // type
                                                url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                                data: datastring, // post data
                                                success: function (responseText) { // get the response
                                                    //                                                alert(responseText);




                                                    location.reload();
                                                    eModal.close();
                                                }, // end success
                                                error: function (jqXHR, textStatus, errorThrown) {

                                                    alert(errorThrown);
                                                    if (jqXHR.status == 500) {
                                                        $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                    } else {
                                                        $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                    }
                                                    $("#process").hide();
                                                }
                                            });
                                        });
                                        $(".del_exam").click(function ()
                                        {

                                            var id = $(this).attr('id');
                                            var msid = $("#msid").val();
                                            var datastring = 'id=' + id + '&msid=' + msid + '&del_exam=' + 'true';
                                            // alert(datastring);

                                            $.ajax({
                                                type: "POST", // type
                                                url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                                data: datastring, // post data
                                                success: function (responseText) { // get the response
                                                    //                                                alert(responseText);


                                                    location.reload();
                                                    //
                                                    //
                                                    eModal.close();
                                                }, // end success
                                                error: function (jqXHR, textStatus, errorThrown) {

                                                    alert(errorThrown);
                                                    if (jqXHR.status == 500) {
                                                        // $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                    } else {
                                                        //$("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                    }
                                                    $("#process").hide();
                                                }
                                            });
                                        });
                                    });
                                </script>           



                                <?php
                                }
                            else if ($content == 'discount_edit')
                                {

                                $student_id = http_get('param2');

                                $id = http_get('param3');

                                $stu_record = Student::get_stu_info($MSID, $student_id)->fetch();

                                //$dis_stu_data = Transport::get_discounted_stu($MSID, $id,$my_date);

                                $discount_stu_data = Transport::get_single_discounted_stu($MSID, $student_id, $id, $oCurrentUser->mydate, 'all')->fetch();




                                //$discounted_stu  = Discount::get_discount_name($MSID ,$discount_stu_data['discount_id'])->fetch();
//                                print_r($discount_stu_data);

                                $discount_list = Transport::get_discount_names($MSID)->fetchAll(PDO::FETCH_ASSOC);

//    print_r($discount_list);
                                //$tpt_station_fetch = $discount_stu_data->fetch();
                                //$tptstations = Transport::get_tptstations($MSID, '', 1);
                                ?>
                                <form method="post" id="discountedit_form">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Student ID <span class="text-red">*</span></label>
                                                <input class="form-control" type="text" size="30" id="student_id" name="student_id" value="<?= $discount_stu_data['s_id'] ?>" readonly="readonly" required/>
                                            </div>
                                            <div class="form-group">
                                                <label>Discount Name<span class="text-red">*</span></label>
                                                <div class="form-group">
                                                    <select class="form-control" id="dis_count" name="dis_count">
                                                        <option value="">Select</option>
                                                        <?php
                                                        foreach ($discount_list as $dis)
                                                            {

                                                            if ($dis['discount_id'] == $discount_stu_data["discount_id"])
                                                                {
                                                                $selected = "selected='selected'";
                                                                }
                                                            else
                                                                {
                                                                $selected = '';
                                                                }

                                                            echo '<option value="' . $dis["discount_id"] . '" ' . $selected . '>' . $dis["name"] . '</option>';
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                                <label>Date From <span class="text-red">*</span></label>
                                                <input class="form-control" type="text" size="30" id="date_from"  value="<?= $discount_stu_data['date_from'] ?>" name="date_from" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Date To <span class="text-red">*</span></label>
                                                <input class="form-control" type="text" size="30" id="date_to" value="<?= $discount_stu_data['date_to'] ?>" name="date_to" required>
                                                <input type="hidden" name="msid" value="<?= $discount_stu_data['MSID'] ?>"/>
                                                <input type="hidden" name="student_id" value="<?= $discount_stu_data['s_id'] ?>"/>

                                                <input type="hidden" name="discount_id" value="<?= $discount_stu_data['id'] ?>"/>
                                                <input type="hidden" name="discount_edit" value="true"/>
                                                <input type="hidden" name="acno" value="<?= $stu_record['acno'] ?>"/>

                                                <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>"/>

                                                <input type="hidden" name="myuid" value="<?= $oCurrentUser->myuid ?>"/>



                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <button type="button" id="dis_btn" name="dis_btn" class="btn btn-lg btn-success btn-block">Submit</button>
                                        </div>
                                        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                                    </div>





                            </div>







                            </form> 

                            <script>

                                $("#dis_btn").click(function ()
                                {

                                    var datastring = $("#discountedit_form").serialize();
                                    //alert(datastring)


                                    $.ajax({
                                        type: "POST", // type
                                        url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                        data: datastring, // post data
                                        success: function (responseText) { // get the response
                                            //                                                alert(responseText);
                                            //alert(responseText);



                                            location.reload();
                                            eModal.close();
                                        }, // end success
                                        error: function (jqXHR, textStatus, errorThrown) {

                                            alert(errorThrown);
                                            if (jqXHR.status == 500) {
                                                $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                            } else {
                                                $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                            }
                                            $("#process").hide();
                                        }
                                    });
                                });
                            </script>





                            <?php
                            }
                        else if ($content == 'transpor_check')
                            {
                            if (isset($_POST['transport']) && $_POST['transport'] == '0')
                                {

                                //echo $oCurrentUser->mydate;

                                $get_result = Transport::get_details_tran_stu($MSID, $oCurrentUser->mydate);


                                echo $get_result_count = $get_result->rowCount();
                                }
                            ?>

                            <?php
                            }
                        else if ($content == 'discount_check')
                            {
                            if (isset($_POST['discount']) && $_POST['discount'] == '0')
                                {
                                $get_discount = Discount::get_stu_discount($MSID, $oCurrentUser->mydate);
                                echo $get_discount_count = $get_discount->rowCount();
                                }
                            }
                        else if ($content == 'hostel_check')
                            {
                            if (isset($_POST['hostel']) && $_POST['hostel'] == '0')
                                {
                                $get_hostel = Hostel::get_hostelers_stu($MSID, $oCurrentUser->mydate);
                                // print_r($get_hostel);

                                echo $get_hostel_count = $get_hostel->rowCount();
                                }
                            }
                        else if ($content == 'locality_add_section')
                            {
                            $id = $_POST['id'];
                            $locality = $_POST['locality'];
                            $pin_code = $_POST['pin_code'];

                            $pin_id = $_POST['pin_id'];

                            $oDb = DBConnection::get();

                            $pins = array();

                            //print_r($oCurrentSchool);

                            $pins = explode(',', $oCurrentSchool->locality_pincode);
                            // print_r($pins);
                            //die("<>>");

                            if (!in_array($pin_code, $pins))
                                {
                                try
                                    {
                                    if ($oCurrentSchool->locality_pincode == '')
                                        {
                                        $pin = $pin_id;
                                        }
                                    else
                                        {
                                        $pin = $oCurrentSchool->locality_pincode . ',' . $pin_id;
                                        }


                                    $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'schools SET locality_pincode = :locality_pincode  WHERE MSID = :MSID');
                                    $status = $sql->execute(array(
                                        ':locality_pincode' => $pin,
                                        ':MSID' => $oCurrentSchool->MSID
                                    ));
                                    if ($status)
                                        {
                                        $message = new Messages();
                                        //$message->add('s', 'Updated successfully!');
                                        echo 'success';
                                        }
                                    else
                                        {
                                        echo 'erroaaar';
                                        }
                                    }
                                catch (Exception $ex)
                                    {
                                    echo $ex->getMessage();
                                    }
                                }

//                          die(">>>");
                            //$oDb = DBConnection::get();
//                          
                            try
                                {
                                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'locality (MSID,post_id, name) VALUES (:MSID,:post_id, :name)');

                                $sql->execute(array(
                                    ':MSID' => $MSID,
                                    ':post_id' => $id,
                                    ':name' => $locality
                                ));
                                $local_id = $oDb->lastInsertId();


                                if ($local_id > 0)
                                    {
                                    echo '<option value="' . $id . '">' . $locality . '</option>';
                                    }
                                else
                                    {
                                    echo 'error';
                                    }
                                }
                            catch (PDOException $e)
                                {
                                //echo 'error';

                                echo $e->getMessage();
                                }
                            }
                        else if ($content == 'hostel')
                            {
                            $id = http_get('param2');
                            $stu_record = Student::get_stu_info($MSID, $id)->fetch();

                            $stu_hostel_data = Hostel::get_allstu_hostel_data($MSID, $id);

                            $stu_record = Student::get_stu_info($MSID, $id)->fetch();

                            // print_r($stu_trans_info);
                            ?>
                            <form method="post" id="hostel_form">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h3 class="box-title"><b>Hostel</b></h3>
                                    </div> 
                                    <div class="col-md-6">
                                        <h4>Hostel</h4>

                                        <table class="table">
                                            <tr>
                                                <th>Student ID</th> <th>Hostel Name</th> <th>Start From</th> <th>To</th>
                                                <th>Action</th>

                                            </tr>
                                            <?php
                                            if ($stu_hostel_data->rowCount() > 0)
                                                {
                                                while ($row_rec = $stu_hostel_data->fetch())
                                                    {

                                                    $hostel = Hostel::get_hostels($MSID, $row_rec['hostel_id'], true)->fetch();
                                                    ?>

                                                    <tr>
                                                        <td><?= $row_rec['s_id'] ?></td><td><?= $hostel['name'] ?></td><td><?php echo $new_date = date("d-m-Y", strtotime($row_rec['from_date'])); ?></td><td><?php echo $new_date2 = date("d-m-Y", strtotime($row_rec['to_date'])); ?></td>
                                                        <td><a class="" id="edit_hostel" data-title="Hostel" data-ms="modal" href="<?= CLIENT_URL ?>/ajax-page-load/hostel_edit/<?= $row_rec['s_id'] ?>/<?= $row_rec['id'] ?>"><b>Edit</b></a>|<a href="javascript:void(0);" class="del_hostel" id="<?= $row_rec['id'] ?>"><b>Delete</b></a></td>
                                                    </tr>





                                                    <?php
                                                    }
                                                }
                                            ?>
                                        </table>

                                    </div>
                                    <div class="col-md-6" id="transport_sec">

                                        <?php
                                        $my_date = $oCurrentUser->mydate;
                                        $hostels = Hostel::get_hostels($MSID, '', true)->fetchAll();
                                        @$hostel_stu_data = Hostel::get_stu_hostel_data($MSID, $id, $my_date)->fetch();
                                        ?>
                                        <select class="form-control" id="hostel" name="hostel">
                                            <option value="">Select</option>
                                            <?php
                                            foreach ($hostels as $hostel)
                                                {

                                                if ($hostel_stu_data['hostel_id'] == $hostel["id"])
                                                    {
//                                                    exit();
                                                    $selected = "selected='selected'";
                                                    }
                                                else
                                                    {
                                                    $selected = '';
                                                    }

                                                echo '<option value="' . $hostel["id"] . '" ' . $selected . '>' . $hostel["name"] . '</option>';
                                                }
                                            ?>
                                        </select> 
                                        <?php
                                        //print_r($oCurrentUser);
                                        ?>
                                    </div>    
                                </div>         

                                <div class="row">   
                                    <div class="col-md-6">
                                        <input type="hidden" name="student_id" id="student_id" value="<?= http_get('param2') ?>"/>
                                        <input type="hidden" name="msid" value="<?= $MSID ?>" id="msid"/>

                                        <input type="hidden" name ="hostel_data" id="tpt_val" value="true" />

                                        <input type="hidden" name="acno" value="<?= $stu_record['acno'] ?>"/>
                                        <input type="hidden" name="s_id" value="<?= $id ?>"/>

                                        <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>"/>

                                        <input type="hidden" name="myuid" value="<?= $oCurrentUser->myuid ?>"/>


                                        <button type="button" name="update_hostel" id="update_hostel" class="btn btn-success">Update</button>            


                                    </div> 


                                </div> 
                            </form>
                            <script>
                                $(document).ready(function ()
                                {

                                    $("#update_hostel").click(function ()
                                    {

                                        var datastring = $("#hostel_form").serialize();
                                        //alert(datastring);




                                        //  var student_id = $("#student_id").val();

                                        //  var  msid = $("#msid").val();




                                        //var datastring = 'tpt='+tpt+'&student_id='+student_id+'&msid='+msid+'&transport='+'true';

                                        //alert(datastring);
                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                // alert(responseText);
                                                //                                                
                                                //                                                alert(responseText);
                                                //alert(responseText);
                                                //alert(responseText);
                                                location.reload();
                                                eModal.close();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {

                                                alert(errorThrown);
                                                if (jqXHR.status == 500) {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                    });
                                    $(".del_hostel").click(function ()
                                    {
                                        var id = $(this).attr('id');
                                        var msid = $("#msid").val();
                                        var acno = $("#acno").val();
                                        var s_id = $("#s_id").val();
                                        var session = $("#session").val();
                                        var myuid = $("#myuid").val();
                                        var datastring = 'id=' + id + '&msid=' + msid + '&del_hostel=' + 'true' + '&s_id=' + s_id + '&acno=' + acno + '&session=' + session + '&myuid=' + myuid;
                                        // alert(datastring);

                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                // alert(responseText);

                                                location.reload();
                                                eModal.close();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {

                                                alert(errorThrown);
                                                if (jqXHR.status == 500) {
                                                    // $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    //$("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                    });
                                });
                            </script>       
                            <?php
                            }
                        else if ($content == 'hostel_edit')
                            {
                            $student_id = http_get('param2');

                            $id = http_get('param3');

                            $hostel_data = Hostel::get_stulast_hostel_data($MSID, $student_id, $id)->fetch();

                            $hostels = Hostel::get_hostels($MSID, '', true)->fetchAll();

                            $stu_record = Student::get_stu_info($MSID, $id)->fetch();
                            ?>
                            <form method="post" id="hostel_edit_form">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Student ID <span class="text-red">*</span></label>
                                            <input class="form-control" type="text" size="30" id="student_id" name="student_id" value="<?= $student_id ?>" readonly="readonly" required/>
                                        </div>
                                        <div class="form-group">
                                            <label>Hostel Name<span class="text-red">*</span></label>
                                            <div class="form-group">
                                                <select class="form-control" id="tpt" name="hostel">
                                                    <option value="">Select</option>
                                                    <?php
                                                    foreach ($hostels as $hostel)
                                                        {

                                                        if ($hostel_data['hostel_id'] == $hostel["id"])
                                                            {
                                                            $selected = "selected='selected'";
                                                            }
                                                        else
                                                            {
                                                            $selected = '';
                                                            }

                                                        echo '<option value="' . $hostel["id"] . '" ' . $selected . '>' . $hostel["name"] . '</option>';
                                                        }
                                                    ?>
                                                </select>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Date From <span class="text-red">*</span></label>
                                            <input class="form-control" type="text" size="25" id="date_from"  value="<?php echo $new_date = date("d-m-Y", strtotime($hostel_data['from_date'])); ?>" name="date_from" required>


                                            <label>Date To <span class="text-red">*</span></label>
                                            <input class="form-control" type="text" size="25" id="date_to" value="<?php
                                            echo $new_date = date("d-m-Y", strtotime($hostel_data['to_date']));
                                            ?>" name="date_to" required>


                                            <input type="hidden" name="msid" value="<?= $hostel_data['MSID'] ?>"/>
                                            <input type="hidden" name="student_id" value="<?= $hostel_data['s_id'] ?>"/>

                                            <input type="hidden" name="hostel_id" value="<?= $hostel_data['id'] ?>"/>
                                            <input type="hidden" name="hostel_edit" value="true"/>
                                            <input type="hidden" name="acno" value="<?= $stu_record['acno'] ?>"/>

                                            <input type="hidden" name="session" value="<?= $oCurrentUser->mysession ?>"/>

                                            <input type="hidden" name="myuid" value="<?= $oCurrentUser->myuid ?>"/>



                                        </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <button type="button" id="hostel_btn" name="hostel_btn" class="btn btn-lg btn-success btn-block">Submit</button>
                                    </div>
                                    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                                </div>





                                </div>







                            </form> 

                            <script>

                                $("#hostel_btn").click(function ()
                                {

                                    var datastring = $("#hostel_edit_form").serialize();
                                    //alert(datastring)


                                    $.ajax({
                                        type: "POST", // type
                                        url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                        data: datastring, // post data
                                        success: function (responseText) { // get the response
                                            // alert(responseText);
                                            //alert(responseText);


                                            location.reload();
                                            eModal.close();
                                        }, // end success
                                        error: function (jqXHR, textStatus, errorThrown) {

                                            alert(errorThrown);
                                            if (jqXHR.status == 500) {
                                                $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                            } else {
                                                $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                            }
                                            $("#process").hide();
                                        }
                                    });
                                });
                            </script>





                            <?php
                            }
                        else if ($content == 'add_holiday')
                            {
//                            print_r(strtotime($_POST['date_from']));
//                            print_r(strtotime($_POST['date_to']));
                            if (strtotime($_POST['date_from']) > strtotime($_POST['date_to']) || $_POST['holiday_name'] == "" || $_POST['date_to'] == "" || $_POST['date_from'] == "")
                                {
                                echo 'error';
                                }
                            else
                                {

                                @$holiday = Attendance:: get_holidays_max($_POST['MSID']);
                                if (@$holiday->rowCount() > 0)
                                    {

                                    while ($holidays = $holiday->fetch())
                                        {
                                        $h_id = $holidays['h_id'] + 1;
                                        }
                                    }
                                $date_from = date('Y-m-d', strtotime($_POST['date_from']));
                                $date_to = date('Y-m-d', strtotime($_POST['date_to']));

                                try
                                    {
                                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'holidays (MSID, ID, DateFrom, DateTo, Particular,colour) VALUES (:MSID, :ID, :DateFrom, :DateTo, :Particular,:colour)');


                                    $sql->execute(array(
                                        ':MSID' => $_POST['MSID'],
                                        ':ID' => $h_id,
                                        ':DateFrom' => $date_from,
                                        ':DateTo' => $date_to,
                                        ':Particular' => $_POST['holiday_name'],
                                        ':colour' => $_POST['colour']
                                    ));
                                    if ($status)
                                        {
                                        echo 'success';
                                        $message = new Messages();
                                        $message->add('s', 'added successfully!');
                                        }
                                    else
                                        {
                                        echo 'error';
                                        }
                                    }
                                catch (PDOException $e)
                                    {
                                    //echo 'error';

                                    echo $e->getMessage();
                                    }
                                }
                            }
                        else if ($content == 'update_holdays')
                            {



                            $id = http_get('param2');

                            $get_holiday = Attendance::get_holidays($MSID, $id);

                            //print_r($get_holiday);

                            @$get_holidays = Attendance::get_holidays($MSID, $id)->fetch();




                            //$stu_record = Student::get_stu_info($MSID, $id)->fetch();
                            ?>
                            <form method="post" id="holiday_edit_form">
                                <div class="row">
                                    <!--<div class="col-md-6">-->
                                    <div class="form-group">
                                        <label>Holiday Name <span class="text-red">*</span></label>
                                        <input class="form-control" type="text" size="30" id="holiday_name" name="holiday_name" value="<?= $get_holidays['Particular'] ?>"/>
                                    </div>
                                    <div class="form-group">
                                        <lable> Select Color</lable> <input type="color" name="colour"  value="<?= $get_holidays['colour'] ?>">
                                    </div>

                                    <div class="form-group">
                                        <label>Date From <span class="text-red">*</span></label>
                                        <input class="form-control adm_date" type="text" size="25" id="date_from"  value="<?php echo $new_date = date("d-m-Y", strtotime($get_holidays['DateFrom'])); ?>" name="date_from" required>


                                        <label>Date To <span class="text-red">*</span></label>
                                        <input class="form-control adm_date" type="text" size="25" id="date_to" value="<?php
                                        echo $new_date = date("d-m-Y", strtotime($get_holidays['DateTo']));
                                        ?>" name="date_to"/>

                                        <input type="hidden" name="edit_holday" value="true"/>
                                        <input type="hidden" name="msid" value="<?= $get_holidays['MSID'] ?>"/>

                                        <input type="hidden" name="ID" value="<?= $get_holidays['ID'] ?>"/>
                                        <input type="hidden" name="holiday_id" value="<?= $get_holidays['holiday_id'] ?>"/>



                                    </div>

                                </div>
                                <!--</div>-->
                                <div class="row">
                                    <div class="col-md-3">
                                        <button type="button" id="holiday_btn" name="holiday_btn" class="btn btn-lg btn-success btn-block">Submit</button>
                                    </div>
                                    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                                </div>





                                </div>







                            </form> 

                            <script>
                                $('.adm_date').datepicker({format: 'dd-mm-yyyy', todayHighlight: true});
                                $('.adm_date').on('changeDate', function (ev) {
                                    $(this).datepicker('hide');
                                });
                                $("#holiday_btn").click(function ()
                                {

                                    var datastring = $("#holiday_edit_form").serialize();
                                    //alert(datastring)


                                    $.ajax({
                                        type: "POST", // type
                                        url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                        data: datastring, // post data
                                        success: function (responseText) { // get the response
                                            //                                            alert(responseText);
                                            //                                        alert(responseText);


                                            if (responseText != 'error') {
                                                location.reload();
                                            } else {
                                                $("#holiday_edit_form").append('<div class="errorDiv text-red">From Date must Be greater then To Date</div>');
                                            }
                                            //                                        
                                            //                                        location.reload();
                                            //                                        eModal.close();
                                        }, // end success  responseText = $.trim(responseText);

                                        error: function (jqXHR, textStatus, errorThrown) {

                                            alert(errorThrown);
                                            if (jqXHR.status == 500) {
                                                $("#transport_sec").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                            } else {
                                                $("#transport_sec").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                            }
                                            $("#process").hide();
                                        }
                                    });
                                });






                            </script>

                            <?php
                            }
                        else if ($content == 'attendance_post')
                            {
                            $student_id = $_POST['id'];

                            $reason = $_POST['reason'];

                            $section = $_POST['section'];

                            $class = $_POST['class'];

                            $attend_date = $oCurrentUser->mydate;

                            $oDb = DBConnection::get();


                            $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
                            $sql .= " where MSID=" . $MSID;

                            $sql .= " AND  SId=" . $student_id;

                            $sql .= " AND  section= '$section'";

                            $sql .= " AND  ClassName = '$class'";

                            $sql .= " AND  AttDate = '$attend_date'";
                            $sql = $oDb->query($sql);

                            //print_r($sql);
                            //die("<>>");

                            if ($sql->rowCount() > 0)
                                {
                                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'attendances SET Reason = :Reason WHERE  MSID = :MSID AND SId = :SId AND AttDate = :AttDate ');
                                $status = $upsql->execute(array(
                                    ':Reason' => $reason,
                                    ':MSID' => $MSID,
                                    ':SId' => $student_id,
                                    ':AttDate' => $attend_date
                                ));

                                echo $status;
                                }
                            }
                        else if ($content == 'holiday_for_all')
                            {
                            $page_name = $_POST['page_name'];
                            if ($page_name == "absent") $page = "A";
                            if ($page_name == "leave") $page = "L";
                            if ($page_name == "holiday") $page = "H";
                            $section = $_POST['section'];
                            $section_id = $_POST['section_id'];
                            $class_name = $_POST['class_name'];
                            $att = $_POST['att'];
                            $attend_date = $oCurrentUser->mydate;

                            $class = $_POST['class'];
//                            $ids = explode(",", +$_POST['student_ids']);
                            $students = Student::get_stu_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, $class_name, @$section_id);
//                            pr($students);
//                            die();
//                            $data = array('class' => $class, 'field_name' => "section", 'field_value' => $section_id); 
//                            $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
                            while ($rows = $students->fetch())
                                {
//                                pr($rows);
                                $oDb = DBConnection::get();
                                $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
                                $sql .= " where MSID=" . $MSID;
                                $sql .= " AND  SId=" . $rows['student_id'];
                                $sql .= " AND  section= '$section'";
                                $sql .= " AND  ClassName = '$class'";
                                $sql .= " AND  AttDate = '$attend_date'";
                                if (@$page) $sql .= " AND  	Att = '$page'";
                                $sql = $oDb->query($sql);
                                $reason = '';
                                //print_r($sql);
                                //die("<>>");

                                if ($sql->rowCount() > 0)
                                    {

                                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'attendances SET Att = :Att WHERE  MSID = :MSID AND SId = :SId AND AttDate = :AttDate ');
                                    $status = $upsql->execute(array(
                                        ':MSID' => $MSID,
                                        ':SId' => $rows['student_id'],
                                        ':AttDate' => $attend_date,
                                        ':Att' => 'H',
                                    ));

                                    echo $status;
                                    }
                                else
                                    {
                                    if ($page == NULL)
                                        {
                                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'attendances (MSID, AttDate,SId,Att,ClassName,section,role) VALUES (:MSID, :AttDate, :SId, :Att, :ClassName, :section, :role)');
                                        $status = $sql->execute(array(
                                            ':MSID' => $MSID,
                                            ':AttDate' => $attend_date,
                                            ':SId' => $rows['student_id'],
                                            ':Att' => 'H',
                                            ':ClassName' => $class,
                                            ':section' => $section,
                                            ':role' => 'student'
                                        ));
                                        }
                                    }
                                }
                            }
                        else if ($content == 'present_for_all')
                            {
                            $section = $_POST['section'];
                            $section_id = $_POST['section_id'];
                            $class_name = $_POST['class_name'];
                            $page_name = $_POST['page_name'];
                            if ($page_name == "absent") $page = "A";
                            if ($page_name == "leave") $page = "L";
                            if ($page_name == "holiday") $page = "H";
                            $att = $_POST['att'];
                            $attend_date = $oCurrentUser->mydate;

                            $class = $_POST['class'];
//                            $ids = explode(",", +$_POST['student_ids']);
                            $students = Student::get_stu_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, $class_name, @$section_id);
                            while ($rows = $students->fetch())
                                {
//                                pr($rows);
                                $oDb = DBConnection::get();
                                $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
                                $sql .= " where MSID=" . $MSID;
                                $sql .= " AND  SId=" . $rows['student_id'];
                                $sql .= " AND  section= '$section'";
                                $sql .= " AND  ClassName = '$class'";
                                $sql .= " AND  AttDate = '$attend_date'";
                                if (@$page) $sql .= " AND  	Att = '$page'";
//                                print_r($sql);
                                $sql = $oDb->query($sql);
                                $reason = '';

                                if ($sql->rowCount() > 0)
                                    {
                                    $oDb = DBConnection::get();
                                    $upsql = $oDb->prepare("Delete From `ms_attendances` where `SId`='" . $rows['student_id'] . "' AND `MSID`='$MSID' AND  AttDate = '$attend_date'");
                                    $upsql->execute();

//            $sql = $oDb->query($sql);
//                                    return $upsql;
                                    }
                                }
                            }
//                        die();
                        else if ($content == 'attendance_emp_post')
                            {
//    print_r($_POST); 
                            $student_id = $_POST['id'];

                            $reason = $_POST['Reason'];

                            $attend_date = $oCurrentUser->mydate;

                            $oDb = DBConnection::get();


                            $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
                            $sql .= " where MSID=" . $MSID;
                            $sql .= " AND  SId=" . $student_id;
                            $sql .= " AND  Role= 'employee'";
                            $sql .= " AND  AttDate = '$attend_date'";
                            $sql = $oDb->query($sql);

                            //print_r($sql);
                            //die("<>>");

                            if ($sql->rowCount() > 0)
                                {
                                $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'attendances SET Reason = :Reason WHERE  MSID = :MSID AND SId = :SId AND AttDate = :AttDate ');
                                $status = $upsql->execute(array(
                                    ':Reason' => $reason,
                                    ':MSID' => $MSID,
                                    ':SId' => $student_id,
                                    ':AttDate' => $attend_date
                                ));

                                echo $status;
                                }
                            }
                        else if ($content == 'attend_post')
                            {
//                            pr($_POST);
                            $student_id = $_POST['id'];
                            $attend = strtoupper($_POST['attend']);
                            $section = $_POST['section'];
                            $class = $_POST['class'];
                            $attend_date = $oCurrentUser->mydate;

                            $oDb = DBConnection::get();

                            $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
                            $sql .= " where MSID=" . $MSID;

                            $sql .= " AND  SId=" . $student_id;

                            $sql .= " AND  section= '$section'";

                            $sql .= " AND  ClassName = '$class'";

                            $sql .= " AND  AttDate = '$attend_date'";



                            $sql = $oDb->query($sql);

                            if ($sql->rowCount() > 0)
                                {
                                if ($attend == 'P')
                                    {
                                    try
                                        {

                                        $oDb = DBConnection::get();
                                        $upsql = $oDb->prepare("Delete From `ms_attendances` where `SId`='$student_id' AND `MSID`='$MSID' AND  AttDate = '$attend_date'");
//            print_r($upsql);
                                        $upsql->execute();

//            $sql = $oDb->query($sql);
                                        return $upsql;
                                        }
                                    catch (PDOException $e)
                                        {
                                        //$message = new Messages();
                                        //$message->add('e', $e->getMessage());
                                        }
                                    }



                                try
                                    {
                                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'attendances SET Att = :Att WHERE  MSID = :MSID AND SId = :SId ');
                                    $status = $upsql->execute(array(
                                        ':Att' => $attend,
                                        ':MSID' => $MSID,
                                        ':SId' => $student_id,
                                    ));
                                    if ($status)
                                        {

                                        echo 'success';
                                        }
                                    else
                                        {
                                        echo 'error';
                                        }
                                    }
                                catch (PDOException $e)
                                    {
                                    echo 'error';

                                    echo $e->getMessage();
                                    }
                                }
                            else
                                {

                                $upsql = $oDb->prepare("Delete From `ms_attendances` where `SId`='$student_id' AND `MSID`='$MSID' AND  AttDate = '$attend_date'");
//            print_r($upsql);
                                $upsql->execute();
                                if ($attend != 'P')
                                    {
                                    try
                                        {



                                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'attendances (MSID, AttDate,SId,Att,ClassName,section,role) VALUES (:MSID, :AttDate, :SId, :Att, :ClassName, :section, :role)');

                                        $status = $sql->execute(array(
                                            ':MSID' => $MSID,
                                            ':AttDate' => $attend_date,
                                            ':SId' => $student_id,
                                            ':Att' => $attend,
                                            ':ClassName' => $class,
                                            ':section' => $section,
                                            ':role' => 'student'
                                        ));
                                        echo $status;
                                        }
                                    catch (PDOException $e)
                                        {

                                        echo $e->getMessage();
                                        }
                                    }
                                }
                            ?>

                            <?php
                            }
                        else if ($content == 'attend_emp_post')
                            {
//    print_r($_POST);
                            $emp_id = $_POST['id'];
                            $attend = strtoupper($_POST['attend']);
                            $attend_date = $oCurrentUser->mydate;
                            $oDb = DBConnection::get();
                            $sql = "SELECT * FROM " . DB_PREFIX . "attendances";
                            $sql .= " where MSID=" . $MSID;
                            $sql .= " AND  SId=" . $emp_id;
                            $sql .= " AND  AttDate = '$attend_date'";
                            $sql = $oDb->query($sql);
                            if ($sql->rowCount() > 0)
                                {
                                if ($attend == 'P')
                                    {
                                    try
                                        {
                                        $oDb = DBConnection::get();
                                        $upsql = $oDb->prepare("Delete From `ms_attendances` where `SId`='$emp_id' AND `MSID`='$MSID' AND  AttDate = '$attend_date'");
                                        $upsql->execute();
                                        return $upsql;
                                        }
                                    catch (PDOException $e)
                                        {
                                        $message = new Messages();
                                        $message->add('e', $e->getMessage());
                                        }
                                    }
                                try
                                    {
                                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'attendances SET Att = :Att WHERE  MSID = :MSID AND SId = :SId ');
                                    $status = $upsql->execute(array(
                                        ':Att' => $attend,
                                        ':MSID' => $MSID,
                                        ':SId' => $emp_id,
                                    ));
                                    if ($status)
                                        {
                                        echo 'success';
                                        }
                                    else
                                        {
                                        echo 'error';
                                        }
                                    }
                                catch (PDOException $e)
                                    {
                                    echo 'error';
                                    echo $e->getMessage();
                                    }
                                }
                            else
                                {
                                $upsql = $oDb->prepare("Delete From `ms_attendances` where `SId`='$emp_id' AND `MSID`='$MSID' AND  AttDate = '$attend_date'");
                                $upsql->execute();
                                if ($attend != 'P')
                                    {
                                    try
                                        {
                                        $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'attendances (MSID, AttDate,SId,section, Att ,role) VALUES (:MSID, :AttDate, :SId, :section,:Att, :role)');
                                        $status = $sql->execute(array(
                                            ':MSID' => $MSID,
                                            ':AttDate' => $attend_date,
                                            ':SId' => $emp_id,
                                            ':section' => $_POST['category'],
                                            ':Att' => $attend,
                                            ':role' => 'employee'
                                        ));
                                        echo $status;
                                        }
                                    catch (PDOException $e)
                                        {
                                        echo $e->getMessage();
                                        }
                                    }
                                }
                            }
                        ?>
