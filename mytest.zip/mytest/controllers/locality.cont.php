<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'locality | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admin'; 
$sMaster = new Master();
$type = http_get('param1');

if($type=='add'){
  $oPageLayout->sWindowTitle = 'Add New locality | ' . CLIENT_NAME;
  
  if(isset($_POST['rsubmit'])){
    $sMaster->add_locality('',$_POST);
  } 
  
  $oPageLayout->sPagePath = PAGES_FOLDER . '/locality/locality-register.inc.php';
 
}
else if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit locality | ' . CLIENT_NAME;
  $loc_id = http_get('param2');

if(isset($_POST['updatesubmit'])){
 $sMaster->add_locality($loc_id,$_POST);
} 

$locality = Master::get_locality($MSID,$loc_id)->fetch(PDO::FETCH_ASSOC);

$oPageLayout->sPagePath = PAGES_FOLDER . '/locality/locality-edit.inc.php'; // special home page
}
else{ 
$locality = Master::get_locality($MSID,'');
$totalrecords = $locality->rowCount();
$oPageLayout->sPagePath = PAGES_FOLDER . '/locality/locality.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>