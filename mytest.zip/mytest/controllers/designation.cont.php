<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Designation | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admin'; 
$sMaster = new Master();
$type = http_get('param1');

if($type=='add'){
  $oPageLayout->sWindowTitle = 'Add New Designation | ' . CLIENT_NAME;
  
  if(isset($_POST['rsubmit'])){
   $sMaster->add_designation('',$_POST);
  } 
  
  $oPageLayout->sPagePath = PAGES_FOLDER . '/designation/designation-register.inc.php';
 
}
else if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit Designation | ' . CLIENT_NAME;
  $des_id = http_get('param2');

    if(isset($_POST['updatesubmit'])){
     $sMaster->add_designation($des_id,$_POST);
  } 
  //get current designation
  $designation = Master::get_designation($MSID,$des_id)->fetch(PDO::FETCH_ASSOC);

$oPageLayout->sPagePath = PAGES_FOLDER . '/designation/designation-edit.inc.php'; // special home page
}
else{ 
$designations = Master::get_designation($MSID);
$totalrecords = $designations->rowCount();
$oPageLayout->sPagePath = PAGES_FOLDER . '/designation/designation.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>