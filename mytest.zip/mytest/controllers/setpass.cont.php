<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for homepage
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
$message = new Messages();

$user = UserManager::get_slusers($oCurrentUser->myuid, $MSID)->fetch(PDO::FETCH_ASSOC);

if (@$_POST['NewPassword']) {
    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $private_key = '6LcbZCQTAAAAADYm49lneSyTDG9QHiImJt8SNcdM';
    $response = file_get_contents($url . "?secret=" . $private_key . "&response=" . @$_POST['g-recaptcha-response']);
    $data = json_decode($response);
    if (isset($data->success) && $data->success == true) {
        if (@$_POST['re-pass'] == @$_POST['pass']) {
            if ($oCurrentUser->ulevel == 3 || $oCurrentUser->ulevel == 9) {
//            pr($_POST);die();
                $password = Employee::update_pasword($MSID, $oCurrentUser->myuid, $_POST['pass']);
            } elseif ($oCurrentUser->ulevel == 2) {
                
            } elseif ($oCurrentUser->ulevel == 1) {
                $password = Student::update_pasword($MSID, $oCurrentUser->myuid, $_POST['pass']);
            }
        } else {
            $message->add('e', 'Password Do Not Match!');
        }
    } else {
        $message->add('e', 'Recaptcha Fail');
    }
}


# include the error template
include_once TEMPLATES_FOLDER . '/setpass.tmpl.php';
?>