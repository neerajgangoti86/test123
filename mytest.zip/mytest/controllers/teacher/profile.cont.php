<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}  
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Profile | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
 
$currentPage = 'Calendar'; 
$uid = explode('E', $oCurrentUser->myuid);
$EmpId = $uid[1];
$employee = Employee::get_employee($MSID, $EmpId, 'all', '', $oCurrentUser->mydate, $out = "false");


$oPageLayout->sPagePath = PAGES_FOLDER . '/teacher/profile.inc.php'; // special home page


# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>