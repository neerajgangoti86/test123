<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Chat';
$admission = new Admission();
$sGeneral = new General();
$sEmployee = new Employee();
$out = "false";


$type = http_get("param1");
$oPageLayout->sWindowTitle = 'Chat | ' . CLIENT_NAME;

if (@$type == 'page') {
    $page = http_get('param2');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}

//******************** Chat box apearence **************************/
if (@$_SESSION['name']) {
    $name = $_SESSION['name'];
    $action = "";
    $style = 'style= "height: 390px !important"';
} else {
    $name = '<---     Select Contact to Start Chat from List     --->';
    $action = 'hidden';
    $style = 'style="height: 430px !important; "';
}

//******************* Setting All Chat List Panels are Hidden ********** */
$e_panel = 'style="display: none; "';
$t_panel = 'style="display: none; "';
$p_panel = 'style="display: none; "';
$s_panel = 'style="display: none; "';


if ($oCurrentUser->ulevel == 1) {

    $user_id = $oCurrentUser->myuid;
    $label = "S";
    /*     * ************** Getting Assigned Class *************** */
    $myuid = explode('S', $oCurrentUser->myuid);
    $student = Student::get_students($oCurrentUser->myuid, '1', $myuid[1])->fetch(PDO::FETCH_ASSOC);
    $days = Master::get_week_days_ttl($MSID, $oCurrentSchool->activity_day);
    while ($r2m = $days->fetch()) {
        for ($i = 1; $i <= $oCurrentSchool->Periods; $i++) {
            $section = (@$student['section']) ? $student['section'] : 1;
            $present = Master::get_timetable($MSID, $student['class_name'], $r2m['WDayId'], $i, $oCurrentUser->mydate, $section);
            while ($emp = $present->fetch()) {
                $employe = Employee::get_employee($MSID, $emp['empid'], $limit = 'all', null, $oCurrentUser->mydate, $out = "false")->fetch(PDO::FETCH_ASSOC);
                $employee[$i] = $employe['uid'];
            }
        }
    }

    /*     * ************** Chat Tabs *********************** */
    $tabs = '<div class="col-md-4 chat-list active-list">Teachers</div>';

    /*     * ************* Default Chat Panel ************************* */
    $t_panel = 'style ="display:block;"';
} elseif ($oCurrentUser->ulevel == 2) {
    $user_id = $oCurrentUser->myuid;

    $p_id = explode('P', $user_id);
    $students = Parents::get_childrens($p_id[1], $oCurrentUser->mydate);
    $teachers = array();
    $j = 0;
    while ($stdnt = $students->fetch()) {
        $student = Student::get_students($oCurrentUser->myuid, '1', $stdnt['student_id'])->fetch(PDO::FETCH_ASSOC);
        $days = Master::get_week_days_ttl($MSID, $oCurrentSchool->activity_day);
        while ($r2m = $days->fetch()) {
            for ($i = 1; $i <= $oCurrentSchool->Periods; $i++) {
                $section = (@$student['section']) ? $student['section'] : 1;
                $present = Master::get_timetable($MSID, $student['class_name'], $r2m['WDayId'], $i, $oCurrentUser->mydate, $section);
                while ($emp = $present->fetch()) {
                    $teacher = Employee::get_employee($MSID, $emp['empid'], $limit = 'all', null, $oCurrentUser->mydate, $out = "false")->fetch(PDO::FETCH_ASSOC);
                    $teachers[$i . $j] = $teacher['uid'];
                }
            }
        }
        $j++;
    }

    //**************** Chat Tabs ************************//
    $tabs = '<div class="col-md-4 chat-list active-list">Teachers</div>';

    //************** Default Chat Panel **************************//
    $t_panel = 'style ="display:block;"';
} elseif ($oCurrentUser->ulevel == 3) {
    $user_id = $oCurrentUser->myuid;
    $id = explode('E', $user_id);

    //*************** Getting Assigned Class ****************//
    $getStudentClasses = Master::get_teacher_timetable($MSID, $id[1]);

    //*************** Chat Tabs ************************//
    $tabs = '<div class="col-md-4 chat-list active-list" id="s_panel">Students</div>';
    $tabs .= '<div class="col-md-4 chat-list" id="p_panel">Parents</div>';
    $tabs .= '<div class="col-md-4 chat-list" id="e_panel">Employees</div>';

    //************** Chat Panels **************************//
    $s_panel = 'style="display: block;"';
} elseif ($oCurrentUser->ulevel == 9) {
    $user_id = $oCurrentUser->myuid;

    //*************** Defining Tabs ************************//
    $tabs = '<div class="col-md-4 chat-list active-list" id="s_panel">Students</div>';
    $tabs .= '<div class="col-md-4 chat-list" id="p_panel">Parents</div>';
    $tabs .= '<div class="col-md-4 chat-list" id="e_panel">Employees</div>';

    $s_panel = 'style="display: block;"';
}
$sender = $user_id;

//********************** All Conversations of Current User ************************/
$getconversation = Chat::all_conversations($MSID, NULL, array('field_one' => $user_id));
$allEmployee = Employee::get_employee($MSID, NULL, $limit = 'all', null, $oCurrentUser->mydate, $out = "false");

//********************** Conversation Data ********************************/
$chat_data = Chat::get_inbox($MSID, NULL, $oCurrentUser->ulevel, $user_id, "", "true", "", array('page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $chat_data->rowCount();
$total_no_recrd = Chat::get_inbox($MSID, NULL, $oCurrentUser->ulevel, $user_id, "", 'true', 'all')->rowCount();

//******************* Add New Chat Message ******************/
if (@$_POST) {
    $postdata = array(
        'message' => @$_POST['msg'],
        'from_role' => @$_POST['from_role'],
        'to_role' => @$_POST['to_role'],
        'from_id' => $_POST['from_id'],
        'to_id' => $_POST['to_id'],
        'date_time' => date("Y-m-d H:i:s"),
        'ip' => $_SERVER['REMOTE_ADDR'],
    );

    Chat::new_message($MSID, $postdata);
}

//**************** Update Message Status **********************/
if (@$_POST['start_chat']) {
    $_SESSION['start_chat'] = $_POST['start_chat'];
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['sender'] = $_POST['sender'];
    $_SESSION['receiver'] = $_POST['receiver'];
    $_SESSION['chat_id'] = $_POST['chat_id'];
    $_SESSION['to_role'] = $_POST['to_role'];
    $data = array(
        'read' => $_POST['read'],
        'chat_id' => $_POST['chat_id'],
    );
    Chat::update_message($MSID, $data);
}
if (@$_POST['conversation']) {
    $data = array(
        'read' => $_POST['read'],
        'chat_id' => $_POST['conversation'],
    );
    Chat::update_message($MSID, $data);
}
$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'users');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/chat/inbox.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>