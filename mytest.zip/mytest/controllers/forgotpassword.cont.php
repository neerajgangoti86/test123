<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for homepage
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$message = new Messages();

/*$oPageLayout->sWindowTitle = 'Dashboard | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'sdfsf sdfsdf sdfsdf';
$oPageLayout->sMetaKeywords = 'sdfsdf, sdfs, sdfsf, sdf';*/



//$oPageLayout->sPagePath = PAGES_FOLDER . '/users/forgotpassword.inc.php'; // special home page

# include the error template
include_once TEMPLATES_FOLDER . '/forgotpassword.tmpl.php';
?>