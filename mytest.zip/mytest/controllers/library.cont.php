<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Library | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Library';
$sLibrary = new Library();
$type = http_get('param1');
$action = http_get('param2');

if ($type == 'cat')
    {
    if ($action == 'delete')
        {
        $id = http_get('param3');
        /**
         * Delete record action function 
         * */
        if (!empty($id))
            {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'book_category',
                'redirect' => CLIENT_URL . '/library/cat',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
            }
        }
    if ($action == 'page')
        {
        $page = http_get('param3');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }
    $library = Library::get_category($MSID, '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $library->rowCount();
    $total_no_recrd = $sLibrary->get_category($MSID, '')->rowCount();
    $links = 3;
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'homework');
    $pagination = $Paginator->createLinks($links, 'pagination');
    $oPageLayout->sPagePath = PAGES_FOLDER . '/library/cat.inc.php'; // special home page
    }
else if ($type == 'book')
    {
    if ($action == 'delete')
        {
        $id = http_get('param3');
        /**
         * Delete record action function 
         * */
        if (!empty($id))
            {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'book',
                'redirect' => CLIENT_URL . '/library/book',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
            }
        }
    if ($action == 'page')
        {
        $page = http_get('param3');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }
    $books = Library::get_books($MSID, '', '', '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $books->rowCount();
    $total_no_recrd = $sLibrary->get_books($MSID)->rowCount();
    $links = 3;
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'homework');
    $pagination = $Paginator->createLinks($links, 'pagination');
    $oPageLayout->sPagePath = PAGES_FOLDER . '/library/book.inc.php'; // special home page
    }
else if ($type == 'issue')
    {
    $oPageLayout->sWindowTitle = 'Issue Books | ' . CLIENT_NAME;
    if (isset($_POST['bookSubmit']))
        {
        $sLibrary->add_issue_book('', $_POST);
        }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/library/issue_book-register.inc.php';
    }
else if ($type == 'due')
    {
    if ($action == 'return')
        {
        $id = http_get('param3');
        $get_book_details = Library::get_due_book($MSID, $id)->fetch();
        $due_date = strtotime($get_book_details['due_date']);
        $current_date = strtotime(date('Y-m-d'));
        if ($current_date <= $due_date)
            {
            $fine_amount = 0;
            }
        else
            {
            echo "fine";
            $datetime1 = new DateTime(date('Y-m-d h:i:s', strtotime($get_book_details['due_date'])));
            $datetime2 = new DateTime();
            $interval = $datetime1->diff($datetime2);
            $fine_amount = $interval->format('%a');
            }

        $get_book_details = $sLibrary->add_return_book($id, $fine_amount);
        }
    if ($action == 'page')
        {
        $page = http_get('param3');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }
    $due_books = Library::get_due_book($MSID, '', '', '1', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $due_books->rowCount();
    $total_no_recrd = $sLibrary->get_due_book($MSID, '', '', '1')->rowCount();
    $links = 3;
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'library/due');
    $pagination = $Paginator->createLinks($links, 'pagination');
    $oPageLayout->sPagePath = PAGES_FOLDER . '/library/due.inc.php'; // special home page
    }
else if ($type == 'return')
    {
    if ($action == 'page')
        {
        $page = http_get('param3');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }
    $due_books = Library::get_due_book($MSID, '', '', '0', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $due_books->rowCount();
    $total_no_recrd = $sLibrary->get_due_book($MSID, '', '', '0')->rowCount();
    $links = 3;
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'library/returned_books');
    $pagination = $Paginator->createLinks($links, 'pagination');
    $oPageLayout->sPagePath = PAGES_FOLDER . '/library/returned_books.inc.php'; // special home page
    }
    
    else if ($type == 'list')
    {
         $oPageLayout->sPagePath = PAGES_FOLDER . '/library/list.php';
    }
    
    
else
    {
    if ($type == 'delete')
        {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id))
            {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'homework',
                'redirect' => CLIENT_URL . '/homework',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
            }
        }
    if ($type == 'page')
        {
        $page = http_get('param2');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }

    $homeworks = Homework::get_homeworks($MSID, '', $id, '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $homeworks->rowCount();
    $total_no_recrd = Homework::get_homeworks($MSID, '', $id)->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'homework');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/homework/homework.inc.php'; // special home page
    }

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>