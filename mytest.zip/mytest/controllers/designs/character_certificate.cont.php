<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */    

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'birth-certificate | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admin'; 
$sMaster = new Master();
//$type = http_get('param1');
$id = http_get('param1');


    $my_date  = $oCurrentUser->mydate;
    

$oPageLayout->sPagePath = PAGES_FOLDER . '/designs/character/character38.php'; // special home page


# include the main template
if(isset($_POST['rsubmit']))
{
	include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
}
else
{
$students = Student::get_students($oCurrentUser->myuid,'1', $id)->fetch(PDO::FETCH_OBJ);
    
include_once TEMPLATES_FOLDER . '/default.tmpl.php';

}
?>