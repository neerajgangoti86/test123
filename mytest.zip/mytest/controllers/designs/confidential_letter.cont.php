<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'birth-certificate | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admin'; 
$sMaster = new Master();
                $id = http_get('param1');
                $student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_ASSOC);
               
$oPageLayout->sPagePath = PAGES_FOLDER . '/designs/confidential_letter/confidential.php'; // special home page


# include the main template
include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
?>