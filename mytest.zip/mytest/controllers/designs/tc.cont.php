<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'TC | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
$currentPage = 'Admin'; 
$sMaster = new Master();
$type = http_get('param1');
$oPageLayout->sPagePath = PAGES_FOLDER . '/designs/tc/'.$type;

if(isset($_POST['rsubmit']))
{
   
 $old_student_tc = Student::old_student_tc_register($MSID,$_POST);
// print_r($_POST);
// exit();
//$_SESSION['old_std_id']= $old_student_tc;
 include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
   
//include_once TEMPLATES_FOLDER . '/elements/report_headers.tmpl.php';

}
else
{







$oPageLayout->sPagePath = PAGES_FOLDER . '/designs/tc/'.$type; // special home page


# include the main template
# 
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
}
?>