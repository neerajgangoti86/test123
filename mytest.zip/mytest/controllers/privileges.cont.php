<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Privilages | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Configuration';
$sRole = new Role();
$type = http_get('param1');

if ($type == 'new') {
    $oPageLayout->sWindowTitle = 'New Privilage | ' . CLIENT_NAME;

    $role = Role::get_role();
    if (@$_POST['role']) {
        $ulevel = $sRole->get_role($_POST['role'])->fetch(PDO::FETCH_ASSOC);
    }
    
    if(@$_POST['addprivilege'])
    {
        $sRole->add_privilages($MSID, $_POST);
    }
    

    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/Privileges-register.inc.php';
} else if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Privilege | ' . CLIENT_NAME;
    $id = http_get('param2');
    $roles = Role::get_role($id)->fetch();

    $selected = Role::privilages($MSID, $id);
    
    $count_data = $selected->rowCount();
    if ($count_data > 0) {
        $data = $selected->fetch();
        //print_r($data);
        $fields = json_decode($data['modules'], true);
        //print_r($fields);
//        die();
        $selected_module = array();
        if (@$fields) {
            foreach ($fields as $k => $val) {
                $selected_module[] = $val;
            }
        }
        //print_r($selected_module);
    }
//    print_r($selected_module);
    if (@$_POST['updatePrivilege']) {
        $sRole->update_privilages($MSID, $id, $_POST);
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/Privileges-edit.inc.php'; // special home page
} else {
    if ($type == 'delete') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'privileges_users',
                'redirect' => CLIENT_URL . '/privileges',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }

    $roles = Role::privilages($MSID);
    $totalrecords = $roles->rowCount();
    $total_no_recrd = Role::privilages($MSID)->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'privileges');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/privileges.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>