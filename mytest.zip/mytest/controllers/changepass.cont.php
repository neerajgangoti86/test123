<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for homepage
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$message = new Messages();

$oPageLayout->sWindowTitle = 'Dashboard | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'sdfsf sdfsdf sdfsdf';
$oPageLayout->sMetaKeywords = 'sdfsdf, sdfs, sdfsf, sdf';


if(@$_POST['change_pass'])
{
      if(@$_POST['change_pass'] != @$_POST['pass'])
      {

        $message->add('e', 'Please Enter Same Password!');
			
	  }
	  else
	  {

            
	
  $result = Employee::change_pasword($MSID,$oCurrentUser->myuid);
  //print_r($result);
  
  //$result = $result->fetch(); 
  if($result->rowCount() > 0)
  {
	$old_password = $result->fetch();
	
	$old_pass = $old_password['password'];
	if($old_pass != $_POST['old_password'])
	{
	   $message->add('e', 'Your Password is not matched');

		
	}
	else
	{
		
		$passowrd = Employee::update_pasword($MSID,$oCurrentUser->myuid,$_POST);
		
	}
	
	  
  }
  
	  }
	
	
  
	
}


$oPageLayout->sPagePath = PAGES_FOLDER . '/users/changepassword.inc.php'; // special home page

# include the error template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>