<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
$sMaster = new Master();

$oPageLayout->sWindowTitle = 'Configuration | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Configuration'; 

$school_board = Master::get_school_board();

//submit school form
if(isset($_POST['updateschool'])){
 $sMaster->register_school($oCurrentSchool->id,$_POST,$_FILES,CLIENT_URL.'/settings'); 
}
$classes = Master::get_classes($MSID,'','','default')->fetchAll(PDO::FETCH_ASSOC);
if(!$oCurrentSchool){
  showHttpError(404);
}
//$parent = Parents::get_parents($MSID,$payrent_id)->fetch(PDO::FETCH_ASSOC);
$oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/setting.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>