<?php

# check if controller is required by index.php 
if (!defined('ACCESS'))
    die;

$oPageLayout = new PageLayout();
//$oPageLayout->sWindowTitle = "Login ";

$sReferrer = http_session("loginReferrer", CLIENT_URL);

# user already logged in?
if ($oCurrentUser) {
    # send to admin
    http_redirect($sReferrer);
}
if (isset($_POST['loginsubmit'])) {
    $oUser = UserManager::login($_POST['username'], $_POST['password'], @$_POST['remember']);
    if ($oUser) {
        $status = UserManager::get_status($_POST['username'], $_POST['password'])->fetch(PDO::FETCH_ASSOC);
        if ($status['mypsw'] == md5('pass')) {
            http_redirect(http_session('password', CLIENT_URL . "/password"));
        } else {
            if (http_get("param1") == 'favicon.ico') {
                http_redirect($sReferrer);
            }
            http_redirect($sReferrer);
        }
    } else {
        # set statusUpdate
        //http_redirect($sReferrer);
        $message = new Messages();
        $message->add('e', 'Username/Password incorrect');
    }
}
include_once TEMPLATES_FOLDER . '/login.tmpl.php';
?>