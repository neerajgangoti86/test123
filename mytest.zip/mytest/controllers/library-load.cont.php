<?php
# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");
$oDb = DBConnection::get();
/*
 * this part used for enrolled form page to list/select existing parents
 */
if ($content == 'issue_book') {
    if (@$_POST['student_id']) {
        $student_id = $_POST['student_id'];
        $student = Student::get_students($oCurrentUser->myuid, '', $student_id);
        $totalrecords = $student->rowCount();
        if ($totalrecords > 0) {
            $Student_detail = $student->fetch(PDO::FETCH_ASSOC);
            ?> 
            <div class="form-group"><label>Book Name</label>
                <label><?= $Student_detail['name']; ?></label>
            </div><?php
        } else {
            ?>
            <div class="form-group"> 
                <span class="text-red">Student Id doesn't exist<span><br>
                        </div>
            <?php
        }
    } if (@$_POST['book_id']) {
        $book_id = $_POST['book_id'];
        $book = Library::get_books($MSID, '', $book_id);
        $totalrecords = $book->rowCount();
        if ($totalrecords > 0) {
            $book_detail = $book->fetch(PDO::FETCH_ASSOC);
            ?> 
                        <div class="form-group"> <label>Book Name</label>
                            <input type="text" value="<?= $book_detail['title']; ?>" name="book_name"></label>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div class="form-group">   
                            <input type="hidden" value="" name="book_name">
                            <span class="text-red">Book Id doesn't exist<span><br>
                                    </div>  
                        <?php
                    }
                }


                exit();
            } 
            
            else if ($content == 'update_book') { //used in fee type and fee group page
                $book = Library::get_books($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
                ?>
                            <form id="ajaxForm" method="post" action="" role="form">
                                <input type="hidden" name="update_book" value="true" />
                                <input type="hidden" name="id" value="<?= $id ?>" />
                                <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                            <?php ?>
                                <div class="col-md-12">


                                    <div class="form-group">
                                        <label>Book No.<span class="text-red">*</span></label>
                                        <input type="number" name="isbn" size="30" value="<?= $book['isbn'] ?>" placeholder="12345" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label>Book Name<span class="text-red">*</span></label>
                                        <input type="text" name="title" size="30" value="<?= $book['title'] ?>"class="form-control">
                                    </div>
<!--                                    <div class="form-group">
                                        <label>category<span class="text-red">*</span></label>
                                        <select name="category_id" class="class_check form-control">
                                            <option value="">Select</option>
                                            <?php
//                                            $categorys = Library::get_category($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
//                                            ?>
                                            //<?php
//                                            foreach ($categorys as $category) {
//                                                if ($category['id'] == $book['category_id']) {
//                                                    $selected = 'selected= "selected"';
//                                                } else {
//                                                    $selected = '';
//                                                }
//                                                echo '<option value="' . $category['id'] . '"' . $selected . '>' . $category['name'] . '</option>';
//                                            }
                                            ?>
                                        </select>
                                    </div>  -->
                                    <div class="form-group">
                                        <label>Author<span class="text-red">*</span></label>
                                        <input type="text" name="author" value="<?= $book['author'] ?>" size="30" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label>Admision No.<span class="text-red">*</span></label>
                                        <input type="number" name="edition" value="<?= $book['edition'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Card No.<span class="text-red">*</span></label>
                                        <input type="text" name="publisher" value="<?= $book['publisher'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Name<span class="text-red">*</span></label>
                                        <input type="number" name="copy_taken" value="<?= $book['copy_taken'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Issue Date<span class="text-red">*</span></label>
                                        <input type="text" name="shelf_no" value="<?= $book['shelf_no'] ?>" size="30" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label>Return Date<span class="text-red">*</span></label>
                                        <input type="text" name="book_position" value="<?= $book['book_position'] ?>" size="30" class="form-control">
                                    </div>


                                </div>


                                <div class="form-group">
                                    <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
                                </div>
                                <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

                            </form>

                            <script>
                                $(function () {
                                    $('#ajaxSubmit').click(function () {
                                        $('#ajaxForm .errorDiv').remove();
                                        var datastring = $("#ajaxForm").serialize();
                                        $("#process").show();
                                        ///ajax code
                                        $.ajax({
                                            type: "POST", // type
                                            url: "<?= CLIENT_URL ?>/ajax-page-post", // request file
                                            data: datastring, // post data
                                            success: function (responseText) { // get the response
                                                //                                                alert(responseText);
                                                responseText = $.trim(responseText);
                                                if (responseText != 'error') {
                                                    location.reload();
                                                    eModal.close();
                                                } else {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                                                }
                                                $("#process").hide();
                                            }, // end success
                                            error: function (jqXHR, textStatus, errorThrown) {
                                                if (jqXHR.status == 500) {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                                } else {
                                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                                }
                                                $("#process").hide();
                                            }
                                        });
                                        // end
                                        return false;
                                    });
                                });
                            </script>
    <?php
}
?>
