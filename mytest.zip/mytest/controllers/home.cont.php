<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for homepage
 */

# make pageLayout Object
$oPageLayout = new PageLayout();



$oPageLayout->sWindowTitle = 'Dashboard | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'sdfsf sdfsdf sdfsdf';
$oPageLayout->sMetaKeywords = 'sdfsdf, sdfs, sdfsf, sdf';

$tran = new Transport();
//print_r($oCurrentUser);
//$MSID="1001";

/* $school_session = Master::get_session($MSID, $fieldname, 'DESC')->fetch();
  $data['start'] = $school_session['begins'];
  $data['ends'] = $school_session['ends'];
  $data['page'] = $page;
  //    print_r($data);
  //    die();
  $data['record_per_page'] = $records_per_page; */


//print_r($students = Student::get_students($oCurrentUser->myuid,'all'));
$students = Student::get_students($oCurrentUser->myuid, 'all')->rowCount();

//print_r(Student::get_students($oCurrentUser->myuid,'all'));
$fee_total = Houses::get_daily_fee_recive($oCurrentUser->myuid, $oCurrentUser->mydate);


//print_r($fee_total);
//print_r($fee_total);

$girls = Student::get_students($oCurrentUser->myuid, 'all', '', '', array('field_name' => 'gender', 'field_value' => 'F'))->rowCount();
$boys = Student::get_students($oCurrentUser->myuid, 'all', '', '', array('field_name' => 'gender', 'field_value' => 'M'))->rowCount();
$employee = Employee::get_employee($MSID, '', '', array('page' => 1, 'record_per_page' => 8), $oCurrentUser->mydate);
$empcount = Employee::get_employee($MSID, '', 'all', '', $oCurrentUser->mydate)->rowCount();

$newAddedstd = Student::get_students($oCurrentUser->myuid, '', '', '', array('page' => 1, 'record_per_page' => 3));

$parent_count = Parents::get_parents_count($oCurrentUser->myuid)->fetch();

$transport_count = $tran->get_std_routes($oCurrentUser->myuid)->fetchAll();

$total_trans = 0;
foreach ($transport_count as $trans) {
    $total_trans = $total_trans + $trans['ttlstd'];
}




//print_r($transport_count);

/* attendence section */
$classes_list = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);

$activityfeed = ActivityFeed::get_activity_feeds($MSID, 6);

$oPageLayout->sPagePath = PAGES_FOLDER . '/home/home.inc.php'; // special home page
# include the error template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>