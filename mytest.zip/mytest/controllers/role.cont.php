<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Role | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Configuration';
$sRole = new Role();
$type = http_get('param1');

if ($type == 'add') {
    $oPageLayout->sWindowTitle = 'Add New Role | ' . CLIENT_NAME;

    if (isset($_POST['roleadd'])) {
//      print_r($_FILES);
//      exit();
        $sRole->add_role('', $_POST);
    }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/role-register.inc.php';
} else if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Role | ' . CLIENT_NAME;
    $id = http_get('param2');
    $roles = Role::get_role($id)->fetch();

    $selected = Role::get_privlages($MSID, $id);
    $count_data = $selected->rowCount();
    if ($count_data > 0) {
        $get_columns = $selected->fetch();
        $fields = json_decode($get_columns['privilege_id'], true);
        $selected_modules = array();
        if (@$fields) {
            foreach ($fields as
                    $k =>
                    $val) {
                $selected_module[] = $val;
            }
        }
    }
//    print_r($selected_module);
    if (isset($_POST['roleupdate'])) {
        $sRole->add_role($id, $_POST);
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/role-edit.inc.php'; // special home page
} else {
    if ($type == 'delete') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'user_roles',
                'redirect' => CLIENT_URL . '/role',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }

    $roles = Role::get_role('',
                    array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $roles->rowCount();
    $total_no_recrd = Role::get_role()->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'role');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/configuration/role.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>