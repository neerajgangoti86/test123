<?php
# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");



?>

