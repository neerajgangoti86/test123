<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Transport Route | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Transport'; 
$sTransport = new Transport();
$sGeneral = new General();
$type = http_get('param1');

if($type=='add'){
  $oPageLayout->sWindowTitle = 'Add New Route | ' . CLIENT_NAME;
  
  if(isset($_POST['rsubmit'])){
   $sTransport->add_tpt_route('',$_POST);
  } 
  
  $oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptroutes-register.inc.php';
 
}
else if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit Route | ' . CLIENT_NAME;
  $route_id = http_get('param2');
  
  if(isset($_POST['updatesubmit'])){
     $sTransport->add_tpt_route($route_id,$_POST);
  } 
  //get current designation
  $tptroutes = Transport::get_tptroutes($MSID,$route_id)->fetch(PDO::FETCH_ASSOC);

$oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptroutes-edit.inc.php'; // special home page
}
else{ 
$route_id = http_get('param2'); 
/**
* Delete record action function 
**/
if($type=='delete'){
if(!empty($route_id)){
 $dataarr = array(
		   'id'        => $route_id,
		   'tablename' => 'tpt_routes',
		   'redirect'  => CLIENT_URL.'/tptroutes',
		   'where'     => 'route_id'
		  );
$deleterecored = General::delete($dataarr);
}
}

  
/*end hide/show column*/	
if($type=='page'){
 $page = http_get('param2');
}else{
 $page = 1;
}
if(isset($_SESSION['r_per_page'])){
$records_per_page=$_SESSION['r_per_page'];
}else{
$records_per_page=RECORDS_PER_PAGE;
}

$tptroutes = Transport::get_tptroutes($MSID,'','',array('selectAll'=>'false','page'=>$page,'record_per_page'=>$records_per_page));
$totalrecords = $tptroutes->rowCount();
$total_no_recrd = Transport::get_tptroutes($MSID)->rowCount();

$links      = 3;

$Paginator  = new Paginator( $total_no_recrd, $records_per_page ,$page,'tptroutes');

$pagination = $Paginator->createLinks( $links, 'pagination' );

$oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptroutes.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>