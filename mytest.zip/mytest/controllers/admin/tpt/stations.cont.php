<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Transport Stations | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Transport'; 
$sTransport = new Transport();
$type = http_get('param1');
 $tptroutes = Transport::get_tptroutes($MSID,'',0);

 if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit Transport Stations | ' . CLIENT_NAME;
  $station_id = http_get('param2');
  $tptroutes = Transport::get_tptroutes($MSID,'',0);
    if(isset($_POST['updatesubmit'])){
     $sTransport->add_tpt_stations($station_id,$_POST);
  } 
  //get current designation
  $tptstations = Transport::get_tptstations($MSID,$station_id)->fetch(PDO::FETCH_ASSOC);

$oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptstations-edit.inc.php'; // special home page
}
else{
if($type=='delete'){
$station_id = http_get('param2');
/**
* Delete record action function 
**/
if(!empty($station_id)){
 $dataarr = array(
		   'id'        => $station_id,
		   'tablename' => 'tpt_stations',
		   'redirect'  => CLIENT_URL.'/tptstations',
		   'where'     => 'station_id'
		  );
$deleterecored = General::delete($dataarr);
} 
}
if($type=='page'){
 $page = http_get('param2');
}else{
 $page = 1;
}
if(isset($_SESSION['r_per_page'])){
$records_per_page=$_SESSION['r_per_page'];
}else{
$records_per_page=RECORDS_PER_PAGE;
}

$tptstations = Transport::get_tptstations($MSID,'','',array('selectAll'=>'false','page'=>$page,'record_per_page'=>$records_per_page));
$totalrecords = $tptstations->rowCount();
$total_no_recrd = Transport::get_tptstations($MSID)->rowCount();

$links      = 3;

$Paginator  = new Paginator( $total_no_recrd, $records_per_page ,$page,'tptstations');

$pagination = $Paginator->createLinks( $links, 'pagination' );

$oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptstations.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>