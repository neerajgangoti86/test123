<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Transport Route Wise List | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
$transport = new Transport();
$currentPage = 'Transport';

//print_r($oCurrentUser);


@$routeId = http_get('param2');
if (!empty($routeId)) {
    if (http_get('param1') == 'tptroutewise_detail') {
        $tptroutes = $transport->get_std_routes($oCurrentUser->myuid,@$routeId,'');
        $totalrecords = $tptroutes->rowCount();
        $oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptroutewise_detail.inc.php';
    }
} else {
    $tptroutes = $transport->get_std_routes($oCurrentUser->myuid,'','');
    $totalrecords = $tptroutes->rowCount();

    $oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptroutewise.inc.php'; // special home page
}# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>