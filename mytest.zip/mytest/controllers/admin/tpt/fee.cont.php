<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Transport Fee | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Transport';
$sTransport = new Transport();
$type = http_get('param1');
if ($type == "add") {
    $oPageLayout->sWindowTitle = "Add New Transport Fee |" . CLIENT_NAME;
    $tptstations = Transport::get_tptstations($MSID, '', 1);
    if (isset($_POST['rsubmit'])) {
        $sTransport->add_tpt_fees('', $_POST);
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptfee-register.inc.php';
} elseif ($type == "edit") {

    $oPageLayout->sWindowTitle = 'Edit Transport Fee| ' . CLIENT_NAME;
    $id = http_get('param2');
    $tptstations = Transport::get_tptstations($MSID, '');
    $tptfees = Transport::get_tptfees($MSID, '');
    if (isset($_POST['updatesubmit'])) {
        $sTransport->add_tpt_fees($id, $_POST);
    }
    //get current designation
    $tptfees = Transport::get_tptfees($MSID, $id)->fetch(PDO::FETCH_ASSOC);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptfee-edit.inc.php'; // special home page
} else {
    if ($type == 'delete') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'tpt_fee',
                'redirect' => CLIENT_URL . '/tptfee',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }

    $tptfee = Transport::get_tptfees($MSID, '', '', $oCurrentUser->mydate, array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page) );
    $totalrecords = $tptfee->rowCount();
    $total_no_recrd = Transport::get_tptfees($MSID, '', '', $oCurrentUser->mydate)->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'tptfee');

    $pagination = $Paginator->createLinks($links, 'pagination');
    $oPageLayout->sPagePath = PAGES_FOLDER . '/transport/tptfee.inc.php'; // special home page
}




# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>