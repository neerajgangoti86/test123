<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Assign Transport | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Transport';
//---------------------------GET CLASSES LIST--------------------------------------//
$getClass = Master::get_classes($MSID);
$ClassID = @$_POST['class'];
//---------------------------CHECK IF THERE IS SECTIONS AVAILABLE--------------//
if (@$_POST['class'] != NULL) {
    $ClassID = $_POST['class'];
    $getSection = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $ClassID);
    $total_record = $getSection->rowCount();
}

if (@$_POST['GetTransportData']) {
    if (@$_POST['section'] != NULL) {
     $data = array(
        'class' => @$_POST['class'],
        'field_name' => 'section',
        'field_value' => @$_POST['section']
    ); } else
        {   $data = array(
        'class' => @$_POST['class']
        ); }
   
    $GetStudent = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
    
    $tpt_std = Transport::get_stu_tpt($MSID, $oCurrentUser->mydate, $ClassID, $oCurrentUser->mysession);
}
if (@$_POST['UpdateTransportData']) {
//    pr($_POST);die();
    $stn = $_POST['station'];
    $strt = $_POST['startDate'];
    $end = $_POST['endDate'];
    foreach($_POST['student'] as $key=>$id){
        Transport::update_student_tpt($MSID, $id, $stn[$key], $strt[$key], $end[$key]);
    }
    
}




$oPageLayout->sPagePath = PAGES_FOLDER . '/transport/assign_transport.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>