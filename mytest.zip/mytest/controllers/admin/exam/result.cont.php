<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Result | ' . CLIENT_NAME;


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');


//Show the list of classes 
$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//Show the lisr of subject groups
$school_sub = SuperAdmin::get_school_subject($MSID, '', 'all');


$text = '';

// For the post data to be stored on variabels
if (isset($_POST['exam_add_datesheet_form']))
    {
    if ($_POST['class_id'] != Null)
        {
        $selected_class = $_POST['class_id'];
        // used in section 
        $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
        }
    if (@$_POST['assesment'])
        {
        $selected_assesment = $_POST['assesment'];
        }
    if (@$_POST['section_id'])
        {
        $selected_section = $_POST['section_id'];
        }
    }
// Show the add marks with students
if (@$_POST['exam_add_performance'])
    {
    if ((@$selected_class || @$selected_class != NULL) && @$selected_assesment && @$text == '')
        {
        $get_status = Exam::get_datesheets($MSID, '', $selected_assesment, '', '', $selected_class, $selected_section, $oCurrentUser->mysession);
        $count = $get_status->rowCount();
        if ($count > 0)
            {
            $datesheet_data = $get_status->fetch();
            $datesheet_id = $datesheet_data['id'];
            $get_record = Exam::get_accademinc_performance($MSID, $datesheet_id);
            $ttlcount = $get_record->rowCount();

            if ($ttlcount > 0)
                {
                $display = "1";
                $get_data = $get_record->fetch();
                }
            }
        else
            {
            $display = NULL;
            }
        }
    else
        {
        $display = NULL;
        }
    }
// Data for Dropdown
if (@$selected_class && $selected_class != NULL)
    {
    // for the list of assesments acc to class
    $assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class)->fetchAll(PDO::FETCH_ASSOC);
    }

$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/result.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>