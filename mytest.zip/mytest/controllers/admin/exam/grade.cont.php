<?php

# check if controller is required by index.php
//if (!defined('ACCESS')) {
//    echo 'Directory access is forbidden.';
//    die;
//}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Exam Grade  | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if ($type == 'del') {
    if (!empty($id)) {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'exam_grades',
            'redirect' => CLIENT_URL . '/exam-grades',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
    }
}
/* start hide/show column */
$grade_array = array(
    "grade" => " Grade",
    "percent_from" => " Percent From",
    "percent_to" => " Percent To",
    "5_point_grade" => " 5 point Grade",
    "grade_point" => " Grade Point",
    "for_class" => " Classes"
);

if (isset($_POST['columnsubmit'])) {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val) {
        $fields[$val] = $grade_array[$val];
    }
    $data = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id,
            DB_PREFIX . "exam_grades", $data);
}
//
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id,
        DB_PREFIX . "exam_grades");
$count_data = $existing->rowCount();
if ($count_data > 0) {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_columns_grades = array();
    foreach ($fields as $k => $val) {
        $selected_columns_grades[] = $k;
    }
}
if (empty($selected_columns_grades)) {
    $selected_columns_grades = array('grade', 'percent_from', 'percent_to',
        '5_point_grade', 'grade_point', 'for_class');
}
/* end hide/show column */
if ($type == 'page') {
    $page = http_get('param2');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}

$exam_grade = Exam::get_exam_grades($MSID, '',
                array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $exam_grade->rowCount();
$total_no_recrd = Exam::get_exam_grades($MSID)->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page,
        'exam-grades');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/grade.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>