<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Regular Test Reports | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Test Report';

/*
 * Get Student Classes
 */
$getClass = Student::get_student_class($MSID);

/*
 * Get Student Section
 */
if(@$_POST['ClassID'] != NULL)
{
$getSection = Student::get_class_section($MSID, $_POST['ClassID']);
$total_record = $getSection->rowCount();
$selectedClass = $_POST['ClassID'];
}


/*
 * Get Week Start - End Date
 */
$CurrentDate = $oCurrentUser->mydate;
$year = date('Y', strtotime($CurrentDate));
$date = new DateTime($CurrentDate);
$WeekNumber = $date->format("W");

function weeklyDates($week, $year) {
    $time = strtotime("1 January $year", time());
    $day = date('w', $time);
    $time += ((7 * $week) + 1 - $day) * 24 * 3600;
    $Date[0] = date('Y-m-j', $time);
    $time += 6 * 24 * 3600;
    $Date[1] = date('Y-m-j', $time);
    return $Date;
}

/*
 * Get Monthly Start - End Date
 */


if (@$_POST['ClassID'] != NULL) {
    $selectedClass = $_POST['ClassID'];
    $forClass = Student::get_student_class($MSID, $selectedClass)->fetch();
    if (@$_POST['reportType'] == 'weekly') {

        $date       = weeklyDates($WeekNumber, $year);
        $StartDate  = $date[0];
        $EndDate    = $date[1];
        $rTypeW     = 'selected ="selected"';
        $data = array('class' => $selectedClass);
        $Student = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
        
        $getSubject = Student::get_student_test_subject($MSID, $selectedClass, $StartDate, $EndDate, $oCurrentUser->mysession);
        $getDate = Student::get_student_test_subject($MSID, $selectedClass, $StartDate, $EndDate, $oCurrentUser->mysession);
    }    
    elseif (@$_POST['reportType'] == 'monthly') {
        
        $monthYear = date('F', strtotime($CurrentDate)) . ' ' . date('Y', strtotime($CurrentDate));
        $YearMonth = strtotime($monthYear);
        $StartDate = date('Y-m-01', $YearMonth);
        $EndDate = date('Y-m-t', $YearMonth); 
        $rTypeM = 'selected ="selected"';
        $data = array('class' => $selectedClass);
        $Student = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
        
        $getSubject = Student::get_student_test_subject($MSID, $selectedClass, $StartDate, $EndDate, $oCurrentUser->mysession);
        $getDate = Student::get_student_test_subject($MSID, $selectedClass, $StartDate, $EndDate, $oCurrentUser->mysession);
    }
}


$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/test_report.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>