<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Academic Performance Add | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');


//Show the list of classes 
$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//Show the lisr of subject groups
$school_sub = SuperAdmin::get_school_subject($MSID, '', 'all');


if (http_get('param1') == "edit")
    {
    $selected_class = http_get('param2');
    $selected_assesment = http_get('param3');
    $selected_activity = http_get('param4');
    $selected_subjects = http_get('param5');
    $selected_section = http_get('param6');
    $display = "true";
    }  $text = '';
    
//print_r($text);
// For the post data to be stored on variabels
if (isset($_POST['exam_add_academic_performance_form']))
    {
  

    if (@strtotime($_POST['end_time']) && @strtotime($_POST['start_time']))
        {
        if (@strtotime($_POST['end_time']) <= strtotime($_POST['start_time']))
            {
            $text .= "<p>Start time must be Less than End time</p>";
            }
        }
    if (@$_POST['max_marks'] == "0" && @$_POST['max_marks'] != NULL)
        {
        $text .= "<p>Max Marks must be greater than 0</p>";
        }
    if (@$_POST['pasing_marks'] == "0" && @$_POST['pasing_marks'] != NULL)
        {
        $text .= "<p>Max Marks must be greater than 0</p>";
        }
    if (@$_POST['max_marks'] && @$_POST['pasing_marks'])
        {
        if (@$_POST['max_marks'] < @$_POST['pasing_marks'])
            {
            $text .= "<p>Max Marks must be greater Passing Marks</p>";
            }
        }
    if ($_POST['class_id'] != Null)
        {
        $selected_class = $_POST['class_id'];
        // used in section 
        $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
        }
    if (@$_POST['assesment'])
        {
        $selected_assesment = $_POST['assesment'];
        }
    if (@$_POST['activity'])
        {
        $selected_activity = $_POST['activity'];
        }
    if (@$_POST['sub_id'] != "")
        {
        $selected_subjects = $_POST['sub_id'];
        }
    if (@$_POST['section_id'])
        {
        $selected_section = $_POST['section_id'];
        }
    if (@$_POST['start_time'])
        {
        $start_time = $_POST['start_time'];
        }
    if ($_POST['max_marks'] != NULL)
        {
        $max_marks = $_POST['max_marks'];
        }
    if ($_POST['pasing_marks'] != NULL)
        {
        $passing_marks = $_POST['pasing_marks'];
        }
    if (@$_POST['exam_date'])
        {
        $exam_date = $_POST['exam_date'];
        }
    if (@$_POST['end_time'])
        {
        $end_time = $_POST['end_time'];
        }
    }
// Show the add marks with students
//    echo $selected_class,$selected_assesment,$selected_subjects,$max_marks;
if (@$_POST['exam_add_performance'])
    {
    if (@$_POST['end_time'] && @$_POST['start_time'])
        {
        if (strtotime($_POST['end_time']) > strtotime($_POST['start_time']))
            {
//            echo "yes";
            if ((@$selected_class || @$selected_class != NULL) && @$selected_assesment && @$selected_subjects && @$max_marks && @$text == '' )
                {
                $display = "true";
//        echo "ddfdsfd";
                }
            }
        }
    else
        {
        $display = NULL;
        }
    }
// Data for Dropdown
if (@$selected_class && $selected_class != NULL)
    {
    // for the list of assesments acc to class
    $assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class)->fetchAll(PDO::FETCH_ASSOC);
    // for list of asubjets
    $subjects = SuperAdmin::get_schoolwise_subject2($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES')->fetchAll(PDO::FETCH_OBJ);

    if (@$selected_subjects && @$selected_assesment)
        {
        // for getting max marks fro assesments
        $assesment_detail = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class, $selected_assesment)->fetch(PDO::FETCH_OBJ);
        // list of activites 
        $activityes = Master::get_activetyes_assigned($MSID, '', array('selectAll' => 'true'), $selected_class, $selected_subjects, $selected_assesment)->fetchAll(PDO::FETCH_OBJ);
        }
    }

// Save students masrks 


if (isset($_POST['add_marks_students']))
    {
    Exam::add_exam_acedemic_performance('', $_POST);
    }


$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/academic_performance_add.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>