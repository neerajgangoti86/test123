<?php

//print_r($_POST);
//exit();
# check if controller is required by index.php
//if (!defined('ACCESS')) {
//    echo 'Directory access is forbidden.';
//    die;
//}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Question Bank  | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Question Bank';
$sTransport = new Homework();
//$type = http_get('param1');



    if (@$_POST['class_id'] != Null) {
        $selected_class = $_POST['class_id'];
    }
    if (@$_POST['subject'] != Null) {
        $selected_subject = $_POST['subject'];
    }
    if (@$_POST['chapter'] != Null) {
        $selected_chapter = $_POST['chapter'];
    }
   
    
   $oPageLayout->sPagePath = PAGES_FOLDER . '/exam/view_questions.inc.php';  
  include_once TEMPLATES_FOLDER . '/default.tmpl.php';
    




?>