<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Academic Performance | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if (isset($_POST['exam_add_academic_performance_form'])) {
    if (!empty($_POST['class_id'])) {
        $selected_class = $_POST['class_id'];
    }
    if (!empty($_POST['assesment'])) {
        $selected_assesment = $_POST['assesment'];
    }
    if (!empty($_POST['sub_id'])) {
        $selected_subjects = $_POST['sub_id'];
    }
}
if (isset($_POST['add_accademic_performance'])) {
    $class_id = $_POST['class_id'];
    $assesment_id = $_POST['assesment'];
    $sub_id = $_POST['sub_id'];
    $max_marks = $_POST['max_marks'];
}
if (isset($_POST['academic_performance_posted_form'])) {

    $class_id = $_POST['class'];
    $assesment_id = $_POST['assesment_id'];
    $sub_id = $_POST['sub_id'];
    $max_marks = $_POST['max_marks'];
}

if (!@$selected_class) {
    $selected_class = 1;
}
//else {
//    $selected_class = $_SESSION['class_id_performance'];
//}



if (isset($_POST['add_marks_students'])) {
    $sExam->add_exam_acedemic_performance('', $_POST);
}

if ($type == 'del') {
    $class_id = http_get('param2');
    $assesment_id = http_get('param3');
    $sub_id = http_get('param4');

    $data = array(
        'class' => $class_id
    );
$message = new Messages();
    $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data)->fetchAll();
    foreach ($students as $student) {
        $students_marks = Exam::get_accademinc_performance($MSID, '', $assesment_id,'', $sub_id, $class_id, $student['student_id'])->fetch(PDO::FETCH_ASSOC);
        if (!empty($id)) {
            $oDb = DBConnection::get();
            $upsql = $oDb->prepare('DELETE FROM ms_exam_co_scholastic_areas WHERE id = :id');
            $upsql->execute(array(
                ':id' => $students_marks["id"]
            ));
        }
    }
    $message->add('s', 'Record deleted successfully!', CLIENT_URL . '/academic-performance');
}

$data = array(
    'class' => $selected_class
);

$students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
$totalrecords_students = $students->rowCount();
$exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '', array('selectAll' => 'true'));
$totalrecords = $exam_co_scholastic_areas->rowCount();
$total_no_recrd = Exam::get_exam_co_scholastic_areas($MSID)->rowCount();
$assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class)->fetchAll(PDO::FETCH_ASSOC);
$subjects = SuperAdmin::get_schoolwise_subject($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES')->fetchAll(PDO::FETCH_OBJ);

$students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
$totalrecords_students = $students->rowCount();
$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
if (@$selected_assesment && $selected_assesment != "all") {
    $assesment_selected = $selected_assesment;
}
else {
    $assesment_selected = '';
}
if (@$selected_class && $selected_class != "all") {
    $class_selected = $selected_class;
}
else {
    $class_selected = '';
}
if (@$selected_subjects && $selected_subjects != "all") {
    $subject_selected = $selected_subjects;
}
else {
    $subject_selected = '';
}

$existing_performance = Exam::get_distinct_assesments($MSID, '', $assesment_selected, $subject_selected, $class_selected, '', $_SESSION['year'], array('selectAll' => 'true'));
$totalrecord_existing = $existing_performance->rowCount();
$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/academic_performance.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>