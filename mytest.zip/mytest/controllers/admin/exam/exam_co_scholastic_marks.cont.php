<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Co- Scholastic Marks | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();

$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if (isset($_POST['remarks_form'])) {
    if (!empty($_POST['class_id'])) {
        $selected_class = $_POST['class_id'];
        $_SESSION['class_id_for_marks'] = $_POST['class_id'];
    }
}
if (isset($_POST['remarks'])) {
//    echo '<pre>';


    $sExam->add_remarks('', $_POST);

    exit();
}
if (!@$_SESSION['class_id_for_marks']) {
    $selected_class = 1;
} else {
    $selected_class = $_SESSION['class_id_for_marks'];
}

if ($type == 'del') {
    if (!empty($id)) {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'exam_remarks',
            'redirect' => CLIENT_URL . '/remarks',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
    }
}
/* end hide/show column */
if ($type == 'page') {
    $page = http_get('param2');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}
$data = array(
    'class' => $selected_class
);
$students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
$totalrecords_students = $students->rowCount();

$exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '',
                array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page),
                $selected_class);
$totalrecords = $exam_co_scholastic_areas->rowCount();

$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/co_scholastic_marks.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>