<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Academic Performance Add | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

//pr($oCurrentUser);

if ($oCurrentUser->ulevel == "9") {
//Show the list of classes 
    $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
} else {
    $teacher_data = Exam::get_teacher_classes($MSID, $oCurrentUser->myuid)->fetchall();
    $classes = array();
    $sections = array(); 
    $subjects = array();
    foreach ($teacher_data as $key => $val) {
        $class = Master::get_class_names($MSID, NULL, $val['Class'])->fetch(PDO::FETCH_ASSOC);
        $classes[$class['class_no']] = $val['Class'];
    }
}
$text = '';
//pr($oCurrentUser);
//echo "selected_class";
//print_r($selected_class);
//echo "selected_section";
//print_r($selected_section);
//echo "selected_assesment";
//print_r($selected_assesment);
//print_r($text);
// For the post data to be stored on variabels
if (isset($_POST['exam_add_datesheet_form'])) {

    if ($_POST['class_id'] != Null) {
        $selected_class = $_POST['class_id'];
        // used in section 
        $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
    }
    if (@$_POST['assesment']) {
        $selected_assesment = $_POST['assesment'];
    }
    if (@$_POST['subject']) {
        $selected_subject = $_POST['subject'];
    }

    if (@$_POST['section_id']) {
        $selected_section = $_POST['section_id'];
    }
}

//---- Get Teacher Data @Sections & @Subjects
if (@$selected_class || @$selected_section) {
    foreach ($teacher_data as $selected_classes) {
        $class_name = Master::get_class_names($MSID, $selected_class)->fetch(PDO::FETCH_ASSOC);
        if ($selected_classes['Class'] == $class_name['class_name']) {
            $section = Master::get_schools_section($MSID, $selected_classes['Section'])->fetch();
            $subject = SuperAdmin::get_schoolwise_subject($MSID, $selected_classes['Subject'], array('selectAll' => 'true'))->fetch(PDO::FETCH_ASSOC);
            $sections[$section['section_id']] = $section['sec_name'];
            $subjects[$subject['subject_id']] = $subject['name'];  
        }
    }
}

if (@$selected_class && $selected_class != NULL) {
    // for the list of assesments acc to class
    $assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class)->fetchAll(PDO::FETCH_ASSOC);
}
if ($oCurrentUser->ulevel == 9) {
    $existing_performance = Exam::get_datesheets($MSID, '', @$selected_assesment, '', @$selected_subject, @$selected_class, @$selected_section, $oCurrentUser->mysession, array('selectAll' => 'true'));
} else {
    $existing_performance = Exam::get_datesheets($MSID, '', @$selected_assesment, '', @$selected_subject, @$selected_class, @$selected_section, $oCurrentUser->mysession, array('selectAll' => 'true'));
}



$totalrecord_existing = $existing_performance->rowCount();


$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/datesheet.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>