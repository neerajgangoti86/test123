<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Final Report| ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
//$type = http_get('param1');

    $id= http_get('param1');
if(@$id){
     $class_id= http_get('param2');
    $student=  Student::get_students($oCurrentUser->myuid,'',$id)->fetch(PDO::FETCH_ASSOC);
  $health_data= Exam::get_exam_health_data($MSID,'',
           array('selectAll' => 'true'), $id, $_SESSION['year'],
        '1')->fetch(PDO::FETCH_ASSOC);
}
$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/final_report.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
?>