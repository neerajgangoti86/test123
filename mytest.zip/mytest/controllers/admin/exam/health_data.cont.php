<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
if ($oCurrentUser->ulevel == "9")
    {
//Show the list of classes 
    $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
    }
else
    {
    $teacher_data = Exam::get_teacher_classes($MSID, $oCurrentUser->myuid)->fetchall();
    $classes = array();
    $sections = array();
    $subjects = array();
    foreach ($teacher_data as $key => $val)
        {
        $class = Master::get_class_names($MSID, NULL, $val['Class'])->fetch(PDO::FETCH_ASSOC);
        $classes[$class['class_no']] = $val['Class'];
        }
    }



$oPageLayout->sWindowTitle = 'Health Data | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if (isset($_POST['exam_add_health_data_form']))
    {
    if ($_POST['class_id'] != NULL)
        {
        $selected_class = $_POST['class_id'];
        }
    if (!empty($_POST['term']))
        {
        $term_selected = $_POST['term'];
        }
    if (!empty($_POST['section_id']))
        {
        $selected_section = $_POST['section_id'];
        }
    }



if (isset($_POST['health_data_posted_form']))
    {
    $sExam->add_exam_health_data('', $_POST);
    }

if ($type == 'del')
    {
    if (!empty($id))
        {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'exam_co_scholastic_areas',
            'redirect' => CLIENT_URL . '/co-scholastic-areas',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
        }
    }

if (((@$selected_class != NULL) && (@$term_selected != NULL)) && (@$selected_section != NULL || $oCurrentSchool->section < 2))
    {
    if ($oCurrentSchool->section < 2)
        {
        $data = array(
            'class' => $selected_class
        );
        }
    else
        {
        $data = array(
            'class' => $selected_class,
            'field_name' => 'section',
            'field_value' => $selected_section
        );
        }
    $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
    $totalrecords_students = $students->rowCount();
    $exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '', array('selectAll' => 'true'));
    $totalrecords = $exam_co_scholastic_areas->rowCount();
    $total_no_recrd = Exam::get_exam_co_scholastic_areas($MSID)->rowCount();
    }
$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/health_data.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>