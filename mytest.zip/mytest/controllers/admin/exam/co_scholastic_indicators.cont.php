<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Co- Scholastic Indicators | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if ($type == 'del') {
    if (!empty($id)) {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'exam_co_scholastic_indicators',
            'redirect' => CLIENT_URL . '/co-scholastic-indicators',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
    }
}
/* start hide/show column */
$co_scholastic_indicators_array = array(
    "co_scholastic_id" => " Co-Scholastic-Area",
    "grade" => " Grade",
    "description" => " Description",
);

if (isset($_POST['columnsubmit'])) {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val) {
        $fields[$val] = $co_scholastic_indicators_array[$val];
    }
    $data = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id,
            DB_PREFIX . "co_scholastic_indicators", $data);
}
//
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id,
        DB_PREFIX . "co_scholastic_indicators");
$count_data = $existing->rowCount();
if ($count_data > 0) {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_columns_co_scholastic_indicators = array();
    foreach ($fields as $k => $val) {
        $selected_columns_co_scholastic_indicators[] = $k;
    }
}
if (empty($selected_columns_co_scholastic_indicators)) {
    $selected_columns_co_scholastic_indicators = array('co_scholastic_id',
       'grade', 'description');
}
/* end hide/show column */
if ($type == 'page') {
    $page = http_get('param2');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}

$exam_co_scholastic_indicators = Exam::get_exam_co_scholastic_indicators($MSID, '', '',
                array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $exam_co_scholastic_indicators->rowCount();
$total_no_recrd = Exam::get_exam_co_scholastic_indicators($MSID)->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page,
        'co-scholastic-indicators');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/co_scholastic_indicators.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>