<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);



$oPageLayout->sWindowTitle = 'Health Data | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();

/**
 * Delete record action function 
 * */
    $student_details = Student::get_stu_details($MSID, $oCurrentUser->myuid, $oCurrentUser->mydate);
    $oPageLayout->sPagePath = PAGES_FOLDER . '/exam/health_data_classlist.inc.php'; // special home page
    $type = http_get('param1');


if(@$type){
    
    
    $students = Master::count_health_data($MSID, $type);
    $totalrecords = $students->rowCount();
//    $exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '', array('selectAll' => 'true'));
//    $totalrecords = $exam_co_scholastic_areas->rowCount();
//    $total_no_recrd = Exam::get_exam_co_scholastic_areas($MSID)->rowCount();
 
$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/health_data_list.inc.php'; // special home page
//
}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>