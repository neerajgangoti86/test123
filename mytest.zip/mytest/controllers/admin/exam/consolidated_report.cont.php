<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Consolidated Report | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if (isset($_POST['colsolidated_report'])) {
    if (!empty($_POST['class_id'])) {
        $selected_class = $_POST['class_id'];
    }

    if (!empty($_POST['sub_id'])) {
        $selected_subjects = $_POST['sub_id'];
    }
}

if (@$selected_subjects && $selected_subjects != "all") {
    $subject_selected = $selected_subjects;
} else {
    $subject_selected = '';
}

if (@$selected_class && $selected_class != "all") {
    $class_selected = $selected_class;
} else {
    $class_selected = '';
}
//print_r($selected_class, $selected_subjects);
//class dropdown
if ($oCurrentUser->ulevel == "9") {
//Show the list of classes 
    $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
} else {

    $teacher_data = Exam::get_teacher_classes($MSID, $oCurrentUser->myuid)->fetchall();
    $teach_classes = array();
    $teach_sections = array(); 
    $teach_subjects = array();
    foreach ($teacher_data as $key => $val) {
        $class = Master::get_class_names($MSID, NULL, $val['Class'])->fetch(PDO::FETCH_ASSOC);
        $teach_classes[$class['class_no']] = $val['Class'];
    }

}

//---- Get Teacher Data @Sections & @Subjects
if (@$selected_class || @$selected_section) {
    foreach ($teacher_data as $selected_classes) {
        $class_name = Master::get_class_names($MSID, $selected_class)->fetch(PDO::FETCH_ASSOC);
        if ($selected_classes['Class'] == $class_name['class_name']) {
            $section = Master::get_schools_section($MSID, $selected_classes['Section'])->fetch();
            $subject = SuperAdmin::get_schoolwise_subject($MSID, $selected_classes['Subject'], array('selectAll' => 'true'))->fetch(PDO::FETCH_ASSOC);
            $teach_sections[$section['section_id']] = $section['sec_name'];
            $teach_subjects[$subject['subject_id']] = $subject['name'];
        }
    }
}



//pr($oCurrentUser);
//section dropdown
//$subject_grp = SuperAdmin::get_school_subject($MSID, '', 'all',
//                array('selectAll' => 'true'), $selected_class)->fetch(PDO::FETCH_ASSOC);
//$subjects_all = SuperAdmin::get_subjects_from_group($subject_grp['subject_gp_id'])->fetch(PDO::FETCH_ASSOC);
//$subjects = explode(',', $subjects_all['subjects']);
//$subjects_id = explode(',', $subjects_all['subject_id']);
if (@$selected_class) {

    $subject = SuperAdmin::get_schoolwise_subject2($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES');

    //print_r($subject);

    $subjects = SuperAdmin::get_schoolwise_subject2($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES')->fetchAll(PDO::FETCH_OBJ);
}






$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/consolidated_data.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>