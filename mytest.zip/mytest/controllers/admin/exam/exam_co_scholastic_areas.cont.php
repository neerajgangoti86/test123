<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Co-Scholastic Areas | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if ($type == 'del') {
    if (!empty($id)) {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'exam_co_scholastic_areas',
            'redirect' => CLIENT_URL . '/co-scholastic-areas',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
    }
}
/* start hide/show column */
$co_scholastic_areas_array = array(
    "MSID" => " MSID ",
    "title" => " Title",
    "max_marks" => " Maximum Marks",
    "class" => " Classes"
);

if (isset($_POST['columnsubmit'])) {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val) {
        $fields[$val] = $co_scholastic_areas_array[$val];
    }
    $data = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id,
            DB_PREFIX . "tpt_routes", $data);
}
//
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id,
        DB_PREFIX . "tpt_routes");
$count_data = $existing->rowCount();
if ($count_data > 0) {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_columns_co_scholastic_areas = array();
    foreach ($fields as $k => $val) {
        $selected_columns_co_scholastic_areas[] = $k;
    }
}
if (empty($selected_columns_co_scholastic_areas)) {
    $selected_columns_co_scholastic_areas = array('MSID', 'title', 'max_marks',
        'class');
}
/* end hide/show column */
if ($type == 'page') {
    $page = http_get('param2');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}

$exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '',
                array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $exam_co_scholastic_areas->rowCount();
$total_no_recrd = Exam::get_exam_co_scholastic_areas($MSID)->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page,
        'co-scholastic-areas');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/co_scholastic_areas.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>