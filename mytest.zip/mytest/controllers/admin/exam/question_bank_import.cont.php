<?php

# check if controller is required by index.php
//if (!defined('ACCESS')) {
//    echo 'Directory access is forbidden.';
//    die;
//}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout(); 

$oPageLayout->sWindowTitle = 'Question Bank  | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Question Bank'; 
$sTransport = new QuestionBank();
 
 if(isset($_POST['rsubmit'])){
//       echo '<pre>';
//     print_r(ASSETS_FOLDER."/csv_file/".$_FILES['file']['name']);
//     exit();
    $sTransport->get_questionpaper_import($MSID,ASSETS_FOLDER."/csv_file/".$_FILES['file']['name']);
 } 
 
# include the main template
 $oPageLayout->sPagePath = PAGES_FOLDER . '/exam/questionbankimport.inc.php';
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>