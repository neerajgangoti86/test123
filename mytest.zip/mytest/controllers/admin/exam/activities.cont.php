<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Exam | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$type = http_get('param1');
$action = http_get('param2');
//print_r($action);
//print_r($type);
if ($type == 'delete') {    
    
    $id = http_get('param2');
    /**
     * Delete record action function 
     * */
    if (!empty($id)) {
        $dataarr = array(
            'id' => $id,
                'tablename' => 'activites',
            'redirect' => CLIENT_URL . '/activities',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
    }
}
if ($action == 'page') {
    $page = http_get('param3');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}
$activityes = Master::get_activetyes_list($MSID,'',array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $activityes->rowCount();
$total_no_recrd = Master::get_activetyes_list($MSID)->rowCount();
$links = 3;
$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'activities');
$pagination = $Paginator->createLinks($links, 'pagination');
$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/activities.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>