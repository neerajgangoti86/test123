<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
} 
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Academic Performance Add | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

if (@$_POST['exam_type']) {
    $exam_type = $_POST['type'];
}
if (@$exam_type) {
    
} else {
    $exam_type = 0;
}
//pr(@$exam_type);
//Show the list of classes 
$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//Show the lisr of subject groups
$school_sub = SuperAdmin::get_school_subject($MSID, '', 'all');

if (@http_get('param1') == "add") {
    $id = http_get('param2');
//                    print_r(http_get('param2'));
    $datesheet = Exam::get_datesheets($MSID, $id)->fetch(PDO::FETCH_OBJ);

//                    print_r($datesheet);
    $selected_class = $datesheet->class;
    $selected_section = $datesheet->section;
    $selected_assesment = $datesheet->assessment;
    $selected_subjects = $datesheet->subject;
    $selected_activity = $datesheet->activity;
    $exam_date = $datesheet->exam_date;
    $max_marks = $datesheet->max_marks;
    $passing_marks = $datesheet->pass_marks;
    $end_time = $datesheet->exam_time_to;
    $start_time = $datesheet->exam_time_from;

    if ($selected_class > 10) {
        
        $stream_sub=  Exam::get_streamsubject($MSID, $selected_subjects )->fetch(PDO::FETCH_ASSOC);
//        print_r($stream_sub);
        $students = Student::get_students_streamwise($oCurrentUser->myuid, $selected_class, $stream_sub['subid'], $stream_sub['stream']);
//        print_r($students);
        $students_all = Student::get_students_streamwise($oCurrentUser->myuid, $selected_class, $stream_sub['subid'], $stream_sub['stream'])->fetch();
    } else {
        $data = array(
            'class' => $selected_class,
            'field_name' => 'section',
            'field_value' => $selected_section
        );
        $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
//         print_r($students);
        $students_all = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data)->fetch();
    }

$students_marks = Exam::get_accademinc_performance($MSID, $id, $selected_class, $students_all['student_id'], $selected_section, array('selectAll' => 'true'))->fetch(PDO::FETCH_ASSOC);
if ($students_marks) {
    $exam_type = $students_marks['type'];
}
$totalrecords_students = $students->rowCount();
}
// Data for Dropdown
if (@$selected_class && $selected_class != NULL) {
    // for the list of assesments acc to class
    $assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class)->fetchAll(PDO::FETCH_ASSOC);
    // for list of asubjets
    $subjects = SuperAdmin::get_schoolwise_subject2($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES')->fetchAll(PDO::FETCH_OBJ);

    if (@$selected_subjects && @$selected_assesment) {
        // for getting max marks fro assesments
        $assesment_detail = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class, $selected_assesment)->fetch(PDO::FETCH_OBJ);
        // list of activites 
        $activityes = Master::get_activetyes_assigned($MSID, '', array('selectAll' => 'true'), $selected_class, $selected_subjects, $selected_assesment)->fetchAll(PDO::FETCH_OBJ);
    }
}

// Save students masrks 


if (isset($_POST['add_marks_students'])) {
//    echo "sad";
//    exit();
    Exam::add_exam_acedemic_performance('', $_POST, $exam_type);
}


$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/academic_performance_add.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>