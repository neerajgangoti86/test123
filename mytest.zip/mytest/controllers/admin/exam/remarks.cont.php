<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Assesment | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();

$type = http_get('param1');
$id = http_get('param2');
/**
 * Delete record action function 
 * */
if ($oCurrentUser->ulevel == "9")
    {
//Show the list of classes 
    $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
    }
else
    {
    $teacher_data = Exam::get_teacher_classes($MSID, $oCurrentUser->myuid)->fetchall();
    $classes = array();
    $sections = array();
    $subjects = array();
    foreach ($teacher_data as $key => $val)
        {
        $class = Master::get_class_names($MSID, NULL, $val['Class'])->fetch(PDO::FETCH_ASSOC);
        $classes[$class['class_no']] = $val['Class'];
        }
    }

if (isset($_POST['remarks_form']))
    {
    if ($_POST['class_id'] != NULL)
        {
        $selected_class = $_POST['class_id'];
        }
    if (!empty($_POST['term']))
        {
        $term_selected = $_POST['term'];
        }
    if (!empty($_POST['section_id']))
        {
        $selected_section = $_POST['section_id'];
        }
    }
if (isset($_POST['remarks']))
    {
    $sExam->add_remarks('', $_POST);
    }

if ($type == 'del')
    {
    if (!empty($id))
        {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'exam_remarks',
            'redirect' => CLIENT_URL . '/remarks',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
        }
    }
if (((@$selected_class != NULL) && (@$term_selected != NULL)) && (@$selected_section != NULL || $oCurrentSchool->section < 2))
    {

    if ($type == 'page')
        {
        $page = http_get('param2');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }
    if ($oCurrentSchool->section < 2)
        {
        $data = array(
            'class' => $selected_class
        );
        }
    else
        {
        $data = array(
            'class' => $selected_class,
            'field_name' => 'section',
            'field_value' => $selected_section
        );
        }
    $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);

    $totalrecords_students = $students->rowCount();

    $exam_remarks = Exam::get_exam_remarks($MSID, '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page), $term_selected, $selected_class);
    $totalrecords = $exam_remarks->rowCount();
//print_r($totalrecords);
    $total_no_recrd = Exam::get_exam_remarks($MSID)->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'remarks');

    $pagination = $Paginator->createLinks($links, 'pagination');
    }
$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/remarks.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>