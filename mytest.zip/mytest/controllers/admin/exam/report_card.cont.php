<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Report Crad | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
//$type = http_get('param1');

//$param1 = http_get('param1');
//if ($param1 == "half-yearly" || $param1 == "final-report") {
    if (@$_POST['report_card_form']) {
        if ((@$_POST['class_id']) && ($_POST['class_id'] != NULL)) {
        $selected_class = $_POST['class_id'];
      $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
        if ((@$_POST['section_id']) && ($_POST['section_id'] != "")) {
            $selected_section = $_POST['section_id'];
            $show_result = "show";
        }

        if ((@$show_result) && ($show_result == "show")) {
            $data = array(
                'class' => $selected_class
            );
            $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
            $totalrecords_students = $students->rowCount();
        }
    } }
//} else {
//    $student = Student::get_students($oCurrentUser->myuid, '', $param1)->fetch(PDO::FETCH_ASSOC);
//    $health_data = Exam::get_exam_health_data($MSID, '',
//                    array('selectAll' => 'true'), $param1, $_SESSION['year'],
//                    '1')->fetch(PDO::FETCH_ASSOC);
//}
$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/report_card.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>