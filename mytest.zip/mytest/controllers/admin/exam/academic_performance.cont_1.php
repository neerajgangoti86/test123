<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Academic Performance | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
// Filter for headder
if (isset($_POST['exam_add_academic_performance_form']))
    {

    if ($_POST['class_id'] != Null)
        {
        $selected_class = $_POST['class_id'];
        }
    if (!empty($_POST['assesment']))
        {
        $selected_assesment = $_POST['assesment'];
        }
//    if (!empty($_POST['activity']))
//        {
//        $selected_activity = $_POST['activity'];
//        }
    if (!empty($_POST['sub_id']))
        {
        $selected_subjects = $_POST['sub_id'];
        }
    if (!empty($_POST['section_id']))
        {
        $selected_section = $_POST['section_id'];
        }
    }

//Data for add 
if (isset($_POST['add_accademic_performance']))
    {



    $class_id = $selected_class = $_POST['class_id'];
    $assesment_id = $selected_assesment = $_POST['assesment'];
    $sub_id = $selected_subjects = $_POST['sub_id'];
    @$activity_id = $selected_activity = $_POST['activity'];
    $max_marks = $_POST['max_marks'];
//    print_r($_POST);
//    exit();
    }


if (isset($_POST['academic_performance_posted_form']))
    {

    $class_id = $_POST['class'];
    $assesment_id = $_POST['assesment_id'];
    @$activity_id = $_POST['activity_id'];
    $sub_id = $_POST['sub_id'];
    $max_marks = $_POST['max_marks'];
    echo "sdfdasf";

    $oPageLayout = new PageLayout();

    $oPageLayout->sPagePath = PAGES_FOLDER . '/exam/academic_performance_add.inc.php';
    }


if (isset($_POST['add_marks_students']))
    {


    Exam::add_exam_acedemic_performance('', $_POST);
    }

//for delete 
if ($type == 'del')
    {
    $class_id = http_get('param2');
    $assesment_id = http_get('param3');
    $activity_id = http_get('param4');
    $sub_id = http_get('param5');
    $section_id = http_get('param6');


    $data = array(
        'class' => $class_id,
        'field_name' => 'section',
        'field_value' => $section_id
    );
    $message = new Messages();
    $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data)->fetchAll(PDO::FETCH_ASSOC);

    foreach ($students as $student)
        {
//          echo "<pre>";
//    print_r($student['student_id']);
//    exit();
        $students_marks = Exam::get_accademinc_performance($MSID, '', $assesment_id, $activity_id, $sub_id, $class_id, $student['student_id'], $oCurrentUser->mysession, array('selectAll' => 'true'), '', $section_id)->fetch(PDO::FETCH_ASSOC);
        if (!empty($id))
            {
            try
                {
                $oDb = DBConnection::get();

                $upsql = $oDb->prepare("DELETE FROM ms_exam_acedemic_performance WHERE id =" . $students_marks['id']);
//            print_r($id); 
//                print_r($upsql);
                $upsql->execute();
                }
            catch (PDOException $e)
                {
                $message = new Messages();
                $message->add('e', $e->getMessage());
                }
            }
        }

//    exit();
    $message->add('s', 'Record deleted successfully!', CLIENT_URL . '/academic-performance');
    }

if (@$selected_class || @$selected_class != NULL)
    {
    $data = array(
        'class' => $selected_class
    );

    $students = Student::get_students($oCurrentUser->myuid, 'all', '', '', @$data);
    $totalrecords_students = $students->rowCount();
    }
//   $assesment = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class);
//print_r($assesment);

$assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), @$selected_class, '', '', '', 'YES')->fetchAll(PDO::FETCH_ASSOC);

// $subject = SuperAdmin::get_schoolwise_subject2($MSID, '', array('selectAll' => 'true'), $selected_class, '', 'YES');


$subjects = SuperAdmin::get_schoolwise_subject2($MSID, '', array('selectAll' => 'true'), @$selected_class, '', 'YES')->fetchAll(PDO::FETCH_OBJ);

$exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '', array('selectAll' => 'true'));
$totalrecords = $exam_co_scholastic_areas->rowCount();
$total_no_recrd = Exam::get_exam_co_scholastic_areas($MSID)->rowCount();

$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//$activityes = Master::get_activetyes_list($MSID)->fetchAll(PDO::FETCH_ASSOC);
if (@$selected_assesment && $selected_assesment != "all")
    {
    $assesment_selected = $selected_assesment;
    }
else
    {
    $assesment_selected = '';
    }
if (@$selected_class && $selected_class != "all")
    {
    $class_selected = $selected_class;
    }
else
    {
    $class_selected = '';
    }
if (@$selected_subjects && $selected_subjects != "all")
    {
    $subject_selected = $selected_subjects;
    }
else
    {
    $subject_selected = '';
    }
if (@$selected_activity && $selected_activity != "all")
    {
    $activity_selected = $selected_activity;
    }
else
    {
    $activity_selected = '';
    }
$activityes = Master::get_activetyes_assigned($MSID, '', array('selectAll' => 'true'), $class_selected, $subject_selected, $assesment_selected)->fetchAll(PDO::FETCH_OBJ);
//print_r($activityes);
$existing_performance = Exam::get_distinct_assesments($MSID, '', $assesment_selected, $activity_selected, $subject_selected, $class_selected, '', $_SESSION['year'], array('selectAll' => 'true'), @$selected_section);

//print_r($existing_performance);

$totalrecord_existing = $existing_performance->rowCount();



$oPageLayout->sPagePath = PAGES_FOLDER . '/exam/academic_performance.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>