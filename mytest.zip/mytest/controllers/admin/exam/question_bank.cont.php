<?php

//print_r($_POST);
//exit();
# check if controller is required by index.php
//if (!defined('ACCESS')) {
//    echo 'Directory access is forbidden.';
//    die;
//}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Question Bank  | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Question Bank';
$sTransport = new Homework();
$type = http_get('param1');
if (@$_POST['class_id'] != Null) {
        $selected_class = $_POST['class_id'];
    }
    if (@$_POST['subject'] != Null) {
        $selected_subject = $_POST['subject'];
    }
if ($type == 'add') {
    $oPageLayout->sWindowTitle = 'Create Question Paper | ' . CLIENT_NAME;
//     print_r($_POST);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/exam/questionbank.inc.php';
    include_once TEMPLATES_FOLDER . '/default.tmpl.php';
  if(@$_POST['insert_que']){
//      print_r($_POST);
   $insert_question= QuestionBank::Insert_questions($MSID, $selected_class, $selected_subject, $_POST);   
      
  }    
} 



else if (@$_POST['psubmit']) {
//     print_r($_POST);
 if (@$_POST['class_id'] != Null) {
        $selected_class = $_POST['class_id'];
    }
    if (@$_POST['subject'] != Null) {
        $selected_subject = $_POST['subject'];
    }
   

    $oPageLayout->sPagePath = PAGES_FOLDER . '/designs/question_bank/question.inc.php';
    include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
} else {
    $oPageLayout->sPagePath = PAGES_FOLDER . '/exam/questionbank.inc.php';
    include_once TEMPLATES_FOLDER . '/default.tmpl.php';
}
?>