<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
//print_r($_SESSION);
//exit();
$oPageLayout->sWindowTitle = 'Student List | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Student';
$sStudent = new Student();
$sGeneral = new General();

$fieldname = http_get('param1');
$fieldID = http_get('param2');
//print_r($fieldID);
$param4 = http_get('param3');
$param5 = http_get('param4');

/* start column hide/show script */
$students_array = array(
    "student_id" => " ID",
    "name" => " Name",
    "father_name" => " Father Name",
    "mother_name" => " Mother Name",
    "d_o_b" => " D.O.B.",
    "class_name" => " Class",
    "sms" => " SMS Mobile",
    "locality" => " Locality",
    "acno" => " AC NO.",
    "house" => " House",
    "gender" => " Gender",
    "blood_group" => " Blood Group",
    "admno" => " Adm. No.",
    "adm_date" => " Adm. Date",
    "class" => " Adm. Class No.",
    "transportation" => " Transportation",
    "discount" => " Discount",
    "roll_no" => " Roll No",
    "aadhar" => " Aadhar",
);
if (isset($_POST['columnsubmit'])) {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val) {
        $fields[$val] = $students_array[$val];
    }
    $columndata = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "students", $columndata);
}
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "students");
$count_data = $existing->rowCount();
if ($count_data > 0) {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_columns_students = array();
    foreach ($fields as $k => $val) {
        $selected_columns_students[] = $k;
    }
}
if (empty($selected_columns_students)) {
    $selected_columns_students = array("student_id", "name", "father_name", "mother_name", "d_o_b", "class_name","sms", "locality", "section");
}
/* end column hide/show script */
/* pagination section start */
// if (!empty($param1)) {
//        $page = $param2;
//    } else if (!empty($fieldname) && $fieldname == 'page') {
//        $page = $fieldID;
//    } else {
//        $page = 1;
//    }
if (!empty($param1)) {
//        echo "1";
    $page = $param2;
} else if (!empty($fieldname) && $fieldname == 'page') {
//        echo "2";
    $page = $fieldID;
} else {
//        echo "3";
    $page = 1;
}

if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = 50;
}
$data['page'] = $page;
$data['record_per_page'] = $records_per_page;

/* if(isset($_SESSION['keyword']))
  {
  $keyword = $_SESSION['keyword'];

  }
 */
if (@$_POST['submit']) {
//// 
    
//print_r($_POST);
//exit();
unset($_SESSION['keyword']);
    $keyword = ''; 
} else
if (@$_SESSION['keyword']) {

//print_r($_SESSION['keyword']);
//exit();
    $keyword = $_SESSION['keyword'];
} else {
    $keyword = '';
}
//print_r($keyword);
//$students = Student::get_students($oCurrentUser->myuid, '', '', '', $data, $keyword);
//    $students = Student::get_students($oCurrentUser->myuid, '', '', '', $data);
//    
//    //print_r($students);
//    $totalrecords = $students->rowCount();
//    $total_no_recrd = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data)->rowCount();
$students = Student::get_quick_search($MSID, '-', '', $oCurrentUser->myuid, '', $keyword, $data);

//print_r($students);
//print_r($students);
//print_r($students);

$total_no_recrd = Student::get_quick_search($MSID, '-', 'all', $oCurrentUser->myuid, '', $keyword)->rowCount();

$totalrecords = $total_no_recrd;

//print_r($data);
//exit();

$links = 3;
$url = 'quick-search';
if ($fieldname != 'page') {
    if (!empty($fieldname)) {
        $url .= '/' . $fieldname;
    } if (!empty($fieldID)) {
        $url .= '/' . $fieldID;
    }
}
$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, $url);
$pagination = $Paginator->createLinks($links, 'pagination');

/* pagination section end */

$oPageLayout->sPagePath = PAGES_FOLDER . '/student/quick_search.inc.php';

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>
