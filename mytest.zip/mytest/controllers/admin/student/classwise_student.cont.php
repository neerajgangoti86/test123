<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}  
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'SMS  | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
 
$currentPage = 'SMS'; 

//---------------------------GET CLASSES LIST--------------------------------------//
$getClass = Student::get_student_class($MSID);

$oPageLayout->sPagePath = PAGES_FOLDER . '/student/classwise_student.inc.php'; // special home page


# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>