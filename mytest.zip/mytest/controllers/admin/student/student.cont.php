
<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
//print_r($_SESSION);
//exit();
$oPageLayout->sWindowTitle = 'Student List | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Student';
$sStudent = new Student();
$sGeneral = new General();
$classID = http_get('param1');
$fieldname = http_get('param2');
if ($classID == "editprofile") 
{

    $id = http_get('param2');
    //$student = Student::get_students($oCurrentUser->myuid, $id)->fetch(PDO::FETCH_OBJ);
    $my_date = $oCurrentUser->mydate;

    $student = Student::get_stu_info($MSID, $id)->fetch(PDO::FETCH_OBJ);

    $classs = Master::get_classes($MSID);

    $houses = Master::get_houses($MSID, '', 1)->fetchAll(PDO::FETCH_ASSOC);

    $tptstations = Transport::get_tptstations($MSID, '', 1);

    $tpt_stu_data = Transport::get_transport_stu($MSID, $id, $my_date);

    $dis_stu_data = Transport::get_discounted_stu($MSID, $id, $my_date);

    $hostel = Hostel::get_hostels($MSID, '', true);
    //print_r($hostel);

    /* print_r($hostel);
      $hostel_count = $hostel->rowCount(); */

    $hostels = Hostel::get_hostels($MSID, '', true)->fetchAll();

    //print_r($hostels);

    $hostel_stu_data = Hostel::get_stu_hostel_data($MSID, $id, $my_date);

    //$hostel_stu_data

    $student_record = new Student();

    //$parents = Student::get_parent_info();
    if (isset($_POST['parent_submit'])) {
        $parent = new Parents();
        $parent->update_parent($_POST['parent'], $_POST, $id);
    }

    if (isset($_POST['update_stu_doc'])) {


        $stu_doc = new Student();

        // print_r($_POST);
        //die("<>>");
        $stu_doc->update_stu_doc($MSID, $_FILES, $_POST);
    }


    if (isset($_POST['updatesubmit'])) {

        /* print_r($_POST);

          die("><><o");
         * 
         */

        //echo  $_FILES['photo']['name'];



        if (!empty($_FILES['photo']['name'])) {
            $student_record->update_stuinfo_photo($id, $_POST, $_FILES);
        } else {


            $student_record->update_student($id, $_POST);
        }
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student-edit.inc.php'; // special home page
} else if ($fieldname == "transportation") {


//    print_r($fieldname);
    $fieldname = http_get('param2');
    $fieldID = http_get('param3');

    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "house" => " House",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
         "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name", "mother_name", "d_o_b", "sms", "locality");
    }
    $class = http_get('param1');
    
    
    $tpt_std = Transport::get_stu_tpt($MSID, $oCurrentUser->mydate, $class, $oCurrentUser->mysession, $fieldID);
    
    $total_count = $tpt_std->rowCount();
//    print_r($tpt_std);
    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/stu_tpt.inc.php';
} else if
    
    ($fieldname == "stream") {


//    print_r($fieldname);
    $fieldname = http_get('param2');
    $fieldID = http_get('param3');

    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "stream" => " Stream",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
         "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name","stream", "mother_name", "d_o_b", "sms", "locality");
    }
    $class = http_get('param1');
    
    
   $students = Student::get_student_streamlist($oCurrentUser->myuid);
    
//    $total_count = $tpt_std->rowCount();
//    print_r($tpt_std);
    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/stu_stream.inc.php';
}

else if ($classID == "newadmission")
    {
    $fieldname = http_get('param2');
    $fieldID = http_get('param3');

    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "house" => " House",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
         "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "student_newadmission", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "student_newadmission");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name", "mother_name", "d_o_b", "sms", "locality");
    }
    /* end column hide/show script */
    /* pagination section start */

    if (!empty($param4)) {
        $page = $param5;
    } else if (!empty($fieldname) && $fieldname == 'page') {
        $page = $fieldID;
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }

    $data['newadmission'] = $_SESSION['year'];
//    print_r($_SESSION['year']);
//    exit();
//$data['newadmission'] = $fieldname;
    $school_session = Master::get_session($MSID, $data['newadmission'], 'DESC')->fetch();
    $data['start'] = $school_session['begins'];
    $data['ends'] = $school_session['ends'];
    $data['page'] = $page;
    $data['record_per_page'] = $records_per_page;
//    print_r($data);
    $students = Student::get_students($oCurrentUser->myuid, '', '', '', $data);
    
    //print_r($students);
    $totalrecords = $students->rowCount();
    $total_no_recrd = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data)->rowCount();
//	if($classID=
//	
//	='all'){
//	  $classes = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//	}
//	else {
//	  $classes = Master::get_classes($MSID,$classID)->fetch(PDO::FETCH_ASSOC);
//	}

    $links = 3;
    $url = 'students/' . $classID;
    if ($fieldname != 'page') {
        if (!empty($fieldname)) {
            $url .= '/' . $fieldname;
        } if (!empty($fieldID)) {
            $url .= '/' . $fieldID;
        }
    }
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, $url);
    $pagination = $Paginator->createLinks($links, 'pagination');
    /* pagination section end */

    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student_detail.inc.php';
} else if ($classID == "outgoing") {
    
    $fieldname = http_get('param2');
    $fieldID = http_get('param3');

    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "house" => " House",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
        "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name", "mother_name", "d_o_b", "sms", "locality");
    }
    /* end column hide/show script */
    /* pagination section start */

    if (!empty($param4)) {
        $page = $param5;
    } else if (!empty($fieldname) && $fieldname == 'page') {
        $page = $fieldID;
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
    if (!empty($fieldname)) {
        $data['outgoing'] = $fieldname;
    } else {
//    print_r($_SESSION['year']);
        $data['outgoing'] = $_SESSION['year'];
        $fieldname = $_SESSION['year'];
//die('here'); 
    }
//$data['outgoing'] = $fieldname;
    $school_session = Master::get_session($MSID, $fieldname, 'DESC')->fetch();
    $data['start'] = $school_session['begins'];
    $data['ends'] = $school_session['ends'];
    $data['page'] = $page;
//    print_r($data);
//    die();
    $data['record_per_page'] = $records_per_page;

    $students = Student::get_outgoing_student_dtl($oCurrentUser->myuid);
//    print_r($students);
    $totalrecords = $students->rowCount();
    $total_no_recrd = Student::get_outgoing_student_dtl($oCurrentUser->myuid)->rowCount();
    $links = 3;
    $url = 'students/' . $classID;
    if ($fieldname != 'page') {
        if (!empty($fieldname)) {
            $url .= '/' . $fieldname;
        } if (!empty($fieldID)) {
            $url .= '/' . $fieldID;
        }
    }
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, $url);
    $pagination = $Paginator->createLinks($links, 'pagination');
    /* pagination section end */

    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student_detail.inc.php';
} 
else if ($classID == "alumini") 
    {
    $fieldname = http_get('param2');
    $fieldID = http_get('param3');

    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "house" => " House",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
        "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "student_alumini", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "student_alumini");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name", "mother_name", "d_o_b", "sms", "locality");
    }
    /* end column hide/show script */
    /* pagination section start */

    if (!empty($param4)) {
        $page = $param5;
    } else if (!empty($fieldname) && $fieldname == 'page') {
        $page = $fieldID;
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
    $data['page'] = $page;
    $data['record_per_page'] = $records_per_page;

    $students = Student::get_alumini_students($MSID, '', '', '', $data);
    $totalrecords = $students->rowCount();
    $total_no_recrd = Student::get_alumini_students($MSID, 'all', '', '', $data)->rowCount();
//	if($classID=='all'){
//	  $classes = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//	}
//	else {
//	  $classes = Master::get_classes($MSID,$classID)->fetch(PDO::FETCH_ASSOC);
//	}

    $links = 3;
    $url = 'students/' . $classID;
    if ($fieldname != 'page') {
        if (!empty($fieldname)) {
            $url .= '/' . $fieldname;
        } if (!empty($fieldID)) {
            $url .= '/' . $fieldID;
        }
    }
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, $url);
    $pagination = $Paginator->createLinks($links, 'pagination');
    /* pagination section end */

    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student_detail.inc.php';
} 
else if ($classID == "failstudents") {
    $fieldname = http_get('param2');
    $fieldID = http_get('param3');

    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "house" => " House",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
        "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "student_fail", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "student_fail");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name", "mother_name", "d_o_b", "sms", "locality");
    }
    /* end column hide/show script */
    /* pagination section start */

    if (!empty($param4)) {
        $page = $param5;
    } else if (!empty($fieldname) && $fieldname == 'page') {
        $page = $fieldID;
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
    $data['fail'] = $fieldname;
    $school_session = Master::get_session($MSID, $fieldname, 'DESC')->fetch();
    $data['start'] = $school_session['begins'];
    $data['ends'] = $school_session['ends'];
    $data['page'] = $page;
    $data['record_per_page'] = $records_per_page;

    $students = Student::get_fail_student($MSID, '', '', '', $data);
    $totalrecords = $students->rowCount();
    $total_no_recrd = Student::get_fail_student($MSID, 'all', '', '', $data)->rowCount();
//	if($classID=='all'){
//	  $classes = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//	}
//	else {
//	  $classes = Master::get_classes($MSID,$classID)->fetch(PDO::FETCH_ASSOC);
//	}

    $links = 3;
    $url = 'students/' . $classID;
    if ($fieldname != 'page') {
        if (!empty($fieldname)) {
            $url .= '/' . $fieldname;
        } if (!empty($fieldID)) {
            $url .= '/' . $fieldID;
        }
    }
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, $url);
    $pagination = $Paginator->createLinks($links, 'pagination');
    /* pagination section end */

    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student_detail.inc.php';
} 
else if (@$classID || $classID == '0') {

    $fieldname = http_get('param2');
    $fieldID = http_get('param3');

    $param4 = http_get('param4');
    $param5 = http_get('param5');

    if (!empty($fieldname)) {

        if ($classID != 'all') {
            $data = array('class' => $classID, 'field_name' => $fieldname, 'field_value' => $fieldID);
        } else {
            if ($fieldname != 'page') {
                $data = array('field_name' => $fieldname, 'field_value' => $fieldID);
            }
        }
    } 
   
    else {
        if ($classID != 'all') {
            $data = array('class' => $classID);
        } else {
            $data = array();
        }
    }
    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "house" => " House",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
        "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "students", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "students");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name", "mother_name", "d_o_b", "sms", "locality", "section");
    }
    /* end column hide/show script */
    /* pagination section start */

    if (!empty($param2)) {
        $page = $param3;
    } else if (!empty($fieldname) && $fieldname == 'page') {
        $page = $fieldID;
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
    $data['page'] = $page;
    $data['record_per_page'] = $records_per_page;

    $students = Student::get_students($oCurrentUser->myuid, '', '', '', $data);
    
    $totalrecords = $students->rowCount();


    $total_no_recrd = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data)->rowCount();
    if ($classID == 'all') {
        $classes = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $classes = Master::get_classes($MSID, '', '', '', $classID)->fetch(PDO::FETCH_ASSOC);
    }

    $links = 3;
    $url = 'students/' . $classID;
    if ($fieldname != 'page') {
        if (!empty($fieldname)) {
            $url .= '/' . $fieldname;
        } if (!empty($fieldID)) {
            $url .= '/' . $fieldID;
        }
    }
    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, $url);
    $pagination = $Paginator->createLinks($links, 'pagination');
    /* pagination section end */

    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student_detail.inc.php';
} else {
    /* start column hide/show script */
    $array_students = array(
        "total" => "Total",
        "gender" => "Gender",
        "house" => "House",
        "section" => "Section",
        "category" => "Category",
        "transport" => "Transport"
    );
    if ($oCurrentSchool->school_type != "0") {
        $index = array_search('gender', $array_students);
        unset($array_students[$index]);
    }
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $array_students[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, "students", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, "students");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_students = array();
        foreach ($fields as $k => $val) {
            $selected_students[] = $k;
        }
    }
    if (empty($selected_students)) {
        $selected_students = array("total", "gender", "house", "section", "category", "transport");
    }
    

    /* end column hide/show script */
    $classes = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student.inc.php';
}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>
