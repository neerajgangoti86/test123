<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Edit Student | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Student';

$sGeneral = new General();

//---------------------------GET CLASSES LIST--------------------------------------//
$getClass = Master::get_classes($MSID);
if (@$_POST['class']) $_SESSION['atpt_class'] = @$_POST['class'];
$ClassID = @$_SESSION['atpt_class'];
//---------------------------CHECK IF THERE IS SECTIONS AVAILABLE--------------//
if (@$_POST['class'] != NULL || @$_SESSION['atpt_class'])
    {

    $getSection = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, @$_SESSION['atpt_class']);
//pr($getSection);     
    $total_record = $getSection->rowCount();
    }

if (@$_POST['UpdateStudentEditData'])
    {
//    pr($_POST);
//    pr($_POST);DIE();
//    pr($_FILES);
//    die();
    foreach ($_POST['id'] as $key => $val)
        {
        if (@$_FILES['image']['name'][$val])
            {
            $target_file = "uploads/" . $MSID . "/" . $_FILES['image']['name'][$val];
            $image = move_uploaded_file($_FILES['image']['tmp_name'][$val],  $target_file);
            }
        else
            {
            $target_file = $_POST['previous_image'][$val];
            }
        $name = (@$_POST['name'][$key]) ? $_POST['name'][$key] : $_POST['previous_name'][$val];
        $dob = (@$_POST['dob'][$key]) ? $_POST['dob'][$key] : $_POST['previous_dob'][$val];
        $gender = (@$_POST['gender'][$key]) ? $_POST['gender'][$key] : $_POST['previous_gender'][$val];
        $adm_date = (@$_POST['adm_date'][$key]) ? $_POST['adm_date'][$key] : $_POST['previous_adm_date'][$val];
        $fees_date = (@$_POST['fees_date'][$key]) ? $_POST['fees_date'][$key] : $_POST['previous_fees_date'][$val];
        $aadhar = (@$_POST['aadhar'][$key]) ? $_POST['aadhar'][$key] : $_POST['previous_aadhar'][$val];
        $house = (@$_POST['house'][$key]) ? $_POST['house'][$key] : $_POST['previous_house'][$val];
        $blood_group = (@$_POST['blood_group'][$key]) ? $_POST['blood_group'][$key] : $_POST['previous_blood_group'][$val];
        $opening_bal = (@$_POST['opening_bal'][$key]) ? $_POST['opening_bal'][$key] : $_POST['previous_opening_bal'][$val];
        $amrit_dhari = (@$_POST['amrit_dhari'][$key]) ? $_POST['amrit_dhari'][$key] : $_POST['previous_amrit_dhari'][$val];
        $boarding_id = (@$_POST['boarding_id'][$key]) ? $_POST['boarding_id'][$key] : $_POST['previous_boarding_id'][$val];
        $section = (@$_POST['section'][$key]) ? $_POST['section'][$key] : $_POST['previous_section'][$val];
        $f_name = (@$_POST['f_name'][$key]) ? $_POST['f_name'][$key] : $_POST['previous_father'][$val];
        $m_name = (@$_POST['m_name'][$key]) ? $_POST['m_name'][$key] : $_POST['previous_mother'][$val];
        $f_mobile = (@$_POST['f_mobile'][$key]) ? $_POST['f_mobile'][$key] : $_POST['previous_mobile'][$val];
        $mobilesms = (@$_POST['mobilesms'][$key]) ? $_POST['mobilesms'][$key] : $_POST['previous_mobilesms'][$val];
        $address = (@$_POST['address'][$key]) ? $_POST['address'][$key] : $_POST['previous_address'][$val];
        $ms_students = array(
            'MSID' => $MSID,
            'name' => $name,
            'birth_date' => $dob,
            'gender' => $gender,
            'photo' => "/" . $target_file,
            'adm_date' => $adm_date,
            'fees_date' => $fees_date,
            'aadhar' => $aadhar,
            'house' => $house,
            'blood_group' => $blood_group,
            'opening_bal' => $opening_bal,
            'amrit_dhari' => $amrit_dhari,
            'boarding_id' => $boarding_id,
            'section' => $section,
        );
        $ms_parents = array(
            'f_name' => $f_name,
            'm_name' => $m_name,
            'm_mobile' => $f_mobile,
            'mobile_sms' => $mobilesms,
            'address' => $address,
        );

//        pr($ms_students);
//        pr($ms_parents);
//        die();
        Student::update_all_student($MSID, $val, $ms_students);

        Parents::update_all_parent($MSID, $_POST['parent_id'][$key], $ms_parents);
        }
    }
//$_SESSION['atpt_sec']=1;
if (@$_POST['GetStudentData']) $_SESSION['StudentData'] = @$_POST['GetStudentData'];
if (@$_POST['GetStudentData'] || @$_SESSION['StudentData'])
    {
    if (@$_POST['section_select']) $_SESSION['atpt_sec'] = @$_POST['section_select'];

    $data = array(
        'class' => @$_SESSION['atpt_class'],
        'section' => @$_SESSION['atpt_sec']
    );
//    print_r($data);
    if (@$_POST['section_select'] != NULL || @$_SESSION['atpt_sec'])
        {
        $GetStudent = Student::get_students3($oCurrentUser->myuid, 'all', '', '', $data);
//        
        }
//    else
//        {
//        $GetStudent = Student::get_students3($oCurrentUser->myuid, 'all', '', '', $data);
//        
//        }
//    pr($GetStudent);
    }



$array_colmns = array(
    "Sr" => "Sr",
    "Student Name" => "Student Name",
    "Image" => "Image",
    "DOB" => "D.O.B.",
    "Father Name" => "Father Name",
    "Mother Name" => "Mother Name",
    "Mobile" => "Mobile",
    "Mobile SMS" => "Mobile SMS",
    "Address" => "Address",
    "Gender" => "Gender",
    "Admission Date" => "Admission Date",
    "Fee Start" => "Fee Start",
    "SL Date" => "SL Date",
    "Adhar No" => "Adhar No",
    "House" => "House",
    "Blood Group" => "Blood Group",
    "Opening Balance" => "Opening Balance",
    "Amrit Dhari" => "Amrit Dhari",
    "Boarding ID" => "Boarding ID",
    "Section" => "Section",
);

if (isset($_POST['columnsubmit']))
    {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val)
        {
        $fields[$val] = $array_colmns[$val];
        }


    $columndata = json_encode($fields);  // encoding in json format
//    print_r($columndata);
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, "students_edit", $columndata);
    }
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, "students_edit");
$count_data = $existing->rowCount();
if ($count_data > 0)
    {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_colmns = array();
    foreach ($fields as $k => $val)
        {
        $selected_colmns[] = $k;
        }
    }
if (empty($selected_colmns))
    {
    $selected_colmns = array("Sr", "ID", "Student Name", "Image", "DOB", "Father Name", "Mother Name", "Mobile", "Mobile SMS", "Gender", "Addmission Date", "Fee Start", "Adhar No", "Section");
    }
//$a = array();




$oPageLayout->sPagePath = PAGES_FOLDER . '/student/edit_students.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>