<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Edit Student | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Student';

$sGeneral = new General();

//---------------------------GET CLASSES LIST--------------------------------------//
$getClass = Master::get_classes($MSID);
if (@$_POST['class'])
    $_SESSION['atpt_class'] = @$_POST['class'];
$ClassID = @$_SESSION['atpt_class'];
//---------------------------CHECK IF THERE IS SECTIONS AVAILABLE--------------//
if (@$_POST['class'] != NULL || @$_SESSION['atpt_class']) {

    $getSection = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, @$_SESSION['atpt_class']);
//pr($getSection);     
    $total_record = $getSection->rowCount();
}

if (@$_POST['UpdateStudentEditData']) {
//    pr($_POST);
//    die; //["image"]["tmp_name"]);DIE();  
    foreach ($_FILES['image']['name'] as $key => $val) {
        if ($val) {
            $target_dir = "uploads/".$MSID; //pr($target_dir);
            $target_file = $target_dir ."/". $_FILES['image']['name'][$key]; pr($target_file);
            $imgmove = move_uploaded_file($_FILES['image']['tmp_name'][$key],$target_file);    
            Student::update_all_student_image($MSID, $key, $target_file);
        }
    }
}





if (@$_POST['GetStudentData'])
    $_SESSION['StudentData'] = @$_POST['GetStudentData'];
if (@$_POST['GetStudentData'] || @$_SESSION['StudentData']) {
    if (@$_POST['section'])
        $_SESSION['atpt_sec'] = @$_POST['section'];

    $data = array(
        'class' => @$_SESSION['atpt_class'],
        'section' => @$_SESSION['atpt_sec']
    );
    if (@$_POST['section'] != NULL || @$_SESSION['atpt_sec']) {
        $GetStudent = Student::get_students3($oCurrentUser->myuid, 'all', '', '', $data);
        ;
    } else {
        $GetStudent = Student::get_students3($oCurrentUser->myuid, 'all', '', '', $data);
        ;
    }
//    pr($GetStudent);
}



$array_colmns = array(
    "Sr" => "Sr",
    "ID" => "ID",
    "Student Name" => "Student Name",
    "Image" => "Image",
    
);

if (isset($_POST['columnsubmit'])) {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val) {
        $fields[$val] = $array_colmns[$val];
    }


    $columndata = json_encode($fields);  // encoding in json format
//    print_r($columndata);
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, "students", $columndata);
}
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, "students");
$count_data = $existing->rowCount();
if ($count_data > 0) {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_colmns = array();
    foreach ($fields as $k => $val) {
        $selected_colmns[] = $k;
    }
}
if (empty($selected_colmns)) {
    $selected_colmns = array("Sr", "ID", "Student Name", "DOB", "Father Name", "Mother Name", "Mobile", "Mobile SMS", "Gender", "Addmission Date", "Fee Start", "Adhar No", "Section");
}
//$a = array();




$oPageLayout->sPagePath = PAGES_FOLDER . '/student/edit_students.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>