
<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
//print_r($_SESSION);
//exit();
$oPageLayout->sWindowTitle = 'Student List | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Student';
$sStudent = new Student();
$sGeneral = new General();
$classID = http_get('param1');

 if (@$classID) {


//    print_r($fieldname);
    $stream = http_get('param2');
    $group = http_get('param3');

    /* start column hide/show script */
    $students_array = array(
        "student_id" => " ID",
        "name" => " Name",
        "father_name" => " Father Name",
        "mother_name" => " Mother Name",
        "d_o_b" => " D.O.B.",
        "sms" => " SMS Mobile",
        "locality" => " Locality",
        "acno" => " AC NO.",
        "stream" => " Stream",
        "gender" => " Gender",
        "blood_group" => " Blood Group",
        "admno" => " Adm. No.",
        "adm_date" => " Adm. Date",
        "class" => " Adm. Class No.",
        "transportation" => " Transportation",
        "discount" => " Discount",
        "roll_no" => " Roll No",
        "aadhar" => " Aadhar",
         "religion" => " Religion",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $students_array[$val];
        }
        $columndata = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing", $columndata);
    }
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "student_outgoing");
    $count_data = $existing->rowCount();
    if ($count_data > 0) {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_students = array();
        foreach ($fields as $k => $val) {
            $selected_columns_students[] = $k;
        }
    }
    if (empty($selected_columns_students)) {
        $selected_columns_students = array("student_id", "name", "father_name","stream", "mother_name", "d_o_b", "sms", "locality");
    }
    $class = http_get('param1');
    
    
   $students_stream = Student::get_student_stream($oCurrentUser->myuid, $class, $stream, $group);
  
  $totalrecords = $students_stream->rowCount();
//    print_r($tpt_std);
    $oPageLayout->sPagePath = PAGES_FOLDER . '/student/student_streamlist.inc.php';
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>
