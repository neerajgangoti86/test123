<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Result | ' . CLIENT_NAME;


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Examination';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

if(!@$_POST['report']){
//Show the list of classes 
$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//Show the lisr of subject groups
$school_sub = SuperAdmin::get_school_subject($MSID, '', 'all');

 
//$text = '';

// For the post data to be stored on variabels
 if (isset($_POST['exam_add_datesheet_form']))
     {
     if ($_POST['class_id'] != Null)
         {
         $selected_class = $_POST['class_id'];
         // used in section 
         $sectiondet = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $selected_class);
         }
     if (@$_POST['assesment'])
         {
        $selected_assesment = $_POST['assesment'];
        }
     if (@$_POST['section_id'])
         {
        $selected_section = $_POST['section_id'];
         }
    }

// Data for Dropdown
if (@$selected_class && $selected_class != NULL)
    {
    // for the list of assesments acc to class
    $assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $selected_class)->fetchAll(PDO::FETCH_ASSOC);
    }
$oPageLayout->sPagePath = PAGES_FOLDER . '/reports/consolidate_reports.inc.php';
include_once TEMPLATES_FOLDER . '/default.tmpl.php';

}



else if(@$_POST['report'])
    
{ 
    
    
  if (@$_POST['section_id']) {
         $data = array(
        'class' => $_POST['class_id'],
        'field_name'=>'section' ,
        'field_value'=> $_POST['section_id']
    );
    
    } else {
       $data = array(
        'class' => @$_POST['class']); }    
    
        $GetSubjects = SuperAdmin::get_subjects_from_datesheet($MSID,$_POST['section_id'],$oCurrentUser->mysession,$_POST['assesment'],$_POST['class_id']);
     $Getassessments = SuperAdmin::get_assessment_from_datesheet($MSID,$_POST['section_id'],$oCurrentUser->mysession,$_POST['assesment'],$_POST['class_id']);
       $GetStudent = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
       $Getasses = SuperAdmin::get_assessment_from_date($MSID,$_POST['section_id'],$oCurrentUser->mysession,$_POST['assesment'],$_POST['class_id']);
  
    $oPageLayout->sPagePath = PAGES_FOLDER . '/reports/consolidate_reports.inc.php';
   include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
}



?>