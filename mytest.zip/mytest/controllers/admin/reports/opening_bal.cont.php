<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Opening Balance | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Reports';
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
/* start hide/show column */
//$opening_bal_student_array = array(
//    "MSID" => " MSID ",
//    "s_id" => " Student ID",
//    "s_name" => " Student Name",
//    "class" => " Class",
//    "d_id" => " Discount",
//    "d_name" => " Discount Name",
//    "d_from" => " Date From",
//    "d_to" => " Date To",
//);
//
//if (isset($_POST['columnsubmit']))
//    {
//    $fields = array(); // for making the field array
//    foreach ($_POST['column1'] as $key => $val)
//        {
//        $fields[$val] = $opening_bal_student_array[$val];
//        }
//    $data = json_encode($fields);  // encoding in json format
//    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "opening-bal", $data);
//    }
////
//$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "opening-bal");
//$count_data = $existing->rowCount();
//if ($count_data > 0)
//    {
//    $get_columns = $existing->fetch();
//    $fields = json_decode($get_columns['fields'], true);
//    $selected_columns_opening_bal_student = array();
//    foreach ($fields as $k => $val)
//        {
//        $selected_columns_opening_bal_student[] = $k;
//        }
//    }
//if (empty($selected_columns_opening_bal_student))
//    {
//    $selected_columns_opening_bal_student = array('MSID', 's_id',
//        'd_id', 'd_to');
//    }
/* end hide/show column */
if ($type == 'page')
    {
    $page = http_get('param2');
    }
else
    {
    $page = 1;
    }
if (isset($_SESSION['r_per_page']))
    {
    $records_per_page = $_SESSION['r_per_page'];
    }
else
    {
    $records_per_page = RECORDS_PER_PAGE;
    }

$opening_bal_student = Fee::get_opening_bal($MSID, '', array('page' => $page, 'record_per_page' => $records_per_page));
//print_r($opening_bal_student);
//exit();
$totalrecords = $opening_bal_student->rowCount();
$total_no_recrd = Fee::get_opening_bal($MSID)->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'opening-bal');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/reports/opening_bal.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>