<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Discounted Students | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Reports';
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if ($type == 'del')
    {
    if (!empty($id))
        {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'discounted_student',
            'redirect' => CLIENT_URL . '/co-scholastic-indicators',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
        }
    }
/* start hide/show column */
$discounted_student_array = array(
    "MSID" => " MSID ",
    "s_id" => " Student ID",
    "s_name" => " Student Name",
    "class" => " Class",
    "d_id" => " Discount",
    "d_name" => " Discount Name",
    "d_from" => " Date From",
    "d_to" => " Date To",
);

if (isset($_POST['columnsubmit']))
    {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val)
        {
        $fields[$val] = $discounted_student_array[$val];
        }
    $data = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "discounted_student", $data);
    }
//
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "discounted_student");
$count_data = $existing->rowCount();
if ($count_data > 0)
    {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_columns_discounted_student = array();
    foreach ($fields as $k => $val)
        {
        $selected_columns_discounted_student[] = $k;
        }
    }
if (empty($selected_columns_discounted_student))
    {
    $selected_columns_discounted_student = array('MSID', 's_id',
        'd_id', 'd_to');
    }
/* end hide/show column */
if ($type == 'page')
    {
    $page = http_get('param2');
    }
else
    {
    $page = 1;
    }
if (isset($_SESSION['r_per_page']))
    {
    $records_per_page = $_SESSION['r_per_page'];
    }
else
    {
    $records_per_page = RECORDS_PER_PAGE;
    }

$discounted_student = Discount::get_discounted_students($MSID, $oCurrentUser->mysession, $oCurrentUser->ends, $oCurrentUser->myuid, '', array('page' => $page, 'record_per_page' => $records_per_page));
//print_r($discounted_student);
//exit();
$totalrecords = $discounted_student->rowCount();
$total_no_recrd = Discount::get_discounted_students($MSID, $oCurrentUser->mysession, $oCurrentUser->ends, $oCurrentUser->myuid)->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'discounted-students');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/reports/discounted_students.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>