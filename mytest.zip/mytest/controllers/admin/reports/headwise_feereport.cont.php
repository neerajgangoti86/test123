<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Headwise Fee Report| ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$type = http_get('param1');


 
if (@$_POST['feereport']) {
    
    if (@$_SESSION['date_period_from']) {
        $from = $_SESSION['date_period_from'];
    }
    else {
        $from = $oCurrentUser->my_period_from;
    }
    if (@$_SESSION['date_period_to']) {
        $to = $_SESSION['date_period_to'];
    }
    else {
        $to = $oCurrentUser->my_period_to;
    }
    
    
    
    
    
      $dtfm=$_POST['date_from'];
       $dtto=$_POST['date_to'];
  $oPageLayout->sPagePath = PAGES_FOLDER . '/reports/headwise_feereports.inc.php'; // special home page  
 include_once TEMPLATES_FOLDER . '/blank.tmpl.php';   
    
 }else {
//    
//    
$oPageLayout->sPagePath = PAGES_FOLDER . '/reports/headwise_feereports.inc.php'; // special home page
//# include the main template
  
 include_once TEMPLATES_FOLDER . '/default.tmpl.php';

}

?>