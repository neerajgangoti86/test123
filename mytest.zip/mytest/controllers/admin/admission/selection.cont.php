<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Selection | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admission'; 
$sAdmission = new Admission();

$students = $sAdmission->get_enrolled_std($MSID,'','','','class');
//echo '<pre>';print_r($students);echo '</pre>';
$totalrecords = $students->rowCount();
$oPageLayout->sPagePath = PAGES_FOLDER . '/admissions/selection.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>