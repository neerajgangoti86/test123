<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for homepage
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Enrollment | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admission';
$admission = new Admission();
//create school MSID  id
$s_id = http_get('param1');
if (@$s_id) {
    if (@$s_id == "sucess") {
        $s_id = http_get('param2');
        $std = Student::get_stdnt($MSID, http_get('param2'));
        $std_count = $std->rowCount();
        if ($std_count > 0) {
            $student = $std->fetch(PDO::FETCH_OBJ);
            $step = $student->step;
            $section = $student->section;
            if ($step > 1) {
                $parent_id = $student->parent_id;
                $status = ($section > 0 ) ? 1 : 0;
                $parent = Student::get_parent($MSID, $parent_id)->fetch(PDO::FETCH_OBJ);
            }
        }
    } else {
        $std_id = $s_id;
        $std = Student::get_stdnt_enroll($MSID, $s_id);
        $std_count = $std->rowCount();
        if ($std_count > 0) {
            $student = $std->fetch(PDO::FETCH_OBJ);

            $step = $student->step;
            $section = $student->section;
            if ($step > 1) {
                $parent_id = $student->parent_id;
                $status = ($section > 0 ) ? 1 : 0;
                $parent = Student::get_parent($MSID, $parent_id)->fetch(PDO::FETCH_OBJ);
            }
        }
        if (isset($_POST['rsubmit2'])) {

            $admission->enrollment($MSID, @$_POST['parent'], @$_POST['student'], $_POST, $_FILES);
        } else if (isset($_POST['rsubmit3'])) {
            $admission->enrollment($MSID, '', '', $_POST, $_FILES);
        }
        $parents = Parents::get_parents($MSID);
        $locality = Master::get_locality($MSID, '', 1);
    }
} else {
//submit school form	  
    if (isset($_POST['rsubmit'])) {



        $admission->enrollment($MSID, @$_POST['parent'], @$_POST['student'], $_POST, $_FILES);
    }
// get all localization
    $locality = Master::get_locality($MSID, '', 1);


    $tptstations = Transport::get_tptstations($MSID, '');



    $tpt_stations_count = $tptstations->rowCount();

    $discounts = Transport::get_discount_names($MSID);

    $discount_counts = Transport::get_discount_names($MSID);
    $discount_count = $discount_counts->rowCount();
    $classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);

    $discount = Discount::get_discount($MSID, '', TRUE);
    
    $hostel = Hostel::get_hostels($MSID, '', true);
    //print_r($hostel);
    
    /*print_r($hostel);*/
    $hostel_count = $hostel->rowCount();
    
    $hostels = Hostel::get_hostels($MSID, '', true)->fetchAll();
    
    //print_r($hostels);
    
}
$category = Master::get_category($MSID, '', 1);

$oPageLayout->sPagePath = PAGES_FOLDER . '/admissions/enrollmentform.inc.php'; // special home page
# include the error template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>