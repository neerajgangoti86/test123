<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Rejected | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admission'; 
$admission = new Admission();

$type = http_get('param1');
if($type=='bck'){
 $sGeneral = new General();
 $stdid = http_get('param2');
 $dataarr = array(
			   'id'        => $stdid,
			   'tablename' => 'students',
			   'redirect'  => CLIENT_URL.'/rejected',
			   'where'     => 'student_id',
			   'status'     => '0'
			  );
  $changeback = $sGeneral->activate_deactivate($dataarr);
}

if($type=='page'){
 $page = http_get('param2');
}else{
 $page = 1;
}
if(isset($_SESSION['r_per_page'])){
$records_per_page=$_SESSION['r_per_page'];
}else{
$records_per_page=RECORDS_PER_PAGE;
}

$students = $admission->get_enrolled_std($MSID,'','rejected','','',array('page'=>$page,'record_per_page'=>$records_per_page));
$totalrecords = $students->rowCount();
$total_no_recrd = $admission->get_enrolled_std($MSID,'all','rejected')->rowCount();

$links      = 3;
$Paginator  = new Paginator( $total_no_recrd, $records_per_page ,$page,'rejected');
$pagination = $Paginator->createLinks( $links, 'pagination' );

$oPageLayout->sPagePath = PAGES_FOLDER . '/admissions/rejected.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>