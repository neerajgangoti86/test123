<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'SMS Template | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'SMS';
$type = http_get('param1');
$id = http_get('param2');


$getKeywords = SMS::get_sms_keywords($MSID, "");
if ($type == 'add') {
    if (@$_POST['msid']) {
        SMS::add_sms_template($MSID, $_POST);
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/sms/add_template.inc.php';
} elseif ($type == 'edit') {
    $template = SMS::get_sms_templates($MSID, $id)->fetch(PDO::FETCH_ASSOC);
    if (@$_POST['msid']) {
        SMS::update_sms_template($MSID, $_POST, $id);
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/sms/edit_template.inc.php';
} elseif ($type == 'delete') {
    if (!empty($id)) {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'sms_templates',
            'redirect' => CLIENT_URL . '/sms-template',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
    }
} else {
    $getTemplates = SMS::get_sms_templates($MSID, NULL);
    $oPageLayout->sPagePath = PAGES_FOLDER . '/sms/sms_template.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>