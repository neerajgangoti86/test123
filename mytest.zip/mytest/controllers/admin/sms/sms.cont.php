<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */
//print_r($_POST);
//die();
# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'SMS | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'sms';

$type = http_get('param1');

$sub_type = http_get('param2');
//pr($type);
//---------------------------GET CLASSES LIST--------------------------------------//
$getClass = Master::get_class_names2($MSID);

if ($type == 'employee')
    {
    $smss = Employee::get_employee($MSID, '', 'all', '', $oCurrentUser->mydate, "false");
    }
elseif ($type == 'old_emp')
    {
    $smss = Employee::get_employee($MSID, '', 'all', '', $oCurrentUser->mydate, "true");
    }
elseif ($type == 'stdnt')
    {

    if (@$_POST['message'])
        {
        // to prevent the redirection after the sms sent to display the sucess message.    
        }
    else
        {
        if (!@$_POST['class_no'])
            {
            header('location:' . CLIENT_URL . '/sms');
            }
        if (@$_POST['classes'])
            {
            $sms_for_all = true;
            $classes = array();
            $smss = array();

            foreach ($_POST['class_no'] as $key => $val)
                {
                $data = array('class' => $val);

                $smss[] = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
                }
            }
        }
    }
elseif ($type == 'std')
    {
    if (@http_get('param4'))
        {
        $fieldname = http_get('param3');
        $fieldID = http_get('param4');
        $data = array('class' => http_get('param3'), 'field_name' => $fieldname, 'field_value' => $fieldID);
        }
    else
        {
        $data = array('class' => http_get('param2'));
        }
    $smss = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
    }
elseif ($type == "parents")
    {

    $smss = $parents = Parents::get_parents_detl($MSID, $oCurrentUser->mydate, $oCurrentUser->mysession, '', '', 'all', '');
    }
elseif ($type == "present" && http_get('param4') == 'students')
    {
//    die();
    $att = '';
    $selected_section = http_get('param3');
    $selected_class = http_get('param2');
//    print_r($selected_class);
//    print_r($selected_section);
    if ($selected_section)
        {

        $section_details = Master::get_schools_section($MSID, 1)->fetch();
        $section_name = $section_details['sec_name'];
//        pr($section_name);
        }

    if ($selected_class != NULL && $selected_class != "all")
        {
        $classss = Master::get_class_names3($MSID, $selected_class)->fetch();
        $class_name = $classss['class_name'];
//        pr($class_name);
        $student_attendance = Student::count_students_attendacnce($oCurrentUser->myuid, @$class_name, @$section_name, $att);
        $students = $student_attendance->fetchALL();
        $total_students_array = array();
        foreach ($students as $stu)
            {
            $total_students_array[] = $stu['SId'];
            }
        @$student_id = implode(',', $total_students_array);
        }
    $smss = Student::get_stu_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, $selected_class, @$selected_section, @$student_id);
//pr($smss);
    }
elseif ($type == "absent" && http_get('param4') == 'students')
    {
    $att = 'A';
    if (@http_get('param3') == 'all')
        {
        $class_name = Null;
        $section_name = Null;

        $smss = Student::count_students_attendacnce($oCurrentUser->myuid, @$class_name, @$section_name, $att);
        }
    else
        {

        $selected_section = http_get('param3');
        $selected_class = http_get('param2');

        if ($selected_section)
            {

            $section_details = Master::get_schools_section($MSID, @$selected_section)->fetch();
            $section_name = $section_details['sec_name'];
            }

        if ($selected_class != NULL && $selected_class != "all")
            {
            $classss = Master::get_class_names3($MSID, $selected_class)->fetch();
            $class_name = $classss['class_name'];

            $smss = Student::count_students_attendacnce($oCurrentUser->myuid, @$class_name, @$section_name, $att);
            }
        }
    }
elseif ($type == "leave" && http_get('param4') == 'students')
    {
    $att = 'L';
    if (@http_get('param3') == 'all')
        {
        $class_name = Null;
        $section_name = Null;

        $smss = Student::count_students_attendacnce($oCurrentUser->myuid, @$class_name, @$section_name, $att);
        }
    else
        {

        $selected_section = http_get('param3');
        $selected_class = http_get('param2');

        if ($selected_section)
            {
            $section_details = Master::get_schools_section($MSID, @$selected_section)->fetch();
            $section_name = $section_details['sec_name'];
            }

        if ($selected_class != NULL && $selected_class != "all")
            {
            $classss = Master::get_class_names3($MSID, $selected_class)->fetch();
            $class_name = $classss['class_name'];

            $smss = Student::count_students_attendacnce($oCurrentUser->myuid, @$class_name, @$section_name, $att);
            }
        }
    }
elseif (($type == 'NT' || $type == 'TS') && http_get('param2') == 'present' || http_get('param2') == 'absent' || http_get('param2') == 'leave' || http_get('param2') == 'all')
    {
    $role = http_get('param1');
    if (http_get('param2') == 'present' || http_get('param2') == 'all')
        {
        if (http_get('param2') == 'present')
            {
            $att = '';
            $emp_attendance = Attendance::count_emp_attendacnce($oCurrentUser->myuid, $role, @$att);
            $employees = $emp_attendance->fetchALL();
            $total_emp_array = array();
            foreach ($employees as $emp)
                {
                $total_emp_array[] = $emp['SId'];
                }
            @$emp_id = implode(',', $total_emp_array);

            $smss = Attendance::get_emp_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, @$role, @$emp_id);
            }

        if (http_get('param2') == 'all')
            {
            $att = NULL;
            $emp_id = NULL;
            $smss = Attendance::get_emp_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, @$role, @$emp_id);
            }
        }

    if (http_get('param2') == 'absent' || http_get('param2') == 'leave')
        {
        if (http_get('param2') == 'leave'):$att = 'L';
        endif;
        if (http_get('param2') == 'absent'): $att = 'A';
        endif;

        $smss = Attendance::count_emp_attendacnce($oCurrentUser->myuid, $role, @$att);
        }
    }
elseif (http_get('param2') == "transport")
    {
    $class = http_get('param1');
    $smss = Transport::get_stu_tpt($MSID, $oCurrentUser->mydate, $class, $oCurrentUser->mysession, "false");
    }
elseif ($type == 'feepayer')
    {
    $payertype = http_get('param2');
    $class = http_get('param3');
    if ($payertype == "all")
        {
        $payertype = "defaulters";
        }

    $smss = Fee::get_defaulters($oCurrentUser->myuid, $payertype, $class, 'all');
    }
elseif ($type == 'transportroute')
    {
    $transport = new Transport();
    $smss = $transport->get_std_routes($oCurrentUser->myuid, http_get('param2'), '');
    }

//---------------------------GET CLASSES LIST Ends --------------------------------------//
$getTemplates = SMS::get_sms_templates($MSID, NULL);
$getDefault = SMS::get_sms_templates($MSID, NULL);
$getkeywords = SMS::get_sms_keywords($MSID);

if (@$_POST)
    {
    $data = array();
    $number = array();
    $sucess = array();
    $default_no = " 8894054847";
    $sent = "1";
    $sms_array = array();


// State for live
    if (@$_POST['sms'])
        {

        $text = $_POST['message'];
        $send_state = 1;
        foreach ($_POST['sms'] as $key => $val)
            {
            if ($type == 'TS' || $type == 'NT')
                {
                $employee = Employee::get_employee($MSID, $val, 'all', '', $oCurrentUser->mydate)->fetch(PDO::FETCH_ASSOC);
                }
            if ($sub_type == "advancepayer" || $sub_type == "perfact_payer") $val = $key;
            $student = Student::get_students($oCurrentUser->myuid, 'all', $val, '', '')->fetch(PDO::FETCH_ASSOC);
            $number_std = $student['mobile_sms'];
            $kwrd = SMS::get_sms_keywords($MSID);
            while ($keyword = $kwrd->fetch())
                {

                if ($keyword['table'] == DB_PREFIX . "student" && @$student)
                    {
                    $table = $student;
                    }
                elseif ($keyword['table'] == DB_PREFIX . 'employee' && @$employee)
                    {
                    $table = $employee;
                    }
                if (strpos($text, $keyword['syntex'])) $text = str_replace($keyword['syntex'], @$table[$keyword['field']], $text);
                }
            if (($sub_type == "advancepayer" || $sub_type == "perfact_payer" ) && strpos($text, "[fee_balance]"))
                {
                $text = str_replace("[fee_balance]", $_POST["fee_amt"][$key], $text);
                }
            $msg = $text;
//            $num = $default_no;
            if (@$send_state) $num = $default_no;
//            if (@$send_state) $num = $default_no . "," . $number_std;
//            else $num = $post_no;

            $sms = SMS::get_sms_detail($MSID)->fetch(PDO::FETCH_OBJ);
            $SenderID = $sms->SenderID;
            $UserName = $sms->UserName;
            $Pass = $sms->Pass;
            $sid = $oCurrentSchool->SMSSID;


            //initialize the request variable
            $request = "sms.vmosms.com/submitsms.jsp?";
            //this is the username of our TM4B account
            $param["user"] = "$UserName";
            //this is the password of our TM4B account
            $param["key"] = "$Pass";
            //this is the message that we want to send
            $param["mobile"] = "$num";
            //this is the message that we want to send
            $param["message"] = "$msg";
            //these are the recipients of the message
            $param["senderid"] = "$SenderID";
            //this is our sender
            $param["accusage"] = "1";
            //this is our sender
            //traverse through each member of the param array

            foreach ($param as $key => $val)
                {
                //we have to urlencode the values
                $request.= $key . "=" . urlencode($val);
                //append the ampersand (&) sign after each paramter/value pair
                $request.= "&";
                }

            //remove the final ampersand sign from the request
            $request = substr($request, 0, strlen($request) - 1);
            $handle = curl_init($request);
            curl_setopt($handle, CURLOPT_RETURNTRANSFER, TRUE);
            /* Get the HTML or whatever is linked in $url. */
            $response = curl_exec($handle);


            $data = explode('sent', $response);
            foreach ($data as $key => $val)
                {
                $number = explode(",", $val);
                if (@$number[1] == "success")
                    {
                    $sucess[] = $number[4];
                    }
                }
            $data = explode('fail', $response);
            foreach ($data as $key => $val)
                {
                $number = explode(",", $val);
                if (@$number[1] == "Invalid Mobile")
                    {
                    $sucess[] = $number[4];
                    }
                }
            $data = explode('fail', $response);
            foreach ($data as $key => $val)
                {
                $number = explode(",", $val);
                if (@$number[1] == "Duplicate Mobile")
                    {
                    $sucess[] = $number[4];
                    }
                }
            $text = $_POST['message'];
            $send_state = 0;
            
            }
        }
    else if (@$_POST['num'])
        {
//            die("working on it");
        $text = $_POST['message'];

        $msg = $text;
        $post_no = @$_POST['num'];

        $num = $default_no;
//        $num = $default_no . "," . $post_no;

        $sms = SMS::get_sms_detail($MSID)->fetch(PDO::FETCH_OBJ);
        $SenderID = $sms->SenderID;
        $UserName = $sms->UserName;
        $Pass = $sms->Pass;
        $sid = $oCurrentSchool->SMSSID;


        //initialize the request variable
        $request = "sms.vmosms.com/submitsms.jsp?";
        //this is the username of our TM4B account
        $param["user"] = "$UserName";
        //this is the password of our TM4B account
        $param["key"] = "$Pass";
        //this is the message that we want to send
        $param["mobile"] = "$num";
        //this is the message that we want to send
        $param["message"] = "$msg";
        //these are the recipients of the message
        $param["senderid"] = "$SenderID";
        //this is our sender
        $param["accusage"] = "1";
        //this is our sender
        //traverse through each member of the param array

        foreach ($param as $key => $val)
            {
            //we have to urlencode the values
            $request.= $key . "=" . urlencode($val);
            //append the ampersand (&) sign after each paramter/value pair
            $request.= "&";
            }

        //remove the final ampersand sign from the request
        $request = substr($request, 0, strlen($request) - 1);
        $handle = curl_init($request);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, TRUE);
        /* Get the HTML or whatever is linked in $url. */
        $response = curl_exec($handle);


        $data = explode('sent', $response);
        foreach ($data as $key => $val)
            {
            $number = explode(",", $val);
            if (@$number[1] == "success")
                {
                if ("+918894054847" != trim($number[4])) $sucess[] = $number[4];
                }
            }
        $data = explode('fail', $response);
        foreach ($data as $key => $val)
            {
            $number = explode(",", $val);
            if (@$number[1] == "Invalid Mobile")
                {
                if ("+918894054847" != trim($number[4])) $sucess[] = $number[4];
                }
            }
        $data = explode('fail', $response);
        foreach ($data as $key => $val)
            {
            $number = explode(",", $val);
            if (@$number[1] == "Duplicate Mobile")
                {
                if ("+918894054847" != trim($number[4])) $sucess[] = $number[4];
                }
            }
        $text = $_POST['message'];
        $send_state = 0;
        }
    }


if (@$type)
    {
    $oPageLayout->sPagePath = PAGES_FOLDER . '/sms/sendsms.inc.php'; // special home page
    }
else
    {
    $oPageLayout->sPagePath = PAGES_FOLDER . '/sms/sms.inc.php'; // special home page
    }# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>