<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Homework| ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Homework'; 
$sTransport = new Homework();
$type = http_get('param1');

if($type=='add'){
  $oPageLayout->sWindowTitle = 'Add New HomeWork | ' . CLIENT_NAME;
  
  if(isset($_POST['homeworkSubmit'])){
//      print_r($_FILES);
//      exit();
   $sTransport->add_homework('',$_POST,$_FILES);
  } 
  
  $oPageLayout->sPagePath = PAGES_FOLDER . '/homework/homework-register.inc.php';
 
}
else if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit Homework | ' . CLIENT_NAME;
  $id = http_get('param2');
  $homework = Homework::get_homeworks($MSID,$id)->fetch();
  
    if(isset($_POST['homeworkupdate'])){
     $sTransport->add_homework($id,$_POST,$_FILES);
  } 
  //get current designation
//  $tptstations = Transport::get_tptstations($MSID,$station_id)->fetch(PDO::FETCH_ASSOC);

$oPageLayout->sPagePath = PAGES_FOLDER . '/homework/homework-edit.inc.php'; // special home page
}
else{
if($type=='delete'){
$id = http_get('param2');
/**
* Delete record action function 
**/
if(!empty($id)){
 $dataarr = array(
		   'id'        => $id,
		   'tablename' => 'homework',
		   'redirect'  => CLIENT_URL.'/homework',
		   'where'     => 'id'
		  );
$deleterecored = General::delete($dataarr);
} 
}
if($type=='page'){
 $page = http_get('param2');
}else{
 $page = 1;
}
if(isset($_SESSION['r_per_page'])){
$records_per_page=$_SESSION['r_per_page'];
}else{
$records_per_page=RECORDS_PER_PAGE;
}
if(!@$id){
 $id=1;   
}
//if(!@$subject){
// $subject= "Hindi";
//}

if(@$_POST['homeworkfrm']){

    if(@$_POST['class_id']){
       $id =$_POST['class_id'];
    }
   if(@$_POST['section_id']){
       $section_id =$_POST['section_id'];
   } 
} 
$homeworks = Homework::get_homeworks($MSID, '', $id, $section_id);
$totalrecords = $homeworks->rowCount();
$total_no_recrd = Homework::get_homeworks($MSID,'',$id)->rowCount();

$links      = 3;

$Paginator  = new Paginator( $total_no_recrd, $records_per_page ,$page,'homework');

$pagination = $Paginator->createLinks( $links, 'pagination' );

$oPageLayout->sPagePath = PAGES_FOLDER . '/homework/homework.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>