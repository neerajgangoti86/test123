<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$sFee = new Fee();
//$user = UserManager::get_slusers($MSID . "vm3", $MSID)->fetch();
//
//$delete_school_session = Fee::get_delete_student_from_fee_billing($MSID, '', $user['mysession']);
//$inserting_school_session_data = Fee::insert_student_into_fee_billing($MSID, '', '');
//$type = http_get('param1');
$page_main = http_get('param1');

$oPageLayout->sWindowTitle = 'Fee | ' . CLIENT_NAME;

$fees = Fee::get_monthly_fee($oCurrentUser->myuid);
$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/m_receivable.inc.php';


include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>