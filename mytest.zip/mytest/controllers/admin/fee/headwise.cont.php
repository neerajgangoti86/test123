<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee Headwise | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$type = http_get('param1');



$fee = Fee::get_daily_fee($oCurrentUser->myuid);

if (@$_POST['dayend']) {
    if (@$_SESSION['date_period_from']) {
        $from = $_SESSION['date_period_from'];
    }
    else {
        $from = $oCurrentUser->my_period_from;
    }
    if (@$_SESSION['date_period_to']) {
        $to = $_SESSION['date_period_to'];
    }
    else {
        $to = $oCurrentUser->my_period_to;
    }
    $end_day = Fee::day_end($MSID, $from, $to);
}
if (@$_POST['date_from']) {

    $dates_between = Employee::update_user_dates($MSID, $oCurrentUser->myuid, $_POST);
}




$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/headwise.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>