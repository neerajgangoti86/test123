<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$sFee = new Fee();
$tpt = (@http_get('param2') == "tpt" && $oCurrentSchool->SeprateTPTFBook == "1") ? "2" : (($oCurrentSchool->SeprateTPTFBook == "0") ? "1" : "0");
if (@http_get('param2') == "month")
    {
    $rsrno = http_get('param3');
    }
$tr_id_no = http_get('param4');


$message = new Messages();
echo $message->display();

$id = http_get('param1');

$student = Student::get_students($oCurrentUser->myuid, '1', $id)->fetch(PDO::FETCH_OBJ);
$trxn = Fee::get_txn($MSID, $tr_id_no)->fetch(PDO::FETCH_OBJ);


$loops = Fee::get_fee_billing_loops($oCurrentUser->myuid, $student->acno);
//$type = http_get('param1');
$page_main = http_get('param1');


$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/fee_report_export.inc.php'; // special home page
$oPageLayout->sWindowTitle = 'Fee | ' . CLIENT_NAME;
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>