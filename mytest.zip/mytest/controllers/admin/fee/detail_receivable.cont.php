<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$sFee = new Fee();

$srno = http_get('param1');
$oPageLayout->sWindowTitle = 'Month wise fee Recivable | ' . CLIENT_NAME;

$fees = Fee::get_monthly_fee_detail($oCurrentUser->myuid, $srno);
$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/detail_receivable.inc.php';
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>