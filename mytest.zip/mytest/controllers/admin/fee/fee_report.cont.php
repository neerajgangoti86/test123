<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$sFee = new Fee();

//$type = http_get('param1');
$page_main = http_get('param1');

$oPageLayout->sWindowTitle = 'Fee | ' . CLIENT_NAME;
/* start column hide/show script */
//$students_array = array(
//    "tr_id_no" => " Transection Id",
//    "AcNo" => " Account No",
//    "FatherName" => " Father Name",
//    "Village" => " Village",
//    "Received_by" => " Received By",
//    "FeeAmt" => " Fee Amount",
//    "late_fee" => " Late Fee",
//    "Total" => " Total Amount"
//); 
//if (isset($_POST['columnsubmit'])) {
//    $fields = array(); // for making the field array
//    foreach ($_POST['column1'] as $key => $val) {
//        $fields[$val] = $students_array[$val];
//    }
//    $data = json_encode($fields);  // encoding in json format
//    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "fee_report", $data);
//}
////
//$existing_def = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "fee_report");
//$columns_counts = $existing_def->rowCount();
//if ($columns_counts > 0) {
//    $data_emp = $existing_def->fetch();
//    $fields = json_decode($data_emp['fields'], true);
//    $selected_columns_students = array();
//    foreach ($fields as $k => $val) {
//        $selected_columns_students[] = $k;
//    }
//}
//if (empty($selected_columns_students)) {
//    $selected_columns_students = array("tr_id_no",
//        "StudentName",
//        "FatherName",
//        "Class",
//        "section",
//        "Village",
//        "FeeAmt",
//        "Amt",
//        "LateFee",
//        "Bal",
//        "MobileSMS");
//}
/* end column hide/show script */
//
//if ($page_main == 'page') {
//    $page = http_get('param2');
//} else {
//    $page = 1;
//}
//if (isset($_SESSION['r_per_page'])) {
//    $records_per_page = $_SESSION['r_per_page'];
//} else {
//    $records_per_page = RECORDS_PER_PAGE;
//}
//
//$students = Fee::get_fee_report($MSID,  array('page' => $page, 'record_per_page' => $records_per_page));
//$totalrecords = $students->rowCount();
//$total_no_recrd = Fee::get_fee_report($MSID,'all')->rowCount();
//print_r($students);
$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/fee_report.inc.php';
//print_r($oCurrentUser);
$get_emp = Employee::change_pasword($MSID,$oCurrentUser->myuid);
  
//print_r($get_emp);

$get_emp_result = $get_emp->fetch();

//print_r($get_emp_result);

//print_r($get_emp_result);

//print_r($get_emp_result);

//die("<>>>");
@$date_get = http_get('param1');




if(@$date_get!='')
{
 unset($_SESSION['date_period_from']);
 unset($_SESSION['date_period_to']);
 
 @$date_gets = date('d-m-Y',strtotime(@$date_get));
 
 @$post = array('date_from'=>@$date_gets,'date_to'=>@$date_gets);
 
 $dates_between = Employee::update_user_dates($MSID,$oCurrentUser->myuid,@$post);
?>
<script type="text/javascript">
   window.location.href = "<?= CLIENT_URL?>/fee-report";
</script>
<?php 
}


if(@$_POST['date_from'])
{
  
  $dates_between = Employee::update_user_dates($MSID,$oCurrentUser->myuid,$_POST);
  
  //$url = CLIENT_URL."/fee-report";
  //header('Location:'.$url);
  
    
}




$students=  Houses::get_daily_fee_recive2($oCurrentUser->myuid);

if(@$_POST['rsbtn'])
{
   include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
}
else
{
//$links = 3;
//
//$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'fee-report' );
//
//$pagination = $Paginator->createLinks($links, 'pagination');

 // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
}
?>