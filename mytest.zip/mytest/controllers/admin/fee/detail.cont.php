<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
$student_id= http_get('param1');
$class= http_get('param2');
$due_date= http_get('param3');
$srno= http_get('param4');
$fee_dtl= Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student_id, $srno,'FALSE');

$student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
//print_r($student);
$Village= Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);

$oPageLayout->sWindowTitle = 'Fee Details | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';


$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/fee_detail.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>