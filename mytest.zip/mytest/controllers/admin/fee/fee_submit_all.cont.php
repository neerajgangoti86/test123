<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Quick Receive | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$responce = array();
$dpl_acs = NULL;
$scss_acs = null;
$amt = array();

$year = $oCurrentUser->mysession;
//http://demo.eschoolexpert.com/feevoucher/submit_headwise/15009/15009/2016-07-01/5/590.00
if (@$_POST['quick_fee']) {
    $amt = 0;
    foreach ($_POST['s_id'] as $key => $val) {

        if (!empty($val)) {
            $student = Student::get_students($oCurrentUser->myuid, '1', $val)->fetch(PDO::FETCH_ASSOC);
            if ($MSID != '1001') {
                $lesure = Fee::get_ledgers($MSID, '1')->fetch(PDO::FETCH_OBJ);
            } else {
                $lesure = Fee::get_ledgers($MSID, '23')->fetch(PDO::FETCH_OBJ);
            }

            $TrDate = date('Y-m-d', strtotime($oCurrentUser->mydate));
            $DR = $lesure->id;
            $acno = $student['acno'];
            
            $date = new DateTime();
            $tmp = $date->format('Y-m-dH:i:s');
            $TridNo = $oCurrentUser->user_id . $tmp;
                    
            $dm = $_POST['month'];
            $my_month = date("M", strtotime($dm));
            $txn = Fee::get_fee_tsn($MSID, $oCurrentUser->mysession, $student['acno'], $oCurrentUser->mydate)->fetch(PDO::FETCH_ASSOC);
            $TridNo = $txn['id'];

            $fees = Fee::get_fee_due_amt($oCurrentUser->myuid, $oCurrentUser->mydate, $student['acno'], $oCurrentUser->begins, $oCurrentUser->ends, 'True', 'True');//->fetchall();
            while ($rowv = $fees->fetch(PDO::FETCH_OBJ)) {
                $pay_month = date("M", strtotime($rowv->DueDate));
                if ($my_month == $pay_month) {
                     $amt = round($rowv->fee);
                     $srno = $rowv->SrNo;
                     $due_date = $rowv->DueDate;
                }
                
            }

            $session = Master::getSchoolSession($MSID, $due_date)->fetch(PDO::FETCH_OBJ);
            $TrDate = date('Y-m-d', strtotime($dm));
            $dbank = NULL;
            if ($dbank == '') {
                $dbank == 'Cash';
            }
            if ($MSID != '1001') {
                if ($dbank == 'Cash') {
                    $DR = '1';
                } else {
                    $DR = '1';
                }
            } else {
                $DR = '23';
            }
            $date = new DateTime();
            $tmp = $date->format('Y-m-dH:i:s');
            $TridNo = $oCurrentUser->user_id . $tmp;
            $ID_DUEDATE_UNIQ = $MSID . '-' . $acno . '-' . $due_date;
            $queryA = "select * FROM `ms_fee_transactions` WHERE   `fee_receipt_id` = '$ID_DUEDATE_UNIQ' And status!='0' And MSID='$MSID'";
            $oDb = DBConnection::get();
            $data = $oDb->query($queryA);
//

            if ($data->rowCount() > 0) {
                $dpl_acs .= " {" . $val . " }";
            } else {
                $student = Student::get_students($oCurrentUser->myuid, '', $val)->fetch(PDO::FETCH_OBJ);
                if ($student->feepaymentmode == '1') {
                    $srno = '';
                }
                $fee_dtl = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->acno, $srno, 'FALSE', 'True')->fetchAll();

                $last_id = General::gererate_db_nextid($MSID, 'fee_transactions', 'party_refference');
                $counts = $last_id->rowCount();
                $party_refrence = 0;
                if ($counts > 0) {

                    $last = $last_id->fetch(PDO::FETCH_OBJ);
                    $party_refrence = $last->party_refference;
//            print_r($party_refrence);
                }
                $party_refrence += 1;
                $msgs = Fee::save_trancection_headwise($MSID, $oCurrentUser->mysession, $TrDate, $DR, $acno, $oCurrentUser->myuid, $party_refrence, $ID_DUEDATE_UNIQ, $TridNo, $amt, $fee_dtl, '', '', $srno, '', '', 'Quick');
                $scss_acs .=" {" . $val . " }";
            }
        }
    }
//    pr($scss_acs); 
}


$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/fee_submit_all.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>