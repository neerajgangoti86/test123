<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee Voucher | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$type = http_get('param1');
if (isset($_POST['skeyword'])) {
    $_SESSION['s_id'] = $_POST['skeyword'];
}
    
if ($type == "student") {
    $_SESSION['s_id'] =   http_get('param2');
   
}
if ($type == "submit") {
    $student_id = http_get('param2');
    $acno = http_get('param3');
    $due_date = http_get('param4');
    $srno = http_get('param5');
    $amt = http_get('param6');
//    exit();
    $FeebkafterReceive = $oCurrentSchool->FeebkafterReceive;
    $FBKDesigns = $oCurrentSchool->FBKDesigns;
    $dbank = $oCurrentSchool->bank_cash;
    $dm = $oCurrentUser->mydate;
//    print_r($oCurrentUser);

    $session = Master::getSchoolSession($MSID, $due_date)->fetch(PDO::FETCH_OBJ);
//    print_r($session);
//    exit();

    $TrDate = date('Y-m-d', strtotime($dm));
    if ($dbank == '') {
        $dbank == 'Cash';
    }
    if ($MSID != '1001') {
        $result = mysql_query($sql = "SELECT * FROM `39Ledgers` WHERE `LName` = '$dbank' And MSid='$MSID' OR `LName` Like '%bank'  And MSid='$MSID'");
        while ($row = mysql_fetch_array($result)) {
            $DR = $row['LId'];
            $row['LName'];
        }

        $resudt = mysql_query($sdl = "SELECT * from `CurrentDR` where MSID='$MSID' ");
        $nr = mysql_num_rows($resudt);
        if ($nr > '0') {
            while ($rod = mysql_fetch_array($resudt)) {
                echo $DR = $rod['ID'];
                $rod['DR'];
            }
        }
    } else {
        $DR = '23';
    }
    $date = new DateTime();
    $tmp = $date->format('Y-m-dH:i:s');
    $TridNo = $oCurrentUser->user_id . $tmp;
    $ID_DUEDATE_UNIQ = $MSID . '-' . $acno . '-' . $due_date;
//    print_r($ID_DUEDATE_UNIQ); 
//    exit();
    $queryA = "select * FROM `ms_fee_transactions` WHERE   `fee_receipt_id` = '$ID_DUEDATE_UNIQ' And status!='0' And MSID='$MSID'";
    $oDb = DBConnection::get();
    $data = $oDb->query($queryA);

    if ($data->rowCount() > 0) {
        $message = new Messages();
        $message->add('e', 'Duplicate Entry!', CLIENT_URL . '/feevoucher');
    } else {

        $fee_dtl = Fee::get_Std_fee($MSID, $student_id, $srno, 'FALSE')->fetchAll();
//echo "<pre>";
//print_r($fee_dtl);
//
//foreach ()exit();


        $save = Fee::save_trancection($MSID, $session->session_id, $TrDate, $DR, $acno, $oCurrentUser->myuid, '0', $ID_DUEDATE_UNIQ, $TridNo, $amt, $fee_dtl, '', '', $srno, '', '', 'True');
//        print_r($save);
//        exit();
//        if ($FeebkafterReceive == '1')
//            {
//            $resh = mysql_query($sqh = "Select * from fbk_designs where Design='$FBKDesigns'");
//            while ($rwh = mysql_fetch_array($resh))
//                {
//                $BBRURL = $rwh['BBRURL'];
//                header("Location:$BBRURL?s_id=$s_id&SrNo=$SrNo&TrDate=$TrDate&EOD=$EOD");
//                }
//            }
//        else
//            {
//            header("Location:feevoucher2.php?id=$s_id");
//            }
    }
}
if ($type == "submit_headwise") {
    $student_id = http_get('param2');
    $acno = http_get('param3');
    $due_date = http_get('param4');
    $srno = http_get('param5');
    $amt = http_get('param6');
//    exit();

    $FeebkafterReceive = $oCurrentSchool->FeebkafterReceive;
    $FBKDesigns = $oCurrentSchool->FBKDesigns;
    $dbank = $oCurrentSchool->bank_cash;
    $dm = $oCurrentUser->mydate;
//    print_r($oCurrentUser);

    $session = Master::getSchoolSession($MSID, $due_date)->fetch(PDO::FETCH_OBJ);
//    print_r($session);
//    exit();

    $TrDate = date('Y-m-d', strtotime($dm));
    if ($dbank == '') {
        $dbank == 'Cash';
    }
    if ($MSID != '1001') {
        $result = mysql_query($sql = "SELECT * FROM `39Ledgers` WHERE `LName` = '$dbank' And MSid='$MSID' OR `LName` Like '%bank'  And MSid='$MSID'");
        while ($row = mysql_fetch_array($result)) {
            $DR = $row['LId'];
            $row['LName'];
        }

        $resudt = mysql_query($sdl = "SELECT * from `CurrentDR` where MSID='$MSID' ");
        $nr = mysql_num_rows($resudt);
        if ($nr > '0') {
            while ($rod = mysql_fetch_array($resudt)) {
                echo $DR = $rod['ID'];
                $rod['DR'];
            }
        }
    } else {
        $DR = '23';
    }
    $date = new DateTime();
    $tmp = $date->format('Y-m-dH:i:s');
    $TridNo = $oCurrentUser->user_id . $tmp;
    $ID_DUEDATE_UNIQ = $MSID . '-' . $acno . '-' . $due_date;
//    print_r($ID_DUEDATE_UNIQ);
//    exit();
    $queryA = "select * FROM `ms_fee_transactions` WHERE   `fee_receipt_id` = '$ID_DUEDATE_UNIQ' And status!='0' And MSID='$MSID'";
    $oDb = DBConnection::get();
    $data = $oDb->query($queryA);

    if ($data->rowCount() > 0) {
        $message = new Messages();
        $message->add('e', 'Duplicate Entry!', CLIENT_URL . '/feevoucher');
    } else {
        $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);

        $fee_dtl = Fee::get_Std_fee($MSID, $student->acno, $srno, 'FALSE', 'True')->fetchAll();

        $save = Fee::save_trancection_headwise($MSID, $session->session_id, $TrDate, $DR, $acno, $oCurrentUser->myuid, '0', $ID_DUEDATE_UNIQ, $TridNo, $amt, $fee_dtl, '', '', $srno, '', '', 'True');
//        print_r($save);
//        exit();
//        if ($FeebkafterReceive == '1')
//            {
//            $resh = mysql_query($sqh = "Select * from fbk_designs where Design='$FBKDesigns'");
//            while ($rwh = mysql_fetch_array($resh))
//                {
//                $BBRURL = $rwh['BBRURL'];
//                header("Location:$BBRURL?s_id=$s_id&SrNo=$SrNo&TrDate=$TrDate&EOD=$EOD");
//                }
//            }
//        else
//            {
//            header("Location:feevoucher2.php?id=$s_id");
//            }
    }
}
$postclass = '';
$firstclasss = Master::get_classes($MSID)->fetch(PDO::FETCH_OBJ);
if (isset($_POST['class_id'])) {
    $postclass = $_POST['class_id'];
} else {
    $postclass = $firstclasss->class_no;
}


$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/voucher_without_tpt.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>