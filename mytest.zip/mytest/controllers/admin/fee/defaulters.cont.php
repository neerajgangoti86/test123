<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';
$sGeneral = new General();
$sFee = new Fee();


$page_main = http_get('param2');
//print_r($page_main);

$oPageLayout->sWindowTitle = 'Fee | ' . CLIENT_NAME;
/* start column hide/show script */
$students_array = array(
    "SID" => " Id",
    "StudentName" => " Name",
    "FatherName" => " Father Name",
    "Class" => " Class",
    "section" => " Section",
    "Village" => " Village",
    "Amt" => " Amount",
    "RdAmt" => " Amount Recived",
    "LateFee" => " Late Fee",
    "Bal" => " Balance",
    "MobileSMS" => " Sms Mobile NO"
);
if (isset($_POST['columnsubmit'])) {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val) {
        $fields[$val] = $students_array[$val];
    }
    $data = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "defaulters", $data);
}
//
$existing_def = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "defaulters");
$columns_counts = $existing_def->rowCount();
if ($columns_counts > 0) {
    $data_emp = $existing_def->fetch();
    $fields = json_decode($data_emp['fields'], true);
    $selected_columns_students = array();
    foreach ($fields as $k => $val) {
        $selected_columns_students[] = $k;
    }
}
if (empty($selected_columns_students)) {
    $selected_columns_students = array("SID",
        "StudentName",
        "FatherName",
        "Class",
        "section",
        "Village",
        "Amt",
        "RdAmt",
        "LateFee",
        "Bal",
        "MobileSMS");
}
/* end column hide/show script */

if ($page_main == 'page') {
    $page = http_get('param3');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}
if (@$_POST['type']) {

    $type = $_POST['type'];
}
else{ $type = http_get('param1');}

if (@$_POST['class_id'] || @$_POST['class_id'] != NULL) {
    if (@$_POST['class_id'] != NULL && @$_POST['class_id'] != "all") {
        $class_no = $_POST['class_id'];
        $cls = Master::get_classes($MSID, '', '', '', $_POST['class_id'])->fetch(PDO::FETCH_OBJ);
        $class = $cls->class_name;
    }
}
if (@$class == NULL) {
    $class = "all";
    $class_no = NULL;
}if (@$type == NULL) {
    $type = "defaulters";
} $students = Fee::get_defaulters($oCurrentUser->myuid, $type, $class, '', array('page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $students->rowCount();
$total_no_recrd = Fee::get_defaulters($oCurrentUser->myuid, $type, $class, 'all')->rowCount();


$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'fee-defaulter/' . $type);

$pagination = $Paginator->createLinks($links, 'pagination');


$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/defaulters.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>