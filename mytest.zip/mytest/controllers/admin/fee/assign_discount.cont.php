<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Discount Assign | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees';

//---------------------------GET CLASSES LIST--------------------------------------//
$getClass = Master::get_classes($MSID);
$ClassID = @$_POST['class'];
$sec = @$_POST['section'];
//---------------------------CHECK IF THERE IS SECTIONS AVAILABLE--------------//
if (@$_POST['class'] != NULL) {
    $ClassID = $_POST['class'];
    $getSection = Student::count_section_wise_student($MSID, $oCurrentUser->mysession, $ClassID);
    $total_record = $getSection->rowCount();
}

if (@$_POST['GetDiscountData']) {
if (@$_POST['section'] != NULL) {
         $data = array(
        'class' => @$_POST['class'],
        'field_name'=>'section' ,
        'field_value'=> @$_POST['section']
    );
    
    } else {
       $data = array(
        'class' => @$_POST['class']); } 
    $GetStudent = Student::get_students($oCurrentUser->myuid, 'all', '', '', $data);
}

if (@$_POST['UpdateDiscountData']) {
    //pr($_POST);
    
    $discount = $_POST['discount'];
    $startDate = $_POST['startDate'];
    $endDate = $_POST['endDate'];
    foreach($_POST['student'] as $key => $id)
    {
        $data = array(
            "date_from" => $startDate[$key],
            "date_to" => $endDate[$key],
            "discount_id" => $discount[$key],
        );
        $a = Discount::update_stdnt_discount($MSID, $id, $data);
    }
}


$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/assign_discount.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>