<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee Structure | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees'; 
$sGeneral = new General();
$type = http_get('param1');
$postclass = '';
$firstclasss = Master::get_classes($MSID)->fetch(PDO::FETCH_OBJ);
if(isset($_POST['class_id'])){
 $postclass = $_POST['class_id'];	
}else{
 $postclass = $firstclasss->class_no;	
}

$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/structure.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>