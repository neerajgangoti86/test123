<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fees  Day Report';
$sGeneral = new General();
$sFee = new Fee();

//$type = http_get('param1');
$page_main = http_get('param1');

$oPageLayout->sWindowTitle = 'Fee | ' . CLIENT_NAME;
$oPageLayout->sPagePath = PAGES_FOLDER . '/fee/fee_report_day.inc.php';
$get_emp = Employee::change_pasword($MSID, $oCurrentUser->myuid);

$get_emp_result = $get_emp->fetch();

/*if (@$_POST['date_from']) {

    $dates_between = Employee::update_user_dates($MSID, $oCurrentUser->myuid, $_POST);
}
*/
$dr = http_get("param1");

//$date_format = date('Y-m-d', strtotime($day));

$students = Houses::get_daily_fee_recive_dr($oCurrentUser->myuid,$dr);
//print_r($students);

if (@$_POST['rsbtn']) 
{
    include_once TEMPLATES_FOLDER . '/blank.tmpl.php';
} else 
{
    include_once TEMPLATES_FOLDER . '/default.tmpl.php';
}
?>