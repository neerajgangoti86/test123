<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Employee';
$admission = new Admission();
$sGeneral = new General();
$sEmployee = new Employee();
  $out = "false";

  
$type = http_get("param1");
//print_r($out);
// get all localization
//$locality = Master::get_locality($MSID,'',1);
// get categories
$designations = Master::get_designation();
$departments = Master::get_department();
//print_r($departments);

/* if(isset($_GET['delete'])){
  $dataarr = array(
  'id'        => $_GET["delete"],
  'tablename' => 'parents',
  'redirect'  => 'parents.php',
  'where'     => 'id'
  );
  $deleteusers = $adminclass->delete($dataarr);
  } */


    $oPageLayout->sPagePath = PAGES_FOLDER . '/users/school_docs.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>