<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Hostels | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Hostels';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if ($type == 'del') {
    if (!empty($id)) {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'hostels',
            'redirect' => CLIENT_URL . '/hostels',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
    }
}
/* start hide/show column */
$hostel_array = array(
    "MSID" => " MSID ",
    "name" => " Name"
);

if (isset($_POST['columnsubmit'])) {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val) {
        $fields[$val] = $hostel_array[$val];
    }
    $data = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id,
            DB_PREFIX . "hostels", $data);
}
//
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id,
        DB_PREFIX . "hostels");
$count_data = $existing->rowCount();
if ($count_data > 0) {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_columns_hostel = array();
    foreach ($fields as $k => $val) {
        $selected_columns_hostel[] = $k;
    }
}
if (empty($selected_columns_hostel)) {
    $selected_columns_hostel = array('MSID', 'name', 'max_marks',
        'class');
}
/* end hide/show column */
if ($type == 'page') {
    $page = http_get('param2');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}

$hostels = Hostel::get_hostels($MSID, '',
                array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $hostels->rowCount();
$total_no_recrd = Hostel::get_hostels($MSID)->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page,
        'hostels');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/hostel/hostel.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>