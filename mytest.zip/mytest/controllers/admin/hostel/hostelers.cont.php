<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Hostelets | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Hostel';
$sExam = new Exam();
$sGeneral = new General();
$type = http_get('param1');

$id = http_get('param2');
/**
 * Delete record action function 
 * */
if ($type == 'del')
    {
    if (!empty($id))
        {
        $dataarr = array(
            'id' => $id,
            'tablename' => 'hosteler',
            'redirect' => CLIENT_URL . '/hostelers',
            'where' => 'id'
        );
        $deleterecored = General::delete($dataarr);
        }
    }
/* start hide/show column */
$hostelers_array = array(
    "MSID" => " MSID ",
    "s_id" => " Student Id",
    "s_name" => " Student Name",
    "hostel_id" => " Hostel Id",
    "hostel_name" => " Hostel Name",
    "from" => " From Date",
);

if (isset($_POST['columnsubmit']))
    {
    $fields = array(); // for making the field array
    foreach ($_POST['column1'] as $key => $val)
        {
        $fields[$val] = $hostelers_array[$val];
        }
    $data = json_encode($fields);  // encoding in json format
    $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "hostelers", $data);
    }
//
$existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "hostelers");
$count_data = $existing->rowCount();
if ($count_data > 0)
    {
    $get_columns = $existing->fetch();
    $fields = json_decode($get_columns['fields'], true);
    $selected_columns_hostelers = array();
    foreach ($fields as $k => $val)
        {
        $selected_columns_hostelers[] = $k;
        }
    }
if (empty($selected_columns_hostelers))
    {
    $selected_columns_hostelers = array('MSID', 's_id',
        'hostel_id', 'hostel_id');
    }
/* end hide/show column */
if ($type == 'page')
    {
    $page = http_get('param2');
    }
else
    {
    $page = 1;
    }
if (isset($_SESSION['r_per_page']))
    {
    $records_per_page = $_SESSION['r_per_page'];
    }
else
    {
    $records_per_page = RECORDS_PER_PAGE;
    }

$hostelers = Hostel::get_hostelers($MSID, '', '', '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $hostelers->rowCount();
$total_no_recrd = Hostel::get_hostelers($MSID)->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'hostelers');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/hostel/hostelers.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>