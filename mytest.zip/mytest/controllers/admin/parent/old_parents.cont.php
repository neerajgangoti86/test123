<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Parents | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Parents';
$admission = new Admission();
$sParents = new Parents();
$type = http_get('param1');

// get all localization
$locality = Master::get_locality($MSID, '', 1);
// get categories
$category = Master::get_category($MSID, '', 1);

/* if(isset($_GET['delete'])){
  $dataarr = array(
  'id'        => $_GET["delete"],
  'tablename' => 'parents',
  'redirect'  => CLIENT_URL.'/parents.php',
  'where'     => 'id'
  );
  $deleteusers = Master::delete($dataarr);
  } */
 if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Parents | ' . CLIENT_NAME;
    $payrent_id = http_get('param2');

    if (isset($_POST['updatesubmit'])) {
        $sParents->create_parent($payrent_id, $_POST);
    }
    //get current parent
    $parent = Parents::get_parents($MSID, $payrent_id)->fetch(PDO::FETCH_ASSOC);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/parents/edit-parent.inc.php'; // special home page
} else {
    /* start column hide/show script */
    $parents_array = array(
        "father_name" => " Father Name",
        "f_occupation" => " Father Occupation",
        "f_qualification" => " Father Qualification",
        "phone_1" => " Father Number",
        "mother_name" => " Mother Name",
        "m_occupation" => " Mother Occupation",
        "m_qualification" => " Mother Qualification",
        "phone_2" => " Mother Number",
        "phone_home" => " Phone Home",
        "mobile_sms" => " Sms Mobile",
        "locality" => " Locality",
        "no_of_childrens" => "Number Of Children",
        "address" => "Address",
        "s_id" => "Student Id",
        "s_name" => "Student Name",
        "s_class" => "Student class",
        "annual_income" => "Annual Income",
        "religion" => " Religion",
        "status" => "Status"
    );
    $sGeneral = new General();
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $parents_array[$val];
        }
        $data = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "parents", $data);
    }
    $existing_parents = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "parents");
    $columns_counts = $existing_parents->rowCount();
    if ($columns_counts > 0) {
        $data_employe = $existing_parents->fetch();
        $fields = json_decode($data_employe['fields'], true);
        $selected_columns_parents = array();
        foreach ($fields as $k => $val) {
            $selected_columns_parents[] = $k;
        }
    }
    if (empty($selected_columns_parents)) {
        $selected_columns_parents = array("father_name", "mother_name", "phone_1", "mobile_sms", "locality", "no_of_childrens");
    }
    /* end column hide/show script */
    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
if(@$_POST['search']){
    $keyword=$_POST['search'];
    
}else{
    $keyword='';
}
   

$parents = Parents::get_parents_detl($MSID, $oCurrentUser->mydate, $oCurrentUser->mysession, 'all', $keyword,'', array('page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $parents->rowCount();
    $total_no_recrd = Parents::get_parents_detl($MSID, $oCurrentUser->mydate, $oCurrentUser->mysession, 'all',$keyword, 'all')->rowCount();



//$parents = Parents::get_parents_detl($MSID, $oCurrentUser->mydate, $oCurrentUser->mysession,'all' ,$keyword,'',array('page' => $page, 'record_per_page' => $records_per_page));
    
   //print_r($parents);
   
 
    //   $totalrecords = $parents->rowCount();
    //$total_no_recrd = Parents::get_parents_detl($MSID,$oCurrentUser->mydate,$oCurrentUser->mysession, 'all',$keyword,'all')->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'parents');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/parents/parent_old.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>