<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Employee';
$admission = new Admission();
$sGeneral = new General();
$sEmployee = new Employee();
  $out = "false";

  
$type = http_get("param1");
//print_r($out);
// get all localization
//$locality = Master::get_locality($MSID,'',1);
// get categories
$designations = Master::get_designation();
$departments = Master::get_department();
//print_r($departments);

/* if(isset($_GET['delete'])){
  $dataarr = array(
  'id'        => $_GET["delete"],
  'tablename' => 'parents',
  'redirect'  => 'parents.php',
  'where'     => 'id'
  );
  $deleteusers = $adminclass->delete($dataarr);
  } */
if (@$type == 'add') {
    $oPageLayout->sWindowTitle = 'Add New Employee | ' . CLIENT_NAME;
//create school MSID  id
    $get_emp_id = $sGeneral->gererate_db_nextid($MSID, 'employee', 'employee_id');
    $emprecords = $get_emp_id->rowCount();
    if ($emprecords > 0) {
        $rowv = $get_emp_id->fetch();
        $emp_id = $rowv['employee_id'] + 1;
    } else {
        $emp_id = '1';
    }


    if (isset($_POST['rsubmit'])) {
        $sEmployee->create_employee('', $_POST, $_FILES);
    }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/employee/employee-register.inc.php';
} else if (@$type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Employees | ' . CLIENT_NAME;
    $id = http_get('param2');
    //update employee
    if (isset($_POST['rsubmit'])) {
        $sEmployee->create_employee($id, $_POST, $_FILES);
    }

    $employee = Employee::get_employee($MSID, $id, 'all', '', $oCurrentUser->mydate,$out)->fetch(PDO::FETCH_ASSOC);
    $oPageLayout->sPagePath = PAGES_FOLDER . '/employee/employee-edit.inc.php';
} else {
    $oPageLayout->sWindowTitle = 'Employees | ' . CLIENT_NAME;
    /* start column hide/show script */
    $employee_array = array(
        "emp_id" => " Emp Id",
        "name" => " Employee Name",
        "father_name" => " Father Name",
        "spouse_name" => " Spouse Name",
        "designation" => " Designation",
        "bank_ac_no" => " Bank AC No",
        "qualification" => " Qualification",
        "mobile" => " Mobile",
        "dob" => " DOB",
        "locality" => " Locality",
        "gender" => " Gender",
        "epf_no" => " EPF Number",
        "epf_join_date" => " EPF Joining Date",
        "retire_date" => " Retire Date",
        "blood_group" => " Blood Group",
        "hire_date" => " Hire Date",
        "emp_category" => " Category",
        "department" => " Department",
        "aadhar_no" => " Adhar Number",
        "address" => " Address",
        "status" => " Status",
    );
    if (isset($_POST['columnsubmit'])) {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val) {
            $fields[$val] = $employee_array[$val];
        }
        $data = json_encode($fields);  // encoding in json format
//        pr($fields);
//         pr($data);
//        exit();
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "employee", $data);
    }
    //
    $existing_emp = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "employee");
    $columns_counts = $existing_emp->rowCount();
    if ($columns_counts > 0) {
        $data_emp = $existing_emp->fetch();
        $fields = json_decode($data_emp['fields'], true);
        $selected_columns_employees = array();
        foreach ($fields as $k => $val) {
            $selected_columns_employees[] = $k;
        }
    }
    if (empty($selected_columns_employees)) {
        $selected_columns_employees = array("emp_id", "name", "father_name", "spouse_name", "designation", "bank_ac_no", "qualification", "mobile", "dob", "locality");
    }
    /* end column hide/show script */

    if (@$type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }

    $employee = Employee::get_employee($MSID, '', '', array('page' => $page, 'record_per_page' => $records_per_page), $oCurrentUser->mydate, $out);
    $totalrecords = $employee->rowCount();
    $total_no_recrd = Employee::get_employee($MSID, '', 'all', '', $oCurrentUser->mydate,$out)->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'employee');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/employee/employee.inc.php'; // special home page
}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>