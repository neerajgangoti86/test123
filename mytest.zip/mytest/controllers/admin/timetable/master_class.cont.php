<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

//print_r($_POST);
if (isset($_POST['timetable_data_form'])) {
    if ($_POST['class_id']!=NULL) {
        $selected_class = $_POST['class_id'];
    }
    if ($_POST['section_id']!=NULL) {
        $selected_section = $_POST['section_id'];
    }
}

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Time Table | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Time Table'; 
$sTimetable = new TimeTable();
$oPageLayout->sPagePath = PAGES_FOLDER . '/timetable/master_class.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>