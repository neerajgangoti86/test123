<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Timetable | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Time Table'; 
if (isset($_POST['timetable_employee'])) {
//    print_r($_POST);
    if ($_POST['employee_id']!=NULL) {
        $selected_employee = $_POST['employee_id'];
    }
    
}

$employees = Employee::get_employee($MSID,'','all',array('emp_category' =>'TS'),$oCurrentUser->mydate)->fetchAll(PDO::FETCH_ASSOC);
//print_r($employees);
$oPageLayout->sPagePath = PAGES_FOLDER . '/timetable/teacherswise.inc.php'; // special home page
//}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>