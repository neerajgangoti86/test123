<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();


$currentPage = 'Time Table'; 
$oPageLayout->sWindowTitle = 'Time Table | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
if (isset($_POST['timetable_data_form'])) {
//    pr($_POST);
    if ($_POST['class_id']!=NULL) {
        $selected_class = $_POST['class_id'];
    }
    if (@$_POST['section_id']) {
        $selected_section = $_POST['section_id'];
    }
}
//get_classes($msid = NULL, $id = NULL, $status = NULL, $limit = NULL, $class_no = NULL)
$classs = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
$tptstations = Transport::get_tptstations($MSID);
$oPageLayout->sPagePath = PAGES_FOLDER . '/timetable/classwise.inc.php'; // special home page
//}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>