<?php
# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
//   pr($_POST);
//if (isset($_POST['term_attend']))
//    {
//
//    /* echo "<pre>";
//      print_r($_POST);
//      //echo "</pre>";
//
//      //die("<>><<");
//     */
//    }



$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Attendance| ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Attendance';
$sattendance = new Attendance();
$type = http_get("param1");
$type2 = http_get("param2");

if ($type == 'today')
    {
    $classes_list = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
    $student_details = Student::get_stu_details($MSID, $oCurrentUser->myuid, $oCurrentUser->mydate);
    $ses_str_dt = $_SESSION['year'] . '-' . date('m-d', strtotime($oCurrentSchool->session_start_date));
    if ($_SESSION['year'] == date('Y'))
        {
        $attencdate = date('Y-m-d');
        }
    else
        {
        $attencdate = $ses_str_dt;
        }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/attendance_today.inc.php';
    }
else if ($type == 'holidays')
    {
    $attendance = Attendance::get_holidays($MSID);
    $totalrecords = $attendance->rowCount();
    $oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/holidays.inc.php';
    }
else if ($type == 'delete')
    {

    $id = http_get("param2");
    try
        {

        $oDb = DBConnection::get();
        $upsql = $oDb->prepare("Delete FROM `ms_holidays` where `holiday_id`='$id' AND `MSID`='$MSID'");
        $upsql->execute();
        }
    catch (PDOException $e)
        {
        $message = new Messages();
        $message->add('e', $e->getMessage());
        }

    $url = CLIENT_URL . '/attendances/holidays';
    header('Location:' . $url);
    }
else
    {


    $ses_str_dt = $_SESSION['year'] . '-' . date('m-d', strtotime($oCurrentSchool->session_start_date));
    $ses_end_dt = ($_SESSION['year'] + 1) . '-' . date('m-d', strtotime($oCurrentSchool->session_end_date));
    if (isset($_POST['attendanceFrm']))
        {


        if ($_POST['class_id'] != NULL)
            {
            $selected_class = $_POST['class_id'];
            $selected_section = $_POST['section_id'];
            if (http_get("param5") != NULL)
                {
                $url = CLIENT_URL . "/attendances/" . $selected_class . "/" . http_get("param2") . "/" . http_get("param3") . "/" . $selected_section . "/" . http_get("param5");
                }
            else
                {
                $url = CLIENT_URL . "/attendances/" . $selected_class . "/" . http_get("param2") . "/" . http_get("param3") . "/" . $selected_section;
                }
            ?>      
            <script type="text/javascript">
                window.location.href = "<?= $url ?>";
            </script>
            <?php
            }
        }

    $day_format = http_get("param2");
    $year = http_get("param4");
    $today_date_day = date('d');
    $day = "";

    $day_end = 0;
    $monday_check = 0;

    if (!@$year)
        {
        $year = $_SESSION['year'];
        }
    if (!@$month)
        {
        $month = date('m');
        }
    $type = http_get("param3");
    $selected_class = http_get("param1");
    $selected_section = http_get("param4");
    if (!@$date)
        {
        if ($year == date('Y'))
            {
            $date = date('Y-m-d');
            }
        else
            {
            $date = $ses_str_dt;
            }
        }
    $month = date('m', strtotime($date));
    $year = date('y', strtotime($date));


    if ($day_format == "d")
        {
        $end_date = date('d', strtotime($date));
        $start_date = date('d', strtotime($date));
        }
    else if ($day_format == "m")
        {
        $day = "";
        $end_date = 31;
        $start_date = 1;
        }
    else
        {
        $start_date = date('d', strtotime($date));
        $end_date = $start_date + 7;
        }
    $dateObj = DateTime::createFromFormat('!m', $month);
    $monthName = $dateObj->format('F');
    $data = array(
        'class' => @$selected_class,
        'section' => @$selected_section
    );
    $students = Student::get_students3($oCurrentUser->myuid, 'all', '', '', $data);
    $totalrecords = $students->rowCount();
    $listdays = array();
    $days = array();
    for ($d = $start_date; $d <= $end_date; $d++)
        {
        $time = mktime(12, 0, 0, $month, $d, $year);
        if (date('m', $time) == $month)
            {
            $listdays[] = date('d', $time);
            $days[] = date('D', $time);
            }
        }
    if (@$type)
        {
        if ($type == 'present') $att = '';
        else if ($type == 'absent') $att = 'A';
        else if ($type == 'leave') $att = 'L';
        else if ($type == 'holiday') $att = 'H';
        else
            {
            $att = 'All';
            }
        }
    if ($selected_section)
        {

        $section_details = Master::get_schools_section($MSID, @$selected_section)->fetch();
        $section_name = $section_details['sec_name'];
        }

    if ($selected_class != NULL && $selected_class != "all")
        {
        $classss = Master::get_class_names3($MSID, $selected_class)->fetch();
        $class_name = $classss['class_name'];

        $student_attendance = Student::count_students_attendacnce($oCurrentUser->myuid, @$class_name, @$section_name, $att);
        $students = $student_attendance->fetchALL();
        $total_students_array = array();
        foreach ($students as $stu)
            {
            $total_students_array[] = $stu['SId'];
            }
        @$student_id = implode(',', $total_students_array);
        } if (@$att == '' || $att == 'All')
        {
        $count_result = Student::get_stu_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, $selected_class, @$selected_section, @$student_id);
        }
    else
        {
        if (http_get("param1") == "all")
            {
            $class_name = Null;
            $section_name = Null;
            }
        $count_result = Student::count_students_attendacnce($oCurrentUser->myuid, @$class_name, @$section_name, $att);
        }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/attendance.inc.php';
    }

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>