<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */
//print_r($_POST);
# make pageLayout Object
/*if (isset($_POST['exam_add_academic_performance_form'])) {

    if ($_POST['class_id'] != Null) {
        $selected_class = $_POST['class_id'];
    }
    if (!empty($_POST['section_id'])) 
    {
        $selected_section = $_POST['section_id'];
    }
    if (!empty($_POST['term'])) {
        $selected_term = $_POST['term'];
    }
    
}*/







$oPageLayout = new PageLayout();
if (@$_POST['add_term_Attendance'] == 'true') {
    $class_id = $_POST['class_id'];
    @$section = $_POST['section'];
    @$term = $_POST['term'];
    @$tw_days = $_POST['tw_days'];
    
    
    
}
if (@$_POST['add_term_atnd']) {

    Attendance::add_exam_attendance('', $_POST);
}

if (@$_POST['form_term']) {
    
    //print_r($_POST);
    
   @$term_selected = $_POST['term']; 
    @$section_selected = $_POST['section_id'];
    @$class_selected = $_POST['class_id'];
    
    
    
    
    
    
}

if(@$class_selected==NULL)
$class_selected="";
if(@$term_selected==NULL)
$term_selected="";
if(@$section_selected==NULL)
@$section_selected="";
$existing_attendance = Attendance::get_exam_attendance($MSID, '', $term_selected, '', '', $oCurrentUser->mysession, $class_selected, @$section_selected, 'True');

print_r($existing_attendance);
die("<..,");
$totalrecord_existing = $existing_attendance->rowCount();
$oPageLayout->sWindowTitle = 'Attendance | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Attendance';
$sattendance = new Attendance();
$sGeneral = new General();
$type = http_get('param1');


$oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/term.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>