<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object 

if(isset($_POST['term_attend']))
{
    
   /* echo "<pre>";
    print_r($_POST);
    //echo "</pre>";
    
    //die("<>><<");
    */
    
}




$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Attendance| ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Attendance'; 
$sattendance = new Attendance();
$type = http_get("param1");
$type2 = http_get("param2");

if($type=='today'){
$classes_list = Master::get_classes($MSID)->fetchAll(PDO::FETCH_ASSOC);
//print_r($classes_list);




$student_details = Student::get_stu_details($MSID,$oCurrentUser->myuid,$oCurrentUser->mydate);
//print_r($student_details);
$ses_str_dt = $_SESSION['year'].'-'.date('m-d',strtotime($oCurrentSchool->session_start_date));
if($_SESSION['year']==date('Y')){
 $attencdate = date('Y-m-d');
}else{
 $attencdate = $ses_str_dt;
}

$oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/attendance_today.inc.php';
}

else if($type == 'holidays')
{
   $attendance = Attendance::get_holidays($MSID);
   $totalrecords = $attendance->rowCount();
   
  // print_r($attendance);
   
   $oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/holidays.inc.php';
    
    
    
}

 else if($type == 'delete')
 {
     
   $id =  http_get("param2"); 
   try 
   {

        $oDb = DBConnection::get();
        $upsql = $oDb->prepare("Delete FROM `ms_holidays` where `holiday_id`='$id' AND `MSID`='$MSID'");
//            print_r($upsql);
        $upsql->execute();

//            $sql = $oDb->query($sql);
        
    } 
    catch (PDOException $e) 
    {
        //$message = new Messages();
       // $message->add('e', $e->getMessage());
    }
    
    $url = CLIENT_URL.'/attendances/holidays';
    header('Location:'.$url);
    
    
   //$oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/holidays.inc.php';  
 }

else{
    $workingdays = Attendance::get_months_working_days($oCurrentUser->myuid);
    
    // print_r($workingdays);
        while ($rowf = $workingdays->fetch())
                                    {  $workingd= $rowf['NOWDays']; } 
     $preworkingdays = Attendance::get_total_working_days($oCurrentUser->myuid);
    
    // print_r($workingdays);
        while ($rowh = $preworkingdays->fetch())
                                    {  $preworkingd= $rowh['NOWDays']; }
                                      
                                    
$oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/month_attendance.inc.php';
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>