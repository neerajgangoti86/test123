<?php
# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Attendance| ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$emp_details = Employee::get_employee_by_cat($MSID, $oCurrentUser->mydate);
//    print_r($emp_details);

$currentPage = 'Attendance';
$sattendance = new Attendance();
if (http_get("param1") == "monthly")
    {
    ?><style type="text/css">
        .heading_title { font-size:16px;}


    </style>
    <?php
    $year = date('Y', strtotime($oCurrentSchool->session_start_date));
    $ses_str_dt = $year . '-' . date('m-d', strtotime($oCurrentSchool->session_start_date));
    $ses_end_dt = ($year + 1) . '-' . date('m-d', strtotime($oCurrentSchool->session_end_date));

    if (isset($_POST['role']))
        {

        $url = CLIENT_URL . "/emp_attendances/monthly/" . $_POST['role'];
        ?>      
        <script type="text/javascript">
            window.location.href = "<?= $url ?>";
        </script>
        <?php
        }
    if (@http_get("param2"))
        {
        $selected_section = http_get("param2");
        }
    else
        {
//        echo "sad";
        $selected_section = 'NT';
        }
    ?>
    <?php
    $today_date_day = date('d', strtotime($oCurrentUser->mydate));
    $day = "";

    $day_end = 0;
    $monday_check = 0;

    if (!@$year)
        {
        $year = date('Y', strtotime($oCurrentUser->mydate));
        }
    if (!@$month)
        {
        $month = date('m', strtotime($oCurrentUser->mydate));
        }



    if (!@$date)
        {
        if ($year == date('Y', strtotime($oCurrentUser->mydate)))
            {
            $date = date('Y-m-d', strtotime($oCurrentUser->mydate));
            }
        else
            {
            $date = date('Y-m-d', strtotime($oCurrentUser->mydate));
            }
        }
    $month = date('m', strtotime($date));
    $year = date('y', strtotime($date));

    $day = "";
    $end_date = 31;
    $start_date = 1;



    $dateObj = DateTime::createFromFormat('!m', $month);
    $monthName = $dateObj->format('F');
//    print_r($selected_section);
    $students = Attendance::get_emp_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, $selected_section);
//print_r($students);

    $totalrecords = $students->rowCount();



    $listdays = array();
    $days = array();

    for ($d = $start_date; $d <= $end_date; $d++)
        {
        $time = mktime(12, 0, 0, $month, $d, $year);
        if (date('m', $time) == $month)
            {
            $listdays[] = date('d', $time);
            $days[] = date('D', $time);
            }
        }
//print_r($date);
//exit();
    }
else
    {
    if (isset($_POST['attendanceEmp']))
        {
        if (http_get("param3") != NULL)
            {
            $url = CLIENT_URL . "/emp_attendances/" . $_POST['role'] . "/" . http_get("param2") . "/" . http_get("param3");
            }
        else
            {
            $url = CLIENT_URL . "/emp_attendances/" . $_POST['role'] . "/" . http_get("param2");
            }
        ?>      
        <script type="text/javascript">
            window.location.href = "<?= $url ?>";
        </script>
        <?php
        }
    if (@http_get("param2"))
        {
        $type = http_get("param2");
        if ($type == 'present') $att = '';
        else if ($type == 'absent') $att = 'A';
        else if ($type == 'leave') $att = 'L';
        else
            {
            $att = 'all';
            }
        }
    if (@http_get("param1") && http_get("param1") != "today")
        {
        $role = http_get("param1");
        }
    if (!@$role)
        {
        $role = 'NT';
        }



    $month = date('m', strtotime($oCurrentUser->mydate));

    $dateObj = DateTime::createFromFormat('!m', $month);
    $monthName = $dateObj->format('F');

    $listdays = array();
    $days = array();

    $student_attendance = Attendance::count_emp_attendacnce($oCurrentUser->myuid, $role, @$att);
    $students = $student_attendance->fetchALL();
    $total_students_array = array();
    foreach ($students as $stu)
        {
        $total_students_array[] = $stu['SId'];
        }
    @$student_id = implode(',', $total_students_array);
//    print_r($student_id);
    if (@$att == 'all' || @$att == '')
        {
        if (@$att == 'all')
            {
            $att = NULL;
            $student_id = NULL;
            }
//        echo "step Present ,TTl Employee ";

        $employee = Attendance::get_emp_attendance_details($MSID, $oCurrentUser->mysession, $oCurrentUser->mydate, @$role, @$student_id);
        }
    else
        {
        if (http_get("param1") == "all")
            {
            $role = Null;
            }
//        echo "step Absent ,Leave ";
        $employee = Attendance::count_emp_attendacnce($oCurrentUser->myuid, @$role, @$att);
        }

    $totalrecords = $employee->rowCount();
    }
$oPageLayout->sPagePath = PAGES_FOLDER . '/attendance/emp_attendance.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>