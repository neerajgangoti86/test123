<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee Type | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fee Panel'; 
$type = http_get('param1');

    if ($type == 'del') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'fee_type',
                'redirect' => CLIENT_URL . '/fee-type',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
$totalRow = 0;
$fee_types = Fee::get_fee_type('','all',array('type'=>'feename'));
$totalRow = $fee_types->rowCount();

$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/fee-type-list.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>