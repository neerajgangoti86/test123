<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();
$sMaster = new Master();

$oPageLayout->sWindowTitle = 'Configuration | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Configuration'; 

$school_board = Master::get_school_board();
$schools = Master::get_schools();



//if(isset($_POST['selected_school']))
//{
//    
//   $school_gets = Master::get_school_details($_POST['selected_school']);
//   
//    
//    $school_get = Master::get_school_details($_POST['selected_school'])->fetch();
//    print_r( $school_get); 
//   $classe = Master::get_classes($_POST['selected_school'],'','','');
//   print_r($classe);
//    
//    
//    $classes = Master::get_classes($_POST['selected_school'],'','','')->fetchAll(PDO::FETCH_ASSOC);
//}
//
//else if(@$_SESSION['SESS_ID'])
//{
//   
//    $school_get = Master::get_school_details($_SESSION['SESS_ID'])->fetch();
////    $classes = Master::get_classes($_SESSION['SESS_ID'],'','','')->fetchAll(PDO::FETCH_ASSOC);
////     $classe = Master::get_classes($_POST['selected_school'],'','','');
//  print_r($school_get);  
//}
//
//else
//{
//     $school_get = Master::get_school_details($oCurrentSchool->MSID)->fetch();
//     $classe = Master::get_classes($_POST['selected_school'],'','','');
//   print_r($school_get);
//} 

echo $id = http_get('param2');




if (isset($_POST['selected_school']))
    $school_id = $_POST['selected_school'];
else if (@$_SESSION['SESS_ID'])
    $school_id = $_SESSION['SESS_ID'];

else if(@$_SESSION['SCHOOL_ID'])

  $school_id = $_SESSION['SCHOOL_ID'];

else
    $school_id = $oCurrentSchool->MSID;
$school_get = Master::get_school_details($school_id)->fetch();

$classe = Master::get_classes($school_id, '', '', '');
//print_r($classe);

$classes = Master::get_classes($school_id, '', '', '')->fetchAll(PDO::FETCH_ASSOC);

//submit school form
if(isset($_POST['updateschool'])){
    
 $_SESSION['SESS_ID'] = $_POST['msid'];
 
 
 $schoo_id  = $_POST['school_ids'];
 
 
    
 $sMaster->register_school($schoo_id,$_POST,$_FILES,CLIENT_URL.'/settings'); 
}

if(!$oCurrentSchool){
  showHttpError(404);
}
//$parent = Parents::get_parents($MSID,$payrent_id)->fetch(PDO::FETCH_ASSOC);
$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/setting.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>