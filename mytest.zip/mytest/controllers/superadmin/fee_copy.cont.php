<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';


$currentPage = 'Fee Panel';
$sSuperAdmin = new SuperAdmin();
$sFee = new Fee();
$type = http_get('param1');
$schools = Master::get_schools();
$totalRow = 0;
$school_fees = Fee::get_school_fee($_SESSION['user_school'], '', 'all');
$totalRow = $school_fees->rowCount();
$slSessionDates = Master::get_session($MSID, $oCurrentUser->mysession + 1)->fetch(PDO::FETCH_ASSOC);
//print_r($slSessionDates);
if (isset($_POST['feecopy'])) {
//    echo "<pre>";
//    print_r($_POST);
//    exit();
    $sFee->fee_copy('', $_POST, CLIENT_URL . '/fee-genrator');
}


$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/fee-copy.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>
