<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Houses | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fee Panel';
$sHouse = new Houses();
$type = http_get('param1');
$schoolspopup = Master::get_schools();
if ($type == "add") {
    $schoolspopup = Master::get_schools();
    $oPageLayout->sWindowTitle = "Add New House |" . CLIENT_NAME;
    if (isset($_POST['house_submit'])) 
    {
    
        
      $sHouse->add_house('', $_POST);
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/houses-register.inc.php';
} elseif ($type == "edit") {

   $schoolspopup = Master::get_schools();
    $oPageLayout->sWindowTitle = 'Edit Discount| ' . CLIENT_NAME;
    $id = http_get('param2');
    if (isset($_POST['house_edit_submit'])) {
        $sHouse->add_house($id, $_POST);
    }
    //get current designation
    $houses = Houses::get_houses('', $id)->fetch(PDO::FETCH_ASSOC);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/house-edit.inc.php'; // special home page
} else {

$schools = Master::get_schools();

    if ($type == 'delete') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'houses',
                'redirect' => CLIENT_URL . '/houses',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
  
    $houses = Houses::get_houses($_SESSION['user_school'], '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $houses->rowCount();
    $total_no_recrd = Houses::get_houses($_SESSION['user_school'])->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'discount');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/houses.inc.php'; // special home page
}




# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>