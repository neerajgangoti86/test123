<?php
# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");

if ($content == 'school_sections')
    {
    //$classes = Master::get_classes('','','','default')->fetchAll(PDO::FETCH_ASSOC);
    $sections = Master::get_sections($MSID)->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="table">
        <div class="head" style="width:100%;  display:inline-block;">
            <div style="width:20%; float:left;"><strong>Class</strong></div>
            <div style="width:20%; float:left;"><strong>No of Sections</strong></div>
            <!--<div style="width:35%; float:left;"><strong>Seats</strong></div>-->
            <div style="width:23%; float:left;">&nbsp;</div>
        </div>
        <?php
        $j = 1;
        for ($i = $_POST['classfrom']; $i <= $_POST['classto']; $i++)
            {
            ?>
            <div style="width:100%; display:inline-block;" class="classdiv_<?= $i; ?>">
                <div style="width:20%; float:left;">
                    <?php
                    foreach (classes_list() as $key => $value)
                        {
                        if ($i == $key)
                            {
                            echo $value;
                            }
                        }
                    ?>
                </div>
                <div style="width:20%; float:left;">
                    <select id="sections" class="addmoresec" data-id="<?= $i; ?>" >
                        <?php
                        for ($sec = 1; $sec < 10; $sec ++)
                            {
                            ?>
                            <option value="<?= $sec; ?>">
                                <?= $sec; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <!--                <div style="width:20%; float:left;">
                                                <select id="sections" name="class_section[<?= $i; ?>][<?= $j; ?>][class_sec]">
                                                    <option value="">Select </option>
                <?php
                foreach ($sections as $rowv)
                    {
                    ?>
                                                                                                    <option value="<?= $rowv['sec_id']; ?>">
                    <?= $rowv['sec_name']; ?>
                                                                                                    </option>
                <?php } ?>
                                                </select>
                                            </div>-->
                <!--                <div style="width:35%; float:left;">
                                                <input type="text" name="class_section[<?= $i; ?>][<?= $j; ?>][sec_seat]" />
                                            </div>-->
                <!--<div style="width:23%; float:left;"><a href="javascript:;" class="addmoresec" data-id="<?= $i; ?>">Add more section</a></div>-->
            </div>
            <div style="border-bottom:1px solid #f4f4f4;" id="child_<?= $i; ?>"></div>
            <?php
            $j++;
            }
        ?>
    </div>
    <script>
        $(function () {
            $('.addmoresec').change(function () {
                var totalclas = <?= $j; ?>;
                var tot = $(this).val();
                //alert()
                var classid = $(this).data('id');
                var tdiv = $('#child_' + classid + ' > div').length;
                var ototal = +totalclas + tdiv;
                $('#child_' + classid).empty();
                var sectionsArray = new Array();
    <?php
    foreach (section_list() as $key => $value)
        {
        ?>
                    sectionsArray.push('<?php echo $value; ?>');
    <?php } ?>
                console.log(sectionsArray);
                for (i = 0; i < tot; i++) {
    //                    if (i == 0) {
    //                        $('#child_' + classid).append('<div style="width:100%; display:inline-block;" class="secdiv_' + classid + '"><div style="width:20%; float:left;">&nbsp; </div><div style="width:20%; float:left;"><lable>Section Name</lable></div><div style="width:35%; float:right;"><lable>Saeting Capacity </lable></div></div>');
    //                    }
                    $('#child_' + classid).append('<div style="width:100%; display:inline-block;" class="secdiv_' + classid + '"><div style="width:20%; float:left;">&nbsp; </div><div style="width:20%; float:left;"><input type="text" id="sections"   value="' + sectionsArray[i] + '" name="class_section[' + classid + '][' + i + '][class_sec]"></div><div style="width:35%; float:right;"><input type="text" placeholder ="Seats" name="class_section[' + classid + '][' + i + '][sec_seat]" /></div></div>');
                }
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'school_classes')
    { //used in school subject register page
    $classesfrm = Master::get_classes($_POST['schoolid']);
//$classesto = Master::get_classes($_POST['schoolid']);
    if (!empty($classesfrm))
        {
        ?>
        <!--<div class="form-group">
          <label>Class From</label>
          <select class="form-control" name="classfrom" required>
        <?php /* while($class = $classesfrm->fetch()){
          echo '<option value="'.$class['class_no'].'">'.$class['class_name'].'</option>';
          } */ ?>
          </select>
        </div>
        <div class="form-group">
          <label>Class To</label>
          <select class="form-control" name="classto" required>
        <?php /* while($class = $classesto->fetch()){
          echo '<option value="'.$class['class_no'].'">'.$class['class_name'].'</option>';
          } */ ?>
          </select>
        </div>-->
        <div class="input-group">
            <span class="input-group-addon">
                <input type="checkbox" class="checkbox"  id="selectall">
            </span>
            <label class="form-control" for="exampleInputName2">Classes</label>
        </div>
        <?php
        while ($rowv = $classesfrm->fetch())
            {
            ?>
            <div class="col-md-4">
                <input type="checkbox"  class="checkbox1" value="<?= $rowv['class_no']; ?>" name="for_class[]">
                <?= $rowv['class_name']; ?>
            </div>
        <?php } ?>
        <div class="col-md-12"></div>
        <script>
            $(document).ready(function () {
                $('#selectall').click(function (event) {
                    if (this.checked) {
                        $('.checkbox1').each(function () {
                            this.checked = true;
                        });
                    } else {
                        $('.checkbox1').each(function () {
                            this.checked = false;
                        });
                    }
                });
            });
        </script>
        <?php
        }
    else
        {
        echo 'classes for this school are not found.';
        }
    ?>
    <?php
    }
else if ($content == 'school_subfeeGroup')
    { //used in school subject register page
    $subfeegroup = SuperAdmin::schoolSubjFeeGroup($_POST['schoolid']);
    if ($subfeegroup->rowCount() > 0)
        {
        ?>
        OR Choose from
        <select class="form-control" name="subfgrp" id="subfgrp" required>
            <option value="">-Select-</option>
            <?php
            while ($subfgrp = $subfeegroup->fetch())
                {
                ?>
                <option value="<?= $subfgrp['fee_group_id']; ?>">
                    <?= $subfgrp['fee_group_id']; ?>
                </option>
            <?php } ?>
        </select>
    <?php } ?>
    <?php
    }
else if ($content == 'fee_type')
    { //used in fee type and fee group page
    $fee_type = Fee::get_fee_type($id)->fetch(PDO::FETCH_ASSOC);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_fee_type" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <div class="form-group">
            <label>Name<span class="text-red">*</span></label>
            <input class="form-control" type="text" id="feename" name="name" value="<?= $fee_type['name'] ?>" autocomplete="off">
        </div>
        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var name = $("#feename");
                var errors = '';
                if (name.val() == '') {
                    name.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    name.parent('.form-group').removeClass('has-error');
                }
                if (errors != '') {
                    return false;
                }

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'school_fee_name')
    {//edit school fee group name
    $schoolspopup = Master::get_schools();
    $sl_feename = Fee::get_fee_names('', $id, 'all')->fetch(PDO::FETCH_ASSOC);
    ?>
    <form method="post" action="" role="form" id="ajaxForm">
        <input type="hidden" name="update_fee_names" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $sl_feename['MSID']; ?>" />
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>School: </label>
                    <?php
                    while ($school = $schoolspopup->fetch())
                        {
                        ?>
                        <?= ($sl_feename['MSID'] == $school['MSID']) ? '(' . $school['MSID'] . ') ' . $school['name'] : ''; ?>
                    <?php } ?>
                </div>
                <div class="form-group">
                    <label>Fee ID</label>
                    <input class="form-control" type="text" name="feeid" value="<?= $sl_feename['fee_id']; ?>" required="required">
                </div>
                <div class="form-group">
                    <label>Fee Name</label>
                    <input class="form-control" type="text" name="feename" id="feename" value="<?= $sl_feename['fee_name']; ?>" required="required">
                </div>
                <div class="form-group">
                    <label>Fee Group ID</label>
                    <input type="text" class="form-control" name="fee_group_id" value="<?= $sl_feename['fee_group_id']; ?>" required="required" />
                </div>
                <div class="form-group" id="feegroupname">
                    <label>Fee Group Name</label>
                    <input type="text" class="form-control" name="fee_grp_nm" id="fee_grp_nm" value="<?= $sl_feename['fee_group_name']; ?>" required="required">
                </div>

            </div>
            <!-- \col -->
            <div class="col-md-4">
                <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
            </div>
            <!-- \col -->
        </div>
        <!-- \row end -->
    </form>
    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'school_fee')
    { //school fee page for add/edit 
    $schoolid = $_POST['schoolid'];
// school's fee id 
    $feeid_htm = '';
    $school_fee = Fee::get_fee_names($schoolid, '', 'all');
    $feeid_htm .= '<option value="">-Select-</option>';
    while ($rowv = $school_fee->fetch())
        {
        $feeid_htm .= '<option value="' . $rowv['fee_id'] . '">' . $rowv['fee_name'] . '</option>';
        }
    //school's session start and end date
    $slSessionDates = Master::get_session($schoolid, $_SESSION['year'])->fetch(PDO::FETCH_OBJ);
    //discounts for school
    $discount_htm = '';
    $discount = Discount::get_discount($schoolid, '', array('selectAll' => 'true'));
    $discount_htm .= '<option value="">-Select-</option>';
    while ($rowv = $discount->fetch())
        {
        $discount_htm .= '<option value="' . $rowv['id'] . '">' . $rowv['name'] . '</option>';
        }
    echo json_encode(array("feehtml" => $feeid_htm, 'startdate' => $slSessionDates->begins, 'enddate' => $slSessionDates->ends, 'discountHTML' => $discount_htm));
    }
else if ($content == 'fee')
    { // edit school fee form 
    $school_fees = Fee::get_school_fee('', $id)->fetch(PDO::FETCH_OBJ);

    $schoolspopup = Master::get_schools('', $school_fees->MSID)->fetch(PDO::FETCH_OBJ);
    $classesfrm = Master::get_classes($school_fees->MSID);
//    $sb_stream = SuperAdmin::get_stream();
    ?>
    <form method="post" action="" role="form" id="ajaxForm">
        <input type="hidden" name="update_school_fee" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>MSID :</label>
                    <?= $schoolspopup->name; ?>
                </div>
                <div class="form-group">
                    <label>Date From</label>
                    <input class="form-control datepikerfm" type="text" name="datefrom" id="datefrom" value="<?= $school_fees->date_from; ?>" />
                </div>
                <div class="form-group">
                    <label>Date To</label>
                    <input class="form-control datepikerfm" type="text" name="dateto" id="dateto" value="<?= $school_fees->date_to; ?>" />
                </div>
                <div class="form-group">
                    <label>Fee Id</label>
                    <select class="form-control" name="fee_id" id="fee_id" required>
                        <?php
                        $school_fee = Fee::get_fee_names($school_fees->MSID, '', 'all');
                        echo '<option value="">-Select-</option>';
                        while ($rowv = $school_fee->fetch())
                            {
                            if ($school_fees->fee_id == $rowv['fee_id'])
                                {
                                $selected = 'selected="selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $rowv['fee_id'] . '" ' . $selected . '>' . $rowv['fee_name'] . '</option>';
                            }
                        ?>
                    </select>
                </div> <div class="form-group">
                    <label>Class From<span class="text-red">*</span></label>
                    <select name="class_from" class="class_check form-control" required>
                        <option value="">Class From</option>
                        <?php
                        $classs = Master::get_classes($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        <?php
                        foreach ($classs as $class)
                            {
                            if ($class['class_no'] == $school_fees->class_from)
                                {
                                $selected = 'selected="selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $class['class_no'] . '" ' . $selected . '>' . $class['class_name'] . '</option>';
                            }
                        ?>
                    </select>
                </div><div class="form-group">
                    <label>Class To<span class="text-red">*</span></label>
                    <select name="class_to" class="class_check form-control" required>
                        <option value="">Class To</option>
                        <?php
                        $classs = Master::get_classes($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
//                        print_r($classs);
//                        exit();
                        ?>
                        <?php
                        foreach ($classs as $class)
                            {
                            if ($class['class_no'] == $school_fees->class_to)
                                {
                                $selected = 'selected="selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $class['class_no'] . '" ' . $selected . '>' . $class['class_name'] . '</option>';
                            }
                        ?>
                    </select>
                </div>

            </div>
            <!--/col-6-->
            <div class="col-md-6">
                <div class="form-group">
                    <label> FF </label>
                    <select class="form-control" name="ff" id="ffedit">
                        <option value="">-Select-</option>
                        <option value="1" <?= ($school_fees->ff == 1) ? 'selected="selected"' : ''; ?>>Yes</option>
                        <option value="0" <?= ($school_fees->ff == 0) ? 'selected="selected"' : ''; ?>>No</option>
                    </select>
                </div>
                <div class="form-group has-srn"  <?= ($school_fees->ff == 1) ? 'style="display:none;"' : '' ?>>
                    <label>Sr No From</label>
                    <input class="form-control" value="<?= $school_fees->sr_no_from ?>" type="text" name="srnofrom" />
                </div>
                <div class="form-group has-srn"  <?= ($school_fees->ff == 1) ? 'style="display:none;"' : '' ?>>
                    <label>Sr No To</label>
                    <input class="form-control" value="<?= $school_fees->sr_no_to ?>" type="text" name="srnoto" />
                </div>
                <div class="form-group has-ff"  <?= ($school_fees->ff == 0) ? 'style="display:none;"' : '' ?>>
                    <label>FF From</label>
                    <input class="form-control" value="<?= $school_fees->ff_from ?>" type="text" name="fffrom" />
                </div>
                <div class="form-group has-ff"  <?= ($school_fees->ff == 0) ? 'style="display:none;"' : '' ?>>
                    <label>FF To</label>
                    <input class="form-control" value="<?= $school_fees->ff_to ?>" type="text" name="ffto" />
                </div> 
                <div class="form-group">
                    <label>Fee Group</label>
                    <input type="text" class="form-control" name="fee_group" id="fee_group" value="<?= $school_fees->fee_group_id; ?>">

                </div>
                <div class="form-group"> 
                    <label>Fee Rate</label>
                    <input class="form-control" type="text" name="fee_rate" value="<?= $school_fees->fee_rate; ?>" />
                </div>
            </div>
            <!--/col-6-->
        </div>
        <div class="row">
            <div class="col-md-4">
                <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
            </div>
            <div class="col-md-8 text-center"><span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span></div>
        </div>
    </form>
    <script type="text/javascript">
        $(function () {
            $('#ffedit').on('change', function () {
                var ffval = $(this).val();
                $('.has-ff').hide();
                $('.has-srn').hide();
                if (ffval == 0) {
                    $('.has-srn').show();
                } else {
                    $('.has-ff').show();
                }
            });
            $('.datepikerfm').datepicker({format: 'yyyy-mm-dd', todayHighlight: true, clearBtn: true});
            $('#selectalledit').click(function (event) {
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            //submit form 
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText == 'validation') {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! all fields are required.</div>');
                        } else {
                            if (responseText != 'error') {
                                location.reload();
                                eModal.close();
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                            }
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'discountRuleEdit')
    { //edit discount rules 
    $discountrule = Discount::getDiscountRules('', $id)->fetch(PDO::FETCH_OBJ);
//    print_r($discountrule);
    $schoolspopup = Master::get_schools('', $discountrule->MSID)->fetch(PDO::FETCH_OBJ);
    $school_fees = Fee::get_fee_names($discountrule->MSID, '', 'all');
    $classesfrm = Master::get_classes($discountrule->MSID);
    $slSessionDates = Master::get_session($discountrule->MSID, $_SESSION['year'])->fetch(PDO::FETCH_OBJ);
    $discount = Discount::get_discount($discountrule->MSID, '', array('selectAll' => 'true'));

    if (empty($discountrule->MSID))
        {
        $schlsid = '1001';
        }
    else
        {
        $schlsid = $discountrule->MSID;
        }
    $sessinDate = Master::get_session($schlsid, $_SESSION['year'])->fetch(PDO::FETCH_OBJ);
    ?>
    <form method="post" action="" role="form" id="ajaxForm">
        <input type="hidden" name="update_discount_rule" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>MSID : </label>
                    <input type="hidden" class="form-control" name="MSID" value="<?= $discountrule->MSID; ?>">
                    <?= $schoolspopup->name; ?>

                </div>
                <div class="form-group">
                    <label>Date From</label>
                    <input class="form-control datepikerfm" type="text" name="datefrom" id="datefrom" value="<?= ($discountrule->date_from ? $discountrule->date_from : $slSessionDates->begins); ?>" />
                </div>
                <div class="form-group">
                    <label>Date To</label>
                    <input class="form-control datepikerfm" type="text" name="dateto" id="dateto" value="<?= ($discountrule->date_from ? $discountrule->date_to : $slSessionDates->ends); ?>" />
                </div>
                <div class="form-group">
                    <label>Discount</label>
                    <select class="form-control" name="discount_id" id="discount_id">
                        <?php
                        echo '<option value="">-Select-</option>';
                        while ($rowv = $discount->fetch())
                            {
                            echo '<option value="' . $rowv['discount_id'] . '" ' . ($discountrule->discount_id == $rowv['discount_id'] ? 'selected="selected"' : '') . '>' . $rowv['name'] . '</option>';
                            }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Class From<span class="text-red">*</span></label>
                    <select name="class_from" class="class_check form-control" required>
                        <option value="">Class From</option>
                        <?php
                        $classs = Master::get_classes($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        <?php
                        foreach ($classs as $class)
                            {
                            if ($class['class_no'] == $discountrule->class_from)
                                {
                                $selected = 'selected="selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $class['class_no'] . '" ' . $selected . '>' . $class['class_name'] . '</option>';
                            }
                        ?>
                    </select>
                </div><div class="form-group">
                    <label>Class To<span class="text-red">*</span></label>
                    <select name="class_to" class="class_check form-control" required>
                        <option value="">Class To</option>
                        <?php
                        $classs = Master::get_classes($MSID, '')->fetchAll(PDO::FETCH_ASSOC);
//                        print_r($classs);
//                        exit();
                        ?>
                        <?php
                        foreach ($classs as $class)
                            {
                            if ($class['class_no'] == $discountrule->class_to)
                                {
                                $selected = 'selected="selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $class['class_no'] . '" ' . $selected . '>' . $class['class_name'] . '</option>';
                            }
                        ?>
                    </select>
                </div>
            </div>
            <!--/col-6-->
            <div class="col-md-6">
                <div class="form-group">
                    <label>Fee Id</label>
                    <select class="form-control" name="fee_id" id="fee_id" required>
                        <?php
                        echo '<option value="">-Select-</option>';
                        while ($rowv = $school_fees->fetch())
                            {
                            echo '<option value="' . $rowv['fee_id'] . '" ' . ($discountrule->fee_id == $rowv['fee_id'] ? 'selected="selected"' : '') . '>' . $rowv['fee_name'] . '</option>';
                            }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Sr No From<span class="text-red">*</span></label>
                    <select class="form-control" name='sr_no_from' value='' required>
                        <?php
                        foreach (school_months($sessinDate->begins, $sessinDate->ends) as $key => $val)
                            {
                            if ($discountrule->sr_no_from == $key)
                                {
                                $selected = 'selected="selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $key . '" ' . $selected . '>' . $val . '</option>';
                            }
                        ?>
                    </select>
                </div><div class="form-group">
                    <label>Sr No To<span class="text-red">*</span></label>
                    <select class="form-control" name='sr_no_to' value='' required>
                        <?php
                        foreach (school_months($sessinDate->begins, $sessinDate->ends) as $key => $val)
                            {
                            if ($discountrule->sr_no_to == $key)
                                {
                                $selected = 'selected="selected"';
                                }
                            else
                                {
                                $selected = '';
                                }
                            echo '<option value="' . $key . '" ' . $selected . '>' . $val . '</option>';
                            }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label> Percent </label>
                    <input class="form-control" type="text" name="percent" value="<?= $discountrule->percent ?>" />
                </div>
                <div class="form-group">
                    <label>Fixed</label>
                    <input class="form-control" type="text" name="fixed" value="<?= $discountrule->fixed_amount ?>" />
                </div> 
            </div>
            <!--/col-6-->
        </div>
        <div class="row">
            <div class="col-md-4">
                <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
            </div>
            <div class="col-md-8 text-center"><span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span></div>
        </div>
    </form>
    <script type="text/javascript">
        $(function () {
            $('.datepikerfm').datepicker({format: 'yyyy-mm-dd', todayHighlight: true, clearBtn: true});
            $('#selectalledit').click(function (event) {
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#allmnthedit').click(function (event) {
                if (this.checked) {
                    $('.checkmonth').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkmonth').each(function () {
                        this.checked = false;
                    });
                }
            });
            //submit form 
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/ajax-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        responseText = $.trim(responseText);
                        if (responseText == 'validation') {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! all fields are required.</div>');
                        } else {
                            if (responseText != 'error') {
                                location.reload();
                                eModal.close();
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                            }
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
<?php } 
else if($content == 'edit_house')
{
     $schoolspopup = Master::get_schools();
     $houses = Houses::get_houses('', $id)->fetch(PDO::FETCH_ASSOC);
   
?>
 <form method="post" action="" role="form" id="ajax_edit_house">
            
 <input type="hidden" name="edit_house" value="true" />
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                         <div class="form-group">
                             <label>School</label>
                            <select class="form-control" name="MSID" id="currschool" required>
                <option value="">-Select School-</option>
                <?php while($school = $schoolspopup->fetch()){ 
                    
                    if($houses['MSID'] == $school['MSID'])
                    {
                        $selected = "selected='selected'";
                    }
                    else
                    {
                       $selected = ''; 
                    }
                    
                    ?>
                <option value="<?=$school['MSID']; ?>" <?= $selected?>>
                <?=$school['name']; ?>
                </option>
                <?php } ?>
              </select>
                        <div class="form-group">
                            <label>House Short Name</label>
              <input class="form-control higt" placeholder="Houses short name" value="<?= $houses['house_s_name']?>" required id="houses_sname" name="houses_sname" type="text">
            </div>
              
         <div class="form-group">
             <label>House Full Name</label>
              <input class="form-control higt" placeholder="Houses full name" value="<?= $houses['house_f_name']?>" required id="houses_fname" name="houses_fname" type="text">
              <input type="hidden" name="id" value="<?= $houses['id']?>"/>
              <span id="error_show"></span>
         </div>  
                        
                                    
                          
                                </div>
                                <!-- \col --> 
                            </div>
                            <!-- \row end -->
                        </div>
                   
                </div>
                <div class="modal-footer">
                    
                    <button type="submit" class="btn btn-primary" id="edit_house_submit">Save changes</button>
                </div>
            
                </form>  
    
    <script type="text/javascript">
    
   $('#edit_house_submit').click(function () {
        
          
        
          /* $('#onajaxForm .errorDiv').remove();
              var errors = '';
                var currschool = $("#currschool");
                var houses_sname = $("#houses_sname");
                 var houses_fname = $("#houses_fname");
        
                
                  if (currschool.val() == '') {
                    currschool.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    currschool.parent('.form-group').removeClass('has-error');
                }
               
                
                if (houses_sname.val() == '') {
                    houses_sname.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    houses_sname.parent('.form-group').removeClass('has-error');
                }
                if (houses_fname.val() == '') {
                    houses_fname.parent('.form-group').addClass('has-error');
                    errors = 'true';
                } else {
                    houses_fname.parent('.form-group').removeClass('has-error');
                }
                
                if (errors != '') {
        	$("#error_show").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                    return false;
                }
        */
          
        
        
        
	   var datastring = $("#ajax_edit_house").serialize();
          // alert(datastring);
           
	   $(".errorDiv").remove();
	   $.ajax({
			type: "POST", // type
			url: "<?= CLIENT_URL ?>/ajax-post", // request file
			data: datastring, // post data
			success: function (responseText) { // get the response
				responseText = $.trim(responseText);
        
                                //alert(responseText);
				if (responseText != 'error') {
					location.reload(); 
				} else {
					$("#ajax_edit_house").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
				}
			}, // end success
			error: function (jqXHR, textStatus, errorThrown) {
				if (jqXHR.status == 500) {
					$("#ajax_edit_house").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
				} else {
					$("#ajax_edit_house").append('<div class="errorDiv text-red">Unexpected error.</div>');
				}
			}
		});
		// end
		return false;
	 });        

    
    
    
   </script> 
<?php 
}

?>
    
