<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Users | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = ''; 
$sGeneral = new General();
$sUserManager = new UserManager();
$type = http_get('param1');

if($type=='add'){
  $oPageLayout->sWindowTitle = 'Add New User | ' . CLIENT_NAME;
  $sGeneral = new General();

 if(isset($_POST['rsubmit'])){
     $sUserManager->create_user($_POST);
  }
  
  $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/users-register.inc.php';
 
}
else if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit User | ' . CLIENT_NAME;
  $user_ID = http_get('param2');

$get_user = UserManager::get_users($user_ID)->fetch(PDO::FETCH_ASSOC); 

  if(isset($_POST['updatesuser'])){
    $sUserManager->update_user($user_ID,$_POST,CLIENT_URL.'/users/edit/'.$user_ID);
  }
  //change password 
  if(isset($_POST['updatepass'])){
    $sUserManager->change_password($user_ID,$_POST,CLIENT_URL.'/users/edit/'.$user_ID);
  }

$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/users-edit.inc.php'; // special home page
}
else{ 
$user_id = http_get('param2');
 /**
  * Delete record action function 
 **/
 if($type=='del'){
  $dataarr = array(
			   'id'        => $user_id,
			   'tablename' => 'users',
			   'redirect'  => CLIENT_URL.'/users',
			   'where'     => 'user_id'
			  );
  $deleteusers = General::delete($dataarr);
 }
 /**
 * activate / deactivate school
 **/
 if($type=='act'){
   $dataarr = array(
			   'id'        => $user_id,
			   'tablename' => 'users',
			   'redirect'  => CLIENT_URL.'/users',
			   'where'     => 'user_id',
			   'status'     => '1'
			  );
  $changeusers = $sGeneral->activate_deactivate($dataarr);
 }
 if($type=='deact'){
   $dataarr = array(
			   'id'        => $user_id,
			   'tablename' => 'users',
			   'redirect'  => CLIENT_URL.'/users',
			   'where'     => 'user_id',
			   'status'     => '0'
			  );
  $changeusers = $sGeneral->activate_deactivate($dataarr);
 } 
  $users = UserManager::get_users();
  print_r($users);
  
  
$totalrecords = $users->rowCount();
$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/users.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>