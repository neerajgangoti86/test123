<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Users | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Subjects Panel'; 
$sSuperAdmin =  new SuperAdmin();
$type = http_get('param1');
if ($type == 'add') {
    $oPageLayout->sWindowTitle = 'School Subject Group | ' . CLIENT_NAME;
    $schools = Master::get_schools();
	$subject_group = SuperAdmin::get_subject_group();
	$subfeegroup   = SuperAdmin::schoolSubjFeeGroup($_SESSION['user_school']);	
    if (isset($_POST['submit'])) {
        $sSuperAdmin->add_school_subject('', $_POST);
    }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/school-subject-register.inc.php';
} else if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Subject | ' . CLIENT_NAME;
    $id = http_get('param2');

    if (isset($_POST['update'])) {
		$sSuperAdmin->add_school_subject($id, $_POST);
    }
    //get current designation
	$school_sub = SuperAdmin::get_school_subject('',$id)->fetch(PDO::FETCH_ASSOC);
	$subfeegroup   = SuperAdmin::schoolSubjFeeGroup($school_sub['MSID']);
	$subject_group = SuperAdmin::get_subject_group();

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/school-subject-edit.inc.php'; // special home page
} else {
	$school_sub =0;
	$totalRow =0;

    $school_sub = SuperAdmin::get_school_subject($_SESSION['user_school'],'','all');
    $totalRow = $school_sub->rowCount();

    if ($type == 'del') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'subjects',
                'redirect' => CLIENT_URL . '/school-subject-group',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
$schools = Master::get_schools();

$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/school-subject.inc.php'; // special home page
}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>