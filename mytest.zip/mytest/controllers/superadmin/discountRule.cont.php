<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Discount Rule | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fee Panel';
$sDiscount = new Discount();
$type = http_get('param1');
if(empty($oCurrentUser->MSID)){$schlsid = '1001';}else{ $schlsid = $oCurrentUser->MSID;}
$sessinDate = Master::get_session($schlsid,$_SESSION['year'])->fetch(PDO::FETCH_OBJ);
$schools = Master::get_schools();

    if ($type == 'delete') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'discount_rule',
                'redirect' => CLIENT_URL . '/discount-rules',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
    $schoolspopup = Master::get_schools();
	$classesfrm   = Master::get_classes($_SESSION['user_school']);
	$slSessionDates = Master::get_session($_SESSION['user_school'],$_SESSION['year'])->fetch(PDO::FETCH_OBJ);
	$discount = Discount::get_discount($_SESSION['user_school'],'', array('selectAll' => 'true'));
    $discountrule = Discount::getDiscountRules($_SESSION['user_school'], '','', array('page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $discountrule->rowCount();
    $total_no_recrd = Discount::getDiscountRules($_SESSION['user_school'],'','all')->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'discount-rules');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/discount-rules.inc.php'; // special home page


# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>