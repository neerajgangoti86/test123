<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee Schedule | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
$currentPage = 'Fee Panel';
$sGeneral = new General();
$sFee = new Fee();
$type = http_get('param1');
if (empty($oCurrentUser->MSID))
    {
    $schlsid = '1001';
    }
else
    {
    $schlsid = $oCurrentUser->MSID;
    }
$sessinDate = Master::get_session($schlsid, $_SESSION['year'])->fetch(PDO::FETCH_OBJ);

if ($type == 'add')
    {
    $schoolspopup = Master::get_schools();
    $oPageLayout->sWindowTitle = 'Add New User | ' . CLIENT_NAME;

    if (isset($_POST['fee_schedule']))
        {
 
        $sFee->add_fee_schedule('', $_POST);
        }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/fee_schedule-register.inc.php';
    }
else if ($type == 'edit')
    {
    $oPageLayout->sWindowTitle = 'Edit Fee Schedule | ' . CLIENT_NAME;
    $id = http_get('param2');

    if (isset($_POST['update_fee_schedule']))
        {
        $sFee->add_fee_schedule($id, $_POST);
        }
    //get current designation
    $fee_schedule = Fee::get_fee_schedule('', $id)->fetch(PDO::FETCH_ASSOC);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/fee_schedule-edit.inc.php'; // special home page
    }
else
    {
    $schools = Master::get_schools();
    $fee_schedule_id = http_get('param2');
    /**
     * Delete record action function 
     * */
    if ($type == 'delete')
        {
        if (!empty($fee_schedule_id))
            {
            $dataarr = array(
                'id' => $fee_schedule_id,
                'tablename' => 'fee_schedule',
                'redirect' => CLIENT_URL . '/fee-schedule',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
            }
        }
    /* start hide/show column */
    $fee_array = array(
        "msid" => " MSID",
        "pay_mode" => " Pay Mode",
        "sr_no" => " Sr No",
        "sr_no_from" => " Sr No From",
        "sr_no_to" => " Sr No To");

    if (isset($_POST['columnsubmit']))
        {
        $fields = array(); // for making the field array
        foreach ($_POST['column1'] as $key => $val)
            {
            $fields[$val] = $fee_array[$val];
            }
        $data = json_encode($fields);  // encoding in json format
        $sGeneral->add_hide_show_columns('', $MSID, $oCurrentUser->user_id, DB_PREFIX . "fee_schedule", $data);
        }
    //
    $existing = $sGeneral->get_hide_show_columns($MSID, $oCurrentUser->user_id, DB_PREFIX . "fee_schedule");
    $count_data = $existing->rowCount();
    if ($count_data > 0)
        {
        $get_columns = $existing->fetch();
        $fields = json_decode($get_columns['fields'], true);
        $selected_columns_fee = array();
        foreach ($fields as $k => $val)
            {
            $selected_columns_fee[] = $k;
            }
        }
    if (empty($selected_columns_fee))
        {
        $selected_columns_fee = array('msid', 'pay_mode', 'sr_no', 'sr_no_from', 'sr_no_from');
        }
    /* end hide/show column */
    if ($type == 'page')
        {
        $page = http_get('param2');
        }
    else
        {
        $page = 1;
        }
    if (isset($_SESSION['r_per_page']))
        {
        $records_per_page = $_SESSION['r_per_page'];
        }
    else
        {
        $records_per_page = RECORDS_PER_PAGE;
        }

    $feeSchedule = Fee::get_fee_schedule($_SESSION['user_school'], '', '', array('page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $feeSchedule->rowCount();
    $total_no_recrd = Fee::get_fee_schedule($_SESSION['user_school'], '', 'all')->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'fee-schedule');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/fee_schedule.inc.php'; // special home page
    }

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>