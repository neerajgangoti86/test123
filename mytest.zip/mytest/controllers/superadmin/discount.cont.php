<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Discount | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fee Panel';
$sDiscount = new Discount();
$type = http_get('param1');

if ($type == "add") {
    $schoolspopup = Master::get_schools();
    $oPageLayout->sWindowTitle = "Add New Discount |" . CLIENT_NAME;
    if (isset($_POST['discount_submit'])) {
        $sDiscount->add_discount('', $_POST);
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/discount-register.inc.php';
} elseif ($type == "edit") {

    $oPageLayout->sWindowTitle = 'Edit Discount| ' . CLIENT_NAME;
    $id = http_get('param2');
    if (isset($_POST['update_discounts'])) {
        $sDiscount->add_discount($id, $_POST);
    }
    //get current designation
    $discounts = Discount::get_discount('', $id)->fetch(PDO::FETCH_ASSOC);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/discount-edit.inc.php'; // special home page
} else {

$schools = Master::get_schools();

    if ($type == 'delete') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'discount_names',
                'redirect' => CLIENT_URL . '/discount',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
  
    $discounts = Discount::get_discount($_SESSION['user_school'], '', array('selectAll' => 'false', 'page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $discounts->rowCount();
    $total_no_recrd = Discount::get_discount($_SESSION['user_school'])->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'discount');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/discount.inc.php'; // special home page
}




# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>