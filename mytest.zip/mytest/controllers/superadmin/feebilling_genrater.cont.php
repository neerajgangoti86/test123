<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee Schedule | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
$currentPage = 'Fee Panel';
$sGeneral = new General();
$sFee = new Fee();

$type = http_get('param1');
if (empty($oCurrentUser->MSID)) {
    $schlsid = '1001';
} else {
    $schlsid = $oCurrentUser->MSID;
}

if (@$_POST['user_school']) {
    $msid = $_POST['user_school'];
//    $class = $_POST['class'];
    $user = UserManager::get_slusers($msid . "vm3", $msid)->fetch();
   
    $delete_school_session = Fee::get_delete_student_from_fee_billing($_POST['user_school'], '', $user['mysession']);
    $inserting_school_session_data = Fee::insert_student_into_fee_billing($msid, '', '');
    $message = new Messages();
    $message->add('s', 'Fee Billing Genrated successfully!', CLIENT_URL . '/fee-billing-genrater');
}
$schools = Master::get_schools();
$fee_billing_genrater = http_get('param2');
/**
 * Delete record action function 
 * */
if ($type == 'delete') {
    if (!empty($fee_billing_genrater)) {

        $delete_school_session = Fee::get_delete_student_from_fee_billing($fee_billing_genrater, '', $oCurrentUser->mysession);
        $message = new Messages();
        $message->add('e', 'Deleted successfully!', CLIENT_URL . '/fee-billing-genrater');
    }
}

/* end hide/show column */
if ($type == 'page') {
    $page = http_get('param2');
} else {
    $page = 1;
}
if (isset($_SESSION['r_per_page'])) {
    $records_per_page = $_SESSION['r_per_page'];
} else {
    $records_per_page = RECORDS_PER_PAGE;
}

$feeSchedule_genrated = Fee::get_genrated_distinct_fee('', $oCurrentUser->mysession, '', array('page' => $page, 'record_per_page' => $records_per_page));
$totalrecords = $feeSchedule_genrated->rowCount();
$total_no_recrd = Fee::get_genrated_distinct_fee('', $oCurrentUser->mysession, 'all')->rowCount();

$links = 3;

$Paginator = new Paginator($total_no_recrd, $records_per_page, $page, 'fee-billing-genrater');

$pagination = $Paginator->createLinks($links, 'pagination');

$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/feebilling_genrater.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>