<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'School Fee Group | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fee Panel'; 
$sSuperAdmin =  new SuperAdmin();
$type = http_get('param1');
    if ($type == 'del') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'fee_names',
                'redirect' => CLIENT_URL . '/fee-name',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
    $school_feenames =0;
	$totalRow =0;

	$school_feenames = Fee::get_fee_names($_SESSION['user_school'],'','all');
	$totalRow = $school_feenames->rowCount();

$schools = Master::get_schools();	
$schoolspopup = Master::get_schools();
$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/fee-names-list.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>