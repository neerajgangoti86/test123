<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Users | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Subjects Panel'; 
$sSuperAdmin =  new SuperAdmin();
$message = new Messages();
$type = http_get('param1');
if ($type == 'add') {
    $oPageLayout->sWindowTitle = 'Add New Subject Group| ' . CLIENT_NAME;
	if (isset($_POST['subjectgrp_submit'])) {
		
	$sql = "select SLG.group_id AS group_id,group_concat(S.subject_id order by S.subject_id ASC separator ',') AS Subjects from ". DB_PREFIX ."subjects_group SLG join ". DB_PREFIX ."subjects_all S on(S.subject_id = SLG.subject_id) group by SLG.group_id";
	
	$sqlgrpid = "select SLG.group_id AS group_id,group_concat(S.subject_id order by S.subject_id ASC separator ',') AS Subjects from ". DB_PREFIX ."subjects_group SLG join ". DB_PREFIX ."subjects_all S on(S.subject_id = SLG.subject_id) group by SLG.group_id order by SLG.group_id DESC";

    $oDb = DBConnection::get();
    $sql = $oDb->query($sql);
	@$curr_grp = implode(',',$_POST['subjectid']);
	$errors = array();
	while($rowv = $sql->fetch()){
		if($curr_grp == $rowv['Subjects']){
		 	$errors[] = 'true';
		}
	}
	if(!empty($errors)){
	 $message->add('e', 'This group is already exit!');	
	}else{
	 $newgrpidarr = $oDb->query($sqlgrpid)->fetch(PDO::FETCH_ASSOC);
	 $newgrpid = $newgrpidarr['group_id']+1;
	 $sSuperAdmin->add_subject_group('',$newgrpid, $_POST);
	}
    }
    $subjects = SuperAdmin::get_subject('','all');
    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/subjectgroup-register.inc.php';
} else if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Subject Group | ' . CLIENT_NAME;
    $id = http_get('param2');

    if (isset($_POST['subjectgrp_update'])) {
        $sSuperAdmin->add_subject_group($id,'', $_POST);
    }
    //get current designation
	$sql_subgroup = "select SLG.group_id AS group_id,SLG.subject_id AS subject_id,S.subject_s_name AS subjects,SLG.orders AS orders from ms_subjects_group SLG join ms_subjects_all S on(S.subject_id = SLG.subject_id) where SLG.group_id={$id} order by SLG.orders";
	$oDb = DBConnection::get();
    $subject_group = $oDb->query($sql_subgroup);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/subjectgroup-edit.inc.php'; // special home page
} else {

$subject_group = SuperAdmin::get_subject_group();
$totalrecords = $subject_group->rowCount();

$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/subjectgroup.inc.php'; // special home page
}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>