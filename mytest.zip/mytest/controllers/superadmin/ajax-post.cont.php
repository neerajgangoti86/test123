<?php

# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller for handeling the ajax pages post values
 * This is a very special controller that is included on other places beside the index
 */
$oDb = DBConnection::get();
if (!empty($_POST['MSID']))
    {
    $MSID = $_POST['MSID'];
    }

if (@$_POST['add_fee_names'] == 'true')
    {//used in school fee_name or group page
    if (empty($_POST['MSID']) || empty($_POST['feeid']) || empty($_POST['feename']) || empty($_POST['fee_group_id']) || empty($_POST['fee_grp_nm']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_names (MSID, fee_id, fee_name, fee_group_id, fee_group_name, created_date) VALUES  (:MSID, :fee_id, :fee_name, :fee_group_id, :fee_group_name, :created_date)');
            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':fee_id' => $_POST['feeid'],
                ':fee_name' => $_POST['feename'],
                ':fee_group_id' => $_POST['fee_group_id'],
                ':fee_group_name' => $_POST['fee_grp_nm'],
                ':created_date' => date('Y-m-d H:i:s')
            ));
            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Group added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_fee_names'] == 'true')
    {//used in edit school fee group name
    if (empty($_POST['MSID']) || empty($_POST['feeid']) || empty($_POST['feename']) || empty($_POST['fee_group_id']) || empty($_POST['fee_grp_nm']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_names SET fee_id = :fee_id, fee_name = :fee_name, fee_group_id = :fee_group_id, fee_group_name = :fee_group_name WHERE id = :id');
            $status = $sql->execute(array(
                ':fee_id' => $_POST['feeid'],
                ':fee_name' => $_POST['feename'],
                ':fee_group_id' => $_POST['fee_group_id'],
                ':fee_group_name' => $_POST['fee_grp_nm'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_fee_type'] == 'true')
    {
    if (empty($_POST['name']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_type (name, type, created_date) VALUES  (:name, :type, :created_date)');
            $status = $sql->execute(array(
                ':name' => $_POST['name'],
                ':type' => $_POST['type'],
                ':created_date' => date('Y-m-d H:i:s')
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Name added successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_fee_type'] == 'true')
    {
    if (empty($_POST['name']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_type SET name = :name WHERE id = :id');
            $status = $sql->execute(array(
                ':name' => $_POST['name'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_school_fee'] == 'true')
    {
    if (empty($_POST['MSID']) || empty($_POST['datefrom']) || empty($_POST['dateto']) || empty($_POST['fee_id']) || empty($_POST['class_from']) || empty($_POST['class_to']) || empty($_POST['fee_rate']))
        {
        echo 'validation';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee (MSID, date_from, date_to, fee_id, class_from,class_to, sr_no_from, sr_no_to, ff, ff_from, ff_to, fee_group_id, fee_rate  ,created_date) VALUES  (:MSID, :date_from, :date_to, :fee_id, :class_from, :class_to, :sr_no_from, :sr_no_to, :ff, :ff_from, :ff_to, :fee_group_id, :fee_rate, :created_date)');
            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':date_from' => $_POST['datefrom'],
                ':date_to' => $_POST['dateto'],
                ':fee_id' => $_POST['fee_id'],
                ':class_from' => $_POST['class_from'],
                ':class_to' => $_POST['class_to'],
                ':sr_no_from' => $_POST['srnofrom'],
                ':sr_no_to' => $_POST['srnoto'],
                ':ff' => $_POST['ff'],
                ':ff_from' => $_POST['fffrom'],
                ':ff_to' => $_POST['ffto'],
                ':fee_group_id' => $_POST['fee_group'],
                ':fee_rate' => $_POST['fee_rate'],
                ':created_date' => date('Y-m-d H:i:s')
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Fee added successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_school_fee'] == 'true')
    {
//    print_r($_POST);
//    exit();
    if (empty($_POST['datefrom']) || empty($_POST['dateto']) || empty($_POST['fee_id']) || empty($_POST['class_from']) || empty($_POST['class_to']) || empty($_POST['fee_rate']))
        {
        echo 'validation';
        }
    else
        {
        try
            {
            if (!empty($_POST['for_class']))
                {
                $classes = implode(',', $_POST['for_class']);
                }
            else
                {
                $classes = '';
                }
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee SET date_from = :date_from, date_to = :date_to, fee_id = :fee_id, class_from=:class_from,class_to=:class_to,sr_no_from = :sr_no_from, sr_no_to = :sr_no_to, ff = :ff, ff_from = :ff_from, ff_to = :ff_to, fee_group_id = :fee_group_id, fee_rate = :fee_rate WHERE id = :id');
            $status = $sql->execute(array(
                ':date_from' => $_POST['datefrom'],
                ':date_to' => $_POST['dateto'],
                ':fee_id' => $_POST['fee_id'],
                ':class_from' => $_POST['class_from'],
                ':class_to' => $_POST['class_to'],
                ':sr_no_from' => $_POST['srnofrom'],
                ':sr_no_to' => $_POST['srnoto'],
                ':ff' => $_POST['ff'],
                ':ff_from' => $_POST['fffrom'],
                ':ff_to' => $_POST['ffto'],
                ':fee_group_id' => $_POST['fee_group'],
                ':fee_rate' => $_POST['fee_rate'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Fee updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_discount_rule'] == 'true')
    {
    print_r($_POST);
    if (empty($_POST['MSID']) || empty($_POST['datefrom']) || empty($_POST['dateto']) || empty($_POST['fee_id']) || empty($_POST['sr_no_from']) || empty($_POST['sr_no_to']) || empty($_POST['discount_id']) || empty($_POST['percent']))
        {
        echo 'validation';
        }
    else
        {
        if ((@$_POST['class_from'] || @$_POST['class_from'] == "0") && (@$_POST['class_to'] || @$_POST['class_to'] == "0"))
            {
            try
                {
                $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'discount_rule (MSID, date_from, date_to, fee_id, discount_id, class_from,class_to,sr_no_from,sr_no_to,percent, fixed_amount,created_date) VALUES  (:MSID, :date_from, :date_to, :fee_id, :discount_id, :class_from, :class_to, :sr_no_from, :sr_no_to, :percent, :fixed_amount, :created_date)');
                $status = $sql->execute(array(
                    ':MSID' => $_POST['MSID'],
                    ':date_from' => $_POST['datefrom'],
                    ':date_to' => $_POST['dateto'],
                    ':fee_id' => $_POST['fee_id'],
                    ':discount_id' => $_POST['discount_id'],
                    ':class_from' => $_POST['class_from'],
                    ':class_to' => $_POST['class_to'],
                    ':sr_no_from' => $_POST['sr_no_from'],
                    ':sr_no_to' => $_POST['sr_no_to'],
                    ':percent' => $_POST['percent'],
                    ':fixed_amount' => $_POST['fixed'],
                    ':created_date' => date('Y-m-d H:i:s')
                ));
                if ($status)
                    {
                    $message = new Messages();
                    $message->add('s', 'Discount rule added successfully!');
                    echo 'success';
                    }
                else
                    {
                    echo 'errosSasr';
                    }
                }
            catch (PDOException $e)
                {
                echo '1error';
                }
            }
        else
            {
            echo 'validation';
            }
        }
    }
else if (@$_POST['update_discount_rule'] == 'true')
    {//used in ajax load page to update discount rule page
    if (empty($_POST['datefrom']) || empty($_POST['dateto']) || empty($_POST['fee_id']) || empty($_POST['discount_id']) || empty($_POST['percent']))
        {
        echo 'validation';
        }
    else
        {
        try
            {
//            if (!empty($_POST['for_class']))
//                {
//                $classes = implode(',', $_POST['for_class']);
//                }
//            else
//                {
//                $classes = '';
//                }
//            if (!empty($_POST['fee_of_months']))
//                {
//                $dismonths = implode(",", $_POST['fee_of_months']);
//                }
//            else
//                {
//                $dismonths = '';
//                }
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'discount_rule SET date_from = :date_from, date_to = :date_to, fee_id = :fee_id, discount_id = :discount_id, class_from = :class_from, class_to = :class_to, sr_no_from = :sr_no_from,sr_no_to = :sr_no_to, percent = :percent, fixed_amount = :fixed_amount WHERE id = :id');
            $status = $sql->execute(array(
                ':date_from' => $_POST['datefrom'],
                ':date_to' => $_POST['dateto'],
                ':fee_id' => $_POST['fee_id'],
                ':discount_id' => $_POST['discount_id'],
                ':class_from' => $_POST['class_from'],
                ':class_to' => $_POST['class_to'],
                ':sr_no_from' => $_POST['sr_no_from'],
                ':sr_no_to' => $_POST['sr_no_to'], 
                ':percent' => $_POST['percent'],
                ':fixed_amount' => $_POST['fixed'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Discount rule updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
    
    else if(@$_POST['add_house']== 'true')
    {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
            if (strlen(trim(@$_POST['houses_sname'])) == 0)
                $message->add('e', 'House short name is required..!!');
          
            if (strlen(trim(@$_POST['houses_fname'])) == 0)
                $message->add('e', 'House full name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'houses SET house_s_name = :house_s_name, house_f_name = :house_f_name WHERE id = :id');
                    $upsql->execute(array(
                        
                        ':house_s_name' => $_POST['houses_sname'],
                        ':house_f_name'=> $_POST['houses_fname'],
                        ':id'=>$id
                    ));
                    $message->add('s', 'House Name Field updated successfully!', CLIENT_URL . '/houses');
                    exit();
                } else {//insert into database
				   $sqldsid = "SELECT * FROM ".DB_PREFIX."houses where MSID=".$_POST['MSID']." order by house_id DESC limit 1";
				  // print_r($sqldsid);
                                   
				   $sqldsid = $oDb->query($sqldsid);
				   $sqldsrslt = $sqldsid->fetch(PDO::FETCH_OBJ);
				   if($sqldsid->rowCount() > 0){ $houseID = $sqldsrslt->house_id+1;}else{$houseID =1;}
                   $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'houses (MSID, house_id, house_s_name, house_f_name) VALUES  (:MSID, :house_id, :house_s_name, :house_f_name)');

                  $status =   $sql->execute(array(
                        ':MSID' => $_POST['MSID'],
		        ':house_id' => $houseID,
                        ':house_s_name' => $_POST['houses_sname'],
                        ':house_f_name'=> $_POST['houses_fname']
                    ));
                   if($status)
                   {
                       echo "Success";
                   }
                   else
                   {
                       echo "error";
                   }
                  
                   // $message->add('s', 'House is added successfully!', CLIENT_URL . '/houses');
                    exit();
                }
            }
        } catch (PDOException $e) {
            echo "error";
        }

         
    
        
       
        
        
        
    }
    else if(@$_POST['edit_house'] == true)
    {
        
       $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //********* Insert into database *********//
           if (!empty($_POST['id'])) 
            {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'houses SET MSID = :MSID, house_s_name = :house_s_name, house_f_name = :house_f_name WHERE id = :id');
                   $status = $upsql->execute(array(
                        ':MSID' => $_POST['MSID'],
                        ':house_s_name' => $_POST['houses_sname'],
                        ':house_f_name'=>  $_POST['houses_fname'],
                        ':id'=>$_POST['id']
                    ));
                   
                  if($status) 
                  {
                      echo "succes";
                  }
                  else
                  {
                      echo "error";
                  }
                   // $message->add('s', 'House Name Field updated successfully!', CLIENT_URL . '/houses');
                   // exit();
        
        
        
    }    
        
        
        
        }
        catch (PDOException $e) {
            echo "error";
        }
    }
?>