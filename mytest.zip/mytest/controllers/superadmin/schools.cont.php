<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Schools List | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Schools';
$sMaster = new Master();
$sGeneral = new General();
$type = http_get('param1');
$board = SuperAdmin::get_school_boards();
if(@$_POST['MSID']){
 $_SESSION['SCHOOL_ID'] = $_POST['MSID'];
// print_r($_POST['MSID']);
 $url=CLIENT_URL."/settings" ; 
 header("location:".$url);
}
if ($type == 'add') {

    $oPageLayout->sWindowTitle = 'Add New School | ' . CLIENT_NAME;
//create school MSID  id
    $get_school = Master::get_schools(1);
    $get_school_cnt = $get_school->rowCount();
    if ($get_school_cnt > 0) {
        $rowv = $get_school->fetch();
        $msidn = $rowv['MSID'] + 1;
    } else {
        $msidn = '1001';
    }
    //submit school form	  
    if (isset($_POST['rgstschool'])) {
        $sMaster->register_school('', $_POST, $_FILES, CLIENT_URL . '/schools');
    }
    //$classes = Master::get_classes('','','','default')->fetchAll(PDO::FETCH_ASSOC);
    //$sections = Master::get_sections()->fetchAll(PDO::FETCH_ASSOC);

    
    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/schools-register.inc.php';
} else if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit School | ' . CLIENT_NAME;
    $school_ID = http_get('param2');
    //submit school form
    if (isset($_POST['updateschool'])) {
        $sMaster->register_school($school_ID, $_POST, $_FILES, CLIENT_URL . '/schools/edit/' . $school_ID);
    }
//$classes = Master::get_classes('','','','default')->fetchAll(PDO::FETCH_ASSOC);
    $get_school = Master::get_schools('', $school_ID)->fetch(PDO::FETCH_ASSOC);
## school section exists.
    $schools_section = Master::get_schools_section($get_school['MSID']);

    $board = SuperAdmin::get_school_boards();
    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/schools-edit.inc.php'; // special home page
} else if ($type == "new-session") {
    $oPageLayout->sWindowTitle = 'New Session | ' . CLIENT_NAME;

    $schools = Master::get_schools();
    if (@$_POST['selected_school']) {
//        print_r($_POST);
        $school_selected = $_POST['selected_school'];
        $school_info = Master::get_schools('', $school_selected)->fetch(PDO::FETCH_OBJ);
        $session = Master::get_sessions($school_selected)->fetch(PDO::FETCH_OBJ);
        $new_year = $session->max + 1;
//        print_r($session);
        $oDb = DBConnection::get();
        if (isset($_POST['rsubmit'])) {
//            print_r(date('m-d',  strtotime($session->begins)));
//            exit();
            $next_year = $new_year + 1;
            $message = new Messages();
            $sql_add_session = $oDb->query("INSERT INTO `ms_sessions` ( `MSID`, `session_id`, `begins`, `ends`) VALUES( " . $session->MSID . ", " . $new_year . ", '" . $new_year . "-" . date('m-d', strtotime($session->begins)) . "', '" . $next_year. "-" . date('m-d', strtotime($session->ends)) . "');");
            $message->add('s', 'New session ' . $new_year . ' of ' . $school_info->name . ' added successfully!');
            $school_selected = "";
        }
    }
    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/schools.inc.php'; // special home page
} else {
    $school_ID = http_get('param2');
    /**
     * Delete record action function 
     * */
    /* if(isset($_GET['delete'])){
      $dataarr = array(
      'id'        => $_GET["delete"],
      'tablename' => 'schools',
      'redirect'  => 'mainadmin.php',
      'where'     => 'id'
      );
      $deleteusers = $adminclass->delete($dataarr);
      } */
    /**
     * activate / deactivate school
     * */
    if ($type == 'act') {
        $dataarr = array(
            'id' => $school_ID,
            'tablename' => 'schools',
            'redirect' => CLIENT_URL . '/schools',
            'status' => '1'
        );
        $changeusers = $sGeneral->activate_deactivate($dataarr);
    }
    if ($type == 'deact') {
        $dataarr = array(
            'id' => $school_ID,
            'tablename' => 'schools',
            'redirect' => CLIENT_URL . '/schools',
            'status' => '0'
        );
        $changeusers = $sGeneral->activate_deactivate($dataarr);
    }
    $schools = Master::get_schools();
    $totalrecords = $schools->rowCount();
    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/schools.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>