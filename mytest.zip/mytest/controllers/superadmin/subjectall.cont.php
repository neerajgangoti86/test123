<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Users | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Subjects Panel'; 
$sSuperAdmin =  new SuperAdmin();
$type = http_get('param1');
if ($type == 'add') {
    $oPageLayout->sWindowTitle = 'Add New Subject | ' . CLIENT_NAME;

    if (isset($_POST['subject_submit'])) {
        $sSuperAdmin->add_subject('', $_POST);
    }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/subjectall-register.inc.php';
} else if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Subject | ' . CLIENT_NAME;
    $id = http_get('param2');

    if (isset($_POST['subject_update'])) {
        $sSuperAdmin->add_subject($id, $_POST);
    }
    //get current designation
    $subjects = SuperAdmin::get_subject($id)->fetch(PDO::FETCH_ASSOC);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/subjectall-edit.inc.php'; // special home page
} else {
    if ($type == 'del') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'subjects_all',
                'redirect' => CLIENT_URL . '/subjectall',
                'where' => 'subject_id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
if($type=='page'){
 $page = http_get('param2');
}else{
 $page = 1;
}
if(isset($_SESSION['r_per_page'])){
$records_per_page=$_SESSION['r_per_page'];
}else{
$records_per_page=RECORDS_PER_PAGE;
}

$all_subjects = SuperAdmin::get_subject('','',array('page'=>$page,'record_per_page'=>$records_per_page));
$totalrecords = $all_subjects->rowCount();
$total_no_recrd = SuperAdmin::get_subject('','all')->rowCount();

$links      = 3;

$Paginator  = new Paginator( $total_no_recrd, $records_per_page ,$page,'subjectall');

$pagination = $Paginator->createLinks( $links, 'pagination' );

$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/subjectall.inc.php'; // special home page
}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>