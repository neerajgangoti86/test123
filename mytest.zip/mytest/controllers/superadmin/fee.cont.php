<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Fee | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Fee Panel'; 
$sSuperAdmin =  new SuperAdmin();
$type = http_get('param1');
$slSessionDates = Master::get_session($_SESSION['user_school'],$_SESSION['year'])->fetch(PDO::FETCH_OBJ);

    if ($type == 'del') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'fee',
                'redirect' => CLIENT_URL . '/fee',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }
$school_fees  = 0;
$totalRow     = 0;
$school_fees  = Fee::get_school_fee($_SESSION['user_school'],'','all');
$totalRow     = $school_fees->rowCount();

$schools      = Master::get_schools();
$schoolspopup = Master::get_schools();
$classesfrm   = Master::get_classes($_SESSION['user_school']);	
$oPageLayout->sPagePath = PAGES_FOLDER . '/superadmin/fee-list.inc.php'; // special home page
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>
