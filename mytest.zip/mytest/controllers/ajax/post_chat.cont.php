<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller for handeling the ajax pages post values
 * This is a very special controller that is included on other places beside the index
 */
$id = http_get("param1");
$oDb = DBConnection::get();
$MSID = @$_POST['MSID'];
if (@$_POST['add_station'] == 'true') {
//    print_r($_POST);
//    exit();
//    $sTransport->add_tpt_stations('', $_POST);
    if (empty($_POST['MSID']) || empty($_POST['stations']) || empty($_POST['route_id']) || empty($_POST['distance'])) {
        echo 'error';
    } else {
        try {


            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_stations (MSID, route_id, station_name, distance, created_date, status) VALUES  (:MSID, :route_id, :station_name, :distance, :created_date, :status)');
            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':route_id' => $_POST['route_id'],
                ':station_name' => $_POST['stations'],
                ':distance' => $_POST['distance'],
                ':created_date' => date('Y-m-d H:i:s'),
                ':status' => '1'
            ));

            if ($status) {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'TPT Station added successfully!');
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} else if (@$_POST['update_tpt_station'] == 'true') {
    if (empty($_POST['route_id']) || empty($_POST['stations']) || empty($_POST['distance'])) {
        echo 'error';
    } else {
        try {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_stations SET route_id = :route_id, station_name = :station_name, distance = :distance WHERE station_id = :station_id');
            $status = $upsql->execute(array(
                ':route_id' => $_POST['route_id'],
                ':station_name' => $_POST['stations'],
                ':distance' => $_POST['distance'],
                ':station_id' => $_POST['id']
            )); 
            if ($status) {
                $message = new Messages();
                $message->add('s', 'TPT Station Field updated successfully!');
                echo 'success';
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} else if (@$_POST['add_route'] == 'true') {
    if (empty($_POST['MSID']) || empty($_POST['route_name'])) {
        echo 'error';
    } else {
        try {

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_routes (MSID, route_name, created_date, status) VALUES  (:MSID, :route_name, :created_date, :status)');

            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':route_name' => $_POST['route_name'],
                ':created_date' => date('Y-m-d H:i:s'),
                ':status' => '1'
            ));




            if ($status) {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'TPT Route added successfully!');
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} else if (@$_POST['update_tpt_route'] == 'true') {
    if (empty($_POST['route_name'])) {
        echo 'error';
    } else {
        try {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_routes SET route_name = :route_name WHERE route_id = :route_id');
            $status = $upsql->execute(array(
                ':route_name' => $_POST['route_name'],
                ':route_id' => $_POST['id']
            ));


            if ($status) {
                $message = new Messages();
                $message->add('s', 'TPT Route updated successfully!');
                echo 'success';
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} else if (@$_POST['add_fee'] == 'true') {
    if (empty($_POST['station_id']) || empty($_POST['date_to']) || empty($_POST['date_from']) || empty($_POST['fee'])) {
        echo 'error';
    } else {
        try {

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'tpt_fee (MSID, station_id, date_from, date_to, fee, created_date, status) VALUES  (:MSID, :station_id, :date_from, :date_to, :fee, :created_date, :status)');

            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':station_id' => $_POST['station_id'],
                ':date_from' => $_POST['date_from'],
                ':date_to' => $_POST['date_to'],
                ':fee' => $_POST['fee'],
                ':created_date' => date('Y-m-d H:i:s'),
                ':status' => '1'
            ));

            if ($status) {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'TPT Fee added successfully!');
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} else if (@$_POST['update_tpt_fee'] == 'true') {
    if (empty($_POST['station_id']) || empty($_POST['station_id']) || empty($_POST['date_to']) || empty($_POST['fee'])) {
        echo 'error';
    } else {
        try {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_fee SET station_id = :station_id, date_from = :date_from, date_to = :date_to , fee = :fee WHERE id= :id');
            $status = $upsql->execute(array( 
                ':station_id' => $_POST['station_id'],
                ':date_from' => $_POST['date_from'],
                ':date_to' => $_POST['date_to'],
                ':fee' => $_POST['fee'],
                ':id' => $_POST['id']
            ));
            if ($status) {
                $message = new Messages();
                $message->add('s', 'Transport Fee updated successfully!');
                echo 'success';
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} 