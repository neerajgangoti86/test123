<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller for handeling the ajax pages post values
 * This is a very special controller that is included on other places beside the index
 */
$id = http_get("param1");
$oDb = DBConnection::get();
$MSID = @$_POST['MSID'];
 if (@$_POST['add_keyword'] == 'true') {
    if (empty($_POST['MSID']) || empty($_POST['name'])) {
        echo 'error';
    } else {
        try {
            $syntex = '['.$_POST['name'].']';

            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'keywords (MSID, name, syntex) VALUES  (:MSID, :name, :syntex)');

            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':name' => $_POST['name'],
                ':syntex' => $syntex,
            ));

            if ($status) {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Keyword added successfully!');
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} else if (@$_POST['update_keyword'] == 'true') {
    if (empty($_POST['name'])) {
        echo 'error';
    } else {
        try {
            $syntex1 = ' <'.$_POST['name'].'> ';
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'keywords SET name = :name, syntex = :syntex WHERE id = :id');
            $status = $upsql->execute(array(
                ':name' => $_POST['name'],
                ':syntex'     => $syntex1,
                ':id'   => $_POST['id'],
                
            ));


            if ($status) {
                $message = new Messages();
                $message->add('s', 'Keyword updated successfully!');
                echo 'success';
            } else {
                echo 'error';
            }
        } catch (PDOException $e) {
            echo 'error';
        }
    }
} 