<?php
# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");

/*
 * this part used for enrolled form page to list/select existing parents
 */
// --------------------------------For Fee Detail --------------------------------// 
if ($content == "fee_detai_headwise")
    {
    $new_fees = array();
    $old_fees = array();
    $rsrno = http_get("param3");
    $s_id = http_get("param4");

    $fees_done = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "1", '', $rsrno, $s_id);

    $count_check = $fees_done->rowCount();
    $fees = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "1");

    $coutns = $fees->rowCount();
    if ($count_check == $coutns)
        {
        
        }
    else
        {
        if ($coutns > 0)
            {
            echo "<select name='fee[]'>
        ";
            $fee = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "1");
            while ($rowv = $fee->fetch(PDO::FETCH_OBJ))
                {
                $fees_done = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "1", '', $rsrno, $s_id, $rowv->FeeId);

                $count_check = $fees_done->rowCount();
                echo $count_check;
                if ($count_check != 1)
                    {
                    echo "<option value='" . $rowv->FeeId . "'>$rowv->FeeName</option>";
                    }
                }
            echo "</select>
    ";
            }
        }
    echo '<a href="' . CLIENT_URL . '/ajax/fee_add/' . $id . '" data-title="Add Fee" data-ms="modal">Add Fee</a>';
    exit();
    }
else if ($content == "discount_detai_headwise")
    {
    $new_fees = array();
    $old_fees = array();
    $rsrno = http_get("param3");
    $s_id = http_get("param4");

    $fees_done = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "2", '', $rsrno, $s_id);

    $count_check = $fees_done->rowCount();
    $fees = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "2");

    $coutns = $fees->rowCount();
    if ($count_check == $coutns)
        {
        
        }
    else
        {
        if ($coutns > 0)
            {
            echo "<select name='fee[]'>
        ";
            $fee = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "2");
            while ($rowv = $fee->fetch(PDO::FETCH_OBJ))
                {
                $fees_done = Fee::get_distinct_fee_names_from_billing($MSID, $oCurrentUser->mysession, "2", '', $rsrno, $s_id, $rowv->FeeId);

                $count_check = $fees_done->rowCount();
                echo $count_check;
                if ($count_check != 1)
                    {
                    echo "<option value='" . $rowv->FeeId . "'>$rowv->FeeName</option>";
                    }
                }
            echo "</select>
    ";
            }
        }
    echo '<a href="' . CLIENT_URL . '/ajax/fee_discout/' . $id . '" data-title="Add Discount" data-ms="modal">Add Discount</a>';
    exit();
    }
else if ($content == 'fee_deteil')
    {
    $student_id = http_get('param2');
    $class = http_get('param3');
    $due_date = http_get('param4');
    $srno = http_get('param5');

    $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
    $fee_dtl = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->acno, $srno, 'FALSE', 'True');

//print_r($student);
    $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">

        <input type="hidden" name="add_fine" value="true" />
        <input type="hidden" name="s_id" value="<?= $student->student_id ?>" />
        <input type="hidden" name="due_date" value="<?= $due_date ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />

        <table width="400" border="1" align="center" id="fee_table" >
            <tr valign="top" class="simple">
                <td colspan="3" align="center" class="simplebold" >Due Date : <?= $due_date ?>( Fee For month of : <?php echo date("M", strtotime($due_date)); ?>) Amount &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            </tr>
            <tr valign="top" class="simple">
                <td colspan="3" align="center" class="simplebold" ><?= $student->student_id ?> &nbsp;<?= $student->name ?>&nbsp;Of <?= $student->class_name ?> Class &nbsp;<?= $student->f_name ?> &nbsp; of <?= $Village->name ?>&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            </tr>
            <tr valign="top" class="simple">
                <td width="86" class="simple" ><b>Sr. No.</b></td>
                <td width="109" class="simple"  align="center"><b>Fee</b></td>
                <td width="110" align="right" class="simple" ><b>Amount</b></td>

            </tr>
            <?php
            $i = 1;
            $ttl_fee = 0;
            while ($rowu = $fee_dtl->fetch())
                {
                $ttl_fee +=$rowu['FeeAmt'];
                ?>
                <tr class="simple4alltext">
                    <td valign="bottom" class="simple4alltext">
                        <?= $i ?></td>
                    <?php $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu['FeeId'])->fetch(PDO::FETCH_OBJ); ?>
                    <td valign="bottom" class="simple4alltext" align="center"><b> <?= $fee->fee_name ?>

                        </b></td>
                    <td align="right" valign="bottom" class="simple4alltext"><b><?= $rowu['FeeAmt'] ?></b></td>

                </tr> <?php
                $i++;
                }
            ?>
            <tr class="simplebold">
                <td colspan="2">Total</td>
                <td align="right">
                    <input type="hidden" class ="sumamt" value="<?= $ttl_fee ?>"></inut><span class="ttl_amount"><b><?= $ttl_fee ?></b></span></td>
            </tr>
            </tr>
        </table></form>
    <div class="row"><div class="col-md-9">



        </div>


        <?php
        $fees = Fee::get_fee_names($MSID, '', 'all', '', '', '');

        $fees_result = $fees->fetch();
        ?>




        <script>
            $(document).ready(function () {

                $(".sumamt")
                        .focusout(function () {
                            var sub_dis = $("#dis_val").val();
                            var sum = 0;
                            $(".sumamt").each(function () {
                                sum += +$(this).val();
                            });
                            var ttl = sum - sub_dis;
                            $(".ttl_amount").text(ttl);
                        });
                $(".subamt")
                        .focusout(function () {
                            var sub_dis = $("#dis_val").val();
                            var sum = 0;
                            $(".sumamt").each(function () {
                                sum += +$(this).val();
                            });
                            var ttl = sum - sub_dis;
                            $(".ttl_amount").text(ttl);
                        });
                var datastring = $("#ajaxForm").serialize();
            });
        </script>    <script>
            $(function () {
                $('#ajaxSubmit').click(function () {
                    $('#ajaxForm .errorDiv').remove();
                    var datastring = $("#ajaxForm").serialize();
                    $("#process").show();
                    ///ajax code
                    $.ajax({
                        type: "POST", // type
                        url: "<?= CLIENT_URL ?>/ajax-post", // request file
                        data: datastring, // post data
                        success: function (responseText) { // get the response
                            //                                                alert(responseText);
                            responseText = $.trim(responseText);
                            if (responseText != 'error') {
                                location.reload();
                                eModal.close();
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                            }
                            $("#process").hide();
                        }, // end success
                        error: function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                            } else {
                                $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                            }
                            $("#process").hide();
                        }
                    });
                    // end
                    return false;
                });




            });
        </script> <?php
        }
    else if ($content == 'fee_deteil_tpt')
        {
        $student_id = http_get('param2');
        $class = http_get('param3');
        $due_date = http_get('param4');
        $srno = http_get('param5');

        $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
        $fee_dtl = Fee::get_Std_fee_tpt($MSID, $oCurrentUser->mysession, $student->acno, $srno, 'FALSE', 'True', "2");

//print_r($student);
        $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
        ?>
        <form id="ajaxForm" method="post" action="" role="form">

            <input type="hidden" name="add_fine" value="true" />
            <input type="hidden" name="s_id" value="<?= $student->student_id ?>" />
            <input type="hidden" name="due_date" value="<?= $due_date ?>" />
            <input type="hidden" name="MSID" value="<?= $MSID ?>" />

            <table width="400" border="1" align="center" id="fee_table" >
                <tr valign="top" class="simple">
                    <td colspan="3" align="center" class="simplebold" >Due Date : <?= $due_date ?>( Fee For month of : <?php echo date("M", strtotime($due_date)); ?>) Amount &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                </tr>
                <tr valign="top" class="simple">
                    <td colspan="3" align="center" class="simplebold" ><?= $student->student_id ?> &nbsp;<?= $student->name ?>&nbsp;<?= $student->class ?>&nbsp;<?= $student->f_name ?> &nbsp; of <?= $Village->name ?>&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                </tr>
                <tr valign="top" class="simple">
                    <td width="86" class="simple" ><b>Sr. No.</b></td>
                    <td width="109" class="simple"  align="center"><b>Fee</b></td>
                    <td width="110" align="right" class="simple" ><b>Amount</b></td>

                </tr>
                <?php
                $i = 1;
                $ttl_fee = 0;
                while ($rowu = $fee_dtl->fetch())
                    {
                    $ttl_fee +=$rowu['FeeAmt'];
                    ?>
                    <tr class="simple4alltext">
                        <td valign="bottom" class="simple4alltext">
                            <?= $i ?></td>
                        <?php $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu['FeeId'])->fetch(PDO::FETCH_OBJ); ?>
                        <td valign="bottom" class="simple4alltext" align="center"><b> <?= $fee->fee_name ?>

                            </b></td>
                        <td align="right" valign="bottom" class="simple4alltext"><b><?= $rowu['FeeAmt'] ?></b></td>

                    </tr> <?php
                    $i++;
                    }
                ?>
                <tr class="simplebold">
                    <td colspan="2">Total</td>
                    <td align="right">
                        <input type="hidden" class ="sumamt" value="<?= $ttl_fee ?>"></inut><span class="ttl_amount"><b><?= $ttl_fee ?></b></span></td>
                </tr>
                </tr>
            </table></form>
        <div class="row"><div class="col-md-9">



            </div>

            <?php
            }
        else if ($content == 'fee_deteil_headwise')
            {

            $student_id = http_get('param2');

            $class = http_get('param3');

            $due_date = http_get('param4');

            $srno = http_get('param5');

            $rsrno = http_get('param6');



            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
            $fee_dtl = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->acno, $srno, 'FALSE', 'True');

//print_r($student);
            //

    $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
            ?>  <div class="row"><div class="col-md-9">







                </div>

                <div class="col-md-3">

                    <input type="button" class="btn btn-sm btn-success " name="add_fee" id="add_fee_btn" value="Add Fee"/>

                    <input type="button" class="btn btn-sm  "   style="background-color:Black ; color:Lime; " name="add_discount" id="add_discount_btn" value="Add Discount"/>

                </div></div>

            <br>

            <form id="ajaxForm" method="post" action="" role="form">
                <input type="hidden" name="add_fine_headwise" value="true" />

                <input type="hidden" name="s_id" value="<?= $student->student_id ?>" />

                <input type="hidden" name="due_date" value="<?= $due_date ?>" />

                <input type="hidden" name="MSID" value="<?= $MSID ?>" />

                <input type="hidden" name="sr_no" value="<?= $srno ?>" />

                <input type="hidden" name="rsr_no" value="<?= $rsrno ?>" />

                <input type="hidden" name="f_name" value="<?= $student->f_name ?>" />

                <input type="hidden" name="village" value="<?= $student->village ?>" />

                <input type="hidden" name="acno" value="<?= $student->acno ?>" />

                <input type="hidden" name="mobile_sms" value="<?= $student->mobile_sms ?>" />

                <input type="hidden" name="house" value="<?= $student->house ?>" />

                <input type="hidden" name="cls" value="<?= $student->class ?>"/>







                <table width="850" border="1" align="center" id="fee_table" >

                    <tr valign="top" class="simple">

                        <td colspan="3" align="center" class="simplebold" >Due Date : <?= $due_date ?>( Fee For month of : <?php echo date("M", strtotime($due_date)); ?>) Amount &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>

                    </tr>

                    <tr valign="top" class="simple">

                        <td colspan="3" align="center" class="simplebold" ><?= $student->student_id ?> &nbsp;<?= $student->name ?>&nbsp;Of <?= $student->class_name ?> Class &nbsp;<?= $student->f_name ?> &nbsp; of <?= $Village->name ?>&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>

                    </tr>

                    <tr valign="top" class="simple">

                        <td width="86" class="simple" ><b>Sr. No.</b></td>

                        <td width="109" class="simple"  align="center"><b>Fee</b></td>

                        <td width="110" align="right" class="simple" ><b>Amount</b></td>



                    </tr>

                    <?php
                    $i = 1;

                    $ttl_fee = 0;

                    $true = 0;

                    $id = 0;

                    while ($rowu = $fee_dtl->fetch())
                        {

                        if ($id == 0)
                            {

                            $id = $rowu['id'];
                            }
                        ?>

                        <?php
                        $ttl_fee +=$rowu['FeeAmt'];



                        if ($rowu['type'] == 1)
                            {

                            $true = 1;

                            if ($rowu['FeeAmt'] != 0)
                                {
                                ?>

                                <tr class="simple4alltext">

                                    <td valign="bottom" class="simple4alltext"> 

                                        <?= $i ?></td> 



                                    <td valign="bottom" class="simple4alltext" align="center"><b><?= $rowu['FeeName'] ?>



                                        </b></td>

                                    <td align="right" valign="bottom" class="simple4alltext"><b>

                                            <input type="text"  style="text-align:right;" class="sumamt form-control" name="update[<?= $rowu['id'] ?>]" value="<?php echo abs($rowu['FeeAmt']); ?>">

                                            <input type="hidden" name="type[<?= $rowu['id'] ?>]" value="<?= $rowu['type'] ?>"></b></td>



                                </tr> <?php
                                }
                            }
                        else if ($rowu['type'] == 2)
                            {

                            if ($rowu['FeeAmt'] != 0)
                                {
                                ?>

                                <tr class="simple4alltext">

                                    <td valign="bottom" class="simple4alltext"> 

                                        <?= $i ?></td> 



                                    <td valign="bottom" class="simple4alltext" align="center"><b><?= $rowu['FeeName'] ?>



                                        </b></td>

                                    <td align="right" valign="bottom" class="simple4alltext"><b>

                                            <input type="text"  style="background-color:Black ; color:Lime; text-align:right;" class="subamt form-control" name="update[<?= $rowu['id'] ?>]" value="<?php echo abs($rowu['FeeAmt']); ?>">

                                            <input type="hidden" name="type[<?= $rowu['id'] ?>]" value="<?= $rowu['type'] ?>"></b></td>



                                </tr>

                                <?php
                                }
                            }
                        else
                            {
                            ?>

                            <tr class="simple4alltext">

                                <td valign="bottom" class="simple4alltext">

                                    <?= $i ?></td>

                                <?php $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu['FeeId'])->fetch(PDO::FETCH_OBJ); ?>

                                <td valign="bottom" class="simple4alltext" align="center"><b> <?= $fee->fee_name ?>



                                    </b></td>

                                <td align="right" valign="bottom" class="simple4alltext"><b>

                                        <input type="hidden" class="sumamt" value="<?= $rowu['FeeAmt'] ?>">

                                        <?php echo round($rowu['FeeAmt']) ?></b></td>



                            </tr> <?php
                            } $i++;
                        }
                    ?> <input type="hidden" name="id_to_pass" id="id_to_pass" value="<?= $id ?>">

                    <tr class="simplebold">

                        <td colspan="2">Total</td>

                        <td align="right">

                            <input type="hidden"  value="<?= $ttl_fee ?>"></inut><span class="ttl_amount"><b><?= $ttl_fee ?></b></span></td>

                    </tr>



                </table></form>

            <br>

            <div class="row"><div class="col-md-9">







                </div>

                <div class="col-md-3"><div class="form-group">

                        <?php
                        if (@$true == 1)
                            {
                            ?>   <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block" >Save Changes</button><?php
                            }
                        else
                            {
                            ?>

                            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block" style="display">Save Changes</button> <?php } ?>

                    </div></div> </div>



            <?php
            $fees = Fee::get_fee_names($MSID, '', 'all', '', '', '');



            $fees_result = $fees->fetch();
            ?>









            <script>

                $(document).ready(function () {



                    $(".sumamt").focusout(function () {

                        var sub = 0;

                        $(".subamt").each(function () {

                            sub += +$(this).val();

                        });

                        var sum = 0;

                        $(".sumamt").each(function () {

                            sum += +$(this).val();

                        });

                        var ttl = sum - sub;

                        $(".ttl_amount").text(ttl);

                    });

                    $(".subamt")

                            .focusout(function () {

                                var sub = 0;

                                $(".subamt").each(function () {

                                    sub += +$(this).val();

                                });

                                var sum = 0;

                                $(".sumamt").each(function () {

                                    sum += +$(this).val();

                                });

                                var ttl = sum - sub;

                                $(".ttl_amount").text(ttl);

                            });

                    var datastring = $("#ajaxForm").serialize();

                });

            </script>    <script>

                $(function () {

                    $("#add_fee_btn").click(function ()

                    {

                        $('#fee_table').find('tr:last').prev().after('<tr><td></td><td class="list_fees"></td><td><input name="fees_value[]" value="0" style=" text-align:right; " class="fees_value form-control"/></td></tr>');

                        $("#ajaxSubmit").css("display", "block");

                        var id_to_pass = $('#id_to_pass').val();

                        var $rsrno = <?= $rsrno ?>;

                        var $student_id =<?= $student_id ?>;

                        //                        var datastring = 'id_to_pass=' + id_to_pass ;

                        $.ajax({
                            type: "POST", // type 

                            url: "<?= CLIENT_URL ?>/ajax/fee_detai_headwise/" + id_to_pass + "/" + $rsrno + "/" + $student_id, // r equest file

                            success: function (responseText) { // get the response

                                //                                                alert(responseText);

                                responseText = $.trim(responseText);

                                //                                alert(responseText);

                                if (responseText != 'error') {

                                    $(".list_fees").html('');

                                    $(".list_fees").append(responseText);

                                    //                                location.reload();

                                    //                                eMo dal.close();

                                } else {

                                    $("list_fees").append('<div class="errorDiv text-red">Error! PLease try again.</div>');

                                }

                                $("#process").hide();

                            }, // end success

                            error: function (jqXHR, textStatus, errorThrown) {

                                if (jqXHR.status == 500) {

                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');

                                } else {

                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');

                                }

                                $("#process").hide();

                            }

                        });

                    });





                });

                $(function () {

                    $("#add_discount_btn").click(function ()

                    {

                        $('#fee_table').find('tr:last').prev().after('<tr><td></td><td class="list_disc"></td><td><input name="fees_value[]" style=" text-align:right; background-color:Black ; color:Lime;" value="0" class="fees_value form-control"/></td></tr>');

                        $("#ajaxSubmit").css("display", "block");

                        var id_to_pass = $('#id_to_pass').val();

                        var $rsrno = <?= $rsrno ?>;

                        var $student_id =<?= $student_id ?>;

                        //                        var datastring = 'id_to_pass=' + id_to_pass ;

                        $.ajax({
                            type: "POST", // type 

                            url: "<?= CLIENT_URL ?>/ajax/discount_detai_headwise/" + id_to_pass + "/" + $rsrno + "/" + $student_id, // r equest file

                            success: function (responseText) { // get the response

                                //                                                alert(responseText);

                                responseText = $.trim(responseText);

                                //                                alert(responseText);

                                if (responseText != 'error') {

                                    $(".list_disc").html('');

                                    $(".list_disc").append(responseText);

                                    //                                location.reload();

                                    //                                eMo dal.close();

                                } else {

                                    $("list_fees").append('<div class="errorDiv text-red">Error! PLease try again.</div>');

                                }

                                $("#process").hide();

                            }, // end success

                            error: function (jqXHR, textStatus, errorThrown) {

                                if (jqXHR.status == 500) {

                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');

                                } else {

                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');

                                }

                                $("#process").hide();

                            }

                        });

                    });





                });

                /* start  Add Discount Section  */















                /* End Add Discount Section  */





                $('#ajaxSubmit').click(function () {





                    //alert("hi");

                    var datastring = $("#ajaxForm").serialize();

                    $("#process").show();

                    ///ajax code

                    $.ajax({
                        type: "POST", // type 

                        url: "<?= CLIENT_URL ?>/ajax-post", // r equest file

                        data: datastring, // post data

                        success: function (responseText) { // get the response

                            //                                                alert(responseText);

                            responseText = $.trim(responseText);

                            //                    alert(responseText);

                            if (responseText != 'error') {

                                location.reload();

                                eModal.close();

                                $(".sucess_msg").append('<div class="alert messages alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">Ã—</button><p>Fee Updated successfully!</p></div>');

                            } else {

                                //                                location.reload();

                                //                                eModal.close();

                                $(".sucess_msg").append('<div class="alert messages alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">Ã—</button><p>Fee Not successfully!</p></div>');

                            }

                            $("#process").hide();

                        }, // end success

                        error: function (jqXHR, textStatus, errorThrown) {

                            if (jqXHR.status == 500) {

                                $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');

                            } else {

                                $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');

                            }

                            $("#process").hide();

                        }

                    });

                    // end

                    return false;

                });

            </script> <?php
            }
        else if ($content == 'fee_deteil_headwise_tpt')
            {
            $student_id = http_get('param2');
            $class = http_get('param3');
            $due_date = http_get('param4');
            $srno = http_get('param5');
            $rsrno = http_get('param6');

            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
            $fee_dtl = Fee::get_Std_fee_tpt($MSID, $oCurrentUser->mysession, $student->acno, $srno, 'FALSE', 'True', "2");

//print_r($student);
//
            $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
            ?>  <div class="row"><div class="col-md-9">



                </div>
                <div class="col-md-3">

                </div></div>
            <br>
            <form id="ajaxForm" method="post" action="" role="form">



                <table width="850" border="1" align="center" id="fee_table" >
                    <tr valign="top" class="simple">
                        <td colspan="3" align="center" class="simplebold" >Due Date : <?= $due_date ?>( Fee For month of : <?php echo date("M", strtotime($due_date)); ?>) Amount &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    </tr>
                    <tr valign="top" class="simple">
                        <td colspan="3" align="center" class="simplebold" ><?= $student->student_id ?> &nbsp;<?= $student->name ?>&nbsp;Of <?= $student->class_name ?> Class &nbsp;<?= $student->f_name ?> &nbsp; of <?= $Village->name ?>&nbsp;&nbsp;   &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    </tr>
                    <tr valign="top" class="simple">
                        <td width="86" class="simple" ><b>Sr. No.</b></td>
                        <td width="109" class="simple"  align="center"><b>Fee</b></td>
                        <td width="110" align="right" class="simple" ><b>Amount</b></td>

                    </tr>
                    <?php
                    $i = 1;
                    $ttl_fee = 0;
                    while ($rowu = $fee_dtl->fetch())
                        {
                        ?>
                        <?php
                        $ttl_fee +=$rowu['FeeAmt'];
                        ?>
                        <tr class="simple4alltext">
                            <td valign="bottom" class="simple4alltext">
                                <?= $i ?></td>
                            <?php $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu['FeeId'])->fetch(PDO::FETCH_OBJ); ?>
                            <td valign="bottom" class="simple4alltext" align="center"><b> <?= $fee->fee_name ?>

                                </b></td>
                            <td align="right" valign="bottom" class="simple4alltext"><b>
                                    <input type="hidden" class="sumamt" value="<?= $rowu['FeeAmt'] ?>">
                                    <?php echo round($rowu['FeeAmt']) ?></b></td>

                        </tr> <?php
                        $i++;
                        }
                    ?> <tr class="simplebold">
                        <td colspan="2">Total</td>
                        <td align="right">
                            <input type="hidden"  value="<?= $ttl_fee ?>"></inut><span class="ttl_amount"><b><?= $ttl_fee ?></b></span></td>
                    </tr>

                </table></form>
            <br>
            <div class="row"><div class="col-md-9">



                </div>
                <div class="col-md-3"><div class="form-group"> </div></div> </div>

            <?php
            }
// --------------------------------For Fee Detail --------------------------------// 
// --------------------------------Edit Paid Fee--------------------------------// 
        else if ($content == 'edit_paid_fee')
            {
            //    print_r($MSID);
            $student_id = http_get("param2");
            $tr_id_no = http_get('param3');
            $trxn = Fee::get_txn($MSID, $tr_id_no)->fetch(PDO::FETCH_OBJ);

            $trxn_detail = Fee::get_txn_detail($tr_id_no);
            $unique_code = explode('-', $trxn->fee_receipt_id);
            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
            $fee_dtl = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->acno, $trxn->sr_no, 'TRUE', '')->fetch(PDO::FETCH_OBJ);

            //    print_r($tr_id_no);
            //   
            //    pr($trxn_detail);

            $dm = $oCurrentUser->mydate;

            $TrDate = date('Y-m-d', strtotime($dm));
            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
            //print_r($student);
            $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
            ?>

            <form id="ajaxForm" method="post" action="" role="form"><input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <input type="hidden" name="update_fee_collection" value="true" />
                <input type="hidden" name="sr_no" value="<?= $trxn->sr_no ?>" />
                <input type="hidden" name="tr_sr_no" value="<?= $tr_id_no ?>" />
                <input type="hidden" name="acno" value="<?= $student->acno ?>" />
                <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <input type="hidden" id="t_id" name="txn_id" value="<?= $trxn->fee_receipt_id ?>" />


                <div class="box-body"> 
                    <div class="row">
                        <div class="col-md-12" align="center"> <b><?= $student->acno ?>&nbsp;<?= $student->name ?> Of <?= $student->class_name ?> Class &nbsp; <?php echo $student->gender == "M" ? "S/O" : "D/O"; ?> &nbsp;<?= $student->f_name ?> </b>
                        </div><div class="row">  <div class="col-md-8"></div>

                            <div class="col-md-4">Due Date    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;:&nbsp; <?php echo $unique_code[2], "-", $unique_code[3], "-", $unique_code[4]; ?></div>
                        </div><div class="row">   <div class="col-md-8"></div>
                            <div class="col-md-4">Fee of Month : &nbsp;<?php echo date('F', strtotime("2012-$unique_code[3]-01")); ?></div>
                        </div><div class="row">    <div class="col-md-8"></div>

                        </div>
                    </div>


                    <div class="row">
                        <div class="form-group">
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Tr Date<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text"  class="issue_datea" value="<?= $TrDate; ?>" name="TrDate" >
                                </div>


                            </div> <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Student ID<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" value="<?= $student_id; ?>" name="student_id" >
                                </div>


                            </div> <div class="row">    

                                <div class="col-md-6" > 
                                    <label align="center" >Total Amount <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" class="ttl_amt"   value="<?= $trxn->ttl_paid; ?>" name="ttl_fee" >   
                                </div>


                            </div><div class="row">    

                                <div class="col-md-6" > 
                                    <label align="center" >Late Fee <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" class="sumamt"   id="id_fine"  value="<?= $trxn->late_fee; ?>" name="late_fee" >   
                                </div>


                            </div><div class="row">    

                                <div class="col-md-6" > 
                                    <label align="center" > Cal. Late Fee <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" class=""   id=""  value="<?= $trxn->cal_late_fee; ?>" name="cal_late_fee" >   
                                </div>


                            </div><div class="row">    

                                <div class="col-md-6" > 
                                    <label align="center" > Discount  <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 "> 
                                    <input type="text" class="subamt"   id="id1" value="<?= $trxn->discount; ?>" name="discount" >   
                                </div>


                            </div><div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"> 
                                        <label align="center" >Total Paying Amount <span class="text-red">*</span></label>
                                    </div>
                                    <div class="col-md-6 ">
                                        <lable type="text"    id="idttl" ><?php echo $sum = $trxn->ttl_paid + $trxn->late_fee - $trxn->discount; ?></lable>   
                                    </div>

                                </div>
                            </div><div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >DR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="dr" id="term">
                                        <?php
                                        if ($MSID != '1001')
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '1')->fetch(PDO::FETCH_OBJ);
                                            }
                                        else
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '23')->fetch(PDO::FETCH_OBJ);
                                            }
                                        ?>
                                        <option value="<?= $lesure->id ?>">
                                            <?= $lesure->name ?>                                      </option>

                                    </select>
                                </div>


                            </div>
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >CR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="cr" id="term"> 

                                        <option value="3">
                                            Fees-N-Funds                                     </option>
                                    </select>
                                </div>


                            </div> 
                        </div>

                    </div>

                    <div class="row sub_btn">
                        <div class="col-md-3">
                            <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                        </div>
                        <div class="col-md-3">
                            <a type="submit" id="delete_btn" name="rloaclsubmit" class="btn btn-lg btn-danger btn-block">Delete</a>
                        </div>
                        <?php
// print_r($oCurrentSchool->MSID);
// if($oCurrentSchool->MSID==10046){
                        //echo $trxn->sr_no;
                        ?>
                        <div class="col-md-3"> <a href="<?= CLIENT_URL ?>/fee-book/feebook_printS46.php/<?= $student_id; ?>/month/<?php
                            if ($trxn->sr_no == '0')
                                {
                                echo "1";
                                }
                            else
                                {
                                echo $trxn->sr_no;
                                }
                            ?>/<?= $tr_id_no ?>" type="submit"  target="_blank"  name="rloaclsubmit" class="btn btn-lg  btn-block" style="background-color:rgb(173,255,47);">Print Receipt</a>
                        </div>

                        <?php // }      ?>
                        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                    </div></div>
            </form>
            <script>
                $(function () {

                    $('#delete_btn').click(function () {
                        swal({
                            title: "Are you sure?",
                            text: "You will not be able to recover this Account Details !",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "Yes, delete it!",
                            cancelButtonText: "No, cancel please!",
                            closeOnConfirm: false,
                            closeOnCancel: false
                        },
                                function (isConfirm) {
                                    if (isConfirm) {
                                        var r_id = $("#t_id").val();
                                        var param = 'r_id/' + r_id;
                                        jQuery.ajax({
                                            type: "POST",
                                            url: "<?= CLIENT_URL ?>/ajax-page-post/del/" + param,
                                            success: function (response) {

                                                swal("Deleted!", "Your account details  has been deleted.", "success");
                                                location.reload();
                                                eModal.close();
                                            },
                                        });
                                    } else {
                                        swal("Cancelled", "Your account details are safe :)", "error");
                                    }
                                });
                    });
                    //   $(".sub_btn").hide();
                    $(".sumamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var fine = $(this).val();
                        var extra = $("#id1").val();
                        var ttl = 0;
                        ttl = parseInt(ttl_amt) + parseInt(fine) - parseInt(extra);
                        //                alert(ttl);
                        $("#idttl").text(ttl);
                    });
                    $(".subamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var fine = $("#id_fine").val();
                        var extra = $("#id1").val();
                        var ttl = 0;
                        ttl = parseInt(ttl_amt) + parseInt(fine) - parseInt(extra);
                        //                alert(ttl);
                        $("#idttl").text(ttl);
                    });
                    $('.issue_datea').datepicker({
                        format: 'yyyy-mm-dd',
                        todayHighlight: true,
                        startDate: "$ses_str_dt",
                        endDate: "$ses_end_dt",
                        clearBtn: true
                    });
                    $('#ajaxSubmit').click(function () {
                        $('#ajaxForm .errorDiv').remove();
                        var datastring = $("#ajaxForm").serialize();
                        $("#process").show();
                        ///ajax code
                        $.ajax({
                            type: "POST", // type
                            url: "<?= CLIENT_URL ?>/ajax-post", // request file
                            data: datastring, // post data
                            success: function (responseText) { // get the response
                                //                                                alert(responseText);
                                responseText = $.trim(responseText);
                                //                        alert(responseText);
                                //                                                alert(responseText);
                                if (responseText != 'error') {
                                    location.reload();
                                    eModal.close();
                                    $(".sucess_msg").append('<div class="alert messages alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Fee Updated successfully!</p></div>');
                                } else {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                                }
                                $("#process").hide();
                            }, // end success
                            error: function (jqXHR, textStatus, errorThrown) {
                                if (jqXHR.status == 500) {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                } else {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                }
                                $("#process").hide();
                            }
                        });
                        // end
                        return false;
                    });
                });
            </script>
            <?php
            }
        else if ($content == 'edit_paid_fee_headwise')
            {
//    print_r($MSID);
            $student_id = http_get("param2");
            $tr_id_no = http_get('param3');
            $trxn = Fee::get_txn($MSID, $tr_id_no)->fetch(PDO::FETCH_OBJ);
            //print_r($trxn);
            $trxn_detail = Fee::get_txn_detail($tr_id_no);
            $unique_code = explode('-', $trxn->fee_receipt_id);

            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
            $fee_dtl = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->acno, $trxn->sr_no, 'TRUE')->fetch(PDO::FETCH_OBJ);

            //print_r($fee_dtl);
//    print_r($tr_id_no);
//   
//    pr($trxn_detail);

            $dm = $oCurrentUser->mydate;

            $TrDate = date('Y-m-d', strtotime($dm));
            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
//print_r($student);
            $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
            ?>

            <form id="ajaxForm" method="post" action="" role="form"><input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <input type="hidden" name="update_fee_collection_headwise" value="true" />
                <input type="hidden" name="sr_no" value="<?= $trxn->sr_no ?>" />
                <input type="hidden" name="tr_sr_no" value="<?= $tr_id_no ?>" />
                <input type="hidden" name="acno" value="<?= $student->acno ?>" />
                <input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <input type="hidden"  id="t_id" name="txn_id" value="<?= $tr_id_no ?>" />


                <div class="box-body"> 
                    <div class="row">
                        <div class="col-md-12" align="center"> <b><?= $student->acno ?>&nbsp;<?= $student->name ?> Of <?= $student->class_name ?> Class <?php echo $student->gender == "M" ? "S/O" : "D/O"; ?> &nbsp;<?= $student->f_name ?> </b>
                        </div><div class="row"> <div class="col-md-12" align="center"> <b>&nbsp; of <?= $Village->name ?></b></div>

                        </div><div class="row">  <div class="col-md-8"></div>

                            <div class="col-md-4">Due Date    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;:&nbsp; <?php echo $unique_code[2], "-", $unique_code[3], "-", $unique_code[4]; ?></div>
                        </div><div class="row">   <div class="col-md-8"></div>
                            <div class="col-md-4">Fee of Month : &nbsp;<?php echo date('F', strtotime("2012-$unique_code[3]-01")); ?></div>
                        </div><div class="row">    <div class="col-md-8"></div>

                        </div>
                    </div>


                    <table width="550" align="center" >
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td width="86" class="simple" ><b>Sr. No.</b></td>
                            <td width="109" class="simple"  align="center"><b>Fee</b></td>
                            <td width="110" align="right" class="simple" ><b>Amount</b></td>

                        </tr> <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>
                        <?php
                        $i = 1;
                        $ttl_fee = 0;
                        while ($rowu = $trxn_detail->fetch(PDO::FETCH_OBJ))
                            {
                            $ttl_fee +=$rowu->rate;
                            $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu->item_id)->fetch(PDO::FETCH_OBJ);
                            if ($rowu->item_id < 0)
                                {
//                        echo $rowu->rate ;
                                if ($rowu->rate != 0)
                                    {
                                    ?> <tr class="simple4alltext">  
                                        <td valign="bottom" class="simple4alltext">
                                            <?= $i ?></td>
                                        <?php
                                        $fee_name = Fee::get_feename_2($MSID, $rowu->item_id)->fetch(PDO::FETCH_OBJ);
//                                        print_r($fee_name) ; 
                                        ?>
                                        <td valign="bottom" class="simple4alltext" align="center"> <?= $fee_name->FeeName ?>


                                        </td>
                                    <input type="hidden" value="<?= $rowu->item_id; ?>"  name="fee_id[<?= $i; ?>]">
                                    <td align="right" valign="bottom" class="simple4alltext">
                                        <?php
                                        if ($fee_name->type == 2)
                                            {
                                            ?>
                                            <input  class="subamt" align="center" style="background-color:Black ; color:Lime; text-align:right;" value="<?php echo abs($rowu->rate); ?>" id="<?= "id_" . $i ?>" name="fee[<?= $i; ?>]" >
                                            <?php
                                            }
                                        else
                                            {
                                            ?>             
                                            <input  class="sumamt" align="center" style="text-align:right;" value="<?php echo round($rowu->rate); ?>" id="<?= "id_" . $i ?>" name="fee[<?= $i; ?>]" >
                                        <?php } ?>  </td>

                                    </tr> 
                                    <?php
                                    }
                                }
                            else
                                {
                                ?>
                                <tr class="simple4alltext">
                                    <td valign="bottom" class="simple4alltext">
                                        <?= $i ?></td>
                                    <td valign="bottom" class="simple4alltext" align="center"> <?= $fee->fee_name ?>

                                    </td>
                                <input type="hidden" value="<?= $rowu->item_id; ?>" name="fee_id[<?= $i; ?>]">
                                <td align="right" valign="bottom" class="simple4alltext"><input   style="text-align:right;"  class="sumamt" align="center"  value="<?php echo round($rowu->rate); ?>" id="<?= "id_" . $i ?>" name="fee[<?= $i; ?>]" ></td>

                                </tr> 
                                <?php
                                }
                            $i++;
                            }
                        ?>  <tr class="simple4alltext">
                            <td valign="bottom" class="simple4alltext">
                                <?= $i ?></td>

                            <td valign="bottom" class="simple4alltext" align="center"> Fine Charge

                            </td>
                            <td align="right" valign="bottom" class="simple4alltext"><input   style="text-align:right;"  id="id1" class="sumamt" type="text" value="<?= $trxn->late_fee ?>" name="late_fee" ></td>

                        </tr><tr class="simple4alltext">
                            <td valign="bottom" class="simple4alltext">
                                <?= $i + 1 ?></td>

                            <td valign="bottom" class="simple4alltext" align="center"> Cal Fine Charge

                            </td>
                            <td align="right" valign="bottom" class="simple4alltext"><input  style="text-align:right;"   id="" class="" type="text" value="<?= $trxn->cal_late_fee ?>" name="cal_late_fee" ></td>

                        </tr> <tr class="simple4alltext">
                            <td valign="bottom" class="simple4alltext">
                                <?= $i + 2 ?></td>

                            <td valign="bottom" class="simple4alltext" align="center"> Extra Odinary Discount

                            </td>
                            <td align="right" valign="bottom" class="simple4alltext"><input type="text"   style="text-align:right;"   id="id2" class="subamt"  value="<?= $trxn->discount ?>" name="discount" ></td>

                        </tr>
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>    
                        <tr class="simplebold">

                            <td colspan="2"><b>Total</b></td>
                            <td  align="right"><lable class="total1" ><b><?= $ttl_fee ?></b></lable></td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ><hr></td>
                        </tr>
                        </tr>
                    </table>

                    <div class="row">
                        <div class="form-group"> 
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Tr Date<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <label align="center" ><input type="text" name="TrDate" value="<?= $trxn->tr_date; ?>" class="adm_date"/></label>
                                </div>


                            </div> <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Student ID<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" value="<?= $student_id; ?>" name="student_id" >
                                </div> 


                            </div> 
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"> 
                                        <label align="center" >Total Paying Amount <span class="text-red">*</span></label>
                                    </div>
                                    <div class="col-md-6 ">
                                        <lable class="total1" ><b><?= $ttl_fee ?></b></lable>
                                        <input type="hidden" value="<?= $ttl_fee ?>" name="paying_amt" id="paying_amt_id">
                                    </div>

                                </div>
                            </div><div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >DR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="dr" id="term">
                                        <?php
                                        if ($MSID != '1001')
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '1')->fetch(PDO::FETCH_OBJ);
                                            }
                                        else
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '23')->fetch(PDO::FETCH_OBJ);
                                            }
                                        ?>
                                        <option value="<?= $lesure->ledgers_id ?>">
                                            <?= $lesure->name ?>                                      </option>

                                    </select>
                                </div>


                            </div>
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >CR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="cr" id="term">

                                        <option value="3">
                                            Fees-N-Funds                                     </option>
                                    </select>
                                </div>


                            </div> 
                        </div>

                    </div>
                    <div class="row sub_btn">

                        <!--$oCurrentUser->MyUid =""-->
                        <?php
                        if (strchr($oCurrentUser->myuid, "vm1"))
                            {
                            $authenticted = 1;
                            }
                        else
                            {
                            $authenticted = 0;
                            }
//                print_r($trxn->status);
                        if ($trxn->status == 1 || $authenticted == 1)
                            {
                            ?><div class="col-md-3">
                                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                            </div>
                            <div class="col-md-3">
                                <a type="submit" id="delete_btn" name="rloaclsubmit" class="btn btn-lg btn-danger btn-block">Delete</a>
                            </div>
                        <?php } ?>
                        <?php $design_RFormDesigns = Student::student_designs($oCurrentSchool->FBKDesigns)->fetch(PDO::FETCH_OBJ); ?>                <div class="col-md-3"> <a href="<?= CLIENT_URL ?>/fee-book/<?= $design_RFormDesigns->cash_receipt ?>/<?= $student_id; ?>/month/<?php
                        if ($trxn->sr_no == '0')
                            {
                            echo "1";
                            }
                        else
                            {
                            echo $trxn->sr_no;
                            }
                        ?>/<?= $tr_id_no ?>/paywith_adjustment" type="submit"  target="_blank"  name="rloaclsubmit" class="btn btn-lg  btn-block" style="background-color:rgb(173,255,47);">Print Receipt</a>
                        </div>
                        <div class="col-md-3"> <a href="<?= CLIENT_URL ?>/fee-report-export/<?= $student_id; ?>/month/<?php
                            if ($trxn->sr_no == '0')
                                {
                                echo "1";
                                }
                            else
                                {
                                echo $trxn->sr_no;
                                }
                            ?>/<?= $tr_id_no ?>/paywith_adjustment" type="submit"  target="_blank"  name="rloaclsubmit" class="btn btn-lg  btn-block" style="background-color:rgb(173,255,47);">Export</a>
                        </div>

                        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                    </div></div>
            </form>
            <script>
                $(function () {
                    $('#delete_btn').click(function () {
                        swal({
                            title: "Are you sure?",
                            text: "You will not be able to recover this Account Details !",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "Yes, delete it!",
                            cancelButtonText: "No, cancel please!",
                            closeOnConfirm: false,
                            closeOnCancel: false
                        },
                                function (isConfirm) {
                                    if (isConfirm) {
                                        var r_id = $("#t_id").val();
                                        var param = 'r_id/' + r_id;
                                        jQuery.ajax({
                                            type: "POST",
                                            url: "<?= CLIENT_URL ?>/ajax-page-post/del/" + param,
                                            success: function (response) {
                                                responseText = $.trim(response);
                                                //                                                                                                                        alert(responseText);
                                                swal("Deleted!", "Your account details  has been deleted.", "success");
                                                location.reload();
                                                eModal.close();
                                            },
                                        });
                                    } else {
                                        swal("Cancelled", "Your account details are safe :)", "error");
                                    }
                                });
                    });
                    $(".subamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var sum = 0;
                        var ttl_paying = 0;
                        var sub = 0;
                        $(".sumamt").each(function () {
                            sum += +$(this).val();
                        });
                        $(".subamt").each(function () {
                            sub += +$(this).val();
                        });
                        var ttl = 0;
                        var late = $("#id1").val();
                        var extra = $("#id2").val();
                        ttl = parseInt(sum) - parseInt(extra) - parseInt(sub);
                        ttl_paying = parseInt(sum) - parseInt(late) - parseInt(sub);
                        //                    alert(ttl);
                        $("#paying_amt_id").val(ttl_paying);
                        $(".total1").text(ttl);
                    });
                    $(".sumamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var sum = 0;
                        var ttl_paying = 0;
                        var sub = 0;
                        $(".sumamt").each(function () {
                            sum += +$(this).val();
                        });
                        $(".subamt").each(function () {
                            sub += +$(this).val();
                        });
                        var ttl = 0;
                        var late = $("#id1").val();
                        var extra = $("#id2").val();
                        ttl = parseInt(sum) - parseInt(extra) - parseInt(sub);
                        ttl_paying = parseInt(sum) - parseInt(late) - parseInt(sub);
                        //                    alert(ttl);
                        $("#paying_amt_id").val(ttl_paying);
                        $(".total1").text(ttl);
                    });
                    $('.issue_datea').datepicker({
                        format: 'yyyy-mm-dd',
                        todayHighlight: true,
                        startDate: "$ses_str_dt",
                        endDate: "$ses_end_dt",
                        clearBtn: true
                    });
                    $('#ajaxSubmit').click(function () {
                        $('#ajaxForm .errorDiv').remove();
                        var datastring = $("#ajaxForm").serialize();
                        $("#process").show();
                        ///ajax code
                        $.ajax({
                            type: "POST", // type 
                            url: "<?= CLIENT_URL ?>/ajax-post", // r equest file
                            data: datastring, // post data
                            success: function (responseText) { // get the response
                                //                                                alert(responseText);
                                responseText = $.trim(responseText);

                                //alert(responseText);
                                //                        alert(responseText);
                                if (responseText != 'error') {
                                    location.reload();
                                    eModal.close();
                                    $(".sucess_msg").append('<div class="alert messages alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Fee Updated successfully!</p></div>');
                                } else {
                                    location.reload();
                                    eModal.close();
                                    $(".sucess_msg").append('<div class="alert messages alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Fee Not Updated </p></div>');
                                }
                                $("#process").hide();
                            }, // end success
                            error: function (jqXHR, textStatus, errorThrown) {
                                if (jqXHR.status == 500) {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                } else {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                }
                                $("#process").hide();
                            }
                        });
                        // end
                        return false;
                    });

                    $('.adm_date').datepicker({format: 'yyyy-mm-dd', todayHighlight: true});
                    $('.adm_date').on('changeDate', function (ev) {
                        $(this).datepicker('hide');
                    });
                });
            </script>
            <?php
            }
// --------------------------------Edit Paid Fee--------------------------------// 
        else if ($content == "fee_discout")
            {
            ?>
            <form acton="" method="post" name="add_fee_ajax_form" id="add_ajax_form">
                <span> Name</span> <input type="text" name="name" id="name" required="required"/> 
                <span> Amount</span> <input type="text" name="amt" id="amt" required="required"/>
                <input type="hidden" value="<?= $id ?>" id="id_to_pass">
                <input type="hidden" name="MSID" value="<?= $MSID ?>" id="MSID">
                <input type="button" name="add_fee_btn" value="Add Button"  class="btn btn-lg add_btn"/>
            </form>
            <script>
                $(document).ready(function ()
                {
                    $(".add_btn").click(function ()
                    {
                        var fee_name = $('#name').val();
                        var fee_amt = $('#amt').val();
                        var id_to_pass = $('#id_to_pass').val();
                        var MSID = $('#MSID').val();
                        var type = '2';

                        var datastring = 'fee_name=' + fee_name + '&fee_amt=' + fee_amt + '&id_to_pass=' + id_to_pass + '&type=' + type + '&MSID=' + MSID + '&add_new_discount=true';
                        //                alert(datastring);

                        $.ajax({
                            type: "POST", // type
                            url: "<?= CLIENT_URL ?>/ajax-post", // request file
                            data: datastring, // post data
                            success: function (responseText) { // get the response
                                //                                                alert(responseText);
                                //                        alert(responseText);
                                location.reload();
                                eModal.close();
                            }, // end success
                            error: function (jqXHR, textStatus, errorThrown) {
                                alert(errorThrown);
                                /*if (jqXHR.status == 500) {
                                 $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                 } else {
                                 $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                 }
                                 $("#process").hide();*/
                            }
                        });
                        // end
                        return false;

                    });
                });

            </script>
            <?php
            }
        else if ($content == "fee_add")
            {
            ?>
            <form acton="" method="post" name="add_fee_ajax_form" id="add_ajax_form">
                <span>Fee Name</span> <input type="text" name="name" id="name" required="required"/> 
                <span>Fee Amount</span> <input type="text" name="amt" id="amt" required="required"/>
                <input type="hidden" value="<?= $id ?>" id="id_to_pass">
                <input type="hidden" name="MSID" value="<?= $MSID ?>" id="MSID">
                <input type="button" name="add_fee_btn" value="Add Button"  class="btn btn-lg add_btn"/>
            </form>
            <script>
                $(document).ready(function ()
                {
                    $(".add_btn").click(function ()
                    {
                        var fee_name = $('#name').val();
                        var fee_amt = $('#amt').val();
                        var id_to_pass = $('#id_to_pass').val();
                        var MSID = $('#MSID').val();
                        var type = '1';

                        var datastring = 'fee_name=' + fee_name + '&fee_amt=' + fee_amt + '&id_to_pass=' + id_to_pass + '&type=' + type + '&MSID=' + MSID + '&add_new_fee=true';
                        //                alert(datastring);

                        $.ajax({
                            type: "POST", // type
                            url: "<?= CLIENT_URL ?>/ajax-post", // request file
                            data: datastring, // post data
                            success: function (responseText) { // get the response
                                //                                                alert(responseText);
                                //                                                alert(responseText);
                                location.reload();
                                eModal.close();
                            }, // end success
                            error: function (jqXHR, textStatus, errorThrown) {
                                alert(errorThrown);
                                /*if (jqXHR.status == 500) {
                                 $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                 } else {
                                 $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                 }
                                 $("#process").hide();*/
                            }
                        });
                        // end
                        return false;

                    });
                });

            </script>
            <?php
            }
        else if ($content == "fee_discount_headwise")
            {



            echo "<select name='fee_discount[]' style='border: 1px solid #000;'>
        ";
            $fee_discount = Fee::get_fee_names($MSID);
            while ($rowv = $fee_discount->fetch(PDO::FETCH_OBJ))
                {
                echo "<option value='" . $rowv->fee_id . "'>$rowv->fee_name</option>";
                }
            echo "</select>
    ";

            echo "<a href='javascript:void(0);' class='pop_up'>Add Discount</a>";
            exit();

            /* echo "<select name='fee_discount[]' style='border: 1px solid #000;'>
              ";
              $fee = Fee::get_fee_names($MSID);
              while ($rowv = $fee_discount->fetch(PDO::FETCH_OBJ)) {
              echo "<option value='" . $rowv->id . "'>$rowv->name</option>";
              }
              echo "</select>
              ";

              echo "<a href='javascript:void(0);' class='pop_up'><i>Add Discount</i></a>"; */
            }

// --------------------------------Fee Submit--------------------------------// 
        else if ($content == 'fee_submit_headwise')
            {
            $student_id = http_get("param2");
            $srno = http_get("param5");
            $due_date = http_get("param4");
            $dm = $oCurrentUser->mydate;

            $TrDate = date('Y-m-d', strtotime($dm));

            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
            $fee_dtl = Fee::get_Std_fee2($oCurrentUser->myuid, $student->acno);
//pr($fee_dtl);
//exit();
            $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
            ?>

            <form id="ajaxForm" method="post" action="" role="form"><input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <input type="hidden" name="add_fee_collection_headwise" value="true" />
                <input type="hidden" name="due_date" value="<?= $due_date ?>" />
                <input type="hidden" name="acno" value="<?= $student->acno ?>" /> 
                <input type="hidden" name="sr_no" value="<?= $srno ?>" />

                <input type="hidden" name="MSID" value="<?= $MSID ?>" />

                <div class="box-body">  
                    <div class="row">
                        <div class="col-md-12" align="center"> <b><?= $student->acno ?>&nbsp;<?= $student->name ?> Of <?= $student->class_name ?> Class <?php echo $student->gender == "M" ? "S/O" : "D/O"; ?> &nbsp;<?= $student->f_name ?> </b>
                        </div><div class="row"> <div class="col-md-12" align="center"> <b>&nbsp; of <?= $Village->name ?></b></div>

                        </div><div class="row">  <div class="col-md-8"></div>
                            <div class="col-md-4">Due Date    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;:&nbsp; <?= $due_date ?></div>
                        </div><div class="row">   <div class="col-md-8"></div>
                            <div class="col-md-4">Fee of Month : &nbsp;<?php echo date("M", strtotime($due_date)); ?></div>
                        </div><div class="row">    <div class="col-md-8"></div>

                        </div>
                    </div>


                    <table width="550" align="center" > 
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td width="86" class="simple" ><b>Sr. No.</b></td>
                            <td width="109" class="simple"  align="center"><b>Fee</b></td>
                            <td width="110" align="right" class="simple" ><b>Amount</b></td>

                        </tr> <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>
                        <?php
                        $ttl_count = $fee_dtl->rowCount();
                        if ($ttl_count > 0)
                            {
                            $i = 1;
                            $ttl_fee = 0;
                            while ($rowu = $fee_dtl->fetch())
                                {
//                        echo $rowu['type'];
                                $ttl_fee +=$rowu['ToPay'];
                                ?>

                                <?php
                                if ($rowu['FeeId'] < 0)
                                    {
                                    $name = $rowu['FeeName'];
                                    }
                                else
                                    {
                                    $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu['FeeId'])->fetch(PDO::FETCH_OBJ);

                                    $name = $fee->fee_name;
                                    }
                                if ($rowu['type'] == 1)
                                    {
                                    if ($rowu['ToPay'] != 0)
                                        {
                                        ?>  <tr class="simple4alltext">
                                            <td valign="bottom" class="simple4alltext">
                                                <?= $i ?></td><td valign="bottom" class="simple4alltext" align="center"> <?= $name ?>

                                            </td>
                                        <input type="hidden" value="<?= $rowu['FeeId']; ?>" name="fee_id[<?= $i; ?>]">
                                        <td align="right" valign="bottom" class="simple4alltext"><input style="text-align: right" class="sumamt" align="center"  value="<?php echo abs($rowu['ToPay']); ?>" id="<?= "id_" . $i ?>"name="fee[<?= $i; ?>]" ></td>
                                        </tr> 
                                        <?php
                                        }
                                    }
                                else if ($rowu['type'] == 2)
                                    {
                                    if ($rowu['ToPay'] != 0)
                                        {
                                        ?>
                                        <tr class="simple4alltext">
                                            <td valign="bottom" class="simple4alltext">
                                                <?= $i ?></td><td valign="bottom" class="simple4alltext" align="center"> <?= $name ?>

                                            </td>
                                        <input type="hidden" value="<?= $rowu['FeeId']; ?>" name="fee_id[<?= $i; ?>]">
                                        <td align="right" valign="bottom" class="simple4alltext"><input  class="subamt" style="text-align: right ;background-color:Black ; color:Lime; "  align="center"  value="<?php echo abs($rowu['ToPay']); ?>" id="<?= "id_" . $i ?>"name="fee[<?= $i; ?>]" ></td>
                                        </tr> 
                                        <?php
                                        }
                                    }
                                else
                                    {
                                    ?>
                                    <tr class="simple4alltext">
                                        <td valign="bottom" class="simple4alltext">
                                            <?= $i ?></td> <td valign="bottom" class="simple4alltext" align="center"> <?= $name ?>

                                        </td>
                                    <input type="hidden" value="<?= $fee->fee_id; ?>" name="fee_id[<?= $i; ?>]">
                                    <td align="right" valign="bottom" class="simple4alltext"><input  class="sumamt" align="center" style="text-align: right" value="<?php echo round($rowu['ToPay']); ?>" id="<?= "id_" . $i ?>"name="fee[<?= $i; ?>]" ></td>
                                    </tr> 
                                    <?php
                                    }
                                ?>


                                <?php
                                $i++;
                                }
                            ?> <tr class="simple4alltext">
                                <td valign="bottom" class="simple4alltext">
                                    <?= $i ?></td>

                                <td valign="bottom" class="simple4alltext" align="center"> Fine Charge

                                </td>
                                <td align="right" valign="bottom" class="simple4alltext"><input  style="text-align: right" id="id1" class="sumamt" type="text" value="0" name="late_fee" ></td>

                            </tr> <tr class="simple4alltext">
                                <td valign="bottom" class="simple4alltext">
                                    <?= $i + 1 ?></td>

                                <td valign="bottom" class="simple4alltext" align="center"> Extra Odinary Discount

                                </td>
                                <td align="right" valign="bottom" class="simple4alltext"><input style="text-align: right" type="text"  id="id2" class="subamt"  value="0" name="discount" ></td>

                            </tr><?php } ?>
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>    
                        <tr class="simplebold">
                            <?php
                            if (@$ttl_fee)
                                {
                                
                                }
                            else
                                {
                                $ttl_fee = 0;
                                }
                            ?>
                            <td colspan="2"><b>Total</b></td>
                            <td  align="right"><lable class="total1" ><b><?= $ttl_fee ?></b></lable></td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ><hr></td>
                        </tr>
                        </tr>
                    </table>

                    <div class="row">
                        <div class="form-group"> 
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Tr Date<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <label align="center" ><input type="text" name="TrDate" value="<?= $TrDate; ?>" class="adm_date"/></label>
                                </div>


                            </div> <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Student ID<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" value="<?= $student_id; ?>" name="student_id" >
                                </div> 


                            </div> 
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"> 
                                        <label align="center" >Total Paying Amount <span class="text-red">*</span></label>
                                    </div>
                                    <div class="col-md-6 ">
                                        <lable class="total1" ><b><?= $ttl_fee ?></b></lable>
                                        <input type="hidden" value="<?= $ttl_fee ?>" name="paying_amt" id="paying_amt_id">
                                    </div>

                                </div>
                            </div><div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >DR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="dr" id="term">
                                        <?php
                                        if ($MSID != '1001')
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '1')->fetch(PDO::FETCH_OBJ);
                                            }
                                        else
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '23')->fetch(PDO::FETCH_OBJ);
                                            }
                                        ?>
                                        <option value="<?= $lesure->ledgers_id ?>">
                                            <?= $lesure->name ?>                                      </option>

                                    </select>
                                </div>


                            </div>
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >CR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="cr" id="term">

                                        <option value="3">
                                            Fees-N-Funds                                     </option>
                                    </select>
                                </div>


                            </div> 
                        </div>

                    </div>
                    <?php
                    if ($ttl_count > 0)
                        {
                        ?> <div class="row sub_btn">
                            <div class="col-md-3">
                                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                            </div>
                            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                        </div>
                    <?php } ?></div>
            </form>

            <script>
                $(function () {



                    $(".subamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var sum = 0;
                        var sub = 0;
                        var ttl_paying = 0;
                        $(".sumamt").each(function () {
                            sum += +$(this).val();
                        });
                        $(".subamt").each(function () {
                            sub += +$(this).val();
                        });
                        var ttl = 0;
                        var late = $("#id1").val();
                        var extra = $("#id2").val();
                        ttl = parseInt(sum) - parseInt(extra) - parseInt(sub);
                        ttl_paying = parseInt(sum) - parseInt(late) - parseInt(sub);
                        //                    alert(ttl);
                        $("#paying_amt_id").val(ttl_paying);
                        $(".total1").text(ttl);
                    });
                    $(".sumamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var sum = 0;
                        var sub = 0;
                        var ttl_paying = 0;
                        $(".sumamt").each(function () {
                            sum += +$(this).val();
                        });
                        $(".subamt").each(function () {
                            sub += +$(this).val();
                        });
                        var ttl = 0;
                        var late = $("#id1").val();
                        var extra = $("#id2").val();
                        ttl = parseInt(sum) - parseInt(extra) - parseInt(sub);
                        ttl_paying = parseInt(sum) - parseInt(late) - parseInt(sub);
                        //                    alert(ttl);
                        $("#paying_amt_id").val(ttl_paying);
                        $(".total1").text(ttl);
                    });
                    $('.issue_datea').datepicker({
                        format: 'yyyy-mm-dd',
                        todayHighlight: true,
                        startDate: "$ses_str_dt",
                        endDate: "$ses_end_dt",
                        clearBtn: true
                    });
                    $('#ajaxSubmit').click(function () {
                        $('#ajaxForm .errorDiv').remove();
                        var datastring = $("#ajaxForm").serialize();
                        $("#process").show();
                        ///ajax code
                        $.ajax({
                            type: "POST", // type 
                            url: "<?= CLIENT_URL ?>/ajax-post", // r equest file
                            data: datastring, // post data
                            success: function (responseText) { // get the response
                                //                                                alert(responseText);
                                responseText = $.trim(responseText);
    //                                                            alert(responseText);
                                if (responseText != 'error') {
                                    location.reload();
                                    eModal.close();
                                    $(".sucess_msg").append('<div class="alert messages alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Fee Submited successfully!</p></div>');
                                } else {
                                    location.reload();
                                    eModal.close();
                                    $(".sucess_msg").append('<div class="alert messages alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Duplicate Entry Not Allowded!</p></div>');
                                }
                                $("#process").hide();
                            }, // end success
                            error: function (jqXHR, textStatus, errorThrown) {
                                if (jqXHR.status == 500) {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                } else {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                }
                                $("#process").hide();
                            }
                        });
                        // end
                        return false;
                    });

                    $('.adm_date').datepicker({format: 'yyyy-mm-dd', todayHighlight: true});
                    $('.adm_date').on('changeDate', function (ev) {
                        $(this).datepicker('hide');
                    });
                });
            </script>
            <?php
            }
        else if ($content == 'fee_submit')
            {
            $student_id = http_get("param2");
            $srno = http_get("param5");
            $due_date = http_get("param4");
            $dm = $oCurrentUser->mydate;

            $TrDate = date('Y-m-d', strtotime($dm));
            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
            $fee_dtl = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->acno, $srno, 'FALSE', 'True');

//print_r($student);
            $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
            ?>

            <form id="ajaxForm" method="post" action="" role="form"><input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <input type="hidden" name="add_fee_collection" value="true" />
                <input type="hidden" name="due_date" value="<?= $due_date ?>" />
                <input type="hidden" name="acno" value="<?= $student->acno ?>" /> 
                <input type="hidden" name="sr_no" value="<?= $srno ?>" />
                <input type="hidden" name="MSID" value="<?= $MSID ?>" />

                <div class="box-body">  
                    <div class="row">
                        <div class="col-md-12" align="center"> <b><?= $student->acno ?>&nbsp;<?= $student->name ?> Of <?= $student->class_name ?> Class <?php echo $student->gender == "M" ? "S/O" : "D/O"; ?> &nbsp;<?= $student->f_name ?> </b>
                        </div><div class="row"> <div class="col-md-12" align="center"> <b>&nbsp; of <?= $Village->name ?></b></div>

                        </div><div class="row">  <div class="col-md-8"></div>
                            <div class="col-md-4">Due Date    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;:&nbsp; <?= $due_date ?></div>
                        </div><div class="row">   <div class="col-md-8"></div>
                            <div class="col-md-4">Fee of Month : &nbsp;<?php echo date("M", strtotime($due_date)); ?></div>
                        </div><div class="row">    <div class="col-md-8"></div>

                        </div>
                    </div>
                    <?php
                    $ttl_fee = 0;
                    while ($rowu = $fee_dtl->fetch())
                        {
                        $ttl_fee +=$rowu['FeeAmt'];
                        }
                    ?>
                    <div class="row">
                        <div class="form-group"> 
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Tr Date<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <label align="center" ><?= $TrDate; ?></label>
                                     <!--<input type="text"  class="issue_datea" value="<?= $TrDate; ?>" name="TrDate" >-->
                                </div>


                            </div> <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Student ID<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" value="<?= $student_id; ?>" name="student_id" >
                                </div> 


                            </div> <div class="row">    

                                <div class="col-md-6" > 
                                    <label align="center" >Total Amount <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" class="ttl_amt"   value="<?= $ttl_fee; ?>" name="ttl_fee" >   
                                </div>


                            </div><div class="row">    

                                <div class="col-md-6" > 
                                    <label align="center" >Late Fee <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" class="sumamt"   id="id_fine"  value="0" name="late_fee" >   
                                </div>


                            </div><div class="row">    

                                <div class="col-md-6" > 
                                    <label align="center" > Discount  <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 "> 
                                    <input type="text" class="subamt"   id="id1" value="0" name="discount" >   
                                </div>


                            </div><div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"> 
                                        <label align="center" >Total Paying Amount <span class="text-red">*</span></label>
                                    </div>
                                    <div class="col-md-6 ">
                                        <lable type="text"    id="idttl" ><?= $ttl_fee; ?></lable>   
                                    </div>

                                </div>
                            </div><div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >DR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="dr" id="term">
                                        <?php
                                        if ($MSID != '1001')
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '1')->fetch(PDO::FETCH_OBJ);
                                            }
                                        else
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '23')->fetch(PDO::FETCH_OBJ);
                                            }
                                        ?>
                                        <option value="<?= $lesure->id ?>">
                                            <?= $lesure->name ?>                                      </option>

                                    </select>
                                </div>


                            </div>
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >CR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="cr" id="term">

                                        <option value="3">
                                            Fees-N-Funds                                     </option>
                                    </select>
                                </div>


                            </div> 
                        </div>

                    </div>
                    <div class="row error_div"  display="none"  >
                        <p class="text-red"  >Paying amount exceades the Total amount</p>
                    </div>
                    <div class="row sub_btn">
                        <div class="col-md-3">
                            <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                        </div>

                        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                    </div></div>
            </form>

            <script>
                $(function () {
                    //   $(".sub_btn").hide(); 
                    $(".error_div").hide();
                    $(".sumamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var fine = $(this).val();
                        var extra = $("#id1").val();
                        var ttl = 0;
                        ttl = parseInt(ttl_amt) + parseInt(fine) - parseInt(extra);
                        //                alert(ttl);
                        $("#idttl").text(ttl);
                    });
                    $(".subamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var fine = $("#id_fine").val();
                        var extra = $("#id1").val();
                        var ttl = 0;
                        ttl = parseInt(ttl_amt) + parseInt(fine) - parseInt(extra);
                        //                alert(ttl);
                        $("#idttl").text(ttl);
                    });
                    $('.issue_datea').datepicker({
                        format: 'yyyy-mm-dd',
                        todayHighlight: true,
                        startDate: "$ses_str_dt",
                        endDate: "$ses_end_dt",
                        clearBtn: true
                    });
                    $('#ajaxSubmit').click(function () {
                        $('#ajaxForm .errorDiv').remove();
                        var datastring = $("#ajaxForm").serialize();
                        $("#process").show();
                        ///ajax code
                        $.ajax({
                            type: "POST", // type 
                            url: "<?= CLIENT_URL ?>/ajax-post", // r equest file
                            data: datastring, // post data
                            success: function (responseText) { // get the response
                                //                                                alert(responseText);
                                responseText = $.trim(responseText);
                                //                                                        alert(responseText);
                                if (responseText != 'error') {
                                    $(".sucess_msg").append('<div class="alert messages alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Fee Submited successfully!</p></div>');
                                    location.reload();
                                    eModal.close();
                                } else {
                                    $(".sucess_msg").append('<div class="alert messages alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Duplicate Entry Not allowed !</p></div>');
                                    location.reload();
                                    eModal.close();
                                }
                                $("#process").hide();
                            }, // end success
                            error: function (jqXHR, textStatus, errorThrown) {
                                if (jqXHR.status == 500) {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                } else {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                }
                                $("#process").hide();
                            }
                        });
                        // end
                        return false;
                    });
                });
            </script>
            <?php
            }

// for late fee submit                         
        else if ($content == 'fee_submit_headwise_with_late_fee')
            {
            $student_id = http_get("param2");
            $srno = http_get("param5");
            $due_date = http_get("param4");
            $dm = $oCurrentUser->mydate;

            $TrDate = date('Y-m-d', strtotime($dm));

            $student = Student::get_students($oCurrentUser->myuid, '', $student_id)->fetch(PDO::FETCH_OBJ);
//            $fee_dtl = Fee::get_Std_fee2($oCurrentUser->myuid, $student->acno);
            $fee_dtl = Fee::get_Std_fee($MSID, $oCurrentUser->mysession, $student->acno, $srno, 'FALSE', 'True');

            $Village = Master::get_locality($MSID, $student->vilage_id)->fetch(PDO::FETCH_OBJ);
            ?>

            <form id="ajaxForm" method="post" action="" role="form"><input type="hidden" name="MSID" value="<?= $MSID ?>" />
                <input type="hidden" name="add_fee_collection_headwise" value="true" />
                <input type="hidden" name="due_date" value="<?= $due_date ?>" />
                <input type="hidden" name="acno" value="<?= $student->acno ?>" /> 
                <input type="hidden" name="sr_no" value="<?= $srno ?>" />

                <input type="hidden" name="MSID" value="<?= $MSID ?>" />

                <div class="box-body">  
                    <div class="row">
                        <div class="col-md-12" align="center"> <b><?= $student->acno ?>&nbsp;<?= $student->name ?> Of <?= $student->class_name ?> Class <?php echo $student->gender == "M" ? "S/O" : "D/O"; ?> &nbsp;<?= $student->f_name ?> </b>
                        </div><div class="row"> <div class="col-md-12" align="center"> <b>&nbsp; of <?= $Village->name ?></b></div>

                        </div><div class="row">  <div class="col-md-8"></div>
                            <div class="col-md-4">Due Date    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;:&nbsp; <?= $due_date ?></div>
                        </div><div class="row">   <div class="col-md-8"></div>
                            <div class="col-md-4">Fee of Month : &nbsp;<?php echo date("M", strtotime($due_date)); ?></div>
                        </div><div class="row">    <div class="col-md-8"></div>

                        </div>
                    </div>


                    <table width="550" align="center" > 
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td width="86" class="simple" ><b>Sr. No.</b></td>
                            <td width="109" class="simple"  align="center"><b>Fee</b></td>
                            <td width="110" align="right" class="simple" ><b>Amount</b></td>

                        </tr> <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>
                        <?php
                        $ttl_count = $fee_dtl->rowCount();
                        if ($ttl_count > 0)
                            {
                            $i = 1;
                            $ttl_fee = 0;
                            while ($rowu = $fee_dtl->fetch())
                                {
//            pr($rowu);
//                        echo $rowu['type'];
                                $ttl_fee +=$rowu['FeeAmt'];
                                ?>

                                <?php
                                if ($rowu['FeeId'] < 0)
                                    {
                                    $name = $rowu['FeeName'];
                                    }
                                else
                                    {
                                    $fee = Fee::get_fee_names($MSID, '', 'all', '', $rowu['FeeId'])->fetch(PDO::FETCH_OBJ);

                                    $name = $fee->fee_name;
                                    }
                                if ($rowu['type'] == 1)
                                    {
                                    if ($rowu['FeeAmt'] != 0)
                                        {
                                        ?>  <tr class="simple4alltext">
                                            <td valign="bottom" class="simple4alltext">
                                                <?= $i ?></td><td valign="bottom" class="simple4alltext" align="center"> <?= $name ?>

                                            </td>
                                        <input type="hidden" value="<?= $rowu['FeeId']; ?>" name="fee_id[<?= $i; ?>]">
                                        <td align="right" valign="bottom" class="simple4alltext"><input style="text-align: right" class="sumamt" align="center"  value="<?php echo abs($rowu['FeeAmt']); ?>" id="<?= "id_" . $i ?>"name="fee[<?= $i; ?>]" ></td>
                                        </tr> 
                                        <?php
                                        }
                                    }
                                else if ($rowu['type'] == 2)
                                    {
                                    if ($rowu['FeeAmt'] != 0)
                                        {
                                        ?>
                                        <tr class="simple4alltext">
                                            <td valign="bottom" class="simple4alltext">
                                                <?= $i ?></td><td valign="bottom" class="simple4alltext" align="center"> <?= $name ?>

                                            </td>
                                        <input type="hidden" value="<?= $rowu['FeeId']; ?>" name="fee_id[<?= $i; ?>]">
                                        <td align="right" valign="bottom" class="simple4alltext"><input  class="subamt" style="text-align: right ;background-color:Black ; color:Lime; "  align="center"  value="<?php echo abs($rowu['FeeAmt']); ?>" id="<?= "id_" . $i ?>"name="fee[<?= $i; ?>]" ></td>
                                        </tr> 
                                        <?php
                                        }
                                    }
                                else
                                    {
                                    ?>
                                    <tr class="simple4alltext">
                                        <td valign="bottom" class="simple4alltext">
                                            <?= $i ?></td> <td valign="bottom" class="simple4alltext" align="center"> <?= $name ?>

                                        </td>
                                    <input type="hidden" value="<?= $fee->fee_id; ?>" name="fee_id[<?= $i; ?>]">
                                    <td align="right" valign="bottom" class="simple4alltext"><input  class="sumamt" align="center" style="text-align: right" value="<?php echo round($rowu['FeeAmt']); ?>" id="<?= "id_" . $i ?>"name="fee[<?= $i; ?>]" ></td>
                                    </tr> 
                                    <?php
                                    }
                                ?>


                                <?php
                                $i++;
                                }
                            ?> <tr class="simple4alltext">
                                <td valign="bottom" class="simple4alltext">
                                    <?= $i ?></td>

                                <td valign="bottom" class="simple4alltext" align="center"> Fine Charge

                                </td>
                                <td align="right" valign="bottom" class="simple4alltext"><input  style="text-align: right" id="id1" class="sumamt" type="text" value="0" name="late_fee" ></td>

                            </tr> <tr class="simple4alltext">
                                <td valign="bottom" class="simple4alltext">
                                    <?= $i + 1 ?></td>

                                <td valign="bottom" class="simple4alltext" align="center"> Extra Odinary Discount

                                </td>
                                <td align="right" valign="bottom" class="simple4alltext"><input style="text-align: right" type="text"  id="id2" class="subamt"  value="0" name="discount" ></td>

                            </tr><?php } ?>
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ></td>
                        </tr>    
                        <tr class="simplebold">
                            <?php
                            if (@$ttl_fee)
                                {
                                
                                }
                            else
                                {
                                $ttl_fee = 0;
                                }
                            ?>
                            <td colspan="2"><b>Total</b></td>
                            <td  align="right"><lable class="total1" ><b><?= $ttl_fee ?></b></lable></td>
                        </tr>
                        <tr valign="top" class="simple">
                            <td colspan="3" align="center" class="simplebold" ><hr></td>
                        </tr>
                        </tr>
                    </table>

                    <div class="row">
                        <div class="form-group"> 
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Tr Date<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <label align="center" ><input type="text" name="TrDate" value="<?= $TrDate; ?>" class="adm_date"/></label>
                                </div>


                            </div> <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >Student ID<span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <input type="text" value="<?= $student_id; ?>" name="student_id" >
                                </div> 


                            </div> 
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-6"> 
                                        <label align="center" >Total Paying Amount <span class="text-red">*</span></label>
                                    </div>
                                    <div class="col-md-6 ">
                                        <lable class="total1" ><b><?= $ttl_fee ?></b></lable>
                                        <input type="hidden" value="<?= $ttl_fee ?>" name="paying_amt" id="paying_amt_id">
                                    </div>

                                </div>
                            </div><div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >DR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="dr" id="term">
                                        <?php
                                        if ($MSID != '1001')
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '1')->fetch(PDO::FETCH_OBJ);
                                            }
                                        else
                                            {
                                            $lesure = Fee::get_ledgers($MSID, '23')->fetch(PDO::FETCH_OBJ);
                                            }
                                        ?>
                                        <option value="<?= $lesure->ledgers_id ?>">
                                            <?= $lesure->name ?>                                      </option>

                                    </select>
                                </div>


                            </div>
                            <div class="row">

                                <div class="col-md-6"> 
                                    <label align="center" >CR <span class="text-red">*</span></label>
                                </div>
                                <div class="col-md-6 ">
                                    <select class="form-control " name="cr" id="term">

                                        <option value="3">
                                            Fees-N-Funds                                     </option>
                                    </select>
                                </div>


                            </div> 
                        </div>

                    </div>
                    <?php
                    if ($ttl_count > 0)
                        {
                        ?> <div class="row sub_btn">
                            <div class="col-md-3">
                                <button type="submit" id="ajaxSubmit" name="rloaclsubmit" class="btn btn-lg btn-success btn-block">Submit</button>
                            </div>
                            <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
                        </div>
                    <?php } ?></div>
            </form>

            <script>
                $(function () {



                    $(".subamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var sum = 0;
                        var sub = 0;
                        var ttl_paying = 0;
                        $(".sumamt").each(function () {
                            sum += +$(this).val();
                        });
                        $(".subamt").each(function () {
                            sub += +$(this).val();
                        });
                        var ttl = 0;
                        var late = $("#id1").val();
                        var extra = $("#id2").val();
                        ttl = parseInt(sum) - parseInt(extra) - parseInt(sub);
                        ttl_paying = parseInt(sum) - parseInt(late) - parseInt(sub);
                        //                    alert(ttl);
                        $("#paying_amt_id").val(ttl_paying);
                        $(".total1").text(ttl);
                    });
                    $(".sumamt").change(function () {
                        var ttl_amt = $(".ttl_amt").val();
                        var sum = 0;
                        var sub = 0;
                        var ttl_paying = 0;
                        $(".sumamt").each(function () {
                            sum += +$(this).val();
                        });
                        $(".subamt").each(function () {
                            sub += +$(this).val();
                        });
                        var ttl = 0;
                        var late = $("#id1").val();
                        var extra = $("#id2").val();
                        ttl = parseInt(sum) - parseInt(extra) - parseInt(sub);
                        ttl_paying = parseInt(sum) - parseInt(late) - parseInt(sub);
                        //                    alert(ttl);
                        $("#paying_amt_id").val(ttl_paying);
                        $(".total1").text(ttl);
                    });
                    $('.issue_datea').datepicker({
                        format: 'yyyy-mm-dd',
                        todayHighlight: true,
                        startDate: "$ses_str_dt",
                        endDate: "$ses_end_dt",
                        clearBtn: true
                    });
                    $('#ajaxSubmit').click(function () {
                        $('#ajaxForm .errorDiv').remove();
                        var datastring = $("#ajaxForm").serialize();
                        $("#process").show();
                        ///ajax code
                        $.ajax({
                            type: "POST", // type 
                            url: "<?= CLIENT_URL ?>/ajax-post", // r equest file
                            data: datastring, // post data
                            success: function (responseText) { // get the response
                                //                                                alert(responseText);
                                responseText = $.trim(responseText);
    //                                                            alert(responseText);
                                if (responseText != 'error') {
                                    location.reload();
                                    eModal.close();
                                    $(".sucess_msg").append('<div class="alert messages alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Fee Submited successfully!</p></div>');
                                } else {
                                    location.reload();
                                    eModal.close();
                                    $(".sucess_msg").append('<div class="alert messages alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button><p>Duplicate Entry Not Allowded!</p></div>');
                                }
                                $("#process").hide();
                            }, // end success
                            error: function (jqXHR, textStatus, errorThrown) {
                                if (jqXHR.status == 500) {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                                } else {
                                    $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                                }
                                $("#process").hide();
                            }
                        });
                        // end
                        return false;
                    });

                    $('.adm_date').datepicker({format: 'yyyy-mm-dd', todayHighlight: true});
                    $('.adm_date').on('changeDate', function (ev) {
                        $(this).datepicker('hide');
                    });
                });
            </script>
            <?php
            }

// --------------------------------Fee Submit--------------------------------// 
        ?>     