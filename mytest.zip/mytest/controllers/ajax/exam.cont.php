<?php
# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");

/*
 * this part used for enrolled form page to list/select existing parents
 */

if ($content == 'exam_select')
    {

    $class_id = $_POST['classid'];

    // $activityes = Master::get_activetyes_list($MSID)->fetchAll(PDO::FETCH_ASSOC);

    $assesments = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), $class_id)->fetchAll(PDO::FETCH_ASSOC);

    $subjects = SuperAdmin::get_schoolwise_subject($MSID, '', array('selectAll' => 'true'), $class_id, '', 'YES')->fetchAll(PDO::FETCH_OBJ);
    ?>
    <div id="show_content_div">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group" id="display_assess">
                    <label>Assesment</label>
                    <select id="assesment_ajax" name="assesment" class="form-control  " >
                        <option value="all"  selected = "selected" >
                            All Assesment
                        </option> 
                        <?php
                        foreach ($assesments as $assesment)
                            {
                            ?>
                            <option value="<?= $assesment['assesment_id']; ?>">
                                <?= $assesment['title']; ?>
                            </option>
                        <?php } ?>

                    </select>

                </div></div></div>                
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Subjects</label>
                    <select id="subjects_ajax" name="sub_id" class="form-control " >
                        <?php
                        $i = 0;
                        ?>   
                        <option value="all"  selected = "selected" >
                            All Subjects
                        </option> 
                        <?php
                        foreach ($subjects as $subject)
                            {
                            if ($selected_subjects == $subject->subject_id)
                                {
                                $selected = 'selected = "selected"';
                                }
                            else
                                {
                                $selected = "";
                                }
                            ?>
                            <option value="<?= $subject->subject_id; ?>" <?= $selected ?> >
                                <?= $subject->name ?>
                            </option>
                            <?php
                            $i++;
                            }
                        ?>


                    </select>   
                </div></div></div>  
    </div>

    <?php
    }
else if ($content == 'update_activities')
    {
    $activities = Master::get_activetyes_list($MSID, $id)->fetch(PDO::FETCH_ASSOC);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_activities" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Name<span class="text-red">*</span></label>
                        <input type="text" name="name" value="<?= $activities['name'] ?>"size="30" class="form-control">
                    </div>
                </div>
                <!-- \col -->
            </div>
        </div>


        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/exam-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                                                alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'update_assign_activities')
    { //used in fee type and fee group page
    $assigned_activity = Master::get_activetyes_assigned($MSID, $id)->fetch(PDO::FETCH_ASSOC);
//    print_r($assigned_activity);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_assign_activities" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="row">
            <div class="col-md-12"><div class="row">
                    <div class="col-md-12">

                        <div class="form-group">
                            <label>Activities<span class="text-red">*</span></label>
                            <select name="activity_id" class="class_check form-control">
                                <option value="">Select</option>
                                <?php
                                $activitits = Master::get_activetyes_list($MSID)->fetchAll(PDO::FETCH_ASSOC);
                                ?>
                                <?php
                                foreach ($activitits as $activitit)
                                    {
                                    if ($activitit['id'] == $assigned_activity['activity_id'])
                                        {
                                        $selected = 'selected= "selected"';
                                        }
                                    else
                                        {
                                        $selected = '';
                                        }
                                    echo '<option value="' . $activitit['id'] . '"' . $selected . '>' . $activitit['name'] . '</option>';
                                    }
                                ?>
                            </select>
                        </div>  

                        <div class="input-group">
                            <span class="input-group-addon">
                                <input type="checkbox" class="checkbox"  id="selectall4"> 
                            </span>
                            <label class="form-control" for="exampleInputName2">Classes</label>
                        </div>
                        <?php
                        $selected_classes = explode(',', $assigned_activity['class']);
                        $get_classes = Master::get_classes($MSID);

                        while ($rowv = $get_classes->fetch(PDO::FETCH_ASSOC))
                            {
                            ?><div class="col-md-4"><input type="checkbox"  class="checkbox1" value="<?= $rowv['class_no']; ?>" name="for_class[]" <?php
                            echo (in_array($rowv['class_no'], $selected_classes)) ? 'checked="checked"' : '';
                            ?>> <?= $rowv['class_name']; ?></div>

                            <?php
                            }
                        ?><br>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <input type="checkbox" class="checkbox"  id="selectall5"> 
                            </span>
                            <label class="form-control" for="exampleInputName2">Assesments</label>
                        </div>
                        <?php
                        $selected_assesment = explode(',', $assigned_activity['assesment_id']);

                        $get_assesment = Exam::get_exam_assesments($MSID, '', array('selectAll' => 'true'), '', '', '', '', 'YES');
                        while ($rowv = $get_assesment->fetch(PDO::FETCH_ASSOC))
                            {
                            ?><div class="col-md-4"><input type="checkbox"  class="checkbox2" value="<?= $rowv['assesment_id']; ?>" name="assesments[]" <?php
                            echo (in_array($rowv['assesment_id'], $selected_assesment)) ? 'checked="checked"' : '';
                            ?>> <?= $rowv['title']; ?></div>

                            <?php
                            }
                        ?><br>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <input type="checkbox" class="checkbox"  id="selectall6"> 
                            </span>
                            <label class="form-control" for="exampleInputName2">Subjects</label>
                        </div>
                        <?php
                        $selected_subject = explode(',', $assigned_activity['subject_id']);

                        $get_subjects = SuperAdmin::get_schoolwise_subject($MSID, '', array('selectAll' => 'true'), '', '', 'YES');
                        while ($rowv = $get_subjects->fetch(PDO::FETCH_ASSOC))
                            {
                            ?><div class="col-md-4"><input type="checkbox"  class="checkbox3" value="<?= $rowv['subject_id']; ?>" name="subjects[]" <?php
                            echo (in_array($rowv['subject_id'], $selected_subject)) ? 'checked="checked"' : '';
                            ?>> <?= $rowv['name']; ?></div>

                            <?php
                            }
                        ?>




                    </div>
                    <!-- \col -->
                </div>
            </div>
            <!-- \col -->
        </div>
    </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {
            $('#selectall4').click(function (event) {
                //                alert('ds');
                if (this.checked) {
                    $('.checkbox1').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox1').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#selectall5').click(function (event) {
                if (this.checked) {
                    $('.checkbox2').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox2').each(function () {
                        this.checked = false;
                    });
                }
            });
            $('#selectall6').click(function (event) {
                if (this.checked) {
                    $('.checkbox3').each(function () {
                        this.checked = true;
                    });
                } else {
                    $('.checkbox3').each(function () {
                        this.checked = false;
                    });
                }
            });

            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();
                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/exam-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                                                alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'section_select')
    {
    $sAdmission = new Admission();
    $classsections = Master::get_schools_section($MSID, '', $_POST['classid']);
    ?>

    <?php
    if ($classsections->rowCount() > 0 && $oCurrentSchool->section != '0')
        {
        ?>  <div class="form-group">
            <label>Select section</label>
            <select id="section_id1" name="section" class="form-control "   required>

                <?php
                while ($rowv = $classsections->fetch())
                    {
                    ?>
                    <option value="<?= $rowv['id']; ?>"><?= $rowv['display_name'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; " . "&nbsp;&nbsp;"; ?></option>
                <?php } ?>  
            </select>

            <?php
            }
        else
            {
            ?>
            <input type="hidden" value="0" id="section_id1" >
            <?php
            }
        }
    else if ($content == 'failed_students')
        { //used in fee type and fee group page
        $exam_std = Exam::get_failed_students($MSID, $id, '-1', array('selectAll' => 'true'), $oCurrentUser->begins, $oCurrentUser->ends)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_grade);
        ?>
        <form id="ajaxForm" method="post" action="" role="form">
            <input type="hidden" name="update_failed_students" value="true" />
            <input type="hidden" name="id" value="<?= $id ?>" />
            <input type="hidden" name="MSID" value="<?= $MSID ?>" />
            <?php ?>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Student Id</label>
                            <input class="form-control" value="<?= $exam_std['s_id'] ?>" type="text" name="s_id" placeholder=""/>
                        </div>
                    </div>
                    <!-- \col --> 
                </div>
                <div class="form-group ">
                    <label  for="exampleInputName2">Result Date:</label>
                    <div class="input-group ">
                        <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>

                        <input type="text" name="date_result" placeholder="<?= $exam_std['date_result'] ?>" id="date_result" value="<?= $exam_std['date_result'] ?>" class="form-control failed_date_update"/>
                    </div>

                </div>




        </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {



            $('.failed_date_update').datepicker({
                format: 'yyyy-mm-dd',
                todayHighlight: true,
                clearBtn: true
            });

            $('.failed_date_update').on('changeDate', function (ev) {
                $(this).datepicker('hide');
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/exam-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'promoted_students')
    { //used in fee type and fee group page
    $exam_std = Exam::get_failed_students($MSID, $id, '', array('selectAll' => 'true'), $oCurrentUser->begins, $oCurrentUser->ends)->fetch(PDO::FETCH_ASSOC);
//        print_r($exam_std);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_failed_students" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Student Id</label>
                        <input class="form-control" value="<?= $exam_std['s_id'] ?>" type="text" name="s_id" placeholder=""/>
                    </div>
                </div>
                <!-- \col --> 
            </div>
            <div class="form-group ">
                <label  for="exampleInputName2">Result Date:</label>
                <div class="input-group ">
                    <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>

                    <input type="text" name="date_result" placeholder="<?= $exam_std['date_result'] ?>" id="date_result" value="<?= $exam_std['date_result'] ?>" class="form-control failed_date_update"/>
                </div>

            </div>




    </form>
    </div>


    <div class="form-group">
        <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
    </div>
    <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </div>
    </form>

    <script>
        $(function () {



            $('.failed_date_update').datepicker({
                format: 'yyyy-mm-dd',
                todayHighlight: true,
                clearBtn: true
            });

            $('.failed_date_update').on('changeDate', function (ev) {
                $(this).datepicker('hide');
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/exam-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
    }
else if ($content == 'exam_co_scholastic_marks')
    {
    //print_r($oCurrentSchool);

    $class_id = http_get("param3");

    $term = http_get("param4");


    $exam_co_scholastic_areas = Exam::get_exam_co_scholastic_areas($MSID, '', array('selectAll' => 'true'), $class_id);

//    print_r($exam_co_scholastic_areas);

    $totalrecords = $exam_co_scholastic_areas->rowCount();
//        print_r($exam_grade);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="add_exam_co_scholastic_marks" value="true" />

        <input type="hidden" name="mysession" value="<?= $oCurrentUser->mysession ?>" />

          <input type="hidden" name="class" value="<?= $class_id ?>" />

        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" id="MSID" value="<?= $MSID ?>" />
        <input type="hidden" name="term" value="<?= $term ?>"
        <?php ?>

               <div class="box-body">
                   <?php
                   if ($totalrecords > 0)
                       {
                       ?>  <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-4"> 
                                    <lable><b>Co Scholastic Area</b></lable>
                                </div>
                                <div class="col-md-4">

                                    <lable><b>
                                            <?php
                                            if ($oCurrentSchool->CoScholastic == 1)
                                                {
                                                echo "Marks";
                                                }
                                            if ($oCurrentSchool->CoScholastic == 2 || $oCurrentSchool->CoScholastic == 3)
                                                {
                                                echo "Grade";
                                                }
                                            ?></b></div>  

                                <div class="col-md-4">
                                    <?php
                                    if ($oCurrentSchool->CoScholastic == 1)
                                        {
                                        ?>
                                        <lable><b>Out OF <span class="text-red ">*</span></b></lable> <?php } ?>
                                    <?php
                                    if ($oCurrentSchool->CoScholastic == 3)
                                        {
                                        ?>
                                        <lable><b>Indicators <span class="text-red ">*</span></b></lable><?php } ?>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                $j = 1;


                while ($rowv = $exam_co_scholastic_areas->fetch())
                    {
                    $marks = Exam::get_exam_co_scholastic_marks($MSID, '', $data = array('selectAll' => 'true'), $id, $oCurrentUser->mysession, '', $term);
                    $totalrecords_marks = $marks->rowCount();
                    if ($totalrecords_marks > 0)
                        {
                        $previous_marks = $marks->fetch(PDO::FETCH_ASSOC);
                        }
                    ?> 

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-4"> 
                                        <?php
                                        echo ($totalrecords_marks > 0) ? $previous_marks['title'] : $rowv['title'];
                                        ?>
                                        <input class="form-control" type="hidden" name="title[]"  value="<?php
                                        echo ($totalrecords_marks > 0) ? $previous_marks['title'] : $rowv['title'];
                                        ?>" id="title" />
                                        <input class="form-control" type="hidden" name="co_scholastic[<?= $rowv['id'] ?>]" value="<?= $rowv['id'] ?>" />
                                        <input type="hidden" value="<?= $rowv['id'] ?>" name="co_schol"/>

                                    </div>
                                    <div class="col-md-4">
                                        <?php
                                        if ($oCurrentSchool->CoScholastic == 1)
                                            {

                                            $marks1 = Exam::get_exam_co_scholastic_marks($MSID, '', $data = array('selectAll' => 'true'), $id, $oCurrentUser->mysession, $rowv['id'], $term);
                                            $marks_get = $marks1->fetch(PDO::FETCH_ASSOC);
                                            ?>   <input type="text"  class="ttl_co_sch form-control"  data-id="<?= $rowv['max_marks'] ?>" value="<?= $marks_get['marks']; ?>" name="marks[]" >
                                            <input type="hidden"  class="ttl_co_sch form-control" name="grades_indicator[]" value="0"/>
                                            <input type="hidden"  class="ttl_co_sch form-control" name="grades[]" value="0"/>
                                            <?php
                                            }
                                        if ($oCurrentSchool->CoScholastic == 2)
                                            {
                                            $marks1 = Exam::get_exam_co_scholastic_marks($MSID, '', $data = array('selectAll' => 'true'), $id, $oCurrentUser->mysession, $rowv['id'], $term);
                                            $grade_get_res = $marks1->fetch(PDO::FETCH_ASSOC);
                                            ?>
                                            <select class="form-control" name='grades[]'>
                                                <option value="">Select</option>
                                                <option value="A" <?php
                                                if (@$grade_get_res['grade'] == 'A')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>A</option>
                                                <option value="B" <?php
                                                if (@$grade_get_res['grade'] == 'B')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>B</option>
                                                <option value="C" <?php
                                                if (@$grade_get_res['grade'] == 'C')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>C</option>
                                                <option value="D" <?php
                                                if (@$grade_get_res['grade'] == 'D')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>D</option>
                                                <option value="E" <?php
                                                if (@$grade_get_res['grade'] == 'E')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>E</option></select>
                                            <input type="hidden"  class="ttl_co_sch form-control" name="marks[]" value="0"/>
                                            <input type="hidden"  class="ttl_co_sch form-control" name="grades_indicator[]" value="0"/>
                                            <?php
                                            }
                                        ?>
                                        <?php
                                        if ($oCurrentSchool->CoScholastic == 3)
                                            {

                                            //$grade_get = $marks->fetchAll(PDO::FETCH_ASSOC);

                                            $marks1 = Exam::get_exam_co_scholastic_marks($MSID, '', $data = array('selectAll' => 'true'), $id, $oCurrentUser->mysession, $rowv['id'], $term);

                                            $grade_get_res = $marks1->fetch(PDO::FETCH_ASSOC);


                                            // $grade_with_indicator = Exam::get_exam_co_scholastic_indicators_grade($MSID, $data = array('selectAll' => 'true'),$grade); 
                                            ?>
                                            <select class="form-control grade_select" name='grades[]' id="grades_<?php echo $j; ?>" required="required" >
                                                <option value="">Select</option>
                                                <option value="A" <?php
                                                if (@$grade_get_res['grade'] == 'A')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>A</option>
                                                <option value="B" <?php
                                                if (@$grade_get_res['grade'] == 'B')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>B</option>
                                                <option value="C" <?php
                                                if (@$grade_get_res['grade'] == 'C')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>C</option>
                                                <option value="D" <?php
                                                if (@$grade_get_res['grade'] == 'D')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>D</option>
                                                <option value="E" <?php
                                                if (@$grade_get_res['grade'] == 'E')
                                                    {
                                                    echo "selected='seleted'";
                                                    }
                                                ?>>E</option>    



                                            </select>


                                            <?php
                                            }
                                        ?>
                                    </div>  
                                    <div class="col-md-4">
                                        <?php
                                        if ($oCurrentSchool->CoScholastic == 1)
                                            {
                                            ?>          <span class="text-red ">*</span> / <?= $rowv['max_marks'] ?>
                                        <?php } ?> <?php
                                        if ($oCurrentSchool->CoScholastic == 3)
                                            {

                                            //$find_grade_indicator = Exam::get_exam_co_scholastic_areas($MSID, '', true, $class_id);
                                            //print_r($find_grade_indicator);
                                            // $indicator_data   =  Exam::get_exam_co_scholastic_indicators($MSID, '', '',$data = array('selectAll' => 'true'));
                                            // $indicator_fetch = $indicator_data->fetchAll();
                                            //print_r($oCurrentschool);
                                            //print_r($indicator_fetch);
                                            ?>  

                                            <input type="hidden"  class="ttl_co_sch form-control" name="marks[]" value="0"/>




                                            <select class="form-control" name='grades_indicator[]' id="graders_indicate_<?= $j ?>" required="required" style="display: none">

                                                <?php
                                                @$marks1 = Exam::get_exam_co_scholastic_marks($MSID, '', $data = array('selectAll' => 'true'), $id, $oCurrentUser->mysession, $rowv['id'], $term);

                                                @$grade_get_res = @$marks1->fetch(PDO::FETCH_ASSOC);
                                                if (@$grade_get_res['indictor_id'] != '0')
                                                    {
                                                    @$indicator_get = Exam::get_indicator_names($MSID, @$grade_get_res['indictor_id'])->fetch();
                                                    ?>
                                                    <option value="<?= $grade_get_res['indictor_id'] ?>"><?= @$indicator_get['description'] ?></option>

                                                    <?php
                                                    }
                                                ?>


                                                <?php ?>
                                            </select>


                                        <?php }
                                        ?>


                                    </div>
                                </div>  
                            </div>
                        </div>
                    </div>
                    <?php
                    $j++;
//                
                    }
                }
            else
                {
                echo '<div class="text-center margin">Please Add Co Scholastic Areas for ' . $class_id . ' Class</div>';
                }
            ?>

        </div>
        <?php
        if ($totalrecords > 0)
            {
            ?> <div class="form-group row">
                <div class="col-md-9"></div><div class="col-md-3">
                    <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Add</button>
                </div></div>
        <?php } ?>
        <div class="col-md-3 text-center"> 
            <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>
    </form>

    <script>
        $(function () {
            var type = <?= $oCurrentSchool->CoScholastic ?>;
            //            alert(type);
            if (type == '1')
            {
                // var error;
                $('.ttl_co_sch').blur(function () {
                    var attended = $(this).val();
                    var max = $(this).data('id');
                    // alert("s");    
                    if (attended == '') {
                        $(this).addClass('error');
                        //$(this).prop('required',true);

                        // error = 'error';
                        //                        return false;

                    } else if (attended <= max) {
                        $(this).removeClass('error');
                        //serror = '';
                    } else
                    {

                        $(this).addClass('error');
                        //error = 'error';
                        //                        return false;
                        //                        
                    }


                });




            }

            $('#ajaxSubmit').click(function ()
            {
                $('#ajaxForm .errorDiv').remove();
                //                if ($(".ttl_co_sch").hasClass("error")) {
                //        $("#error_div").append('<div class="errorDiv text-red">You have Entered marks greater then maximum marks.</div>');
                //        } else{
                var datastring = $("#ajaxForm").serialize();
                // alert(datastring);
                alert(datastring);
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/exam-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        alert(responseText);
                        responseText = $.trim(responseText);

                        if (responseText != 'error') 
                         { 
                         location.reload();
                         eModal.close();
                         } else {
                         $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                         }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });

            $(".grade_select").change(function ()
            {

                var id = $(this).attr('id');

                var grade_split = id.split("_");

                var grad_id = grade_split[1];
                //alert(grad_id);

                var grade = $("#" + id).val();

                var MSID = $("#MSID").val();



                var datastring = 'grade=' + grade + '&id=' + id + '&msid=' + MSID + '&grade_indicator=true';

//                alert(datastring);

                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/exam-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
//                        alert(responseText);

//exit();
                        $("#graders_indicate_" + grad_id).html('');
                        $("#graders_indicate_" + grad_id).show();
                        $("#graders_indicate_" + grad_id).append(responseText);



                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            // $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            // $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;




            });

            //        }
        });
    </script>
    <?php
    }
?>     