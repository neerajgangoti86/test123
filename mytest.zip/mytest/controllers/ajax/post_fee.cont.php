<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller for handeling the ajax pages post values
 * This is a very special controller that is included on other places beside the index
 */
$id = http_get("param1");
$oDb = DBConnection::get();
$MSID = @$_POST['MSID'];
if (@$_POST['add_fee_collection'] == 'true') {
//    print_r($_POST);
//    exit();
    $MSID = $_POST['MSID'];
    $due_date = $_POST['due_date'];
    $TrDate = $oCurrentUser->mydate;
    $DR = $_POST['dr'];
    $acno = $_POST['acno'];
    $sr_no = $_POST['sr_no'];
    $late_fee = $_POST['late_fee'];
    $discount = $_POST['discount'];
    $date = new DateTime();
    $tmp = $date->format('Y-m-dH:i:s');
    $amt = $_POST['ttl_fee'];
    $TridNo = $oCurrentUser->user_id . $tmp;
    $session = Master::getSchoolSession($MSID, $due_date)->fetch(PDO::FETCH_OBJ);
    $ID_DUEDATE_UNIQ = $MSID . '-' . $_POST['acno'] . '-' . $due_date;

    $queryA = "select * FROM `ms_fee_transactions` WHERE   `fee_receipt_id` = '$ID_DUEDATE_UNIQ' And status='1' And MSID='$MSID'";
    $oDb = DBConnection::get();
    $data = $oDb->query($queryA);

    if ($data->rowCount() > 0) {
        echo "error";
    } else {
        $save = Fee::save_trancection($MSID, $session->session_id, $TrDate, $DR, $acno, $oCurrentUser->myuid, '0', $ID_DUEDATE_UNIQ, $TridNo, $amt, '', '', '', $sr_no, $late_fee, $discount);
    }
} else if (@$_POST['add_new_fee'] == 'true') {

//    
//     $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_billing (MSID, DueDate, SID, FeeName, FeeAmt, AcNo, SrNo, RSrNo, FeeId, Class, FatherName ,Village, MobileSMS, House,type) VALUES  (:MSID, :DueDate, :SID, :FeeName, :FeeAmt , :AcNo, :SrNo, :RSrNo, :FeeId, :Class, :FatherName ,:Village, :MobileSMS, :House ,:type )');
//        $status = $sql->execute(array(
//            ':MSID' => $MSID,
//            ':DueDate' => $fee_details->DueDate,
//            ':SID' => $fee_details->SID,
//            ':FeeName' => $_POST['fee_name'],
//            ':FeeAmt' => $_POST['fee_amt'],
//            ':AcNo' => $fee_details->AcNo,
//            ':SrNo' => $fee_details->SrNo,
//            ':RSrNo' => $fee_details->RSrNo,
//            ':FeeId' => $id,
//            ':Class' => $fee_details->Class,
//            ':FatherName' => $fee_details->FatherName,
//            ':Village' => $fee_details->Village,
//            ':MobileSMS' => $fee_details->MobileSMS,
//            ':House' => $fee_details->House,
//            ':type' => $_POST['type']
//        ));
//        




    $MSID = $_POST['MSID'];
    $fee_details = Fee::get_feename($MSID, $_POST['id_to_pass'])->fetch(PDO::FETCH_OBJ);
//
//    print_r($fee_details);
//    exit();
    $id = -$_POST['id_to_pass'];
//    try {
    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_billing (MSID, DueDate, SID, FeeName, FeeAmt, FeeGroup,AcNo, SrNo, RSrNo,   FeeId, Class,Session, FatherName ,Village, MobileSMS, House,type) VALUES  (:MSID, :DueDate, :SID, :FeeName, :FeeAmt , :FeeGroup, :AcNo, :SrNo, :RSrNo, :FeeId, :Class, :Session, :FatherName ,:Village, :MobileSMS, :House ,:type)');
    $status = $sql->execute(array(
        ':MSID' => $MSID,
        ':DueDate' => $fee_details->DueDate,
        ':SID' => $fee_details->SID,
        ':FeeName' => $_POST['fee_name'],
        ':FeeAmt' => $_POST['fee_amt'],
        ':FeeGroup' => $fee_details->FeeGroup,
        ':AcNo' => $fee_details->AcNo,
        ':SrNo' => $fee_details->SrNo,
        ':RSrNo' => $fee_details->RSrNo,
        ':FeeId' => $id,
        ':Class' => $fee_details->Class,
        ':Session' => $oCurrentUser->mysession,
        ':FatherName' => $fee_details->FatherName,
        ':Village' => $fee_details->Village,
        ':MobileSMS' => $fee_details->MobileSMS,
        ':House' => $fee_details->House,
        ':type' => $_POST['type']
    ));

//    print_r($sql);
//    exit();
//        if ($status) {
    echo 'success';
//            header(CLIENT_URL . '/ajax/fee_detail_headwise/');
    $message = new Messages();
    $message->add('s', 'Fine  added successfully!');
//        } else {
//            echo 'error';
//        }
//    } catch (PDOException $e) {
//        echo 'errorsss';
//    }
} else if (@$_POST['add_new_discount'] == 'true') {


    $MSID = $_POST['MSID'];
    $fee_details = Fee::get_feename($MSID, $_POST['id_to_pass'])->fetch(PDO::FETCH_OBJ);

//    print_r($fee_details);
//    exit();
    $id = -$_POST['id_to_pass'];
    $amt = -$_POST['fee_amt'];
//    try {
    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_billing (MSID, DueDate, SID, FeeName, FeeAmt,FeeGroup, AcNo, SrNo, RSrNo,   FeeId, Class, Session,FatherName ,Village, MobileSMS, House,type) VALUES  (:MSID, :DueDate, :SID, :FeeName, :FeeAmt ,:FeeGroup, :AcNo, :SrNo, :RSrNo, :FeeId, :Class, :Session,:FatherName ,:Village, :MobileSMS, :House ,:type)');
    $status = $sql->execute(array(
        ':MSID' => $MSID,
        ':DueDate' => $fee_details->DueDate,
        ':SID' => $fee_details->SID,
        ':FeeName' => $_POST['fee_name'],
        ':FeeAmt' => $amt,
        ':FeeGroup' => $fee_details->FeeGroup,
        ':AcNo' => $fee_details->AcNo,
        ':SrNo' => $fee_details->SrNo,
        ':RSrNo' => $fee_details->RSrNo,
        ':FeeId' => $id,
        ':Class' => $fee_details->Class,
        ':Session' => $oCurrentUser->mysession,
        ':FatherName' => $fee_details->FatherName,
        ':Village' => $fee_details->Village,
        ':MobileSMS' => $fee_details->MobileSMS,
        ':House' => $fee_details->House,
        ':type' => $_POST['type']
    ));

//    print_r($sql);
//    exit();
//        if ($status) {
    echo 'success';
//            header(CLIENT_URL . '/ajax/fee_detail_headwise/');
    $message = new Messages();
    $message->add('s', 'Fine  added successfully!');
//        } else {
//            echo 'error';
//        }
//    } catch (PDOException $e) {
//        echo 'errorsss';
//    }
} else if (@$_POST['add_fee_collection_headwise'] == 'true') {
//    print_r($_POST);
    $MSID = $_POST['MSID'];
    $due_date = $_POST['due_date'];
    $TrDate = $_POST['TrDate'];
    $DR = $_POST['dr'];
    $acno = $_POST['acno'];
    $sr_no = $_POST['sr_no'];

    $late_fee = $_POST['late_fee'];
    $discount = $_POST['discount'];
    $date = new DateTime();
    $tmp = $date->format('Y-m-dH:i:s');
    $amt = $_POST['paying_amt'];
    $TridNo = $oCurrentUser->user_id . $tmp;
    $session = Master::getSchoolSession($MSID, $due_date)->fetch(PDO::FETCH_OBJ);
    $ID_DUEDATE_UNIQ = $MSID . '-' . $_POST['acno'] . '-' . $due_date;

//    $queryA = "select * FROM `ms_fee_transactions` WHERE   `fee_receipt_id` = '$ID_DUEDATE_UNIQ' And status='1' And MSID='$MSID'";
//    $oDb = DBConnection::get();
//    $data = $oDb->query($queryA);
//    if ($data->rowCount() > 0) {
//        echo "error";
//    } else {
   
    if (($amt > 0) || ($late_fee > 0 ) || ($discount > 0)){
        $fee_array = @$_POST['fee_id'];
    $data_array = @$_POST['fee'];
     $last_id = General::gererate_db_nextid($MSID, 'fee_transactions', 'party_refference');
        $counts = $last_id->rowCount();
        $party_refrence = 0;
        if ($counts > 0) {

            $last = $last_id->fetch(PDO::FETCH_OBJ);
            $party_refrence = $last->party_refference;
//            print_r($party_refrence);
        }
        $party_refrence += 1;
    $save = Fee::save_trancection_headwise($MSID, $session->session_id, $TrDate, $DR, $acno, $oCurrentUser->myuid, $party_refrence, $ID_DUEDATE_UNIQ, $TridNo, $amt, '', $data_array, $fee_array, $sr_no, $late_fee, $discount);}else{  echo 'sucess';
    
    }
//    }
} else if (@$_POST['add_fine_headwise'] == 'true') {
//    print_r($_POST);
//    die("<>>>");


    $i = 0;
    if (@($_POST['update'])) {
        foreach (@$_POST['update'] as $ids => $amt) {
            if ($_POST['type'][$ids] == 2)
                $amt = -$amt;

            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_billing SET FeeAmt = :FeeAmt WHERE id = :id');
            $status = $sql->execute(array(
                ':FeeAmt' => $amt,
                ':id' => $ids
            ));
        }
    }
    if (isset($_POST['fee']) && !empty($_POST['fee'])) {
//        print_r($_POST);
//        exit();

        foreach (@$_POST['fee'] as $fee) {
//            if ($fee > 0) {
            $fee_name = Fee::get_feename_2($MSID, $fee)->fetch(PDO::FETCH_OBJ);
//                print_r($_POST);
//                exit();
            $name = $fee_name->FeeName;
            if ($fee_name->type == 2) {
                $amt = -$_POST['fees_value'][$i];
            } else {
                $amt = $_POST['fees_value'][$i];
            }
//            } else {
//                $fee_name = Fee::get_feename($MSID, $fee)->fetch(PDO::FETCH_OBJ);
//                $name = $fee_name->FeeName;
//            }


            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_billing (MSID, DueDate, Sid, FeeName, Session,FeeAmt, AcNo, SrNo, RSrNo, FeeId, Class, FatherName ,Village, MobileSMS, House,type) VALUES  (:MSID, :DueDate, :Sid, :FeeName,:Session, :FeeAmt , :AcNo, :SrNo, :RSrNo, :FeeId, :Class, :FatherName ,:Village, :MobileSMS, :House ,:type)');
            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':DueDate' => $_POST['due_date'],
                ':Sid' => $_POST['s_id'],
                ':FeeName' => $name,
                ':Session' => $oCurrentUser->mysession,
                ':FeeAmt' => $amt,
                ':AcNo' => $_POST['acno'],
                ':SrNo' => $_POST['sr_no'],
                ':RSrNo' => $_POST['rsr_no'],
                ':FeeId' => $fee,
                ':Class' => $_POST['cls'],
                ':FatherName' => $_POST['f_name'],
                ':Village' => $_POST['village'],
                ':MobileSMS' => $_POST['mobile_sms'],
                ':House' => $_POST['house'],
                ':type' => $fee_name->type,
            ));
            $i++;
        }
    }



    $j = 0;

//    if (isset($_POST['fee_discount']) && !empty($_POST['fee_discount'])) {
//        foreach (@$_POST['fee_discount'] as $fee_discount) {
//
//
//
//            $fee_name = Fee::get_feename($MSID, $fee_discount)->fetch(PDO::FETCH_OBJ);
//
//
//            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_billing (MSID, DueDate, Sid, FeeName, FeeAmt, AcNo, SrNo, RSrNo, FeeId, Class, FatherName ,Village, MobileSMS, House) VALUES  (:MSID, :DueDate, :Sid, :FeeName, :FeeAmt , :AcNo, :SrNo, :RSrNo, :FeeId, :Class, :FatherName ,:Village, :MobileSMS, :House )');
//            $status = $sql->execute(array(
//                ':MSID' => $MSID,
//                ':DueDate' => $_POST['due_date'],
//                ':Sid' => $_POST['s_id'],
//                ':FeeName' => $fee_name->fee_name,
//                ':FeeAmt' => "-" . $_POST['discount_value'][$j],
//                ':AcNo' => $_POST['acno'],
//                ':SrNo' => $_POST['s_id'],
//                ':RSrNo' => $_POST['rsr_no'],
//                ':FeeId' => $fee,
//                ':Class' => $_POST['cls'],
//                ':FatherName' => $_POST['f_name'],
//                ':Village' => $_POST['village'],
//                ':MobileSMS' => $_POST['mobile_sms'],
//                ':House' => $_POST['house']
//            ));
//            $j++;
//        }
//    }

    if ($status) {
        echo 'success';
        $message = new Messages();
        $message->add('s', 'Fee added successfully!');
    } else {
        echo 'error';
    }
} else if (@$_POST['update_fee_collection_headwise'] == 'true') {
    
   
    $MSID = $_POST['MSID'];
    $TrDate = $_POST['TrDate'];
    $DR = $_POST['dr'];
    $acno = $_POST['acno'];
    $sr_no = $_POST['sr_no'];
    $date = new DateTime();
    $tmp = $date->format('Y-m-dH:i:s');
    $amt = $_POST['paying_amt'];
    $TridNo = $_POST['tr_sr_no'];
    $fee_array = $_POST['fee_id'];
    $data_array = $_POST['fee'];
    $late_fee = $_POST['late_fee'];
    $cal_late_fee = $_POST['cal_late_fee'];
    $discount = $_POST['discount'];
    $save = Fee::update_fee_paid_headwise($TrDate, $DR, $acno, $oCurrentUser->myuid, $TridNo, $amt, $data_array, $fee_array, $late_fee, $discount, $cal_late_fee, $MSID);
} else if (@$_POST['update_fee_collection'] == 'true') {
//    print_r($_POST);  
//        exit();

    $MSID = $_POST['MSID'];
    $TrDate = $_POST['TrDate'];
    $DR = $_POST['dr'];
    $acno = $_POST['acno'];
    $sr_no = $_POST['sr_no'];
    $date = new DateTime();
    $tmp = $date->format('Y-m-dH:i:s');
    $amt = $_POST['ttl_fee'];
    $late_fee = $_POST['late_fee'];
    $cal_late_fee = $_POST['cal_late_fee'];
    $discount = $_POST['discount'];
    $TridNo = $_POST['tr_sr_no'];
    $save = Fee::update_fee_paid($TrDate, $DR, $acno, $oCurrentUser->myuid, $TridNo, $amt, '', '', $late_fee, $discount, $cal_late_fee);
}




/* * ***********   =================  Student Transport Edit Section =================  */ else if (@$_POST['trans_edit'] == 'true') {
    //$student_tran = new Student();

    echo "<pre>";

    print_r($_POST);

    echo "</pre>";

    die("<><<");



    $student_id = $_POST['student_id'];

    $msid = $_POST['msid'];





    //$stu_trans_info = $student_tran->get_stu_traninfo($msid, $student_id);
    //$stu_trans_get = $stu_trans_info->fetch();
    //$stu_trans_date = $stu_trans_get['date_to'];

    $stu_tran_get_from_date = $_POST['date_from'];

    $current_date = $oCurrentUser->mydate;

    $stu_date_from = date('Y-m-d', strtotime($current_date . ' -1 day'));


    $stu_date_to = $_POST['date_to'];

    $stu_trans_id = $_POST['trans_id'];

    /* echo "<pre>";
      print_r($_POST);
      echo "</pre>"; */

    //die("<>><<<");

    if ($stu_tran_get_from_date == $current_date) {

        echo "hi";   // echo "Hi";
        //die("<>>");
        //$del_tran = Transport:: stu_del_trans($msid, $stu_trans_id, $stu_tran_get_from_date);
    }
    // die("<>><<");
    //die("<>>")
    // echo $stu_trans_get['tpt_stn_id'];
    //echo $_POST['tpt'];
    else {

        //echo "Hi";


        try {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'tpt_std SET tpt_stn_id = :tpt_stn_id, date_from = :date_from, date_to = :date_to  WHERE id = :id');
            $status = $upsql->execute(array(
                ':tpt_stn_id' => $_POST['tpt'],
                ':date_from' => $stu_date_from,
                ':date_to' => $stu_date_to,
                ':id' => $stu_trans_id
            ));



            if ($status) {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
            } else {
                echo 'error';
            }

            $Delete = Fee::get_delete_student_from_fee_billing($msid, '', $oCurrentUser->mysession, $student_id);
            $data_insert = Fee::insert_student_into_fee_billing2($oCurrentUser->myuid, '', $student_id);
        } catch (PDOException $e) {
            // echo 'error';

            echo $e->getMessage();
        }
    }
}


/* * *********    ==================  End Here  ==================================  */ 