<?php
# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");

/*
 * this part used for enrolled form page to list/select existing parents
 */
if ($content == 'update_tpt_station') {
    $station_id = http_get('param2');
    $tptroutes = Transport::get_tptroutes($MSID, '', 1);

    $tptstations = Transport::get_tptstations($MSID, $id)->fetch(PDO::FETCH_ASSOC);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_tpt_station" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Route  <span class="text-red">*</span></label>
                        <select name="route_id" class="form-control">
                            <option value="">Select</option>
                            <?php
                            foreach ($tptroutes as $route) {
                                if ($route["route_id"] == $tptstations['route_id']) {
                                    $selected = 'selected="selected"';
                                } else {
                                    $selected = '';
                                }
                                echo '<option value="' . $route["route_id"] . '" ' . $selected . '>' . $route["route_name"] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Station Name<span class="text-red">*</span></label>
                        <input class="form-control" type="text" size="30" value="<?= $tptstations['station_name']; ?>" id="stations" name="stations">
                    </div>
                    <div class="form-group">
                        <label>Distance<span class="text-red">*</span></label>
                        <input class="form-control" type="text" size="30" value="<?= $tptstations['distance']; ?>" id="distance" name="distance">
                    </div>
                </div>
                <!-- \col -->
            </div>
        </div>


        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/tpt-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                                                                            
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            //alert(responseText);
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
} else if ($content == 'update_tpt_route') {
    $route_id = http_get('param2');

    $tptroutes = Transport::get_tptroutes($MSID, $route_id)->fetch(PDO::FETCH_ASSOC);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_tpt_route" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Route Name<span class="text-red">*</span></label>
                        <input class="form-control" type="text" size="30" value="<?= $tptroutes['route_name']; ?>" id="route_name" name="route_name">
                    </div>
                </div>
                <!-- \col -->
            </div>
        </div>


        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/tpt-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                                                                                alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
} else if ($content == 'update_tpt_fee') {
    $id = http_get('param2');
    $tptstations = Transport::get_tptstations($MSID, $id, 0);
   
    $tptfees = Transport::get_tptfees($MSID, $id, 0, $oCurrentUser->mydate)->fetch(PDO::FETCH_ASSOC);
     
//    print_r($tptfees);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_tpt_fee" value="true" />
        <input type="hidden" name="id" value="<?= $tptfees["id"] ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Station <span class="text-red">*</span></label>
                        <select name="station_id" class="form-control">
                         <?php
                               foreach ($tptstations as $station) {
                                if ($station["station_id"] == $tptfees['station_id']) {
                                    $selected = 'selected="selected"';
                                } else {
                                    $selected = '';
                                }
                                echo '<option value="' . $station["station_id"] . '" ' . $selected . '>' . $station["station_name"] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group ">
                        <label  for="exampleInputName2">Date From:</label>
                        <div class="input-group">
                            <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                            <input type="text" value="<?= $tptfees['date_from']; ?>" name="date_from" class="form-control pull-right fee_start"/>
                        </div>
                    </div>
                    <div class="form-group ">
                        <label  for="exampleInputName2">Date To:</label>
                        <div class="input-group">
                            <div class="input-group-addon"> <i class="fa fa-calendar"></i> </div>
                            <input type="text" name="date_to" value="<?= $tptfees['date_to']; ?>" class="form-control pull-right fee_end"/>
                        </div>
                        <div class="form-group">
                            <label>Transport Fee <span class="text-red">*</span></label>
                            <input class="form-control" value="<?= $tptfees['fee']; ?>" type="text" size="30" id="distance" name="fee">
                        </div>

                    </div>
                </div>
                <!-- \col -->
            </div>
        </div>


        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {

            $('.fee_start').datepicker({
                format: 'yyyy-mm-dd',
                todayHighlight: true,
                clearBtn: true
            });
            $('.fee_start').on('changeDate', function (ev) {
                $(this).datepicker('hide');
            });
            $('.fee_end').datepicker({
                format: 'yyyy-mm-dd',
                todayHighlight: true,
                clearBtn: true
            });
            $('.fee_end').on('changeDate', function (ev) {
                $(this).datepicker('hide');
            });
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/tpt-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
    //                                                                                                        alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
}
?>     