<?php

class Master {

    public $class_from;
    public $class_to;
    public $oCurrentUser;
    public $oCurrentSchool;

    public function __construct() {
        //$this->oCurrentUser   = http_session("oCurrentUser", null);
        //$this->oCurrentUser->MSID != NULL ? $this->oCurrentSchool = $this->get_schools('',  $this->oCurrentUser->MSID)->fetch(PDO::FETCH_OBJ): ''; 
        //$this->class_from = $this->oCurrentSchool->class_from;
        //$this->class_to = $this->oCurrentSchool->class_to;
    }

    /**
     * get locality by school
     * @param string $msid
     * @param string $id
     * @param string $status
     * @return mixed User/false
     */
    
    public static function get_week_day_id($msid = NULL, $day = NULL) {

        try {
            $sql = 'SELECT * FROM `'. DB_PREFIX .'weekdays` WHERE Day = "'.$day.'" AND MSID = '.$msid;
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    
    public function add_fee_schedule($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        $data = implode(",", $postdata['fee_of_months']);
        try {
            //********* Insert into database *********//
//            if (strlen(trim(@$postdata['fee_of_months'])) == 0)
//                $message->add('e', 'Please Select Fee of months..!!');
//            if (strlen(trim(@$postdata['month'])) == 0)
//                $message->add('e', 'Please Select months..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'fee_schedule SET pay_mode = :pay_mode, month=:month,fee_of_months=:fee_of_months WHERE id = :id');
                    $upsql->execute(array(
                        ':pay_mode' => $postdata['pay_mode'],
                        ':month' => $postdata['month'],
                        ':fee_of_months' => $data,
                        ':id' => $id
                    ));
                    $message->add('s', 'Fee Schedule is updated successfully!', CLIENT_URL . '/feeschedule');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'fee_schedule (MSID, pay_mode,month ,fee_of_months, status) VALUES  (:MSID, :pay_mode, :month, :fee_of_months, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':pay_mode' => $postdata['pay_mode'],
                        ':month' => $postdata['month'],
                        ':fee_of_months' => $data,
                        ':status' => '1'
                    ));
                    $message->add('s', 'Fee Schedule added successfully!', CLIENT_URL . '/feeschedule');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_school_details($msid = NULL) {
        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "schools WHERE";


            if (@$msid) {
                $sql .= " MSID=" . $msid;
            }


            //$sql .= " order by class_no ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_class_names($msid = NULL, $id = NULL) {

        try {
            $sql = "SELECT * FROM `" . DB_PREFIX . "classes` where 1 ";
            if ($msid != NULL) {
                $sql .= " And MSID=" . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND class_no=" . $id;
            }

            $sql .= " order by id ASC";
//            if ($data['selectAll'] == 'false') {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_teacher_timetable($msid = NULL, $e_id = NULL, $wid = NULL, $period = NULL, $class = Null, $Section = NULL) {

        try {
            $sql = "SELECT distinct  M.Class,M.`MSID`, M.`empid`,M.days, M.colour, M.Section,  M.Period , M.Subject, S.name, S.subject_id FROM `ms_time_tb` M LEFT JOIN ms_schoolwise_subjects S ON M.Subject=S.subject_id AND M.`MSID` = S.`MSID`  WHERE 1 ";
            if ($e_id != NUll) {
                $sql.=" And M.`empid`='$e_id' ";
            } if ($period != NUll) {
                $sql.=" And Period='$period' ";
            } if ($class != NUll) {
                $sql.=" And M.`class`='$class' ";
            } if ($Section != NUll) {
                $sql.=" And M.`Section`='$Section' ";
            } if ($msid != NUll) {
                $sql.=" And M.`MSID`='$msid'  ";
            } if ($wid != NUll) {
                $sql.="AND FIND_IN_SET('" . $wid . "',days)";
            }
            $sql .="ORDER BY M.Period";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_class_names3($msid = NULL, $id = NULL) {

        try {
            $sql = "SELECT distinct(class_name),class_no,id FROM `" . DB_PREFIX . "classes` where class_id ";
            /* if ($msid != NULL) {
              $sql .= " And MSID=" . $msid;
              }
              if ($id != NULL) {
              $sql .= " AND class_no=" . $id;
              } */
            $sql .= " And MSID=" . $msid;

            $sql .= " AND class_no=" . $id;



            $sql .= " order by id ASC";
//            if ($data['selectAll'] == 'false') {
//                $records_per_page = $data['record_per_page'];
//                $starting_position = ($data['page'] - 1) * $records_per_page;
//                $sql .= " limit $starting_position, $records_per_page";
//            }
//             print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_week_days_ttl($msid = NULL, $day = NULL, $activity_day = "false") {

        try {
            if ($activity_day == "True") {
                $sql = "SELECT *  FROM `" . DB_PREFIX . "weekdays` where  WDayId!='0'  ";
            } else {
                $sql = "SELECT distinct Day,WDayId FROM `" . DB_PREFIX . "weekdays` where  WDayId!='0'  ";
            }


            if ($day != NULL) {
                if ($activity_day == "True") {
                    $sql .= " And Day= '" . $day . "'";
                } else {
                    $sql .= " And Day!= '" . $day . "'";
                }
            }
            if ($msid != NULL) {
                $sql .= " And MSID=" . $msid;
            }
            $sql .=" Order By WDayId ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_master_timetable($msid = NULL, $period = NULL, $section = NULL, $class = NULL, $begins = Null) {

        try {
            $sql = "SELECT M.`MSID`,  M.`id`, M.empid,M.`Period`,M.`colour`, M.`days`, M.`Class`, M.`Section`, M.`Subject`
  ,E.emp_name,E.employee_id ,E.MSID,S.name,(S.subject_id) as sub,S.MSID FROM `ms_time_tb` M INNER JOIN ms_employee
  E on M.empid =E.employee_id  And M.MSID=E.MSID INNER JOIN ms_schoolwise_subjects S on S.subject_id=M.Subject  And M.MSID=S.MSID  where M.`Class`='$class' And M.`Period`='$period' And E.MSID='$msid' And M.MSID='$msid' And S.MSID='$msid'    And M.`Section`='$section'

";


//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_timetable($msid = NULL, $class = NULL, $wid = NULL, $period = NULL, $mydate = Null, $section = NULL) {

        try {
            $sql = "SELECT M.`MSID` , M.`empid` , M.`Period` , M.`colour` , M.`Class` , M.`Section` , M.`Subject` , E.`emp_name` , E.`employee_id` , E.`MSID` , S.`name` , (
S.`subject_id`
) AS sub, S.`MSID`
FROM `ms_time_tb` M
INNER JOIN ms_employee E ON M.`Empid` = E.`employee_id`
AND M.`MSID` = E.`MSID`
INNER JOIN ms_schoolwise_subjects S ON S.`subject_id` = M.`Subject`
AND M.`MSID` = S.`MSID`
WHERE M.`Class` = '$class'
AND M.`Section` = '$section'
AND `Period` = '$period'
AND E.MSID = '$msid'
AND M.MSID = '$msid'
AND S.MSID = '$msid'
AND E.`retire_date` > '$mydate'
AND FIND_IN_SET( '$wid', days )
ORDER BY M.Period";


//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_class_names2($msid = NULL, $id = NULL) {

        try {
            $sql = "SELECT * FROM `" . DB_PREFIX . "classes` where 1 ";
            if ($msid != NULL) {
                $sql .= " And MSID=" . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND class_no=" . $id;
            }

            $sql .= " order by id ASC";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_stu_class_names($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM `" . DB_PREFIX . "classes` where 1 ";
            if ($msid != NULL) {
                $sql .= " And MSID=" . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND class_no=" . $id;
            }

            $sql .= " order by id ASC";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_class_result($msid = NULL, $id = NULL) {

        try {
            $sql = "SELECT * FROM `" . DB_PREFIX . "classes` where 1";
            if ($msid != NULL) {
                $sql .= " And MSID=" . $msid;
            }
            if ($id != NULL) {
                $sql .= " And id=" . $id;
            }
            $sql .= " order by id ASC";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_fee_schedule($msid = NULL, $id = NULL, $status = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM `" . DB_PREFIX . "fee_schedule` where 1 ";
            if ($msid != NULL) {
                $sql .= " And MSID=" . $msid;
            }
            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            if ($status != NULL) {
                $sql .= " AND status=" . $status;
            }
            $sql .= " order by id ASC";
            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function limitWords($text, $limit) {
        $word_arr = explode(" ", $text);

        if (count($word_arr) > $limit) {
            $words = implode(" ", array_slice($word_arr, 0, $limit)) . '';
            return $words;
        }

        return $text;
    }

    public static function get_locality($msid = NULL, $id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }

            $sql .= " order by id ASC";
//            print_r($sql);     

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_locality_new2($msid = NULL, $post_id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality";
            $sql .= " where MSID=" . $msid;

            if ($post_id != NULL) {
                $sql .= " AND post_id=" . $post_id;
            }

            $sql .= " order by id ASC";
//            print_r($sql);     

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_locality2($msid = NULL, $pincode = NULL, $limit = 'all', $where = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality_b";
//            $sql .= " where MSID=" . $msid;

            if ($pincode != NULL) {
                $sql .= " where pincode=" . $pincode;
            }
            $sql .= " order by id ASC";
            if ($limit != 'all') {
                $records_per_page = $where['record_per_page'];
                $starting_position = ($where['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            //print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_locality_name($msid = NULL, $name = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality";
            $sql .= " where MSID=" . $msid;

            if ($name != NULL) {
                $sql .= " AND name like '$name%'";
            }
            /* if ($status != NULL) {
              $sql .= " AND status=" . $status;
              } */
            $sql .= " order by id ASC";
            //print_r($sql);     

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    /**
     * get category sc, obc etc by school
     * @param string $msid
     * @param string $id
     * @param string $status
     * @return mixed User/false
     */
    public static function get_session($msid = NULL, $id = NULL, $sort = Null) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "sessions";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND session_id=" . $id;
            }
            if ($sort != NULL) {
                if ($sort == 'ASC') {
                    $sql .= " order by id ASC";
                } else {
                    $sql .= " order by id DESC";
                }
            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_school_board($id = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "school_boards ";

            if ($id != NULL) {
                $sql .= ' WHERE id=' . $id;
            }

            $sql .= " ORDER BY id ASC";
            //$sql .= " where MSID=" . $msid;
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (Exception $ex) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function getSchoolSession($msid = NULL, $datesl = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "sessions";
            $sql .= " where MSID=" . $msid;

            if ($datesl != NULL) {
                $sql .= " AND '" . $datesl . "' Between begins And ends";
            }

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_dates($name = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "date";

            $sql .= " Where id=" . $name;
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
//            print_r($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_years($id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "year";

            $sql .= " Where id=" . $id;
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_months($msid = NULL, $sr_no = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "months";

            $sql .= " Where MSID=" . $msid . " and sr_no = " . $sr_no;

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_category($msid = NULL, $id = NULL, $status = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "category";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND cat_id=" . $id;
            }
            if ($status != NULL) {
                //$sql .= " AND status=" . $status;
            }
//            print_r($sql);
            $sql .= " order by id ASC";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_department() {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "department";
            // $sql .= " where MSID=" . $msid;

            /* if ($id != NULL) {
              $sql .= " AND id=" . $id;
              }
              if ($status != NULL) {
              $sql .= " AND status=" . $status;
              } */
            $sql .= " order by id ASC";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_designation() {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "designation";
            //$sql .= " where MSID=" . $msid;

            /* if ($id != NULL) {
              $sql .= " AND id=" . $id;
              } */
            /* if ($status != NULL) {
              $sql .= " AND status=" . $status;
              } */
            $sql .= " order by id ASC";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_classes($msid = NULL, $id = NULL, $status = NULL, $limit = NULL, $class_no = NULL) {
        try {
            $oCurrentUser = http_session("oCurrentUser", null);
            $oCurrentUser->MSID != NULL ? $oCurrentSchool = self::get_schools('', $oCurrentUser->MSID)->fetch(PDO::FETCH_OBJ) : '';
            $sql = "SELECT * FROM " . DB_PREFIX . "classes WHERE 1 ";
            if (@$id) {
                $sql .= " AND id=" . $id;
            }
            if (@$class_no || $class_no == '0') {
                $sql .= " AND class_no=" . $class_no;
            }
            if (@$msid) {
                $sql .= " AND MSID=" . $msid;
            }

            if (@$status) {
                $sql .= " AND status=" . $status;
            }
            $sql .= " order by class_no ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_locality_list($msid = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality";
            $sql .= " where MSID=" . $msid;

            $sql .= " order by id ASC";
//            print_r($sql);     

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_locality_list_pincode($msid = NULL, $post_id = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality";
            $sql .= " where MSID=" . $msid;

            $sql .= " and post_id=" . $post_id;

            $sql .= " order by id ASC";
//            print_r($sql);     

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_locality_list2($msid = NULL, $pincodes = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality_b where  pincode IN (" . $pincodes . ")";
//            if (@$pincodes) {
//                $arr = array();
//                $arr = explode(',', $pincodes);
//                $i = 0;
//                foreach ($arr as $ar) {
//                    if ($i == 0) {
//                        $sql .=" where (";
//                    } else {
//                        $sql .=" Or ";
//                    }
//                    $sql .= " pincode=" . $ar;
//               $i++; }
//                $sql .=" ) ";
//            }
            $sql .= " order by id ASC";
//            print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_locality_list3($pincodes = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "locality where  post_id IN (" . $pincodes . ")";
//            if (@$pincodes) {
//                $arr = array();
//                $arr = explode(',', $pincodes);
//                $i = 0;
//                foreach ($arr as $ar) {
//                    if ($i == 0) {
//                        $sql .=" where (";
//                    } else {
//                        $sql .=" Or ";
//                    }
//                    $sql .= " pincode=" . $ar;
//               $i++; }
//                $sql .=" ) ";
//            }
            $sql .= " order by name ASC";
//            print_r($sql);

            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_activetyes_assigned($msid = NULL, $id = NULL, $data = array('selectAll' => 'true'), $class = Null, $subject = Null, $assesment = null) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "exam_activities_assign";
            $sql .= " where MSID=" . $msid;
            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            if ($class != NULL) {
                $sql .= " AND FIND_IN_SET('" . $class . "',class)";
            }
            if ($subject != NULL) {
                $sql .= " AND FIND_IN_SET('" . $subject . "',subject_id)";
            }
            if ($assesment != NULL) {
                $sql .= " AND FIND_IN_SET('" . $assesment . "',assesment_id)";
            }
            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_activetyes_list($msid = NULL, $id = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "activites";
            $sql .= " where MSID=" . $msid;
            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//        print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_houses($msid = NULL, $id = NULL, $status = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "houses";
            $sql .= " where MSID=" . $msid;

            if ($id != NULL) {
                $sql .= " AND house_id=" . $id;
            }
            if ($status != NULL) {
                $sql .= " AND status=" . $status;
            }
            $sql .= " order by house_id ASC";
            // print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);

            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_schools($limit = NULL, $whr = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "schools";
            if (!empty($whr)) {
                $sql .= " where id = '" . $whr . "' OR MSID = '" . $whr . "'";
            }
            $sql .= " order by name ASC";
            if (!empty($limit)) {
                $sql .= " limit " . $limit;
            }

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_sections($msid = NULL, $id = NULL, $class_id = NULL, $status = NULL) {
        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "schools_section  SSC
INNER JOIN " . DB_PREFIX . "sections S ON SSC.`sec_name`=S.sec_name WHERE SSC.MSID= " . $msid;

            if ($id != NULL) {
                $sql .= " AND SSC.section_id=" . $id;
            }
//            if (@$class_id || $class_id == '0') {
//                $sql .= " AND SSC.class_id= '" . $class_id . "'";
//            }
//            if ($status != NULL) {
//                $sql .= " AND SSC.status=" . $status;
//            }
            $sql .= " order by SSC.id ASC";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_sessions($msid = NULL, $max = NULL) {
        try {
            $sql = "SELECT max(session_id) as max,MSID,session_id,begins,ends FROM " . DB_PREFIX . "sessions WHERE MSID= " . $msid;
            $sql .= " order by id ASC";
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_schools_section($MSID = NULL, $id = NULL, $classid = NULL) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "schools_section";

            $sql .= " WHERE MSID=" . $MSID;

            if ($id != NULL) {
                $sql .= " AND section_id=" . $id;
            }

//             print_r($sql);
            /* if ($classid != NULL) 
              {
              $sql .= " AND class_id=" . $classid;
              } */
//            if ($id == NULL && $classid == NULL) {
//                $sql .= " GROUP BY class_id order by class_id ASC";
//            } else {
            $sql .= " order by id ASC";
//            }
//            print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_school_section($MSID = NULL, $section_id = NULL) {

        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "schools_section";

            $sql .= " WHERE MSID=" . $MSID;


            if ($section_id != NULL) {
                $sql .= " AND section_id=" . $section_id;
            }

//            if ($classid != NULL) {
//                $sql .= " AND class_id=" . $classid;
//            }
//            if ($id == NULL && $classid == NULL) {
//                $sql .= " GROUP BY class_id order by class_id ASC";
//            } else {
            $sql .= " order by id ASC";
//            }
            //print_r($sql);
//            exit();
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_subject($msid = NULL, $id = NULL, $class_id = NUll, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "subjects_all Where 1 ";
//            if ($msid != NULL) {
//                $sql .= " where MSID=" . $msid;
//            } else {
//                $sql .= " where (MSID !='' OR MSID IS NOT NULL)";
//            }

            if ($id != NULL) {
                $sql .= " AND subject_id=" . $id;
            }
//            if ($class_id != NULL) {
//                $sql .= " AND classFrom <=" . $class_id;
//                $sql .= " AND classTo >=" . $class_id;
//            }
            $sql .= " order by subject_id ASC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_subject_name($msid = NULL, $id = NULL, $class_id = NUll, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "main_subjects Where 1 ";
//            if ($msid != NULL) {
//                $sql .= " where MSID=" . $msid;
//            } else {
//                $sql .= " where (MSID !='' OR MSID IS NOT NULL)";
//            }

            if ($id != NULL) {
                $sql .= " AND ID=" . $id;
            }
//            if ($class_id != NULL) {
//                $sql .= " AND classFrom <=" . $class_id;
//                $sql .= " AND classTo >=" . $class_id;
//            }
            $sql .= " order by ID ASC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_modules($id = NULL, $status = NULL, $data = array('selectAll' => 'true')) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "modules";
            if ($status != NULL) {
                $sql .= " Where  status=" . $status;
            }
            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }

            $sql .= " order by id ASC";

            if ($data['selectAll'] == 'false') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            //print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function get_events($msid = NULL, $id = NULL, $limit = 'all', $data = array('page' => 1, 'record_per_page' => 10)) {
        try {
            $sql = "SELECT * FROM " . DB_PREFIX . "events";

            if ($msid != NULL) {
                $sql .= " where MSID=" . $msid;
            }

            if ($id != NULL) {
                $sql .= " AND id=" . $id;
            }
            $sql .= " order by id ASC";

            if ($limit != 'all') {
                $records_per_page = $data['record_per_page'];
                $starting_position = ($data['page'] - 1) * $records_per_page;
                $sql .= " limit $starting_position, $records_per_page";
            }
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    //register school
    public function register_school($id = NULL, $postdata = NULL, $file = NULL, $redirect = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        $sGeneral = new General();
        try {
            if (strlen(trim(@$postdata['msid'])) == 0)
                $message->add('e', 'MSID is required!');
            if (strlen(trim(@$postdata['name'])) == 0)
                $message->add('e', 'Name is required!');
            if (strlen(trim(@$postdata['place'])) == 0)
                $message->add('e', 'Place is required!');
            if (strlen(trim(@$postdata['post'])) == 0)
                $message->add('e', 'Post is required!');
            if (strlen(trim(@$postdata['distt'])) == 0)
                $message->add('e', 'Distt is required!');
            if (strlen(trim(@$postdata['state'])) == 0)
                $message->add('e', 'State is required!');
            if (strlen(trim(@$postdata['pin'])) == 0)
                $message->add('e', 'Pin is required!');
            if (strlen(trim(@$postdata['board'])) == 0)
                $message->add('e', 'Board is required!');
            if (strlen(trim(@$postdata['affno'])) == 0)
                $message->add('e', 'AffNo is required!');

            if (strlen(trim(@$postdata['schoolno'])) == 0)
                $message->add('e', 'SchoolNo is required!');

            if (!$message->hasMessages()) {
                //image upload
                if (!empty($file['logoimage']['name'])) {
                    //call thumbnail creation function and store thumbnail name
                    $newfilename = 'photo_' . round(microtime(true));
                    $upload_img = $sGeneral->cwUpload($file, 'logoimage', 'uploads/', $newfilename, TRUE, 'uploads/thumbs/', '200', '160');
                } else {
                    $upload_img = '';
                }

                if (!empty($id)) {//update school
                    if (empty($upload_img)) {
                        $update_img = $postdata['logoimage_org'];
                    } else {
                        $update_img = $upload_img;
                    }
//                    echo $postdata['Detailed_Headwise'];
//                    die(">>");

                    /* print_r($postdata);
                      echo $id;
                      die("<>>>"); */


//                    print_r($postdata);
//                    echo $id;
//                    
//                    die("<>>><");
//                    
                    //echo  $id;
                    //die("<>>");
                    // die("<>>");
                    //die(">/");
                    // print_r($postdata['bankcash']);
                    //exit();
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'schools SET MSID = :MSID, name = :name, place = :place, post = :post, distt = :distt, state = :state, pin = :pin, board = :board, affNo = :affNo,  recNo  = :recNo, schoolNo = :schoolNo, phone = :phone, bank = :bank, branch = :branch, acno = :acno, class_from = :class_from, class_to = :class_to, bank_cash = :bank_cash, fee_last_date = :fee_last_date, logo_img = :logo_img, transport = :transport, hostel = :hostel, SeprateTPTFBook = :SeprateTPTFBook, house = :house, adm_no =:adm_no, selection = :selection, library = :library, science = :science, arts = :arts, commerce = :commerce, school_type= :school_type, Detailed_Headwise= :Detailed_Headwise, activity = :activity, ward_of_company = :ward_of_company, no_of_term = :no_of_term, CoScholastic = :CoScholastic, separate_tpt_book = :separate_tpt_book ,RoundAmt = :RoundAmt, amount_multiple_of = :amount_multiple_of, bank_reciept = :bank_reciept,discount = :discount,watermark = :watermark,locality_pincode = :locality_pincode,admno_auto = :admno_auto,combine_feebook = :combine_feebook ,grades_in_acc_perf = :grades_in_acc_perf  WHERE id = :id');
                    $udpate = $upsql->execute(array(
                        ':MSID' => $postdata['msid'],
                        ':name' => $postdata['name'],
                        ':place' => $postdata['place'],
                        ':post' => $postdata['post'],
                        ':distt' => $postdata['distt'],
                        ':state' => $postdata['state'],
                        ':pin' => $postdata['pin'],
                        ':board' => $postdata['board'],
                        ':affNo' => $postdata['affno'],
                        ':recNo' => $postdata['recno'],
                        ':schoolNo' => $postdata['schoolno'],
                        ':phone' => $postdata['phone'],
                        ':bank' => $postdata['bank'],
                        ':branch' => $postdata['branch'],
                        ':acno' => $postdata['acno'],
                        ':class_from' => $postdata['classfrom'],
                        ':class_to' => $postdata['classto'],
                        ':bank_cash' => $postdata['bankcash'],
                        ':fee_last_date' => $postdata['feelastdate'],
                        ':logo_img' => $update_img,
                        ':transport' => $postdata['transport'],
                        ':hostel' => $postdata['hostel'],
                        ':SeprateTPTFBook' => $postdata['feebook'],
                        ':house' => $postdata['house'],
                        ':library' => $postdata['library'],
                        ':adm_no' => $postdata['adm_no'],
                        ':selection' => $postdata['selection'],
                        ':science' => $postdata['science'],
                        ':arts' => $postdata['arts'],
                        ':commerce' => $postdata['commerce'],
                        ':school_type' => $postdata['school_type'],
                        ':Detailed_Headwise' => $postdata['Detailed_Headwise'],
                        ':activity' => $postdata['activity'],
                        ':ward_of_company' => $postdata['ward_of_company'],
                        ':no_of_term' => $postdata['no_of_term'],
                        ':CoScholastic' => $postdata['conschol_updgrade'],
                        ':separate_tpt_book' => $postdata['separte_tpt'],
                        ':RoundAmt' => $postdata['round_amount'],
                        ':amount_multiple_of' => $postdata['amount_muliple_of'],
                        ':bank_reciept' => $postdata['bank_receipt'],
                        ':discount' => $postdata['discount'],
                        ':watermark' => $postdata['watermark'],
                        ':locality_pincode' => $postdata['locality_pincode'],
                        ':admno_auto' => $postdata['admno_auto'],
                        ':combine_feebook' => $postdata['combine_feebook'],
                        ':grades_in_acc_perf' => $postdata['grades_in_acc_perf'],
                        ':id' => $id
                    ));


                    $message->add('s', 'School updated successfully!', $redirect);
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'schools (MSID,name,place,post, distt, state, pin, board,affNo,recNo,schoolNo, phone, bank, branch, acno, class_from, class_to, bank_cash, fee_last_date, logo_img, transport, hostel, library,adm_no,selection, science, arts, commerce,section,school_type, created_date,status) VALUES  (:MSID, :name, :place, :post, :distt, :state, :pin, :board, :affNo, :recNo, :schoolNo, :phone, :bank, :branch, :acno, :class_from, :class_to, :bank_cash, :fee_last_date, :logo_img, :transport, :hostel, :library, :adm_no, :selection, :science, :arts, :commerce, :section, :school_type, :created_date, :status)');

                    $inserted = $sql->execute(array(
                        ':MSID' => $postdata['msid'],
                        ':name' => $postdata['name'],
                        ':place' => $postdata['place'],
                        ':post' => $postdata['post'],
                        ':distt' => $postdata['distt'],
                        ':state' => $postdata['state'],
                        ':pin' => $postdata['pin'],
                        ':board' => $postdata['board'],
                        ':affNo' => $postdata['affno'],
                        ':recNo' => $postdata['recno'],
                        ':schoolNo' => $postdata['schoolno'],
                        ':phone' => $postdata['phone'],
                        ':bank' => $postdata['bank'],
                        ':branch' => $postdata['branch'],
                        ':acno' => $postdata['acno'],
                        ':class_from' => $postdata['classfrom'],
                        ':class_to' => $postdata['classto'],
                        ':bank_cash' => $postdata['bankcash'],
                        ':fee_last_date' => $postdata['feelastdate'],
                        ':logo_img' => $upload_img,
                        ':transport' => $postdata['transport'],
                        ':hostel' => $postdata['hostel'],
                        ':library' => $postdata['library'],
                        ':adm_no' => $postdata['adm_no'],
                        ':selection' => $postdata['selection'],
                        ':science' => $postdata['science'],
                        ':arts' => $postdata['arts'],
                        ':commerce' => $postdata['commerce'],
                        ':section' => $postdata['section'],
                        ':school_type' => $postdata['school_type'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    if ($inserted) {
                        //  <-------- Adding All the Session in the Session table ---------->
                        $sql_add_session = $oDb->query("INSERT INTO `ms_sessions` ( `MSID`, `session_id`, `begins`, `ends`) VALUES( " . $postdata['msid'] . ", " . $postdata['year'] . ", '" . $postdata['session_start_date'] . "', '" . $postdata['session_end_date'] . "');");


                        $arr = array();
                        foreach (classes_list() as $key => $value) {
                            $arr[$key] = $value;
                        }
                        for ($i = $postdata['classfrom']; $i <= $postdata['classto']; $i++) {
                            $val_cls = $arr[$i];
                            $classsql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'classes (MSID, class_no, class_name,created_date,status) VALUES  (:MSID, :class_no, :class_name ,:created_date,:status)');
                            $classsql->execute(array(
                                ':MSID' => $postdata['msid'],
//                            ':MSID' => 111,
                                ':class_no' => $i,
                                ':class_name' => $val_cls,
                                ':created_date' => date('Y-m-d H:i:s'),
                                ':status' => '1'
                            ));
                        }
                        if ($postdata['section_check'] == true) {
                            foreach ($postdata['class_section'] as $keycls => $arrcl) {
                                $i = 65;
                                foreach ($arrcl as $key => $sectioarr) {
                                    $char = chr($i);
                                    if (!empty($sectioarr['class_sec'])) {
                                        $secsql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'schools_section (MSID, class_id, sec_name,display_name, sec_seats, created_date) VALUES  (:MSID, :class_id, :sec_name,:display_name, :sec_seats, :created_date)');
                                        $secsql->execute(array(
                                            ':MSID' => $postdata['msid'],
//                                            ':MSID' => 111,
                                            ':class_id' => $keycls,
                                            ':sec_name' => $char,
                                            ':display_name' => $sectioarr['class_sec'],
                                            ':sec_seats' => $sectioarr['sec_seat'],
                                            ':created_date' => date('Y-m-d H:i:s')
                                        ));
                                    } $i++;
                                }
                            }
                        }
                    }
                    $message->add('s', 'School registered successfully!', $redirect);
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_locality($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //insert into database
            if (strlen(trim(@$postdata['fname'])) == 0)
                $message->add('e', 'Locality Name is required..!!');
            if (strlen(trim(@$postdata['postoffice'])) == 0)
                $message->add('e', 'Post-Office is a required field..!!');
            if (strlen(trim(@$postdata['tehsil'])) == 0)
                $message->add('e', 'Tehsil Name is required..!!');
            if (strlen(trim(@$postdata['district'])) == 0)
                $message->add('e', 'District Name is required..!!');
            if (strlen(trim(@$postdata['state'])) == 0)
                $message->add('e', 'State Name is required..!!');
            if (strlen(trim(@$postdata['pincode'])) == 0)
                $message->add('e', 'Pin-Code is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update locality
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'locality SET name = :name, postoffice = :postoffice, tehsil = :tehsil, district = :district, state = :state, pincode = :pincode, status = :status  WHERE  id = :id');
                    $upsql->execute(array(
                        ':name' => $postdata['fname'],
                        ':postoffice' => $postdata['postoffice'],
                        ':state' => $postdata['state'],
                        ':tehsil' => $postdata['tehsil'],
                        ':district' => $postdata['district'],
                        ':pincode' => $postdata['pincode'],
                        ':status' => $postdata['status'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Locality updated successfully!', CLIENT_URL . '/locality/edit/' . $id);
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'locality (MSID, name, postoffice, tehsil, district, state, pincode, created_date, status) VALUES  (:MSID, :name, :postoffice, :tehsil, :district, :state, :pincode, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':name' => $postdata['fname'],
                        ':postoffice' => $postdata['postoffice'],
                        ':state' => $postdata['state'],
                        ':tehsil' => $postdata['tehsil'],
                        ':district' => $postdata['district'],
                        ':pincode' => $postdata['pincode'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'Locality added successfully!', CLIENT_URL . '/locality');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_category($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //************************ Insert into database ************************//
            if (strlen(trim(@$postdata['fname'])) == 0)
                $message->add('e', 'Category Name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update Category
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'category SET name = :name, status = :status  WHERE id = :id');
                    $upsql->execute(array(
                        ':name' => $postdata['fname'],
                        ':status' => $postdata['status'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Category updated successfully!', CLIENT_URL . '/category');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'category (MSID, name, created_date, status) VALUES  (:MSID, :name, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':name' => $postdata['fname'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'Category added successfully!', CLIENT_URL . '/category');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_department($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //************************ Insert into database ************************//
            if (strlen(trim(@$postdata['dept_name'])) == 0)
                $message->add('e', 'Department Name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update department
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'department SET dept_name = :dept_name, status = :status  WHERE id = :id');
                    $upsql->execute(array(
                        ':dept_name' => $postdata['dept_name'],
                        ':status' => $postdata['status'],
                        ':id' => $id
                    ));
                    $message->add('s', 'department updated successfully!', CLIENT_URL . '/department');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'department (MSID, dept_name, created_date, status) VALUES  (:MSID, :dept_name, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':dept_name' => $postdata['dept_name'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'department added successfully!', CLIENT_URL . '/department');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

//************************ Add designation ************************ Add designation************************ //

    public function add_designation($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //************************ Insert into database ************************//
            if (strlen(trim(@$postdata['designation'])) == 0)
                $message->add('e', 'Designation Name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'designation SET d_name = :d_name, status = :status  WHERE id = :id');
                    $upsql->execute(array(
                        ':d_name' => $postdata['designation'],
                        ':status' => $postdata['status'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Designation Field updated successfully!', CLIENT_URL . '/designation');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'designation (MSID, d_name, created_date, status) VALUES  (:MSID, :d_name, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':d_name' => $postdata['designation'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'Designation added successfully!', CLIENT_URL . '/designation');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_classes($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //************************ Insert into database ************************//
            if (strlen(trim(@$postdata['cname'])) == 0)
                $message->add('e', 'Class name is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update classes
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'classes SET class_name = :class_name, class_fullname = :class_fullname  WHERE id = :id');
                    $upsql->execute(array(
                        ':class_name' => $postdata['cname'],
                        ':class_fullname' => $postdata['cfname'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Class updated successfully!', CLIENT_URL . '/msclass/edit/' . $id);
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'classes (MSID, class_name, class_fullname, created_date, status) VALUES  (:MSID, :class_name, :class_fullname, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':class_name' => $postdata['cname'],
                        ':class_fullname' => $postdata['cfname'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'Class added successfully!', CLIENT_URL . '/msclass');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_houses($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            //************************ Insert into database ************************//
            if (strlen(trim(@$postdata['house_sname'])) == 0)
                $message->add('e', 'House ShortName is required..!!');
            if (strlen(trim(@$postdata['house_fname'])) == 0)
                $message->add('e', 'House FullName is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update designation
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'houses SET house_s_name = :house_s_name, house_f_name = :house_f_name, color = :color  WHERE house_id = :house_id');
                    $upsql->execute(array(
                        ':house_s_name' => $postdata['house_sname'],
                        ':house_f_name' => $postdata['house_fname'],
                        ':color' => $postdata['color'],
                        ':house_id' => $id
                    ));
                    $message->add('s', 'House Field updated successfully!', CLIENT_URL . '/houses');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'houses (MSID, house_s_name, house_f_name, color, created_date, status) VALUES  (:MSID, :house_s_name, :house_f_name,  :color, :created_date, :status)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':house_s_name' => $postdata['house_sname'],
                        ':house_f_name' => $postdata['house_fname'],
                        ':color' => $postdata['color'],
                        ':created_date' => date('Y-m-d H:i:s'),
                        ':status' => '1'
                    ));
                    $message->add('s', 'House added successfully!', CLIENT_URL . '/houses');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_subject($id = NULL, $postdata = array()) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            // Insert into database //
            if (strlen(trim(@$postdata['subject'])) == 0)
                $message->add('e', 'Subject name is required..!!');
            if (strlen(trim(@$postdata['subject_code'])) == 0)
                $message->add('e', 'Subject Code is required..!!');
            if (strlen(trim(@$postdata['classFrom'])) == 0)
                $message->add('e', 'From Class is required..!!');
            if (strlen(trim(@$postdata['classTo'])) == 0)
                $message->add('e', 'To Class is required..!!');

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update classes
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'subjects SET subject = :subject, subject_code = :subject_code, classFrom =:classFrom ,  classTo =:classTo WHERE id = :id');
                    $upsql->execute(array(
                        ':subject' => $postdata['subject'],
                        ':subject_code' => $postdata['subject_code'],
                        ':classFrom' => $postdata['classFrom'],
                        ':classTo' => $postdata['classTo'],
                        ':id' => $id
                    ));
                    $message->add('s', 'Subject updated successfully!', CLIENT_URL . '/subject');
                    exit();
                } else {//insert into database
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'subjects (MSID, subject, subject_code,classFrom,classTo, created_date) VALUES  (:MSID, :subject, :subject_code, :classFrom, :classTo, :created_date)');

                    $sql->execute(array(
                        ':MSID' => $postdata['MSID'],
                        ':subject' => $postdata['subject'],
                        ':subject_code' => $postdata['subject_code'],
                        ':classFrom' => $postdata['classFrom'],
                        ':classTo' => $postdata['classTo'],
                        ':created_date' => date('Y-m-d H:i:s'),
                    ));
                    $message->add('s', 'Subject added successfully!', CLIENT_URL . '/subject');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public function add_modules($id = NULL, $new_state = NULL) {
        $message = new Messages();
        $oDb = DBConnection::get();
        try {
            // Insert into database //

            if (!$message->hasMessages()) {

                if (!empty($id)) {//update classes
                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'modules SET status = :status WHERE id = :id');
                    $upsql->execute(array(
                        ':status' => $new_state,
                        ':id' => $id
                    ));
                    $message->add('s', 'Module IS updated successfully!', CLIENT_URL . '/modules');
                    exit();
                }
            }
        } catch (PDOException $e) {
            $message->add('e', $e->getMessage());
        }
    }

    public static function section_name_list($msid = NULL, $section_id = NULL) {

        try {

            $sql = "SELECT * FROM " . DB_PREFIX . "schools_section WHERE ";

            $sql .= " MSID=" . $msid;

            if (@$section_id != NULL) {

                $sql .= " AND section_id =" . $section_id;
            }



            $sql .= " order by section_id";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function month_name_get($msid = NULL, $month = NULL) {

        try {

            $sql = "SELECT * FROM `ms_month` where Monthno='$month'  And MSID='$msid'";



            $sql .= " order by Monthno";
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function total_books($msid = NULL) {

        try {

            $sql = "SELECT count( `book_id` ) totalbooks
FROM `ms_book`
WHERE `MSID` = '" . $msid . "'";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function total_school_percent($myuid = NULL) {

        try {

            $sql = "Select count(TP.student_id) topper, TP.percent From (SELECT CS.student_id,DS.`assessment`,Sum(AP.marks_obtained) MO,Sum(DS.`max_marks`),Sum(AP.marks_obtained)/Sum(DS.`max_marks`)*100 percent FROM (SELECT CU.msid,CU.Mysession Session, S.`student_id`,S.`adm_classno`+CU.MySession-Year(S.`adm_date`)+COALESCE(SUM(`result`),0) CClass,K.`class_from`,K.`class_to` FROM ms_students S INNER JOIN (SELECT * FROM `ms_slusers` WHERE myuid='".$myuid."') CU ON S.msid=CU.msid And S.`fees_date` <= CU.`ends` AND S.`sl_date` >= CU.`Begins` INNER JOIN ms_schools K ON K.`msid`=CU.`msid` LEFT JOIN ms_exams E ON E.msid=CU.msid AND E.`s_id`=S.`student_id` AND E.`date_result` < CU.`mydate` GROUP BY S.`student_id` HAVING CClass Between K.`class_from` AND K.`class_to`) CS LEFT JOIN ms_exam_datesheet DS ON DS.`msid`=CS.`msid` AND DS.`session`=CS.`session` AND DS.`class`=CS.`Cclass` Left Join ms_exam_acedemic_performance AP ON AP.msid=CS.MSID And  AP.`datesheet_id`=DS.id And CS.`student_id`=AP.`student_id` Group by AP.`student_id`) TP Where TP.percent>90";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function total_TS_Staff($msid = NULL, $mydate = NULL) {

        try {

            $sql = "SELECT count(`employee_id`) totalts FROM `ms_employee` WHERE `MSID`='" . $msid . "' And '" . $mydate . "' between `hire_date` And `retire_date` And `emp_category`='TS'";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function total_health_data($msid = NULL, $session = NULL) {

        try {

            $sql = "SELECT count(`s_id`) id FROM `ms_exam_health_data` WHERE `MSID`='" . $msid . "' And `session`='" . $session . "'";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }

    public static function total_admin($msid = NULL) {

        try {

            $sql = "SELECT count( `employee_id` ) admin FROM `ms_employee` WHERE `MSID` = '" . $msid . "'  AND `ulevel` =9";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function total_users($msid = NULL) {

        try {

            $sql = "SELECT count(`user_id`) user FROM `ms_slusers` WHERE `MSID`='".$msid."'";

//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function count_health_data($msid = NULL, $class=NULL, $dental=NULL ) {

        try {

            $sql = "SELECT * FROM `ms_exam_health_data` WHERE `MSID`='".$msid."' And `class`='".$class."'";
            
            if($dental!=NULL){ 
            $sql .=  "And dental_hygiene='".$dental."'"; 
            }
            
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    public static function health_data_range($msid = NULL, $class=NULL, $type=NULL, $from= NULL, $to= NULL) {

        try {

            $sql = "SELECT * FROM `ms_exam_health_data` WHERE `MSID`='".$msid."' And `class`='".$class."' And `".$type."` BETWEEN '".$from."' AND '".$to."'";
            
//            print_r($sql);
            $oDb = DBConnection::get();
            $sql = $oDb->query($sql);
            return $sql;
        } catch (PDOException $e) {
            $message = new Messages();
            $message->add('e', $e->getMessage());
        }
    }
    

}

?>
