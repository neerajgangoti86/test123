<?php
# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller for handeling the ajax pages
 * This is a very special controller that is included on other places beside the index
 */

$content = http_get("param1");
$id = http_get("param2");

/*
 * this part used for enrolled form page to list/select existing parents
 */if ($content == 'update_sms_keyword') {
    $id = http_get('param2');

    $SMS_Keywords = SMS::get_sms_keywords($MSID, $id)->fetch(PDO::FETCH_ASSOC);
    ?>
    <form id="ajaxForm" method="post" action="" role="form">
        <input type="hidden" name="update_keyword" value="true" />
        <input type="hidden" name="id" value="<?= $id ?>" />
        <input type="hidden" name="MSID" value="<?= $MSID ?>" />
        <?php ?>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Keyword<span class="text-red">*</span></label>
                        <input class="form-control" type="text" size="30" value="<?= $SMS_Keywords['name']; ?>" id="keywords_name" name="name">
                    </div>
                </div>
                <!-- \col -->
            </div>
        </div>


        <div class="form-group">
            <button type="submit" id="ajaxSubmit" name="submit" class="btn btn-lg btn-success btn-block">Update</button>
        </div>
        <div class="col-md-3 text-center"> <span id="process" style="display:none;" class="fa fa-circle-o-notch fa-spin fa-3x text-primary text-red"></span> </div>

    </form>

    <script>
        $(function () {
            $('#ajaxSubmit').click(function () {
                $('#ajaxForm .errorDiv').remove();

                var datastring = $("#ajaxForm").serialize();
                $("#process").show();
                ///ajax code
                $.ajax({
                    type: "POST", // type
                    url: "<?= CLIENT_URL ?>/sms-post", // request file
                    data: datastring, // post data
                    success: function (responseText) { // get the response
                        //                                                                                alert(responseText);
                        responseText = $.trim(responseText);
                        if (responseText != 'error') {
                            location.reload();
                            eModal.close();
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Error! PLease try again.</div>');
                        }
                        $("#process").hide();
                    }, // end success
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Internal error: ' + jqXHR.responseText + '</div>');
                        } else {
                            $("#ajaxForm").append('<div class="errorDiv text-red">Unexpected error.</div>');
                        }
                        $("#process").hide();
                    }
                });
                // end
                return false;
            });
        });
    </script>
    <?php
} 

?>     