<?php
# check if controller is required by index.php
if (!defined('ACCESS'))
    {
    echo 'Directory access is forbidden.';
    die;
    }
/*
 * controller for handeling the ajax pages post values
 * This is a very special controller that is included on other places beside the index
 */
$id = http_get("param1");
$oDb = DBConnection::get();
$MSID = @$_POST['MSID'];
if (@$_POST['add_activities'] == 'true')
    {
    if (empty($_POST['MSID']) || empty($_POST['name']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'activites (MSID, name) VALUES  (:MSID, :name)');
            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':name' => $_POST['name']
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Activities added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_activities'] == 'true')
    {
    if (empty($_POST['name']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'activites SET name = :name  WHERE id = :id');
            $status = $upsql->execute(array(
                ':name' => $_POST['name'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_assign_activities'] == 'true')
    {
    if (empty($_POST['MSID']) || (empty($_POST['activity_id']) || (empty($_POST['for_class'])) || (empty($_POST['subjects'])) || (empty($_POST['assesments']))))
        {
        echo 'error';
        }
    else
        {
        try
            {
//            print_r($_POST);
            $class = implode(",", $_POST['for_class']);
            $subject = implode(",", $_POST['subjects']);
            $assesments = implode(",", $_POST['assesments']);
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_activities_assign (MSID,subject_id,activity_id,assesment_id,class) VALUES  (:MSID,:subject_id,:activity_id,:assesment_id,:class)');
            $status = $sql->execute(array(
                ':MSID' => $_POST['MSID'],
                ':subject_id' => $subject,
                ':activity_id' => $_POST['activity_id'],
                ':assesment_id' => $assesments,
                ':class' => $class
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Activities Assigned added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
//            echo 'error';
            }
        }
    }
else if (@$_POST['update_assign_activities'] == 'true')
    {
    if ((empty($_POST['activity_id']) || (empty($_POST['for_class'])) || (empty($_POST['subjects'])) || (empty($_POST['assesments']))))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $class = implode(",", $_POST['for_class']);
            $subject = implode(",", $_POST['subjects']);
            $assesments = implode(",", $_POST['assesments']);
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_activities_assign SET subject_id = :subject_id,activity_id = :activity_id,assesment_id = :assesment_id,class = :class WHERE id = :id');
            $status = $sql->execute(array(
                ':subject_id' => $subject,
                ':activity_id' => $_POST['activity_id'],
                ':assesment_id' => $assesments,
                ':class' => $class,
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['update_failed_students'] == 'true')
    {
    if (empty($_POST['s_id']))
        {
        echo 'error';
        }
    else
        {
        try
            {
//            print_r($_POST);
            $sql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exams SET s_id = :s_id ,date_result = :date_result WHERE id = :id');
            $status = $sql->execute(array(
                ':s_id' => $_POST['s_id'],
                ':date_result' => $_POST['date_result'],
                ':id' => $_POST['id']
            ));
            if ($status)
                {
                $message = new Messages();
                $message->add('s', 'Updated successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_failed_student'] == 'true')
    {

    if (empty($_POST['s_id']) || empty($_POST['date_result']))
        {
        echo 'error';
        }
    else
        {
        try
            {
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exams (MSID, s_id, date_result,result) VALUES  (:MSID,:s_id,:date_result,:result)');
            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':s_id' => $_POST['s_id'],
                ':date_result' => $_POST['date_result'],
                ':result' => $_POST['result'],
            ));
            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Added successfully!');
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo 'error';
            }
        }
    }
else if (@$_POST['add_exam_co_scholastic_marks'] == 'true')
    {


    if (empty($_POST['MSID']) || empty($_POST['id']))
        {
        echo 'error';
        }
    else
        {

        try
            {



            $i = 0;
            foreach ($_POST['co_scholastic'] as $data => $val)
                {
                $marks = Exam::get_exam_co_scholastic_marks($_POST['MSID'], '', array('selectAll' => 'true'), $_POST['id'], $_POST['mysession'], $data, $_POST['term']);
                $totalrecords_marks = $marks->rowCount();


                if ($totalrecords_marks > 0)
                    {

                    $existing_marks = $marks->fetch(PDO::FETCH_ASSOC);

                    //print_r($existing_marks);


                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_co_scholastic_marks SET session = :session ,title = :title , marks = :marks, grade = :grade, indicator = :indicator, term = :term WHERE id = :id');
                    $status = $upsql->execute(array(
                        ':session' => $oCurrentUser->mysession,
                        ':title' => @$_POST['title'][$i],
                        ':marks' => @$_POST['marks'][$i],
                        ':grade' => @$_POST['grades'][$i],
                        ':indicator' => @$_POST['grades_indicator'][$i],
                        ':term' => @$_POST['term'],
                        ':id' => $existing_marks['id'],
                    ));
                    }
                else
                    {
                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_co_scholastic_marks (MSID,co_scholastic_id,s_id ,class,session, title ,grade, indicator, term, marks) VALUES  (:MSID, :co_scholastic_id, :s_id,:class,:session, :title , :grade, :indicator, :term , :marks)');
                    $status = $sql->execute(array(
                        ':MSID' => $_POST['MSID'],
                        ':co_scholastic_id' => $data,
                        ':s_id' => @$_POST['id'],
                        ':class' => @$_POST['class'],
                        ':session' => $oCurrentUser->mysession,
                        ':title' => @$_POST['title'][$i],
                        ':grade' => @$_POST['grades'][$i],
                        ':indicator' => @$_POST['grades_indicator'][$i],
                        ':term' => @$_POST['term'],
                        ':marks' => @$_POST['marks'][$i],
                    ));
                    }

                $i++;
                }



            if (@$status)
                {
                $message = new Messages();
                $message->add('s', 'Added successfully!');
                echo 'success';
                }
            else
                {
                echo 'error';
                }
            }
        catch (PDOException $e)
            {
            echo $e->getMessage();
            //echo 'error';
            }
        }


////        else if($_POST['grades'])
//        {
//            try 
//            {                
//                $i = 0;
//            foreach ($_POST['co_scholastic'] as $data => $val) {
//                $marks = Exam::get_exam_co_scholastic_marks($_POST['MSID'], '', array('selectAll' => 'true'), $_POST['id'], $_SESSION['year'], $data, $_POST['term']);
//                $totalrecords_marks = $marks->rowCount();
//                if ($totalrecords_marks > 0) {
//
//                    $existing_marks = $marks->fetch(PDO::FETCH_ASSOC);
//                    $upsql = $oDb->prepare('UPDATE ' . DB_PREFIX . 'exam_co_scholastic_marks SET title = :title ,grade = :grade WHERE id = :id');
//                    $upsql->execute(array(
//                        ':title' => $_POST['title'][$i],
//                        ':grade' => $_POST['grades'][$i],
//                        ':id' => $existing_marks['id'],
//                    ));
//                } else {
//                    $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_co_scholastic_marks (MSID, co_scholastic_id, s_id, session, title, grade) VALUES  (:MSID, :co_scholastic_id,:s_id, :session, :title , :grade)');
//                    $status = $sql->execute(array(
//                        ':MSID' => $_POST['MSID'],
//                        ':co_scholastic_id' => $data,
//                        ':s_id' => $_POST['id'],
//                        ':session' => $_SESSION['year'],
//                        ':title' => $_POST['title'][$i],
//                        ':grades' => $_POST['grades'][$i]
//                    ));
//                }
//
//                $i++;
//                
//            }
//            
//                if ($status) {
//                $message = new Messages();
//                $message->add('s', 'Added successfully!');
//                echo 'success';
//            } else {
//                echo 'error';
//            }
//            
//                } catch (PDOException $e) {
//                echo   $e->getMessage();
//           //echo 'error';
//        }
//                
//                   }      
//                
//                
//                
//            
//            
//            
    }
else if (@$_POST['add_co_scholastic_areas'] == 'true')
    {
//    print_r($_POST);

    if (empty($_POST['title']) || empty($_POST['max_marks']) || empty($_POST['for_class']))
        {

//        echo 'xdfsdfs';
        }
    elseif (is_numeric($_POST['max_marks']) && ($_POST['max_marks'] > 0 ))
        {
        try
            {
            $data = implode(",", $_POST['for_class']);
            $sql = $oDb->prepare('INSERT INTO ' . DB_PREFIX . 'exam_co_scholastic_areas (MSID, title, max_marks, class) VALUES  (:MSID, :title, :max_marks , :class )');

            $status = $sql->execute(array(
                ':MSID' => $MSID,
                ':title' => $_POST['title'],
                ':max_marks' => $_POST['max_marks'],
                ':class' => $data
            ));

            if ($status)
                {
                echo 'success';
                $message = new Messages();
                $message->add('s', 'Co - Scholastic - Area added successfully!');
                }
            else
                {
                echo 'error2';
                }
            }
        catch (PDOException $e)
            {
            echo 'error12';
            }
        }
    else
        {
        echo 'error1';
        }
    }
else if (@$_POST['grade_indicator'] == 'true')
    {


    $msid = $_POST['msid'];

    $grade = $_POST['grade'];

    $id_all = $_POST['id'];
    $ids = array();
    $ids = explode("_", $id_all);

//    print_r($ids);
//    exit();
//

    $grade_with_indicator = Exam::get_exam_co_scholastic_indicators_grade($msid, $data = array('selectAll' => 'true'), $grade, $ids[1]);

    $grade_with_ind_fetch = $grade_with_indicator->fetchAll();

    foreach ($grade_with_ind_fetch as $res)
        {
        ?>
        <option value="<?= $res['id'] ?>" ><?= $res['description'] ?></option>  



        <?php
        }
    }
?>

