<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}  
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Paid Salary | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';
 
$currentPage = 'Paid Salary'; 
$activities = ActivityFeed::get_activity_feeds($MSID);
$students = Student::get_students($oCurrentUser->myuid, 'all')->rowCount();
$empcount = Employee::get_employee($MSID, '', 'all', '', $oCurrentUser->mydate)->rowCount();



$oPageLayout->sPagePath = PAGES_FOLDER . '/home/home_dashboard.inc.php'; // special home page


# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>