<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
# make pageLayout Object
$oPageLayout = new PageLayout();
$sUserManager = new UserManager();
$oPageLayout->sWindowTitle = 'Profile | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = ''; 

$user_ID = $oCurrentUser->user_id;
$get_user = UserManager::get_users($user_ID)->fetch(PDO::FETCH_ASSOC); 
if(isset($_POST['updatesuser'])){
 $sUserManager->update_user($user_ID,$_POST,CLIENT_URL.'/profile');
}
//change password 
if(isset($_POST['updatepass'])){
 $sUserManager->change_password($user_ID,$_POST,CLIENT_URL.'/profile');
}

$oPageLayout->sPagePath = PAGES_FOLDER . '/profile/profile.inc.php'; // special home page

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>