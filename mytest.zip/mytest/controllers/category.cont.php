<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Category | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admin'; 
$sMaster = new Master();
$type = http_get('param1');

if($type=='add'){
  $oPageLayout->sWindowTitle = 'Add New Category | ' . CLIENT_NAME;
  
  if(isset($_POST['rsubmit'])){
   $sMaster->add_category('',$_POST);
  } 
  
  $oPageLayout->sPagePath = PAGES_FOLDER . '/category/category-register.inc.php';
 
}
else if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit Category | ' . CLIENT_NAME;
  $cat_id = http_get('param2');

if(isset($_POST['updatesubmit'])){
 $sMaster->add_category($cat_id,$_POST);
} 

$category = Master::get_category($MSID,$cat_id)->fetch(PDO::FETCH_ASSOC);

$oPageLayout->sPagePath = PAGES_FOLDER . '/category/category-edit.inc.php'; // special home page
}
else{ 
$category = Master::get_category($MSID,'');
$totalrecords = $category->rowCount();
$oPageLayout->sPagePath = PAGES_FOLDER . '/category/category.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>