<?php
# check if controller is required by index.php
if (!defined('ACCESS')){  
     echo 'Directory access is forbidden.';
     die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Department | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admin'; 
$sMaster = new Master();
$type = http_get('param1');

if($type=='add'){
  $oPageLayout->sWindowTitle = 'Add New Department | ' . CLIENT_NAME;
  
 if(isset($_POST['rsubmit'])){
  $sMaster->add_department('',$_POST);
  } 
  
  $oPageLayout->sPagePath = PAGES_FOLDER . '/department/department-register.inc.php';
 
}
else if($type=='edit'){
  $oPageLayout->sWindowTitle = 'Edit Department | ' . CLIENT_NAME;
  $dep_id = http_get('param2');

  if(isset($_POST['updatesubmit'])){
     $sMaster->add_department($dep_id,$_POST);
  }   
  //get current parent
  $department = Master::get_department($MSID,$dep_id)->fetch(PDO::FETCH_ASSOC);

$oPageLayout->sPagePath = PAGES_FOLDER . '/department/department-edit.inc.php'; // special home page
}
else{ 
$departments = Master::get_department($MSID);
$totalrecords = $departments->rowCount();
$oPageLayout->sPagePath = PAGES_FOLDER . '/department/department.inc.php'; // special home page
}

# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>