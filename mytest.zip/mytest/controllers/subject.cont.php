<?php

# check if controller is required by index.php
if (!defined('ACCESS')) {
    echo 'Directory access is forbidden.';
    die;
}
/*
 * controller to get all data for enrolled student
 */

# make pageLayout Object
$oPageLayout = new PageLayout();

$oPageLayout->sWindowTitle = 'Subjects | ' . CLIENT_NAME;
$oPageLayout->sMetaDescription = 'admissions for the new students';
$oPageLayout->sMetaKeywords = 'admission, school, student, mount shivalik';

$currentPage = 'Admin';
$sMaster = new Master();
$type = http_get('param1');

if ($type == 'add') {
    $oPageLayout->sWindowTitle = 'Add New Subject | ' . CLIENT_NAME;

    if (isset($_POST['subject_submit'])) {
        $sMaster->add_subject('', $_POST);
    }

    $oPageLayout->sPagePath = PAGES_FOLDER . '/subject/subject-register.inc.php';
} else if ($type == 'edit') {
    $oPageLayout->sWindowTitle = 'Edit Subject | ' . CLIENT_NAME;
    $id = http_get('param2');

    if (isset($_POST['subject_update'])) {
        $sMaster->add_subject($id, $_POST);
    }
    //get current designation
    $subject = Master::get_subject($MSID, $id)->fetch(PDO::FETCH_ASSOC);

    $oPageLayout->sPagePath = PAGES_FOLDER . '/subject/subject-edit.inc.php'; // special home page
} else {
    if ($type == 'delete') {
        $id = http_get('param2');
        /**
         * Delete record action function 
         * */
        if (!empty($id)) {
            $dataarr = array(
                'id' => $id,
                'tablename' => 'subjects',
                'redirect' => CLIENT_URL . '/subject',
                'where' => 'id'
            );
            $deleterecored = General::delete($dataarr);
        }
    }

    if ($type == 'page') {
        $page = http_get('param2');
    } else {
        $page = 1;
    }
//    print_r($page);
    if (isset($_SESSION['r_per_page'])) {
        $records_per_page = $_SESSION['r_per_page'];
    } else {
        $records_per_page = RECORDS_PER_PAGE;
    }
    $subject = Master::get_subject($MSID, '', '', '',
                    array('page' => $page, 'record_per_page' => $records_per_page));
    $totalrecords = $subject->rowCount();
    $total_no_recrd = Master::get_subject($MSID, '', '', 'all','')->rowCount();

    $links = 3;

    $Paginator = new Paginator($total_no_recrd, $records_per_page, $page,
            'subject');

    $pagination = $Paginator->createLinks($links, 'pagination');

    $oPageLayout->sPagePath = PAGES_FOLDER . '/subject/subject.inc.php'; // special home page
}
# include the main template
include_once TEMPLATES_FOLDER . '/default.tmpl.php';
?>