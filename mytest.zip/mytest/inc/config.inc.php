<?php
date_default_timezone_set('Asia/Calcutta');

# set locales to IN by default
setlocale(LC_TIME, 'en_IN');

# set UTF-8 encoding with header
header('Content-Type:text/html; charset=UTF-8');

define("CLIENT_URL", "http://demo.eschoolexpert.com");

//define("CLIENT_URL", "http://localhost/mountshivalik");
# set classes folder
define("CLASSES_FOLDER", DOCUMENT_ROOT . '/classes');

# set include folder
define("PAGES_FOLDER", DOCUMENT_ROOT . '/pages');

# set css folder
define("ASSETS_FOLDER", CLIENT_URL . '/assets');

# set css folder
define("UPLOADS_FOLDER", CLIENT_URL . '/uploads');

# set plugins folder
define("PLUGINS_FOLDER", CLIENT_URL . '/plugins');

# set templates folder
define("TEMPLATES_FOLDER", DOCUMENT_ROOT . '/templates');

# set templates folder
define("INC_FOLDER", DOCUMENT_ROOT . '/inc');

# include the base functions
require_once(INC_FOLDER . '/base_functions.inc.php');

# register the autoload function
spl_autoload_register('autoloadClass');

# start session
if (!session_id())
    session_start();

//define("DEBUG", (isAside() ? 1 : 0));
define("DEBUG", 1);
define("DEBUG_QUERIES", 0);

# error reporting
error_reporting(E_ALL | E_STRICT);
set_error_handler('error_handler', E_ALL | E_STRICT);
register_shutdown_function('shutdown_handler');

/*
 * Database connection details
 * To make a connection to an other container, make yourself some acces in 'Direct Admin' and
 * use the first letter of the user to connect. e.g. c.a-sidemedia.nl as host
 */
// client
//define("DB_HOST", "50.62.209.38");
//define("DB_USER", "msps_swap_11");
//define("DB_PASS", "Htns869@");
//define("DB_DATABASE", "msps_swap_db");
//testserver
//define("DB_HOST", "localhost");
//define("DB_USER", "dextero3_sanjeev");
//define("DB_PASS", "sanjeev@123!");
//define("DB_DATABASE", "dextero3_mountshivalik");
//local server
define("DB_HOST", "localhost");
define("DB_USER", "adminamvm");
define("DB_PASS", "admin");
define("DB_DATABASE", "demo_eschoolexpert");



//localhost
//define("DB_HOST", "localhost");
//define("DB_USER", "root");
//define("DB_PASS", "");
//define("DB_DATABASE", "mount_sp_final"); 

define("DB_PREFIX", "ms_");
define("RECORDS_PER_PAGE", 10); // records limit for all pages
// *** encrypt or not admin password true|false
define("USE_PASSWORD_ENCRYPTION", true);
// *** type of encryption - AES|MD5
define("PASSWORD_ENCRYPTION_TYPE", "MD5");
// *** password encryption key 
define("PASSWORD_ENCRYPTION_KEY", "LKD98900sfkjkkJHu0");
define("DEVELOPER_NAME", "Sanjeev Kumar"); //name of the maker
define("DEFAULT_ERROR_EMAIL", "swap.sanjeev@gmail.com");

# Current logged in user 
$oCurrentUser = http_session("oCurrentUser", null);
@$oCurrentUser->MSID != NULL ? $oCurrentSchool = Master::get_schools('', $oCurrentUser->MSID)->fetch(PDO::FETCH_OBJ) : '';
//print_r($oCurrentUser->MSID);
if (@$oCurrentUser->MSID) {
    $MSID = $oCurrentUser->MSID;
} else {
    session_unset($_SESSION);
}
if (isset($_POST['r_per_page'])) {
    $_SESSION['r_per_page'] = $_POST['r_per_page'];
}
//if(empty($_SESSION['year'])){$_SESSION['year'] = date('Y');}
/* setting user year and date to database and */
if (isset($_POST['sessionFrmYear'])) {


    UserManager::updateUserSession($_POST['year']);
    UserManager::onSessionUpdateDate($_POST['year']);
}
if (isset($_POST['sessionFrmDate'])) {

    $user_date = date("Y-m-d", strtotime($_POST['user_date']));
    UserManager::updateUserDate($user_date);
    UserManager::onDateUpdateSession($user_date);
}

//  SWITCHING CHILDRENS BY PARENTS
if (isset($_POST['children'])) {
    $_SESSION['student_id'] = $_POST['children'];
//    $url = CLIENT_URL . "/quick-search";
//
//    header('Location:' . $url);
}
if (isset($_POST['serch_frm'])) {
    $_SESSION['keyword'] = $_POST['search'];
//    print_r($_SESSION);

    $url = CLIENT_URL . "/quick-search";

    header('Location:' . $url);
}
if (isset($_POST['userFrmschool'])) {
    UserManager::updateSessionSchool($_POST['user_school']);
}
# SITE CONSTANTS
define("CLIENT_NAME", @$oCurrentSchool->name ? $oCurrentSchool->name : "Mount Shivalik Public School");
//define("CLIENT_HTTPURL", "http://development.dexterousteam.com/mountshivalik");
//define("CLIENT_HTTPSURL", "https://development.dexterousteam.com/mountshivalik");

define("CLIENT_HTTPURL", "http://localhost/mountshivalik");
define("CLIENT_HTTPSURL", "https://localhost/mountshivalik");
//define("CLIENT_HTTPURL", "http://vmosms.com/mount_shivalik");
//define("CLIENT_HTTPSURL", "https://vmosms.com/mount_shivalik");
define("DEFAULT_EMAIL_FROM", CLIENT_NAME . " <testing.swapdevelopment@gmail.com>");
define("DEFAULT_EMAIL_REPLY_TO", CLIENT_NAME . " <testing.swapdevelopment@gmail.com>");
?>