<?php

/**
  Subjects array used in homework
 * */
function subject_list()
    {
    $subjectarr = array(
        "1" => 'English',
        "2" => 'Hindi',
        "3" => 'Maths',
        "4" => 'Science',
        "5" => 'Social',
        "6" => 'EVS',
    );
    return $subjectarr;
    }

function check_privlages($add, $edit, $delete, $userID = NULL, $msid, $ad_btn_type = NULL)
    {

    if (@$userID)
        {
        $a = Role::privilages($msid, NULL, $userID)->fetch(PDO::FETCH_ASSOC);
        }
//    return CLIENT_URL;
    $data = " ";
    if (@$add && $a['p_add'] == 1)
        {
        if ($ad_btn_type != NULL)
            {
            $data .= '<button class="btn bg-olive btn-flat margin" data-target="#myModal" data-toggle="modal" type="button">' . $add . '</button>';
            }
        else
            {
            $data .= '<a class="btn bg-olive btn-flat margin" href="' . $add . '">Add New</a>';
            }
        }
    if (@$edit && $a['p_edit'] == 1)
        {
        if ($ad_btn_type != NULL)
            {
            $data .= '<a class="btn btn-info btn-flat" data-title="Edit Category" href="' . $edit . '">Edit</a>&nbsp';
            }
        else
            {
            $data .= '<a class="btn btn-info btn-flat" data-title="Edit Category" data-ms="modal" href="' . $edit . '">Edit</a>&nbsp';
            }
        }
    if (@$delete && $a['p_delete'] == 1)
        {
        $data .= '&nbsp; <a data-bb="confirm" class="btn btn-danger btn-flat" href="' . $delete . '">Delete</a>';
        }
    return $data;
    }

function check_privleges($operation = array())
    {
    if (@$operation['userID'])
        {
        $a = Role::privilages($operation['MSID'], NULL, $operation['userID'])->fetch(PDO::FETCH_ASSOC);
        }
    $tag = $operation['element'];
    if (@$operation['value']) $value = 'value="' . $operation['value'] . '"';
    if (@$operation['class']) $class = 'class="' . $operation['class'] . '"';
    if (@$operation['id']) $id = 'id="' . $operation['id'] . '"';
    if (@$operation['href']) $href = 'href="' . $operation['href'] . '"';
    $label = @$operation['label'];
    if (@$operation['name']) $name = 'name="' . @$operation['name'] . '"';
    if (@$operation['type']) $type = 'type="' . @$operation['type'] . '"';
    if (@$operation['data-target']) $data_target = 'data-target="' . @$operation['data-target'] . '"';
    if (@$operation['data-toggle']) $data_toggle = 'data-toggle="' . @$operation['data-toggle'] . '"';
    if (@$operation['data-title']) $data_title = 'data-title="' . @$operation['data-title'] . '"';
    if (@$operation['data-bb']) $data_bb = 'data-bb="' . @$operation['data-bb'] . '"';
    if (@$operation['data-ms']) $data_ms = 'data-ms="' . @$operation['data-bb'] . '"';

    $data = " ";
    if ($operation['action'] == 'add' && $a['p_add'] == 1)
        {
        if (strtolower($tag) != 'input')
            {
            $data .= '<' . $tag . ' ' . @$class . ' ' . @$name . '  ' . @$type . '  ' . @$data_target . '  ' . @$data_toggle . '   ' . @$data_bb . ' ' . @$data_title . ' ' . @$id . ' ' . @$data_title . ' ' . @$href . ' ' . @$data_ms . '>' . $label . '</' . $tag . '>&nbsp';
            }
        else
            {
            $data .= '<' . $tag . ' ' . @$value . ' ' . @$class . '  ' . @$name . '  ' . @$type . '  ' . @$data_target . '  ' . @$data_toggle . '   ' . @$data_bb . ' ' . @$data_title . ' ' . @$id . ' ' . @$data_title . ' ' . @$href . ' ' . @$data_ms . '>&nbsp';
            }
        }

    if ($operation['action'] == 'edit' && $a['p_edit'] == 1)
        {
        if (strtolower($tag) != 'input')
            {
            $data .= '<' . $tag . ' ' . @$class . '  ' . @$name . '  ' . @$type . '  ' . @$data_target . '  ' . @$data_toggle . '   ' . @$data_bb . ' ' . @$data_title . ' ' . @$id . ' ' . @$data_title . ' ' . @$href . '' . @$data_ms . '>' . $label . '</' . $tag . '>&nbsp';
            }
        else
            {
            $data .= '<' . $tag . ' ' . @$class . '  ' . @$name . '  ' . @$type . '  ' . @$data_target . '  ' . @$data_toggle . '   ' . @$data_bb . ' ' . @$data_title . ' ' . @$id . ' ' . @$data_title . ' ' . @$href . ' ' . @$data_ms . ' ' . @$value . '>&nbsp';
            }
        }
    if ($operation['action'] == 'delete' && $a['p_delete'] == 1)
        {
        if (strtolower($tag) != 'input')
            {
            $data .= '<' . $tag . ' ' . @$class . '  ' . @$name . '  ' . @$type . '  ' . @$data_target . '  ' . @$data_toggle . '   ' . @$data_bb . ' ' . @$data_title . ' ' . @$id . ' ' . @$data_title . ' ' . @$href . ' ' . @$data_ms . '>' . $label . '</' . $tag . '>&nbsp';
            }
        else
            {
            $data .= '<' . $tag . ' ' . @$class . '  ' . @$name . '  ' . @$type . '  ' . @$data_target . '  ' . @$data_toggle . '   ' . @$data_bb . ' ' . @$data_title . ' ' . @$id . ' ' . @$data_title . ' ' . @$href . ' ' . @$data_ms . ' ' . @$value . '>&nbsp';
            }
        }

    print $data;
    }

function pr($data)
    {
    echo "<pre>";
    print_r($data);
    echo "</pre>";
    }

/**
 * Boolean yes/no value dropdown array used in various forms
 */
function yes_no_dropdown()
    {
    $yesnoarr = array(
        "1" => 'Yes',
        "0" => 'No'
    );
    return $yesnoarr;
    }

// Superadmin 11        
function SuperAdminMenu()
    {
    $adminmenu = array(
        "Schools Panel" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "School" => CLIENT_URL . '/schools',
                "School Session" => CLIENT_URL . '/schools/new-session',
                "Schoo Configuration" => CLIENT_URL . '/settings'
            )
        ),
        /* "School Configurations" => array
          (
          'icon' => 'fa-graduation-cap',
          'url' => 'javascript:;',
          'submenu' => array
          (
          "Settings" => CLIENT_URL . '/settings'

          )
          ), */
        "Houses Panel" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Houses" => CLIENT_URL . '/houses'
            )
        ),
        "Users" => array
            (
            'icon' => 'fa-users',
            'url' => CLIENT_URL . '/users',
            'submenu' => array()
        ),
        "Subjects Panel" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Subjects" => CLIENT_URL . '/subjectall',
                "Subjects Group" => CLIENT_URL . '/subjectgroup',
                "School Subjects Group" => CLIENT_URL . '/school-subject-group'
            )
        ), "Subjects Panel" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Subjects" => CLIENT_URL . '/subjectall',
                "Subjects Group" => CLIENT_URL . '/subjectgroup',
                "School Subjects Group" => CLIENT_URL . '/school-subject-group'
            )
        ),
        "Error Reporting" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Tasks" => CLIENT_URL . '/tasks'
            )
        ),
        "Fee Panel" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                //"Fee type" => CLIENT_URL . '/fee-type',
//                "Fee Group" => CLIENT_URL . '/fee-group',
                "Fee Names" => CLIENT_URL . '/fee-name',
                "Fee Schedule" => CLIENT_URL . '/fee-schedule',
                "Fee Billing Genrater" => CLIENT_URL . '/fee-billing-genrater',
                "Fee" => CLIENT_URL . '/fee',
                "Fee Schedule Genrator" => CLIENT_URL . '/fee-genrator',
                "Discount" => CLIENT_URL . '/discount',
                "Discount Rules" => CLIENT_URL . '/discount-rules'
            )
        )
    );
    return $adminmenu;
    }

// School Admin 9
function school_menu()
    {
    $menuarr = array(
        "Admission" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                //"Admissions" => CLIENT_URL.'/admissions',
                "Enrollment" => CLIENT_URL . '/enrollment',
                "Selection" => CLIENT_URL . '/selection',
                "Rejection" => CLIENT_URL . '/rejected'
            )
        ),
        "Parents" => array
            (
            'icon' => 'fa-users',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Parents" => CLIENT_URL . '/parents',
                "old Parents" => CLIENT_URL . '/parents-old',
                "Add New" => CLIENT_URL . '/parents/add'
            )
        ),
        "Student" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Students" => CLIENT_URL . '/students',
                "Edit All Student" => CLIENT_URL . '/edit-all-student',
                "Alumini" => CLIENT_URL . '/students/alumini',
                "New Admissions" => CLIENT_URL . '/students/newadmission',
                "Out Going Students" => CLIENT_URL . '/students/outgoing',
                "Session Wise Strength" => CLIENT_URL . '/sessionwise',
                "Quick Search" => CLIENT_URL . '/quick-search',
                "I D Card Print" => CLIENT_URL . '/icard_print',
            //"Failed Students" => CLIENT_URL . '/students/failstudents',
            )
        ),
        "Employee" => array
            (
            'icon' => 'fa-user-plus',
            'url' => 'javascript:;',
            'submenu' => array
                ("Add New Employee" => CLIENT_URL . '/employee/add',
                "Employees" => CLIENT_URL . '/employee',
                "Old Employees" => CLIENT_URL . '/employee-old',
            )
        ), "Fees" => array
            (
            'icon' => 'fa-money',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Receive Fee' => CLIENT_URL . "/feevoucher",
//                'Receive Fee Tpt' => CLIENT_URL . "/feevoucher-tpt",
//                'Receive Fee Without Tpt' => CLIENT_URL . "/feevoucher-without-tpt",
                'Fee Structure' => CLIENT_URL . "/fee-structure",
                'Defaulters/ Advance Payer' => CLIENT_URL . "/fee-defaulter",
                'Daily Fee Collection' => CLIENT_URL . "/fee-report",
                'Fee Summary' => CLIENT_URL . "/fee-summary",
                'Fee Report Headwise' => CLIENT_URL . "/fee-headwise",
                'Monthly Fee Collection' => CLIENT_URL . "/fee-report-monthly",
                'Month wise Receivable Fee' => CLIENT_URL . "/m_receivable",
                'Year wise Receivable Fee' => CLIENT_URL . "/y_receivable",
                'Assign Discount' => CLIENT_URL . "/assign-discount",
                'Quick Receive Fee' => CLIENT_URL . "/quick-receive",
//                'yearly receivable fee' => CLIENT_URL . "/y_receivable",
//                'Fee Transaction'=>CLIENT_URL . "/fee-transaction"
            )
        ), "Examination" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                ('Activities' => CLIENT_URL . '/activities',
                'Activities Assign' => CLIENT_URL . '/activities-assign',
                'Academic Performance' => CLIENT_URL . '/academic-performance',
                'Enter Marks for a Class' => CLIENT_URL . '/enter-marks',
                'Assesments' => CLIENT_URL . '/assesments',
                'Co-Scholastic Areas' => CLIENT_URL . '/co-scholastic-areas',
                'Co-Scholastic Indicators' => CLIENT_URL . '/co-scholastic-indicators',
                'Grades' => CLIENT_URL . '/exam-grades',
                'Datesheet' => CLIENT_URL . '/datesheet',
                'Remarks' => CLIENT_URL . '/remarks',
                'Failed Students' => CLIENT_URL . '/failed-students',
                'Promoted Students' => CLIENT_URL . '/promoted-students',
                'Health Data' => CLIENT_URL . '/health-data',
                'Co-Scholastic Marks' => CLIENT_URL . '/co-scholastic-marks',
                'Result' => CLIENT_URL . '/result',
                'Subejectwise Result' => CLIENT_URL . '/subjectwise-result',
                'Consolidated Report' => CLIENT_URL . '/consolidated-report',
                'Report Card' => CLIENT_URL . '/report-cards',
                'Gradewise List' => CLIENT_URL . '/gradewise-list',
                'Question Bank' => CLIENT_URL . '/question-bank/add',
                'Question Paper Generator ' => CLIENT_URL . '/question-bank',
                'Question Bank Import' => CLIENT_URL . '/question-bank-import',
                'test-report' => CLIENT_URL . '/test-report',
            )
        ),
        "Transport" => array
            (
            'icon' => 'fa-truck',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Assign Transport" => CLIENT_URL . '/assign-transport',
                "Route Wise List" => CLIENT_URL . '/tptroutewise',
                "Routes" => CLIENT_URL . '/tptroutes',
                "TPT Stations" => CLIENT_URL . '/tptstations',
                "Transport Fee" => CLIENT_URL . '/tptfee',
//                "Vehicles" => 'javascript:;'
            )
        ),
        "Configuration" => array
            (
            'icon' => 'fa-wrench',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Settings" => CLIENT_URL . '/settings',
                "Manage Modules" => CLIENT_URL . '/modules',
                "Manage Role" => CLIENT_URL . '/role',
                "Manage Privileges" => CLIENT_URL . '/privileges',
            )
        ),
        "Attendance" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Student Attendance" => CLIENT_URL . '/attendances/today',
//                "Student Attendance" => CLIENT_URL . '/attendances',
//                "Employee " => CLIENT_URL . '/emp_attendances', 
                "Employee Attendance" => CLIENT_URL . '/emp_attendances/today',
                "Term Attendance" => CLIENT_URL . '/term-attendances',
//                "View Students" => CLIENT_URL . '/month_attendances',
                "Holidays" => CLIENT_URL . '/attendances/holidays'
            )
        ),
//        "Calendar" => array
//            (
//            'icon' => 'fa-calendar',
//            'url' => CLIENT_URL . '/event-calender',
//            'submenu' => array()
//        ),
        "Homework" => array
            (
            'icon' => 'fa-users',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "View Homework" => CLIENT_URL . '/homework',
                "Add Homework" => CLIENT_URL . '/homework/add'
            )
        ),
//        "Admin" => array
//            (
//            'icon' => 'fa-key',
//            'url' => 'javascript:;',
//            'submenu' => array
//                (
//                "Locality" => CLIENT_URL . '/locality',
//                "Category" => CLIENT_URL . '/category',
//                "Department" => CLIENT_URL . '/department',
//                "Designation" => CLIENT_URL . '/designation',
//                "Classes" => CLIENT_URL . '/msclass',
//                "Houses" => CLIENT_URL . '/houses',
//                "Discounted Students" => CLIENT_URL . '/discounted-students',
//                "Assign Discount" => CLIENT_URL . '/assign-discount',
////                "Subjects" => CLIENT_URL . '/subject',
//            )
//        ),
        "Library" => array
            (
            'icon' => 'fa-newspaper-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Library List" => CLIENT_URL . '/library/list',
                "Categories" => CLIENT_URL . '/library/cat',
                "Books" => CLIENT_URL . '/library/book',
                "Issue new Book" => CLIENT_URL . '/library/issue',
                "Returned Book" => CLIENT_URL . '/library/return',
                "Issued Books" => CLIENT_URL . '/library/due',
            )
        ),
        "Users" => array
            (
            'icon' => 'fa-users',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Users" => CLIENT_URL . '/users'
            )
        ),
        "Time Table" => array
            (
            'icon' => 'fa-adjust',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Class Time Table" => CLIENT_URL . '/timetable-classwise',
                "Teachers Time Table" => CLIENT_URL . '/timetable-teachers',
                "Master Time Table" => CLIENT_URL . '/master-timetable',
            )
        ),
        "Hostels" => array
            (
            'icon' => 'fa-home',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Hostels' => CLIENT_URL . '/hostels',
                'Hostelers' => CLIENT_URL . '/hostelers'
            )
        ),
//        "Finance" => array
//            (
//            'icon' => 'fa-database',
//            'url' => 'javascript:;',
//            'submenu' => array
//                (
//                'Masters' => "javascript:;",
//                'Transactions' => "javascript:;",
//                'Balancesheet' => "javascript:;",
//                'Quick Reports' => "javascript:;",
//                'Settings' => "javascript:;"
//            )
//        ),
//        "Utility" => array
//            (
//            'icon' => 'fa-cogs',
//            'url' => 'javascript:;',
//            'submenu' => array
//                (
//                "Events" => 'javascript:;',
//                "Albums" => 'javascript:;'
//            )
//        ),
        "Security Features" => array
            (
            'icon' => 'fa-cogs',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Security Cameras" => CLIENT_URL . '/security',
                "GPS Trackers" => CLIENT_URL . '/security/gps'
            )
        ),
        "SMS" => array
            (
            'icon' => 'fa-cogs',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "SMS" => CLIENT_URL . '/sms',
                "Templates" => CLIENT_URL . '/sms-template',
                "Keywords" => CLIENT_URL . '/sms-keyword',
            )
        ),
        "Reports" => array
            (
            'icon' => 'fa-cogs',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Discounted Students" => CLIENT_URL . '/discounted-students',
                "Opening Balance" => CLIENT_URL . '/opening-bal'
            )
        ),
        "Chat" => array
            (
            'icon' => 'fa-weixin',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Chat" => CLIENT_URL . '/chat_inbox',
            )
        ),
    );
    return $menuarr;
    }

// accountant  8
function accountant_menu()
    {
    $menuarr = array(
        "Admission" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                //"Admissions" => CLIENT_URL.'/admissions',
                "Enrollment" => CLIENT_URL . '/enrollment',
                "Selection" => CLIENT_URL . '/selection',
                "Rejection" => CLIENT_URL . '/rejected'
            )
        ),
        "Student" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Students" => CLIENT_URL . '/students',
                "Alumini" => CLIENT_URL . '/students/alumini',
                "New Admissions" => CLIENT_URL . '/students/newadmission',
                "Out Going Students" => CLIENT_URL . '/students/outgoing',
                "Session Wise Strength" => CLIENT_URL . '/sessionwise',
                "Quick Search" => CLIENT_URL . '/quick-search',
            //"Failed Students" => CLIENT_URL . '/students/failstudents',
            )
        ),
        "Employee" => array
            (
            'icon' => 'fa-user-plus',
            'url' => 'javascript:;',
            'submenu' => array
                ("Add New Employee" => CLIENT_URL . '/employee/add',
                "Employees" => CLIENT_URL . '/employee',
                "Old Employees" => CLIENT_URL . '/employee-old',
            )
        ), "Fees" => array
            (
            'icon' => 'fa-money',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Receive Fee' => CLIENT_URL . "/feevoucher",
//                'Receive Fee Tpt' => CLIENT_URL . "/feevoucher-tpt",
//                'Receive Fee Without Tpt' => CLIENT_URL . "/feevoucher-without-tpt",
                'Fee Structure' => CLIENT_URL . "/fee-structure",
                'Defaulters/ Advance Payer' => CLIENT_URL . "/fee-defaulter",
                'Daily Fee Collection' => CLIENT_URL . "/fee-report",
                'Fee Summary' => CLIENT_URL . "/fee-summary",
                'Fee Report Headwise' => CLIENT_URL . "/fee-headwise",
//                'Fee Transaction'=>CLIENT_URL . "/fee-transaction"
            )
        ), "Examination" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Academic Performance' => CLIENT_URL . '/academic-performance',
                'Co-Scholastic Marks' => CLIENT_URL . '/co-scholastic-marks',
                'Health Data' => CLIENT_URL . '/health-data',
                'Remarks' => CLIENT_URL . '/remarks',
                'Consolidated Report' => CLIENT_URL . '/consolidated-report',
                'Report Card' => CLIENT_URL . '/report-cards',
            )
        ),
        "Transport" => array
            (
            'icon' => 'fa-truck',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Route Wise List" => CLIENT_URL . '/tptroutewise',
                "Routes" => CLIENT_URL . '/tptroutes',
                "TPT Stations" => CLIENT_URL . '/tptstations',
                "Transport Fee" => CLIENT_URL . '/tptfee',
            )
        ),
        "Attendance" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Today Attendance" => CLIENT_URL . '/attendances/today',
                "Student Attendance" => CLIENT_URL . '/attendances',
                "Employee Attendance" => CLIENT_URL . '/emp_attendances',
                "Term Attendance" => CLIENT_URL . '/term-attendances',
                "Holidays" => CLIENT_URL . '/attendances/holidays'
            )
        ),
        "Library" => array
            (
            'icon' => 'fa-newspaper-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Categories" => CLIENT_URL . '/library/cat',
                "Books" => CLIENT_URL . '/library/book',
                "Issue new Book" => CLIENT_URL . '/library/issue',
                "Returned Book" => CLIENT_URL . '/library/return',
                "Issued Books" => CLIENT_URL . '/library/due',
            )
        ),
        "Hostels" => array
            (
            'icon' => 'fa-home',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Hostels' => CLIENT_URL . '/hostels',
                'Hostelers' => CLIENT_URL . '/hostelers'
            )
        ),
    );
    return $menuarr;
    }

// clerck  7
function cleark_menu()
    {
    $menuarr = array(
        "Admission" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                //"Admissions" => CLIENT_URL.'/admissions',
                "Enrollment" => CLIENT_URL . '/enrollment',
                "Selection" => CLIENT_URL . '/selection',
                "Rejection" => CLIENT_URL . '/rejected'
            )
        ),
        "Student" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Students" => CLIENT_URL . '/students',
                "Alumini" => CLIENT_URL . '/students/alumini',
                "New Admissions" => CLIENT_URL . '/students/newadmission',
                "Out Going Students" => CLIENT_URL . '/students/outgoing',
                "Session Wise Strength" => CLIENT_URL . '/sessionwise',
                "Quick Search" => CLIENT_URL . '/quick-search',
            //"Failed Students" => CLIENT_URL . '/students/failstudents',
            )
        ),
        "Employee" => array
            (
            'icon' => 'fa-user-plus',
            'url' => 'javascript:;',
            'submenu' => array
                ("Add New Employee" => CLIENT_URL . '/employee/add',
                "Employees" => CLIENT_URL . '/employee',
                "Old Employees" => CLIENT_URL . '/employee-old',
            )
        ), "Examination" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Academic Performance' => CLIENT_URL . '/academic-performance',
                'Co-Scholastic Marks' => CLIENT_URL . '/co-scholastic-marks',
                'Health Data' => CLIENT_URL . '/health-data',
                'Remarks' => CLIENT_URL . '/remarks',
                'Consolidated Report' => CLIENT_URL . '/consolidated-report',
                'Report Card' => CLIENT_URL . '/report-cards',
            )
        ),
        "Transport" => array
            (
            'icon' => 'fa-truck',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Route Wise List" => CLIENT_URL . '/tptroutewise',
                "Routes" => CLIENT_URL . '/tptroutes',
                "TPT Stations" => CLIENT_URL . '/tptstations',
                "Transport Fee" => CLIENT_URL . '/tptfee',
            )
        ),
        "Attendance" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Today Attendance" => CLIENT_URL . '/attendances/today',
                "Student Attendance" => CLIENT_URL . '/attendances',
                "Employee Attendance" => CLIENT_URL . '/emp_attendances',
                "Term Attendance" => CLIENT_URL . '/term-attendances',
                "Holidays" => CLIENT_URL . '/attendances/holidays'
            )
        ),
        "Library" => array
            (
            'icon' => 'fa-newspaper-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Categories" => CLIENT_URL . '/library/cat',
                "Books" => CLIENT_URL . '/library/book',
                "Issue new Book" => CLIENT_URL . '/library/issue',
                "Returned Book" => CLIENT_URL . '/library/return',
                "Issued Books" => CLIENT_URL . '/library/due',
            )
        ),
        "Hostels" => array
            (
            'icon' => 'fa-home',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Hostels' => CLIENT_URL . '/hostels',
                'Hostelers' => CLIENT_URL . '/hostelers'
            )
        ),
    );
    return $menuarr;
    }

// librarian 5
function LibraryMenu()
    {
    $menuarr = array(
        "My Profile" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "My Profile" => CLIENT_URL . '/students',
            )
        ),
        "Time Table" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Class Time Table" => CLIENT_URL . '/timetable-classwise',
                "Teachers Time Table" => CLIENT_URL . '/timetable-teachers',
            )
        ),
        "Attendence" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "My Attendence" => CLIENT_URL . '/students',
            )
        ),
        "Student" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Students" => CLIENT_URL . '/students',
                "Alumini" => CLIENT_URL . '/students/alumini',
                "New Admissions" => CLIENT_URL . '/students/newadmission',
                "Quick Search" => CLIENT_URL . '/quick-search',
            )
        ),
        "Examination" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Academic Performance' => CLIENT_URL . '/academic-performance',
                'Co-Scholastic Marks' => CLIENT_URL . '/co-scholastic-marks',
                'Health Data' => CLIENT_URL . '/health-data',
                'Remarks' => CLIENT_URL . '/remarks',
                'Consolidated Report' => CLIENT_URL . '/consolidated-report',
                'Report Card' => CLIENT_URL . '/report-cards',
            )
        ),
        "Attendance" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Today Attendance" => CLIENT_URL . '/attendances/today',
                "Student Attendance" => CLIENT_URL . '/attendances',
                "Employee Attendance" => CLIENT_URL . '/emp_attendances',
                "Term Attendance" => CLIENT_URL . '/term-attendances',
                "Holidays" => CLIENT_URL . '/attendances/holidays'
            )
        ), "Library" => array
            (
            'icon' => 'fa-newspaper-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Library List" => CLIENT_URL . '/library/list',
                "Categories" => CLIENT_URL . '/library/cat',
                "Books" => CLIENT_URL . '/library/book',
                "Issue new Book" => CLIENT_URL . '/library/issue',
                "Returned Book" => CLIENT_URL . '/library/return',
                "Issued Books" => CLIENT_URL . '/library/due',
            )
        )
    );
    return $menuarr;
    }

// teacher 3
function teacher_menu()
    {
    $menuarr = array(
        "Profile" => array
            (
            'icon' => 'fa-user',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Profile" => CLIENT_URL . '/profile',
            )
        ),
        "Time Table" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Class Time Table" => CLIENT_URL . '/class-timetable',
            //"Teachers Time Table" => CLIENT_URL . '/timetable-teachers',
            )
        ),
        "Attendence" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Attendence" => CLIENT_URL . '/attendence',
                "Student Attendance" => CLIENT_URL . '/attendances/today',
            )
        ),
        "Home Work" => array
            (
            'icon' => 'fa-graduation-cap',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Assign Home Work" => CLIENT_URL . '/homework-assign',
                "Home Work List" => CLIENT_URL . '/homework-list',
            )
        ),
        "Examination" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
//                'Academic Performance' => CLIENT_URL . '/academic-performance',
                'Co-Scholostic' => CLIENT_URL . '/co-scholastic',
                'Consolidated Report' => CLIENT_URL . '/consolidated-report',
                'Health Data' => CLIENT_URL . '/health-data',
                'Remarks' => CLIENT_URL . '/remarks',
                'Results' => CLIENT_URL . '/exam-results',
                'Exam Schedule' => CLIENT_URL . '/exam-schedule',
                'Term Attendance' => CLIENT_URL . '/term-attendance',
            )
        ),
        "Salary Details" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                'Salary Slips' => CLIENT_URL . '/salary-slips',
                'Paid Salary' => CLIENT_URL . '/paid-salary'
            )
        ),
        "Leaves" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Apply" => CLIENT_URL . '/apply-leave',
                "History" => CLIENT_URL . '/leave-history',
            )
        ),
        "Chat" => array
            (
            'icon' => 'fa-weixin',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Chat" => CLIENT_URL . '/chat_inbox',
            )
        ),
    );
    return $menuarr;
    }

// Parent 2
function ParentMenu()
    {
        {
        $menuarr = array(
            "profile" => array
                (
                'icon' => 'fa-user',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Profile" => CLIENT_URL . '/profile',
                )
            ),
            "Time Table" => array
                (
                'icon' => 'fa-calendar-o',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Time Table" => CLIENT_URL . '/timetable',
                )
            ),
            "Class Mates" => array
                (
                'icon' => 'fa-users',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Class Mates" => CLIENT_URL . '/classmates',
                )
            ),
            "Teachers" => array
                (
                'icon' => 'fa-users',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Teachers" => CLIENT_URL . '/teachers',
                )
            ),
            "Notification" => array
                (
                'icon' => 'fa-bell',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Notification" => CLIENT_URL . '/notification',
                )
            ),
            "Attendance" => array
                (
                'icon' => 'fa-pencil-square-o',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Attendance" => CLIENT_URL . '/attendance',
                )
            ),
            "Calendar" => array
                (
                'icon' => 'fa-calendar-o',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Calendar" => CLIENT_URL . '/calendar',
                )
            ),
            "Library" => array
                (
                'icon' => 'fa-book',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Library" => CLIENT_URL . '/library',
                )
            ),
            "Examination" => array
                (
                'icon' => 'fa-file',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Examination" => CLIENT_URL . '/examination',
                )
            ),
            "Assignment" => array
                (
                'icon' => 'fa-file-word-o',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Assignment" => CLIENT_URL . '/assignment',
                )
            ),
            "Question Bank" => array
                (
                'icon' => 'fa-question-circle',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Question Bank" => CLIENT_URL . '/questionbank',
                )
            ),
            "Notice Board" => array
                (
                'icon' => 'fa-newspaper-o',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Notice Board" => CLIENT_URL . '/noticeboard',
                )
            ),
            "Homework" => array
                (
                'icon' => 'fa-book',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "View Homework" => CLIENT_URL . '/homework',
                //"Add Homework" => CLIENT_URL . '/Homework/Add'
                )),
            "Fee AC" => array
                (
                'icon' => 'fa-money',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Fee AC" => CLIENT_URL . '/feeaccount',
                )
            ),
            "Report Card" => array
                (
                'icon' => 'fa-file-text-o',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Report Card" => CLIENT_URL . '/reportcard',
                    "hyap" => CLIENT_URL . '/HYAP'
                )
            ),
            "Chat" => array
                (
                'icon' => 'fa-weixin',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Chat" => CLIENT_URL . '/chat_inbox',
                )
            ),
            "Change Password" => array
                (
                'icon' => 'fa-key',
                'url' => 'javascript:;',
                'submenu' => array
                    (
                    "Change Password" => CLIENT_URL . '/changepassword',
                )
            ),
        );
        return $menuarr;
        }
    }

// student  
function StudentMenu()
    {
    $menuarr = array(
        "profile" => array
            (
            'icon' => 'fa-user',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Profile" => CLIENT_URL . '/profile',
            )
        ),
        "Time Table" => array
            (
            'icon' => 'fa-calendar-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Time Table" => CLIENT_URL . '/timetable',
            )
        ),
        "Class Mates" => array
            (
            'icon' => 'fa-users',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Class Mates" => CLIENT_URL . '/classmates',
            )
        ),
        "Teachers" => array
            (
            'icon' => 'fa-users',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Teachers" => CLIENT_URL . '/teachers',
            )
        ),
        "Notification" => array
            (
            'icon' => 'fa-bell',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Notification" => CLIENT_URL . '/notification',
            )
        ),
        "Attendance" => array
            (
            'icon' => 'fa-pencil-square-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Attendance" => CLIENT_URL . '/attendance',
            )
        ),
        "Calendar" => array
            (
            'icon' => 'fa-calendar-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Calendar" => CLIENT_URL . '/calendar',
            )
        ),
        "Library" => array
            (
            'icon' => 'fa-book',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Library" => CLIENT_URL . '/library',
            )
        ),
        "Examination" => array
            (
            'icon' => 'fa-file',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Examination" => CLIENT_URL . '/examination',
                "Exam Tips" => CLIENT_URL . '/exam-tips',
                "Term Assesment" => CLIENT_URL . '/term-assesment',
                "Test Report" => CLIENT_URL . '/class-test-report',
            )
        ),
        "Assignment" => array
            (
            'icon' => 'fa-file-word-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Assignment" => CLIENT_URL . '/assignment',
            )
        ),
        "Question Bank" => array
            (
            'icon' => 'fa-question-circle',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Question Bank" => CLIENT_URL . '/questionbank',
            )
        ),
        "Notice Board" => array
            (
            'icon' => 'fa-newspaper-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Notice Board" => CLIENT_URL . '/noticeboard',
            )
        ),
        "Homework" => array
            (
            'icon' => 'fa-book',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "View Homework" => CLIENT_URL . '/homework',
            //"Add Homework" => CLIENT_URL . '/Homework/Add'
            )),
        "Fee AC" => array
            (
            'icon' => 'fa-money',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Fee AC" => CLIENT_URL . '/feeaccount',
            )
        ),
        "Report Card" => array
            (
            'icon' => 'fa-file-text-o',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Report Card" => CLIENT_URL . '/reportcard',
                "hyap" => CLIENT_URL . '/HYAP'
            )
        ),
        "Change Password" => array
            (
            'icon' => 'fa-key',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Change Password" => CLIENT_URL . '/changepassword',
            )
        ),
        "Chat" => array
            (
            'icon' => 'fa-weixin',
            'url' => 'javascript:;',
            'submenu' => array
                (
                "Chat" => CLIENT_URL . '/chat_inbox',
            )
        ),
    );
    return $menuarr;
    }

/**
 * Qualification drop down
 */
function days_name($val)
    {
    $arrWeek = array("", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
    return $arrWeek[$val];
    }

function days_name_short($val)
    {
    $arrWeek = array("", "M", "T", "W", "Th", "F", "S", "Su");
    return $arrWeek[$val];
    }

function get_role_name($role)
    {
    $role_level = array("", "Student", "Parent", "Teacher", "", "librarian", "", "Cleark", "Accountant", "School", "", "Superadmin");
    return $role_level[$role];
    }

function qualifications()
    {
    $yesnoarr = array("Under Matric", "Matriculate", "10+2", "Post Graduate", "Ph.d",
        "Graduate", "M.Phil", "MBBS", "B.A.", "M.A.", "B.E.", "M.E.", "M.B.A", "M.Sc.");
    return $yesnoarr;
    }

function religion()
    {
    $relarr = array("Hindu", "Sikh", "Muslim", "Christian");
    return $relarr;
    }

function annual_income()
    {
    $anualarr = array("Below 60000", "60000 to 2 Lac", "2 Lac to 5 Lac", "above 5 Lac");
    return $anualarr;
    }

function f_occupation()
    {
    $foccarr = array("Agriculture", "Govt.Service", "Private Job", "Business", "Staff");
    return $foccarr;
    }

function m_occupation()
    {
    $moccarr = array("House Wife", "Govt.Service", "Private Job", "Business", "Staff");
    return $moccarr;
    }

function classes_list()
    {
    $classesarr = array(
        "-2" => 'Pre Nur',
        "-1" => 'Nur',
        "0" => 'Kg',
        "1" => '1st',
        "2" => '2nd',
        "3" => '3rd',
        "4" => '4th',
        "5" => '5th',
        "6" => '6th',
        "7" => '7th',
        "8" => '8th',
        "9" => '9th',
        "10" => '10th',
        "11" => '11th',
        "12" => '12th'
    );
    return $classesarr;
    }

function section_list()
    {
    $sectionarr = array(
        "1" => 'A',
        "2" => 'B',
        "3" => 'C',
        "4" => 'D',
        "5" => 'F',
        "6" => 'G',
        "7" => 'H',
        "8" => 'I',
        "9" => 'J',
        "10" => 'K',
    );
    return $sectionarr;
    }

/**
 * schools months according to start date and end date
 *
 */
function school_months($startDate, $endDate)
    {
    $start = strtotime($startDate);
    $end = strtotime($endDate);
    $result = array();
    $countm = 1;
    while ($start <= $end)
        {
        $month = date("F", $start);
        if (!in_array($month, $result))
            {
            $result[$countm] = $month;
            $countm++;
            }
        $start += 86400;
        }
    return $result;
    }

/**
 * Basic functions for all needs
 * @param String $sClassName name of class that should be autoloaded
 */
/* auto load class by name */

function autoloadClass($sClassName)
    {

    $sFileName = CLASSES_FOLDER . "/" . $sClassName . ".class.php";

    if (file_exists($sFileName)) include_once($sFileName);
    else throw new Exception("File '$sFileName' doesn't exist");
    }

/**
 * check if a class could be loaded
 * @param String $sClassName name of class that should be autoloaded
 * @return Boolean true,false
 */
function classCouldBeLoaded($sClassName)
    {
    try
        {
        class_exists($sClassName, true);
        return true;
        }
    catch (Exception $e)
        {
        return false;
        }
    }

/**
 * Dump variables to the screen or return result
 * @param string $mValue value to dump
 * @param boolean $bShowHTML do uses htmlentities
 * @param boolean $sReturnResult return value rather than printing it
 */
function _d($mValue, $bShowHTML = true, $sReturnResult = false)
    {

    $sDump = "<pre>";
    if ($bShowHTML === true)
        {
        $sDump .= htmlentities(print_r($mValue, 1));
        }
    else
        {
        $sDump .= print_r($mValue, 1);
        }
    $sDump .= "</pre>";

    if ($sReturnResult)
        {
        return $sDump;
        }
    else
        {
        echo $sDump;
        }
    }

/**
 * Get a value from the $_GET Array
 * @param String $sKey
 * @param Mixed $mDefault
 * @return Mixed
 */
function http_get($sKey, $mDefault = null)
    {
    return array_key_exists($sKey, $_GET) ? $_GET[$sKey] : $mDefault;
    }

/**
 * Get a value from the $_POST Array
 * @param String $sKey
 * @param Mixed $mDefault
 * @return Mixed
 */
function http_post($sKey, $mDefault = null)
    {
    return array_key_exists($sKey, $_POST) ? $_POST[$sKey] : $mDefault;
    }

/**
 * Get a value from the $_SESSION Array
 * @param String $sKey
 * @param Mixed $mDefault
 * @return Mixed
 */
function http_session($sKey, $mDefault = null)
    {
    if (!$_SESSION)
        {
        return $mDefault;
        }
    return array_key_exists($sKey, $_SESSION) ? $_SESSION[$sKey] : $mDefault;
    }

/**
 * Get a value from the $_COOKIE Array
 * @param String $sKey
 * @param Mixed $mDefault
 * @return Mixed
 */
function http_cookie($sKey, $mDefault = null)
    {
    return array_key_exists($sKey, $_COOKIE) ? $_COOKIE[$sKey] : $mDefault;
    }

/**
 * redirect to a given location and stop script from executing
 * @param $sRedirectURL  URL to redirect to
 * @param Boolean $bUtm (true to keep Google Analytics UTM parameters working)
 */
function http_redirect($sRedirectURL, $bUtm = false, $b301 = false)
    {
    if ($bUtm)
        {
        if (http_get('utm_source') && !strpos($url, 'utm_source='))
            {
            $sRedirectURL .= (strpos($sRedirectURL, '?') ? '&' : '?') . 'utm_source=' . http_get('utm_source');
            }
        if (http_get('utm_medium') && !strpos($sRedirectURL, 'utm_medium='))
            {
            $sRedirectURL .= (strpos($sRedirectURL, '?') ? '&' : '?') . 'utm_medium=' . http_get('utm_medium');
            }
        if (http_get('utm_campaign') && !strpos($sRedirectURL, 'utm_campaign='))
            {
            $sRedirectURL .= (strpos($sRedirectURL, '?') ? '&' : '?') . 'utm_campaign=' . http_get('utm_campaign');
            }
        if (http_get('utm_term') && !strpos($sRedirectURL, 'utm_term='))
            {
            $sRedirectURL .= (strpos($sRedirectURL, '?') ? '&' : '?') . 'utm_term=' . http_get('utm_term');
            }
        if (http_get('utm_content') && !strpos($sRedirectURL, 'utm_content='))
            {
            $sRedirectURL .= (strpos($sRedirectURL, '?') ? '&' : '?') . 'utm_content=' . http_get('utm_content');
            }
        }
    if ($b301) header("HTTP/1.1 301 Moved Permanently");
    header("Location: " . $sRedirectURL);
    die();
    }

/**
 * Make a given part of a URL a pretty (SEO friendly) look
 * @param String $sUrlPart
 * @param String $bConvertToUTF8 convert $sUrlPart to UTF-8
 * @return String (SEO friendly) pretty URL part
 */
function prettyUrlPart($sUrlPart, $bConvertToUTF8 = false)
    {

    if ($bConvertToUTF8)
        {
        $sUrlPart = utf8_encode($sUrlPart);
        }

    $sUrlPart = htmlentities($sUrlPart, ENT_COMPAT, "UTF-8", false); //make HTMLentities to remove accents
    $sUrlPart = preg_replace('#&szlig;#i', 'ss', $sUrlPart); //replace `ß` for `ss` (next row is not enough, replaces `ß` for `sz`)
    $sUrlPart = preg_replace('#&([a-z]{1,2})(?:acute|lig|grave|ring|tilde|uml|cedil|caron);#i', '\1', $sUrlPart); //remove accents
    $sUrlPart = html_entity_decode($sUrlPart, ENT_COMPAT, "UTF-8"); //decode to normal character again

    $sUrlPart = str_replace('\'', '', $sUrlPart); //remove all single quotes
    $sUrlPart = preg_replace('#[^a-z0-9-]+#i', '-', $sUrlPart); //replace all non alphanumeric characters and hyphens, with a hyphen
    $sUrlPart = preg_replace('#-+#', '-', $sUrlPart); //remove all double hyphens
    $sUrlPart = trim($sUrlPart, '-'); //remove hyphens at beginning and end of string

    $sUrlPart = strtolower($sUrlPart); //string to lower case characters
    return $sUrlPart;
    }

/**
 * prepend a given string with http:// if necessary (optionally keeps HTTPS in tact)
 * @param string $sValue (www.google.nl or http://www.google.nl or https://www.google.nl)
 * @param boolean $bForceHttp
 * @return string 
 */
function addHttp($sValue, $bForceHttp = false)
    {
    if (!preg_match("#^http(s)?:\/\/#", $sValue) && $sValue)
        {
        $sValue = "http://" . $sValue;
        }
    if ($bForceHttp)
        {
        return preg_replace('#^(https://)#i', 'http://', $sValue);
        }
    return $sValue;
    }

/**
 * prepend a given string with https:// if necessary (optionally keeps HTTP in tact)
 * @param string $sValue (www.google.nl or http://www.google.nl or https://www.google.nl)
 * @param boolean $bForceHttps
 * @return string 
 */
function addHttps($sValue, $bForceHttps = false)
    {
    if (!preg_match("#^http(s)?:\/\/#", $sValue) && $sValue)
        {
        $sValue = "https://" . $sValue;
        }
    if ($bForceHttps)
        {
        return preg_replace('#^(http://)#i', 'https://', $sValue);
        }
    return $sValue;
    }

/* show http error page */

function showHttpError($iErrorNr)
    {
    include_once DOCUMENT_ROOT . "/controllers/errors.cont.php";
    die();
    }

/**
 * returns the current url
 * @return string
 */
function getCurrentUrl()
    {
    $sUrl = 'http';
    $bIsHTTPS = false;
    if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == 'on')
        {
        $bIsHTTPS = true;
        $sUrl .= 's';
        }
    $sUrl .= '://';
    $sUrl .= isset($_SERVER["SERVER_NAME"]) ? $_SERVER["SERVER_NAME"] : '';

    if (isset($_SERVER["SERVER_PORT"]) && (!$bIsHTTPS && $_SERVER["SERVER_PORT"] != '80') || ($bIsHTTPS && $_SERVER["SERVER_PORT"] != '443'))
        {
        $sUrl .= ':' . $_SERVER["SERVER_PORT"];
        }

    $sUrl .= isset($_SERVER["REQUEST_URI"]) ? $_SERVER["REQUEST_URI"] : '';
    return $sUrl;
    }

function curPageURL()
    {
    $isHTTPS = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on");
    $port = (isset($_SERVER["SERVER_PORT"]) && ((!$isHTTPS && $_SERVER["SERVER_PORT"] != "80") || ($isHTTPS && $_SERVER["SERVER_PORT"] != "443")));
    $port = ($port) ? ':' . $_SERVER["SERVER_PORT"] : '';
    $url = ($isHTTPS ? 'https://' : 'http://') . $_SERVER["SERVER_NAME"] . $port . $_SERVER["REQUEST_URI"];
    return $url;
    }

/**
 * return relative url path of the current page without extension optional with querystring
 * @param Boolean $bWithQRS also keep query string attached
 * @return string
 */
function getCurrentUrlPath($bWithQRS = false, $bWithExtension = false)
    {
    $sCurrentUrlPath = $_SERVER['REQUEST_URI'];

    return cleanUrlPath($sCurrentUrlPath, $bWithQRS, $bWithExtension);
    }

/**
 * cleans url path from extension and or querystring and slash at the end
 * @param string $sUrlPath relative path of the url after the domain name starting with slash
 * @param boolean $bWithQRS keep qrystring
 * @param boolean $bWithExtension keep extension
 * @return string
 */
function cleanUrlPath($sUrlPath, $bWithQRS = false, $bWithExtension = false)
    {

# cut urlPart in pieces
    preg_match("/^([^\?\&\.]*)([^\?\&]*)(.*)$/", $sUrlPath, $aMatches);

    $sUrlPath = $aMatches[0];
    $sUrlPathClean = $aMatches[1];
    $sExtension = $aMatches[2];
    $sQRYString = $aMatches[3];

# part needs to start with a slash
    if (!preg_match("#^\/#", $sUrlPathClean))
        {
        $sUrlPathClean = "/" . $sUrlPathClean;
        }

# remove slash at the end
    if (preg_match("#\/$#", $sUrlPathClean))
        {
        $sUrlPathClean = substr($sUrlPathClean, 0, -1); // remove slash at end
        }

# add extension
    if ($bWithExtension)
        {
        $sUrlPathClean .= $sExtension;
        }

# add QRYString
    if ($bWithQRS)
        {
        $sUrlPathClean .= $sQRYString;
        }

#if empty, add slash
    if (empty($sUrlPathClean)) $sUrlPathClean = '/';

    return $sUrlPathClean;
    }

/**
 * remove query string
 * @param string $sUrlPart
 * @return string
 */
function format($data)
    {
    echo ucwords(strtolower($data));
    }

function removeQRYStringFromUrlPath($sUrlPath)
    {
    if (preg_match("/([^\?\&]*)[\?\&]/", $sUrlPath, $aMatches))
        {
        $sUrlPath = $aMatches[1];
        }
    return $sUrlPath;
    }

/**
 * prepare password for database with sha 512
 * @param string $sPass (passwordt to prepare)
 * @return string hashed and max 100 chars
 */
function hashPasswordForDb($sPass)
    {
    return substr(hash('sha512', $sPass), 0, 100);
    }

function hashpassword($password)
    {
    if (USE_PASSWORD_ENCRYPTION)
        {

        if (PASSWORD_ENCRYPTION_TYPE == 'AES')
            {
            $password = AES_ENCRYPT($password, PASSWORD_ENCRYPTION_KEY);
            }
        else
            {
            $password = MD5($password);
            }
        }
    else
        {
        $password = $password;
        }
    return $password;
    }

/**
 * Generate HTML code for displaying pagination
 * @param int $iPageCount total amount of pages
 * @param int $iCurrPage curent page number
 * @param string $sURLFormat the url to place in de <a href="$sURLFormat"></a>, page number must be placed by %s
 * @param string $iPrevPage string to represent the previous page link/button
 * @param string $iNextPage string to represent the next page link/button
 * @param int $iPageOffsetBef amount of pages shown before the current page
 * @param int $iPageOffsetAft amount of pages shown after the current page
 * @param int $sDotSep seperator between pageLinks
 * @return string
 */
function generatePaginationHTML($iPageCount, $iCurrPage, $sURLFormat = '?page=%s', $iPrevPage = '&lt;', $iNextPage = '&gt;', $iPageOffsetBef = 2, $iPageOffsetAft = 2, $sDotSep = '&hellip;')
    {
    $sHtml = '';
    if ($iPageCount > 1)
        {

        /* if difference between (currPage-offset-1) equals 2, make offset one larger */
        if (($iCurrPage - $iPageOffsetBef - 1) == 2)
            {
            $iPageOffsetBef += 1;
            }

        /* if difference between (currPage+offset-lastPage) equals 2, make offset one larger */
        if (($iPageCount - ($iCurrPage + $iPageOffsetAft)) == 2)
            {
            $iPageOffsetAft += 1;
            }

        $sHtml .= '<div class="pagination">';

        if ($iCurrPage > 1) $sHtml .= '<a class="prevPage" href="' . sprintf($sURLFormat, ($iCurrPage - 1)) . '">' . $iPrevPage . '</a>';

        if (($iCurrPage - 1) > $iPageOffsetBef)
            {
            $sHtml .= '<a class="firstPage" href="' . sprintf($sURLFormat, "1") . '">1</a>';
            if (($iCurrPage - $iPageOffsetBef) > 2) $sHtml .= '<span class="dotSep">' . $sDotSep . '</span>';
            }

        /* for loop to make links around current page */
        $iOffsetCounter = (-$iPageOffsetBef); //extra counter for offset counting

        for ($i = ($iCurrPage - $iPageOffsetBef); $i <= ($iCurrPage + $iPageOffsetAft); $i++)
            {
            if ($i >= 1 && $i <= ($iPageCount))
                {
                if ($i != $iCurrPage)
                    {
                    $sHtml .= '<a class="pageLink offset' . $iOffsetCounter . '" href="' . sprintf($sURLFormat, $i) . '">' . $i . '</a>';
                    }
                else $sHtml .= '<span class="currPage">' . $i . '</span>';
                }
            $iOffsetCounter++;
            }

        if (($iCurrPage + $iPageOffsetAft) < $iPageCount)
            {
            if (($iCurrPage + $iPageOffsetAft) < ($iPageCount - 1))
                {
                $sHtml .= '<span class="dotSep">' . $sDotSep . '</span>';
                }
            $sHtml .= '<a class="lastPage" href="' . sprintf($sURLFormat, $iPageCount) . '">' . $iPageCount . '</a>';
            }


        if ($iCurrPage < $iPageCount) $sHtml .= '<a class="nextPage" href="' . sprintf($sURLFormat, ($iCurrPage + 1)) . '">' . $iNextPage . '</a>';


        $sHtml .= '</div>';
        }
    return $sHtml;
    }

/**
 * check if string is a valid password
 * minimal 8 characters, 1 uppercase, 1 digit, 1 special character
 * @return boolean
 */
function isValidPassword($sPass)
    {
    return preg_match('#^.*(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\W])(?=.*[\d]).*$#', $sPass);
    }

/**
 * remove a directory and all in it
 * @param string $sPath
 */
function emptyAndRemoveDir($sPath)
    {
    if (empty($sPath))
        {
        return false;
        }
    else
        {
        $sPath = preg_replace('#(/)$#i', '', $sPath); // remove slash if has one
        if (!$rDir = @opendir($sPath)) return false;
        while (false !== ($sFileDir = @readdir($rDir)))
            {
            # not a file name, continue
            if ($sFileDir == '.' || $sFileDir == '..') continue;
            # try to unlink, otherwise, try to empty
            if (!@unlink($sPath . '/' . $sFileDir)) emptyAndRemoveDir($sPath . '/' . $sFileDir, true);
            }

        # close dir
        @closedir($rDir);

        # remove dir
        @rmdir($sPath);
        }
    }

/**
 * check if IP addres is aside
 */
function isAside()
    {
    return $_SERVER['REMOTE_ADDR'] == '37.0.81.193';
    }

/**
 * check if IP addres is client IP
 */
function isClient()
    {
    return in_array($_SERVER['REMOTE_ADDR'], explode(',', CLIENT_IP));
    }

/**
 * handle PHP errors
 * @param int $iErrorno
 * @param string $sError
 * @param string $sFile
 * @param int $iLine
 * @param string $sExtraInfo
 */
function error_handler($iErrorLevel, $sError, $sFile, $iLine, $sExtraInfo = '')
    {
    if (!error_reporting()) return false;
    $sErrorMsg = '<br />';
    switch ($iErrorLevel)
        {
        case E_WARNING:
        case E_USER_WARNING:
            $sErrorMsg .= '<b>Warning: </b>';
            break;
        case E_NOTICE:
        case E_USER_NOTICE:
            $sErrorMsg .= '<b>Notice: </b>';
            break;
        default:
            $sErrorMsg .= '<b>Error: </b>';
            break;
        }
    $sErrorMsg .= $sError . ' in <b>' . $sFile . '</b>' . ' on line ' . $iLine . '<br />';
    if (DEBUG)
        {
        echo $sErrorMsg;
        }
    else
        {
        Debug::logError($iErrorLevel, $sErrorMsg, $sFile, $iLine, _d($sExtraInfo, 1, 1), Debug::LOG_IN_EMAIL);
        Debug::logError($iErrorLevel, $sErrorMsg, $sFile, $iLine, _d($sExtraInfo, 1, 1), Debug::LOG_IN_DATABASE);
        }
    }

/**
 * handle fatal error or other errors that shutdown the script
 */
function shutdown_handler()
    {
    $aErrorDetails = error_get_last();
    if ($aErrorDetails === null) return;
    if (!error_reporting()) return false;
    $sErrorMsg = '<br />';
    switch ($aErrorDetails['type'])
        {
        case E_ERROR:
            $sErrorMsg .= '<b>Fatal error: </b>';
            break;
        default:
            return;
        }
    $sErrorMsg .= $aErrorDetails['message'] . ' in <b>' . $aErrorDetails['file'] . '</b>' . ' on line ' . $aErrorDetails['line'] . '<br />';

    if (DEBUG)
        {
        echo $sErrorMsg;
        }
    else
        {
        Debug::logError($aErrorDetails['type'], $sErrorMsg, $aErrorDetails['file'], $aErrorDetails['line'], '', Debug::LOG_IN_EMAIL);
        Debug::logError($aErrorDetails['type'], $sErrorMsg, $aErrorDetails['file'], $aErrorDetails['line'], '', Debug::LOG_IN_DATABASE);
        echo 'There is a fatal error. Please contact us.';
        }
    }

/**
 * Insert the address and return the lat long
 * @param string $sAddress
 * @return array (latitude / longitude)
 */
function getLatLong($sAddress)
    {
    $sGeocode = file_get_contents('http://maps.google.com/maps/api/geocode/json?address=' . urlencode($sAddress) . '&sensor=false');
    $oOutput = json_decode($sGeocode);

# Check if there is a lattitude and longitude
    if (empty($oOutput->results[0]->geometry->location->lat) || empty($oOutput->results[0]->geometry->location->lng))
        {
        return NULL;
        }
    else
        {
        $aLocation = array();
        $aLocation['latitude'] = $oOutput->results[0]->geometry->location->lat;
        $aLocation['longitude'] = $oOutput->results[0]->geometry->location->lng;
        return $aLocation;
        }
    }

/**
 * converts HTML characters to HTML entities
 * @param mixed $mValue
 * @return string 
 */
function _e($mValue)
    {
    return htmlentities($mValue, ENT_QUOTES, 'UTF-8');
    }

/**
 *
 * Time ago function
 */
function timeAgo($time_ago)
    {
    $cur_time = time();
    $time_elapsed = $cur_time - $time_ago;
    $seconds = $time_elapsed;
    $minutes = round($time_elapsed / 60);
    $hours = round($time_elapsed / 3600);
    $days = round($time_elapsed / 86400);
    $weeks = round($time_elapsed / 604800);
    $months = round($time_elapsed / 2600640);
    $years = round($time_elapsed / 31207680);
// Seconds
    if ($seconds <= 60)
        {
        echo "$seconds seconds";
        }
//Minutes
    else if ($minutes <= 60)
        {
        if ($minutes == 1)
            {
            echo "one minute";
            }
        else
            {
            echo "$minutes minutes";
            }
        }
//Hours
    else if ($hours <= 24)
        {
        if ($hours == 1)
            {
            echo "an hour";
            }
        else
            {
            echo "$hours hours";
            }
        }
//Days
    else if ($days <= 7)
        {
        if ($days == 1)
            {
            echo "yesterday";
            }
        else
            {
            echo "$days days";
            }
        }
//Weeks
    else if ($weeks <= 4.3)
        {
        if ($weeks == 1)
            {
            echo "a week";
            }
        else
            {
            echo "$weeks weeks";
            }
        }
//Months
    else if ($months <= 12)
        {
        if ($months == 1)
            {
            echo "a month";
            }
        else
            {
            echo "$months months";
            }
        }
//Years
    else
        {
        if ($years == 1)
            {
            echo "one year";
            }
        else
            {
            echo "$years years";
            }
        }
    }

################ Ajax pagination function #########################################

function paginate_function($item_per_page, $current_page, $total_records, $total_pages)
    {
    $pagination = '';
    $recordArray = array('5', '10', '25', '50', '100');
    $pagination .= '<select name="r_per_page" class="perpage">';
    foreach ($recordArray as $val)
        {
        $pagination .= '<option value="' . $val . '" ' . ($item_per_page == $val ? 'selected="selected"' : '') . '>' . $val . '</option>';
        }
    $pagination .='</select>';
    if ($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages)
        { //verify total pages and current page number
        $pagination .= '<ul class="pagination">';

        $right_links = $current_page + 3;
        $previous = $current_page - 1; //previous link 
        $next = $current_page + 1; //next link
        $first_link = true; //boolean var to decide our first link

        if ($current_page > 1)
            {
            $previous_link = ($previous == 0) ? 1 : $previous;
            $pagination .= '<li class="first"><a href="#" data-page="1" title="First">&laquo;</a></li>'; //first link
            $pagination .= '<li><a href="#" data-page="' . $previous . '" title="Previous">&lt;</a></li>'; //previous link
            for ($i = ($current_page - 2); $i < $current_page; $i++)
                { //Create left-hand side links
                if ($i > 0)
                    {
                    //$pagination .= '<li><a href="#" data-page="'.$i.'" title="Page'.$i.'">'.$i.'</a></li>';
                    }
                }
            $first_link = false; //set first link to false
            }
        if ($current_page <= 1)
            {
            $pagination .= '<li class="first"><a href="#" title="First">&laquo;</a></li>'; //first link
            $pagination .= '<li><a href="#"  title="Previous">&lt;</a></li>'; //previous link
            }
        if ($first_link)
            { //if current active page is first link
            //$pagination .= '<li class="first active"><a>'.$current_page.'</a></li>';
            }
        elseif ($current_page == $total_pages)
            { //if it's the last active link
            //$pagination .= '<li class="last active"><a>'.$current_page.'</a></li>';
            }
        else
            { //regular current link
            //$pagination .= '<li class="active"><a>'.$current_page.'</a></li>';
            }

        for ($i = $current_page + 1; $i < $right_links; $i++)
            { //create right-hand side links
            if ($i <= $total_pages)
                {
                //$pagination .= '<li><a href="#" data-page="'.$i.'" title="Page '.$i.'">'.$i.'</a></li>';
                }
            }
        if ($current_page < $total_pages)
            {
            $next_link = ($i > $total_pages) ? $total_pages : $i;
            $pagination .= '<li><a href="#" data-page="' . $next . '" title="Next">&gt;</a></li>'; //next link
            $pagination .= '<li class="last"><a href="#" data-page="' . $total_pages . '" title="Last">&raquo;</a></li>'; //last link
            }
        if ($current_page >= $total_pages)
            {
            $pagination .= '<li><a href="#" title="Next">&gt;</a></li>'; //next link
            $pagination .= '<li class="last"><a href="#" title="Last">&raquo;</a></li>'; //last link
            }
        $pagination .= '<li class="last">Page: ' . $current_page . ' of ' . $total_pages . '</li>'; //last link
        $pagination .= '</ul>';
        }
    return $pagination; //return pagination links
    }

/* function pr($val, $var_name = NULL) {
  if (!empty($val)) {
  echo "<pre>";
  if (isset($var_name)) {
  echo "<div style='color:lightgreen;background-color:black;font-size:18px'>Data for '<font color=red>" . $var_name . "</font>' as [key] => value</div><br>";
  }
  print_r($val);
  echo "</pre>";
  }
  } */
?>