<?php

//SELECT (`A`.student_id) as sid,`A`.name,`A`.birth_date,`A`.sl_date,`A`.house,`A`.sssm_id,`A`.section,P.id,P.f_name,P.m_name,P.village,P.MSID,`A`.adm_classno+'$session'-Year(`A`.fees_date)+COALESCE(B.SumResult,0) AS CClass,T.tpt_stn_id FROM (SELECT * FROM `ms_students` WHERE `MSID`='$msid' AND '$dm' BETWEEN `fees_date` AND `sl_date`) AS A INNER JOIN ms_parents P ON A.parent_id=P.id LEFT JOIN (SELECT MSID,`s_id`,SUM(`result`) AS SumResult FROM `ms_exams` WHERE MSID='$msid'  AND `date_result` <'$dm' GROUP BY s_id) AS B ON A.student_id=B.s_id Left JOIN ms_tpt_std T ON A.MSID=T.MSID AND A.student_id=T.S_id AND '$dm' BETWEEN T.date_from AND T.date_to Having CClass='$cno' AND P.MSID='$msid'  AND T.tpt_stn_id Is Not Null
//https://data.gov.in/catalog/all-india-pincode-directory
error_reporting(E_ALL);
ini_set('display_errors', 'on');
# get micro time to check what time it takes to load the PHP
$iSMT = microtime(true);
 
//"SELECT `feegroupid` ,group_concat(sa.subject_s_name) FROM `ms_fee_slsubgrp` fsg 
//Inner join ms_subjects_all sa on sa.subject_id=fsg.subgroupid WHERE 1 group by `feegroupid`"
// To see what the document root is you can use next line (not working with cron jobs)
//echo $_SERVER['DOCUMENT_ROOT'];
# set document root
//define('DOCUMENT_ROOT', '/home/rootsmann/domains/rootsmann.nl/public_html/');
define('DOCUMENT_ROOT', $_SERVER['DOCUMENT_ROOT'] . '/');
//print_r(DOCUMENT_ROOT);
//exit();
# for checking access in controllers
define("ACCESS", 'xXx');

include_once DOCUMENT_ROOT . '/inc/config.inc.php';

include_once INC_FOLDER . '/loginControl.inc.php';


# get the controller from the $_GET
$sControllerRequest = strtolower(http_get('controller', null));



# controller request is empty? simulate home
if (empty($sControllerRequest))
    {
    $sControllerRequest = 'home';
    $_GET['controller'] = 'home';
    }
# Key = 'controller name', Value = 'path to file' ()

if (@$oCurrentUser->ulevel == '11')
    {
    $aControllers = array(
        'home' => '/controllers/superadmin/home.cont.php',
        'schools' => '/controllers/superadmin/schools.cont.php',
        'users' => '/controllers/superadmin/users.cont.php',
        'profile' => '/controllers/superadmin/profile.cont.php',
        'subjectall' => '/controllers/superadmin/subjectall.cont.php',
        'subjectgroup' => '/controllers/superadmin/subjectgroup.cont.php',
        'school-subject-group' => '/controllers/superadmin/schoolsubjects.cont.php',
        'ajax-load' => '/controllers/superadmin/ajax-load.cont.php',
        'ajax-post' => '/controllers/superadmin/ajax-post.cont.php',
        'fee-name' => '/controllers/superadmin/feenames.cont.php',
        'fee-type' => '/controllers/superadmin/feetype.cont.php',
        'fee-group' => '/controllers/superadmin/feegroup.cont.php',
        'fee-schedule' => '/controllers/superadmin/feeschedule.cont.php',
        'fee-billing-genrater' => '/controllers/superadmin/feebilling_genrater.cont.php',
        'board' => '/controllers/superadmin/board.cont.php',
        'fee' => '/controllers/superadmin/fee.cont.php',
        'fee-genrator' => '/controllers/superadmin/fee_copy.cont.php',
        'settings' => '/controllers/superadmin/setting.cont.php',
        'discount' => '/controllers/superadmin/discount.cont.php',
        'discount-rules' => '/controllers/superadmin/discountRule.cont.php',
        'discounted-students' => '/controllers/superadmin/discountedStudents.cont.php',
        'houses' => '/controllers/superadmin/houses.cont.php'
    );
    }
else if (@$oCurrentUser->ulevel == '9')
    {

//    if($oCurrentUser->status == '1')
    $status = '1';
    if ($oCurrentUser->status == $status)
        {
        $aControllers = array('changepassword' => '/controllers/changepass.cont.php');
        }
    else
        {

        $aControllers = array(
            'home' => '/controllers/home.cont.php',
            'login' => '/controllers/login.cont.php',
            'admissions' => '/controllers/admin/admission/admissions.cont.php',
            'enrollment' => '/controllers/admin/admission/enrollmentform.cont.php',
            'selection' => '/controllers/admin/admission/selection.cont.php',
            'rejected' => '/controllers/admin/admission/rejected.cont.php',
            'parents' => '/controllers/admin/parent/parents.cont.php',
            'parents-old' => '/controllers/admin/parent/old_parents.cont.php',
            'employee' => '/controllers/admin/employee/employee.cont.php',
            'employee-old' => '/controllers/admin/employee/employee_old.cont.php',
            'icard_print' => '/controllers/admin/student/icard_print.cont.php',
            'students' => '/controllers/admin/student/student.cont.php',
            'quick-search' => '/controllers/admin/student/quicksearch.cont.php',
            'academic-add' => '/controllers/admin/exam/academic_add.cont.php',
            'exam-grades' => '/controllers/admin/exam/grade.cont.php',
            'assesments' => '/controllers/admin/exam/assesment.cont.php',
            'remarks' => '/controllers/admin/exam/remarks.cont.php',
            'activities' => '/controllers/admin/exam/activities.cont.php',
            'activities-assign' => '/controllers/admin/exam/activities_assign.cont.php',
            'co-scholastic-areas' => '/controllers/admin/exam/co_scholastic_areas.cont.php',
            'co-scholastic-marks' => '/controllers/admin/exam/co_scholastic_marks.cont.php',
            'co-scholastic-indicators' => '/controllers/admin/exam/co_scholastic_indicators.cont.php',
            'academic-performance' => '/controllers/admin/exam/academic_performance.cont.php',
            'consolidated-report' => '/controllers/admin/exam/consolidated_report.cont.php',
            'failed-students' => '/controllers/admin/exam/failed_students.cont.php',
            'promoted-students' => '/controllers/admin/exam/promoted_students.cont.php',
            'report-cards' => '/controllers/admin/exam/report_card.cont.php',
            'final-report' => '/controllers/admin/exam/final_report.cont.php',
            'gradewise-list' => '/controllers/admin/exam/gradewise_list.cont.php',
            'health-data' => 'controllers/admin/exam/health_data.cont.php',
            'tptroutewise' => '/controllers/admin/tpt/routewise.cont.php',
            'tptroutes' => '/controllers/admin/tpt/routes.cont.php',
            'tptstations' => '/controllers/admin/tpt/stations.cont.php',
            'tptfee' => '/controllers/admin/tpt/fee.cont.php',
            'attendances' => '/controllers/admin/attendance/attendance.cont.php',
            'emp_attendances' => '/controllers/admin/attendance/empattendance.cont.php',
            'term-attendances' => '/controllers/admin/attendance/term.cont.php',
            'month_attendances' => '/controllers/admin/attendance/month_attendance.cont.php',
            'sms' => '/controllers/admin/sms/sms.cont.php',
            'feevoucher' => '/controllers/admin/fee/voucher.cont.php',
            'feevoucher-tpt' => '/controllers/admin/fee/voucher_tpt.cont.php',
            'feevoucher-without-tpt' => '/controllers/admin/fee/voucher_without_tpt.cont.php',
            'fee-structure' => '/controllers/admin/fee/structure.cont.php',
            'fee-detail' => '/controllers/admin/fee/detail.cont.php',
            'fee-defaulter' => '/controllers/admin/fee/defaulters.cont.php',
            'fee-report' => '/controllers/admin/fee/fee_report.cont.php',
            'fee-report-monthly' => '/controllers/admin/fee/fee_report_monthly.cont.php',
            'fee-report-month-day' => '/controllers/admin/fee/fee_report_month_day.cont.php',
            'fee-summary' => '/controllers/admin/fee/summary.cont.php',
            'fee-headwise' => '/controllers/admin/fee/headwise.cont.php',
            'fee-transaction' => '/controllers/admin/fee/fee_transaction.cont.php',
            'timetable-classwise' => '/controllers/admin/timetable/classwise.cont.php',
            'master-class' => '/controllers/admin/timetable/master_class.cont.php',
            'timetable-teachers' => '/controllers/admin/timetable/teacherswise.cont.php',
            'master-timetable' => '/controllers/admin/timetable/master.cont.php',
            'library' => '/controllers/admin/library/library.cont.php',
            'homework' => '/controllers/admin/homework/homework.cont.php',
            'hostels' => '/controllers/admin/hostel/hostel.cont.php',
            'hostelers' => '/controllers/admin/hostel/hostelers.cont.php',
            //fdgdf
            'locality' => '/controllers/locality.cont.php',
            'category' => '/controllers/category.cont.php',
            'department' => '/controllers/department.cont.php',
            'designation' => '/controllers/designation.cont.php',
            'msclass' => '/controllers/classes.cont.php',
            'ajax' => '/controllers/ajax/fee.cont.php',
            'exam-load' => '/controllers/ajax/exam.cont.php',
            'exam-post' => '/controllers/ajax/post_exam.cont.php',
            'tpt-load' => '/controllers/ajax/tpt.cont.php',
            'tpt-post' => '/controllers/ajax/post_tpt.cont.php',
            'ajax-post' => '/controllers/ajax/post_fee.cont.php',
            'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
            'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
            'profile' => '/controllers/profile.cont.php',
            'sessionwise' => '/controllers/sessionwise.cont.php',
            'settings' => '/controllers/setting.cont.php',
            'houses' => '/controllers/houses.cont.php',
            'activityfeeds' => '/controllers/activityfeed.cont.php',
            'subject' => '/controllers/subject.cont.php',
            'modules' => '/controllers/module.cont.php',
            'role' => '/controllers/role.cont.php',
            'event-calender' => '/controllers/event_calender.cont.php',
            'half-yearly' => '/controllers/designs/half_yearly.cont.php',
            'report-card' => '/controllers/designs/report_card.cont.php',
            'character-certificate' => '/controllers/designs/character_certificate.cont.php',
            'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
            'errors' => '/controllers/errors.cont.php',
            'registration-form' => '/controllers/designs/registration_form.cont.php',
            'fee-book' => '/controllers/designs/fee_book.cont.php',
            'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
            'tc' => '/controllers/designs/tc.cont.php',
            'security' => '/controllers/admin/camara/security_cam.cont.php',
            'changepassword' => '/controllers/changepass.cont.php',
            'discounted-students' => '/controllers/discounted_student.cont.php',
                //'forgotpassword'=>'/controllers/forgotpassword.cont.php'
        );
        }
    }
else if (@$oCurrentUser->ulevel == '7')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'attendances' => '/controllers/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/attendance/empattendance.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => 'controllers/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => 'controllers/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
    );
    }
else if (@$oCurrentUser->ulevel == '5')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'attendances' => '/controllers/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/attendance/empattendance.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => 'controllers/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => 'controllers/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
    );
    }
else if (@$oCurrentUser->ulevel == '3')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'attendances' => '/controllers/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/attendance/empattendance.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => 'controllers/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => 'controllers/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
    );
    }
else if (@$oCurrentUser->ulevel == '2')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'attendances' => '/controllers/attendance/attendance.cont.php',
        'emp_attendances' => '/controllers/attendance/empattendance.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => 'controllers/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => 'controllers/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
    );
    }
else if (@$oCurrentUser->ulevel == '1')
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'myprofile' => '/controllers/student/profile.cont.php',
        'timetable' => '/controllers/student/timetable.cont.php',
        'myclassmates' => '/controllers/student/myclassmates.cont.php',
        'myteachers' => '/controllers/student/myteachers.cont.php',
        'attendance' => '/controllers/student/attendance.cont.php',
        'homework' => '/controllers/student/homework.cont.php',
        'feeaccount' => '/controllers/student/feeac.cont.php',
        'reportcard' => '/controllers/student/reportcard.cont.php',
        'hyap' => '/controllers/student/hyap.cont.php',
    );
    }
else
    {
    $aControllers = array(
        'home' => '/controllers/home.cont.php',
        'login' => '/controllers/login.cont.php',
        'admissions' => '/controllers/admissions.cont.php',
        'enrollment' => '/controllers/enrollmentform.cont.php',
        'selection' => '/controllers/selection.cont.php',
        'rejected' => '/controllers/rejected.cont.php',
        'parents' => '/controllers/parents.cont.php',
        'employee' => '/controllers/employee.cont.php',
        'locality' => '/controllers/locality.cont.php',
        'category' => '/controllers/category.cont.php',
        'department' => '/controllers/department.cont.php',
        'designation' => '/controllers/designation.cont.php',
        'msclass' => '/controllers/classes.cont.php',
        'ajax-page-load' => '/controllers/ajax-page-load.cont.php',
        'ajax-page-post' => '/controllers/ajax-page-post.cont.php',
        'profile' => '/controllers/profile.cont.php',
        'students' => '/controllers/student.cont.php',
        'sessionwise' => '/controllers/sessionwise.cont.php',
        'settings' => '/controllers/setting.cont.php',
        'houses' => '/controllers/houses.cont.php',
        'tptroutewise' => '/controllers/tpt/routewise.cont.php',
        'tptroutes' => '/controllers/tpt/routes.cont.php',
        'tptstations' => '/controllers/tpt/stations.cont.php',
        'tptfee' => '/controllers/tpt/fee.cont.php',
        'activityfeeds' => '/controllers/activityfeed.cont.php',
        'homework' => '/controllers/homework.cont.php',
        'subject' => '/controllers/subject.cont.php',
        'modules' => '/controllers/module.cont.php',
        'role' => '/controllers/role.cont.php',
        'event-calender' => '/controllers/event_calender.cont.php',
        'library' => '/controllers/library.cont.php',
        'exam-grades' => '/controllers/exam/grade.cont.php',
        'assesments' => 'controllers/exam/assesment.cont.php',
        'remarks' => 'controllers/exam/remarks.cont.php',
        'co-scholastic-areas' => '/controllers/exam/co_scholastic_areas.cont.php',
        'co-scholastic-marks' => '/controllers/exam/co_scholastic_marks.cont.php',
        'co-scholastic-indicators' => '/controllers/exam/co_scholastic_indicators.cont.php',
        'academic-performance' => 'controllers/exam/academic_performance.cont.php',
        'consolidated-report' => 'controllers/exam/consolidated_report.cont.php',
        'failed-students' => '/controllers/exam/failed_students.cont.php',
        'promoted-students' => '/controllers/exam/promoted_students.cont.php',
        'half-yearly' => '/controllers/designs/half_yearly.cont.php',
        'report-card' => '/controllers/designs/report_card.cont.php',
        'character-certificate' => '/controllers/designs/character_certificate.cont.php',
        'confidential-letter' => '/controllers/designs/confidential_letter.cont.php',
        'health-data' => 'controllers/exam/health_data.cont.php',
        'final-report' => '/controllers/exam/final_report.cont.php',
        'gradewise-list' => '/controllers/exam/gradewise_list.cont.php',
        'hostels' => '/controllers/hostel.cont.php',
        'hostelers' => '/controllers/hostelers.cont.php',
        'errors' => '/controllers/errors.cont.php',
        'feevoucher' => '/controllers/fee/voucher.cont.php',
        'fee-structure' => '/controllers/fee/structure.cont.php',
        'fee-detail' => '/controllers/fee/detail.cont.php',
        'fee-defaulter' => '/controllers/fee/defaulters.cont.php',
        'fee-report' => '/controllers/fee/fee_report.cont.php',
        'fee-summary' => '/controllers/fee/summary.cont.php',
        'fee-headwise' => '/controllers/fee/headwise.cont.php',
        'registration-form' => '/controllers/designs/registration_form.cont.php',
        'fee-book' => '/controllers/designs/fee_book.cont.php',
        'birth-certificate' => '/controllers/designs/birth_certificate.cont.php',
        'tc' => '/controllers/designs/tc.cont.php',
        'report-cards' => '/controllers/exam/report_card.cont.php',
    );
    }
# get the controller 'path to file' from the controller array
if (array_key_exists($sControllerRequest, $aControllers))
    {
    $sControllerPath = $aControllers[$sControllerRequest];
    }
else
    {
    # Path found? GO
    if (empty($sControllerPath) && !empty($sControllerRequest))
        {
        # non existing controller request and page
        //showHttpError(404);
        $iErrorNr = 404;
        include_once DOCUMENT_ROOT . "/controllers/errors.cont.php";
        }
    }

if (file_exists(DOCUMENT_ROOT . $sControllerPath))
    {
    include_once DOCUMENT_ROOT . $sControllerPath;
    }
else
    {
    //showHttpError(404);
    $iErrorNr = 404;
    include_once DOCUMENT_ROOT . "/controllers/errors.cont.php";
    }
if (DEBUG)
    {
    //echo "Time to load PHP: " . ($iEMT - $iSMT) . " sec";
    }
# save referrer for redirecting after login
if (http_get('controller') != 'account' && !(http_get('controller') == 'winkelwagen' && empty($_GET['param1'])))
    {
    $_SESSION['frontendLoginReferrer'] = getCurrentUrlPath(true, true);
    }

?>