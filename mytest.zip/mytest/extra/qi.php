<?php

$q= "


Select MN1.mydate,MN1.AcNo,MN1.name,MN1.admno,MN1.section,MN1.opening_bal,MN1.FeeAmt , MN1.DueDate 
from (
Select mn.mydate,mn.AcNo,mn.name,mn.admno,mn.section,mn.opening_bal,mn.DueDate,mn.FeeAmt,mn.RSrNo
FROM (
SELECT U.mydate,m.AcNo,S.name,S.admno,S.section,S.opening_bal,m.DueDate,m.FeeAmt,m.RSrNo
FROM 
`ms_fee_billing` m 
Inner Join ms_students S On S.MSID =m.MSID And S.student_id =  m.SID
Inner Join ms_slusers  U WHERE U.myuid = '1001e1' And m.MSID = 1001 
) mn group by mn.AcNo ,mn.RSrNo 
) MN1 Where MN1.DueDate <= DATE_SUB(MN1.mydate,interval 10 Day) group by MN1.AcNo 











Select MN1.mydate,MN1.AcNo,MN1.name,MN1.f_name,MN1.admno,MN1.section,MN1.village,MN1.mobile_sms,MN1.opening_bal,MN1.FeeAmt , MN1.DueDate 
from (
Select mn.mydate,mn.AcNo,mn.name,mn.f_name,mn.admno,mn.section,mn.village,mn.mobile_sms,mn.opening_bal,mn.DueDate,mn.FeeAmt,mn.RSrNo
FROM (
SELECT U.mydate,m.AcNo,S.name,p.f_name,S.admno,S.section,p.village,p.mobile_sms,S.opening_bal,m.DueDate,m.FeeAmt,m.RSrNo
FROM 
`ms_fee_billing` m 
Inner Join ms_students S On S.MSID =m.MSID Inner Join ms_parents p On S.parent_id =p.id 
Inner Join ms_slusers  U WHERE U.myuid = '1001e1' And m.MSID = 1001 
) mn group by mn.AcNo ,mn.RSrNo 
) MN1 Where MN1.DueDate <= Date_add(MN1.mydate,interval -10 Day) group by MN1.AcNo ";