
<?php $s="  
Select CSD.MSID MSID,CSD.AcNo AcNo,CSD.SID SID,CSD.SrNo SrNo,FS.RSrNo RSrNo,CSD.DueDate DueDate,CSD.FeeId FeeId,round(Sum(If(FEE.FeeId=0,COALESCE(TR.TptRate,0), 

FEE.FeeRate))*(1-COALESCE (DR.Percent,0))-(COALESCE(DR.FixedAmt,0))) FeeAmt
From (/*--------------------------------------CSD Starts ------------------------------------ */
Select Q1.*,If(Month(Q1.DueDate)-Month(Q1.Begins)+1 >0,Month(Q1.DueDate)-Month(Q1.Begins)+1,Month(Q1.DueDate)-Month (Q1.Begins)+13) SrNo 

,Q1.AdmClassNo+Year(Q1.Begins)-Year(Q1.FSDate)+COALESCE(Sum(E.Result),0) 

CClass,SFG.FgroupId,SAT.TptStation,DS.Discount,P.FatherName,P.MobileSMS,P.FeePaymentMode 
FROM (/*+++++++++++++++++++++++++++++++++++++++++++++++++Q1 Starts+++++++++++++++++++++++++++++++++++++++++++++++*/
Select S.Id SID,S.PID,S.AcNo,S.Name StudentName,S.AdmClassNo,S.FSDate,S.SLDate,S.GroupId,S.OpeningBal,DD.DateId DueDate,FN.Id 

FeeId,FN.FeeName,FN.FeeGroup,COY.Name SchoolName,COY.SeprateTPTFBook,CU.MSID,CU.Mydate,CU.MySession,CU.Begins,CU.Ends From (SELECT * 

FROM `91Users` WHERE MyUid = '1001vm1' ) CU    Inner Join 10Company COY On COY.MSID = CU.MSID Inner Join 6Dates DD On DD.DateId Between 

CU.Begins And CU.Ends And Day(DateId) = '1' Inner Join 13Students S On S.MSID =CU.MSID And DD.DateID Between S.FSDate And S.SLDate Inner 

Join 7FeeNames FN On FN.MSID=CU.MSID 
/*Where S.AcNo='6'*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++ Q1 Ends ++++++++++++++++++++++++++++++++++++++++++++++++++*/
) Q1 
      
Left Join 
14Exam E On E.MSID = Q1.MSID AND E.S_Id=Q1.SID And E.DateResult<Q1.DueDate 
Inner Join 
100SchoolFeeGrp SFG On SFG.MSID=Q1.MSID AND SFG.GroupId=Q1.GroupId 
Left Join 
35SATpt SAT ON SAT.MSID=Q1.MSID And Q1.DueDate Between SAT.DateFrom And SAT.DateTo And SAT.S_Id=Q1.SID 
Left Join 
34DiscountedStudent DS ON DS.MSID=Q1.MSID And DS.S_Id=Q1.SID And Q1.DueDate Between DS.DateFrom And DS.DateTo 
Inner Join 
12Parents P On P.Id=Q1.PID
Inner Join
11Localities L On L.MSID=Q1.MSID And L.Village=P.Village
 
Where 1
Group By Q1.SID, Q1.DueDate,Q1.FeeId
/*-----------------------------------------------------------CSD Ends------------------------------------*/
) CSD

Inner Join 
31FeeSchedule FS On FS.MSID=CSD.MSID And FS.PayMode=CSD.FeePaymentMode  And CSD.SrNo Between FS.SrNoFrom And FS.SrNoTo
Inner Join 
31Fee1 FEE On FEE.MSID=CSD.MSID And CSD.DueDate Between FEE.DateFrom And FEE.DateTo And FEE.FeeId=CSD.FeeId And CSD.CClass Between 

FEE.ClassFrom And 

FEE.ClassTo And 
(CSD.FGroupId=FEE.FGroupId Or FEE.FGroupId = '0') And If(FEE.FF='1' And CSD.DueDate=CSD.FSDate,CSD.SrNo Between FEE.FFFrom And 

FEE.FFTo,CSD.SrNo Between 

FEE.SrNoFrom And FEE.SrNoTo)
Left Join 
36TptRate TR On TR.MSID=CSD.MSID And CSD.DueDate Between TR.DateFrom And TR.DateTo And CSD.TptStation=TR.TptStation
Left Join 
33DiscountRule DR On DR.MSID=CSD.MSID And CSD.DueDate Between DR.DateFrom And DR.DateTo And DR.Discount=CSD.Discount And 

DR.FeeId=FEE.FeeId And CSD.CClass 

Between DR.ClassFrom And DR.ClassTo And CSD.SrNo Between DR.SrNoFrom And DR.SrNoTo 
Group By AcNo,SrNo,SID,FeeId " ; 






$us =" 

Select CSD.MSID MSID,CSD.AcNo AcNo,CSD.SID SID,CSD.SrNo SrNo,FS.r_sr_no r_sr_no,CSD.DueDate DueDate,CSD.FeeId FeeId,round(Sum(If(FEE.fee_id=0,COALESCE(TR.fee,0), 

FEE.fee_rate))*(1-COALESCE (DR.percent,0))-(COALESCE(DR.fixed_amount,0))) FeeAmt
From (/*--------------------------------------CSD Starts ------------------------------------ */
Select Q1.*,If(Month(Q1.DueDate)-Month(Q1.Begins)+1 >0,Month(Q1.DueDate)-Month(Q1.Begins)+1,Month(Q1.DueDate)-Month (Q1.Begins)+13) SrNo 

,Q1.adm_classno+Year(Q1.Begins)-Year(Q1.fees_date)+COALESCE(Sum(E.result),0) 

CClass,SFG.fee_group_id FgroupId,SAT.tpt_stn_id TptStation,DS.discount_id Discount,P.f_name,P.mobile_sms MobileSMS,P.feepaymentmode FeePaymentMode 
FROM (/*+++++++++++++++++++++++++++++++++++++++++++++++++Q1 Starts+++++++++++++++++++++++++++++++++++++++++++++++*/
Select S.student_id SID,S.parent_id,S.acno AcNo,S.name StudentName, S.adm_classno, S.fees_date, S.sl_date, S.group_id, S.opening_bal,DD.date_id DueDate, FN.fee_id FeeId,FN.fee_name FeeName,FN.fee_group_name FeeGroup,COY.name SchoolName, COY.SeprateTPTFBook, CU.MSID, CU.mydate Mydate, CU.mysession MySession, CU.begins Begins, CU.ends Ends From (SELECT * FROM `ms_slusers` WHERE myuid = '1001vm1' ) CU
Inner Join ms_schools COY On COY.MSID = CU.MSID
Inner Join ms_dates DD On DD.date_id Between CU.begins And CU.ends And Day(date_id) = '1' 
Inner Join ms_students S On S.MSID = CU.MSID And DD.date_id Between S.fees_date And S.sl_date
Inner Join ms_fee_names FN On FN.MSID=CU.MSID order by S.student_id, DD.date_id 
/*Where S.AcNo='6'*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++ Q1 Ends ++++++++++++++++++++++++++++++++++++++++++++++++++*/
) Q1 
      
Left Join 
ms_exams E On E.MSID = Q1.MSID AND E.s_id=Q1.SID And E.date_result<Q1.DueDate 
Inner Join 
ms_subjects SFG On SFG.MSID=Q1.MSID AND SFG.subject_gp_id=Q1.group_id 
Left Join 
ms_tpt_std SAT ON SAT.MSID=Q1.MSID And Q1.DueDate Between SAT.date_from And SAT.date_to And SAT.S_id=Q1.SID 
Left Join 
ms_discounted_student DS ON DS.MSID=Q1.MSID And DS.s_id=Q1.SID And Q1.DueDate Between DS.date_from And DS.date_to 
Inner Join 
ms_parents P On P.id=Q1.parent_id
Inner Join
ms_locality L On L.MSID=Q1.MSID And L.id=P.village
 
Where 1
Group By Q1.SID, Q1.DueDate,Q1.FeeId
/*-----------------------------------------------------------CSD Ends------------------------------------*/
) CSD

Inner Join 
ms_fee_schedule FS On FS.MSID=CSD.MSID And FS.pay_mode=CSD.FeePaymentMode  And CSD.SrNo Between FS.sr_no_from And FS.sr_no_to 
Inner Join 
ms_fee FEE On FEE.MSID=CSD.MSID And CSD.DueDate Between FEE.date_from And FEE.date_to And FEE.fee_id=CSD.FeeId And CSD.CClass Between FEE.class_from And FEE.class_to And 
(CSD.FgroupId=FEE.fee_group_id Or FEE.fee_group_id = '0') And If(FEE.ff='1' And CSD.DueDate=CSD.fees_date,CSD.SrNo Between FEE.ff_from And FEE.ff_to,CSD.SrNo Between FEE.sr_no_from And FEE.sr_no_to)
Left Join 
ms_tpt_fee TR On TR.MSID=CSD.MSID And CSD.DueDate Between TR.date_from And TR.date_to And CSD.TptStation=TR.station_id
Left Join 
ms_discount_rule DR On DR.MSID=CSD.MSID And CSD.DueDate Between DR.date_from And DR.date_to And
DR.discount_id=CSD.Discount And DR.fee_id=FEE.fee_id And CSD.CClass
Between DR.class_from And DR.class_to And CSD.SrNo Between DR.sr_no_from And DR.sr_no_to 
Group By AcNo,SrNo,SID,FeeId";